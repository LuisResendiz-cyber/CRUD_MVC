const Joi = require("joi");

const fs = require("fs");

const regExName = new RegExp(/^[a-zA-ZñÑáéíóúüÁÉÍÓÚÜ\s\.]+$/);

const templateMailSchema = Joi.object({
  nombrePlantilla: Joi.string().required(),
  correoRemitente: Joi.string().email().required(),
  nombreRemitente: Joi.string().required(),
  asunto: Joi.string().required(),
  contenidoPlantilla: Joi.string().required(),
});

const templateSmsSchema = Joi.object({
  msg: Joi.string().required(),
  tel: Joi.string()
    .length(10)
    .pattern(/^[0-9]+$/)
    .required(),
  campana: Joi.string().required(),
});
const templateLayoutSchema = Joi.object({
  layout: Joi.object({
    fieldname: Joi.string().required(),
    originalname: Joi.string().required(),
    encoding: Joi.string().required(),
    mimetype: Joi.string().valid("image/jpeg", "image/png").required(),
    size: Joi.number().max(5242880).required(), // 5MB en bytes
  }).required(),
});

const templateSendMailTemp = Joi.object({
  correoRemitente: Joi.string().required(),
  idTemplate: Joi.string().required(),
  nombreRemitente: Joi.string().required(),
});

const templateDataMail = Joi.object({
  email: Joi.string().required(),
  subject: Joi.string().required(),
  content: Joi.string().required(),
});
const templateSmsScotia = Joi.object({
  opcion: Joi.string().required(),  
});

/* const templateDataRfc = Joi.object({
  nombre: Joi.string().required(),
  ap_paterno: Joi.string().required(),
  ap_materno: Joi.string().allow('').optional(),
  fecha_nacimiento: Joi.string().required(),
});
 */
const templateDataRfc = Joi.object({
  nombre: Joi.string().required().pattern(regExName).messages({
    'string.empty': 'campo nombre vacio',
    'string.pattern.base': 'Formato nombre incorrecto'
  }),
  ap_paterno: Joi.string().required().pattern(regExName).messages({
    'string.empty': 'campo nombre vacio',
    'string.pattern.base': 'Formato ap paterno incorrecto'
  }),
  ap_materno: Joi.string().allow('').optional().pattern(regExName).messages({
    'string.pattern.base': 'Formato ap materno incorrecto'
  }),
  fecha_nacimiento: Joi.string().required().pattern(new RegExp(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/)).messages({
    'string.empty': 'campo fecha vacio',
    'string.pattern.base': 'Formato fecha incorrecto'
  })
});

const templateDataCampaign = Joi.object({
  campaign: Joi.number().required(),
});

const templateDataProveedor = Joi.object({
  campaign: Joi.number().required(),
  idCredenciales: Joi.number().required(),
  activo: Joi.number().required(),
});

const validarSms = (req, res, next) => {
  const { error } = templateSmsSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const validarDataRfc = (req, res, next) => {
  const { error } = templateDataRfc.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const checkCampaign = (req, res, next) => {
  const { error } = templateDataCampaign.validate(req.query);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const checkProveedor = (req, res, next) => {
  const { error } = templateDataProveedor.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const validarTemplateMail = (req, res, next) => {
  const { error } = templateMailSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const checkSendMailTemplate = (req, res, next) => {
  const { error } = templateSendMailTemp.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};
const checkSendMail = (req, res, next) => {
  const { error } = templateDataMail.validate(req.body);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};
const smsScotia = (req, res, next) => {
  const { error } = templateSmsScotia.validate(req.query);
  if (error) {
    return res.status(400).json({ status: false, details: error.message });
  }
  next();
};

const validarUpload = (req, res, next) => {
  const filePath = "src/public/html/" + req.file.originalname;

  fs.stat(filePath, (err, stats) => {
    if (err) {
      console.error("Error al verificar el archivo:", err);
      return res.status(400).json({ status: false, details: err });
    } else {
      console.log("El archivo se ha subido correctamente");
      // Realizar acciones adicionales si es necesario
    }
  });

  next();
};

const validarCsvUpload = (req, res, next) => {
  const filePath = "src/public/csv/" + req.file.originalname;

  fs.stat(filePath, (err, stats) => {
    if (err) {
      console.error("Error al verificar el archivo CSV:", err);
      return res.status(400).json({ status: false, details: err });
    } else {
      console.log("El archivo CSV se ha subido correctamente");
    }
  });

  next();
};

const check = {
  validarSms,
  validarTemplateMail,
  validarUpload,
  checkSendMailTemplate,
  validarCsvUpload,
  checkSendMail,
  smsScotia,
  validarDataRfc,
  checkCampaign,
  checkProveedor
};

module.exports = check;
