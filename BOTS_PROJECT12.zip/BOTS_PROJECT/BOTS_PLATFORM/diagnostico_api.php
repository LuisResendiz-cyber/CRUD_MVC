<?php
$url = "http://host.docker.internal:4001/Users/CreateUser";

$data = [
    "customer_id" => "1",
    "name" => "Luis Fernando",
    "last_name" => "Resendiz Mendoza",
    "phone_number" => "4411003234",
    "email_user" => "luresendiz@impulse-telecom.com",
    "passwordHash" => "luis123luis",
    "rolid" => 1
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($data),
]);

$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

var_dump($response, $error);
