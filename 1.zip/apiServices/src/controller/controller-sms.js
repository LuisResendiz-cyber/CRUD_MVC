const { actionsMysql } = require("../model/model-mysql");
const { enviarSMS, smsMasivoDigital,smsMasivoScotiabank,smsMasivoHsbc } = require("../model/model-sms");
const { oraExcProc,oraExcProcNoCursor,createConnObj } = require("../model/model-oracle");


const actSms = {
  test: (req, res) => {
    console.log("peticion test sms");
    res.json({ status: 200, rspta: "Mensaje enviado", proveedor: 1 });
  },
  sendSms: async (req, res) => {
    const { msg, tel, campana } = req.body;

    const credencialesSMS = await actionsMysql.credencialesSms(campana);
 
    if (credencialesSMS.length > 0) {
      const result = await enviarSMS(credencialesSMS, msg, tel);
      
      const rspta = JSON.stringify(result);
      await actionsMysql.saveLogSms(campana, tel+'|'+rspta.slice(0,450),"INDIVIDUAL", result.proveedor );
      
      res.send(result);
    } else {
      await actionsMysql.saveLogSms( campana,"Sin Credenciales", "Sin Datos", "Sin Proveedor" );
      console.log("Sin Credenciales");
      res.send({ rspta: "Sin Credenciales para ejecutar envio masivo" });
    }
  },


  sendSmsMasivoDigital: async (req, res) => {
    const campaign = 1008;
    const nameProcedure="XSP_GET_DATOS_SMS"
    objConnOracle =await createConnObj(campaign,nameProcedure)   
    if (objConnOracle != null || objConnOracle != undefined) {    
      try {
        const msjMasivos = await oraExcProc(objConnOracle);

        if (msjMasivos.length) {
          const credencialesSMS = await actionsMysql.credencialesSms(campaign);
          const result = await smsMasivoDigital(credencialesSMS, msjMasivos);

          const da = JSON.stringify(result);
          await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL",1)
          await actionsMysql.saveLogSms(campaign, da, "MASIVO")
          res.send(result);
        } else {
          await actionsMysql.saveLogSms(campaign,"Sin numero para enviar mensajes","MASIVO");
          await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL",0)
          console.log("Sin numeros para ejecutar envio masivo");
          res.status(402).json({ status: 402, rspta: "Sin numeros para ejecutar envio masivo" });
          
        }
      } catch (error) {
        res.status(500).send({ error: error.message });
      }
    } else {
      console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    }
  },
  sendSmsMasivoScotiabank: async (req, res) => {
      const campaign = 1002;
      const {opcion}= req.query 
      const nameProcedure="xsp_sanasPractivas"
      let parameters = { option: opcion, customerid: 0, surveyid : 0 }

      objConnOracle =await createConnObj(campaign,nameProcedure,parameters)      
      if (objConnOracle == null || objConnOracle == undefined) {    
        console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
        res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
      }else {        
        try {          
          const oraRspta = await oraExcProc(objConnOracle);          
          if (oraRspta == 0) {
            console.log("NO DATA IN ORACLE")                        
            res.json({ status: 402, rspta: "NO DATA IN ORACLE" });
          }else {
            // console.log('con datos')            
            const credencialesSMS = await actionsMysql.credencialesSms(campaign);
            const smsScotiabank = await actionsMysql.smsScotiabank(campaign);
            
            const result = await smsMasivoScotiabank(oraRspta, credencialesSMS,smsScotiabank);
            
            const da = JSON.stringify(result.TOTAL);
            await actionsMysql.saveLogCron("SMS MASIVOS SCOTIABANK",1)
            await actionsMysql.saveLogSms(campaign, `{"status":200,"desc":"Total mensajes enviados: ${da} "}`, "MASIVO",1);            
            let detalles = {...result.DETALLES}            
            // console.log(detalles)
            for (const key in detalles) {
              if (detalles.hasOwnProperty(key)) {
                const elemento = detalles[key];                
                let insertLogOra = {...objConnOracle}
                insertLogOra.nameProcedure='xsp_ingresa_log'
                insertLogOra.parameters = elemento
                const oraRspta = await oraExcProcNoCursor(insertLogOra);   
                console.log(oraRspta)   
              }
            }
            res.send(result);
          }
        } catch (error) {
          res.status(500).send({ error: error.message });
        }        
      }
  },
  sendSmsMasivoHsbc : async (req,res) => {

    const campaign = 998;
    const nameProcedure="XSP_GET_SMS_EMAIL"
    objConnOracle =await createConnObj(campaign,nameProcedure)       
    if (objConnOracle == null || objConnOracle == undefined) {    
      console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    } else {

      try {
        const msjMasivos = await oraExcProc(objConnOracle);

        if (msjMasivos.length < 1) {
          res.status(402).json({ status: 402, rspta: "Sin numeros para ejecutar envio masivo" });
          await actionsMysql.saveLogSms(campaign,"Sin numero para enviar mensajes","MASIVO");          
        }else {
          const credencialesSMS = await actionsMysql.credencialesSms(campaign);
          const result = await smsMasivoHsbc(credencialesSMS, msjMasivos);
          const da = JSON.stringify(result);
          // await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL",1)
          await actionsMysql.saveLogSms(campaign, da, "MASIVO")
          res.json(result)
        }

      } catch (error) {
        console.log(error)
      }

      
    }
  }

};

module.exports = { actSms };
