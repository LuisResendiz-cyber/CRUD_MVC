<?php
ini_set('display_errors', true);
ini_set("soap.wsdl_cache_enabled", "0");

require_once("lib/nusoap.php");
require_once("calcular_rfc.php");

$server = new soap_server();
$server->configureWSDL("GenerarRFC", "urn:GenerarRFC");

$server->register(
        "CalcularRFC",
        array(
            "nombre" => "xsd:string",
            "apellidoPaterno" => "xsd:string",
            "apellidoMaterno" => "xsd:string",
            "fecha" => "xsd:string"),
        array(
            "return" => "xsd:string"
            ),
        "urn:generarrfc", "urn:generarrfc#CalcularRFC");

function CalcularRFC($nombre, $apellidoPaterno, $apellidoMaterno, $fecha) {
    /*
     * Cambiamos todo a may�sculas.
     * Quitamos los espacios al principio y final del nombre y apellidos
     */
    $nombre = strtoupper(trim($nombre));
    $nombre = str_replace(array('�', '�', '�', '�'), 'A', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'E', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'I', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'O', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'U', $nombre);
    $nombre = str_replace(array('�', '�'), '&', $nombre);
    $apellidoPaterno = strtoupper(trim($apellidoPaterno));
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'A', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'E', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'I', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'O', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'U', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�'), '&', $apellidoPaterno);
    $apellidoMaterno = strtoupper(trim($apellidoMaterno));
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'A', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'E', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'I', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'O', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'U', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�'), '&', $apellidoMaterno);

    //RFC que se regresar�
    $rfc = "";

    

    //Quitamos los art�culos de los apellidos
    $apellidoPaterno_editado = QuitarArticulos($apellidoPaterno);
    $apellidoMaterno_editado = QuitarArticulos($apellidoMaterno);
    $nombre_editado1 = QuitarNombreJM($nombre);
    $nombre_editado = QuitarArticulos($nombre_editado1);

    //Agregamos el primer caracter del apellido paterno
    $rfc = substr($apellidoPaterno_editado, 0, 1);

    //Buscamos y agregamos al rfc la primera vocal del primer apellido
    $len_apellidoPaterno = strlen($apellidoPaterno_editado);
    for ($x = 1; $x < $len_apellidoPaterno; $x++) {
        $c = substr($apellidoPaterno_editado, $x, 1);
        if (EsVocal($c)) {
            $rfc .= $c;
            break;
        }
    }

    //Agregamos el primer caracter del apellido materno
    $rfc .= substr($apellidoMaterno_editado, 0, 1);

    //Agregamos el primer caracter del primer nombre
    $rfc .= substr($nombre_editado, 0, 1);

    //Agregamos la fecha yymmdd (por ejemplo: 680825, 25 de agosto de 1968 )
    $rfc .= substr($fecha, 8, 4) . substr($fecha, 3, 2) . substr($fecha, 0, 2);

    //Le agregamos la homoclave al rfc
    //CalcularHomoclave($apellidoPaterno . " " . $apellidoMaterno . " " . $nombre, $fecha, $rfc);
    $rfc = QuitarAltisonantes($rfc);
    $homoclave = CalcularHomoclave($apellidoPaterno . " " . $apellidoMaterno . " " . $nombre, $rfc);
    $rfc .= $homoclave;
    return $rfc;
    // return $nombre_editado. ' ' .$apellidoPaterno_editado. ' ' .$apellidoMaterno_editado;

}

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
