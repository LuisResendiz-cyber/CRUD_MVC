<?php
// Controllers/TestApi.php
class TestApi extends Controllers {
    
    public function __construct() {
        parent::__construct();
        session_start();
        if(empty($_SESSION['login'])) {
            header('Location: '.base_url().'/login');
        }
    }
    
    public function test() {
        echo "<h1>Prueba de Conexión a API - Con Formato JSON Específico</h1>";
        echo "<h3>Configuración:</h3>";
        echo "API URL: " . API_NODE_URL . "<br>";
        echo "USE_API: " . (USE_API ? 'TRUE' : 'FALSE') . "<br><br>";
        
        // Test 1: Probar obtener usuarios
        echo "<h3>Test 1: Obtener usuarios desde API</h3>";
        $testResponse = api_get('Users/GetAllUsers');
        
        echo "Status: " . ($testResponse['success'] ? 'Éxito' : 'Error') . "<br>";
        echo "Código HTTP: " . $testResponse['code'] . "<br>";
        
        if ($testResponse['success']) {
            echo "Total usuarios: " . count($testResponse['data']) . "<br>";
            echo "<pre>" . json_encode($testResponse['data'], JSON_PRETTY_PRINT) . "</pre>";
        } else {
            echo "Error: " . ($testResponse['error'] ?? 'Desconocido') . "<br>";
            echo "Raw Response: " . htmlspecialchars($testResponse['raw']) . "<br>";
        }
        
        echo "<hr>";
        
        // Test 2: Probar creación de usuario
        echo "<h3>Test 2: Crear usuario de prueba</h3>";
        echo '<form method="POST">';
        echo '<input type="submit" name="test_create" value="Probar creación" class="btn btn-primary">';
        echo '</form>';
        
        if (isset($_POST['test_create'])) {
            // Generar datos de prueba similares a los que envía tu controlador
            $testData = [
                'customer_id' => 'TEST' . rand(1000, 9999),
                'name' => 'Test API',
                'last_name' => 'PHP',
                'phone_number' => '1234567890',
                'email_user' => 'testapi' . rand(100, 999) . '@example.com',
                'passwordHash' => hash("SHA256", 'test123'),
                'rolid' => 2
            ];
            
            echo "<h4>JSON enviado a la API:</h4>";
            echo "<pre>" . json_encode($testData, JSON_PRETTY_PRINT) . "</pre>";
            
            $createResponse = api_post('Users/CreateUser', $testData);
            
            echo "<h4>Resultado de creación:</h4>";
            echo "Success: " . ($createResponse['success'] ? 'Sí' : 'No') . "<br>";
            echo "Code: " . $createResponse['code'] . "<br>";
            
            if ($createResponse['success']) {
                echo "Usuario creado exitosamente!<br>";
                echo "<pre>" . json_encode($createResponse['data'], JSON_PRETTY_PRINT) . "</pre>";
            } else {
                echo "Error: " . json_encode($createResponse['error'] ?? $createResponse['data']) . "<br>";
            }
        }
        
        echo "<hr>";
        
        // Test 3: Probar el modelo directamente
        echo "<h3>Test 3: Probar modelo UsuariosModel</h3>";
        require_once("Models/UsuariosModel.php");
        $model = new UsuariosModel();
        
        $modelTest = $model->testAPIConnection();
        echo "Resultado: " . $modelTest['message'] . "<br>";
        echo "Código: " . $modelTest['code'] . "<br>";
        
        echo "<hr>";
        
        // Test 4: Probar método unificado
        echo "<h3>Test 4: Probar getUsuariosUnified</h3>";
        $usuarios = $model->getUsuariosUnified();
        echo "Total usuarios obtenidos: " . count($usuarios) . "<br>";
    }
    
    public function testCreacionReal() {
        echo "<h1>Prueba de Creación Real (simulando controlador)</h1>";
        
        // Simular datos que vendrían de tu formulario
        $_POST = [
            'txtIdentificacion' => 'IDTEST' . rand(1000, 9999),
            'txtNombre' => 'Usuario',
            'txtApellido' => 'Prueba',
            'txtTelefono' => '5512345678',
            'txtEmail' => 'prueba' . rand(100, 999) . '@test.com',
            'txtPassword' => '123456',
            'listRolid' => 2,
            'listStatus' => 1
        ];
        
        // Simular procesamiento del controlador
        $strIdentificacion = $_POST['txtIdentificacion'];
        $strNombre = $_POST['txtNombre'];
        $strApellido = $_POST['txtApellido'];
        $intTelefono = $_POST['txtTelefono'];
        $strEmail = $_POST['txtEmail'];
        $strPassword = hash("SHA256", $_POST['txtPassword']);
        $intTipoId = $_POST['listRolid'];
        $intStatus = $_POST['listStatus'];
        
        // Usar el modelo
        require_once("Models/UsuariosModel.php");
        $model = new UsuariosModel();
        
        echo "<h4>Datos procesados:</h4>";
        echo "Identificación: $strIdentificacion<br>";
        echo "Nombre: $strNombre<br>";
        echo "Apellido: $strApellido<br>";
        echo "Teléfono: $intTelefono<br>";
        echo "Email: $strEmail<br>";
        echo "Password (hash): " . substr($strPassword, 0, 20) . "...<br>";
        echo "Rol ID: $intTipoId<br>";
        echo "Status: $intStatus<br>";
        
        echo "<h4>Resultado de insertUsuario:</h4>";
        $resultado = $model->insertUsuario($strIdentificacion, $strNombre, $strApellido, 
                                          $intTelefono, $strEmail, $strPassword, 
                                          $intTipoId, $intStatus);
        
        if ($resultado === "exist") {
            echo "El usuario ya existe<br>";
        } elseif ($resultado > 0) {
            echo "Usuario creado exitosamente. ID: $resultado<br>";
        } else {
            echo "Error al crear usuario<br>";
        }
    }
}
?>