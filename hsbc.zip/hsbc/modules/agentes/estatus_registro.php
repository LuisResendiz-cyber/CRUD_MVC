<?
require_once('includes/includes.inc.php');
require_once('agentes.inc.php');

initialize("agente", "");

$nomina = get_session_varname("s_usr_nomina");
$empresa = get_session_varname("s_usr_centro");

/*$rsER = get_ER(get_session_varname('id_registro'), $db);
$rsER->BOF;

//die(!$rsER->EOF);

$codigo_tabla = "";

$codigo_tabla.= "<div id=\"tabla1\" style=\"display:none;\">";
$codigo_tabla.= "<table border='1' width='98%' class=\"cuestionario\">\r\n";
$codigo_tabla.= "<!--caption># de Solicitud: ".get_session_varname('id_solicitud')."</caption-->\r\n";
$codigo_tabla.= "<tr>\r\n";
$codigo_tabla.= "<th width='17%' class='agenda'>Fecha</th>";
$codigo_tabla.= "<th width='12%' class='agenda'>Hora</th>";
$codigo_tabla.= "<th width='48%' class='agenda'>Estatus</th>";
$codigo_tabla.= "<th width='19%' class='agenda'>Tel&eacute;fono</th>";
$codigo_tabla.= "<th width='4%' class='agenda'>SC</th>";
$codigo_tabla.= "</tr>\r\n";

$FILAS = 0;
$CONTACTOS = 0;

if (!$rsER->EOF) {
	while (!$rsER->EOF) {
		$codigo_tabla.= "<tr class='agenda'>\r\n";
		$codigo_tabla.= "<td class='agenda'>{$rsER->fields['FECHA']}</td>\r\n";
		$codigo_tabla.= "<td class='agenda'>{$rsER->fields['HORA']}</td>\r\n";
		$codigo_tabla.= "<td class='agenda'>{$rsER->fields['ESTATUS']}</td>\r\n";
		$codigo_tabla.= "<td class='agenda'>{$rsER->fields['TELEFONO']}</td>\r\n";		
		$codigo_tabla.= "<td class='agenda'>{$rsER->fields['SC']}</td>\r\n";				
		$codigo_tabla.= "</tr>\r\n";
		
		$CONTACTOS = $CONTACTOS + $rsER->fields['SC'];
		$FILAS++;
		
		$rsER->MoveNext();
	}
	$rsER->Close();
}

$codigo_tabla.= "</table>";
$codigo_tabla.= "</div>";

$PROBABILIDAD = ($FILAS == 0) ? 0 : floor((1000 * $CONTACTOS / $FILAS))/10;
/*echo "<br />Probabilidad de contacto: <font style=\"font-size: 24px; font-weight: bold; \">" . $PROBABILIDAD . "%</font>";
echo "<input type=\"button\" value=\"Ver detalles\" onclick=\"
		if(this.value=='Ver detalles') {
			document.getElementById('tabla1').style.display='block';
			this.value='Ocultar detalles';
		} else {
			document.getElementById('tabla1').style.display='none';
			this.value='Ver detalles';		
		}
		\" id=\"boton1\" />";

echo $codigo_tabla;	*/	


        //obtiene la OCC 
        $occ = number_format(get_occ_agente($nomina, str_replace('app', '', $dbuser), $db),2);

        if ($empresa == 5){
            if($occ<70) {$color1 = "FF0000";} //hasta 69.999 --rojo
            else if($occ<75) {$color1 = "FFFF7F";} //desde 74.999 hasta 72.999  -- amarillo
            else {$color1 = "00FF00";}	//desde 75.0 en adelante -- verde
            
            $occ = number_format($occ, 0);
            
        } else {
            if($occ<68) {$color1 = "FF0000";} //hasta 67.999
            else if($occ<73) {$color1 = "FFFF7F";} //desde 68.0 hasta 72.999
            else {$color1 = "00FF00";}	//desde 73.0 en adelante
            
            $occ = number_format($occ, 0);
        }
            
        
        echo "<table class='cuestionario'>"
        . "<tr>"
                . "<td>&nbsp;</td>"
        . "</tr>"                        
        . "<tr>"
                . "<td class='label_aviso'>OCUPACI&Oacute;N</td>"
        . "</tr>"
        . "<tr>"
                . "<td>&nbsp;</td>"
        . "</tr>"                
        . "<tr align='center' height='100%'>"
                . "<td style='border-radius:25px;' bgcolor='#{$color1}'>"
                . "<font style='font-size:300%;'>{$occ}%</font>"
                . "</td>"
        . "</tr>"
        . "<tr>"
                . "<td>&nbsp;</td>"
        . "</tr>"                
        . "</table>";
        
	//echo $occ."%";

?>
