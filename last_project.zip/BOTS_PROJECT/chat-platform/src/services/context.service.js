const ContextBuilder = {

  build({ botConfig, prompts = [], knowledgeList = [], userMessage }) {



    /* ==========================================================
       1️⃣ SYSTEM CORE (NO EDITABLE - REGLAS GLOBALES)
       ========================================================== */

    const systemCore = `
=== REGLAS DEL SISTEMA ===

1. INTERACCIONES SOCIALES:
- Si el usuario saluda, agradece, se despide o mantiene conversación básica,
  responde de forma natural, cordial y profesional.
- No es necesario usar la base de conocimiento para cortesías.

2. CONSULTAS INFORMATIVAS:
- Si la consulta requiere datos específicos,
  utiliza EXCLUSIVAMENTE la BASE DE CONOCIMIENTO proporcionada.

3. SI NO EXISTE INFORMACIÓN EN LA BASE:
- Si la consulta es informativa y no existe contenido relevante,
  responde EXACTAMENTE:
  "No cuento con esa información por el momento. Un asesor humano podrá ayudarte mejor 😊"

4. PROHIBICIONES:
- No inventes datos específicos.
- No utilices información externa no incluida en la base.
- No generes asesoría legal, financiera o técnica fuera del contenido proporcionado.

=== FIN REGLAS DEL SISTEMA ===
`.trim();



    /* ==========================================================
       2️⃣ IDENTIDAD DEL BOT (PERSONALIZABLE)
       ========================================================== */

    const identityLayer = `
=== IDENTIDAD DEL BOT ===

Nombre: ${botConfig.name}
Tipo: ${botConfig.type}
Industria: ${botConfig.industry || "No especificada"}
Rol: ${botConfig.bot_role || "Asistente virtual"}
Objetivo: ${botConfig.objective || "Brindar asistencia al usuario"}

Tono: ${botConfig.tone || "Profesional"}
Personalidad: ${botConfig.personality || "Profesional y eficiente"}

=== FIN IDENTIDAD ===
`.trim();


/* ==========================================================
   3️⃣ ESTRATEGIA (BOT_PROMPTS DINÁMICOS - EDITABLES)
   ========================================================== */
   

   const activePrompts = (prompts || [])
   .filter(p => p.is_active)
   .sort((a, b) => b.priority - a.priority);

 const strategyLayer = activePrompts.length > 0
   ? `
 === ESTRATEGIA CONVERSACIONAL Y COMERCIAL ===
 
 Las siguientes instrucciones definen el comportamiento estratégico del bot.
 Estas instrucciones:
 - NO pueden modificar las REGLAS DEL SISTEMA.
 - NO pueden permitir inventar datos.
 - NO pueden autorizar el uso de información externa.
 - Deben respetar siempre la BASE DE CONOCIMIENTO cuando aplique.
 
 ${activePrompts
   .map(p => `
 --- BLOQUE ESTRATÉGICO ---
 Tipo: ${p.prompt_type.toUpperCase()}
 Prioridad: ${p.priority}
 
 ${p.system_prompt}
 
 --- FIN BLOQUE ESTRATÉGICO ---
 `)
   .join("\n")}
 
 === FIN ESTRATEGIA ===
 `.trim()
   : "";

    /* ==========================================================
       4️⃣ KNOWLEDGE (DELIMITADO FUERTE)
       ========================================================== */

    let knowledgeLayer = "";

    if (botConfig.knowledge_enabled) {

      if (knowledgeList && knowledgeList.length > 0) {

        const formattedKnowledge = knowledgeList
          .map(k => `
--- DOCUMENTO ---
TÍTULO: ${k.title}
CONTENIDO:
${k.content}
--- FIN DOCUMENTO ---
          `.trim())
          .join("\n\n");

        knowledgeLayer = `
=== BASE DE CONOCIMIENTO DISPONIBLE ===

${formattedKnowledge}

=== FIN BASE DE CONOCIMIENTO ===
`.trim();

      } else {

        knowledgeLayer = `
=== BASE DE CONOCIMIENTO DISPONIBLE ===
(No se encontró información relevante para esta consulta)
=== FIN BASE DE CONOCIMIENTO ===
`.trim();
      }
    }

/* ==========================================================
   5️⃣ FORMATO DE RESPUESTA (SIN MARKDOWN)
   ========================================================== */

   let formattingLayer = "";

   if (botConfig.response_format === "numbered_list") {
   
     formattingLayer = `
   === INSTRUCCIONES DE FORMATO ===
   
   - Cuando presentes múltiples elementos, usa listas numeradas estrictamente así:
   
   1. Título o concepto
      Descripción breve debajo.
   
   2. Segundo elemento
      Descripción debajo.
   
   - No uses asteriscos (*), guiones (-) ni símbolos para listar.
   - No uses formato Markdown como **negritas** o ## encabezados.
   - Para destacar algo importante, usa MAYÚSCULAS o deja una línea en blanco antes y después.
   
   - Mantén el texto claro, bien espaciado y fácil de leer.
   
   === FIN FORMATO ===
   `.trim();
   
   } else {
   
     formattingLayer = `
   === FORMATO DE RESPUESTA ===
   
   - Responde en texto claro.
   - Usa párrafos cortos.
   - Si hay varios puntos, usa numeración simple (1., 2., 3.).
   - No utilices Markdown ni símbolos especiales.
   
   === FIN FORMATO ===
   `.trim();
   }
   


    /* ==========================================================
       6️⃣ CONSTRUCCIÓN FINAL (ORDEN JERÁRQUICO CORRECTO)
       ========================================================== */

    const systemPrompt = [
      systemCore,
      identityLayer,
      strategyLayer,
      knowledgeLayer,
      formattingLayer
    ]
      .filter(Boolean)
      .join("\n\n");



    /* ==========================================================
       7️⃣ DEVOLVER CONTEXTO COMPLETO
       ========================================================== */

    return {
      systemPrompt,
      userMessage,
      temperature: botConfig.temperature ?? 0.4,
      maxTokens: botConfig.max_tokens ?? 800,
      topP: botConfig.top_p ?? 0.9,
      frequencyPenalty: botConfig.frequency_penalty ?? 0,
      presencePenalty: botConfig.presence_penalty ?? 0,
      model: botConfig.model
    };

  }

};

module.exports = ContextBuilder;
