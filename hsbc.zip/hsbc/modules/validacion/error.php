<?php
# @uthor Mark  
# Error File on Validacion

require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize("validacion","Error");

$error = $_REQUEST["e"]; 

layout_menu($db, "");

if($error == 1){
	$id_solicitud = $_REQUEST['sl'];
	$msg_error = 'La solicitud #'.$id_solicitud.' no cumple con el estado para realizar la validacion';
} else if($error == 2) {
	$msg_error = 'El registro no se pudo liberar correctamente, intente de nuevo!!!';
}
?>
	<form method="post" action="modules.php?mod=agentes&op=process_data&act=1" name="frm1">
	<p class="textbold">Agentes &gt; Error</p>
	<p>&nbsp;</p>
	<table border="0">
		<tr>
			<td>Error:&nbsp;</td>
			<td class="textleft" colspan="2"><b><?=$msg_error?></b></td>
		</tr><tr>
			<td colspan="3">&nbsp;</td>
		</tr>
	</table>
	</form>
<?
layout_footer();
?>