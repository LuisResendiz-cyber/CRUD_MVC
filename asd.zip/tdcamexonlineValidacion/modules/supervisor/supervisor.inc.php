<?php

##### DEVUELVE EL REPORTE DE PRODUCTIVIDAD
function get_reporte_productividad($tipo_reporte, $fecha_del, $fecha_al, $turno, $s_usr_nomina, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN REP_PRODUCTIVIDADTABLA_SJR(:tipo_reporte, :fecha_del, :fecha_al, :turno, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $tipo_reporte, 'tipo_reporte');
    $db->InParameter($stmt, $fecha_del, 'fecha_del');
    $db->InParameter($stmt, $fecha_al, 'fecha_al');
    $db->InParameter($stmt, $turno, 'turno');
    $rs = $db->ExecuteCursor($stmt, 'rc');

//    pa($rs);
//    die();
//    exit();

//    $rs = $db->ExecuteCursor("BEGIN REP_PRODUCTIVIDADTABLA_SJR(" . $tipo_reporte . ",'" . $fecha_del . "','" . $fecha_al . "','" . $turno . "', " . $s_usr_nomina . ", :rc); END;", 'rc');
    return $rs;
}

##### DEVUELVE EL REPORTE DE CANCELADAS

function get_reporte_canceladas($tipo_reporte, $fecha_del, $fecha_al, $turno, $usr_id, $db) {
    //$rs = $db->ExecuteCursor("BEGIN REP_CANCELADAS_SJR(".$tipo_reporte.",'".$fecha_del."','".$fecha_al."','".$turno."',".$usr_id.",:rc); END;", 'rc');
    $rs = $db->ExecuteCursor("BEGIN REP_CANCELADAS(" . $tipo_reporte . ",'" . $fecha_del . "','" . $fecha_al . "','" . $turno . "', :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DEL 01800

function get_detalle_01800_usuario($s_usr_id, $anio, $mes, $dia, $db) {
    $query = "BEGIN SOL_REPORTE01800_WS(:usr_id, :year, :month, :day, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $s_usr_id, 'usr_id');
    $db->InParameter($stmt, $anio, 'year');
    $db->InParameter($stmt, $mes, 'month');
    $db->InParameter($stmt, $dia, 'day');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    
//    $rs = $db->ExecuteCursor("BEGIN SOL_REPORTE01800_WS(" . $s_usr_id . ", " . $anio . ", " . $mes . ", " . $dia . ", :rc); END;", 'rc');
//    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVULEVE EL REPORTE DE PRODUCTIVIDAD X ZONA Y ETAPA

function get_reporte_productividad_P($tipo_reporte, $fecha_del, $fecha_al, $string_zonas, $string_etapas, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_REP_PRODUCTIVIDAD_ZONA(" . $tipo_reporte . ",'" . $fecha_del . "','" . $fecha_al . "','" . $string_zonas . "','" . $string_etapas . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Muestra los datos de la solicitud capturada, para ver que agente tiene asignada la venta

function get_buscar_sol_asignar($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_BUSCAR_SOL_ASIGNAR(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#Asigna una venta a un nuevo agente.

function set_asigna_venta_nvoagente($id_solicitud, $n_agente_ant, $n_agente_nvo, $db) {
    $stmt = $db->PrepareSP("BEGIN SPU_AIGNA_SOL_NVOAGENTE(:p_id_solicitud,:p_n_agente_ant,:p_n_agente_nvo,:v_asignacion_b); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $n_agente_ant, 'p_n_agente_ant');
    $db->InParameter($stmt, $n_agente_nvo, 'p_n_agente_nvo');
    $db->OutParameter($stmt, $v_asignacion_b, 'v_asignacion_b');
    $db->Execute($stmt);
    return $v_asignacion_b;
}

#Muestra las zonas activas para traer el REP Productividad

function get_rep_zonas($db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_REP_ZONAS(:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo($v_id_campo, $db) {
    $rs = $db->ExecuteCursor("BEGIN spS_Catalogo('" . $v_id_campo . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

function get_seguimiento_agente($nomina, $fecha1, $fecha2, $tipo, $db) {
    $query = "BEGIN SPS_SEG_AGENTE(:nomina, :fecha1, :fecha2, :tipo, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $nomina, 'nomina');
    $db->InParameter($stmt, $fecha1, 'fecha1');
    $db->InParameter($stmt, $fecha2, 'fecha2');
    $db->InParameter($stmt, $tipo, 'tipo');

    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

function get_seguimiento_solicitud($solicitud, $tipo, $db) {
    $query = "BEGIN SPS_SEG_SOLICITUD(:solicitud, :tipo, :rc); END;";

    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $tipo, 'tipo');

    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

function set_revivir_solicitud($solicitud, $db) {
    $query = "BEGIN REVIVIR(:solicitud, :rc); END;";

    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}


function get_layoutIq($fecha,$layout,$nomina,$db){
    $fechas = explode('/', $fecha);
    try {
        $query = "BEGIN Sps_datos_layoutIq(:d1, :m1, :y1,:nomina, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $fechas[0], 'd1');
        $db->InParameter($stmt, $fechas[1], 'm1');
        $db->InParameter($stmt, $fechas[2], 'y1');
        $db->InParameter($stmt, $nomina,'nomina');
        $rs = $db->ExecuteCursor($stmt, 'rc');    
        return $rs;
    } catch (Exception $e) {
        pa($e->getTraceAsString());
        die();
        exit();
    }
    
}