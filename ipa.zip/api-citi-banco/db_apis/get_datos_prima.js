const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".OBJETIVO_PRIMA(:resp, :opt, :obj, :nomina); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.opt || !context.obj || !context.nomina){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.opt     = context.opt;
            binds.obj     = context.obj;
            binds.nomina     = context.v_persona;
            binds.resp      = context.resp


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;