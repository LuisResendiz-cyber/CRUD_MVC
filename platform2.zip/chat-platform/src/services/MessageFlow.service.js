const customerModel = require("../models/webchat.models");
const ChatResolver = require("../controllers/Knowledge.controller");

async function processIncomingMessage({ session_id, message, channel = "web" }) {

  if (!session_id || !message) {
    throw new Error("Datos incompletos");
  }

  // 1️⃣ Obtener o crear sesión
  const session = await customerModel.getOrCreateSession(session_id, channel);
  const conversation_id = session.session_uuid;

  // 2️⃣ Guardar mensaje del usuario
  await customerModel.insertWebhookLog({
    event_type: "web_reply",
    status: "received",
    message_text: message,
    channel,
    role: "user",
    id_envio: conversation_id,
  });

  // 3️⃣ Si está en humano → no responde bot
  if (session.status === "human") {
    return null;
  }

  // 4️⃣ Resolver con IA
  const resolution = await ChatResolver.resolve({
    session,
    message
  });

  const replyText = resolution?.message || null;

  console.log("BOT_ANSWER: " + replyText);

  // 5️⃣ Guardar respuesta del bot
  if (replyText && session.status === "bot") {
    await customerModel.insertWebhookLog({
      event_type: "web_reply",
      status: "sent",
      message_text: replyText,
      channel,
      role: "assistant",
      id_envio: conversation_id,
    });
  }

  return replyText;
}

module.exports = { processIncomingMessage };
