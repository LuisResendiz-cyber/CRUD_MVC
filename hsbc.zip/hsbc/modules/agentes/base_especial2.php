<?php
# @uthor Mark
# Cuestionario File
libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
//
//initialize("agente", "Nuevo registro");
//print_r($_REQUEST);
$super_destino = explode("_", $_REQUEST['radio_']);
//echo get_session_varname("s_usr_nomina");
//echo $super_destino[2];
echo get_insert_bases_especiales($super_destino[2],$super_destino[1],2,$db);


?>