const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
console.log(context);
const baseQuery = "BEGIN " + context.schema + ".INSERTAR_LOG_BLOQ_PROC(:u_persona, :respuesta); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.respuesta || !context.u_persona){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.respuesta     = context.respuesta;
						binds.u_persona     = context.u_persona;
            const result = await database.simpleExecute(query, binds);

            console.log(Object.values(result));

            return result;
        }
}

module.exports.find = find;
