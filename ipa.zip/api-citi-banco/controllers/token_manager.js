class Manager {
    constructor() {
        this.tokens  = Array;
        this.get = ()=>{
            if (!this.tokens['jwt']) return null;
		    return this.tokens['jwt'];
        };
        this.set = val=>{
            this.tokens['jwt'] = val;
        }
    }
    static getInstance() {
        if (!Manager.instance) {
            Manager.instance = new Manager();
        }
        return Manager.instance;
    }
}
module.exports = Manager.getInstance();
