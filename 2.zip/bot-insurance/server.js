import express from "express";
import cors from "cors";
import botRoutes from "./src/routes/botRoutes.js";
import { config } from "./src/config/index.js";

const app = express();

app.use(cors());
// Para recibir JSON
app.use(express.json());

// -----------------------------------
// RUTAS
// -----------------------------------
app.use("/bot", botRoutes);

// Archivos estáticos (si los usas)
app.use(express.static("src/public"));

// -----------------------------------
// INIT SERVER
// -----------------------------------
const PORT = config.port || 4002;

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
