// db.js
const oracledb = require("oracledb");

const ENVIRONMENT = process.env.NODE_ENV;

const envO = {
  user: ENVIRONMENT === "development" ? "DTREJO" : "dbo",
  password: ENVIRONMENT === "development" ? "12345678" : "prueba",
  connectString:
    ENVIRONMENT === "development" ? "172.20.1.35/XE" : "192.168.1.14/xccmtaf",
};

const dbConfig = {
  user: envO.user,
  password: envO.password,
  // connectString: '192.168.1.14/XCCMTAF',
  connectString: envO.connectString,
  poolMax: 2,
  poolMin: 1,
  poolIncrement: 1,
  poolTimeout: 60,
};

let pool;

async function initPool() {
  pool = await oracledb.createPool(dbConfig);
}

async function closePool() {
  if (pool) {
    await pool.close();
  }
}

function getPool() {
  if (!pool) {
    throw new Error(
      "El pool de conexiones no está inicializado. Llama a initPool() primero."
    );
  }
  return pool;
}

module.exports = {
  initPool,
  closePool,
  getPool,
};



