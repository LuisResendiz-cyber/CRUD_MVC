<?php
# New_referido File 
# @uthor Mark

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

initialize("clientes","Referidos");

$tipo_llamada = (isset($_POST['tipollamada'])?$_POST['tipollamada']:"");
$nombre = (isset($_POST['nombre'])?$_POST['nombre']:"");
$paterno = (isset($_POST['paterno'])?$_POST['paterno']:"");
$materno = (isset($_POST['materno'])?$_POST['materno']:"");
$estado = trim((isset($_POST['estado'])?$_POST['estado']:""));	
$telefono= (isset($_POST['telefono'])?$_POST['telefono']:"");
$num_cliente = (isset($_POST['num_cliente'])?$_POST['num_cliente']:"");	

layout_menu($db);

echo "<script>
	bines_array = new Array();";
	$bines = get_bines();
	$b = 0;
	while($bin = get_row($bines)){
		echo "bines_array[".$b."] = ".$bin[0].";";
		$b++;
	}	
echo "</script>";

if(isset($_GET["action"]) == 1){
	$statement = get_cliente_folio(base64_decode($_REQUEST['u_p']));
	$cliente = get_row($statement);
	echo '<table border="0">
			<form method="post" action="'.$linkpath.'clientes/process_data.php?action=1" name="frm1">
				<input type="hidden" name="u_persona" id="u_persona" value="'.base64_decode($_REQUEST['u_p']).'">
				<input type="hidden" name="u_registro" id="u_registro" value="'.base64_decode($_REQUEST['rxc']).'">
			</form>
			<tr>
				<td colspan=\"5\">Confirmacion de Alta</td>
			</tr><tr>
				<td>&nbsp;</td>
			</tr><tr>
				<td><b>Se creo un cliente con numero de solicitud: <font color="red">'.base64_decode($_REQUEST['u_p']).'</font></b></td>
			</tr><tr>				
				<td colspan="2"><b>Registro interno:</b></td><td>'.base64_decode($_REQUEST['rxc']).'</td>
			</tr><tr>
				<td colspan="2"><b>Nombre (s):</b></td><td>'.$cliente[0].'</td>
			</tr><tr>
				<td colspan="2"><b>Apellidos:</b></td><td>'.$cliente[1].'</td>
			</tr><tr>
				<td>
					<br>
					<input type="button" value="Ir a la solicitud" onclick="MuestraSolicitud()">&nbsp;&nbsp;
				</td>
			</tr>
		</table>';
		//<input type="button" value="Regresar a la busqueda" onclick="back_busqueda('.$linkpath.')">
}else{
	echo '
		<p class="textbold">Nuevo Referido</p>
		<p>&nbsp;</p>
		<form method="post" action="'.$linkpath.'clientes/process_data.php?action=4" name="frm1">
			<table class="text" border="0">
				<tr>
					<td colspan="2">
				</tr><tr>
					<td colspan="2">*<b> Campos Obligatorios</b></td>
				</tr><tr>
					<td colspan="2">
						<table>
							<tr>
								<td>* Nombre:&nbsp;</td><td><input type="text" name="nombre" id="nombre"></td>
							</tr><tr>
								<td>* Paterno:&nbsp;</td><td><input type="text" name="paterno" id="paterno"></td>
							</tr><tr>
								<td>Materno:&nbsp;</td><td><input type="text" name="materno" id="materno"></td>
							</tr><tr>
								<td>* Fecha de Nacimiento: (dd/mm/yyyy)&nbsp;</td>
								<td>
									<script language="JavaScript">
										var SC_SET_1 = {\'appearance\': SC_APPEARANCE,\'dataArea\':\'fecha_nac\',\'dateFormat\' : \'d/m/Y\'}
										new sCalendar(SC_SET_1);
									</script>
								</td>
							</tr><tr>
								<td>* 16 D�gitos de la Tarjeta de Cr�dito:&nbsp;</td>
								<td>
								<input type="text" name="tarjeta" id="tarjeta" maxlength="16">
								<br><div id="loading1" style="display:none">Validando 16 Digitos, espere un momento.&nbsp;<img src="'.$linkpath.'includes/imgs/loading.gif"></div>
								</td>
							</tr>
						</table>
					</td>
				</tr><tr>
					<td colspan="2">
						<input type="button" value="Procesar" onclick="ValidaReferido()"/>&nbsp;&nbsp;
						<input type="button" value="Limpiar Datos" onclick="LimpiaDatos('.$linkpath.')"/></td>
				</tr>
			</table>
		</form>
	  <p>&nbsp;</p>';
}
layout_footer();
/*</tr><tr>
	<td>* RFC:&nbsp;</td>
<td>
<input type=\"text\" name=\"rfc\" id=\"rfc\" maxlength=\"10\"><a href=\"#\" onclick=\"calcula_rfc()\"><img src=\"".$linkpath."includes/imgs/calcula.jpg\" border=\"0\" width=\"20\" alt=\"Calcular RFC\"></a>
<br><div id=\"loading\" style=\"display:none\">Realizando peticion, espere un momento.&nbsp;<img src=\"".$linkpath."includes/imgs/loading.gif\"></div>
</td>
</tr><tr>
<td>* Telefono casa (Lada+Numero):&nbsp;</td><td><input type=\"text\" name=\"telefonocasa\" id=\"telefonocasa\" maxlength=\"10\"></td>
</tr><tr>
<td>Telefono oficina (Lada+Numero):&nbsp;</td><td><input type=\"text\" name=\"telefonooficina\" id=\"telefonooficina\" maxlength=\"10\"></td>
</tr><tr>
<td>Telefono celular (Lada+Numero):&nbsp;</td>
<td><input type=\"text\" name=\"telefonooficina\" id=\"telefonocelular\" maxlength=\"10\"></td>
</tr><tr>
<td>* Cuantas cuentas relacionadas tiene:&nbsp;</td>
<td>
<select name=\"cuentas_rel\">
<option value=\"0\" selected>0</option>
<option value=\"1\">1</option>
<option value=\"2\">2</option>
<option value=\"3\">3</option>
<option value=\"4\">4</option>
<option value=\"5\">5</option>
<option value=\"6\">6</option>
<option value=\"7\">7</option>
<option value=\"8\">8</option>
<option value=\"9\">9</option>
<option value=\"10\">10</option>
</select>
</td>
</tr><tr>
<td>* Motivo de solicitud del plan:&nbsp;</td>
<td>
<select name=\"motivo\">";
$motivosol = get_motivosolicitud();
while($motivo = get_row($motivosol))
echo "<option value=\"".$motivo[0]."\">".$motivo[1]."</option>";
echo "</select>
</td>
</tr><tr>
<td>* La tarjeta es Light:&nbsp;</td>
<td>
<select name=\"light\" id=\"light\">
<option value=\"0\">No</option>
<option value=\"1\">Si</option>
</select>
</td>
</tr><tr>
<td>* Saldo:&nbsp;</td><td><input type=\"text\" name=\"saldo\" id=\"saldo\" maxlength=\"7\"></td>
</tr><tr>
*/

?>