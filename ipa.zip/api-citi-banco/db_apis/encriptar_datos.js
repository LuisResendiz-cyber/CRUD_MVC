const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  // console.log('********************************************');
  // console.log('**funcion para llamar a ENCRIPTAR_DATOS**');
  // const baseQuery = "BEGIN CITI.ENCRIPTAR_DATOS(:ult_batch, :keys, :response); END;";
  const baseQuery = "BEGIN CITI.ENCRIPTAR_DATOS(:ult_batch, :response); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  // if(context.ult_batch== '' || context.schema=='' || context.keys== ''){
  if(context.ult_batch== '' || context.schema==''){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.ult_batch = context.ult_batch;
    // binds.keys = context.keyrig;
    binds.response = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_NUMBER};
    const result = await database.simpleExecute(query, binds);
    // console.log();
    return result;
  }
}

module.exports.find = find;

