<?php
require_once "conexion.php";

class ModeloCampanas{

	static public function mdlMostrarCampanas($tabla, $item, $valor){
    if($item != null){
		$stmt = Conexion::conectar()->prepare("SELECT NOMBRE_CAMPANA, estatus, id_campana FROM $tabla WHERE id_campana = :$item");
		$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);
		$stmt -> execute();
		return $stmt -> fetch();
	}else{
		$stmt = Conexion::conectar()->prepare("SELECT NOMBRE_CAMPANA, estatus, id_campana FROM $tabla");
		$stmt -> execute();
		return $stmt -> fetchAll();
	}
		$stmt -> close();
        $stmt = null;
    }

	static public function mdlCrearCampana($tabla, $datos){             
                    try {
	          $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(nombre_campana, estatus) VALUES (:nombre_campana, 1)");                    
		$stmt->bindParam(":nombre_campana", $datos["Nombre_Campana"], PDO::PARAM_STR);
		if($stmt->execute()){
			return "ok";	
		}else{
			return "error";
		}
		$stmt->close();
		$stmt = null;
          } catch (Exception $th) {
                    echo $th->getMessage();
          }
	}

	static public function mdlEditarCampana($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET NOMBRE_CAMPANA = :EditarName WHERE id_campana = :Enlace_id");
		$stmt -> bindParam(":EditarName", $datos["EditarName"], PDO::PARAM_STR);
		$stmt -> bindParam(":Enlace_id", $datos["id_campana"], PDO::PARAM_STR);

		if($stmt -> execute()){
			return "ok";
		}else{
			return "error";	
		}
		$stmt -> close();
		$stmt = null;
	}

	static public function mdlBorrarEnlace($tabla, $datos){
		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);
		if($stmt -> execute()){
			return "ok";
		}else{
			return "error";
		}
		$stmt -> close();
		$stmt = null;
	}
}