import axios from "axios";
import { config } from "../config/index.js";

export async function generarRespuesta(messages) {
  const response = await axios(`${config.ollamaUrl}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: config.modelName,
      messages,
      stream: false
    }),
  });

  if (!response.ok) {
    throw new Error("Error al comunicarse con el modelo local");
  }

  const data = await response.json();
  // Retornamos el contenido generado
  return data?.choices?.[0]?.message?.content || "No se obtuvo respuesta del modelo.";
}
