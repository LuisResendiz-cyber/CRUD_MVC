#!/bin/sh

export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=/u01/app/oracle/product/10.2.0/db_1
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export ORACLE_SID=ccm
export ORACLE_TERM=xterm
export ORAHOME=/u01/app/oracle/product/10.2.0/db_1
export ORASID=ccm
export PATH=/u01/app/oracle/product/10.2.0/db_1/bin:/usr/sbin:/usr/kerberos/bin:/usr/local/bin:/bin:/usr/bin:/home/oracle/bin

sqlldr USERID=megacable/m3g4c4bl3@ccm, CONTROL=/var/www/htdocs/seguimiento/modules/Files_remesas/load_data_megacable_lx.ctl, LOG=/var/www/htdocs/seguimiento/modules/Files_remesas/load_data_megacable.log, bad=/var/www/htdocs/seguimiento/modules/Files_remesas/load_data_megacable.bad

#data=T03DJ000004.DAT
