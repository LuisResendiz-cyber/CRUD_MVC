<?php
header("Content-type:text/xml");
require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

load_session();

print("<?xml version=\"1.0\"?>");
?>
<tree id="0">
<?php
	
	get_supervisores($db);
	
	//Nivel de supervisores
	function get_supervisores($db){
		$rs_super = $db->Execute("SELECT USR_ID, USR_NOMBRE FROM TBL_USUARIOS WHERE USR_NIVEL = 'S' AND USR_ACTIVO = 1 ORDER BY USR_ID,USR_NOMBRE");

		while(!$rs_super->EOF){
			print("<item style='font-family:arial;font-size:8.5pt'  id='".$rs_super->fields['USR_ID']."' text=\"". str_replace('"',"&quot;",$rs_super->fields['USR_NOMBRE'])."\">");
			get_agentes($rs_super->fields['USR_ID'],$db);
			print("</item>");
			$rs_super->MoveNext();
		}
	}
	
	//Nivel de agentes
	function get_agentes($super,$db){
		$rs_agentes = $db->Execute("SELECT USR_ID, USR_NOMBRE FROM TBL_USUARIOS WHERE USR_NIVEL in ('A','AI') AND USR_ACTIVO = 1 AND USR_ID_SUPERVISOR =".$super." ORDER BY USR_ID,USR_NOMBRE");

		while(!$rs_agentes->EOF){
			print("<item style='font-family:arial;font-size:8.5pt' id='".$rs_agentes->fields['USR_ID']."' text=\"". str_replace('"',"&quot;",$rs_agentes->fields['USR_ID'].'-'.$rs_agentes->fields['USR_NOMBRE'])."\"></item>");
			$rs_agentes->MoveNext();
		}
	}
?>
</tree>
