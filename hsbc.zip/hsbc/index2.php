<?php
# Index File 
# @uthor Mark

require_once("includes/includes.inc.php");
$valor_return = 0;
$message = "";

load_session();

if (isset($_GET["log_out"])) {
    $message = "Ha finalizado tu sesion.";
}

if (isset($_GET["msg"])) {
    $valor_return = desencripta($_GET["msg"]);
    switch ($valor_return) {
        case 1:
            $message = "La clave de usuario y/o contrase&ntilde;a no es valida...";
            break;
        case 2:
            $message = "La clave de usuario y/o contrase&ntilde;a no es valida...";
            break;
        case 4:
            $message = "Error de base de datos...";
            break;
        case 3:
            $message = "Sesi&oacute;n ocupada...";
            break;
        case 5:
            $message = "Tu contrase&ntilde;a est&aacute; por caducar.\n\nPor favor solicita que la reseteen para no perder tu acceso...\n";
            break;
        case 6:
            $message = "Tu contrase&ntilde;a caduca hoy mismo.\n\nPor favor solicita que la reseteen o no tendr&aacute;s acceso ma&ntilde;ana...\n";
            break;
        case 7:
            $message = "Tu contrase&ntilde;a ha caducado.\n\nPor favor solicita que la reseteen para volver a tener acceso...\n";
            break;
        case 8:
            $message = "Tu extensión se encuentra ocupada.\n\nPide que liberen tu extensi&oacute;n para volver a tener acceso...\n";
            break;
        case 9:
            $message = "Bloqueado por falta injustificada\n";
            break;
        case 10:
            $message = "Has rebasado el n&utilde;mero de intentos\n\nTu usuario ha sido bloquedo...";
            break;
        case 11:
            $message = "El usuario ha sido bloqueado, para el desbloquear lo podra hacer solo y unicamente (Supervisro,Jefe operacion,guns)";
            break;
    }
}

layout_header("Inicio");
layout_menu($db);

if (is_logged()) {
    if ($valor_return == 5 || $valor_return == 6) {
        echo $message;
    }
    echo 'Seleccione una opcion del menu que se encuentra a la izquierda<br>
        <form name="GenericForm" action="#" method="POST"></form>';
} else {
    layout_loggin($message);
}

layout_footer();
