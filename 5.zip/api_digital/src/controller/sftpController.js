import fs from "fs";
import * as step from "../model/sftpModel.js";
import {notifySMS } from "./gralController.js";
import { saveLog } from "./mysqlController.js";


export const start = async () => {
  try {    
    let executionTime = new Date().toLocaleString();     
    console.log('\x1b[33m%s\x1b[0m', `-- Process has started -- ${executionTime}`);
    await saveLog('Proceso iniciado',1);

    await runInsertCsv();

    console.log('\x1b[33m%s\x1b[0m', `-- Process has ended -- ${executionTime}`);
    await saveLog(`Proceso finalizado`,1);

  } catch (error) {
    await notifySMS(`Error en el proceso de banderas fun start: ${error}`);
    console.error(error);

  }
};

export const runInsertCsv = async () => {
  try {
    const isCsv = await step.checkCsvExist();
    
    if (step.isArrayEmpty(isCsv)) {
      console.log("Sin archivos CSV en local");
      await saveLog("Sin archivos CSV en local",1);
      return false;
    }
    
    console.log("Archivos CSV encontrados: ", isCsv.length);

    const insertPromises = isCsv.map(async (item) => {
      const readCSV = await step.readCSV(item);
      const insertCSV = await step.insertCSV(readCSV);
      // console.log(readCSV);
      await saveLog(`Filas insertadas para ${item}: ${insertCSV} ` ,1);
      await step.moveCsv(item);
    });

    await Promise.all(insertPromises);

    const hygiene = await step.hygiene();    
    console.log('Proceso de higiene completado:', hygiene);
    await saveLog(`Proceso de higiene completado`,1);
    

    return new Promise((resolve) => setTimeout(resolve, 5000));

  } catch (error) {
    console.error("Error durante el proceso:", error);
    await saveLog(`Error durante el proceso: ${error}`,1);
    await notifySMS(`Error en el proceso de banderas fun runInsertCsv: ${error}`);
    return false; // O manejar el error de otra manera
  }
};

