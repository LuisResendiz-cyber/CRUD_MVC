const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

 const baseQuery = "BEGIN " + context.schema + ".get_prima_acc_mensual(:p_u_persona,:p_plan, :rc); END;";
  console.log(context);
   let query = baseQuery;
   const binds = {}; //Define un objeto para la variable SP
   let result2 = {};

   if(!context.u_persona || !context.plan){
     //console.log("Parametros incorrectos")
     result2.error_ = true;
     result2.mensaje = "Parametros Erroneos";
     return result2;

   }else{

    binds.p_u_persona = context.u_persona;
    binds.p_plan = context.plan;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    console.log(binds);
    const result = await database.simpleExecuteRC(query, binds);
     console.log(result);
    return result;
  }
}

module.exports.find = find;
