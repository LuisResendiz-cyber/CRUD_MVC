<?php
# surveyClass
# @uthor Mark 
require_once ('includes.inc.php');

class surveyClass {
	
    var $db;
    var $solicitud;
    var $producto;
    var $xml;
    
   public function surveyClass($id_solicitud, $id_producto, $db) {
        $this->SetDB($db);
        $this->SetSolicitud($id_solicitud);
        $this->SetProducto($id_producto);
        $this->SetXML();
    }


    # All setter methods

    private function SetDB($db){
        $this->db = $db;
    }

    private function SetSolicitud($id_solicitud){
        $this->solicitud = $id_solicitud;
    }

    private function SetProducto($id_producto){
        $this->producto = $id_producto;
    }

    public function SetLogin($message) {
        if($this->objSession->GetIsLogged()) {
                $this->login = 'Seleccione una opcion del menu que se encuentra a la izquierda';
        } else {
                $this->login = '<form id="login" name="frm1" action="'.$this->linkpath.'index.php?login=1" method="POST">
                <h4>Iniciar Sesion</h4>
                <p id="text">Para ingresar al sistema debes, capturar tu Id Usuario y contrase�a<br></p>
                <table border="0" id="t1">
                        <tr>
                                <td colspan="2"><font color="red">'.$message.'</font></td>
                        </tr><tr>
                                <td>Id Usuario:</td><td><input type="text" maxlenght="10" size="10" name="user" id="user"></td>
                        </tr><tr>
                                <td>Contrase�a:</td><td><input type="password" maxlenght="10" size="10"  name="password" id="password"></td>
                        </tr><tr>
                                <td colspan=\"2\"><input type="button" value="Ingresar" onclick="ValidaLogin()"></td>
                        </tr>
                </table>
                </form>';
        }
    }

    public function SetXML() {

        $xml_ = '<?xml version="1.0" encoding="ISO-8859-1"?>';
        $xml_ .= '<CUESTIONARIO>';

        $cuestionario = get_cuestionario($this->GetProducto(), 1, 0, 0, 0, $this->GetBD());
        $cuestionario_array = explode('-', $cuestionario);
        $nombre_c = $cuestionario_array[0];
        $descrip_c = $cuestionario_array[1];

        $xml_ .= '<NOMBRE_CUESTIONARIO>'.$nombre_c.'</NOMBRE_CUESTIONARIO>';

        $preguntas_ = get_preguntas($this->GetProducto(), $this->GetSolicitud(), 1, 0, $this->GetBD());
        if(count($preguntas_->_array) > 0){
            for($indice_ = 0; $indice_ < count($preguntas_->_array); $indice_++){
                $questionid_xml = $preguntas_->_array[$indice_]['QUESTIONID'];
                $xml_ .= '<SECCION>';
                $xml_ .= '<QUESTIONID>'.$preguntas_->_array[$indice_]['QUESTIONID'].'</QUESTIONID>';
                $xml_ .= '<QUESTIONTEXT>'.special_chars($preguntas_->_array[$indice_]['QUESTIONTEXT']).'</QUESTIONTEXT>';
                $xml_ .= '<DISPLAYORDER>'.$preguntas_->_array[$indice_]['DISPLAYORDER'].'</DISPLAYORDER>';
                $xml_ .= '<FORCEANSWER>'.$preguntas_->_array[$indice_]['FORCEANSWER'].'</FORCEANSWER>';
                $xml_ .= '<DESPLIEGAVALIDACION>'.$preguntas_->_array[$indice_]['DESPLIEGAVALIDACION'].'</DESPLIEGAVALIDACION>';
                $respuestas_ = get_respuestas($this->GetProducto(), $preguntas_->_array[$indice_]['QUESTIONID'], 1, $this->GetSolicitud(), 1, 0, $this->GetBD());
                
                if(count($respuestas_->_array) > 0){

                    for($indice_resp_ = 0; $indice_resp_ < count($respuestas_->_array); $indice_resp_++){
                        $xml_ .= '<PREGUNTA>';
                        $xml_ .= '<SURVEYID>'.$this->GetProducto().'</SURVEYID>';
                        $xml_ .= '<QUESTIONID>'.$questionid_xml.'</QUESTIONID>';
                        $xml_ .= '<CHOICEID>'.$respuestas_->_array[$indice_resp_]['CHOICEID'].'</CHOICEID>';
                        $xml_ .= '<CHOICETEXT>'.special_chars($respuestas_->_array[$indice_resp_]['CHOICETEXT']).'</CHOICETEXT>';
                        $xml_ .= '<CHOICETYPE>'.$respuestas_->_array[$indice_resp_]['CHOICETYPE'].'</CHOICETYPE>';
                        $xml_ .= '<CHOICELEN>'.$respuestas_->_array[$indice_resp_]['CHOICELEN'].'</CHOICELEN>';
                        $xml_ .= '<CHOICEFORCE>'.$respuestas_->_array[$indice_resp_]['CHOICEFORCE'].'</CHOICEFORCE>';

                        /*
                        if(strlen($respuestas_->_array[$indice_resp_]['DATAFIELD']) > 2){
                            $valor_ = get_respuestas_default($this->GetSolicitud(), $respuestas_->_array[$indice_resp_]['DATAFIELD'], $this->GetBD());
                            $xml_ .= '<DATAFIELD>'.special_chars($valor_->_array[0][0]).'</DATAFIELD>';
                        }else{
                            $xml_ .= '<DATAFIELD>'.$respuestas_->_array[$indice_resp_]['DATAFIELD'].'</DATAFIELD>';
                        }
                        */
                        $xml_ .= '<DATAFIELD>'.$respuestas_->_array[$indice_resp_]['DATAFIELD'].'</DATAFIELD>';
                        //$xml_ .= '<DATAFIELD></DATAFIELD>';
                        $xml_ .= '<TEXTANSWER>'.$respuestas_->_array[$indice_resp_]['TEXTANSWER'].'</TEXTANSWER>';
                        $xml_ .= '<NUMANSWER>'.$respuestas_->_array[$indice_resp_]['NUMANSWER'].'</NUMANSWER>';
                        $xml_ .= '<QUERY>'.$respuestas_->_array[$indice_resp_]['QUERY'].'</QUERY>';

                        if(strlen($respuestas_->_array[$indice_resp_]['QUERY']) > 2){
                            
                            if (preg_match("/[\([0-9]]/", $respuestas_->_array[$indice_resp_]['QUERY'])){

                                if (preg_match("/MUNICIPIO/i", $respuestas_->_array[$indice_resp_]['QUERY'])) {
                                    $xml_ .= '<CP_ID>MUNICIPIO'.substr($respuestas_->_array[$indice_resp_]['QUERY'], (strlen($respuestas_->_array[$indice_resp_]['QUERY']) -3 ), 1).'</CP_ID>';                                    
                                    //echo "Se encontró una coincidencia. --> MUNICIPIO";
                                } else if (preg_match("/ESTADO/i", $respuestas_->_array[$indice_resp_]['QUERY'])) {
                                    $xml_ .= '<CP_ID>ESTADO'.substr($respuestas_->_array[$indice_resp_]['QUERY'], (strlen($respuestas_->_array[$indice_resp_]['QUERY']) -3 ), 1).'</CP_ID>';
                                    //echo "Se encontró una coincidencia. --> ESTADO";
                                } else if (preg_match("/COLONIA/i", $respuestas_->_array[$indice_resp_]['QUERY'])) {
                                    $xml_ .= '<CP_ID>COLONIA'.substr($respuestas_->_array[$indice_resp_]['QUERY'], (strlen($respuestas_->_array[$indice_resp_]['QUERY']) -3 ), 1).'</CP_ID>';                                    
                                    //echo "Se encontró una coincidencia. --> COLONIA";
                                }
                            } 
                           

                            $datos_ = get_datos_query($respuestas_->_array[$indice_resp_]['QUERY'], $this->GetBD());
                            
                            if(count($datos_->_array) > 0){
                                $xml_ .= '<OPCIONES>';
                                for($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++){
                                    $xml_ .= '<OPCION>';
                                    $xml_ .= '<VALOR>'.$datos_->_array[$indice_datos_query_]['VALOR'].'</VALOR>';
                                    $xml_ .= '<TEXTO>'.special_chars($datos_->_array[$indice_datos_query_]['TEXTO']).'</TEXTO>';
                                    $xml_ .= '</OPCION>';
                                }
                                $xml_ .= '</OPCIONES>';
                            }

                        }

                        $xml_ .= '<PARAMETER>'.$respuestas_->_array[$indice_resp_]['PARAMETER'].'</PARAMETER>';
                        $xml_ .= '<RECONOCEDOR>'.$respuestas_->_array[$indice_resp_]['RECONOCEDOR'].'</RECONOCEDOR>';
                        $xml_ .= '<EDITABLE>'.$respuestas_->_array[$indice_resp_]['EDITABLE'].'</EDITABLE>';
                        $xml_ .= '</PREGUNTA>';
                    }
                }

                $xml_ .= '</SECCION>';
            }

        }
        $xml_ .= '</CUESTIONARIO>';
        $this->xml = $xml_;
    }
	
    # All getter methods
	
    private function GetBD(){
        return $this->db;
    }

    private function GetSolicitud(){
        return $this->solicitud;
    }

    private function GetProducto(){
        return $this->producto;
    }
    public function GetXML(){
        return $this->xml;
    }
	
}
?>