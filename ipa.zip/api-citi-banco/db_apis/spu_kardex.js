const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {

const baseQuery = "BEGIN ASISTENCIA.TL_SPU_KARDEXOPER_HO(:nomina, :mes, :preg, :resp, :usr); END;";
	let query = baseQuery;
	const binds = {};

	let result2 = {};

        if(!context.nomina || !context.mes){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.nomina = context.nomina;
            binds.mes = context.mes;
            binds.preg = context.preg;
            binds.resp = context.resp;
            binds.usr = context.usr;

            const result = await database.simpleExecute(query, binds);

            // console.log(result); 

            return result;
        }            
}
  
module.exports.find = find;
