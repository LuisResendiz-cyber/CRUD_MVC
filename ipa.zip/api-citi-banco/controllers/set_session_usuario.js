const set_session_usuario = require('../db_apis/set_session_usuario.js');

async function post(req, res, next) {
  try {
    const context = req.body;//{};
    console.log(context);
    // context.camp      = 1;
    // context.prioridad   = 1;
    // context.estatus     = 0;
    // context.intentos    = 10;
    // context.user_     = 8981;
    // context.rand_     = 0;
    // context.tipoCampana   = '0';

    const rows = await set_session_usuario.find(context);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
