const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
   
const baseQuery = "BEGIN " + context.schema + ".proc_Survey_GetSurvey(:SurveyId_, :Lang, :Exist, :Name_, :Desc_); END;";
//        console.log(typeof(context.SurveyId_));	
//        console.log(typeof(context.Lang));	
//        console.log(typeof(context.Exist));	
//        console.log(typeof(context.Name_));	
//        console.log(typeof(context.Desc_));	
        //console.log(context);	
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.SurveyId_ || !context.Lang || !context.Exist || !context.Name_ || !context.Desc_){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{
            binds.SurveyId_      = {val:parseInt(context.SurveyId_), dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_NUMBER};
            binds.Lang      = {val:parseInt(context.Lang), dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_NUMBER};
            binds.Exist       = {val:parseInt(context.Exist), dir: oracledb.BIND_INOUT, type: oracledb.DB_TYPE_NUMBER};
            binds.Name_       = {val:context.Name_, dir: oracledb.BIND_INOUT, type: oracledb.DB_TYPE_VARCHAR};                        
            binds.Desc_       = {val:context.Desc_, dir: oracledb.BIND_INOUT, type: oracledb.DB_TYPE_VARCHAR};                                    


            const result = await database.simpleExecute(query, binds);

//             console.log(result);	

            return result;
        }
}
module.exports.find = find;