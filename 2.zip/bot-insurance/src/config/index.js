import dotenv from "dotenv";
dotenv.config();

export const config = {
  port: process.env.PORT || 4002,
  ollamaUrl: process.env.OLLAMA_URL || "http://localhost:11434",
  modelName: process.env.MODEL_NAME || "qwen2.5:7b",
};
