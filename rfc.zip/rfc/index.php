<?php

ini_set('display_errors', true);

require_once('calcular_rfc.php');
if (empty($_GET['nombre'])) {
    echo "Error: No se proporcion� nombre (par�metro <strong>nombre</strong>.";
} elseif (empty($_GET['paterno'])) {
    echo "Error: No se proporcion� apellido paterno (par�metro <strong>paterno</strong>.";
} elseif (empty($_GET['fecha'])) {
    echo "Error: No se proporcion� fecha de nacimiento (par�metro <strong>fecha</strong>.";
} else {
    $nombre = $_GET['nombre'];
    $paterno = $_GET['paterno'];
    $materno = (empty($_GET['materno']) ? '' : $_GET['materno']);
    $fecha = $_GET['fecha'];
    echo CalcularRFC($nombre, $paterno, $materno, $fecha);
}