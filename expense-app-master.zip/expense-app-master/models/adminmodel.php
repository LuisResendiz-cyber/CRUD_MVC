
<?php

class AdminModel extends Model{

    public function __construct(){
        parent::__construct();
    }
}

?>