<?php
class ControladorLigas
{
          static public function ctrCrearLiga()
		  {
		if(isset($_POST["nuevoLiga"]))
		{

                              if ($_POST["titulo"] && $_POST["nuevoLiga"] && $_POST["campana"]) {
                                        $tabla = "enlaces";

                                        $datos = array(
                                                  "Titulo_Enlace" => $_POST["titulo"],
                                                  "nombreLiga" => $_POST["nuevoLiga"],
                                                  "Id_campana" => $_POST["campana"]
                                        );

                                        $respuesta = ModeloEnlaces::mdlCrearEnlace($tabla, $datos);

                                        if ($respuesta == "ok") {
                                                  echo '<script>
					swal({
						type: "success",
						title: "¡El Enlace ha sido guardado correctamente!",
						showConfirmButton: true,
						confirmButtonText: "Cerrar"
					}).then(function(result){
						if(result.value){		
							window.location = "?ruta=enlaces";
						}
					});</script>';
                                        }
                              } else {
                                        echo '<script>
					swal({
						type: "error",
						title: "¡El Enlace no puede ir vacío o llevar caracteres especiales!",
						showConfirmButton: true,
						confirmButtonText: "Cerrar"
					}).then(function(result){
					if(result.value){
					window.location = "?ruta=enlaces";
					}
					});
				</script>';
                              }
		}
                    
          }

          //MOSTRAR USUARIO
          static public function ctrMostrarEnlaces($item, $valor){
		$tabla = "enlaces";
                    $respuesta = ModeloEnlaces::mdlMostrarEnlaces($tabla, $item, $valor);

                    return $respuesta;
          }

          //	EDITAR USUARIO
          static public function ctrEditarEnlace()
          {
			if(isset($_POST["Editartitulo"]))
			{

                                        $tabla = "enlaces";
                                        $datos = array(
                                                  "Editartitulo" => $_POST["Editartitulo"],
                                                  "EditarLiga" => $_POST["EditarLiga"],
                                                  "Editarcampana" => $_POST["Editarcampana"],
                                                  "Enlace_id" => $_POST["Enlace_id"]

                                        );
										
                                        $respuesta = ModeloEnlaces::mdlEditarEnlace($tabla, $datos);
                                        if ($respuesta == "ok") {
                                                  echo '<script>
					swal({
						  type: "success",
						  title: "El Enlace ha sido editado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result) {
									if (result.value) {
									window.location = "?ruta=enlaces";
									}
								})
					</script>';
                                        }
                              
									}
          }

          static public function ctrBorrarEnlace(){
                    if (isset($_GET["idEnlace"])) {
                              $tabla = "enlaces";
                              $datos = $_GET["idEnlace"];
                              $respuesta = ModeloEnlaces::mdlBorrarEnlace($tabla, $datos);
                              if ($respuesta == "ok") {
                                        echo '<script>
				swal({
					  type: "success",
					  title: "El usuario ha sido borrado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {
								window.location = "?ruta=enlaces";
								}
							})
				</script>';
                              }
                    }
          }
}
