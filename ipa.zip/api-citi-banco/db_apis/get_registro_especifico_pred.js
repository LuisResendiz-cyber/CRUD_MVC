const oracledb = require('oracledb');
const database = require('../services/database.js');


// async function find(context){
//   console.log(context);
//   const baseQuery = "BEGIN " + context.schema + ".XSP_GETREGISTROESP_PRED_TIME(:u_registro, :telefono, :usr_id, :tipo_campana, :duracion, :grabacion, :keys, :rc ); END;";
// 	let query = baseQuery;
// 	const binds = {};
//   let result2 = {};
//
//   if(!context.u_registro || !context.telefono || !context.usr_id || !context.tipo_campana || !context.duracion || !context.grabacion || context.keys !== '1'){
//     //console.log("Parametros incorrectos")
//     result2.error_ = true;
//     result2.mensaje = "Parametros Erroneos";
//     return result2;
//
//   }else{
//     binds.u_registro      = context.u_registro;
//     binds.telefono   = context.telefono;
//     binds.usr_id     = context.usr_id;
//     binds.tipo_campana   = context.tipo_campana;
//     binds.duracion     = context.duracion;
//     binds.grabacion    = context.grabacion;
//     binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
//     binds.keys      = context.keys;
//     console.log(binds);
//     const result = await database.simpleExecuteRC(query, binds);
//     console.log(result);
//     return result;
//   }
// }

async function give(context){
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".XSP_GETREGISTROESP_PRED_TIME(:u_registro, :telefono, :usr_id, :tipo_campana, :duracion, :grabacion, :rc ); END;";
  let query = baseQuery;

  const binds = {};
  let result2 = {};

  if(!context.u_registro || !context.telefono || !context.usr_id || !context.tipo_campana || !context.duracion || !context.grabacion){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.u_registro      = context.u_registro;
    binds.telefono   = context.telefono;
    binds.usr_id     = context.usr_id;
    binds.tipo_campana   = context.tipo_campana;
    binds.duracion     = context.duracion;
    binds.grabacion    = context.grabacion;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    console.log(binds);
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;

  }
}

module.exports.give = give;
