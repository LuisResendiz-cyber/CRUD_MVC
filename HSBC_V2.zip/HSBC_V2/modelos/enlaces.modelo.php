<?php
require_once "conexion.php";

class ModeloEnlaces{

	static public function mdlMostrarEnlaces($tabla, $item, $valor){
		if($item != null){
			$stmt = Conexion::conectar()->prepare("SELECT url, titulo, id_campana FROM $tabla WHERE $item = :$item");
			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);
			$stmt -> execute();
			return $stmt -> fetch();
		}else{
			$stmt = Conexion::conectar()->prepare("SELECT e.id, e.titulo, e.url, cc.NOMBRE_CAMPANA, e.Fecha FROM $tabla e join cat_campanas cc on e.id_campana = cc.id_campana");
			$stmt -> execute();
			return $stmt -> fetchAll();
		}
		$stmt -> close();
                    $stmt = null;
          }


		static public function mdlMostrarCampanas($tabla){
				$stmt = Conexion::conectar()->prepare("SELECT NOMBRE_CAMPANA, estatus, id_campana FROM $tabla where estatus = 1");			
				$stmt -> execute();
				return $stmt -> fetchAll();
				$stmt -> close();
				$stmt = null;
		}

	static public function mdlCrearEnlace($tabla, $datos){              
                    try {
	          $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(titulo, url, id_campana) VALUES (:tituloEnlace, :nombreEnlace, :id_Campana)");                    
		$stmt->bindParam(":tituloEnlace", $datos["Titulo_Enlace"], PDO::PARAM_STR);
		$stmt->bindParam(":nombreEnlace", base64_encode($datos["nombreLiga"]), PDO::PARAM_STR);
		$stmt->bindParam(":id_Campana", $datos["Id_campana"], PDO::PARAM_STR);
		if($stmt->execute()){
			return "ok";	
		}else{
			return "error";
		}
		$stmt->close();
		$stmt = null;
          } catch (Exception $th) {
                    echo $th->getMessage();
          }
	}

	static public function mdlEditarEnlace($tabla, $datos){
		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET titulo = :Editartitulo, url=:EditarLiga, id_campana=:Editarcampana WHERE id = :Enlace_id");
		$stmt -> bindParam(":Editartitulo", $datos["Editartitulo"], PDO::PARAM_STR);
		$stmt -> bindParam(":EditarLiga", base64_encode($datos["EditarLiga"]), PDO::PARAM_STR);
		$stmt -> bindParam(":Editarcampana", $datos["Editarcampana"], PDO::PARAM_STR);
		$stmt -> bindParam(":Enlace_id", $datos["Enlace_id"], PDO::PARAM_STR);

		if($stmt -> execute()){
			return "ok";
		}else{
			return "error";	
		}
		$stmt -> close();
		$stmt = null;
	}

	static public function mdlBorrarEnlace($tabla, $datos){
		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id_campana = :id_campana");
		$stmt -> bindParam(":id_campana", $datos, PDO::PARAM_INT);
		if($stmt -> execute()){
			return "ok";
		}else{
			return "error";
		}
		$stmt -> close();
		$stmt = null;
	}
}