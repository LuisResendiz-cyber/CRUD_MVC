<?php
# @uthor Mark
# nuevo_telefono File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

$error = "0";
$error = isset($_REQUEST['error']) ??  '';

initialize("agente","Nuevo Telefono");

if ($error == 0) {
    layout_menu($db, "");
}else{
    layout_menu($db, "avisoClienteMolesto();");
}

$datos_cliente = get_session_varname("datos_persona");
?>	
<p class="textbold">Agentes &gt; Nuevo Telefono</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=11" name="frm1">

<table border="0">
    <tr>
        <td colspan="2"><?=form_oblmsg();?></td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr><tr>
        <td><b>Cliente: </b></td>
        <td><b><?=$datos_cliente[0]["NOMBRE"].' '.$datos_cliente[0]["APATERNO"].' '.$datos_cliente[0]["AMATERNO"]?></b></td>
    </tr><tr>
        <td><b>* Lada:<br></b>
        <td><input type="text" class="form-control" size="10" name="lada" id="lada" maxlength="3" ></td>
    </tr><tr>
        <td><b>* N&uacute;mero Telef&oacute;nico:</b>
        <td><input type="text" class="form-control" size="10" name="telefono" id="telefono" maxlength="8" onchange="verify_movil(this,9);">
            <div id="tel_9">                
            </div>
        </td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr><tr>
        <td colspan="2">
            <input type="hidden" size="10" name="tipo_telefonico" id="tipo_telefonico" value="">
            <input type="button" value="Cancelar" class="btn btn-danger" onclick="Atras()"/>&nbsp;&nbsp;
            <input type="button" value="Continuar" class="btn btn-success" onclick="Valida_Telefono('<?=encripta(11)?>')"/>&nbsp;&nbsp;
        </td>
    </tr>
</table>
</form>
<?
layout_footer();
?>