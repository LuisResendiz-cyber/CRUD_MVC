import {
  tariff,
  funeralExpenses,
  rate,
  hea,
  segmentos,
  descuentos,
  dataForms,
  derechoPoliza,
  iva,
  recargosPorPago,
  asistenciaMedica,
} from "./tables.js";

function calculateAge(fechaNacimiento) {
  const nacimiento = convertDate(fechaNacimiento); // Convertimos el string de fecha
  if (!nacimiento) return ""; // Si la fecha es inválida, retornamos un valor vacío
  
  // const hoy = new Date();
  // let edad = hoy.getFullYear() - nacimiento.getFullYear();
  // const mes = hoy.getMonth() - nacimiento.getMonth();
  // if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
  //   edad--;
  // }
  // return edad;
}

function convertDate(fechaStr) {
  const [dia, mes, año] = fechaStr.split("/").map(Number);
  if (!dia || !mes || !año) return null; // Retornar null si algún valor es inválido
  return new Date(año, mes - 1, dia); // Mes se ajusta restando 1 porque empieza en 0 en Date
}

function calculateSAAGFU(data) {
  let D5 = data;
  let Tarifas_Y4 = tariff.y4;
  let Tarifas_Z4 = tariff.z4;

  let result = Math.min(D5 * Tarifas_Y4, Tarifas_Z4);
  // console.log(result)
  return result;
}

function calculateAGFU(gender, age) {
  if (funeralExpenses[age]) {
    return gender == "M"
      ? funeralExpenses[age].Hombres
      : funeralExpenses[age].Mujeres;
  } else {
    return "N/A";
  }
}

function calculateRate(gender, age) {
  // console.log(gender,'--------',age)
  if (rate[age]) {
    return gender == "M" ? rate[age].Hombres : rate[age].Mujeres;
  } else {
    return "N/A";
  }
}

function calculatePorDesc() {
  const segment = dataForms.segment; //D8

  if (dataForms.discounts == "Segmento") {
    //d9

    const segmentoEncontrado = segmentos.find(
      (item) => item.segmento === segment
    );
    dataForms.porDesc = segmentoEncontrado.porcentaje;
    document.querySelector(".porDesc").textContent = `${
      segmentoEncontrado.porcentaje ?? 0
    }%`;

    // console.log('segmentoEncontrado.porcentaje->',segmentoEncontrado.porcentaje )
  } else {
    const descuentoEncontrado = descuentos.find(
      (item) => item.tipo === dataForms.discounts
    );
    dataForms.porDesc = descuentoEncontrado.porcentaje;
    document.querySelector(".porDesc").textContent = `${
      descuentoEncontrado.porcentaje ?? 0
    }%`;

    // console.log('segmentoEncontrado.porcentaje->',descuentoEncontrado.porcentaje )
  }
}

const calculateTblHea = () => {
  const sumInsured = document.querySelector("#sumInsured").value;
  const rowOneKeys = Array.from({ length: 9 }, (_, i) => `h${14 + i}`);
  const dataHeaKeys_h0 = Array.from({ length: 9 }, (_, i) => `HEA-0-${i + 1}`);
  const dataHeaKeys_h1 = Array.from({ length: 9 }, (_, i) => `HEA-1-${i + 1}`);
  const dataHeaKeys_h2 = Array.from({ length: 9 }, (_, i) => `HEA-2-${i + 1}`);
  const dataHeaKeys_h3 = Array.from({ length: 9 }, (_, i) => `HEA-3-${i + 1}`);
  const dataHeaKeys_h4 = Array.from({ length: 9 }, (_, i) => `HEA-4-${i + 1}`);
  const dataHeaKeys_h5 = Array.from({ length: 9 }, (_, i) => `HEA-5-${i + 1}`);
  const dataHeaKeys_h6 = Array.from({ length: 9 }, (_, i) => `HEA-6-${i + 1}`);

  //? ----------------------------------------------------------------------------------------------------
  const updateCell = (cell, value) => {
    //*Primero limpiamos datos para despues planchar lo nuevo
    let rsp = parseFloat(value.toFixed(2));

    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    cell.textContent = `$${rsp}`;
    // cell.style.backgroundColor = 'yellow';
    dataForms.hea[cell.className] = value;
  };

  const calculateSum = (prefix, dataHeaKeys) => {
    const sum = dataHeaKeys
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`) // Evita "HEA- -10"
      .reduce((acc, key) => acc + (dataForms.hea[key] ?? 0), 0);
    return Math.round(sum * 100) / 100;
  };

  //? ----------------------------------------------------------------------------------------------------
  const calculateRowOneCell = (index, cell) => {
    const key = index === 0 ? "h13" : rowOneKeys[index - 1];
    const value = ((dataForms.customer?.[key] ?? 0) / 1000) * sumInsured;
    updateCell(cell, value);
  };

  const calculateRowTwoCell = (index, cell) => {
    const baseValue = dataForms.hea[`HEA-0-${index + 1}`] ?? 0;
    const value = baseValue * dataForms.porDesc;
    updateCell(cell, value);
  };

  const calculateRowThreeCell = (index, cell) => {
    const h1 = dataForms.hea[`HEA-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`HEA-1-${index + 1}`] ?? 0;

    const value =
      (h1 - h2) * recargosPorPago[dataForms.paymentMethod].porcentaje;
    // console.log('h7-->', recargosPorPago[dataForms.paymentMethod].porcentaje)
    // console.log('R.P.F.--->',value)
    updateCell(cell, value);
  };

  const calculateRowFourCell = (index, cell) => {
    const value = 0;
    updateCell(cell, value);
  };

  const calculateRowFiveCell = (index, cell) => {
    const h1 = dataForms.hea[`HEA-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`HEA-1-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`HEA-2-${index + 1}`] ?? 0;
    const h4 = dataForms.hea[`HEA-3-${index + 1}`] ?? 0;

    // console.table('h1:',h1,'h2:',h2,'h3:',h3,'h4:',h4,'iva:',iva)
    // console.log('Formula:  ',(h1 + h2 + h3 + h4) * iva)
    const value = (h1 + h2 + h3 + h4) * iva; //0.16
    // console.log('iva-->',value)
    updateCell(cell, value);
  };

  const calculateRowSixCell = (index, cell) => {
    const h1 = dataForms.hea[`HEA-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`HEA-1-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`HEA-2-${index + 1}`] ?? 0;
    const h4 = dataForms.hea[`HEA-3-${index + 1}`] ?? 0;
    const h5 = dataForms.hea[`HEA-4-${index + 1}`] ?? 0;
    const value = h1 + h2 + h3 + h4 + h5;
    updateCell(cell, value);

    // =(E24-E25+E26+E27+E28)
  };
  const calculateRowSevenCell = (index, cell) => {
    const h29 = dataForms.hea[`HEA-5-${index + 1}`] ?? 0;

    const value = h29 / recargosPorPago[dataForms.paymentMethod].frecuencia;
    updateCell(cell, value);
  };
  const calculateRowEightCell = (index, cell) => {
    const h30 = dataForms.hea[`HEA-6-${index + 1}`] ?? 0;

    const value = h30;
    updateCell(cell, value);
  };

  //? ----------------------------------------------------------------------------------------------------

  Array.from(tbl_hea.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      //!------------------------------------------------------------------
      if (rowIndex === 1) {
        //Prima Neta Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowOneCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-0-", dataHeaKeys_h0);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 2) {
        //Descuento Especial
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowTwoCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-1-", dataHeaKeys_h1);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 3) {
        //R.P.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowThreeCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-2-", dataHeaKeys_h2);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 4) {
        //Derecho Póliza
        if (cellIndex === 1) {
          const val = derechoPoliza;
          updateCell(cell, val);
        }

        if (cellIndex > 1 && cellIndex < 10) {
          calculateRowFourCell(cellIndex - 1, cell);
        }

        if (cellIndex === 10) {
          const sum = calculateSum("HEA-3-", dataHeaKeys_h3);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 5) {
        //IVA
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowFiveCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-4-", dataHeaKeys_h4);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 6) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowSixCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-5-", dataHeaKeys_h5);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 7) {
        //Prima 1er Recibo
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowSevenCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("HEA-6-", dataHeaKeys_h6);
          updateCell(cell, sum);
        }
      }
      //!------------------------------------------------------------------
      if (rowIndex === 8) {
        //Pagos subsecuentes
        if (cellIndex >= 1 && cellIndex < 11) {
          calculateRowEightCell(cellIndex - 1, cell);
        }
      }
      //!------------------------------------------------------------------
    });
  });
};

// *************************************************************************************

const calculateTbLAgfu = () => {
  if (dataForms.funeralExpenses == 0) {
    // console.log('sin gastos funerarios')
    return false;
  }

  const rowOneKeys = Array.from({ length: 9 }, (_, i) => `h${14 + i}-agfu`);
  const dataHeaKeys = Array.from({ length: 9 }, (_, i) => `AGFU-0-${i + 1}`);
  const dataHeaKeys_1 = Array.from({ length: 9 }, (_, i) => `AGFU-1-${i + 1}`);
  const dataHeaKeys_2 = Array.from({ length: 9 }, (_, i) => `AGFU-2-${i + 1}`);
  const dataHeaKeys_3 = Array.from({ length: 9 }, (_, i) => `AGFU-3-${i + 1}`);
  const dataHeaKeys_4 = Array.from({ length: 9 }, (_, i) => `AGFU-4-${i + 1}`);
  const dataHeaKeys_5 = Array.from({ length: 9 }, (_, i) => `AGFU-5-${i + 1}`);

  const updateCell = (cell, value) => {
    //*Primero limpiamos datos para despues planchar lo nuevo
    let rsp = parseFloat(value.toFixed(2));

    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    cell.textContent = `$${rsp}`;
    // cell.style.backgroundColor = 'yellow';
    dataForms.hea[cell.className] = value;
  };
  const calculateSum = (prefix, dataHeaKeys) => {
    const sum = dataHeaKeys
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`) // Evita "AGFU- -10"
      .reduce((acc, key) => acc + (dataForms.hea[key] ?? 0), 0);
    return Math.round(sum * 100) / 100;
  };

  const calculateRowOneCell = (index, cell) => {
    const key = index === 0 ? "h13-agfu" : rowOneKeys[index - 1];
    const value = ((dataForms.customer?.[key] ?? 0) * dataForms.saAgfu) / 1000;
    updateCell(cell, value);
  };

  const calculateRowTwoCell = (index, cell) => {
    const baseValue = dataForms.hea[`AGFU-0-${index + 1}`] ?? 0;
    const value = baseValue * dataForms.porDesc;
    updateCell(cell, value);
  };

  const calculateRowThreeCell = (index, cell) => {
    const h1 = dataForms.hea[`AGFU-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`AGFU-1-${index + 1}`] ?? 0;
    const value =
      (h1 - h2) * recargosPorPago[dataForms.paymentMethod].porcentaje;
    updateCell(cell, value);
  };

  const calculateRowFourCell = (index, cell) => {
    const h1 = dataForms.hea[`AGFU-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`AGFU-1-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`AGFU-2-${index + 1}`] ?? 0;
    const value = h1 + h2 + h3;
    updateCell(cell, value);
  };

  const calculateRowFiveCell = (index, cell) => {
    const e37 = dataForms.hea[`AGFU-3-${index + 1}`] ?? 0;

    const value = e37 / recargosPorPago[dataForms.paymentMethod].frecuencia;
    updateCell(cell, value);
  };
  const calculateRowSixCell = (index, cell) => {
    const h30 = dataForms.hea[`AGFU-4-${index + 1}`] ?? 0;

    const value = h30;
    updateCell(cell, value);
  };

  Array.from(tbl_agfu.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      if (rowIndex === 1) {
        //Prima Cobertura
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowOneCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-0-", dataHeaKeys);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 2) {
        //Descuento Especial
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowTwoCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-1-", dataHeaKeys_1);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 3) {
        //R.P.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowThreeCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-2-", dataHeaKeys_2);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 4) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowFourCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-3-", dataHeaKeys_3);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 5) {
        //Prima 1er Recibo
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowFiveCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-4-", dataHeaKeys_4);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 6) {
        //Pagos subsecuentes
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRowSixCell(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("AGFU-5-", dataHeaKeys_5);
          updateCell(cell, sum);
        }
      }
    });
  });
};

const calculateTblAsim = () => {
  if (dataForms.medicalAssistance == 0) {
    return false;
  }

  const dataHeaKeys_h0 = Array.from({ length: 9 }, (_, i) => `ASIM-0-${i + 1}`);
  const dataHeaKeys_h1 = Array.from({ length: 9 }, (_, i) => `ASIM-1-${i + 1}`);
  const dataHeaKeys_h2 = Array.from({ length: 9 }, (_, i) => `ASIM-2-${i + 1}`);
  const dataHeaKeys_h3 = Array.from({ length: 9 }, (_, i) => `ASIM-3-${i + 1}`);
  const dataHeaKeys_h4 = Array.from({ length: 9 }, (_, i) => `ASIM-4-${i + 1}`);
  const dataHeaKeys_h5 = Array.from({ length: 9 }, (_, i) => `ASIM-5-${i + 1}`);
  const rowOneKeys = Array.from({ length: 9 }, (_, i) => `h${14 + i}`);

  const updateCell = (cell, value) => {
    //*Primero limpiamos datos para despues planchar lo nuevo
    let rsp = parseFloat(value.toFixed(2));

    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    cell.textContent = `$${rsp}`;
    // cell.style.backgroundColor = 'yellow';
    dataForms.hea[cell.className] = value;
  };

  const calculateSum = (prefix, dataHeaKeys) => {
    const sum = dataHeaKeys
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`) // Evita "HEA- -10"
      .reduce((acc, key) => acc + (dataForms.hea[key] ?? 0), 0);
    return Math.round(sum * 100) / 100;
  };

  const calculatePrimaAsistencia = (index, cell) => {
    const key = index === 0 ? "h13-age" : rowOneKeys[index - 1];
    const value = dataForms.customer?.[key] == null ? 0 : asistenciaMedica;
    // console.log('***',value)

    updateCell(cell, value);
  };
  const calculateDescuentoEspecial = (index, cell) => {
    const baseValue = dataForms.hea[`ASIM-0-${index + 1}`] ?? 0;
    const value = baseValue * dataForms.porDesc;

    updateCell(cell, value);
  };

  const calculateRpf = (index, cell) => {
    const h1 = dataForms.hea[`ASIM-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`ASIM-1-${index + 1}`] ?? 0;
    const value =
      (h1 - h2) * recargosPorPago[dataForms.paymentMethod].porcentaje;
    updateCell(cell, value);
  };
  const calculateIva = (index, cell) => {
    const h1 = dataForms.hea[`ASIM-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`ASIM-1-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`ASIM-2-${index + 1}`] ?? 0;

    const value = (h1 + h2 + h3) * iva; //0.16

    updateCell(cell, value);
  };
  const calculatePrimaTotal = (index, cell) => {
    const h0 = dataForms.hea[`ASIM-0-${index + 1}`] ?? 0;
    const h1 = dataForms.hea[`ASIM-1-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`ASIM-2-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`ASIM-3-${index + 1}`] ?? 0;
    const value = h0 + h1 + h2 + h3;
    updateCell(cell, value);
  };

  const calculatePrimaPrimerRecibo = (index, cell) => {
    const e37 = dataForms.hea[`ASIM-4-${index + 1}`] ?? 0;

    const value = e37 / recargosPorPago[dataForms.paymentMethod].frecuencia;
    updateCell(cell, value);
  };

  const calculatePagosSubsecuentes = (index, cell) => {
    const h30 = dataForms.hea[`ASIM-5-${index + 1}`] ?? 0;
    const value = h30;
    updateCell(cell, value);
  };

  Array.from(tbl_asim.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      if (rowIndex === 1) {
        //Prima Asistencia
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaAsistencia(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-0-", dataHeaKeys_h0);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 2) {
        //Descuento Especial
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateDescuentoEspecial(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-1-", dataHeaKeys_h1);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 3) {
        //R.P.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRpf(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-2-", dataHeaKeys_h2);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 4) {
        //IVA
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateIva(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-3-", dataHeaKeys_h3);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 5) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaTotal(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-4-", dataHeaKeys_h4);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 6) {
        //Prima 1er Recibo
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaPrimerRecibo(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("ASIM-5-", dataHeaKeys_h5);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 7) {
        //Pagos subsecuentes
        if (cellIndex >= 1 && cellIndex < 11) {
          calculatePagosSubsecuentes(cellIndex - 1, cell);
        }
      }
    });
  });
};

const calculateNoDiscount = () => {
  const dataHeaKeys_h0 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-0-${i + 1}`
  );
  const dataHeaKeys_h1 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-1-${i + 1}`
  );
  const dataHeaKeys_h2 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-2-${i + 1}`
  );
  const dataHeaKeys_h3 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-3-${i + 1}`
  );
  const dataHeaKeys_h4 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-4-${i + 1}`
  );
  const dataHeaKeys_h5 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-5-${i + 1}`
  );
  const dataHeaKeys_h6 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-6-${i + 1}`
  );
  const dataHeaKeys_h7 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-7-${i + 1}`
  );
  const dataHeaKeys_h8 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-8-${i + 1}`
  );
  const dataHeaKeys_h9 = Array.from(
    { length: 9 },
    (_, i) => `Monto_Prima_Anual-9-${i + 1}`
  );

  const sumInsured = document.querySelector("#sumInsured").value;

  const rowOneKeys = Array.from({ length: 9 }, (_, i) => `h${14 + i}`);
  const rowOneKeysAge = Array.from({ length: 9 }, (_, i) => `h${14 + i}-age`);
  const rowOneKeysAgfu = Array.from({ length: 9 }, (_, i) => `h${14 + i}-agfu`);

  const updateCell = (cell, value) => {
    //*Primero limpiamos datos para despues planchar lo nuevo
    let rsp = parseFloat(value.toFixed(2));

    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    cell.textContent = `$${rsp}`;
    // cell.style.backgroundColor = 'yellow';
    dataForms.hea[cell.className] = value;
  };

  const calculateSum = (prefix, dataHeaKeys) => {
    const sum = dataHeaKeys
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`) // Evita "HEA- -10"
      .reduce((acc, key) => acc + (dataForms.hea[key] ?? 0), 0);
    return Math.round(sum * 100) / 100;
  };

  const calculatePrimaNetaTotal = (index, cell) => {
    const key = index === 0 ? "h13" : rowOneKeys[index - 1];
    const value = ((dataForms.customer?.[key] ?? 0) / 1000) * sumInsured;
    // console.log(sumInsured)
    updateCell(cell, value);
  };
  const calculatePrimaApoyoGF = (index, cell) => {
    const key = index === 0 ? "h13-age" : rowOneKeysAge[index - 1];
    const key2 = index === 0 ? "h13-agfu" : rowOneKeysAgfu[index - 1];

    if (dataForms.funeralExpenses === 1 && dataForms.customer?.[key] != null) {
      // console.log('Fecha de nacimiento encontrada:', dataForms.customer[key2], 'Suma asegurada:', dataForms.sumInsured);

      const value = (dataForms.customer[key2] * dataForms.saAgfu) / 1000;
      updateCell(cell, value);
    }
  };

  const calculatePrimaAsistencia = (index, cell) => {
    const key = index === 0 ? "h13-age" : rowOneKeys[index - 1];
    const value = dataForms.customer?.[key] == null ? 0 : asistenciaMedica;

    updateCell(cell, value);
  };

  const calculateRpf = (index, cell) => {
    const h1 = dataForms.hea[`Monto_Prima_Anual-0-${index + 1}`] ?? 0;
    const h2 = dataForms.hea[`Monto_Prima_Anual-1-${index + 1}`] ?? 0;
    const h3 = dataForms.hea[`Monto_Prima_Anual-2-${index + 1}`] ?? 0;
    const value =
      (h1 + h2 + h3) * recargosPorPago[dataForms.paymentMethod].porcentaje;
    updateCell(cell, value);
  };
  const calculateIva = (index, cell) => {
    const E53 = dataForms.hea[`Monto_Prima_Anual-0-${index + 1}`] ?? 0;
    const E55 = dataForms.hea[`Monto_Prima_Anual-2-${index + 1}`] ?? 0;

    const E57 = dataForms.hea[`Monto_Prima_Anual-4-${index + 1}`] ?? 0;

    const value =
      ((E53 + E55) * (1 + recargosPorPago[dataForms.paymentMethod].porcentaje) +
        E57) *
      iva;

    // console.log('fffffffffff----',recargosPorPago[dataForms.paymentMethod].porcentaje)

    updateCell(cell, value);
  };

  const calculatePrimaTotal = (index, cell) => {
    const E53 = dataForms.hea[`Monto_Prima_Anual-0-${index + 1}`] ?? 0;
    const E54 = dataForms.hea[`Monto_Prima_Anual-1-${index + 1}`] ?? 0;
    const E55 = dataForms.hea[`Monto_Prima_Anual-2-${index + 1}`] ?? 0;
    const E56 = dataForms.hea[`Monto_Prima_Anual-3-${index + 1}`] ?? 0;
    const E57 = dataForms.hea[`Monto_Prima_Anual-4-${index + 1}`] ?? 0;
    const E58 = dataForms.hea[`Monto_Prima_Anual-5-${index + 1}`] ?? 0;
    const value = E53 + E54 + E55 + E56 + E57 + E58;
    updateCell(cell, value);
  };

  const calculatePrimaPrimerRecibo = (index, cell) => {
    const e37 = dataForms.hea[`Monto_Prima_Anual-6-${index + 1}`] ?? 0;

    const value = e37 / recargosPorPago[dataForms.paymentMethod].frecuencia;
    updateCell(cell, value);
  };

  const calculatePagosSubsecuentes = (index, cell) => {
    const h30 = dataForms.hea[`Monto_Prima_Anual-7-${index + 1}`] ?? 0;
    const value = h30;
    updateCell(cell, value);
  };

  Array.from(tbl_no_discount.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      if (rowIndex === 1) {
        //Prima Neta Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaNetaTotal(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-0-", dataHeaKeys_h0);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 2) {
        //Prima Apoyo por G.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaApoyoGF(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-1-", dataHeaKeys_h1);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 3) {
        //Prima Asistencia
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaAsistencia(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-2-", dataHeaKeys_h2);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 4) {
        //R.P.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRpf(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-3-", dataHeaKeys_h3);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 5) {
        //Derecho Póliza
        if (cellIndex === 1) {
          const val = derechoPoliza;
          updateCell(cell, val);
        }

        if (cellIndex > 1 && cellIndex < 10) {
          updateCell(cell, 0);
        }

        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-4-", dataHeaKeys_h4);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 6) {
        //IVA
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateIva(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-5-", dataHeaKeys_h5);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 7) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaTotal(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-6-", dataHeaKeys_h6);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 8) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calculatePrimaPrimerRecibo(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSum("Monto_Prima_Anual-7-", dataHeaKeys_h7);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 9) {
        //Pagos subsecuentes
        if (cellIndex >= 1 && cellIndex < 11) {
          calculatePagosSubsecuentes(cellIndex - 1, cell);
        }
      }

      // *****************Fin de array**********************
    });
  });
};

const calculateAcsel = () => {
  // const dataHeaKeys_h0 = Array.from({ length: 9 }, (_, i) => `Monto_Prima_Anual-0-${i + 1}`);
  // const rowOneKeys = Array.from({ length: 9 }, (_, i) => `h${14 + i}`);

  const updateCell = (cell, value) => {
    //*Primero limpiamos datos para despues planchar lo nuevo
    let rsp = parseFloat(value.toFixed(2));

    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    cell.textContent = `$${rsp}`;
    // cell.style.backgroundColor = 'yellow';
    dataForms.hea[cell.className] = value;
  };

  const calculatePrimaRiesgo = (index, cell) => {
    const N24 = dataForms.hea[`HEA-0-10`] ?? 0;
    const N34 = dataForms.hea[`AGFU-0-10`] ?? 0;
    const N42 = dataForms.hea[`ASIM-0-10`] ?? 0;

    const value = N24 + N34 + N42;
    updateCell(cell, value);
  };

  const calculatePrimaNeta = (index, cell) => {
    const N24 = dataForms.hea[`HEA-0-10`] ?? 0;
    const N34 = dataForms.hea[`AGFU-0-10`] ?? 0;
    const N42 = dataForms.hea[`ASIM-0-10`] ?? 0;

    const N25 = dataForms.hea[`HEA-1-10`] ?? 0;
    const N35 = dataForms.hea[`AGFU-1-10`] ?? 0;
    const N43 = dataForms.hea[`ASIM-1-10`] ?? 0;

    const value = N24 + N34 + N42 - N25 - N35 - N43;
    updateCell(cell, value);
  };

  const calculateRecargoFraccionamiento = (index, cell) => {
    const N26 = dataForms.hea[`HEA-2-10`] ?? 0;
    const N36 = dataForms.hea[`AGFU-2-10`] ?? 0;
    const N44 = dataForms.hea[`ASIM-2-10`] ?? 0;

    const value = N26 + N36 + N44;
    updateCell(cell, value);
  };
  const calculateDerechoEmision = (index, cell) => {
    const N27 = dataForms.hea[`HEA-3-10`] ?? 0;
    const value = N27;
    updateCell(cell, value);
  };

  const calculateImpuesto = (index, cell) => {
    const N28 = dataForms.hea[`HEA-4-10`] ?? 0;
    const N45 = dataForms.hea[`ASIM-3-10`] ?? 0;

    const value = N28 + N45;

    updateCell(cell, value);
  };
  const calculatePrimaTotalSinDescuentos = (index, cell) => {
    const N59 = dataForms.hea[`Monto_Prima_Anual-6-10`] ?? 0;
    const value = N59;

    updateCell(cell, value);
  };

  const calculateDescuento = (index, cell) => {
    const N25 = dataForms.hea[`HEA-1-10`] ?? 0;
    const N35 = dataForms.hea[`AGFU-1-10`] ?? 0;
    const N43 = dataForms.hea[`ASIM-1-10`] ?? 0;

    const value = N25 + N35 + N43;

    updateCell(cell, value);
  };

  const calculatePrimaTotal = (index, cell) => {
    const N29 = dataForms.hea[`HEA-5-10`] ?? 0;
    const N37 = dataForms.hea[`AGFU-3-10`] ?? 0;
    const N46 = dataForms.hea[`ASIM-4-10`] ?? 0;

    const value = N29 + N37 + N46;

    updateCell(cell, value);
  };

  const calculatePrimeraCuota = (index, cell) => {
    const N30 = dataForms.hea[`HEA-6-10`] ?? 0;
    const N38 = dataForms.hea[`AGFU-4-10`] ?? 0;
    const N47 = dataForms.hea[`ASIM-5-10`] ?? 0;

    const value = N30 + N38 + N47;

    updateCell(cell, value);
  };

  const calculateSumaAseguradaHea = (index, cell) => {
    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    const value = dataForms.sumInsured;
    // console.log('sumInsured--',value)

    cell.textContent = `$${value}`;
    cell.style.backgroundColor = "yellow";
    dataForms.hea[cell.className] = value;
  };
  const calculateSumaAseguradaAgfu = (index, cell) => {
    cell.textContent = "";
    dataForms.hea[cell.className] = "";

    const value = dataForms.saAgfu;
    // console.log('saAgfu--',value)

    cell.textContent = `$${value}`;
    cell.style.backgroundColor = "yellow";
    dataForms.hea[cell.className] = value;
  };

  Array.from(tblAcsel.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      if (rowIndex === 1) {
        //PrimaRiesgo
        if (cellIndex == 1) {
          calculatePrimaRiesgo(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 2) {
        //Prima Neta
        if (cellIndex == 1) {
          calculatePrimaNeta(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 3) {
        //RecargoFraccionamiento
        if (cellIndex == 1) {
          calculateRecargoFraccionamiento(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 4) {
        //Derecho Emision
        if (cellIndex == 1) {
          calculateDerechoEmision(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 5) {
        //Impuesto
        if (cellIndex == 1) {
          calculateImpuesto(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 6) {
        //PrimaTotalSinDescuentos
        if (cellIndex == 1) {
          calculatePrimaTotalSinDescuentos(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 7) {
        //Descuento
        if (cellIndex == 1) {
          calculateDescuento(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 8) {
        //Prima Total
        if (cellIndex == 1) {
          calculatePrimaTotal(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 9) {
        //Primera Cuota
        if (cellIndex == 1) {
          calculatePrimeraCuota(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 10) {
        //Suma Asegurada HEA
        if (cellIndex == 1) {
          calculateSumaAseguradaHea(cellIndex - 1, cell);
        }
      }
      if (rowIndex === 11) {
        //Suma Asegurada AGFU
        if (cellIndex == 1) {
          calculateSumaAseguradaAgfu(cellIndex - 1, cell);
        }
      }
    });
  });
};

export function reloadAll(inputs) {
  // console.log(inputs)
  const [
    ,
    // Ignoramos el primer elemento
    { value: sumInsuredValue }, // Suma asegurada
    { value: saAgfu }, // Suma asegurada
    { value: paymentMethod }, // Forma de pago
    { value: segmentValue }, // Segmento
    { value: discounts }, // Descuento
    { checked: medicalAssistance }, // Asistencia médica
    { checked: funeralExpenses }, // Gastos funerarios
  ] = inputs;

  if (sumInsuredValue) {
    // console.log('sumInsuredValue----',sumInsuredValue)
    const rspta = calculateSAAGFU(sumInsuredValue);

    document.getElementById("saAgfu").value = rspta;

    dataForms.sumInsured = sumInsuredValue;

    dataForms.saAgfu = rspta;
  }

  if (paymentMethod) {
    const surcharge = recargosPorPago[paymentMethod].porcentaje * 100;
    let rsp = parseFloat(surcharge.toFixed(2));
    document.getElementById("paymentSurcharges").value = `${rsp}%`;
    dataForms.paymentMethod = paymentMethod;
  }

  //!aqui debemos de validar si hay gastos funerarios o asistencia medica sino limpiar la tabla correspondiente
  // console.log(medicalAssistance, '-----------medicalAssistance')
  // console.log(funeralExpenses, '-----------funeralExpenses')

  if (!funeralExpenses) {
    console.log("limpiando tabla");
    Object.keys(dataForms.hea).forEach((key) => {
      if (key.startsWith("AGFU-")) {
        delete dataForms.hea[key];
      }
    });

    Array.from(tbl_agfu.rows).forEach((row, rowIndex) => {
      Array.from(row.cells).forEach((cell, cellIndex) => {
        if (rowIndex != 0) {
          //Suma Asegurada AGFU
          if (cellIndex != 0) {
            cell.textContent = `$0`;
            // cell.style.backgroundColor = "yellow";
          }
        }
      });
    });
    // console.log('updateCustomerTable', dataForms.hea);
  }

  dataForms.segment = segmentValue ?? 0;
  dataForms.discounts = discounts ?? 0;
  dataForms.medicalAssistance = medicalAssistance ? 1 : 0;
  dataForms.funeralExpenses = funeralExpenses ? 1 : 0;

  calculatePorDesc();
  calculateTblHea();
  calculateTbLAgfu();
  calculateTblAsim();
  calculateNoDiscount();

  calculateAcsel();

  // console.log('reloadAll**')
  // console.table(dataForms);
}

export function updateCustomerTable(event) {
  const fila = event.target.closest("tr");
  const fechaNacimiento = fila.querySelector(".date-of-birth").value;
  const gender = fila.querySelector(".gender").value;
  const celdaEdad = fila.querySelector(".birth");
  const celdaAgfu = fila.querySelector(".agfu");
  const celdaRate = fila.querySelector(".rate");

  if (fechaNacimiento) {
    // Calcular edad, AGFU y rate cuando hay fecha de nacimiento
    const classes = celdaRate.classList;
    const specificClass = Array.from(classes).find((cls) => cls.startsWith("h")  );
    const edad = calculateAge(fechaNacimiento);
    const agfu = calculateAGFU(gender, edad);
    const rate = calculateRate(gender, edad);

    celdaEdad.value = edad;
    celdaAgfu.value = agfu;
    celdaRate.value = rate;

    // dataForms.customer[`${specificClass}-age`] = 0;
    // dataForms.customer[`${specificClass}-agfu`] = 0;

    dataForms.customer[`${specificClass}-age`] = edad;
    dataForms.customer[`${specificClass}-agfu`] = agfu;
    // dataForms.customer[specificClass] = rate;
    dataForms.customer[specificClass] = rate;
  } else {
    // Limpiar los campos si no hay fecha de nacimiento
    celdaEdad.value = "";
    celdaAgfu.value = "";
    celdaRate.value = "";
  }
  calculateTblHea();

  calculateTbLAgfu();
  calculateTblAsim();
  calculateNoDiscount();
  calculateAcsel();

  // console.log('updateCustomerTable', dataForms.hea);
}
