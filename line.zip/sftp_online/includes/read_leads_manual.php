<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CARGA AUTOMATICA LEADS DIGITAL</title>
</head>
<body>
    <style>
        body{
        background-color: black;
        color: white;
        }
        hr{
            border: 1px solid green;
        }
    </style>
</body>
</html>
<?
include "includes/saveData.php";

function start($db){  
    // echo 'hola';   
    // die();



    
    log_('INICIA CARGA AUTOMATICA',0,$db);
    $rspta_trunc = truncar_tbl_TU_CARGABASE_2($db);   //truncamos la tabla tu_cargabase_2 
    if(intval($rspta_trunc->_array[0]['RESPONSE']) == 1){
        log_('TABLA TRUNCADA => '.$rspta_trunc->_array[0]['RESPONSE'],0,$db);        
        open_leads($db);//iniciar guardado en tu_cargabase_2        
    }
    else{                           
        log_('ERROR AL TRUNCAR LA TABLA => '.$rspta_trunc->_array[0]['RESPONSE'],0,$db);                    
        // notifica('ERROR AL TRUNCAR LA TABLA => '.$rspta_trunc->_array[0]['RESPONSE']);   
        die();
    }  
}
function open_leads($db){
    $dir = scandir('leads_Errores');
    $directorio = array_diff($dir, array('.', '..'));

    
    foreach ($directorio as $key => $value) {  
       
        read_leads($value,$db);
        mover_archivos($value,1);
        // die();
    }
    sanitizacion($db); //higiene
} 
function read_leads($data,$db){ 
    // echo $data; die();
    try {
        $archivo = fopen("leads_Errores/".$data, "r");
        if ($archivo) {        
        fgetcsv($archivo);        
        while (($linea = fgetcsv($archivo)) !== false) {                        
            $titulo=$data;    
            $df=str_replace( array(' ',':','.csv'), array('_','_',''),$titulo);  
            $fechaC= explode("_", $df);  
            $dato_0= isset($linea[0]) ? $linea[0] : '';            
            $dato_1= isset($linea[1]) ? $linea[1] : '';
            $dato_2= isset($linea[2]) ? $linea[2] : '';
            $dato_3= isset($linea[3]) ? $linea[3] : '';
            $dato_4= isset($linea[4]) ? $linea[4] : '';
            $dato_5= isset($linea[5]) ? $linea[5] : '';
            $dato_6= isset($linea[6]) ? $linea[6] : '';
            $dato_7= isset($linea[7]) ? $linea[7] : '';
            $dato_8= isset($linea[8]) ? $linea[8] : '';
            $dato_9= isset($linea[9]) ? $linea[9] : '';
            $dato_10= isset($linea[10]) ? $linea[10] : '';
            $dato_11= isset($linea[11]) ? $linea[11] : '';
            $dato_12= isset($linea[12]) ? $linea[12] : '';
            $dato_13= isset($linea[13]) ? $linea[13] : '';
            $dato_14= isset($linea[14]) ? $linea[14] : '';
            
            $lead=array(
                'base' => $fechaC[3].' '.$fechaC[4].'_'.$fechaC[5].'_'.$fechaC[6].' '.$fechaC[7].'_'.$fechaC[8].'_'.$fechaC[9].' AUTO',
                "etiqueta_reg" => $fechaC[3].' '.$fechaC[4].'_'.$fechaC[5].'_'.$fechaC[6].' '.$fechaC[7].'_'.$fechaC[8].'_'.$fechaC[9],
                "ID" => $dato_0,
                "Nombre" => $dato_1.' '.$dato_2.' '.$dato_3,
                "Telefono" => $dato_5,
                "Fecha_c" => $fechaC[4].'/'.$fechaC[5].'/'.$fechaC[6], //fecha carga archivo
                "Hora_c" => $fechaC[7].':'.$fechaC[8].':'.$fechaC[9],  //hora carga archivo
                "Categoria" => $dato_6,
                "Fecha_nac" => $dato_4,
                "Bounce_Funnel" => $dato_7,
                "Source" => $dato_10,
                "Campaign" => $dato_8,
                "Gclid" => $dato_9,
                "Medium" => $dato_11,
                "Email" => $dato_12,
                "Auto_year" => $dato_13,
                "Model_brand_version" => $dato_14
             );

            // var_dump($lead);
            $rsptaI=insertarRegistro($lead,$db);//guardar en tu_cargabase_2   
            // echo $rsptaI;
                 
            if ($rsptaI === 'ERROR') {     
                log_('ERROR AL GUARDAR => '.$df.' - '.$dato_0,1,$db);        
                // notifica($data);
                mover_archivos($data,2); //mover a la carpeta de errores

            }     
            elseif(intval($rsptaI->_array[0]['RESPONSE']) == 1){             
                log_('REGISTRO GUARDADO => '.$df.' - '.$dato_0,0,$db);                           
            }
            else{                                       
                log_('ERROR AL GUARDAR => '.$df.' - '.$dato_0,1,$db);                                           
                // notifica($data);
                mover_archivos($data,2); //mover a la carpeta de errores
            }
            // die();
        } //fin while        
        fclose($archivo);
        } else {
            echo "No se pudo abrir el archivo:".$data;
            // notifica($data);        
            mover_archivos($data,2); //mover a la carpeta de errores
        }
    
    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";       
    }
    
}//fin read_leads


function sanitizacion($db){        
    $opt=optimiza_TU_CARGABASE_2($db);   
    if ($opt->_array[0]['RESPONSE']) {        
        log_('Exito al optimizar tabla',0,$db); 
        higiene($db);  
        $valida_1=valida_paso_1($db);
        if ($valida_1->_array[0]['RESPONSE']) { 
            log_('Exito paso 1',0,$db); 
        } else { 
            log_('Error paso 1',1,$db); 
            // notifica('Error paso 1');   
        }
    }else{
        log_('Error al optimizar tabla',1,$db); 
        // notifica('Error al optimizar tabla');   
    }    
    sleep(1);
}

    
function log_($texto,$estatus,$db){    
    echo '<hr>';
    echo $paso=$texto;   
    guardar_Log_SFTP($db,$estatus,$paso);
    sleep(1);
}



 
function mover_archivos($value,$opcion){        
    $folder='leads_Temporal/';
    $folder_destino = $opcion ==1 ? 'leads_Respaldo/':'leads_Errores/';     
    if (file_exists($folder.$value)) {
        echo '<br> Archivo transferido a la carpeta: '.$folder_destino.$value; 
        copy($folder.$value,$folder_destino.$value);
        unlink('leads_Temporal/'.$value); //descomentar al terminar            
    }else {
        echo 'No existe el archivo => '.$value;
    } 
}



