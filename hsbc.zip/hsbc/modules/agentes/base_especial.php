<?php
# @uthor Mark
# Cuestionario File
libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Nuevo registro");

$bases = get_select_bases_especiales(get_session_varname("s_usr_id"),$db);
//echo '<pre>';
//print_r($bases);
//echo '</pre>';
?>
<script language="JavaScript" src="<?= $linkpath ?>includes/js/jquery_validate.js" type="text/javascript"></script>
    <script>
        $(document).ready(function(){
            $("#base_especial").validate({
                submitHandler: function() {
                    var formData = new FormData($("#base_especial")[0]);
                    $.ajax({
                        url: "<?= $linkpath ?>modules.php?mod=agentes&op=base_especial2",
                        type: "post",
                        dataType: "html",
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false
                    }).done(function(data){
                        alert(data);
                    });
                }
            });
        });            
    </script>
</head>    
<body style="background: #3F738D;">
    <form name="base_especial" id="base_especial" method="post">
        <table style="alignment-adjust: central">
            <tr>
                <th colspan="2">Bases Especiales Disponibles</th>
            </tr>
                <?php
                while ($arr = $bases->FetchRow()){
                    echo "<tr>";
                    echo "<td>".$arr['NOMBRE']."(<span style=\"font-weight: 900;\">".$arr['DESCRIPCION']."</span>)<td>";
                    echo "<td><input class='required' type=\"radio\" value=\"radio_".$arr['U_SUPERVISOR']."_".get_session_varname("s_usr_nomina")."\" id=\"radio_\" name=\"radio_\"/><td>";                
                    echo "</tr>";
                }
                ?>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <input type="submit" value="Procesar" id="procesar"/>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>