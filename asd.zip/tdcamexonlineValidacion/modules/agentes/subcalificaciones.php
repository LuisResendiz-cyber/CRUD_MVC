<?php
# @uthor Mark
# Index File on agente module

$tu_base = " disabled";
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Nuevo registro");
$t_registro = $_REQUEST['t_reg'];

$isPredictivo2 = get_session_varname("s_usr_marcacion");

/* if(isset($_GET['aprocesado'])){## para ofrecer otro producto
  $aprocesado = $_GET['aprocesado'];
  } else {
  $aprocesado = null;
  } */

if ($isPredictivo2 == 1 && $t_registro == 1) {
    $t_registro = 1;
} else {
    $t_registro = 0;
}

set_session_varname("t_registro", $t_registro);
set_session_varname("url_contacto", "subcalificaciones");

//$tel = '.$datos_cliente[$indice]["CLAVELADA"].$datos_cliente[$indice]["TELEFONO"].'
$extenagente = get_session_varname('extension');
$user = get_session_varname("s_usr_id");
$nomina = get_session_varname('s_usr_nomina');
$datos_cliente = get_session_varname("datos_persona");

//if ($t_registro == 1){
    set_session_varname("tel_predictivo", $datos_cliente[0]['U_TELEFONO']);
//}

$id_solicitud = (strlen(get_session_varname('id_solicitud')) > 0 ? get_session_varname('id_solicitud') : desencripta($_REQUEST['sol']));
$productos_ = get_productos_campana($id_solicitud,$db); //PRODUCTOS
//$prod = $productos_->fields['U_PRODUCTO'];
//for ($t = 0; $t < count($productos_->_array); $t++)
layout_menu($db, "ShowScript_GeneralIN()");
?>
<p class="textbold">Agentes &gt; Calificaci&oacute;n de contacto en fr&iacute;o</p>
<p>&nbsp;</p>
<p>Qu&eacute; l&aacute;stima que no tuve suerte de encontrarlo, mi nombre es (mencionar nombre y apellido) de Volaris Invex la intenci&oacute;n de mi llamada era para informarle que por lanzamiento se le est&aacute; invitando a adquirir nuestra tarjeta Volaris un a&ntilde;o por medio de la cual puede ser acreedor a grandes descuentos que les haremos llegar v&iacute;a correo electr&oacute;nico y podr&aacute; tener viajes por medio de la aerol&iacute;nea sin costo, no se si usted ha viajado o ha escuchado de la aerol&iacute;nea Volaris.</p>
<p>Perfecto, esta tarjeta la podemos hacer extensiva para usted la cual tiene un bono de bienvenida de $1,200 y por cada compra que usted realice se le estar&aacute; bonificando en su monedero electr&oacute;nico para que comience a viajar a costos muy bajos y como cliente preferencial ya que...</p>
<p>&nbsp;</p>		
<form method="post" action="modules.php?mod=agentes&op=cuestionario" name="frm1">
    <table class="text" border="0" height="500px">
        <tr>
            <td width="60%">
                <table border="0">
                    <tr>
                        <td colspan="4">Seleccione la calificaci&oacute;n del contacto en fr&iacute;o o contacto distinto.</td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="2" class="textleft"><b>CALIFICACI&Oacute;N:&nbsp;</b></td>
                        <td colspan="2" class="label">
                            <select name="subcal">
                                <!--option value="">Elige opcion</option-->
                                <option value="1">No califica</option>
                                <option value="2">No interesa</option>
                                <option value="3">S&iacute; interesa</option>								
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">Seleccione de la lista una opci&oacute;n en cuanto haga contacto con cualquier persona de los distintos telefonos</td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <input type="button" value="Continuar" id="obRegistroAsisContinuar" onclick="this.disabled = true;
                                    revisa_calificacion2(1,frm1.subcal, frm1.tipo.value, frm1.referente.value, frm1.calificacion.value, frm1.telefono.value, frm1.cont.value, frm1.num.value, '<?=encripta(42)?>');" />&nbsp;&nbsp;
                            <input type="button" value="Regresar" id="btnRegresar" onclick="this.disabled = true;
                                    revisa_calificacion2(2,frm1.subcal, frm1.tipo.value, frm1.referente.value, frm1.calificacion.value, frm1.telefono.value, frm1.cont.value, frm1.num.value, '<?=encripta(42)?>');" />&nbsp;&nbsp;
                        </td>
                    </tr>
                </table>
            </td>
            <td rowspan="2">
                <div id="script" class="script"></div>
            </td>
        </tr>
    </table>
    <input type="hidden" name="tipo" value="<?php echo $_REQUEST['tipo'] ?>" />
    <input type="hidden" name="referente" value="<?php echo $_REQUEST['referente'] ?>" />
    <input type="hidden" name="calificacion" value="<?php echo $_REQUEST['calificacion'] ?>" />	
    <input type="hidden" name="telefono" value="<?php echo $_REQUEST['telefono'] ?>" />		
    <input type="hidden" name="cont" value="<?php echo $_REQUEST['cont'] ?>" />			
    <input type="hidden" name="num" value="<?php echo $_REQUEST['num'] ?>" />				
</form>
<?
layout_footer();
