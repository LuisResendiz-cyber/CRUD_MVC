<?php

# @uthor Mark 
# Process_data File 

require_once("includes/includes.inc.php");
require_once("modules/agentes/agentes.inc.php");

load_session();

$isPredictivo = get_session_varname("s_usr_marcacion");


$action = $_REQUEST['act'];
$ip_server = "172.20.1.10";
$header = "index2.php";

if (isset($action) && $action == 1) { # VALIDA LA AUTENTICACION DEL USUARIO
    
    $valor_return = login($_POST["user"], $_POST["password"], $_POST["extension"], $_POST["marcacion"], $db);
    

        $marcacion= $_POST["marcacion"] == 1 ? 'predictivo': "asistido";  

        $ext=get_session_varname("extension");

        $url_status_pred = "http://".$ip_server."/marcadoasistido/click2dial/hsbc/ivr.php?nomina=".$_POST["user"]."&marcacion=".$marcacion."&ext=".$ext;

        // var_dump($url_status_pred);
        // die();
        //$url_status_pred = "http://".$ip_server."/PYC_CLUSTER_ASISTIDO/hsbc/ivr.php?nomina=".$_POST["user"]."&marcacion=".$marcacion."&ext=".$ext;             
        $Curl_statuspred = curl_init();
        curl_setopt($Curl_statuspred, CURLOPT_URL, $url_status_pred);
        curl_setopt($Curl_statuspred, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($Curl_statuspred, CURLOPT_TIMEOUT, 3);
        $response =  curl_exec($Curl_statuspred);
        curl_close($Curl_statuspred);
        $response;

      




    $header = "index2.php?msg=" . encripta($valor_return);
    
} elseif (isset($action) && $action == 2) { # TERMINA SESION DEL USUARIO
    $empresa = get_session_varname("s_usr_centro");
    
    if ($isPredictivo == 1) {

        //Todos los centros estan centralizados ya no se hace distincion ni se usan diferentes URL's
        $url_logout_pred = "http://172.20.1.10/click2dial/hsbc/softemployeelogout.php?employeeid=" . get_session_varname("s_usr_id");
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
        
    }

    /*echo $_SESSION['s_usr_id'];
    echo $_SESSION['s_usr_maquina'];

    die();*/
    desocupar_usuario(get_session_varname("s_usr_id"), $db);
    set_traking(get_session_varname("s_usr_id"), 'FINALIZO SESION', get_session_varname("s_usr_maquina"), 0, '', $db);
    unload_session($db);
    $header = "index2.php?log_out=1";
}
header("location: " . $header);
