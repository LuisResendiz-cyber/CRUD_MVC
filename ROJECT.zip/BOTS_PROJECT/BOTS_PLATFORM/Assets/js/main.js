(function () {
  "use strict";
  let message; 
  var treeviewMenu = $(".app-menu");

  // Toggle Sidebar
  $('[data-toggle="sidebar"]').click(function (event) {
    event.preventDefault();
    $(".app").toggleClass("sidenav-toggled");
  });

  // Activate sidebar treeview toggle
  $("[data-toggle='treeview']").click(function (event) {
    event.preventDefault();
    if (!$(this).parent().hasClass("is-expanded")) {
      treeviewMenu
        .find("[data-toggle='treeview']")
        .parent()
        .removeClass("is-expanded");
    }
    $(this).parent().toggleClass("is-expanded");
  });

  $("[data-toggle='treeview.'].is-expanded")
    .parent()
    .toggleClass("is-expanded");
  $("[data-toggle='tooltip']").tooltip();

  window.Crud = {
    view({ module, request, id }) {
      fetch(`${base_url}/${module}/${request}/${id}`)
        .then((res) => res.json())
        .then((data) => {
          if (module == "Roles") {
          Crud.openModalRoles(module, data);            
          } else {
            fntViewUsuario(data);                        
          }
        }).catch((err) => console.error(err));
    },
    edit({ module, request, id }) {
      console.log(module);
      if (module == "Roles") {        
      fntEditRol(module, request, id);
      }else{
      fetch(`${base_url}/${module}/${request}/${id}`)
      .then((res) => res.json())
      .then((data) => {
        if (module == "Roles") {
          Crud.openModalRoles(module, data);            
        } else {
          editUsuarios(data);             
        }
      }).catch((err) => console.error(err));
      
    }
    },
    delete({ module,request, id }) {
      
      swal(
        {
          title: `Eliminar ${module}`,
          text: `¿Realmente quiere eliminar el ${module}?`,
          type: "warning",
          showCancelButton: true,
          confirmButtonText: "Si, eliminar!",
          cancelButtonText: "No, cancelar!",
          closeOnConfirm: false,
          closeOnCancel: true,
        },
        function (isConfirm) {
          if (isConfirm) {
      fetch(`${base_url}/${module}/${request}/${id}`)
      .then((res) => res.json())
      .then((data) => {
        let message = data.data.status == 0 ? "Error" : "Exitoso!"
        let icon = data.data.status == 0 ? "error" : "success"

        swal(message, data.data.Message, icon);
        const nameTable = `#table${module}`;
        let setRequest = [];

        if (module == "Roles") {
          setRequest = ["getRol", "delRol", "editRol"]
        }else{
          setRequest = ["getUsuario", "delUsuarios", "getUsuario"]
        }
        setTimeout(() => {
          initDataTable({
            tableId: nameTable,
            url: `${base_url}/${module}/get${module}`,
            dataSrc: module.toLowerCase(),
            module: module,
            request: setRequest,
            columnRenderers: {
              status: function (data) {
                return data == 1
                  ? '<span class="badge badge-success">Activo</span>'
                  : '<span class="badge badge-danger">Inactivo</span>';
              },
            },
          });
        }, 500);


      }).catch((err) => console.error(err));
          }
        }
      )
    },
	openModalRoles(module, data) {
		var estadoUsuario = data.data.status == 1 ? 
		'<span class="badge badge-success">Activo</span>' : 
		'<span class="badge badge-danger">Inactivo</span>';

		document.querySelector("#celIdentificacion").innerHTML = data.data.NOMBRE;
		document.querySelector("#celDescripcion").innerHTML = data.data.DESCRIPCION;
		document.querySelector("#celEstado").innerHTML = estadoUsuario;
		const modal = $('#modalViewRol');		
		modal.modal('show');
	}
  };

  async function initDataTable({
    tableId,
    url,
    dataSrc = "",
    module,
	  request,
    columnRenderers = {},
    pageLength = 10,
    order = [[0, "asc"]],
  }) {
    const table = $(tableId);
    if ($.fn.DataTable.isDataTable(tableId)) {
      table.DataTable().destroy();
      table.empty();
    }

    const response = await fetch(url);
    const json = await response.json();

    const data = dataSrc ? json[dataSrc] : json;

    if (!data || !data.length) {
      console.warn("No data received");
      return;
    }

    // 🔹 2. CONSTRUIR THEAD Y COLUMNS
    const columns = [];
    const thead = $("<thead><tr></tr></thead>");

    Object.keys(data[0]).forEach((key) => {
      thead.find("tr").append(`<th>${formatTitle(key)}</th>`);

      // 🔸 Si existe renderer para esta columna → usarlo
      if (columnRenderers[key]) {
        columns.push({
          data: key,
          render: columnRenderers[key],
        });
      } else {
        columns.push({ data: key });
      }
    });

    // 🔹 Acciones
    thead.find("tr").append("<th>Acciones</th>");
    columns.push({
      data: null,
      orderable: false,
      searchable: false,
      render: (row) => `
			<button class="btn btn-info btn-sm" onclick="Crud.view({ module: '${module}', request: '${request[0]}', id: ${row.ID} })">
			  <i class="fa fa-eye"></i>
			</button>
			<button class="btn btn-warning btn-sm" onclick="Crud.edit({ module: '${module}', request: '${request[2]}',id: ${row.ID} })">
			  <i class="fa fa-pencil"></i>
			</button>
			<button class="btn btn-danger btn-sm" onclick="Crud.delete({ module: '${module}', request: '${request[1]}',id: ${row.ID} })">
			  <i class="fa fa-trash"></i>
			</button>			
		  `,
    });

    table.prepend(thead);

    table.DataTable({
      data,
      columns,
      responsive: true,
      pageLength,
      order,
      dom: '<"row mb-2"<"col-md-4"l><"col-md-4 text-center"B><"col-md-4"f>>rtip',
      buttons: [
        { extend: "excel", className: "btn btn-success btn-sm me-1" },
        { extend: "csv", className: "btn btn-info btn-sm me-1" },
        { extend: "pdf", className: "btn btn-danger btn-sm me-1" },
      ],
    });
  }

  function formatTitle(key) {
    return key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
  }
  //GET_DATA
  async function getData(url) {
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data; // 👈 CLAVE
    } catch (error) {
        console.error('Error en getData:', error);
        throw error;
    }
}
  // EXPONER
  window.initDataTable = initDataTable;
  window.getData = getData;
})();



