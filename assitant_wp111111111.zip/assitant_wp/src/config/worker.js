const { Worker } = require("bullmq");

const worker = new Worker(
  "jobs",   // nombre de la cola — debe coincidir con queue.js
  async (job) => {

    console.log("=== Nuevo job recibido ===");
    console.log("Tipo:", job.name);
    console.log("ID Job:", job.id);
    console.log("Data:", job.data);

    // =======================================================
    // 1) TEST JOB (DEMO)
    // =======================================================
    if (job.name === "testJob") {
      console.log("Ejecutando testJob...");
      return { ok: true };
    }

    // =======================================================
    // 2) INBOUND MESSAGE (MENSAJE REAL DEL USUARIO)
    // =======================================================
    if (job.name === "inboundMessage") {
      const { from, text, wamid } = job.data;

      console.log("📩 Mensaje del usuario:");
      console.log("Número:", from);
      console.log("Texto:", text);
      console.log("WAMID:", wamid);

      // 👉 Aquí ya puedes meter:
      // - lógica de flujo
      // - lógica de botones
      // - conexión a IA
      // - respuesta automática

      // EJEMPLO simple de respuesta (luego lo hacemos real):
      console.log(`Responderé a ${from}: "${text}"`);

      // IMPORTANTE: si ya tienes una función sendWhatsAppMessage, la conectamos aquí.
      // await sendWhatsAppMessage(from, `Recibí tu mensaje: ${text}`);

      return { processed: true };
    }

    // =======================================================
    // 3) JOB DESCONOCIDO
    // =======================================================
    console.warn("⚠️ Job desconocido:", job.name);
    return { error: " job no reconocido " };
  },
  {
    connection: {
      host: "127.0.0.1",
      port: 6379,
    },
  }
);

worker.on("completed", (job) => {
  console.log(`✔️ Job completado: ${job.id}`);
});

worker.on("failed", (job, err) => {
  console.error(`❌ Job falló: ${job.id}`, err);
});
