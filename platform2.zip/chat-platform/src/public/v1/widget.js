document.addEventListener("DOMContentLoaded", () => {

  const chatBody = document.querySelector(".chat-body");
  const input = document.querySelector(".chat-footer input");
  const sendBtn = document.querySelector(".chat-footer button");

  if (!localStorage.getItem("chat_session_id")) {
    localStorage.setItem("chat_session_id", crypto.randomUUID());
  }

  const sessionId = localStorage.getItem("chat_session_id");


  const socket = io("http://localhost:4001", {
    transports: ["websocket"],
    auth: {
      session_id: sessionId,
      bot_id: 2
    }
  });

  input.disabled = false;
  sendBtn.disabled = false;

  function addMessage(text, type) {
    const msg = document.createElement("div");
    msg.className = `message ${type}`;
    msg.innerHTML = `<div class="bubble">${text}</div>`;
    chatBody.appendChild(msg);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  let typing = null;

  function showTyping() {
    if (typing) return;
  
    typing = document.createElement("div");
    typing.className = "message bot typing";
    typing.innerHTML = `
      <div class="bubble typing-indicator">
        <span></span><span></span><span></span>
      </div>
    `;
  
    chatBody.appendChild(typing);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
  
  

  function hideTyping() {
    typing?.remove();
    typing = null;
  }

  sendBtn.onclick = sendMessage;
  //input.onkeydown = e => e.key === "Enter" && sendMessage();

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendMessage();
    }
  });
  

  function sendMessage() {
    const text = input.value.trim();
    if (!text) return;

    input.value = "";
    addMessage(text, "user");
    showTyping();

    socket.emit("user_message", text);
  }

  socket.on("bot_message", (msg) => {
    hideTyping();
    addMessage(msg, "bot");
  });


  async function loadChatHistory() {
    try {
      const response = await fetch(
        `http://localhost:4001/apiV1/history/${sessionId}`
      );
      const data = await response.json();
  
      if (data.messages) {
        data.messages.forEach((msg) => {
          addMessage(
            msg.message_text,
            msg.role === "user" ? "user" : "bot"
          );
  
          lastMessageId = msg.id_webhook;
        });
      }
    } catch (err) {
      console.error("Error cargando historial", err);
    }
  }
  
  loadChatHistory();
  

});
