const express =  require('express');
const check = require('../Middleware/errorMiddleware')
const router = express.Router();
const jwt = require('../Middleware/authMiddelaware')
const appController = require('../controllers/appController')

router.post('/Createuser',check.checkUser, appController.setUser)
router.post('/login', check.checkLogin, appController.login)
router.get('/contactos', jwt, appController.getContacto)
router.get('/sync/contactos', jwt, appController.DataProcess)



router.get('/users', appController.getUser)
router.get('/User/:id', check.checkGetUser, jwt, appController.getUserById)


module.exports = router;