const express = require('express');
const router = express.Router();

const botsController = require('../controllers/bots.controller')

//BOT
//router.get("/init", botsController.getUserById);

router.get('/getAllBots', botsController.getAllBots);                   // GET /api/bots
router.get('/active', botsController.getActiveBots);          // GET /api/bots/active
router.get('/:id', botsController.getBotById);               // GET /api/bots/:id
router.get('/type/:type', botsController.getBotsByType);     // GET /api/bots/type/:type
router.post('/', botsController.createBot);                  // POST /api/bots
router.put('/:id', botsController.updateBot);                // PUT /api/bots/:id
router.delete('/:id', botsController.deleteBot);             // DELETE /api/bots/:id
router.patch('/:id/status', botsController.changeBotStatus); // PATCH /api/bots/:id/status


module.exports = router;