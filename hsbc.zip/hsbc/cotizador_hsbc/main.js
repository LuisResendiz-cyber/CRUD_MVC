import {hea,agfu,asim,noDiscount,acsel} from "./tables.js";
import { generateTable } from "./tableUtils.js";
import { reloadAll,updateCustomerTable  } from "./functions.js";


const tblAcsel = document.getElementById("tblAcsel");
const tbl_hea = document.getElementById("tbl_hea");
const tbl_agfu = document.getElementById("tbl_agfu");
const tbl_asim = document.getElementById("tbl_asim");
const tbl_no_discount = document.getElementById("tbl_no_discount");
 
window.addEventListener("load", function () {
  // console.clear();
  tblAcsel.innerHTML= generateTable(acsel);
  tbl_hea.innerHTML= generateTable(hea);
  tbl_agfu.innerHTML= generateTable(agfu);
  tbl_asim.innerHTML= generateTable(asim);
  tbl_no_discount.innerHTML= generateTable(noDiscount);

});
  


const inputs = document.querySelectorAll("#dateQuotation, #sumInsured, #saAgfu, #paymentMethod, #segment, #discounts, #medicalAssistance, #funeralExpenses, .date-of-birth, .gender");


inputs.forEach(input => {
  input.addEventListener("change", (event) => {

    if (event.target.matches("#dateQuotation, #sumInsured, #saAgfu, #paymentMethod, #segment, #discounts, #medicalAssistance, #funeralExpenses")) {
      reloadAll(inputs);
      
    } else if (event.target.matches(".date-of-birth, .gender")) {
      reloadAll(inputs);
      updateCustomerTable(event);
      
    }
  });
});



// inputs.forEach(input => {
//   input.dispatchEvent(new Event('change'));
// });







































































 
