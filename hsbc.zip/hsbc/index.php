

<script language='JavaScript1.2'>
    var myvar;
    var alto = screen.height;
    var ancho = screen.width;
    var myurl;
    myvar = "top=0,left=0,resizable=no,width=" + ancho + ",height=" + alto + ",toolbar=no,location=no,status=no,directories=no,scrollbars=yes,menubar=no"
    window.open("index3.php", "Sicall", myvar);
</script>
<b>PARA UNA MEJOR FUNCIONALIDAD DEL SICALL, FAVOR DE MANTENER ESTA VENTANA ABIERTA.</b>