const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
  // console.log('--------+++');
  console.log(context);
  // console.log('--------+++');*/
const baseQuery = "BEGIN "+ context.schema +".GET_CLAVEN_ACEPTAOFERTA(:rc); END;";
	let query = baseQuery;
	const binds = {};
  let result2 = {};
  binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
  const result = await database.simpleExecuteRC(query, binds);
  // console.log('_____****');
  console.log(result);
  // console.log('_____****');*/
  return result;

}

module.exports.find = find;
