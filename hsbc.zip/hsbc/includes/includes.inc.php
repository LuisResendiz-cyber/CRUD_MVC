<?php
ini_set("session.gc_maxlifetime", (60 * 60) * 8); // 60 minutos   //se setea a 8 horas a peticion de Aldo por motivo del funcionamiento del simulador @ 20221019
ini_set("session.gc_probability", 1);
ini_set("session.gc_divisor", 1);
ini_set("display_errors", true);

# Includes File
# @uthor Mark

    // $dbserver = '(DESCRIPTION =
    //     (LOAD_BALANCE = ON)
    //     (ADDRESS_LIST =
    //         (ADDRESS =
    //             (PROTOCOL = TCP)
    //             (HOST = 192.168.1.13)
    //             (PORT = 1521)
    //         )
    //         (ADDRESS =
    //             (PROTOCOL = TCP)
    //             (HOST = 192.168.1.14)
    //             (PORT = 1521)
    //         )
    //     )
    //     (CONNECT_DATA =
    //         (SERVICE_NAME = xccmtaf)
    //     )
    // )';

// if($_SERVER["SERVER_ADDR"] == '172.20.1.72'){
$dbserver = '(DESCRIPTION =
   (ADDRESS =
       (PROTOCOL = TCP)
       (HOST = 172.20.1.116)
       (PORT = 1521)
   )
   (CONNECT_DATA =
       (SERVICE_NAME = XE)
   )
)';
//}else{
   /*  $dbserver = '(DESCRIPTION =
         (ADDRESS =
             (PROTOCOL = TCP)
             (HOST = xccm-scan.ccm-itq.mx)
             (PORT = 1521)
         )
         (CONNECT_DATA =
             (SERVICE_NAME = xccmtaf)
         )
     )';*/
// }


$dbuser = "hsbcapp";
$dbpassword = "h0d9c476f1b";
// $dbuser = "hsbcweb";
// $dbpassword = "h526f80ac5e";
$dbschema = "";

$sessiontimeout = 3000;
$pagetitle = "Impulse Telecom";
$pagefooter = "Impulse Telecom";

/*
 * $linkpath es calculado y agregado a una cookie para
 * poder leerlo desde javascript y no tener que cambiar
 * este dato en futuras campañas.
 */
$path = explode('/', $_SERVER['SCRIPT_NAME']);
$linkpath = "";
for ($i = 1; $i < count($path) - 1; $i++) {
    $linkpath .= "/{$path[$i]}";
}
unset($path);

//session_save_path("/var/lib/php" . $linkpath);
session_save_path(__DIR__ . "/sessions");
$linkpath .= "/";
setcookie('linkpath', $linkpath);

$header_title = "HSBC SEGUROS";
$serveraddress = "http://{$_SERVER["SERVER_ADDR"]}:{$_SERVER["SERVER_PORT"]}";

require_once("openConnection.php");
require_once("session.inc.php");
require_once("db.inc.php");
require_once("menu.inc.php");
require_once("layout.inc.php");
require_once("functions.inc.php");
require_once("utils.inc.php");
require_once("section.inc.php");

error_reporting(E_ALL ^ E_NOTICE);
