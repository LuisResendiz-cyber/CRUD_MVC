<?php
// liga.php
if (isset($_GET['url'])) {
    $url = $_GET['url'];
    // Validar la URL si es necesario (por seguridad, validar que la URL sea válida y de confianza)
    // Por ejemplo, si solo permites URLs de un dominio específico:
    // if (strpos($url, 'https://www.youtube.com/') === 0) { ... }
    
    // Redirigir a la URL pasada
    header("Location: $url");
    exit;  // Asegúrate de que el script termine aquí
} else {
    // Si no se pasa la URL, mostrar un mensaje de error o redirigir a otra página
    echo "No se ha proporcionado una URL válida.";
}
?>
2