var body = {
    voice: "625jGFaa0zTLtQfxwc6Q",
    instructions: ``,
    dispositions: []
};

pm.environment.set('req_body', JSON.stringify(body));