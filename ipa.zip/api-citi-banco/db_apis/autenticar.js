const oracledb = require('oracledb');
const database = require('../services/database.js');

const baseQuery = `BEGIN DBO.XSP_AUTHCREDENCIAL_API(:uid_, :pwd,:rc); END;`;

async function find(context){
   console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.user || !context.password){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");
    //Se asignan los valores respecto a los parametros del SP
    binds.uid_ = context.user;

    // binds.pwd = context.password;
    binds.pwd = {val:context.password,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    //console.log("\n", result, "\n");
    console.log('---', result, '---');
    return result;
  }
}

module.exports.find = find;
