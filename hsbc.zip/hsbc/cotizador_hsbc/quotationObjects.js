export const objData = {
  O3: 1,
  O1: 1,
  O4: 1,
  CUSTOMER: {
  },
  HEA: {},


};


export const rates = {
  Y4: 10, // $Tarifas.Y4
  Z4: 50000, //  $Tarifas.Z4
};

export const paymentSurcharges = {
  Anual: { value: 0.00, colS: 1 },
  Mensual: { value: 0.1268, colS: 12 },
  Trimestral: { value: 0.1142, colS: 4 },
  Semestral: { value: 0.0957, colS: 2 },
  Iva: { value: 0.16 },
};

export const segmentos = {
  //! Actualmente todo esta en 0 pero cuando estos valores cambien se deben de agregar pero en formato de porcentaje ejem: 11% = 0.11
  Advance: 0,
  Premier: 0,
  Personal_Banking: 0,
  Privada: 0,
};

export const descuentos = {
  //! Actualmente todo esta en 0 pero cuando estos valores cambien se deben de agregar pero en formato de porcentaje ejem: 11% = 0.11
  Especial: 0,
  Segmento: 0,
  Empleado: 0,
  Ninguno: 0,
};



export const objFuneralExpenses = {
  0: { Male: 1.6341, Female: 1.6341 },
  1: { Male: 1.6341, Female: 1.6341 },
  2: { Male: 1.6341, Female: 1.6341 },
  3: { Male: 1.6341, Female: 1.6341 },
  4: { Male: 1.6341, Female: 1.6341 },
  5: { Male: 1.6341, Female: 1.6341 },
  6: { Male: 1.6341, Female: 1.6341 },
  7: { Male: 1.6341, Female: 1.6341 },
  8: { Male: 1.6341, Female: 1.6341 },
  9: { Male: 1.6341, Female: 1.6341 },
  10: { Male: 1.6341, Female: 1.6341 },
  11: { Male: 1.6341, Female: 1.6341 },
  12: { Male: 1.6341, Female: 1.6341 },
  13: { Male: 1.6341, Female: 1.6341 },
  14: { Male: 1.6341, Female: 1.6341 },
  15: { Male: 1.6341, Female: 1.6341 },
  16: { Male: 1.6341, Female: 1.6341 },
  17: { Male: 1.6341, Female: 1.6341 },
  18: { Male: 1.6341, Female: 1.6341 },
  19: { Male: 1.6341, Female: 1.6341 },
  20: { Male: 0.7593, Female: 0.7593 },
  21: { Male: 0.7593, Female: 0.7593 },
  22: { Male: 0.7593, Female: 0.7593 },
  23: { Male: 0.7593, Female: 0.7593 },
  24: { Male: 0.7593, Female: 0.7593 },
  25: { Male: 0.7593, Female: 0.7593 },
  26: { Male: 0.7593, Female: 0.7593 },
  27: { Male: 0.7593, Female: 0.7593 },
  28: { Male: 0.7593, Female: 0.7593 },
  29: { Male: 0.7593, Female: 0.7593 },
  30: { Male: 1.3904, Female: 1.3904 },
  31: { Male: 1.3904, Female: 1.3904 },
  32: { Male: 1.3904, Female: 1.3904 },
  33: { Male: 1.3904, Female: 1.3904 },
  34: { Male: 1.3904, Female: 1.3904 },
  35: { Male: 1.3904, Female: 1.3904 },
  36: { Male: 1.3904, Female: 1.3904 },
  37: { Male: 1.3904, Female: 1.3904 },
  38: { Male: 1.3904, Female: 1.3904 },
  39: { Male: 1.3904, Female: 1.3904 },
  40: { Male: 2.8371, Female: 2.8371 },
  41: { Male: 2.8371, Female: 2.8371 },
  42: { Male: 2.8371, Female: 2.8371 },
  43: { Male: 2.8371, Female: 2.8371 },
  44: { Male: 2.8371, Female: 2.8371 },
  45: { Male: 2.8371, Female: 2.8371 },
  46: { Male: 2.8371, Female: 2.8371 },
  47: { Male: 2.8371, Female: 2.8371 },
  48: { Male: 2.8371, Female: 2.8371 },
  49: { Male: 2.8371, Female: 2.8371 },
  50: { Male: 6.0147, Female: 6.0147 },
  51: { Male: 6.0147, Female: 6.0147 },
  52: { Male: 6.0147, Female: 6.0147 },
  53: { Male: 6.0147, Female: 6.0147 },
  54: { Male: 6.0147, Female: 6.0147 },
  55: { Male: 6.0147, Female: 6.0147 },
  56: { Male: 6.0147, Female: 6.0147 },
  57: { Male: 6.0147, Female: 6.0147 },
  58: { Male: 6.0147, Female: 6.0147 },
  59: { Male: 6.0147, Female: 6.0147 },
  60: { Male: 10.5828, Female: 10.5828 },
  61: { Male: 10.5828, Female: 10.5828 },
  62: { Male: 10.5828, Female: 10.5828 },
  63: { Male: 10.5828, Female: 10.5828 },
  64: { Male: 10.5828, Female: 10.5828 },
  65: { Male: 10.5828, Female: 10.5828 },
  66: { Male: 10.5828, Female: 10.5828 },
  67: { Male: 10.5828, Female: 10.5828 },
  68: { Male: 10.5828, Female: 10.5828 },
  69: { Male: 10.5828, Female: 10.5828 }
}


export const objRate = {

  0: { Male: 949.6805, Female: 1011.5273 },
  1: { Male: 743.3025, Female: 827.0273 },
  2: { Male: 542.3987, Female: 620.868 },
  3: { Male: 305.7785, Female: 393.3933 },
  4: { Male: 258.2232, Female: 324.6006 },
  5: { Male: 228.9058, Female: 279.4731 },
  6: { Male: 213.4988, Female: 257.9701 },
  7: { Male: 202.0099, Female: 241.6851 },
  8: { Male: 184.7844, Female: 230.5462 },
  9: { Male: 172.6456, Female: 217.8481 },
  10: { Male: 170.321, Female: 212.3271 },
  11: { Male: 170.4491, Female: 212.8239 },
  12: { Male: 176.7481, Female: 215.3516 },
  13: { Male: 165.403, Female: 194.2673 },
  14: { Male: 167.5433, Female: 206.6373 },
  15: { Male: 167.3808, Female: 224.6408 },
  16: { Male: 160.0194, Female: 245.1783 },
  17: { Male: 153.7828, Female: 277.7858 },
  18: { Male: 163.5439, Female: 324.6568 },
  19: { Male: 161.4973, Female: 348.8907 },
  20: { Male: 160.3037, Female: 363.1541 },
  21: { Male: 166.2934, Female: 376.3427 },
  22: { Male: 168.9555, Female: 381.117 },
  23: { Male: 180.2851, Female: 398.2644 },
  24: { Male: 191.3303, Female: 411.1749 },
  25: { Male: 201.4725, Female: 427.1912 },
  26: { Male: 208.1183, Female: 432.0999 },
  27: { Male: 213.7456, Female: 433.5996 },
  28: { Male: 223.6222, Female: 438.7801 },
  29: { Male: 229.412, Female: 443.8668 },
  30: { Male: 237.0733, Female: 442.6358 },
  31: { Male: 246.0001, Female: 445.2197 },
  32: { Male: 254.8362, Female: 446.2196 },
  33: { Male: 257.5139, Female: 442.2983 },
  34: { Male: 274.1083, Female: 441.1485 },
  35: { Male: 280.4229, Female: 445.9665 },
  36: { Male: 286.9063, Female: 448.3568 },
  37: { Male: 299.2888, Female: 454.7339 },
  38: { Male: 312.2681, Female: 458.3771 },
  39: { Male: 312.1837, Female: 502.0361 },
  40: { Male: 326.0473, Female: 511.9502 },
  41: { Male: 341.6793, Female: 536.8995 },
  42: { Male: 355.9927, Female: 567.6199 },
  43: { Male: 371.1779, Female: 610.4321 },
  44: { Male: 391.9747, Female: 608.5886 },
  45: { Male: 411.728, Female: 641.9429 },
  46: { Male: 435.565, Female: 657.175 },
  47: { Male: 452.3624, Female: 670.248 },
  48: { Male: 485.2262, Female: 703.3617 },
  49: { Male: 513.2563, Female: 718.9406 },
  50: { Male: 538.6524, Female: 740.806 },
  51: { Male: 562.1238, Female: 777.916 },
  52: { Male: 591.2256, Female: 792.1919 },
  53: { Male: 629.473, Female: 792.3169 },
  54: { Male: 667.1172, Female: 814.5385 },
  55: { Male: 698.0313, Female: 842.5062 },
  56: { Male: 724.9241, Female: 849.1801 },
  57: { Male: 755.935, Female: 876.1323 },
  58: { Male: 764.1493, Female: 906.8182 },
  59: { Male: 763.3463, Female: 916.7417 },
  60: { Male: 779.472, Female: 931.4801 },
  61: { Male: 788.2488, Female: 954.0361 },
  62: { Male: 795.1884, Female: 970.2617 },
  63: { Male: 827.1616, Female: 1006.1469 },
  64: { Male: 852.3922, Female: 1046.4939 },
  65: { Male: 857.5726, Female: 1087.9782 },
  66: { Male: 876.7884, Female: 1107.4971 },
  67: { Male: 885.2528, Female: 1130.6436 },
  68: { Male: 854.6949, Female: 1120.5701 },
  69: { Male: 860.8877, Female: 1075.4551 }


}


export const derechoPoliza = 150
export const medicalAssitance = 66


export const hea = {
  headers: ["HEA", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Neta Total", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Derecho Póliza", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["IVA", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Total", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima SFP", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  ]
};

export const agfu = {
  headers: ["AGFU", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Cobertura",     0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",              0, 0, 0, 0, 0, 0, 0, 0, 0, 0],    
    ["Prima Total",         0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima SFP",           0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};

export const asim = {
  headers: ["ASIM", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Asistencia",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",              0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["IVA",                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Total",         0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima SFP",           0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};


export const acsel = {
  headers: ['Titulo',"Anualizado", "Forma de pago mensual"],
  rows: [
    ["Prima Hospitalización", 0,0],
    ["Prima Funerario",  0,0],
    ["Prima Asistencia",0,0],
    ["Prima Riesgo Total",0,0],
    ["Descuento Especial",0,0],
    ["Recargos por forma de pago",0,0],
    ["Derecho Póliza",0,0],
    ["IVA",0,0],
    ["Prima Total",0,0],
    ["Primer pago",0],
    ["Último pago",0]
  ]
};
