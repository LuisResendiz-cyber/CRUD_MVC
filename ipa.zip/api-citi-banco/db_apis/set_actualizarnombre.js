const oracledb = require('oracledb');
const database = require('../services/database.js');
 

async function find(context) {
  
const baseQuery = "BEGIN "+ context.schema +".spU_NombrePersonas(:solicitud, :nombre,:apaterno,:amaterno); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};
        
        if(!context.solicitud || !context.nombre || !context.apaterno || !context.amaterno){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            
            binds.solicitud = context.solicitud;
            binds.nombre = context.nombre;
            binds.apaterno = context.apaterno;
            binds.amaterno = context.amaterno;

            const result = await database.simpleExecute(query, binds);

//             console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;