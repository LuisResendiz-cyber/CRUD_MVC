let activeSessionId = null;
let quickReplyActive = false;

const inputMessage = document.getElementById("agent-message-input");
const sendBtn = document.getElementById("agent-send-btn");

let quickReplies = [];
let filteredReplies = [];
let quickReplyIndex = 0;

sendBtn.addEventListener("click", sendAgentMessage);

const socket = io("http://localhost:4001", {
  auth: {
    type: "crm",
  },
});

socket.on("connect", () => {
  console.log("✅ Inbox conectado:", socket.id);
});

socket.emit("inbox:init");

socket.on("inbox:conversations", (conversations) => {
  renderConversationList(conversations);
});

let conversationsState = [];


socket.on("conversation_updated", (data) => {
  console.log(data);
  updateConversationInInbox(data);
});

function updateConversationInInbox(data) {
  const container = document.getElementById("conversation-list");
  const existingItem = container.querySelector(`[data-session="${data.session_uuid}"]`);

  if (existingItem) {
    existingItem.remove();
  }

  // 🔥 crear nuevo con datos actualizados
  const updatedItem = createConversationElement(data);

  // 🔥 poner arriba
  container.prepend(updatedItem);
}


console.log("🚀 Emitiendo inbox:quick_replies");

// 🔥 Cargar quick replies del bot
socket.emit("quick_replies:load", {
  id_bot: 2, // el bot activo del inbox
  channel: "web",
});

// 📥 Recibir quick replies
socket.on("quick_replies:data", (data) => {
  quickReplies = data;
  console.log("⚡ Quick replies cargadas:", quickReplies);
});

// function renderConversationList(conversations) {
//   const container = document.getElementById("conversation-list");
//   container.innerHTML = "";

//   console.log(conversations);

//   conversations.forEach((c) => {
//     const statusLabel =
//       c.status === "bot"
//         ? `<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Bot</span>`
//         : c.status === "human"
//         ? `<span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Agente</span>`
//         : `<span class="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Cerrado</span>`;

//     const item = document.createElement("div");
//     item.className = "p-4 bg-white hover:bg-gray-50 cursor-pointer";
//     item.dataset.session = c.session_uuid;

//     item.innerHTML = `
//         <div class="flex justify-between items-center">
//           <span class="font-medium text-gray-800">
//             ${c.name}
//           </span>
//           ${statusLabel}
//         </div>
//         <p class="text-sm text-gray-500 truncate">
//           ${c.last_message || "Sin mensajes"}
//         </p>
//       `;

//     item.addEventListener("click", () => {
//       openConversation(c);
//     });

//     container.appendChild(item);
//   });
// }

function renderConversationList(conversations) {
  const container = document.getElementById("conversation-list");
  container.innerHTML = "";

  conversations.forEach((c) => {
    const item = createConversationElement(c);
    container.appendChild(item);
  });
}

function getStatusLabel(status) {
  if (status === "bot") {
    return `<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Bot</span>`;
  }

  if (status === "human") {
    return `<span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Agente</span>`;
  }

  return `<span class="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Cerrado</span>`;
}


function createConversationElement(c) {
  const item = document.createElement("div");
  item.className = "p-4 bg-white hover:bg-gray-50 cursor-pointer";
  item.dataset.session = c.session_uuid;
  const statusLabel = getStatusLabel(c.status);

  item.innerHTML = `
    <div class="flex justify-between items-center">
      <span class="font-medium text-gray-800">
        ${c.name}
      </span>
      ${statusLabel}
    </div>

    <div class="flex justify-between items-center mt-1">
      <p class="text-sm text-gray-500 truncate">
        ${c.last_message || "Sin mensajes"}
      </p>

      ${
        c.unread_count > 0
          ? `<span class="ml-2 text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">
              ${c.unread_count}
            </span>`
          : ""
      }
    </div>
  `;

  item.addEventListener("click", () => {
    openConversation(c);
  });

  return item;
}


function openConversation(chat) {
  inputMessage.value = "";
  activeSessionId = chat.session_uuid;

  socket.emit("conversation:read", {
    session_uuid: chat.session_uuid
  });


  // Header
  document.getElementById("chat-user-name").textContent =
    chat.name || "Anónimo";

  document.getElementById(
    "chat-bot-status"
  ).textContent = `🤖 ${chat.bot_name} · IA activa`;

  document.getElementById("chat-status-badge").textContent = "Abierto";

  // Limpiar mensajes
  document.getElementById("chat-messages").innerHTML = "";

  // pedir historial al backend
  socket.emit("inbox:load_messages", {
    session_uuid: activeSessionId,
  });

  setTimeout(() => {
    if (inputMessage) {
      inputMessage.focus();
    }
  }, 0);
}

socket.on("inbox:messages", (messages) => {
  console.log(messages);
  messages.forEach((msg) => {
    renderMessage(msg);
  });
});

function renderMessage({ role, message_text }) {
  const container = document.getElementById("chat-messages");

  const wrapper = document.createElement("div");

  if (role === "user") {
    wrapper.className = "flex justify-start";
    wrapper.innerHTML = `
        <div class="bg-gray-200 px-4 py-2 rounded-lg max-w-md">
          ${message_text}
        </div>
      `;
  }

  if (role === "assistant") {
    wrapper.className = "flex justify-end";
    wrapper.innerHTML = `
        <div class="bg-indigo-600 text-white px-4 py-2 rounded-lg max-w-md whitespace-pre-line">
          ${message_text}
        </div>
      `;
  }

  if (role === "agent") {
    wrapper.className = "flex justify-end";
    wrapper.innerHTML = `
        <div class="bg-green-600 text-white px-4 py-2 rounded-lg max-w-md whitespace-pre-line">
          ${message_text}
        </div>
      `;
  }

  if (role === "system") {
    wrapper.className = "flex justify-center";
    wrapper.innerHTML = `
        <div class="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
          ${message_text}
        </div>
      `;
  }

  container.appendChild(wrapper);
  container.scrollTop = container.scrollHeight;
}

socket.on("chat_status_update", (data) => {
  const { session_uuid, status } = data;

  // Solo afecta si es la conversación que estoy viendo
  if (session_uuid !== activeSessionId) return;

  if (status === "closed") {
    lockChatInput();
  }

  if (status === "open") {
    unlockChatInput();
  }
});

function lockChatInput() {
  inputMessage.disabled = true;
  sendBtn.disabled = true;
}

function unlockChatInput() {
  inputMessage.disabled = false;
  sendBtn.disabled = false;
}

socket.on("new_message", (data) => {
  // Solo pintar si es la conversación abierta
  if (data.session_uuid !== activeSessionId) return;

  addChatMessage(data);
});

function addChatMessage({ role, message_text }) {
  const container = document.getElementById("chat-messages");

  // 🟡 MENSAJES DE SISTEMA
  if (role === "system") {
    const wrapper = document.createElement("div");
    wrapper.className = "flex justify-center";

    wrapper.innerHTML = `
    <div class="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
      ${message_text}
    </div>
  `;

    container.appendChild(wrapper);
    container.scrollTop = container.scrollHeight;
    return;
  }

  // 🟢 MENSAJES NORMALES
  const wrapper = document.createElement("div");
  wrapper.className =
    role === "user" ? "flex justify-start" : "flex justify-end";

  const bubble = document.createElement("div");

  if (role === "user") {
    bubble.className = "bg-gray-200 px-4 py-2 rounded-lg max-w-md";
  } else if (role === "assistant") {
    bubble.className = "bg-indigo-600 text-white px-4 py-2 rounded-lg max-w-md";
  } else if (role === "agent") {
    bubble.className = "bg-green-600 text-white px-4 py-2 rounded-lg max-w-md";
  }

  bubble.textContent = message_text;

  wrapper.appendChild(bubble);
  container.appendChild(wrapper);
  container.scrollTop = container.scrollHeight;
}

// function addChatMessage({ role, message_text }) {
//   const container = document.getElementById("chat-messages");

//   const wrapper = document.createElement("div");
//   wrapper.className =
//     role === "user" ? "flex justify-start" : "flex justify-end";

//   const bubble = document.createElement("div");
//   bubble.className =
//     role === "user"
//       ? "bg-gray-200 px-4 py-2 rounded-lg max-w-md"
//       : role === "assistant"
//       ? "bg-indigo-600 text-white px-4 py-2 rounded-lg max-w-md"
//       : "bg-green-600 text-white px-4 py-2 rounded-lg max-w-md";

//   bubble.textContent = message_text;

//   wrapper.appendChild(bubble);
//   container.appendChild(wrapper);
//   container.scrollTop = container.scrollHeight;
// }

inputMessage.addEventListener("keydown", (e) => {
  // 🔑 ENTER
  if (e.key === "Enter") {
    // 🟢 CASO A: quick replies abiertas
    if (quickReplyActive) {
      e.preventDefault();
      e.stopPropagation();

      applySelectedQuickReply();
      return;
    }

    // 🔵 CASO B: envío normal
    e.preventDefault();
    sendAgentMessage();
  }
});

function applySelectedQuickReply() {
  const selected = document.querySelector(".quick-reply.selected");
  if (!selected) return;

  inputMessage.value = selected.dataset.text;
  inputMessage.focus();

  hideQuickReplies();
  quickReplyActive = false;
}

function sendAgentMessage() {
  const text = inputMessage.value.trim();

  if (!text) return;
  if (!activeSessionId) return;

  socket.emit("agent_message", {
    session_uuid: activeSessionId,
    agent_id: 1,
    message: text,
  });

  inputMessage.value = "";
}

document.getElementById("btnReturnBot").addEventListener("click", () => {
  console.log("voy aqui");
  console.log(activeSessionId);
  if (!activeSessionId) return;

  socket.emit("return_to_bot", {
    session_uuid: activeSessionId,
  });
});

inputMessage.addEventListener("input", () => {
  const value = inputMessage.value;

  if (!value.startsWith("/")) {
    hideQuickReplies();
    return;
  }

  const search = value.slice(1).toLowerCase();

  filteredReplies = quickReplies.filter(
    (q) =>
      q.shortcut.toLowerCase().includes(search) ||
      q.title.toLowerCase().includes(search)
  );

  quickReplyIndex = 0;
  renderQuickReplies(filteredReplies);
});

function renderQuickReplies(list) {
  quickReplyActive = true;

  const container = document.getElementById("quick-replies");
  container.innerHTML = "";

  if (!list.length) {
    container.classList.add("hidden");
    return;
  }

  list.forEach((q, i) => {
    const item = document.createElement("div");
    item.className = `
        px-4 py-2 cursor-pointer
        ${i === quickReplyIndex ? "bg-indigo-100" : "hover:bg-gray-100"}
      `;
    item.innerHTML = `
        <div class="font-medium">/${q.shortcut}</div>
        <div class="text-sm text-gray-500">${q.title}</div>
      `;

    item.onclick = () => applyQuickReply(q);
    container.appendChild(item);
  });

  container.classList.remove("hidden");
}

function applyQuickReply(q) {
  inputMessage.value = q.message_text;
  hideQuickReplies();
  inputMessage.focus();
}

function hideQuickReplies() {
  quickReplyActive = false;
  document.getElementById("quick-replies").classList.add("hidden");
}

inputMessage.addEventListener("keydown", (e) => {
  console.log(e.keyCode);
  const container = document.getElementById("quick-replies");
  if (container.classList.contains("hidden")) return;

  if (e.key === "ArrowDown") {
    quickReplyIndex = (quickReplyIndex + 1) % filteredReplies.length;
    renderQuickReplies(filteredReplies);
    e.preventDefault();
  }

  if (e.key === "ArrowUp") {
    quickReplyIndex =
      (quickReplyIndex - 1 + filteredReplies.length) % filteredReplies.length;
    renderQuickReplies(filteredReplies);
    e.preventDefault();
  }

  if (e.key === "Enter") {
    applyQuickReply(filteredReplies[quickReplyIndex]);
    e.preventDefault();
  }

  if (e.key === "Escape") {
    hideQuickReplies();
  }
});
