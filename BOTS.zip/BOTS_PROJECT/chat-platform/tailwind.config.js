/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    // PHP (frontend real)
    "../BOTS_PLATFORM/**/*.php",

    // HTML / JS si usas algo ahí
    "../BOTS_PLATFORM/**/*.html",
    "../BOTS_PLATFORM/**/*.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
