<?php

class ApiModel
{
  private \GuzzleHttp\Client $client;

  public function __construct(\GuzzleHttp\Client $client)
  {
    $this->client = $client;
  }

  public function fetchDataGet($urlApi): ?array
  {
    try {
      $response = $this->client->request('GET', $urlApi, [
        'verify' => false,
        'headers' => [
          'Accept' => 'application/json',
        ],
        'curl' => [
          CURLOPT_PORT => 4001,
        ]
      ]);
      
      return json_decode($response->getBody(), true);

    } catch (\GuzzleHttp\Exception\ConnectException $e) {      
      echo "Error de conexión: " . $e->getMessage() . "\n";
      echo "Host: " . $e->getRequest()->getUri() . "\n";

      //! Notificar errores
      $content = "Error de conexion: " . $e->getMessage();
      $this->report_errors($content);



      return null;
    } catch (\GuzzleHttp\Exception\RequestException $e) {
      // Captura otros errores de solicitud
      echo "Request URI: " . $e->getRequest()->getUri() . "\n";
      if ($e->hasResponse()) {
        echo "Response: " . $e->getResponse()->getBody();
      }
      return null;
    } catch (\Exception $e) {
      // Captura cualquier otro tipo de excepción
      echo "Error general: " . $e->getMessage() . "\n";
      return null;
    }
  }
  public function fetchDataPost($urlApi, $data): ?array
  {
    try {
      $response = $this->client->request(
        'POST',
        $urlApi,
        [
          'verify' => false,
          'headers' => [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
          ],
          'timeout' => 60,
          'curl' => [
            CURLOPT_PORT => 4001,
          ],
          'json' => $data
        ]
      );

      return json_decode($response->getBody(), true);
    } catch (\GuzzleHttp\Exception\RequestException $e) {
      echo "Request URI: " . $e->getRequest()->getUri() . "\n";
      if ($e->hasResponse()) {
        echo "Response: " . $e->getResponse()->getBody();
      }
      return null;
    }
  }






  public function report_errors($content): ?array
  {
    $urlApi =$_ENV['API_REPORT_URL'] . 'sendMail';

    $data = [
      'email' => "dtrejo@impulse-telecom.com",
      'subject' => "Proceso Bot banamex",
      'content' => $content
    ];

    try {
      $response = $this->client->request(
        'GET', 
        $urlApi,
        [
        'verify' => false,
        'headers' => [
          'Accept' => 'application/json',
          'Content-Type' => 'application/json',
        ],
        // 'curl' => [
        //   CURLOPT_PORT => 3009,
        // ],
        'json' => $data
      ]);
      return json_decode($response->getBody(), true);
    } catch (\GuzzleHttp\Exception\ConnectException $e) {      
      echo "Error de conexión: " . $e->getMessage() . "\n";
      echo "Host: " . $e->getRequest()->getUri() . "\n";
      return null;
    } catch (\GuzzleHttp\Exception\RequestException $e) {
      // Captura otros errores de solicitud
      echo "Request URI: " . $e->getRequest()->getUri() . "\n";
      if ($e->hasResponse()) {
        echo "Response: " . $e->getResponse()->getBody();
      }
      return null;
    } catch (\Exception $e) {
      // Captura cualquier otro tipo de excepción
      echo "Error general: " . $e->getMessage() . "\n";
      return null;
    }
  }
}
