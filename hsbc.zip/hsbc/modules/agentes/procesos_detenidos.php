<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Solicitud");

layout_menu($db, "");

$user = get_session_varname('s_usr_id');

$registros = get_procesos_detenidos($user, $db);
?>
<p class="textbold">Agentes &gt; Procesos Detenidos</p>
<p>&nbsp;</p>
<?
rs2html($registros);
layout_footer();
?>