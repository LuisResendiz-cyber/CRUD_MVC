const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN "+ context.schema +".sps_productos_ofertados(:V_CUSTOMERID, :rc); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.V_CUSTOMERID){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
          
      			binds.V_CUSTOMERID = context.V_CUSTOMERID;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};


            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;