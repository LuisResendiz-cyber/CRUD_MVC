const db = require("../db/mysql");

const CustomersModel = {
  async insertWebhookLog({ event_type, wamid = null, from_number = 0, status  = null, message_text  = null, role= "user", id_envio = 0, raw_json = null}) {
    const sql = `INSERT INTO BOTS_CONVERSATION_LOG (event_type, wamid, from_number, status, message_text, role, conversation_id, raw_json)VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

    await db.query(sql, [
      String(event_type).substring(0, 20),
      wamid || null,
      from_number || null,
      status || null,
      message_text || null,
      role || null,
      id_envio || null,
      JSON.stringify(raw_json)
    ]);
  },
  async getOrCreateSession(conversationId, channel = "web") {
    // 1️⃣ Buscar sesión existente
    const [rows] = await db.query(
      `
      SELECT *
      FROM CHAT_SESSIONS
      WHERE session_uuid = ?
      LIMIT 1
      `,
      [conversationId]
    );
  
    if (rows.length > 0) {
      // 2️⃣ Actualizar última actividad
      await db.query(
        `
        UPDATE CHAT_SESSIONS
        SET last_activity = NOW()
        WHERE session_uuid = ?
        `,
        [conversationId]
      );
  
      return rows[0];
    }
  
    // 3️⃣ Crear nueva sesión
    const [result] = await db.query(
      `
      INSERT INTO CHAT_SESSIONS
        (client_id,session_uuid, channel, status, id_bot)
      VALUES (4, ?, ?, 'bot', 1)
      `,
      [conversationId, channel]
    );
  
    // 4️⃣ Devolver la sesión creada
    const [newSession] = await db.query(
      `
      SELECT *
      FROM CHAT_SESSIONS
      WHERE id = ?
      `,
      [result.insertId]
    );
  
    return newSession[0];
  },
  async getSessionByUUID(session_uuid) {
    const [rows] = await db.query(
      `SELECT 
          session_uuid,
          customer_name,
          status,
          last_message,
          customer_name as name,
          unread_count,
          last_activity
       FROM CHAT_SESSIONS
       WHERE session_uuid = ?`,
      [session_uuid]
    );
  
    return rows[0];
  },
  async resetUnread(session_uuid) {
    await db.query(
      `UPDATE CHAT_SESSIONS 
       SET unread_count = 0 
       WHERE session_uuid = ?`,
      [session_uuid]
    );
  },  
  async updateSessionAfterMessage(session_uuid, {
    last_message,
    last_message_role,
    incrementUnread = false
  }) {  
    let query = `
      UPDATE CHAT_SESSIONS
      SET last_message = ?,
          last_message_role = ?,
          last_activity = NOW()
    `;
  
    const params = [last_message, last_message_role];
  
    if (incrementUnread) {
      query += `, unread_count = unread_count + 1`;
    }
  
    query += ` WHERE session_uuid = ?`;
  
    params.push(session_uuid);
  
    await db.query(query, params);
  },  
  async getHistory(conversation_id){
    const [rows] = await db.query(
      `SELECT id_webhook, role, message_text
       FROM BOTS_CONVERSATION_LOG
       WHERE conversation_id = ?
         AND channel = 'web'
       ORDER BY created_at ASC`,
      [conversation_id]
    );

    if (rows.length) return rows;
  },
  async getConversationById(conversation_id) {
    const [rows] = await db.query(
      `SELECT *
       FROM BOTS_CONVERSATION_LOG
       WHERE conversation_id = ?`,
      [conversation_id]
    );
    return rows[0];
  },
  async switchSessionToHuman(sessionUuid) {
    const sql = `
      UPDATE CHAT_SESSIONS
      SET status = 'human',
          last_activity = NOW()
      WHERE session_uuid = ?
        AND status = 'bot'
    `;
  
    await db.execute(sql, [sessionUuid]);
  },
  async setSessionHuman({ session_uuid, agent_id }) {
    const sql = `
      UPDATE CHAT_SESSIONS
      SET status = 'human',
          assigned_agent_id = ?,
          last_activity = NOW()
      WHERE session_uuid = ?
    `;
    await db.query(sql, [agent_id, session_uuid]);
  },
  async setSessionBot(session_uuid) {
    return db.query(`
      UPDATE CHAT_SESSIONS
      SET status = 'bot',
          assigned_agent_id = NULL,
          last_activity = NOW()
      WHERE session_uuid = ?
    `, [session_uuid]);
  },
  async getNewMessages(conversation_id, last_id) {
    const sql = `
      SELECT id_webhook, message_text, role, created_at
      FROM BOTS_CONVERSATION_LOG
      WHERE conversation_id = ?
        AND id_webhook > ?
      ORDER BY id_webhook ASC
    `;
    const [rows] = await db.query(sql, [conversation_id, last_id]);
    return rows;
  },
  async closeSession(session_uuid) {
    return db.query(`
      UPDATE CHAT_SESSIONS
      SET status = 'closed', last_activity = NOW()
      WHERE session_uuid = ?
    `, [session_uuid]);
  },
  async reopenSession(session_uuid) {
    return db.query(`
      UPDATE CHAT_SESSIONS
      SET status = 'bot', last_activity = NOW()
      WHERE session_uuid = ?
    `, [session_uuid]);
  },
  async getConversations(option, session_id) {
    console.log(option, session_id);

    try {
      const [rows] = await db.query('CALL sp_inbox_crud(?,?)', [option, session_id]);           
        return rows[0];  
    } catch (error) {
      console.error('Error en User CRUD:', error);
      throw error;
    }
  },
  async getQuickReplies(option, id_bot, channel = "web") {

    try {
      const [rows] = await db.query('CALL sp_quick_replies_crud(?, ?, ?)', [option, id_bot, channel]);           
      return rows[0];  
    } catch (error) {
      console.error('Error en User CRUD:', error);
      throw error;
    }
  }
  
  
  

};

module.exports = CustomersModel;
