import * as Yup from "yup";
import { AnySchema } from "yup";

export const ValSignIn = Yup.object().shape({
  USERNAME: Yup.string()
    .required("username is required")
    .min(6, "username must contain 6 characters"),
  PASSWORD: Yup.string()
    .required("password is required")
    .min(8, "password must contain 8 characters"),
});

export const ValUpdateSurvey = Yup.object().shape({
  ID_SURVEY: Yup.string().required("ID_SURVEY is required"),
  STATUS_SURVEY: Yup.number().required("password is required").integer(),
});

export const validate =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate(req.body, { abortEarly: false });
      next();
    } catch (err: any) {
      res.status(400).json({ errors: err.errors });
    }
  };

export const validateSurvey =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate({
        params: req.params,
        body: req.body,
      });

      next();
    } catch (err: any) {
      return res.status(400).json({ type: err.name, message: err.message });
    }
  };

export const ValSurvey = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMER_ID: Yup.string().required("The CUSTOMERID field is required.").max(100),
    NOMBRE: Yup.string().required("El campo NOMBRE es obligatorio."),
    AP_PATERNO: Yup.string().required("El campo AP_PATERNO es obligatorio."),
    AP_MATERNO: Yup.string().required("El campo AP_MATERNO es obligatorio."),
    FECHA_NACIMIENTO: Yup.string()
    .required("El campo FECHA_NACIMIENTO es obligatorio.")
    .matches(
      /^\d{4}-\d{2}-\d{2}$/,
      "El campo FECHA_NACIMIENTO debe de ser en formato YYYY-MM-DD."
    ),
    RFC: Yup.string().required("El campo RFC es obligatorio.").max(13),
    INGRESOS_FIJOS_COMPROBABLES: Yup.string().required("El campo INGRESOS_FIJOS_COMPROBABLES es obligatorio."),
    NACIONALIDAD: Yup.string().required("El campo NACIONALIDAD es obligatorio."),
    PAIS_ORIGEN: Yup.string().required("El campo PAIS_ORIGEN es obligatorio."),
    SEXO: Yup.string().required("El campo SEXO es obligatorio."),
    ESTADO_NACIMIENTO: Yup.string().required("El campo ESTADO_NACIMIENTO es obligatorio."),
    ESTADO_ALTERNO_NACIMIENTO: Yup.string().required("El campo ESTADO_ALTERNO_NACIMIENTO es obligatorio."),
    TIPO_ID: Yup.string().required("El campo TIPO_ID es obligatorio."),
    NUMERO_ID: Yup.string().required("El campo NUMERO_ID es obligatorio."),
    ANTIGUEDAD_VIVIENDA_ANIOS: Yup.string().required("El campo ANTIGUEDAD_VIVIENDA_ANIOS es obligatorio."),
    ANTIGUEDAD_VIVIENDA_MESES: Yup.string().required("El campo ANTIGUEDAD_VIVIENDA_MESES es obligatorio."),
    CALLE: Yup.string().required("El campo CALLE es obligatorio."),
    NUMERO_EXTERIOR: Yup.string().required("El campo NUMERO_EXTERIOR es obligatorio."),
    NUMERO_INTERIOR: Yup.string().required("El campo NUMERO_INTERIOR es obligatorio."),
    CP: Yup.string().required("El campo CP es obligatorio.").max(10, "El rfc no puede exceder de 10 digitos"),
    COLONIA: Yup.string().required("El campo COLONIA es obligatorio."),
    MUNICIPIO: Yup.string().required("El campo MUNICIPIO es obligatorio."),
    ESTADO: Yup.string().required("El campo ESTADO es obligatorio."),
    LADA: Yup.string().required("El campo LADA es obligatorio."),
    TELEFONO: Yup.string().required("El campo TELEFONO es obligatorio."),
    TELEFONO_CELULAR: Yup.string().required("El campo TELEFONO_CELULAR es obligatorio.").matches(/^[0-9]+$/, "Telefono debe de contener solo digitos.").min(10, "El número de teléfono debe tener al menos 10 dígitos.").max(10, "El numero no puede exceder de 10 digitos"),
    CORREO_ELECTRONICO: Yup.string().required("El campo CORREO_ELECTRONICO es obligatorio."),
    TIPO_VIVIENDA: Yup.string().required("El campo TIPO_VIVIENDA es obligatorio."),
    TRABAJADOR_INDEPENDIENTE: Yup.string().required("El campo TRABAJADOR_INDEPENDIENTE es obligatorio."),
    STATUS_LABORAL: Yup.string().required("El campo STATUS_LABORAL es obligatorio."),
    TIPO_INDUSTRIA: Yup.string().required("El campo TIPO_INDUSTRIA es obligatorio."),
    OCUPACION: Yup.string().required("El campo OCUPACION es obligatorio."),
    ANTIGUEDAD_EMPRESA_ANIOS: Yup.string().required("El campo ANTIGUEDAD_EMPRESA_ANIOS es obligatorio."),
    ANTIGUEDAD_EMPRESA_MESES: Yup.string().required("El campo ANTIGUEDAD_EMPRESA_MESES es obligatorio."),
    NOMBRE_EMPRESA: Yup.string().required("El campo NOMBRE_EMPRESA es obligatorio."),
    LADA_OFICINA: Yup.string().required("El campo LADA_OFICINA es obligatorio."),
    TELEFONO_OFICINA: Yup.string().required("El campo TELEFONO_OFICINA es obligatorio."),
    BANCO_REF_1: Yup.string().required("El campo BANCO_REF_1 es obligatorio."),
    DIGITOS_TDC: Yup.string().required("El campo DIGITOS_TDC es obligatorio."),
    CREDITO_HIPOTECARIO: Yup.string().required("El campo CREDITO_HIPOTECARIO es obligatorio."),
    CREDITO_AUTO: Yup.string().required("El campo CREDITO_AUTO es obligatorio."),
    TITULAR_TDC: Yup.string().required("El campo TITULAR_TDC es obligatorio."),
    TYPIFICATIONID: Yup.string().required("El campo TYPIFICATIONID es obligatorio."),      
  }),
});


export const ValSurveyNoSale = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .matches(/^[0-9]+$/, "The CUSTOMERID must be a numeric value.")
      .max(100),
    ID_PHONE: Yup.string()
      .required("The ID_PHONE field is required.")
      .matches(/^[0-9]+$/, "The ID_PHONE must be a numeric value.")
      .max(20),
    TYPIFICATIONID: Yup.string()
      .required("The TYPIFICATIONID field is required.")
      .matches(/^[0-9]+$/, "The TYPIFICATIONID must be a numeric value.")
      .max(100),
  }),
});


export const ValCustomerInformation = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .max(100)
  }),
});
