const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".xsp_isSolicitudOK(:id_solicitud, :res); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.id_solicitud || !context.res){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    binds.id_solicitud     = context.id_solicitud;
    binds.res     = {var: context.res, dir: oracledb.BIND_INOUT, type: oracledb.DB_TYPE_NUMBER};

    const result = await database.simpleExecute(query, binds);
    // console.log(result); 
    return result;

  }
}
 
module.exports.find = find;