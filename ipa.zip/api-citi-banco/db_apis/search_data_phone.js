const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context){
  // console.log('***** llamando procedimiento SPS_DATA_TELEFONO *****');
  // console.log(context);
  const baseQuery = "BEGIN CITI.SPS_DATA_TELEFONO(:case_, :nombre, :ap_paterno, :ap_materno, :telefono, :fecha_inicio, :fecha_fin, :rc); END;";
  // const baseQuery = "BEGIN CITI.SPS_DATA_TELEFONO(:case_, :nombre, :ap_paterno, :ap_materno, :telefono, :keys, :fecha_inicio, :fecha_fin, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(context.schema=='' || context.case_=='' || context.keys){
    // if(context.schema=='' || context.case_=='' || context.keys){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    let array_data = [];
    for(const data of context.keyrig){
      binds.case_ = context.case_;
      binds.nombre = context.nombre;
      binds.ap_paterno = context.ap_paterno;
      binds.ap_materno = context.ap_materno;
      binds.telefono = context.telefono;
      // binds.keys = data[0];
      binds.fecha_inicio = data[1].substring(0,10);
      binds.fecha_fin = data[2].substring(0,10);
      // console.log(data[0]);
      // console.log(data[1].substring(0,10));
      // console.log(data[2].substring(0,10));
      binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

      const result = await database.simpleExecuteRC(query, binds);
      // console.log('result query INICIO');
      // console.log(result);
      // console.log('result query FIN');
      array_data.push([result]);
    }

  	return array_data;
  }
}

module.exports.find = find;