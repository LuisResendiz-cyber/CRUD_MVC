import path from "path";
import { fileURLToPath } from "url";
import { existsSync,mkdir,rm } from "fs";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const publicFolderPath = path.join(
  __dirname,
  "..",
  "..",
  "src/public/backLeads"
);

export const hiWord = (req,res) => {
  res.render('index');
}


export const cleanCsvFiles = async () => {
  if (existsSync(publicFolderPath)) {
    console.log("Carpeta existe");

    // Eliminar la carpeta (recursivamente)
    rm(publicFolderPath, { recursive: true, force: true }, (err) => {
      if (err) {
        console.error("Error al eliminar la carpeta:", err);
      } else {
        console.log("Carpeta eliminada con exito.");
        createDirectory();
      }
    });
  } else {
    console.log("No existe la carpeta");
    createDirectory();
  }
};

// Función para crear la carpeta
const createDirectory = () => {
  mkdir(publicFolderPath, { recursive: true }, (err) => {
      if (err) {
          console.error('Error al crear la carpeta:', err);
      } else {
          console.log('Carpeta creada con exito.');
      }
  });
};