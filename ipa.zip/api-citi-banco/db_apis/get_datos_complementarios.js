const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

// const baseQuery = "BEGIN " + context.schema + ".CSP_GETDATOSSOLICITUD_WS(:id_solicitud, :rc, :key); END;";
const baseQuery = "BEGIN " + context.schema + ".CSP_GETDATOSSOLICITUD_WS(:id_solicitud, :rc); END;";
  console.log(context);
	let query = baseQuery;
	const binds = {};
  let result2 = {};

  // if(!context.id_solicitud || !context.key){
  if(!context.id_solicitud){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.id_solicitud = context.id_solicitud;
    binds.rc = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR};
    // binds.key      = context.keyrig[0][0];

    const result = await database.simpleExecuteRC(query, binds);
    console.log(binds);
    console.log('///', result, '////');

    return result;
  }
}

module.exports.find = find;
