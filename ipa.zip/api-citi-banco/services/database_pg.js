const {Pool} = require('pg'); 
const dbConfig = require('../config/database_pg.js');
// const pool = new Pool(dbConfig.objConfiguracion)
module.exports = new Pool(dbConfig.objConfiguracion);
// module.exports = pool
/* 
module.exports = {
    conn :  async ()=>{
        return await pool.connect();
    }
} */

/*;(async function() {
    const client = await pool.connect();
    module.exports = client;
  })()*/