const express = require('express');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');
const https = require('https');

//require('expose-gc');////

//global.gc();////

const router = new express.Router();
const app = express();

const tokenConfig = require('../config/confingToke.js');
//--------------------------------------------------------------//
//----------------------    TOKEN   ----------------------------//
//--------------------------------------------------------------//

const Ctr_usuarios = require('../controllers/usuarios_tokens.js');

const VerificarToken = express.Router();
const payload = {check:  true, jwtid : '' };
const v_expiresIn = 43200;
//Define la llave
app.set('llave', tokenConfig.llave);

//async function actulizarToken(v_usuario_id,token,uid){
//  let t2 = await Ctr_usuarios.insertarUsuario(v_usuario_id,token,uid).catch(async function(req,res){
//    //console.log("entro 3");
//    t = await Ctr_usuarios.updateUsuario(v_usuario_id,token,uid);
//    return Ctr_usuarios.obtenerToken(v_usuario_id);
//  });
//  return t2;
//};

function actulizarToken(v_usuario_id,token,uid){
  return new Promise((resolve,reject) =>{
    Ctr_usuarios.insertarUsuario(v_usuario_id,token,uid).catch(async function(req,res){
      console.log("entro 3");
      t = Ctr_usuarios.updateUsuario(v_usuario_id,token,uid);
      t2 = Ctr_usuarios.obtenerToken(v_usuario_id);
      resolve(t2);
    });
  });
};

VerificarToken.use((req, res, next) => {
  let token = req.headers['access-token'];
  let uid = req.headers['uid'];
  const v_usr_id = parseInt(req.headers['s_usr_id']);
  //console.log(req.headers);
  if (token) {
    jwt.verify(token, app.get('llave'), async (err, decoded) => {
      if (err) {

        const token_base = await Ctr_usuarios.obtenerToken(v_usr_id);
        if(token_base.uid == uid){    //token == token
          token = jwt.sign(payload, app.get('llave'), {
            expiresIn: v_expiresIn
          });

          Ctr_usuarios.updateUsuario(v_usr_id,token,token_base.uid);
          res.status(205).json({ token:token});
          res.end();
        }else{
          res.status(300).json({ msg:"Datos de Autenticacion Erroneos" });
        }

      } else {
        req.decoded = decoded;
        next();
      }
    });
  } else {
    res.send({
      mensaje: 'Token no proveída.'
    });
    res.end();
  }
});


// TEST LISTENING API
router.get('/test', (req, res) => {
  console.log("rspta: peticion test exitosa")
  res.json({ rspta: "peticion test exitosa" });
});


//--------------------------------------------------------------//
//----------------------    SESSION.INC   ----------------------//
//--------------------------------------------------------------//


/*const set_session_usuario = require('../controllers/set_session_usuario.js');//-----OK
router.route('/set_session_usuario').post([VerificarToken,set_session_usuario.post]);*/

const set_session_usuario = require('../controllers/set_session_usuario.js');//-----OK
router.route('/set_session_usuario').post(async function(req,res){
  const r = await Ctr_usuarios.cleanUsuario(req.body.p_id_user);
  res.json({result:true});
});

const set_traking = require('../controllers/set_traking.js');//-----OK
router.route('/set_traking').post([VerificarToken,set_traking.post]);

//const set_traking_ = require('../controllers/set_traking_.js');//-----OK
//router.route('/set_traking_').post([VerificarToken,set_traking_.post]);

//const set_traking_aviso = require('../controllers/set_traking_aviso.js');//-----OK
//router.route('/set_traking_aviso').post([VerificarToken,set_traking_aviso.post]);

const get_agente_info_ini = require('../controllers/get_agente_info_ini.js');//-----OK
router.route('/get_agente_info_ini').post([VerificarToken,get_agente_info_ini.post]);

const get_agente_info = require('../controllers/get_agente_info.js');//-----OK
router.route('/get_agente_info').post([VerificarToken,get_agente_info.post]);

const gesp = require('../controllers/get_EsPredictivo.js'); //-----OK
router.route('/get_EsPredictivo').post(gesp.post);
router.route('/get_EsPredictivos').get(gesp.post);

const gprou = require('../controllers/get_profile_user.js'); //-----OK
router.route('/get_profile_user').post([VerificarToken,gprou.post]);

const gusb = require('../controllers/get_user_base.js'); //-----OK
router.route('/get_user_base').post([VerificarToken,gusb.post]);

const autenticar = require('../controllers/autenticar.js');//-----OK


router.route('/autenticar').post(async function (req, res){
  const uid = req.body.uid;
  console.log(uid);

  if(!parseInt(uid)){//valida que el dato sea numerico
    res.status(404).json({V_RESULTADO:19});
  }
  if(!(String(uid).length == 19 || String(uid).length == 20)){
    res.status(404).json({V_RESULTADO:20});
  }

  let data = await autenticar.post(req);
   console.log('aqui');
   const data_mysql = await Ctr_usuarios.obtenerToken(data[0].USUARIO_ID);
  // console.log(data_mysql);

  if(data_mysql.length == 0){
    if(data[0].V_RESULTADO == 0 || data[0].V_RESULTADO == 5 || data[0].V_RESULTADO == 6 || data[0].V_RESULTADO == 12){
      console.log("Proceso Normal: "+data_mysql);
      const token = jwt.sign(payload, app.get('llave'), {
        expiresIn: v_expiresIn
      });
      console.log('token: '+token);
      try {
        const e = await actulizarToken(data[0].USUARIO_ID,token,uid);
        } catch (error) {
            console.log("err", error);

          }
        data[0].token = token;

    }
  }else{
    jwt.verify(data_mysql.token, app.get('llave'), async (err, decoded) => {
      if (err) {
        if( (data[0].V_RESULTADO == 0 || data[0].V_RESULTADO == 5 || data[0].V_RESULTADO == 6 || data[0].V_RESULTADO == 12) && (parseInt(uid) == parseInt(data_mysql.uid)) ){
          console.log("Token Vencio, genera otro y actualiza");
          const token = jwt.sign(payload, app.get('llave'), {
            expiresIn: v_expiresIn
          });
          console.log("token", token);
          try {
            const e = await actulizarToken(data[0].USUARIO_ID,token,uid);
            console.log("e", e);

          } catch (error) {
            console.log("err", error);

          }
          data[0].token = token;
          console.log("Usuarios Logueado", data);
        }else{
          data[0].V_RESULTADO = 18;
        }
      } else {//si es valido
        // console.log("Token Valida");
        if(parseInt(uid) == parseInt(data_mysql.uid) ){
          // console.log("Uid igual,");
          if(data[0].V_RESULTADO == 0 || data[0].V_RESULTADO == 5 || data[0].V_RESULTADO == 6 || data[0].V_RESULTADO == 12){
            // console.log("Usuarios Logueado");
            data[0].token = data_mysql.token;
          }
        }else{
          // console.log("Uid Invalido, Cambia el V_RESULTADO 18");
          data[0].V_RESULTADO = 18;
        }
      }
    });
  }
  //console.log(data);
  res.json(data);
});

const addAttempts = require('../controllers/addAttempts.js');//-----OK
router.route('/addAttempts').post(addAttempts.post);

const get_PuedeReferido = require('../controllers/get_PuedeReferido.js');//-----OK
router.route('/get_PuedeReferido').post([VerificarToken,get_PuedeReferido.post]);

const set_evento_registro = require('../controllers/set_evento_registro.js');//-----OK
router.route('/set_evento_registro').post([VerificarToken,set_evento_registro.post]);

//const update_evento_registro = require('../controllers/update_evento_registro.js');//-----OK
//router.route('/update_evento_registro').post([VerificarToken,update_evento_registro.post]);

const update_evento_registro2 = require('../controllers/update_evento_registro2.js');//-----OK
router.route('/update_evento_registro2').post([VerificarToken,update_evento_registro2.post]);

const set_preavail = require('../controllers/set_preavail.js');//-----OK
router.route('/set_preavail').post([VerificarToken,set_preavail.post]);

const goa = require('../controllers/get_occ_agente.js'); //-----OK
router.route('/get_occ_agente').post([VerificarToken,goa.post]);

const gtlla = require('../controllers/get_time_llamada_agente.js'); //-----OK
router.route('/get_time_llamada_agente').post([VerificarToken,gtlla.post]);

const saut = require('../controllers/set_autorizacion.js'); //-----OK
router.route('/set_autorizacion').post(saut.post);



//--------------------------------------------------------------//
//----------------------    AGENTES.INC   ----------------------//
//--------------------------------------------------------------//

const get_preavail = require('../controllers/get_preavail.js');//-----OK
router.route('/get_preavail').post([VerificarToken,get_preavail.post]);

const get_PreAvail_Telefono = require('../controllers/get_PreAvail_Telefono.js');//-----OK
router.route('/get_PreAvail_Telefono').post([VerificarToken,get_PreAvail_Telefono.post]);

const get_PreAvail_Grabacion = require('../controllers/get_PreAvail_Grabacion.js');//-----OK
router.route('/get_PreAvail_Grabacion').post([VerificarToken,get_PreAvail_Grabacion.post]);

const get_registro_especifico_pred = require('../controllers/get_registro_especifico_pred.js');//-----OK
router.route('/get_registro_especifico_pred').post([VerificarToken,get_registro_especifico_pred.post]);

const get_registro_especifico_vici_dial = require('../controllers/get_registro_especifico_vici_dial.js');//-----OK
router.route('/get_registro_especifico_vici_dial').post([VerificarToken,get_registro_especifico_vici_dial.post]);

const get_notas = require('../controllers/get_notas.js');//-----OK
router.route('/get_notas').post([VerificarToken,get_notas.post]);

const set_notas = require('../controllers/set_notas.js');//-----OK
router.route('/set_notas').post([VerificarToken,set_notas.post]);

const log_clearmeetme = require('../controllers/log_clearmeetme.js');//-----OK
router.route('/log_clearmeetme').post([VerificarToken,log_clearmeetme.post]);

const get_registro_solicitud = require('../controllers/get_registro_solicitud.js');//-----OK
router.route('/get_registro_solicitud').post([VerificarToken,get_registro_solicitud.post]);

const get_cal_NC = require('../controllers/get_cal_NC.js');//-----OK
router.route('/get_cal_NC').post([VerificarToken,get_cal_NC.post]);

const get_cal_NC_SN = require('../controllers/get_cal_NC_SN.js');//-----OK
router.route('/get_cal_NC_SN').post([VerificarToken,get_cal_NC_SN.post]);

const get_cal_SC = require('../controllers/get_cal_SC.js');//-----OK
router.route('/get_cal_SC').post([VerificarToken,get_cal_SC.post]);

const set_califica_telefono = require('../controllers/set_califica_telefono.js');//-----OK
router.route('/set_califica_telefono').post([VerificarToken,set_califica_telefono.post]);

const set_estatus_registro = require('../controllers/set_estatus_registro.js');//-----OK
router.route('/set_estatus_registro').post([VerificarToken,set_estatus_registro.post]);

const set_estatus_registro_normal = require('../controllers/set_estatus_registro_normal.js');//-----OK
router.route('/set_estatus_registro_normal').post([VerificarToken,set_estatus_registro_normal.post]);

const get_registro_especifico = require('../controllers/get_registro_especifico.js');//-----OK
router.route('/get_registro_especifico').post([VerificarToken,get_registro_especifico.post]);

const get_cuestionario = require('../controllers/get_cuestionario.js');//-----OK
router.route('/get_cuestionario').post([VerificarToken,get_cuestionario.post]);

const articulo22_automatico = require('../controllers/articulo22_automatico.js');//-----OK
router.route('/articulo22_automatico').post([VerificarToken,articulo22_automatico.post]);

const log_bloqueo_predictivo = require('../controllers/log_bloqueo_predictivo.js');//-----OK
router.route('/log_bloqueo_predictivo').post([VerificarToken,log_bloqueo_predictivo.post]);

const get_preguntas = require('../controllers/get_preguntas.js');//-----OK
router.route('/get_preguntas').post([VerificarToken,get_preguntas.post]);

const get_respuestas = require('../controllers/get_respuestas.js');//-----OK
router.route('/get_respuestas').post([VerificarToken,get_respuestas.post]);

const get_datos_query_CP = require('../controllers/get_datos_query_CP.js');//-----OK
router.route('/get_datos_query_CP').post([VerificarToken,get_datos_query_CP.post]);

const get_datos_query_CP_edo = require('../controllers/get_datos_query_CP_edo.js');//-----OK
router.route('/get_datos_query_CP_edo').post([VerificarToken,get_datos_query_CP_edo.post]);

const get_datos_query_CP_mun = require('../controllers/get_datos_query_CP_mun.js');//-----OK
router.route('/get_datos_query_CP_mun').post([VerificarToken,get_datos_query_CP_mun.post]);

const get_datos_query_CP_col = require('../controllers/get_datos_query_CP_col.js');//-----OK
router.route('/get_datos_query_CP_col').post([VerificarToken,get_datos_query_CP_col.post]);

const set_delete_survey = require('../controllers/set_delete_survey.js');//-----OK
router.route('/set_delete_survey').post([VerificarToken,set_delete_survey.post]);

const set_insert_survey = require('../controllers/set_insert_survey.js');//-----OK
router.route('/set_insert_survey').post([VerificarToken,set_insert_survey.post]);

const set_update_results = require('../controllers/set_update_results.js');//-----OK
router.route('/set_update_results').post([VerificarToken,set_update_results.post]);

const set_datos_solicitud_exitosa = require('../controllers/set_datos_solicitud_exitosa.js');//-----OK
router.route('/set_datos_solicitud_exitosa').post([VerificarToken,set_datos_solicitud_exitosa.post]);

const set_datos_solicitud_exitosa_s = require('../controllers/set_datos_solicitud_exitosa_s.js');//-----OK
router.route('/set_datos_solicitud_exitosa_s').post([VerificarToken,set_datos_solicitud_exitosa_s.post]);

const get_productos_campana = require('../controllers/get_productos_campana.js');//-----OK
router.route('/get_productos_campana').post([VerificarToken,get_productos_campana.post]);

const gdatv = require('../controllers/get_datos_valida_rfc.js'); //-----OK
router.route('/get_datos_valida_rfc').post([VerificarToken,gdatv.post]);

const gvalr = require('../controllers/get_valida_rfc.js'); //-----OK
router.route('/get_valida_rfc').post([VerificarToken,gvalr.post]);

const gdatc = require('../controllers/get_datos_complementarios.js'); //-----OK
router.route('/get_datos_complementarios').post([VerificarToken,gdatc.post]);

const gdatg = require('../controllers/get_datos_grabados.js'); //-----OK
router.route('/get_datos_grabados').post([VerificarToken,gdatg.post]);
//---------------------------------------------------------------------------------//
//------------------------    T I P I F I C A C I O N      ------------------------//
//---------------------------------------------------------------------------------//
// const get_retroactivo_tipi = require('../controllers/get_retroactivo_tipi.js');
// router.route('/retroactivo_tipificacion').post(get_retroactivo_tipi.post);

const tipificaciones = require('../controllers/tipificaciones.js'); //-----OK
router.route('/tipificaciones').post([tipificaciones.post]);

const gpam = require('../controllers/get_prima_acc_mensual.js'); //-----OK
router.route('/get_prima_acc_mensual').post([gpam.post]);

const gpvm = require('../controllers/get_prima_vida_mensual.js'); //-----OK
router.route('/get_prima_vida_mensual').post([gpvm.post]);

const srci = require('../controllers/spi_respuesta_cliente_ivr.js'); //-----OK
router.route('/spi_respuesta_cliente_ivr').post([srci.post]);

const gtp = require('../controllers/get_metodos_pago.js'); //-----OK
router.route('/get_metodos_pago').post([gtp.post]);

const gph = require('../controllers/get_PreAvail_Hora.js'); //-----OK
router.route('/get_PreAvail_Hora').post([gph.post]);

const gpu = require('../controllers/get_PreAvail_uuid.js'); //-----OK
router.route('/get_PreAvail_uuid').post([gpu.post]);

const get_bloqueo_predictivo = require('../controllers/get_bloqueo_predictivo.js');//-----OK
router.route('/get_bloqueo_predictivo').post([get_bloqueo_predictivo.post]);

const obt_cal_cons = require('../controllers/get_calificaciones_consumidas.js'); //-----OK
router.route('/get_calificaciones_consumidas').post([obt_cal_cons.post]);

const obt_bloqueo_vici = require('../controllers/get_bloqueo_vici.js'); //-----OK
router.route('/get_bloqueo_vici').post([obt_bloqueo_vici.post]);

const bloqueo_reus = require('../controllers/bloqueo_reus.js'); //-----OK
router.route('/bloqueo_reus').post([bloqueo_reus.post]);

const set_grabacion = require('../controllers/set_grabacion.js'); //-----OK
router.route('/set_grabacion').post([set_grabacion.post]);

const get_sirh = require('../controllers/get_sirh.js'); //-----OK
router.route('/get_sirh').post([get_sirh.post]);


const guardarLogAudio = require('../controllers/guardarLogAudio.js'); //-----OK
router.route('/guardarLogAudio').post([guardarLogAudio.post]);


const get_Ubicacion = require('../controllers/get_Ubicacion.js'); //-----OK
router.route('/get_Ubicacion').post([get_Ubicacion.post]);

const get_domicilio = require('../controllers/get_domicilio.js'); //-----OK
router.route('/get_domicilio').post([get_domicilio.post]);


const get_Horarios = require('../controllers/get_Horarios.js'); //-----OK
router.route('/get_Horarios').post([get_Horarios.post]);


const set_cambio_domicilio = require('../controllers/set_cambio_domicilio.js'); //-----OK
router.route('/set_cambio_domicilio').post([set_cambio_domicilio.post]);

const get_cambio_domicilio = require('../controllers/get_cambio_domicilio.js'); //-----OK
router.route('/get_cambio_domicilio').post([get_cambio_domicilio.post]);

const get_datos_suboferta = require('../controllers/get_datos_suboferta.js'); //-----OK
router.route('/get_datos_suboferta').post([get_datos_suboferta.post]);

const gcn_ao = require('../controllers/get_claven_aceptaoferta.js'); //-----OK
router.route('/get_claven_aceptaoferta').post([VerificarToken,gcn_ao.post]);

const get_clvn = require('../controllers/get_clave_n.js'); //-----OK
router.route('/get_clave_n').post(get_clvn.post);

const slsol = require('../controllers/set_libera_solicitud.js'); //-----OK
router.route('/set_libera_solicitud').post([VerificarToken,slsol.post]);

const set_libera_agendado = require('../controllers/set_libera_agendado.js');//-----OK
router.route('/set_libera_agendado').post([VerificarToken,set_libera_agendado.post]);

const set_agenda_registro = require('../controllers/set_agenda_registro.js');//-----OK
router.route('/set_agenda_registro').post([VerificarToken,set_agenda_registro.post]);

const get_registros_agendado = require('../controllers/get_registros_agendado.js');//-----OK
router.route('/get_registros_agendado').post([VerificarToken,get_registros_agendado.post]);

const get_valida_solicitud_capturada = require('../controllers/get_valida_solicitud_capturada.js');//-----OK
router.route('/get_valida_solicitud_capturada').post([VerificarToken,get_valida_solicitud_capturada.post]);

const es_grabada = require('../controllers/es_grabada.js');//-----OK
router.route('/es_grabada').post([VerificarToken,es_grabada.post]);

const gaud = require('../controllers/get_agenda_usuario_dia.js'); //-----OK
router.route('/get_agenda_usuario_dia').post([VerificarToken,gaud.post]);

const gidt = require('../controllers/get_id_telefono.js'); //-----OK
router.route('/get_id_telefono').post([VerificarToken,gidt.post]);

const svt = require('../controllers/set_verifica_tel.js'); //-----OK
router.route('/set_verifica_tel').post([VerificarToken,svt.post]);

const gois = require('../controllers/get_obtiene_ivr_sec.js'); //-----OK
router.route('/get_obtiene_ivr_sec').post([VerificarToken,gois.post]);

const gpsms = require('../controllers/get_proveedor_sms.js'); //-----OK
router.route('/get_proveedor_sms').post([VerificarToken,gpsms.post]);

const suids = require('../controllers/set_UID_sms_ivr.js'); //-----OK
router.route('/set_UID_sms_ivr').post([VerificarToken,suids.post]);

const gfp = require('../controllers/get_forma_pago.js'); //----------------------------todavia no
router.route('/get_forma_pago').post([VerificarToken,gfp.post]);

const gpv = require('../controllers/get_prima_values.js'); //-----OK
router.route('/get_prima_values').post([VerificarToken,gpv.post]);

const gpvrh = require('../controllers/get_prima_values_rh.js'); //-----OK
router.route('/get_prima_values_rh').post([VerificarToken,gpvrh.post]);

const gpv7 = require('../controllers/get_prima_values_7.js'); //-----OK
router.route('/get_prima_values_7').post([VerificarToken,gpv7.post]);

const gpva = require('../controllers/get_prima_values_A.js'); //-----OK
router.route('/get_prima_values_A').post([VerificarToken,gpva.post]);

const getp = require('../controllers/get_prima.js'); //-----OK
router.route('/get_prima').post([VerificarToken,getp.post]);

const gdac = require('../controllers/get_datos_copy.js'); //-----OK
router.route('/get_datos_copy').post([VerificarToken,gdac.post]);

const op = require('../controllers/ObtenerPlan.js'); //-----OK
router.route('/ObtenerPlan').post([VerificarToken,op.post]);

const srec = require('../controllers/set_recuperada.js'); //-----OK
router.route('/set_recuperada').post([VerificarToken,srec.post]);

const vnum = require('../controllers/verifcar_numero.js'); //-----OK
router.route('/verifcar_numero').post([VerificarToken,vnum.post]);

const libera_extension = require('../controllers/libera_extension.js');//-----OK
router.route('/libera_extension').post(libera_extension.post);

const get_medias_horas = require('../controllers/get_medias_horas.js');//-----OK
router.route('/get_medias_horas').post([VerificarToken,get_medias_horas.post]);





//-----------------------------------------------------------------------------//
//-------------------------       amexinsurance       -------------------------//
//------------------------------------------------------------------------  ---//

const verpa = require('../controllers/verifypassword.js'); //-----OK
router.route('/verifypassword').post([VerificarToken,verpa.post]);

const gcncsup = require('../controllers/get_cal_NC_SUP.js'); //-----OK
router.route('/get_cal_NC_SUP').post([VerificarToken,gcncsup.post]);

const get_cal_SC2 = require('../controllers/get_cal_SC2.js');//-----OK
router.route('/get_cal_SC2').post([VerificarToken,get_cal_SC2.post]);

const get_registro_especifico_amex = require('../controllers/get_registro_especifico_amex.js');//-----OK
router.route('/get_registro_especifico_amex').post([VerificarToken,get_registro_especifico_amex.post]);

const set_valida_solicitud_capturada = require('../controllers/set_valida_solicitud_capturada.js');//-----OK
router.route('/set_valida_solicitud_capturada').post([VerificarToken,set_valida_solicitud_capturada.post]);

const set_actualiza_reventa = require('../controllers/set_actualiza_reventa.js');//-----OK
router.route('/set_actualiza_reventa').post([VerificarToken,set_actualiza_reventa.post]);

const get_detalle_agendados_usuario = require('../controllers/get_detalle_agendados_usuario.js');//-----OK
router.route('/get_detalle_agendados_usuario').post([VerificarToken,get_detalle_agendados_usuario.post]);

const get_detalle_01800_usuario = require('../controllers/get_detalle_01800_usuario.js');//-----OK
router.route('/get_detalle_01800_usuario').post([VerificarToken,get_detalle_01800_usuario.post]);

const sntel = require('../controllers/set_nuevo_telefono.js'); //-----NO
router.route('/set_nuevo_telefono').post([VerificarToken,sntel.post]);

const get_choicescatalog = require('../controllers/get_choicescatalog.js');//-----OK
router.route('/get_choicescatalog').post([VerificarToken,get_choicescatalog.post]);

const set_datos_solicitud_exitosa_amex = require('../controllers/set_datos_solicitud_exitosa_amex.js');//-----OK
router.route('/set_datos_solicitud_exitosa_amex').post([VerificarToken,set_datos_solicitud_exitosa_amex.post]);

const get_productos_campana_amex = require('../controllers/get_productos_campana_amex.js');//-----OK
router.route('/get_productos_campana_amex').post([VerificarToken,get_productos_campana_amex.post]);

const gprocf = require('../controllers/get_productos_campanaf.js'); //-----OK
router.route('/get_productos_campanaf').post([VerificarToken,gprocf.post]);

const gvalra = require('../controllers/get_valida_rfc_amex.js'); //-----OK
router.route('/get_valida_rfc_amex').post([VerificarToken,gvalra.post]);

const get_datos_valida_rfc_amex = require('../controllers/get_datos_valida_rfc_amex.js'); //-----OK
router.route('/get_datos_valida_rfc_amex').post([VerificarToken,get_datos_valida_rfc_amex.post]);

const get_datos_gen = require('../controllers/get_datos_gen.js'); //-----OK
router.route('/get_datos_gen').post([VerificarToken,get_datos_gen.post]);

const get_mensaje_registro = require('../controllers/get_mensaje_registro.js'); //-----OK
router.route('/get_mensaje_registro').post([VerificarToken,get_mensaje_registro.post]);

const get_tipoBase = require('../controllers/get_tipoBase.js');//-----ERROR
router.route('/get_tipoBase').post([VerificarToken,get_tipoBase.post]);

const get_datos_prima = require('../controllers/get_datos_prima.js');//-----ERROR
router.route('/get_datos_prima').post([VerificarToken,get_datos_prima.post]);

const get_cal_transferencia = require('../controllers/get_cal_transferencia.js');//-----OK
router.route('/get_cal_transferencia').post([VerificarToken,get_cal_transferencia.post]);

const set_cal_hotEspecial = require('../controllers/set_cal_hotEspecial.js');//-----OK
router.route('/set_cal_hotEspecial').post([VerificarToken,set_cal_hotEspecial.post]);

const set_compara_prefijo = require('../controllers/set_compara_prefijo.js');//-----OK
router.route('/set_compara_prefijo').post([VerificarToken,set_compara_prefijo.post]);

const set_banco_prefijo = require('../controllers/set_banco_prefijo.js');//-----ERROR
router.route('/set_banco_prefijo').post([VerificarToken,set_banco_prefijo.post]);

const get_copy_data = require('../controllers/get_copy_data.js');//-----OK
router.route('/get_copy_data').post([VerificarToken,get_copy_data.post]);

const toScoreAgent = require('../controllers/toScoreAgent.js');//-----ERROR
router.route('/toScoreAgent').post([VerificarToken,toScoreAgent.post]);

const getagentevalidacion = require('../controllers/getagentevalidacion.js');//-----OK
router.route('/getagentevalidacion').post([VerificarToken,getagentevalidacion.post]);

const get_productos_ofertados = require('../controllers/get_productos_ofertados.js');//-----OK
router.route('/get_productos_ofertados').post([VerificarToken,get_productos_ofertados.post]);

const set_duplica_califica_sup = require('../controllers/set_duplica_califica_sup.js');//-----OK
router.route('/set_duplica_califica_sup').post([VerificarToken,set_duplica_califica_sup.post]);

const get_datos_dominios_correo = require('../controllers/get_datos_dominios_correo.js');//-----OK
router.route('/get_datos_dominios_correo').post([VerificarToken,get_datos_dominios_correo.post]);

const get_datos_inicio = require('../controllers/get_datos_inicio.js');//-----OK
router.route('/get_datos_inicio').post([VerificarToken,get_datos_inicio.post]);

const get_Ventanueva = require('../controllers/get_Ventanueva.js');//-----OK
router.route('/get_Ventanueva').post([VerificarToken,get_Ventanueva.post]);

const sing = require('../controllers/set_insert_nombre_grabacion.js');//-----OK
router.route('/setInsertNombreGrabacion').post([VerificarToken,sing.post]);

const set_valida_solicitud = require('../controllers/set_valida_solicitud.js');
router.route('/set_valida_solicitud').post([VerificarToken,set_valida_solicitud.post]);

const cambiarPassword = require('../controllers/cambiarPassword.js');
router.route('/cambiarPassword').post([VerificarToken,cambiarPassword.post]);

const get_registro_campana = require('../controllers/get_registro_campana.js');
router.route('/get_registro_campana').post([VerificarToken,get_registro_campana.post]);





//-----------------------------------------------------------------------------//
//---------------------------       I N V E X       ---------------------------//
//-----------------------------------------------------------------------------//


const getindicadores = require('../controllers/getindicadores.js');//-----OK
router.route('/getindicadores').post([VerificarToken,getindicadores.post]);

const get_base_especial = require('../controllers/get_base_especial.js');//-----OK
router.route('/get_base_especial').post([VerificarToken,get_base_especial.post]);

const get_valida_acceso = require('../controllers/get_valida_acceso.js');//-----OK
router.route('/get_valida_acceso').post([VerificarToken,get_valida_acceso.post]);

const set_busca_datos2 = require('../controllers/set_busca_datos2.js');//-----OK
router.route('/set_busca_datos2').post([VerificarToken,set_busca_datos2.post]);

const set_datos_solicitud = require('../controllers/set_datos_solicitud.js'); //-----OK
router.route('/set_datos_solicitud').post([VerificarToken,set_datos_solicitud.post]);

const set_relacion_registro = require('../controllers/set_relacion_registro.js'); //-----OK
router.route('/set_relacion_registro').post([VerificarToken,set_relacion_registro.post]);

const get_detalle_agendados_usuario_invex = require('../controllers/get_detalle_agendados_usuario_invex.js'); //-----OK
router.route('/get_detalle_agendados_usuario_invex').post([VerificarToken,get_detalle_agendados_usuario_invex.post]);

const set_nuevo_telefono_invex = require('../controllers/set_nuevo_telefono_invex.js'); //-----OK
router.route('/set_nuevo_telefono_invex').post([VerificarToken,set_nuevo_telefono_invex.post]);

const get_productos_campana_invex = require('../controllers/get_productos_campana_invex.js'); //-----OK
router.route('/get_productos_campana_invex').post([VerificarToken,get_productos_campana_invex.post]);

const get_datos_grabados_invex = require('../controllers/get_datos_grabados_invex.js'); //-----OK
router.route('/get_datos_grabados_invex').post([VerificarToken,get_datos_grabados_invex.post]);

const set_bloquea_cliente_molesto = require('../controllers/set_bloquea_cliente_molesto.js'); //-----OK
router.route('/set_bloquea_cliente_molesto').post([VerificarToken,set_bloquea_cliente_molesto.post]);

const get_validacionrfc = require('../controllers/get_validacionrfc.js'); //-----OK
router.route('/get_validacionrfc').post([VerificarToken,get_validacionrfc.post]);

const es_grabada_invex = require('../controllers/es_grabada_invex.js'); //-----OK
router.route('/es_grabada_invex').post([VerificarToken,es_grabada_invex.post]);

const set_actualizarnombre = require('../controllers/set_actualizarnombre.js'); //-----OK
router.route('/set_actualizarnombre').post([VerificarToken,set_actualizarnombre.post]);

const get_800 = require('../controllers/get_800.js'); //-----OK
router.route('/get_800').post([VerificarToken,get_800.post]);

const get_datos_prescrining = require('../controllers/get_datos_prescrining.js'); //-----OK
router.route('/get_datos_prescrining').post([VerificarToken,get_datos_prescrining.post]);

const set_datos_prescrining = require('../controllers/set_datos_prescrining.js'); //-----OK
router.route('/set_datos_prescrining').post([VerificarToken,set_datos_prescrining.post]);

const get_cuestionario_calidad = require('../controllers/get_cuestionario_calidad.js'); //-----OK
router.route('/get_cuestionario_calidad').post([VerificarToken,get_cuestionario_calidad.post]);

const get_select_bases_especiales = require('../controllers/get_select_bases_especiales.js'); //-----OK
router.route('/get_select_bases_especiales').post([VerificarToken,get_select_bases_especiales.post]);

const get_insert_bases_especiales = require('../controllers/get_insert_bases_especiales.js'); //-----OK
router.route('/get_insert_bases_especiales').post([VerificarToken,get_insert_bases_especiales.post]);

const getAgendas = require('../controllers/getAgendas.js'); //-----OK
router.route('/getAgendas').post([VerificarToken,getAgendas.post]);



//-----------------------------------------------------------------------------//
//----------------------    T D C A M E X O N L I N E    ----------------------//
//------------------------------------------------------------------------  ---//

const get_consulta_base = require('../controllers/get_consulta_base.js'); //-----OK
router.route('/get_consulta_base').post([VerificarToken,get_consulta_base.post]);

const get_datos_long_app = require('../controllers/get_datos_long_app.js'); //-----OK
router.route('/get_datos_long_app').post([VerificarToken,get_datos_long_app.post]);

const get_consulta_zona = require('../controllers/get_consulta_zona.js'); //-----OK
router.route('/get_consulta_zona').post([VerificarToken,get_consulta_zona.post]);

const get_datos_prescrining_online = require('../controllers/get_datos_prescrining_online.js'); //-----OK
router.route('/get_datos_prescrining_online').post([VerificarToken,get_datos_prescrining_online.post]);

const set_prescrining = require('../controllers/set_prescrining.js'); //-----OK
router.route('/set_prescrining').post([VerificarToken,set_prescrining.post]);

const get_listElegible_face = require('../controllers/get_listElegible_face.js'); //-----OK
router.route('/get_listElegible_face').post([VerificarToken,get_listElegible_face.post]);

const get_conteo_agendas = require('../controllers/get_conteo_agendas.js'); //-----OK
router.route('/get_conteo_agendas').post([VerificarToken,get_conteo_agendas.post]);

const set_busca_cliente = require('../controllers/set_busca_cliente.js');
router.route('/set_busca_cliente').post([VerificarToken,set_busca_cliente.post]);

const get_registro_val = require('../controllers/get_registro_val.js');//-----OK
router.route('/get_registro_val').post([VerificarToken,get_registro_val.post]);

const get_datos_query = require('../controllers/get_datos_query.js');//-----OK
router.route('/get_datos_query').post([VerificarToken,get_datos_query.post]);

const get_datos_ob = require('../controllers/get_datos_ob.js');//-----OK
router.route('/get_datos_ob').post([VerificarToken,get_datos_ob.post]);

const get_data_graph = require('../controllers/get_data_graph.js');//-----OK
router.route('/get_data_graph').post([VerificarToken,get_data_graph.post]);

router.route('/fuera_linea').post(async function (req, res){
  console.log(req.body);
  const params = new URLSearchParams();
  params.append('solicitud', req.body.solicitud);
  params.append('event', req.body.event);
  fetch('http://172.20.1.95/api_fueralinea/main3.php', { method: 'POST', body:params })
    .then(res => res.json())
    .then(json =>{
      console.log(json);
      res.send(json);
    }
    );
  // res.send("entro");
  });




//---------------------------------------------------------------------------------//
//------------------------        P R E N O M I N A        ------------------------//
//---------------------------------------------------------------------------------//

const getDeducciones = require('../controllers/getDeducciones.js');
router.route('/getDeducciones').post([VerificarToken,getDeducciones.post]);

const getPercepciones = require('../controllers/getPercepciones.js');
router.route('/getPercepciones').post([VerificarToken,getPercepciones.post]);


//---------------------------------------------------------------------------------//
//------------------------         K A R D E X       ------------------------//
//---------------------------------------------------------------------------------//

const sps_cursos_ho = require('../controllers/sps_cursos_ho.js');
router.route('/sps_cursos_ho').post([VerificarToken,sps_cursos_ho.post]);

const spi_capa = require('../controllers/spi_capa.js');
router.route('/spi_capa').post([VerificarToken,spi_capa.post]);

const spi_capa_usr = require('../controllers/spi_capa_usr.js');
router.route('/spi_capa_usr').post([VerificarToken,spi_capa_usr.post]);

const campana_nomina = require('../controllers/campana_nomina.js');
router.route('/campana_nomina').post([VerificarToken,campana_nomina.post]);

const sps_meses_kardex = require('../controllers/sps_meses_kardex.js');
router.route('/sps_meses_kardex').post([VerificarToken,sps_meses_kardex.post]);

const sps_kardex_ho = require('../controllers/sps_kardex_ho.js');
router.route('/sps_kardex_ho').post([VerificarToken,sps_kardex_ho.post]);

//---------------------------------------------------------------------------------//
//------------------------    T D C A M E X O N L I N E    ------------------------//
//---------------------------------------------------------------------------------//

const set_guarda_referido = require('../controllers/set_guarda_referido.js');
router.route('/set_guarda_referido').post([VerificarToken,set_guarda_referido.post]);

const set_registro_especifico = require('../controllers/set_registro_especifico.js');
router.route('/set_registro_especifico').post([VerificarToken,set_registro_especifico.post]);

//---------------------------------------------------------------------------------//
//------------------------    P R E D I C T I V O   ------------------------//
//---------------------------------------------------------------------------------//

const get_datos_precarga = require('../controllers/get_datos_precarga.js');
router.route('/get_datos_precarga').post(get_datos_precarga.post);


//---------------------------------------------------------------------------------//
//------------------------     N O     S E     U S A N     ------------------------//
//---------------------------------------------------------------------------------//


/*const goccad = require('../controllers/get_occ_agente_detalle.js'); //----- OK
router.route('/get_occ_agente_detalle').post([VerificarToken,goccad.post]);

const get_valida_acceso = require('../controllers/get_valida_acceso.js');
router.route('/get_valida_acceso').post([VerificarToken,get_valida_acceso.post]);

const set_busca_datos = require('../controllers/set_busca_datos.js');
router.route('/set_busca_datos').post([VerificarToken,set_busca_datos.post]);

const set_busca_datos2 = require('../controllers/set_busca_datos2.js');
router.route('/set_busca_datos2').post([VerificarToken,set_busca_datos2.post]);

const set_datos_empresas = require('../controllers/set_datos_empresas.js');
router.route('/set_datos_empresas').post([VerificarToken,set_datos_empresas.post]);

const set_datos_solicitud = require('../controllers/set_datos_solicitud.js');
router.route('/set_datos_solicitud').post([VerificarToken,set_datos_solicitud.post]);

const set_subcalificacion_registro = require('../controllers/set_subcalificacion_registro.js');
router.route('/set_subcalificacion_registro').post([VerificarToken,set_subcalificacion_registro)];

const set_valida_solicitud_capturada = require('../controllers/set_valida_solicitud_capturada.js');
router.route('/set_valida_solicitud_capturada').post([VerificarToken,set_valida_solicitud_capturada.post]);

const set_relacion_registro = require('../controllers/set_relacion_registro.js');
router.route('/set_relacion_registro').post([VerificarToken,set_relacion_registro.post]);

const set_registro_especifico = require('../controllers/set_registro_especifico.js');
router.route('/set_registro_especifico').post([VerificarToken,set_registro_especifico.post]);

const set_nuevo_telefono = require('../controllers/set_nuevo_telefono.js');
router.route('/set_nuevo_telefono').post([VerificarToken,set_nuevo_telefono.post]);

const get_lista_medias_horas = require('../controllers/get_lista_medias_horas.js');
router.route('/get_lista_medias_horas').post([VerificarToken,get_lista_medias_horas.post]);

const get_respuestas_default = require('../controllers/get_respuestas_default.js');
router.route('/get_respuestas_default').post([VerificarToken,get_respuestas_default.post]);

const get_datos_query = require('../controllers/get_datos_query.js');
router.route('/get_datos_query').post([VerificarToken,get_datos_query.post]);

const get_datos_query2 = require('../controllers/get_datos_query2.js');
router.route('/get_datos_query2').post([VerificarToken,get_datos_query2.post]);

const set_guarda_referdido = require('../controllers/set_guarda_referdido.js');
router.route('/set_guarda_referdido').post([VerificarToken,set_guarda_referdido.post]);

const getindicadores = require('../controllers/getindicadores.js');
router.route('/getindicadores').post([VerificarToken,getindicadores.post]);*/

//---------------------------------------------------------------------------------//
//--------------    I N T E L I G E N C I A   D E   M E R C A D O S  --------------//
//---------------------------------------------------------------------------------//

const login = require('../controllers/login.js');
router.route('/login').post(login.post);

const procesar_tu_cargabase = require('../controllers/procesar_tu_cargabase.js');
router.route('/procesar_tu_cargabase').post(procesar_tu_cargabase.post);

const encriptar_datos = require('../controllers/encriptar_datos.js');
router.route('/encriptar_datos').post(encriptar_datos.post);

const load_users = require('../controllers/load_users.js');
router.route('/load_users').post(load_users.post);

const change_pass = require('../controllers/change_pass.js');
router.route('/change_pass').post(change_pass.post);

const get_permisos = require('../controllers/get_permisos.js');
router.route('/get_permisos').post(get_permisos.post);

const load_profiles = require('../controllers/load_profiles.js');
router.route('/load_profiles').post(load_profiles.post);

const load_permissions = require('../controllers/load_permissions.js');
router.route('/load_permissions').post(load_permissions.post);

const add_record = require('../controllers/add_record.js');
router.route('/add_record').post(add_record.post);

const save_new_user = require('../controllers/save_new_user.js');
router.route('/save_new_user').post(save_new_user.post);

const reset_password = require('../controllers/reset_password.js');
router.route('/reset_password').post(reset_password.post);

const edit_row = require('../controllers/edit_row.js');
router.route('/edit_row').post(edit_row.post);

const delete_row = require('../controllers/delete_row.js');
router.route('/delete_row').post(delete_row.post);
// const {deletes_row} = require('../controllers/delete_row');
// router.post('/delete_row', deletes_row);

const save_new_perfil = require('../controllers/save_new_perfil.js');
router.route('/save_new_perfil').post(save_new_perfil.post);

const search_data_phone = require('../controllers/search_data_phone.js');
router.route('/search_data_phone').post(search_data_phone.post);

const search_resultadosllamadas = require('../controllers/search_resultadosllamadas.js');
router.route('/search_resultadosllamadas').post(search_resultadosllamadas.post);

const bloquear_telefono = require('../controllers/bloquear_telefono.js');
router.route('/bloquear_telefono').post(bloquear_telefono.post);

// const art = require('../controllers/art.js');
// router.route('/art').post(art.post);
const {post} = require('../controllers/art');
router.post('/art', post);

const reus = require('../controllers/reus');
router.route('/reus', post).post(reus.post);

// const insert_tucargabase = require('../controllers/insert_tucargabase.js');
// router.route('/insert_tucargabase').post(insert_tucargabase.post);

const obtenerBases = require('../controllers/obtenerBases.js');
router.route('/obtenerBases').post(obtenerBases.post);

const conamer = require('../controllers/conamer.js');
router.route('/conamer').post(conamer.post);

const calificada = require('../controllers/calificada.js');
router.route('/calificada').post(calificada.post);
// const {pos} = require('../controllers/calificada');
// router.post('/calificada', pos);

const bloqueo_telefono = require('../controllers/bloqueo_telefono.js');
router.route('/bloqueo_telefono').post(bloqueo_telefono.post);

const reporte_anis = require('../controllers/reporte_anis.js');
router.route('/reporte_anis').post(reporte_anis.post);

const bases_contacto = require('../controllers/bases_contacto.js');
router.route('/bases_contacto').post(bases_contacto.post);

const reporte_contacto1 = require('../controllers/reporte_contacto1.js');
router.route('/reporte_contacto1').post(reporte_contacto1.post);

const reporte_contacto2 = require('../controllers/reporte_contacto2.js');
router.route('/reporte_contacto2').post(reporte_contacto2.post);

const repositorio_ventas = require('../controllers/repositorio_ventas.js');
router.route('/repositorio_ventas').post(repositorio_ventas.post);

const obtenerTickets = require('../controllers/obtenerTickets.js');
router.route('/obtenerTickets').post(obtenerTickets.post);

const crearEditarTicket = require('../controllers/crearEditarTicket.js');
router.route('/crearEditarTicket').post(crearEditarTicket.post);

const usuariosAUT = require('../controllers/usuariosAUT.js');
router.route('/usuariosAUT').post(usuariosAUT.post);

const load_permisos = require('../controllers/load_permisos.js');
router.route('/load_permisos').post(load_permisos.post);

const log_dids = require('../controllers/log_dids.js');
router.route('/log_dids').post(log_dids.post);
//---------------------------------------------------------------------------------//
//-------------------------------------  D B A  -----------------------------------//
//---------------------------------------------------------------------------------//
const rotate_key = require('../controllers/rotate_key.js');
router.route('/rotate_key').post(rotate_key.post);



const agent = new https.Agent({
  rejectUnauthorized: false
});

router.route('/requestpredictivo').post(async function (req, res){
console.log(req.body.url);
fetch(req.body.url)
  .then(res => res.json())
  .then(json =>{

    console.log(String(json));
    res.send(String(json));
  })

});

router.route('/requestpredictivo_ssl').post(async function (req, res){
  let act = parseInt(req.body.act);
  let params = req.body.url;
  let url;
  //console.log(req.body.act);
  //console.log(req.body.url);
  if(req.body.act || req.body.url ){
    switch  (act){
      case 1  :
      url = 'http://172.20.1.10/marcadoasistido/click2dial/citi/marcadoasistido.php?'+params;
      break;
      default:
      res.send({msg:'Parametros no enviados'});
      break;
    }

//    fetch(url, {agent})
//    .then(res => res.json())
//    .then(json =>{
//      console.log(json);
//      res.send(json);
//    });
fetch(url)
.then(res.send({data:'Ejecuta con exito liga Asistido'}))

}
});

router.route('/avisoprivacidad').post(async function (req, res){
  let act = parseInt(req.body.act);
  let params = req.body.url;
  let url;
  //console.log(req.body.act);
  //console.log(req.body.url);
  if(req.body.act || req.body.url ){
    switch  (act){
      case 1  :
      url = 'http://172.20.1.10/click2dial/citi/clearmeetme-aviso.php?'+params;
      //console.log('predictivo');
      break;
      case 2  :
      url = 'http://172.20.1.10/marcadoasistido/click2dial/citi/transfiere-aviso-privacidad.php?'+params;
      //console.log('asistido');
      break;
      default:
      res.send({msg:'Parametros no enviados'});
      break;
    }

//    fetch(url, {agent})
//    .then(res => res.json())
//    .then(json =>{
//      console.log(json);
//      res.send(json);
//    });
fetch(url)
.then(res.send({data:'Ejecuta con exito liga Aviso Privacidad'}))

}
});

module.exports = router;
