const set_estatus_registro_normal = require('../db_apis/set_estatus_registro_normal.js');
 
async function post(req, res, next) {
  try {
    const context = req.body;//{};

    // context.camp      = 1;
    // context.prioridad   = 1;
    // context.estatus     = 0;
    // context.intentos    = 10;
    // context.user_     = 8981;
    // context.rand_     = 0;    
    // context.tipoCampana   = '0';    
 
    const rows = await set_estatus_registro_normal.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;