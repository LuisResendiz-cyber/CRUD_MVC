const oracledb = require('oracledb');
const database = require('../services/database.js');
 
 
async function find(context) {
  console.log(context);
const baseQuery = "BEGIN " + context.schema + ".XSP_GETLISTAESTATUSSICONTACTO(:camp, :contacto, :origen, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};
        if(!context.camp || !context.contacto){
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;
        }else{
            binds.camp      = context.camp;
            binds.contacto      = context.contacto;
            binds.origen      = context.origen;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
            const result = await database.simpleExecuteRC(query, binds);

            //console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;