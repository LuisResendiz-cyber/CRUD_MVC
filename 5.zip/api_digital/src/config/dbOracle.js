import oracledb from "oracledb";
import { config } from "dotenv";
config();
const ENVIRONMENT = process.env.NODE_ENV || "PRODUCCION";

const env = {
  user: ENVIRONMENT === "development" ? "AMEXINSURANCEDIG" : "AMEXINSURANCEDIG",
  password: ENVIRONMENT === "development" ? "12345678" : "af05bedccdc",
  connectString:
    ENVIRONMENT === "development" ? "172.20.1.35/XE" : "192.168.1.14/xccmtaf",
};

const dbConfig = {
  user: env.user,
  password: env.password,
  connectString: env.connectString,
  poolMax: 5,
  poolMin: 1,
  poolIncrement: 1,
  poolTimeout: 180,
};

let pool;

async function initPool() {
  if (!pool) {
    pool = await oracledb.createPool(dbConfig);    
  }
}

async function closePool() {
  if (pool) {
    await pool.close(0); // 0 significa cerrar inmediatamente

    pool = null; // Limpiar la referencia del pool

    console.log("Pool de conexiones cerrado");
  }
}

function getPool() {
  if (!pool) {
    throw new Error(
      "El pool de conexiones no está inicializado. Llama a initPool() primero."
    );
  }

  return pool;
}

export { initPool, closePool, getPool };
