const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".XSP_SOLICITUDEXITOSA(:p_registro, :p_solicitud, :p_u_persona, :p_u_telefono, :p_grabacion, :p_u_user); END;";

	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.p_registro || !context.p_solicitud || !context.p_u_persona || !context.p_u_telefono || !context.p_grabacion || !context.p_u_user){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.p_registro      = context.p_registro;
            binds.p_solicitud      = context.p_solicitud;
            binds.p_u_persona      = context.p_u_persona;
            binds.p_u_telefono      = context.p_u_telefono;
            binds.p_grabacion      = context.p_grabacion;
            binds.p_u_user      = context.p_u_user;

            console.log(binds);

            const result = await database.simpleExecute(query, binds);

             console.log(result);

            return result;
        }
}

module.exports.find = find;
