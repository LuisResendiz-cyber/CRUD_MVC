const spi_capa = require('../db_apis/spi_capa.js');
 
async function post(req, res, next) {
  try {        
    // console.log("autenticar",req.body)

    const rows = await spi_capa.find(req.body);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
