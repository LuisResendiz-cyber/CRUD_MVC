// services/chat/chat.resolver.js

const rulesService = require("./rules.service");
const knowledgeService = require("./knowledge.service");
const responseFactory = require("./response.factory");

class ChatResolver {
  async resolve({ session, message }) {
    // 1️⃣ Validar reglas de sesión
    const ruleDecision = rulesService.evaluate(session, message);

    if (ruleDecision.type === "HUMAN") {
      return responseFactory.human();
    }

    // 2️⃣ Intentar resolver con conocimiento estático
    const knowledgeAnswer =
      await knowledgeService.match(message);

    if (knowledgeAnswer) {
      return responseFactory.bot(knowledgeAnswer);
    }

    // 3️⃣ Fallback (LLM en el futuro)
    return responseFactory.bot(
      "Gracias por tu mensaje, en breve un asesor te apoyará 😊"
    );
  }
}

module.exports = new ChatResolver();
