const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  // console.log(context);
  const baseQuery =
    "BEGIN CITI.SPS_REPOSITORIO_VENTA(:v_fecha1, :v_fecha2, :rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  let result = {};

  if (context.v_fecha1 == "" || context.v_fecha2 == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
  } else {
    binds.v_fecha1 = context.v_fecha1;
    binds.v_fecha2 = context.v_fecha2;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
    // console.log(result);  

    return result;
  }
}

module.exports.find = find;
