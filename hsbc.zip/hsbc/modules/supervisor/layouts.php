<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("supervisor", "Seguimiento");

$id_solicitud = get_session_varname('id_solicitud');

layout_menu($db, "frm1.solicitud.focus();");
?>
<p class="textbold">Supervisor &gt; Revivir Solicitud</p>
<p>&nbsp;</p>
<div id="content">
    <fieldset>
        <legend><b style="color: red; font-size: 16px; ">Layouts</b></legend>
        <form name="layouts" id="layouts" action="modules.php?mod=supervisor&op=proces_data&act=" method="post">
            <table align="center">
                <tr>
                    <th colspan="2" align="center">
                        <h2>Par&aacute;metros:</h2>
                    </th>
                </tr>
                <tr>
                    <td>
                        <label for="fecha">Fecha:</label>
                    </td>
                    <td>
                        <input type="text" name="fecha" id="fecha" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="layoot">Layout:</label>
                    </td>
                    <td>
                        <select name="t_layout" id="t_layout">
                            <option value="">Selecciona una Opcion...</option>
                            <option value="1">IQ Call</option>
                        </select>
                    </td>
                </tr>
                <tr>                    
                    <td align="center" colspan="2">
                        <p>&nbsp;</p>
                        <input type="button" id="l_button" value="Generar Layout IQ" onclick="generar_layouts()">
                    </td>
                </tr>
            </table>
            <div id="result">                
            </div>
        </form>
    </fieldset>
</div>
<?
layout_footer();
?>