const customerModel = require("../models/webchat.models");
const ChatResolver = require("../controllers/Knowledge.controller");
const { emitToSession } = require("../ws/socket");

async function processIncomingMessage({ session_id, message, channel = "web" }) {

  if (!session_id || !message) {
    throw new Error("Datos incompletos");
  }

  const events = [];

  // 1️⃣ Obtener o crear sesión
  const session = await customerModel.getOrCreateSession(session_id, channel);
  const conversation_id = session.session_uuid;

  // 2️⃣ Guardar mensaje del usuario
  await customerModel.insertWebhookLog({
    event_type: "web_reply",
    status: "received",
    message_text: message,
    channel,
    role: "user",
    id_envio: conversation_id,
  });


  //if (session.status === "user") {
    await customerModel.updateSessionAfterMessage(session.session_uuid, {
      last_message: message,
      last_message_role: "user",
      incrementUnread: true
    });
  //}
  

  // 3️⃣ Si está en humano o cerrado → NO IA
  if (session.status === "human" || session.status === "closed") {
    return { session, events };
  }

  // 4️⃣ Resolver con IA
  const resolution = await ChatResolver.resolve({
    session,
    message
  });

  const replyText = resolution?.message || null;

  // 5️⃣ Guardar respuesta del bot
  if (replyText && session.status === "bot") {
    await customerModel.insertWebhookLog({
      event_type: "web_reply",
      status: "sent",
      message_text: replyText,
      channel,
      role: "assistant",
      id_envio: conversation_id,
    });



    await customerModel.updateSessionAfterMessage(session.session_uuid, {
      last_message: replyText,
      last_message_role: "assistant"
    });

    events.push({
      role: "assistant",
      message_text: replyText,
      created_at: new Date()
    });
  }

  return { session, events };
}

async function closeChatByInactivity(session_id) {
  await customerModel.closeSession(session_id);

  await customerModel.insertWebhookLog({
    event_type: "chat_closed",
    status: "system",
    message_text: "Chat cerrado por inactividad",
    channel: "web",
    role: "system",
    id_envio: session_id,
  });

  await customerModel.updateSessionAfterMessage(session_id, {
    last_message: "Chat cerrado por inactividad",
    last_message_role: "system"
  });
}

async function reopenSession(session_id) {

  await customerModel.reopenSession(session_id);

  
  await customerModel.insertWebhookLog({
    event_type: "chat_open",
    status: "system",
    message_text: "El chat ha sido reactivado 😊",
    channel: "web",
    role: "system",
    id_envio: session_id,
  });


  await customerModel.updateSessionAfterMessage(session_id, {
    last_message: "El chat ha sido reactivado 😊",
    last_message_role: "system"
  });

}

async function sendHumanMessage(session_uuid, agent_id, message) {
  if (!session_uuid || !agent_id || !message) {
    throw new Error("Datos incompletos");
  }

  // 1️⃣ Pasar sesión a humano
  await customerModel.setSessionHuman({
    session_uuid,
    agent_id,
  });


  
  // 2️⃣ Guardar mensaje del agente
  await customerModel.insertWebhookLog({
    event_type: "human_reply",
    status: "sent",
    message_text: message,
    channel: "web",
    role: "agent",
    id_envio: session_uuid,
  });


  await customerModel.updateSessionAfterMessage(session_uuid, {
    last_message: message,
    last_message_role: "agent"
  });
  

  return {
    session_uuid,
    role: "agent",
    message_text: message,
    created_at: new Date(),
  };
}

module.exports = { sendHumanMessage };


module.exports = { processIncomingMessage, closeChatByInactivity, reopenSession, sendHumanMessage };
