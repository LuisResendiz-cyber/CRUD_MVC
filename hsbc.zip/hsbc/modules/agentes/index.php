<?php
# @uthor Mark
# Index File on agente module

$tu_base = " disabled";
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Nuevo registro");
unset_session_varname("t_registro");
$t_registro = $_REQUEST['t_reg'];
unset_session_varname("tel_predictivo");

$isPredictivo2 = get_session_varname("s_usr_marcacion");

if ($isPredictivo2 == 1 && $t_registro == 1) {
    $t_registro = 1;
} else {
    $t_registro = 0;
}



set_session_varname("t_registro", $t_registro);
set_session_varname("url_contacto", "index");

if(isset($_SESSION['aprocesado'])){## para ofrecer otro producto
    $aprocesado = get_session_varname('aprocesado');
} else {
    $aprocesado = null;
}

if(!isset($_GET['calificados'])){## para hacer refresh si no
    $subcalificacion = $_GET['subcalificacion'];
}

//$tel = '.$datos_cliente[$indice]["CLAVELADA"].$datos_cliente[$indice]["TELEFONO"].'
$extenagente = get_session_varname('extension');
$user = get_session_varname("s_usr_id");
$nomina = get_session_varname('s_usr_nomina');

$datos_cliente = get_session_varname("datos_persona");
//var_dump($datos_cliente);
$sc = get_session_varname("sc");
//var_dump($datos_cliente[0]['BANDERA_SEGMENTO']);
$tipo_zona = $datos_cliente[0]['TIPO_ZONA'];
$limit_credit = $datos_cliente[0]['LIMIT_CREDIT'];
includesScoreCSS();
$empresa = get_session_varname("s_usr_centro");


// if(trim($tipo_zona) == 'S'){
//     $tipo_zona2 = 'SPONSOR';
// }else if(trim($tipo_zona) == 'L'){
//     $tipo_zona2 = 'RECHAZOS';
// }else {
//     $tipo_zona2 = 'MERCADO ABIERTO';
// }
$tipo_zona2 = 'HSBC';

set_session_varname("tel_predictivo", $datos_cliente[0]['U_TELEFONO']);

//Centro de costos de agente
$cc = get_session_varname("s_usr_cc");
//echo "Centro de costos: ".$cc;

$id_solicitud = (strlen(get_session_varname('id_solicitud')) > 0 ? get_session_varname('id_solicitud') : desencripta($_REQUEST['sol']));
$tipo_zona_l4 = get_tipo_zona($id_solicitud, $db);
// $productos_ = get_productos_campana($id_solicitud,$db); //PRODUCTOS
$productos_ = get_productos_campana_agentes($id_solicitud,$nomina,$db); //PRODUCTOS
$len = count($productos_->_array);


$prods_ = '';
for($i=0; $i<$len; $i++){
    $nombre_prod = $productos_->_array[$i]['NAME'];
    $id_prod = $productos_->_array[$i]['SURVEYID'];
    $prods_ .= '<option value="'.$id_prod.'">'.$nombre_prod.'</option>';
}



//echo $nombre_prod . '|' . $id_prod;

//if (get_session_varname("s_usr_id") == 4297)
$datos_referido = get_datos_referido($id_solicitud, $db);
//$prod = $productos_->fields['U_PRODUCTO'];
//for ($t = 0; $t < count($productos_->_array); $t++)
//layout_menu($db, "ShowScript_GeneralIN()");

$hora = date("H");
$minutos = date("i");
$random = rand(1,6);
$dia = date("w");

//$empresa = 'ITS';
// echo 'PRIMA= ' .$datos_cliente[0]['PRIMA'];

if(get_session_varname("inicio") === 1 && $t_registro == 0){
    $body = " inicio_marcar(2); ";
    unset_session_varname("inicio");
}else{
    $body ="";
}

if($hora == 10 || $hora == 11 || $hora == 12 || $hora == 13|| $hora == 14 || $hora == 15 || $hora == 16 || $hora == 17 || $hora == 18){
    if($minutos > 00 && $minutos < 10){
        if ($empresa == 'ITQ'){
            layout_menu($db, "ShowScript_GeneralIN();dialogo('https://172.20.1.79/ImagenesAntiestres/rutina_antiestres_".$random.".jpg', 'Relax');".$body);
        }else if($empresa == 'ITS'){
            if($dia == 5){
                layout_menu($db, "ShowScript_GeneralIN();dialogo('https://172.20.1.79/ImagenesAntiestres/sjr/nomina.jpg', 'Nomina');".$body);
            }else{
                layout_menu($db, "ShowScript_GeneralIN();dialogo('https://172.20.1.79/ImagenesAntiestres/sjr/rutina_antiestres_".$random.".jpg', 'Relax');".$body);
            }
        }else if($empresa == 'ITCMX'){
            layout_menu($db, "ShowScript_GeneralIN();dialogo('https://172.20.1.79/ImagenesAntiestres/itt/rutina_antiestres_".$random.".jpg', 'Relax');".$body);
        }  else {
            layout_menu($db, "ShowScript_GeneralIN();".$body);
        }
    }else{
        layout_menu($db, "ShowScript_GeneralIN();".$body);
    }
}else{
    layout_menu($db, "ShowScript_GeneralIN(); ".$body);
}

//echo "<script>dialogo('http://".$_SERVER['SERVER_ADDR']."/ImagenesAntiestres/imagen_6.jpg', 'Relax')</script>";
// echo desencripta('MTg=');

?>
<p class="textbold">Agentes &gt; Obtener Registro</p>
<p>&nbsp;</p>

<form method="post" action="modules.php?mod=agentes&op=cuestionario" name="frm1">
    <table class="cuestionario" border="1" height="300px">
        <tr>
            <td width="100%">
                <table border="0">
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="textleft" width="25%" colspan="2"><b>Nombre cliente:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['NOMBRE'] . '&nbsp;' . $datos_cliente[0]['APATERNO'] . '&nbsp;' . $datos_cliente[0]['AMATERNO'] ?></td>

                    </tr>
                    <tr>
                        <td colspan="2" ><b># Solicitud:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $id_solicitud ?></td>
                    </tr>
                    <!--tr>
                        <td colspan="2" class="textleft"><b>RFC:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['RFC'] ?></td>
                    </tr-->
                    <tr>
                        <td colspan="2" class="textleft"><b>Localizaci&oacute;n:&nbsp;</b></td>
                        <td colspan="2" class="label"><font size="4" color="green"><?= $datos_cliente[0]['LOCALIZACION'] ?></font></td>
                    </tr>

                    

                    <tr>
                        <td colspan="2" class="textleft"><b>Zona:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $tipo_zona2 ?></td>
                    </tr>

                     <tr>
                        <td colspan="2" class="textleft"><b>Oferta:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $limit_credit ?></td>
                    </tr>

                    <?PHP
                    if($datos_cliente[0]['REFERIDO_POR'] != ''){
                    ?>
                    <tr>
                        <td colspan="2" class="textleft"><b>Referido por;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['REFERIDO_POR'] ?></td>
                    </tr>
                    <?PHP
                    }
                    ?>

                    <tr>
                        <td colspan="2" class="textleft"><b>TDD:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['ULT_TDD'] ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="textleft"><b>TDC:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['ULT_TDC'] ?></td>
                    </tr>


                    <?php if ($tipo_zona_l4->_array[0]['ORIGEN'] == 'TDC') { ?>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Tipo Tarjeta:&nbsp;</td>
                        <td colspan="2" class="label"><span style="font-size: 13px;color: red;"><?php echo  $datos_cliente[0]['PRODUCTO']?></span></td>
                    </tr>
                    <?php }?>

                    <?php if($tipo_zona_l4->_array[0]['ORIGEN'] == 'L4'){ ?>
                    <tr>
                        <td colspan="2" class="textleft"><b style="font-size: 20px;color: red;">Origen:&nbsp;</b></td>
                        <td colspan="2" class="label" style="font-size: 20px;color: red;"><?= $tipo_zona_l4->_array[0]['ORIGEN'] ?></td>
                    </tr>
                    <?php } ?>

                    <?php if($tipo_zona_l4->_array[0]['ORIGEN'] == 'Portabilidad'){ ?>
                    <tr>
                        <td colspan="2" class="textleft"><b style="font-size: 20px;color: red;">Origen</b></td>
                        <td colspan="2" class="label" style="font-size: 20px;color: red;"><?= $tipo_zona_l4->_array[0]['ORIGEN'] ?></td>
                    </tr>

                    <tr>
                        <td colspan="2" class="textleft"><b>Tipo de cliente</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['BANDERA_SEGMENTO']  ?></td>

                        
                    </tr>
                    <tr>
                        <td colspan="2" class="textleft"><b>Tipo de Cuenta</b></td>
                        <td colspan="2" class="label"><?=$datos_cliente[0]['SUB_17'] ?></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="textleft"><b>Producto a ofertar</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['AP_O_HC'] ?></td>
                    </tr>
                    <?php } ?>


               


                    <?php
                         if($datos_cliente[0]['PRIMA'] != '1'){
                            ?>

                     <tr>
                        <td colspan="2" class="textleft"><b>Tipo Cliente:&nbsp;</b></td>
                        <td colspan="2" class="label"><?= $datos_cliente[0]['ESTRATEGIA_16'] ?></td>
                     </tr>
                      <!-- <tr> 
                        <td colspan="2" class="textleft"><b>PRIMA:&nbsp;</b></td>
                        <td colspan="2" class="label"> -->
                            <?php

                            // if($datos_cliente[0]['ESTRATEGIA_16'] == 'Advance' || $datos_cliente[0]['ESTRATEGIA_16'] == 'Premier'){
                            //     echo $datos_cliente[0]['PRIMA']." /DESC ".$datos_cliente[0]['PRIMA_DESC'];
                            // }else{
                            //     echo $datos_cliente[0]['PRIMA'] ;
                            // }
                         ?>
                         <!-- </td> -->
                     <!-- </tr> -->
                      <!-- <tr>
                        <td colspan="2" class="textleft"><b>PRIMA A 30 DIAS:&nbsp;</b></td>
                        <td colspan="2" class="label"><span style="color:red;">}
                            <?php


                        //    if($datos_cliente[0]['ESTRATEGIA_16'] == 'Advance' || $datos_cliente[0]['ESTRATEGIA_16'] == 'Premier'){
                        //         echo $datos_cliente[0]['PRIMA2']." /DESC ".$datos_cliente[0]['PRIMA2_DESC'];
                        //     }else{
                        //         echo $datos_cliente[0]['PRIMA2'] ;
                        //     }

                         ?>
                         </span>
                         </td>

                     </tr>



                    <?php if (  $datos_cliente[0]['PRIMA'] != $datos_cliente[0]['PRIMA2']){ ?>

                    <tr class="label" align="middle">
                        <td class="label" colspan="4"><span style="color:blue; font-size:18px;"><b>CLIENTE CUMPLE A&Ntilde;OS DENTRO DE LOS PROXIMOS 30 DIAS</b></span></td>

                    </tr>

                    <?php } ?>

                     <?php } ?>






                    <?php
                        if($datos_cliente[0]['TIPO_ZONA'] == 'PF'){
                    ?>
                    <tr>
                        <td colspan="2" class="textleft"><b>Fecha de Caducidad:&nbsp;</b></td>
                        <td colspan="2" class="label"><?=$datos_cliente[0]['FECHA_CADUCIDAD']?></td>
                    </tr>
                    <?php
                        }
                    ?>

                    <?php

                    if(get_session_varname('resul_reus') > 0){
                        $msj = "";
                        if(get_session_varname('resul_reus') == 1){
                            $msj = "TELEFONO BLOQUEADO POR REUS (MÁS INFORMACIÓN CON INTELIGENCIA DE MERCADOS)";
                        }elseif(get_session_varname('resul_reus') == 2){
                            $msj = "TELEFONO EXISTENTE, SE LIBERO";
                        }elseif(get_session_varname('resul_reus') == 3){
                            $msj = "TELEFONO EXISTENTE, SE ENCUENTRA BLOQUEADO (MÁS INFORMACIÓN CON INTELIGENCIA DE MERCADOS)";
                        }elseif(get_session_varname('resul_reus') == 4){
                            $msj = "TELEFONO DE REFERIDO, SE ENCUENTRA BLOQUEADO (MÁS INFORMACIÓN CON INTELIGENCIA DE MERCADOS)";
                        }elseif(get_session_varname('resul_reus') == 5){
                            $msj = "EL TELEFONO YA SE ENCUENTRA REGISTRADO, SI NO SE MUESTRA ES POR QUE SE ENCUENTRA BLOQUEADO POR IM";
                        }
                        ?>
                    <tr>
                        <td colspan="4" class="textleft" style="color: red;"><b><?=$msj?></b></td>
                    </tr>
                        <?php
                        unset_session_varname('resul_reus');
                    }
                    ?>
                    <!--"javascript:AbreVentana()" a href = " modules.php?mod=agentes&op=marcadoasistido?employeeid='.$nomina.'&exten='.$datos_cliente[$indice]["CLAVELADA"].$datos_cliente[$indice]["TELEFONO"].'&sicallVarSolicitud='.$id_solicitud.'"></a-->
                    <?
                    $contador = 1;
                    $count_selected = 0;
                    $arrayTels = array();
                    for($indice = 0; $indice < count($datos_cliente); $indice++){
                        $arrayTels[] = array(
                            '0' => $datos_cliente[$indice]['CLAVELADA'] . $datos_cliente[$indice]['TELEFONO'],
                            '1' => $datos_cliente[$indice]['U_TELEFONO'],
                            '2' => $datos_cliente[$indice]['TIPO_TELEFONIA']
                        );
                        //Trae todos los telefonos del cliente, pone la imagen del telefono para marcador asistido
                        //Verifica si esta en asistido o Normal
                        //echo 'tipo de registro: '.$t_registro.' es predictivo: '.$isPredictivo; //die();
                        //echo 'Nomina: '.$nomina.'<br>';
                        //echo 'User: '.$user.'<br>';


                        if ($t_registro == 0/* && $datos_cliente[$indice]["ACTIVO"] == 1*/) {
                            echo '<tr>';
                            echo '  <td colspan="2" class="textleft">';
                                ?>      <input type="button" class="menulink" id="btnMarcar<?= $contador ?>" value="Marcar tel. <?php echo $contador; ?>" onclick="this.disabled=true;AbreVentana(this, <?= $contador ?>, '<?php echo $nomina ?>','<?php echo  $datos_cliente[$indice]['CLAVELADA'] . $datos_cliente[$indice]['TELEFONO']; ?>','<?php echo $id_solicitud; ?>',<?php echo $extenagente; ?>, '<?php echo $cc; ?>','<?php echo $datos_cliente[$indice]['U_TELEFONO']; ?>', <?=$datos_cliente[0]['U_ZONA']?>);"/>     <?php
                            echo '  </td>
                                    <td ><input class="label" type="text" size="25" name="tel_' . $contador . '" id="tel_' . $contador . '" value="' . $datos_cliente[$indice]["LOCALIZACIONRT"] . '" readonly></td>
                                    <td>';
                        } else {
                            echo '<tr>
                                    <td  colspan="2" class="textleft"></td>
                                    <!--td><input type="button" class="menulink" id="btnMarcar'. $contador.'"  value="Marcar tel. '.$contador.'" onclick="this.disabled=true;AbreVentana(this,'.$contador .', \''. $nomina.'\',\''.$datos_cliente[$indice]['CLAVELADA'] . $datos_cliente[$indice]['TELEFONO'].'\',\''.$id_solicitud.'\','.$extenagente.',\''. $cc.'\');"/-->
                                    <td ><input class="label" type="text" size="25" name="tel_' . $contador . '" id="tel_' . $contador . '" value="' .$datos_cliente[$indice]["LOCALIZACIONRT"]./*.$datos_cliente[$indice]['CLAVELADA'] . $datos_cliente[$indice]['TELEFONO'] .*/ '" readonly></td>
                                    <td>';
                        }
                        if (strlen($datos_cliente[$indice]["TELEFONO"]) > 0) {
                            $cal_en_curso = explode("|", get_session_varname("calificados"));
                            for($var = 0; $var < $var_c = count($cal_en_curso) - 1; $var++)
                            {
                                    $cal_en_curso[$var] = explode(",", $cal_en_curso[$var]);
                            }
                            echo '<select name="tel_0' . $contador . '" id="tel_0' . $contador . '" style="width:300px" onchange="revisa_calificacion_test(this, 1, ' . $id_solicitud . ', tel_' . $contador . '.value, ' . $contador . ');">
                                                            <option value="0">Elige opci&oacute;n</option>' . "\r\n";

                            //Cambia el tipo de base a SN, para manuales que no sean Sponsor.

                            $cal_NC = get_cal_NC(1, $db);



                            $cal_selected = "";
                            for($var = $var_c - 1; $var >= 0; $var--){
                                if($cal_en_curso[$var][1] == $contador) {
                                    $cal_selected = $cal_en_curso[$var][0];
                                    break;
                                }
                            }
                            while (!$cal_NC->EOF) {
                                //echo  $contador;
                                $selected = "";
                                if (get_session_varname("caltelefono" . $contador) == $cal_NC->fields['U_ESTATUSLLAMADA']) {
                                    $selected = "selected";
                                } else {
                                    $selected = " ";
                                }
                                if (count($cal_en_curso) > 1){
                                    if ($cal_selected == $cal_NC->fields['U_ESTATUSLLAMADA']) {
                                            $selected = "selected";
											$count_selected++;
                                    } else {
                                            $selected = " ";
                                    }
                                }


                                if ($cal_NC->fields['REFERIDO'] == 'B'){
                                    echo "<option ".$selected." style='background-color:Red;' value=\"{$cal_NC->fields['U_ESTATUSLLAMADA']}\">{$cal_NC->fields['TIPO_CONTACTO']} - {$cal_NC->fields['ESTATUS']} ({$cal_NC->fields['U_ESTATUSLLAMADA']}) [{$cal_NC->fields['REFERIDO']}] </option>\r\n";
                                } else
                                {
                                    echo "<option ".$selected." value=\"{$cal_NC->fields['U_ESTATUSLLAMADA']}\">{$cal_NC->fields['TIPO_CONTACTO']} - {$cal_NC->fields['ESTATUS']} ({$cal_NC->fields['U_ESTATUSLLAMADA']}) [{$cal_NC->fields['REFERIDO']}]</option>\r\n";
                                }

                                $cal_NC->MoveNext();
                            }
                            echo "</select>\r\n";
                        } else {
                            echo "&nbsp;";
                        }
                        echo '</td>
                                </tr>' . "\r\n";
                        $contador++;
                    }
                    if($t_registro == 0){
                        set_session_varname('arrayTels', $arrayTels);
                    }

                    ?>
                    <tr>
                        <td colspan="4">&nbsp;<input type="hidden" name="cont" value="<?= $contador - 1 ?>" id="cont"></td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2" class="textleft"><b>PRODUCTO:&nbsp;</b></td>
                        <td colspan="2" class="label">
                            <select name="producto_">                                
                                <?php echo $prods_; ?>
                                <!-- <option value="1">ACCIDENTES PERSONALES</option>
                                <option value="2">HOSPITAL CASH</option> -->
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>

                    <tr>
                        <td colspan="4">Seleccione de la lista una opci&oacute;n en cuanto haga contacto con cualquier persona de los distintos telefonos</td>
                    </tr>
                    <tr>
                        <td colspan="4">&nbsp;</td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <?php
						if($aprocesado != 1){
                            if ($isPredictivo2 == 1) {
                                ?>
                                <input id="btnContinuar" type="button" class="custionario_boton" value="Continuar" title="pred"  onclick="this.disabled = true;
                                        Continuar(this,<?= $contador - 1 ?>, '<?= encripta(4) ?>', 1, <?php echo $nomina.", ".$id_solicitud ?>)"/>&nbsp;&nbsp;<!--id="obRegistroPredContinuar"-->
                                        <input type="button" class="custionario_boton" value="Abandonar" id="btnAbandonar" onclick="this.disabled = true;
                                    AbandonarV2(this,<?= $contador - 1 ?>, '<?= encripta(18) ?>', null, <?php echo $nomina.", ".$id_solicitud ?>)"/>
									&nbsp;&nbsp;
                            <?php } elseif($isPredictivo2 == 3) { ?>
                                <input type="button" class="custionario_boton" value="Continuar" id="obRegistroAsisContinuar" onclick="this.disabled = true;
                                        Continuar(this,<?= $contador - 1 ?>, '<?= encripta(4) ?>', 3)"/>&nbsp;&nbsp;
                            <?php } else { ?>
                                <input type="button" class="custionario_boton" value="Continuar" id="obRegistroAsisContinuar" onclick="this.disabled = true;
                                        Continuar(this,<?= $contador - 1 ?>, '<?= encripta(4) ?>', 2, <?php echo $nomina.", ".$id_solicitud ?>)"/>&nbsp;&nbsp;

                                    <input type="button" class="custionario_boton" value="Abandonar" id="btnAbandonar" onclick="this.disabled = true;
                                    AbandonarV2(this,<?= $contador - 1 ?>, '<?= encripta(18) ?>', null, <?php echo $nomina.", ".$id_solicitud ?>)"/>
									&nbsp;&nbsp;
                            <?php } ?>
                            
                            
                <?php 	} else {
                                if ($isPredictivo2 == 1) {
                                ?>
                                <input id="btnContinuar" type="button" class="custionario_boton" value="Continuar" title="pred"  onclick="this.disabled = true;
                                        Continuar(this,<?= $contador - 1 ?>, '<?= encripta(4) ?>', 1, <?php echo $nomina.", ".$id_solicitud ?>)"/>&nbsp;&nbsp;<!--id="obRegistroPredContinuar"-->
                            <?php } else { ?>
                                <input type="button" class="custionario_boton" value="Continuar" id="obRegistroAsisContinuar" onclick="this.disabled = true;
                                        Continuar(this,<?= $contador - 1 ?>, '<?= encripta(4) ?>', 2, <?php echo $nomina.", ".$id_solicitud ?>)"/>&nbsp;&nbsp;
                            <?php } ?>
                                <!--<input type="button" class="custionario_boton"  value="Calificar Validador" id="btnCalificar" onclick="this.disabled=true;score();"/>&nbsp;&nbsp;-->
                                <input type="button" class="custionario_boton" value="Finalizar Venta" title="Finalizar la Venta y mandarla a validacion" onclick="this.disabled=true;Finalizar_venta('<?= encripta(43) ?>')"/>&nbsp;&nbsp;
                <?php 	}

		//}
				?>
                            <!-- <input type="button" class="custionario_boton" value="Nuevo Telefono" id="btnNuevoTelefono" onclick="this.disabled = true;
                                    Agregar_Telefono(this)"> -->
                            <?php
                            if($tipo_zona == 'SN' && trim($datos_cliente[0]['NOMBRE']) == '') {
                            ?>
                            <input type="button" class="custionario_boton" value="Actualizar Nombre" id="btnActNombre" onclick="this.disabled = true;
                                    Actualizar_Nombre(this)">
                            <?php } ?>
                        </td>
                    </tr>
                </table>
            </td>
            <!--td rowspan="2">
                <iframe class="cuestionario" style="height:150px;" src="modules.php?mod=agentes&op=estatus_registro" frameBorder="0" scrolling="auto" id="iframe1"></iframe>
            </td-->
        </tr>
    </table>




	<!-- <div id="div-oculto" style="width: 100%; height: 500px">hola mundo</div> -->
	<?php
		//echo get_session_varname("s_usr_marcacion");
		if($count_selected == $_REQUEST["cont"] and isset($count_selected) and isset($_REQUEST["cont"])) {
			if ($isPredictivo2 == 1)
				$var = "1";
			else
				$var = "2";
	?>
	<script>
	/*
		document.getElementById("obRegistroAsisContinuar").disabled = true;
		Continuar(document.getElementById("obRegistroAsisContinuar"),<?= $contador - 1 ?>, '<?= encripta(4) ?>', <?= $var ?>);
	*/
	</script>

	<?php
		}

	?>








</form>
<div class="element_to_pop_up" id="element_to_pop_up"></div>
<?
layout_footer();
if ($sc[0]==1 && $sc[1]!= null){
//    print_r($sc);
        echo '<script>$( document ).ready(function() {
                score();
              });</script>';
        echo '<input type="hidden"  value="'.$sc[1].'" id="antiguasolicitud">';
        unset_session_varname("sc");
        $sc='';
        unset($sc);
}
