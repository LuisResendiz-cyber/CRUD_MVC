const db = require("../db/mysql");

const CustomersModel = {

  async insertWebhookLog({ event_type, wamid, from_number = 0, status, message_text, role= "user", id_envio = 0, raw_json = null}) {
    const sql = `
      INSERT INTO WHATSAPP_WEBHOOK_LOG 
      (event_type, wamid, from_number, status, message_text, role, conversation_id, raw_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      String(event_type).substring(0, 20),
      wamid || null,
      from_number || null,
      status || null,
      message_text || null,
      role || null,
      id_envio || null,
      JSON.stringify(raw_json)
    ]);
  },
  async getOrCreateSession (sessionUuid, channel) {
    const [rows] = await db.query(
      "SELECT * FROM CHAT_SESSIONS WHERE session_uuid = ? AND channel = ?",
      [sessionUuid, channel]
    );
  
    if (rows.length) return rows[0];
  
    const [result] = await db.query(
      "INSERT INTO CHAT_SESSIONS (session_uuid, channel) VALUES (?, ?)",
      [sessionUuid, channel]
    );
  
    return {
      id: result.insertId,
      session_uuid: sessionUuid,
      channel,
      status: "bot"
    };
  },
  async getHistory(conversation_id){
    const [rows] = await db.query(
      `SELECT role, message_text
       FROM WHATSAPP_WEBHOOK_LOG
       WHERE conversation_id = ?
         AND channel = 'web'
       ORDER BY created_at ASC`,
      [conversation_id]
    );

    if (rows.length) return rows;
  }
};

module.exports = CustomersModel;
