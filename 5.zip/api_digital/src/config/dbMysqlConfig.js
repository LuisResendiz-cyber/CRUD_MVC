
import {createPool} from "mysql2/promise";
import { config } from 'dotenv';
config();
const ENVIRONMENT = process.env.NODE_ENV || "PRODUCCION";

const env = {
  host: ENVIRONMENT === "development" ? "172.20.1.149" : "172.20.1.97",
  user: ENVIRONMENT === "development" ? "lresendiz" : "msn_impulse",
  password: ENVIRONMENT === "development" ? "R3s3nd1z*" : "m5N1mpul53*",
  database: ENVIRONMENT === "development" ? "itachi" : "itachi"  
}



export const pool = createPool({
  host: env.host,
  user: env.user,
  password: env.password,
  database: env.database,
  waitForConnections: true,
  connectionLimit: 1, // Máximo número de conexiones simultáneas
  queueLimit: 0 // Sin límite en la cola de solicitudes
});


