module.exports = {
  // port: process.env.HTTP_PORT || 3013,
  port: process.env.HTTP_PORT || 10020,
  // DSA
  //keyRingHost: 'http://172.20.1.89:5000/key/getDataKeys?schema=TDCAMEXONLINE2'
  // keyRingHost: 'http://172.20.1.89:2137/api_keyring_citi/get_key?schema=citi',
  keyRingHost: 'http://172.20.1.89:2137/api_keyring_citi/get_key',
  keyRingRotate: 'http://172.20.1.89:2137/api_keyring_citi/rotate_key'

  // PROD
  // keyRingHost: 'http://172.23.62.183:2137/api_keyring_citi/get_key?schema=citi',
  // keyRingRotate: 'http://172.23.62.183:2137/api_keyring_citi/rotate_key'
  // keyRingHost: 'http://172.20.1.99:2137/api_keyring/get_key?schema=TDCAMEXONLINE2',
  // keyRingRotate: 'http://172.20.1.99:2137/api_keyring/rotate_key'

};
