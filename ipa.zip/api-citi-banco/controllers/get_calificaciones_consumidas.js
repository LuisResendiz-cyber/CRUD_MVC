const get_calificaciones_consumidas = require('../db_apis/get_calificaciones_consumidas.js');

async function post(req, res, next) {
  try {
    const context = req.body;//{};

    const respuesta = await get_calificaciones_consumidas.give(context);

    if (req.params.id) {
      if (respuesta.length === 1) {
        res.status(200).json(respuesta[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(respuesta);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
