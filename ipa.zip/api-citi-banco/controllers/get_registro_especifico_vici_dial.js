const get_registro_especifico_vici_dial = require('../db_apis/get_registro_especifico_vici_dial.js');
const fetch = require('node-fetch');
const jwt = require('./token_manager.js');
const config  = require('../config/web-server.js');

async function post(req, res, next) {
  try {
    const context = req.body;

    const respuesta = await get_registro_especifico_vici_dial.give(context);

    if (req.params.id) {
      if (respuesta.length === 1) {
        res.status(200).json(respuesta[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(respuesta);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
