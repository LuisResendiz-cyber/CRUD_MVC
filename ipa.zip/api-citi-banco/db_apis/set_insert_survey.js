const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
console.log(context);	 
const baseQuery = "BEGIN " + context.schema + ".PROC_INSERTSURVEYINT(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :responseDate, :responseNo, :Lang); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.varUserID || !context.varSurveyID || !context.varQuestionNo || !context.varChoiceNo || !context.responseDate || !context.responseNo || !context.Lang){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.varUserID      = context.varUserID;
            binds.varSurveyID      = context.varSurveyID;
            binds.varQuestionNo      = context.varQuestionNo;
            binds.varChoiceNo      = context.varChoiceNo;
            binds.responseDate      = context.responseDate;
            binds.Lang      = context.Lang;
            binds.responseNo      = context.responseNo;

            const result = await database.simpleExecute(query, binds);

console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;
