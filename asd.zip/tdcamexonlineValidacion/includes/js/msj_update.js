/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


$(function() {
    var name = $("#p1name"),
            name2 = $("#p2name"),
            apaterno = $("#apaterno"),
            amaterno = $("#amaterno"),
            solicitud = $("#solicitud"),
            allFields = $([]).add(name).add(apaterno).add(amaterno),
            tips = $(".validateTips");

    function updateTips(t) {
        tips
                .text(t)
                .addClass("ui-state-highlight");
        setTimeout(function() {
            tips.removeClass("ui-state-highlight", 1500);
        }, 500);
    }

    function checkLength(o, n, min, max) {
        if (o.val().length > max || o.val().length < min) {
            o.addClass("ui-state-error");
            updateTips("Length of " + n + " must be between " +
                    min + " and " + max + ".");
            return false;
        } else {
            return true;
        }
    }

    function checkRegexp(o, regexp, n) {
        if (!(regexp.test(o.val()))) {
            o.addClass("ui-state-error");
            updateTips(n);
            return false;
        } else {
            return true;
        }
    }

    $("#dialog-form").dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        buttons: {
            "Actualizar": function() {
                var bValid = true;
                allFields.removeClass("ui-state-error");

                bValid = bValid && checkLength(name, "name", 3, 16);
                bValid = bValid && checkLength(apaterno, "apaterno", 3, 16);
                bValid = bValid && checkLength(amaterno, "amaterno", 0, 16);

                bValid = bValid && checkRegexp(name, /^[a-z]([0-9a-z_])+$/i, "Username may consist of a-z, 0-9, underscores, begin with a letter.");
                // From jquery.validate.js (by joern), contributed by Scott Gonzalez: http://projects.scottsplayground.com/email_address_validation/
                bValid = bValid && checkRegexp(apaterno, /^[a-z]([0-9a-z_])+$/i, "eg. ui@jquery.com");
                bValid = bValid && checkRegexp(amaterno, /^[a-z]([0-9a-z_])+$/i, "Password field only allow : a-z 0-9");
                /*$().ready(function() {
                 debug: true,
                 $("#actdatos").validate();
                 });*/

                if (bValid) {
                    /*$( "#users tbody" ).append( "<tr>" +
                     "<td>" + name.val() + "</td>" +
                     "<td>" + apaterno.val() + "</td>" +
                     "<td>" + amaterno.val() + "</td>" +
                     "<td>" + solicitud.val() + "</td>" +
                     "</tr>" );*/
                    window.location = 'modules.php?mod=agentes&op=process_data&act=MzU=&nombre=' + name.val() + '&nombre2=' + name2.val() + '&apaterno=' + apaterno.val() + '&amaterno=' + amaterno.val() + '&solicitud=' + solicitud.val();
                    $(this).dialog("close");
                }
            },
            Cancel: function() {
                $(this).dialog("close");
            }
        },
        close: function() {
            allFields.val("").removeClass("ui-state-error");
        }
    });

    $("#create-user")
            .button()
            .click(function() {
                $("#dialog-form").dialog("open");
            });
});
      