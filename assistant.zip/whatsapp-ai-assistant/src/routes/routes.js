const express = require('express');
const router = express.Router();
const CustomerController = require("../controllers/customerController");


router.get('/getCustomers',CustomerController.getCustomers);

module.exports = router;
