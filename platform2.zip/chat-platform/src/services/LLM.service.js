const axios = require("axios");

const OLLAMA_URL = "http://localhost:11434/api/generate";
const MODEL = "phi3:latest";

function buildKnowledgeContext(knowledgeList = []) {
  if (!knowledgeList.length) return "NO HAY INFORMACIÓN DISPONIBLE.";

  return knowledgeList.map((k) => `• ${k.title}:\n${k.content}`).join("\n\n");
}

const LLMService = {
  async generate({ systemPrompt, userMessage, knowledge }) {
    const knowledgeContext = buildKnowledgeContext(knowledge);

    const finalPrompt = `
${systemPrompt}

==============================
CONTEXTO DE CONOCIMIENTO
(ÚNICA Y EXCLUSIVA FUENTE)
==============================
${knowledgeContext}

==============================
REGLA ABSOLUTA
==============================
Si la respuesta NO está CONTENIDA TEXTUALMENTE
en el CONTEXTO DE CONOCIMIENTO:

- NO expliques
- NO des contexto
- NO definas conceptos generales
- NO intentes ayudar
- NO menciones que es un tema distinto

DEBES responder ÚNICAMENTE y EXACTAMENTE:
"No cuento con esa información por el momento. Un asesor humano podrá ayudarte mejor 😊"

NO escribas nada más.

==============================
PREGUNTA DEL USUARIO
==============================
${userMessage}
`;

    const response = await axios.post(OLLAMA_URL, {
      model: MODEL,
      prompt: finalPrompt,
      stream: false,
      options: {
        temperature: 0,
        top_p: 0.1,
        repeat_penalty: 1.2,
      },
    });

    return response.data.response.trim();
  },
  async generateChat({ userMessage }) {
    const prompt = `
  Eres un agente virtual de atención al cliente.
  Responde de forma natural, empática y profesional.
  
  REGLAS:
  - No proporciones información técnica
  - No inventes datos
  - No prometas soluciones específicas
  - Ofrece ayuda humana si es necesario
  
  Mensaje del usuario:
  "${userMessage}"
  `;

    const response = await axios.post(OLLAMA_URL, {
      model: MODEL,
      prompt,
      stream: false,
      options: {
        temperature: 0.4,
      },
    });

    return response.data.response.trim();
  },
  async generateGreeting({ userMessage }) {
    const prompt = `
Eres un agente virtual de atención al cliente.

Tu objetivo es responder SALUDOS de forma:
- Breve
- Natural
- Profesional
- Sin explicaciones innecesarias

REGLAS:
- Responde SOLO con un saludo.
- Elige correctamente entre:
  - "Buenos días"
  - "Buenas tardes"
  - "Buenas noches"
  según el momento del día.
- Sé amable y cercano.
- NO proporciones información de servicios.
- NO hagas preguntas complejas.
- Mantén la respuesta corta.
- Invita sutilmente a continuar la conversación.
- NO des contexto adicional

Tu respuesta debe:
- Ser una sola frase
- Invitar al usuario a hacer su consulta

EJEMPLOS (NO LOS REPITAS):
- "¡Buenos días! 😊 ¿En qué puedo ayudarte?"
- "¡Buenas tardes! Estoy aquí para ayudarte."
- "¡Buenas noches! ¿Qué información te gustaría conocer?"

MENSAJE DEL USUARIO:
"${userMessage}"
`;

    try {
      const response = await axios.post(OLLAMA_URL, {
        model: MODEL,
        prompt,
        stream: false,
        options: {
          temperature: 0.6, // naturalidad
          top_p: 0.9,
          repeat_penalty: 1.1,
        },
      });

      return response.data.response.trim();
    } catch (error) {
      console.error("Error en generateGreeting:", error.message);
      return "¡Hola! 😊 ¿En qué puedo ayudarte?";
    }
  },
  async generateOpinion({ userMessage }) {
    const prompt = `
  Eres un agente virtual de atención al cliente.
  
  OBJETIVO:
  Responder opiniones, comentarios personales o desconfianza del usuario
  de forma empática, profesional y calmada.
  
  REGLAS OBLIGATORIAS:
  - NO contradigas al usuario
  - NO intentes convencer
  - NO defiendas a la empresa
  - NO discutas
  - NO hagas promesas
  - NO menciones políticas, leyes o temas externos
  
  TONO:
  - Empático
  - Respetuoso
  - Cercano
  - Profesional
  
  INSTRUCCIONES:
  - Valida cómo se siente el usuario
  - Agradece que lo comparta
  - Mantén la respuesta corta
  - Invita a continuar la conversación
  - Si es apropiado, ofrece apoyo humano sin insistir
  
  EJEMPLOS (NO LOS REPITAS):
  - "Entiendo cómo te sientes, gracias por decirlo."
  - "Aprecio que compartas tu opinión."
  - "Es válido tener dudas, estoy aquí para ayudarte."
  
  MENSAJE DEL USUARIO:
  "${userMessage}"
  `;

    try {
      const response = await axios.post(OLLAMA_URL, {
        model: MODEL,
        prompt,
        stream: false,
        options: {
          temperature: 0.7,
          top_p: 0.9,
          repeat_penalty: 1.1,
        },
      });

      return response.data.response.trim();
    } catch (error) {
      console.error("Error en generateOpinion:", error.message);
      return "Gracias por compartir tu opinión 😊 Estoy aquí para ayudarte.";
    }
  },
  async generateFarewell({ userMessage }) {
    const prompt = `Eres un asistente de atención al cliente.

    Debes responder DESPEDIDAS de forma:
    - Muy breve
    - Natural
    - Profesional
    - Amable
    
    REGLAS:
    - NO hagas preguntas
    - NO des información adicional
    - NO intentes continuar la conversación
    - Responde con UNA sola frase
    
    Ejemplos válidos:
    - "¡Gracias! Que tengas un excelente día 😊"
    - "Con gusto. ¡Hasta luego!"
    - "Gracias por contactarnos. ¡Buen día!"
    - "¡Hasta pronto!"
       
    MENSAJE DEL USUARIO:
  "${userMessage}"
    `;

    try {
      const response = await axios.post(OLLAMA_URL, {
        model: MODEL,
        prompt,
        stream: false,
        options: {
          temperature: 0.3,
          top_p: 0.8,
        },
      });

      return response.data.response.trim();
    } catch (error) {
      console.error("Error en generateOpinion:", error.message);
      return "Gracias por compartir tu opinión 😊 Estoy aquí para ayudarte.";
    }
  },

  async generateFarewellSoft({ userMessage }) {
    const prompt = `Eres un asistente de atención al cliente.

    El usuario está agradeciendo o cerrando la conversación de forma amable.
    
    Debes responder:
    - De forma breve
    - Sin hacer preguntas
    - Sin continuar la conversación
    - Agradeciendo o cerrando amablemente
    
    Ejemplos válidos:
    - "¡Con gusto! Que tengas un excelente día 😊"
    - "Gracias a ti. ¡Estamos para ayudarte!"
    - "Un placer ayudarte. ¡Buen día!"
       
    MENSAJE DEL USUARIO:
  "${userMessage}"
    `;

    try {
      const response = await axios.post(OLLAMA_URL, {
        model: MODEL,
        prompt,
        stream: false,
        options: {
          temperature: 0.3,
          top_p: 0.8,
        },
      });

      return response.data.response.trim();
    } catch (error) {
      console.error("Error en generateOpinion:", error.message);
      return "Gracias por compartir tu opinión 😊 Estoy aquí para ayudarte.";
    }
  },
  
};

module.exports = LLMService;
