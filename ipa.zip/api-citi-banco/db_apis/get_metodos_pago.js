const oracledb = require('oracledb');
const database = require('../services/database.js');

// async function find(context) {

//  const baseQuery = "BEGIN " + context.schema + ".GET_METODOS_PAGO(:p_u_persona, :keys, :rc); END;";
//  const baseQuery = "BEGIN " + context.schema + ".GET_METODOS_PAGO(:p_u_persona, :rc); END;";
//   console.log(context);
//    let query = baseQuery;
//    const binds = {}; //Define un objeto para la variable SP
//    let result2 = {};
//
//    if(!context.u_persona){
//      //console.log("Parametros incorrectos")
//      result2.error_ = true;
//      result2.mensaje = "Parametros Erroneos";
//      return result2;
//
//    }else{
//
//     binds.p_u_persona = context.u_persona;
//     // binds.keys      = '1';
//     binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
//
//     const result = await database.simpleExecuteRC(query, binds);
//      console.log(result);
//     return result;
//   }
// }

async function give(context){
  console.log(context);
  // const baseQuery = "BEGIN " + context.schema + ".GET_METODOS_PAGO(:p_u_persona, :keys, :rc); END;";
  const baseQuery = "BEGIN " + context.schema + ".GET_METODOS_PAGO(:p_u_persona, :rc); END;";
  let query = baseQuery;

  const binds = {};
  let result2 = {};

  if(!context.u_persona){
    // if(!context.u_persona || !context.keyrig){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.p_u_persona      = context.u_persona;
    // binds.keys      = context.keyrig;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    console.log(binds);
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;

  }
}

// module.exports.find = find;
module.exports.give = give;
