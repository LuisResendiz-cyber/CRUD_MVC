<?php
# CargaRemesas File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize("mesa_control","Actualizacion de Registros");
layout_menu($db ,"");
?>

<b>D&eacute; click en el bot&oacute;n examinar para seleccionar el archivo.</b><br>
Recuerda que los datos del archivo deben ser de una solo clasificaci&oacute;n (Caidos Impulse, Caidos Banco, Recuperadas, Aceptadas, Canceladas)<br>
<form name="frm1" method="post" action="modules.php?mod=mesa_control&op=process_data&act=6" enctype="multipart/form-data">
    <table width="45%" align="left" border="0">
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr><tr>
            <td colspan="2"><b>Archivo:</b>&nbsp;<input type="file" name="fichero" size="50" ></td>
        </tr><tr>
            <td colspan="2">&nbsp;</td>
        </tr><tr>
            <td colspan="2">
                <input type="hidden" name="action_val" value="upload">
                <input type="button" value="Pantalla Anterior" onclick="back()"/>&nbsp;&nbsp;
                <input type="button" name="continuar" value="Continuar" onclick="validaFicheroForm()" />
            </td>
        </tr>
    </table>
</form>
<?
realpath('modules/Files_remesas/load_data.ctl');

layout_footer();
?>