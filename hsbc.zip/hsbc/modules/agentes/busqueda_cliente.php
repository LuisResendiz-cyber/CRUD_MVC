<?php
# @uthor Mark
# Index File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Busqueda de Clientes");
layout_menu($db);
?>	
<p class="textbold">Agentes &gt; Busqueda de Clientes</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=resultado_busq_cliente" name="frm1">
<table class="text" border="0">
    <tr>
        <td width="60%">
            <table border="0">
                <tr>
                    <td colspan="3">&nbsp;</td>
                </tr><tr>
                    <td colspan="2">Introduzca alguno de los campos para realizar la b&uacute;squeda.</td>
                </tr><tr>
                    <td colspan="3">
                        <table border="0">
                            <tr>
                                <td class="textleft"><b>Solicitud: </b></td>
                                <td><input type="text" size="20" name="solicitud" id="solicitud" maxlength="10"></td>
                            </tr><tr>
                                <td class="textleft"><b>Nombre: </b></td>
                                <td><input type="text" size="20" name="nombre" id="nombre" maxlength="20" ></td>
                            </tr><tr>
                                <td class="textleft"><b>Apellido Paterno:</b>
                                <td><input type="text" size="20" name="paterno" id="paterno" maxlength="20" ></td>
                            </tr><tr>
                                <td class="textleft"><b>Apellido Materno:</b>
                                <td><input type="text" size="20" name="materno" id="materno" maxlength="20" ></td>
                            </tr><tr>
                                <td class="textleft"><b>N&uacute;mero Telef&oacute;nico: </b>
                                <td><input type="text" size="10" name="telefono" id="telefono" maxlength="10" ></td>
                            </tr>
                        </table>
                        <br>
                    </td>
                </tr><tr>
                    <td colspan="3">
                        <input type="button" value="Buscar" onclick="this.disabled=true;BuscarCliente(this)"/>&nbsp;&nbsp;
                        <!--input type="button" value="Buscar" onclick="alert('No habilitado por el momento')"/>&nbsp;&nbsp;-->
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</form>
<?
layout_footer();
?>