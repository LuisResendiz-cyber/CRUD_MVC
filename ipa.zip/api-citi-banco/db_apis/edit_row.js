const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  console.log('**funcion para llamar a EDIT_ROW_SIM** ');
  console.log(context);
  const baseQuery = "BEGIN "+context.schema+".EDIT_ROW_SIM(:id, :tabla, :perfil, :estatus, :permisos, :response); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(context.schema==''){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.id = context.id;
    binds.tabla = context.tabla;
    binds.perfil = context.perfil;
    binds.estatus = context.estatus;
    binds.permisos = context.permisos;  
    binds.response = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_NUMBER};
    const result = await database.simpleExecute(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;