// lib/configoracle.js
const oracledb = require('oracledb');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const ENVIRONMENT = process.env.ENVIRONMENT || 'development';

console.log(ENVIRONMENT);


let pool;

async function initOraclePool() {
  try {
    pool = await oracledb.createPool({
      user: process.env.USERDB_ORACLE,
      password: process.env.PASS_ORACLE,
      connectString: ENVIRONMENT === "development"
        ? "172.20.1.35/XE"
        : "192.168.1.14/xccmtaf",           
      poolMin: 1,
      poolMax: 5,
      poolIncrement: 1,
      queueTimeout: 60000
    });

    console.log('Oracle pool creado, Conexion Exitosa');
  } catch (err) {
    console.error('Error creando Oracle pool:', err.message);
    process.exit(1);
  }
}

function getOraclePool() {
  if (!pool) {
    throw new Error('El pool de Oracle no ha sido inicializado. Llama a initOraclePool primero.');
  }
  return pool;
}

module.exports = {
  initOraclePool,
  getOraclePool
};