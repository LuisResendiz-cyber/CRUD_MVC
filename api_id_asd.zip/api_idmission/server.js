
const httpsServer = require('./app')
const PORT = process.env.PORT || 4000; 


httpsServer.listen(PORT, () => { console.log(`API runing on port ${PORT} https://localhost:${PORT}`) })

