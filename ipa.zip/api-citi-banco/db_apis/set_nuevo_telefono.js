const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN "+ context.schema +".XSP_SETNUEVOTELEFONO2(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :v_u_user, :v_bl_reus); END;";
// const baseQuery = "BEGIN "+ context.schema +".XSP_SETNUEVOTELEFONO2(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :v_u_user, :v_bl_reus, :keys); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};
        //console.log('____', context, '____');

        if(!context.v_u_persona || !context.v_lada || !context.v_telefono || !context.v_tipo|| !context.v_u_user){
          // if(!context.v_u_persona || !context.v_lada || !context.v_telefono || !context.v_tipo|| !context.v_u_user||context.keys== ''){
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;
          console.log('+++', result2, '+++');

        }else{
            console.log('aqui');
            binds.v_u_persona = {val:parseInt(context.v_u_persona) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER};
            binds.v_lada = context.v_lada;
            binds.v_telefono = context.v_telefono;
            binds.v_tipo =  {val:parseInt(context.v_tipo) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER};
            binds.v_u_user = {val:parseInt(context.v_u_user) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER};
            binds.v_bl_reus = {val:context.v_bl_reus, dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
            // binds.keys      = context.keyrig;

            const result = await database.simpleExecute(query, binds);

            //console.log('---', result, '---');	

            return result;
        }            
}
 
module.exports.find = find;




/*
function set_nuevo_telefono($id_solicitud, $lada, $telefono, $tipo, $db) {
    $stmt = $db->PrepareSP("BEGIN xsp_setNuevoTelefono(:v_u_persona, :v_lada, :v_telefono, :v_tipo); END;");
    $db->InParameter($stmt, $id_solicitud, 'v_u_persona');
    $db->InParameter($stmt, $lada, 'v_lada');
    $db->InParameter($stmt, $telefono, 'v_telefono');
    $db->InParameter($stmt, $tipo, 'v_tipo');
    $db->Execute($stmt);
}
*/