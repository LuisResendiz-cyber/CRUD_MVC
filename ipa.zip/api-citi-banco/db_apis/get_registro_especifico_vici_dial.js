const oracledb = require('oracledb');
const database = require('../services/database.js');

async function give(context){
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".XSP_GETREGISTROESP_VICI_DIAL(:v_telefono, :v_numcliente, :v_agente, :v_u_persona, :rc); END;";
  let query = baseQuery;
  const binds = {};
    try {      
      binds.v_telefono   = context.telefono;
      binds.v_numcliente  = context.numcliente;
      binds.v_agente   = context.v_agente;
      binds.v_u_persona   = context.u_persona;
      binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
      const result = await database.simpleExecuteRC(query, binds);
      return result;
    } catch (error) {
      console.log(error);
    }

  
}

module.exports.give = give;
