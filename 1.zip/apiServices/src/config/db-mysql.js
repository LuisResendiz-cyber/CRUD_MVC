const mysql = require('mysql2/promise');

const ENVIRONMENT = process.env.NODE_ENV;

const envO = {
  host: ENVIRONMENT === "development" ? "172.20.1.149" : "172.20.1.97",
  user: ENVIRONMENT === "development" ? "lresendiz" : "msn_impulse",
  password: ENVIRONMENT === "development" ? "R3s3nd1z*" : "m5N1mpul53*"  
}

// const pool = mysql.createPool({
//   host: envO.host,
//   user: envO.user,
//   password: envO.password,
//   database: 'itachi',
//   waitForConnections: true,
//   connectionLimit: 2, 
//   queueLimit: 0
// })

async function connItahi() {
  return await mysql.createConnection({
    host: envO.host,
    user: envO.user,
    password: envO.password,
    database: 'itachi',
  });
}


async function connTocImpulse() {
  return await mysql.createConnection({
    host: '67.20.76.217',
    user: 'tocimpul_landingamexsms',
    password: 'U3F5LWmT7H(',
    database: 'tocimpul_landingamexsms'
  });
}

module.exports = { connItahi,connTocImpulse };



