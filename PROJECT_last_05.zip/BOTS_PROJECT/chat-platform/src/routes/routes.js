const express = require('express');
const router = express.Router();
const webchatController = require("../controllers/webchat.controller");

router.post("/webchat", webchatController.receiveMessage);
router.get("/history/:conversation_id", webchatController.historyConversation) 
//router.post("/human/message", webchatController.sendHumanMessage);
router.get("/messages", webchatController.getMessages);

module.exports = router;