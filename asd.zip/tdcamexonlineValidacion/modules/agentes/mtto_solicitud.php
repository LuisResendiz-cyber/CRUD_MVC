<?php
# @uthor Mark
# resultado_busq_cliente File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Resultado de la Busqueda");
layout_menu($db, "");

$customerid = ($_REQUEST['customerid'] != null ? $_REQUEST['customerid'] : 0);
$surveyid = ($_REQUEST['surveyid'] != null ? $_REQUEST['surveyid'] : 0);
$user = get_session_varname("s_usr_id");
$registros = set_datos_solicitud($customerid, $surveyid, $user, $db);

if ($registros->EOF) {
    $encontro = 0;
} else {
    $encontro = 1;
}
?>
<p class="textbold">Agentes &gt; Resultado de la Busqueda</p>
<p>&nbsp;</p>
<table border="1" align="center">
<?php
if (!$registros->EOF) {
    while (!$registros->EOF) {
        for ($i = 0; $i < $registros->FieldCount(); $i++) {
            $field = $registros->FetchField($i);
            ?>
            <tr>
                <th align="right"><?php echo $field->name ?></th>
                <td class="label"><?php echo $registros->fields[$i] ?></td>
            </tr>
            <?php
        }
        $registros->MoveNext();
    }
} else {
    echo "La solicitud no pertenece al agente que consulta.<br />\r\n";
}
?>
</table>
<?php
layout_footer();
?>