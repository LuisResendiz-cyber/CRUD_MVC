const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
  console.log(context);
const baseQuery = "BEGIN " + context.schema + ".xsp_setPreAvail(:p_usr_id,:p_customerid); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.p_usr_id     = context.s_usr_id;
  binds.p_customerid = context.p_id_solicitud;
  
  const result = await database.simpleExecute(query, binds);
  console.log(result); 
  return result;
}
 
module.exports.find = find;
