(function () {
  if (window.__CHAT_WIDGET_LOADED__) return;
  window.__CHAT_WIDGET_LOADED__ = true;

  const SCRIPT_TAG = document.currentScript;

  const CONFIG = {
    clientId: SCRIPT_TAG.getAttribute("data-client-id"),
    baseUrl: SCRIPT_TAG.src.replace("/embed.js", ""),
    baseUrlUser: "http://localhost:4001/",
  };

  if (!CONFIG.clientId) {
    console.warn("Chatbot: data-client-id no definido");
    return;
  }

  // 🔐 PASO 5.1 — VALIDAR CLIENTE CON BACKEND
  fetch(`${CONFIG.baseUrlUser}Users/init?client=${CONFIG.clientId}`)
    .then(res => res.json())
    .then(init => {
      if (!init.active) {
        console.warn("Chatbot: cliente inactivo o no autorizado");
        return;
      }

      // 👉 Guardar contexto mínimo global
      window.__CHATBOT_CONTEXT__ = {
        customerId: init.customerId,
        botId: init.bot.id,
        botTipo: init.bot.tipo,
        botNombre: init.bot.nombre
      };

      renderWidget(CONFIG);
    })
    .catch(err => {
      console.error("Chatbot init error:", err);
    });

  // =========================
  // RENDER DEL WIDGET
  // =========================
  function renderWidget(CONFIG) {
    /* =========================
         ESTILOS
      ========================== */
    const style = document.createElement("style");
    style.innerHTML = `
      #chat-launcher {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: #d32f2f;
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 24px;
        box-shadow: 0 6px 20px rgba(0,0,0,.25);
        z-index: 999999;
      }

      #chat-iframe {
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 360px;
        height: 520px;
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 40px rgba(0,0,0,.2);
        z-index: 999999;
        display: none;
        background: transparent;
      }

      @media (max-width: 400px) {
        #chat-iframe {
          right: 0;
          bottom: 0;
          width: 100%;
          height: 100%;
          border-radius: 0;
        }
      }
    `;
    document.head.appendChild(style);

    /* =========================
         BOTÓN
      ========================== */
    const button = document.createElement("button");
    button.id = "chat-launcher";
    button.innerHTML = "💬";

    /* =========================
         IFRAME
      ========================== */
    const iframe = document.createElement("iframe");
    iframe.id = "chat-iframe";

    // 👉 SOLO PASAMOS clientId (nada sensible)
    iframe.src = `${CONFIG.baseUrl}/widget.html?clientId=${CONFIG.clientId}`;
    iframe.allow = "clipboard-write";

    /* =========================
         TOGGLE
      ========================== */
    let isOpen = false;

    button.addEventListener("click", () => {
      isOpen = !isOpen;
      iframe.style.display = isOpen ? "block" : "none";
    });

    document.body.appendChild(button);
    document.body.appendChild(iframe);

    window.addEventListener("message", (event) => {
      if (!event.data) return;

      if (event.data.type === "CHAT_WIDGET_CLOSE") {
        isOpen = false;
        iframe.style.display = "none";
      }
    });

    iframe.addEventListener("load", () => {
      isOpen = true;
      iframe.style.display = "block";
    });        
  }
})();
