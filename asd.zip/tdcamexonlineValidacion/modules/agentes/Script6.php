<?php
/*require_once("includes/includes.inc.php");
require_once("agentes.inc.php");*/

function darSaludo() {
    $iHora = date('H');

    if ($iHora >= 0 && $iHora < 12) {
        $sSaludo = "Buenos d&iacute;as";
    } else if ($iHora >= 12 && $iHora <= 19) {
        $sSaludo = "Buenas tardes";
    } else {
        $sSaludo = "Buenas noches";
    }

    return $sSaludo;
}

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agentes", "Script");

$u_persona = $_SESSION['datos_persona'][0]['U_PERSONA'];
//$rfc = $_SESSION['datos_persona'][0]['RFC'];
$nombre = $_SESSION['s_usr_nombre'];
//$apaterno = $_SESSION['datos_persona'][0]['APATERNO'];        
echo "<pre>";
 $productos_ = get_productos_campana($u_persona, $db);
 //print_r($productos_);
echo "</pre>";
$datos = get_datos_query2('XSP_GETDATOSCLIENTEINICIO_1('.$u_persona.',:rc)',$db);

echo "<pre>";
//print_r($datos);
echo "</pre>";
?>


    <table width="360" cellpadding="0" cellspacing="0">
        <tr>
            <td width="354" height="165" colspan="2" bgcolor="#FFFFF9" align="center">
                <div class=Section1>

                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=576
                           style='width:432.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes;
                            height:123.75pt'>
                            <td width=576 style='width:432.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                height:123.75pt'>
                                <p align=center style='text-align:center'><span style='font-size:9.0pt;
                                                                                font-family:Arial'>Logo <span class=SpellE>Amex</span><o:p></o:p></span></p>
                                <p class=style13 align=center style='text-align:center'><span class=SpellE><span
                                            style='font-size:9.0pt'>Script</span></span><span style='font-size:9.0pt'>
                                        <span class=SpellE>Venta CONVERSION</span><o:p></o:p></span></p>
                                <p class=MsoNormal align=center style='text-align:center'><strong><span
                                            style='font-size:9.0pt;font-family:Arial;color:blue'>No. de Solicitud: <?php echo $u_persona; ?> <br>Producto Origen: <?php echo$productos_->_array[$t]['NOMBRE'];?></span></strong><span
                                        style='font-size:9.0pt;font-family:Arial;color:blue'> <br style='mso-special-character:
                                                                                              line-break'>
                                        <![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
                                        <![endif]><o:p></o:p></span></p>
                                <div align=center>
                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=504
                                           style='width:378.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>PRESENTACI&Oacute;N<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:1;height:14.25pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:14.25pt'>
                                                <p><span style='font-size:9.0pt;font-family:Arial'><?php echo darSaludo(); ?> mi nombre es 
                                                        </span><span class=style151><b
                                                                style='mso-bidi-font-weight:normal'><span style='color:windowtext'></span></b></span>
                                                        <b style='mso-bidi-font-weight:normal'><?php echo $nombre.","; ?></b>
                                                        me podr&iacute;a comunicar con el Sr/Srita. 
                                                        <b style='mso-bidi-font-weight:normal'><span style='color:windowtext'></span></b></span>
                                                        <b style='mso-bidi-font-weight:normal'><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>. Muchas gracias.
                                                        <br>
                                            </td>                                            
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>ESCENARIO NO CONTESTA<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>                                        
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p><span class=style31><b><span style='font-size:9.0pt;font-style: italic;'>
                                                (No se encuentra se termina la llamada mencionando el tel&eacute;fono de localizaci&oacute;n.
                                                Y se pregunta alg&uacute;n horario disponible, mencionando la intenci&oacute;n de brindarle
                                                informaci&oacute;n valiosa de American Express.)
                                                </span></b></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>ESCENARIO CONTESTA<o:p></o:p></span></b></p>
                                            </td>
                                        </tr> 
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                Me da mucho gusto saludarlo Sr./Srita. <b><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>, 
                                                mi nombre es: <b><?php echo $nombre; ?>.</b>
                                                </span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                Esta es una llamada de servicio y es muy grato informarle que American Express
                                                hizo un an&acirc;lisis del historial de <b>La Tarjeta (Green)</b> que tiene actualmente con
                                                nosotros y debido al perfil y buen manejo que tiene de la misma, American Express
                                                ha decidido aumentar los beneficios con los que ya cuenta. Invit&acirc;ndolo a adquirir La
                                                exclusiva Tarjeta <b>The Gold Card</b> esta Tarjeta <b>ser&acirc; el pasaporte a m&ucirc;ltiples
                                                viajes, ahorros y recompensas.</b>                                                
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                Sr. / Srita. <b><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>, usted realiza viajes frecuentes ya sea por 
                                                negocio o por placer? Le gustar&iacute;a poder viajar de ahora en adelante disfrutando de mayor
                                                comodidad, mayor protecci&oacute;n y gozando de atractivos descuentos? 
                                                </span></span></p>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>BENEFICIOS<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm; height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Con La Tarjeta The Gold Card American Express podr&acirc; hacerlo de ahora en adelante
                                                    disfrutando de mayor comodidad incluso antes de abordar el avi&oacute;n, ya que tendr&acirc;
                                                    <b>acceso ilimitado a las salas de espera Centurion Club</b> ubicadas en los
                                                    principales aeropuertos del pa&iacute;s. (Ciudad de M&eacute;xico, Guadalajara, Toluca y
                                                    Monterrey) Donde podr&acirc; disfrutar de servicios como: Men&uacute; Gourmet, Televisi&oacute;n, 
                                                    internet Wi-Fi, Est&ecaron;tica, Spa, Centro de Negocios, Regaderas adem&acirc;s de una sala de
                                                    entretenimiento para ni&ntilde;os.
                                                </span></span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>                                                
                                                    Contar&aacute; tambi&eacute;n con la membres&iacute;a Priority Pass sin costo, la cual le permitir&aacute;
                                                    tener acceso a m&aacute;s de 600 salas de espera VIP en distintos aeropuertos alrededor
                                                    del mundo incluyendo las principales ciudades de Estados Unidos y Europa. (Est&aacute;
                                                    membres&iacute;a tiene un costo al p&uacute;blico de $99USD)
                                                </span></span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                            Adem&aacute;s para que usted siga viajando contar&aacute; con 4 membres&iacute;as <b>sin costo</b> de las
                                                    Cadenas Hoteleras m&aacute;s importantes, que le otorgan beneficios como: upgrades de
                                                    habitaci&oacute;n, descuentos en alimentos y bebidas o en el SPA, late check out , ascenso
                                                    de habitaci&oacute;n etc. Las cadenas hoteleras participantes son (Farimont, Ipreffered,
                                                    Radisson y Mel&iacute;a)
                                                </span></span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Tambi&eacute;n usted contar&aacute; con descuentos en aerol&iacute;neas participantes como un <b>15%
                                                    de descuento en todas las rutas en tarifa econ&oacute;mica de Interjet.</b>
                                                </span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Adicional podr&aacute; gozar del programa <b>Membership Rewards sin costo de por vida</b>
                                                    con mayor flexibilidad al poder utilizar sus puntos, <b>para pagar con ellos todo lo
                                                    relacionado con sus viajes como boletos de avi&oacute;n, estancias de hotel,
                                                    renta de autos y m&aacute;s.</b>
                                                </span></span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Viajar&aacute; tambi&eacute;n siempre protegido y con tranquilidad ya que si su maleta se retrasa
                                                    o se pierde, usted ahora contar&aacute; con una mayor protecci&oacute;n de hasta $700 USD
                                                    reembolsables a su Tarjeta por evento. Y tambi&eacute;n contar&aacute; con mayor cobertura en
                                                    su seguro contra accidentes en viajes de hasta $250,000 USD, para que realice sus
                                                    viajes siempre con tranquilidad.
                                                </span></span></p>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>OPCI&Oacute;N SI EL TH MENCIONA QUE NO VIAJA<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                Con The Gold Card tendr&aacute; acceso autom&aacute;tico sin costo de por vida al programa
                                                Membership Rewards, mismo que crea una alianza con PAYBACK&REG;, un nuevo e
                                                innovador Programa de Lealtad en M&eacute;xico, que le dar&aacute; m&aacute;s valor por sus compras
                                                con La Tarjeta.
                                                </span></span></p>
                                                <br>
                                                <ol type="num">
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                <b>Paga</b> con su Tarjeta American Express y obtendr&aacute; 1 Punto por cada
                                                                D&oacute;lar Americano que gaste o su equivalente en Moneda Nacional.
                                                            </span></span></p>                                                        
                                                    </li>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                <b>Adem&aacute;s le llegar&aacute; a su domicilio un Monedero PAYBACK</b> con el
                                                                cual podr&aacute; obtener Puntos adicionales en los Establecimientos de los Socios
                                                                PAYBACK como Comercial Mexicana, Interjet, Nextel, 7-Eleven y gasolineras
                                                                Petro-7.
                                                            </span></span></p>
                                                    </li>
                                                </ol>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <b>Usted podr&aacute; elegir usar sus Puntos para intercambiar Recompensas</b> del
                                                    programa Membership Rewards o adquirir bienes y/o servicios en los
                                                    Establecimientos de los Socios PAYBACK de manera instant&aacute;nea.
                                                    Adem&aacute;s usted contar&aacute; con ofertas en distintos establecimientos en el cual podr&aacute;
                                                    obtener: Mensualidades sin intereses, descuentos, eventos exclusivos de
                                                    entretenimiento y mucho m&aacute;s.
                                                </span></span></p>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>BENEFICIOS DEL PROGRAMA MEMBERSHIP REWARDS<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <b>&iquest;Conoce el programa Membership Rewards?</b>
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <b>NO conoce el programa</b> Con este programa podr&aacute; acumular puntos por cada
                                                    compra que realice (1 pto por cada d&oacute;lar gastado o su equivalente en moneda
                                                    nacional) adem&aacute;s este programa es <b>sin costo de por vida</b> podr&aacute; obtener
                                                    recompensas de nuestro catalogo como: Electr&oacute;nicos, Joyer&iacute;a, monederos de
                                                    distintas tiendas departamentales e intercambiarlos por viajes, adem&aacute;s con su
                                                    tarjeta Gold gozar&aacute; de mayor flexibilidad al utilizar sus puntos, ya que <b>podr&aacute; pagar
                                                    con ellos todo lo relacionado con sus viajes como boletos de avi&oacute;n,</b>
                                                    estancias de hotel, renta de autos y m&aacute;s.                                                
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Esto es muy sencillo, cuando la transacci&oacute;n aparezca en el Edo. de cuenta usted
                                                    deber&aacute; llamar a Servicio a Cliente y ah&iacute; podr&aacute; pagar dichas compras ya sea total o
                                                    parcialmente con los puntos que tenga acumulados.
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <b>S&Iacute; conoce el programa</b> Ahora con The Gold Card el programa es <b>sin costo de
                                                    por vida</b> para usted y adem&aacute;s de poder intercambiar sus puntos por productos del
                                                    cat&aacute;logo gozar&aacute; de mayor flexibilidad al poder utilizar sus puntos, <b>para pagar con
                                                    ellos todo lo relacionado con sus viajes como boletos de avi&oacute;n, estancias
                                                    de hotel, renta de autos y m&aacute;s.</b>
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Esto es muy sencillo, cuando la transacci&oacute;n aparezca en el Edo. de cuenta usted
                                                    deber&aacute; llamar a Servicio a Cliente y ah&iacute; podr&aacute; pagar dichas compras ya sea total o
                                                    parcialmente con los puntos que tenga acumulados.
                                                </span></span></p>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>COSTO DE ANUALIDAD (EL CLIENTE ACEPTA EL CAMBIO DE SU TARJETA)<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>                                                
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    En este caso para brindarle un mejor servicio y preocupados por su
                                                    tranquilidad, su producto actual ser&aacute; reemplazado por The Gold Card conservando
                                                    el mismo n&uacute;mero de cuenta, fecha de corte y de aniversario, por lo que usted
                                                    pagar&aacute; la cuota de $375 USD m&aacute;s IVA hasta su pr&oacute;ximo aniversario que ser&aacute; la
                                                    misma fecha con la que cuenta hasta ahora. Y de la misma manera diferidos en 3
                                                    meses incluyendo hasta <b>5 Tarjetas adicionales sin costo de por vida.</b>
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Adem&aacute;s todos los cargos que tenga como: meses sin intereses, cargos recurrentes y
                                                    pagos diferidos se transferir&aacute;n de manera autom&aacute;tica. Adicionalmente le pedimos
                                                    que verifique con los proveedores de dichos cargos que se hayan migrado de forma
                                                    correcta.
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    &iquest;Tiene Ud. Alguna otra duda o pregunta acerca de este proceso?
                                                </span></span></p>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b>
                                                        <span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                            COSTO DE ANUALIDAD (EL CLIENTE DESEA QUEDARSE CON AMBAS TARJETAS)
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>                                                
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Todo esto es parte de la gran variedad de beneficios que usted podr&aacute; disfrutar al
                                                    adquirir La Tarjeta The Gold Card American Express, <b>Sin Costo durante el 1&cir; A&ntilde;o,</b>
                                                    a partir del segundo a&ntilde;o la cuota anual ser&aacute; del equivalente en moneda nacional de
                                                    $375 USD m&aacute;s IVA, diferidos en 3 meses incluyendo <b>hasta 5 Tarjetas adicionales
                                                    sin costo de por vida.</b>
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <b>"Recordar preguntar a qui&eacute;n le gustar&iacute;a extender los beneficios para
                                                    vender con supps"</b>
                                                </span></span></p>
                                                <br>                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b>
                                                        <span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                        DESPEDIDA    
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>                                                
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    American Express Company (M&eacute;xico), S.A. de C.V., con domicilio en Patriotismo 635,
                                                    Col. Ciudad de los Deportes, Delegaci&oacute;n Benito Ju&aacute;rez, C.P. 03710, M&eacute;xico, D.F.,
                                                    recaba sus datos personales para la realizaci&oacute;n de todas las actividades
                                                    relacionadas con las Tarjetas de Servicios de American Express. Para mayor
                                                    informaci&oacute;n consulte nuestro Aviso de Privacidad integral en
                                                    www.americanexpress.com.mx.
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Le reitero mi Nombre <?php echo $nombre; ?> ejecutivo/asesor de American Express, mi tel&eacute;fono
                                                    es _________, <b>lo dejo con mi compa&ntilde;ero (a)________de calidad quien validar&aacute;
                                                    su informaci&oacute;n y realizar&aacute; una grabaci&oacute;n en la cual usted autoriza su
                                                    nueva Tarjeta. Agradezco</b> y le felicito por su excelente decisi&oacute;n de formar parte
                                                    de los TH American Express que siga teniendo un(a) excelente <?php echo darSaludo(); ?> 
                                                    Hasta luego.
                                                </span></span></p>
                                                <br>                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b>
                                                        <span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                        EJEMPLO DE PREGUNTAS
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>                                                
                                                <br>
                                                <ol type="num">
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                <b>&iquest;Cu&aacute;ndo se cancela el producto anterior?</b>
                                                                En el momento que el TH active su nuevo producto en ese momento el producto anterior
                                                                quedar&aacute; inactivo.
                                                            </span></span></p>                                                        
                                                    </li>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                <b>&iquest;Si no me llega el nuevo pl&aacute;stico puedo seguir comprando con mi Tarjeta?</b>
                                                                La Tarjeta nueva le llegar&aacute; en un periodo de 10 d&iacute;as m&aacute;ximo despu&eacute;s de haber sido
                                                                aprobada. Mientras eso ocurre puede seguir utilizando el producto anterior sin ning&uacute;n
                                                                problema.
                                                            </span></span></p>
                                                    </li>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                <b>&iquest;Cu&aacute;ndo tengo que pagar mi cuota anual?</b>
                                                                Al conservar misma fecha de aniversario usted pagar&aacute; la nueva cuota hasta que le toque el
                                                                aniversario de su Tarjeta actual.
                                                            </span></span></p>
                                                    </li>
                                                </ol>                                              
                                            </td>
                                        </tr>                                        
                                    </table>
                                </div>
                            <p align=center style='text-align:center'>&nbsp;</p>
                        </td>
                    </tr>
                </table>