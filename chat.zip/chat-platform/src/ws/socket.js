const { Server } = require("socket.io");
const { processIncomingMessage } = require("../services/MessageFlow.service");

// 🔑 VARIABLE GLOBAL DEL MÓDULO
let ioInstance = null;

function initWebSocket(server) {
  const io = new Server(server, {
    cors: { origin: "*" }
  });

  // ✅ guardamos referencia
  ioInstance = io;

  io.on("connection", (socket) => {
    const { session_id } = socket.handshake.auth;

    if (!session_id) {
      console.warn("⚠️ Socket sin session_id");
      return;
    }

    socket.join(session_id);
    console.log("🟢 Socket unido a sesión:", session_id);

    socket.on("user_message", async (text) => {
      try {
        const reply = await processIncomingMessage({
          session_id,
          message: text,
          channel: "web"
        });

        if (reply) {
          io.to(session_id).emit("bot_message", reply);
        }

      } catch (err) {
        console.error(err);
        socket.emit("bot_message", "Ocurrió un error, intenta más tarde.");
      }
    });
  });
}

// 🔌 FUNCIÓN PÚBLICA (para agentes, sistema, etc.)
function emitToSession(sessionId, event, payload) {
  if (!ioInstance) {
    console.warn("⚠️ WebSocket no inicializado");
    return;
  }

  ioInstance.to(sessionId).emit(event, payload);
}

module.exports = {
  initWebSocket,
  emitToSession
};
