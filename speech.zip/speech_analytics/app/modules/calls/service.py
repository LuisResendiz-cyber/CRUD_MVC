from sqlalchemy.orm import Session
from . import models, schemas


def create_call(db: Session, call_data: schemas.CallCreate):
    new_call = models.Call(
        call_id=call_data.call_id,
        agent_id=call_data.agent_id,
        status="uploaded"
    )

    db.add(new_call)
    db.commit()
    db.refresh(new_call)

    return new_call
