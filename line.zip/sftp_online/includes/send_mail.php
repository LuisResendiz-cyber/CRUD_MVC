<?php

error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);


require 'PHPMailer/PHPMailerAutoload.php';


$data='IMPULSE_CC_DIGITAL_WINBACK_2023_07_26 01 05 03.csv';
$rs3 = array(
       "DESARROLLO" => 'dsa@impulse-telecom.com',
    //   "ULISES" => 'ujuarez@impulse-telecom.com',
    //   "BLANCA" => 'balegria@impulse-telecom.com',
     //   "DANIEL2" => 'danieluaeh@gmail.com',
     );

    echo $mensaje = '
    <div style="background: #d8fdf8;">
    <p> <b style="color: green;"> EXITO </b> en la carga automatica de archivos CSV para Insurance Digital</p>
    <p> Archivos cargados => <b style="color: black;"> '.$data.' </b></p>
    </div>
    '; 
    die();

    foreach ($rs3 as $key => $value) {
        // echo '<hr>'.$key.' -> '.$value;    
        $asunto = "ERROR EN CARGA AUTOMATICA DIGITAL";
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        $mail->Host = "mail.impulse-telecom.com.mx";
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = "reportes@impulse-telecom.com";
        $mail->Password = "R3p0rt32016";
        $mail->setFrom('reportes@impulse-telecom.com', 'impulse telecom');
        $mail->addAddress($value, '');
       
        $mail->isHTML(true);
        $mail->Subject = $asunto;  
        $mail->Body    = '
        <div style="background: #d8fdf8;">
        <p> <b style="color: red;"> Error </b> en la carga automatica de archivos CSV para Insurance Digital</p>
        <p> El archivo con errores es => <b style="color: red;"> '.$data.' </b></p>
    
        </div>
        '; 
        
        echo getcwd() . "\n";
        echo '<hr>';
        // $archivo_adjunto = "leads_Temporal/".$data;
        $archivo_adjunto = "leads_Temporal/IMPULSE_CC_DIGITAL_WINBACK_2023_07_26 01 05 03.csv";
        echo $archivo_adjunto;
        // die();

        $mail->addAttachment($archivo_adjunto);
        //echo $mensaje; 
        
        $mail->msgHTML($mensaje);
        
        if (!$mail->send()) {
          echo "Mailer Error: ".$mail->ErrorInfo;    
        } else {
          echo '<hr> Enviado';
            // echo "Mailer sent!->".$rs3->fields['CORREO']."->".$contador;
        }
      } //FIN FUNCION
  