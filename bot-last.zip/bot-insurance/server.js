import express from "express";
import cors from "cors";
import botRoutes from "./src/routes/botRoutes.js";
import { config } from "./src/config/index.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/bot", botRoutes);
app.use(express.static("src/public"));


app.listen(config.port, () => {
  console.log(`Servidor corriendo en http://localhost:${config.port}`);
});
