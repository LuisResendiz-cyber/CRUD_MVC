    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="<?= media();?>/images/avatar.png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?= $_SESSION['userData']['name']; ?></p>
          <p class="app-sidebar__user-designation"><?= $_SESSION['userData']['nombrerol']; ?></p>
        </div>
      </div>
      <ul class="app-menu">
      <?php if (!empty($_SESSION['modules'])): ?>
    <?php foreach ($_SESSION['modules'] as $module): ?>
        <li class="treeview">
            <a class="app-menu__item" href="#" data-toggle="treeview">
                <i class="app-menu__icon fa fa-users"></i>
                <span class="app-menu__label"><?= htmlspecialchars($module['title']) ?></span>
                <i class="treeview-indicator fa fa-angle-right"></i>
            </a>

            <?php if (!empty($module['submodules'])): ?>
                <ul class="treeview-menu">
                    <?php foreach ($module['submodules'] as $sub): ?>
                        <li>
                            <a class="treeview-item" href="<?= base_url() . $sub['route'] ?>">
                                <i class="icon fa fa-<?= $sub['icon'] ?>"></i>
                                <?= htmlspecialchars($sub['title']) ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
<?php endif; ?>
      </ul>
    </aside>