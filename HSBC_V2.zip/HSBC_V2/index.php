<?php



require_once "controladores/plantilla.controlador.php";

require_once "controladores/usuarios.controlador.php";

require_once "controladores/enlaces.controlador.php";
require_once "controladores/campanas.controlador.php";


require_once "modelos/usuarios.modelo.php";

require_once "modelos/enlaces.modelo.php";
require_once "modelos/campanas.modelo.php";


require_once "extensiones/vendor/autoload.php";



$plantilla = new ControladorPlantilla();

$plantilla -> ctrPlantilla();
