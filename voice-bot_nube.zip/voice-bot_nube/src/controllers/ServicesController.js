const { transcribeAudio } = require('../services/stt');

const appController = {
    async stt(req, res){
        try {
            if (!req.file) {
                return res.status(400).json({ error: "No audio file uploaded" });
            }

            const text = await transcribeAudio(req.file.buffer);

            res.json({ text });
        } catch (error) {
            console.error("STT Error:", error.response?.data || error);
            res.status(500).json({ error: "STT failed" });
        }
    }
}

module.exports = appController;