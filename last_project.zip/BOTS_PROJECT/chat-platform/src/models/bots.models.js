const db = require("../db/mysql");

const Bots = {
    async Bot(option, params = {}) {


        try {
          // Valores por defecto
          const {
            botId = null,
            nombre = null,
            descripcion = null,
            tipo = null,
            estado = null,
            LLM = null
          } = params;
          
          // Ejecutar el procedimiento almacenado
          const [rows] = await db.query(
            'CALL sp_bot_crud(?, ?, ?, ?, ?, ?, ?)', 
            [option, botId, nombre, descripcion, tipo, estado, LLM]
          );
          
          return rows[0];
        } catch (error) {
          console.error('Error en Bot CRUD:', error);
          throw error;
        }
      }
};

module.exports = Bots;


