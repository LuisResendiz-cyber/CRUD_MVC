const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  console.log(context);
  // const baseQuery = "BEGIN " + context.schema + ".XSP_SETAGENDAXFECHA(:agente, :reg, :ano, :mes, :dia, :media, :nombre_, :comment_, :camp, :keys); END;";
  const baseQuery = "BEGIN " + context.schema + ".XSP_SETAGENDAXFECHA(:agente, :reg, :ano, :mes, :dia, :media, :nombre_, :comment_, :camp); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.s_usr_id || !context.id_registro || !context.anio || !context.mes || !context.day || !context.hora || !context.nombre || !context.comentarios || !context.camp){
    // if(!context.s_usr_id || !context.id_registro || !context.anio || !context.mes || !context.day || !context.hora || !context.nombre || !context.comentarios || !context.camp || context.keys== ''){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.agente = context.s_usr_id;
    binds.reg = context.id_registro;
    binds.ano = context.anio;
    binds.mes = context.mes;
    binds.dia = context.day;
    binds.media = context.hora;
    binds.nombre_ = {val:context.nombre,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.comment_ = {val:context.comentarios,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.camp = context.camp;
    // binds.keys = context.keyrig[0][0];
    console.log(binds);
    const result = await database.simpleExecute(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;
