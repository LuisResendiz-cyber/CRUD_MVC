// services/chat/knowledge.service.js

const KNOWLEDGE_BASE = [
    {
      keywords: ["horario", "abren", "cierran"],
      answer: "Nuestro horario es de lunes a viernes de 9:00 a 18:00."
    },
    {
      keywords: ["precio", "costo", "plan"],
      answer: "Para precios, un asesor puede ayudarte."
    }
  ];
  
  module.exports = {
    async match(message) {
      const text = message.toLowerCase();
  
      for (const item of KNOWLEDGE_BASE) {
        if (item.keywords.some(k => text.includes(k))) {
          return item.answer;
        }
      }
  
      return null;
    }
  };
  