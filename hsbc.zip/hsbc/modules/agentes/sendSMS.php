<?php 
  require_once "../../includes/includes.inc.php";
  require_once "agentes.inc.php";

  $customerid = $_REQUEST['customerid'];
  $surveyid = $_REQUEST['surveyid']; 
	$cliente = $_REQUEST['cliente']; 
	$u_telefono = $_REQUEST['u_telefono']; 
	$nomina = $_REQUEST['nomina'];
	$telefono = $_REQUEST['telefono'];


  $tipo_envio = 1; //SMS
  $proveedor = get_proveedor_sms($db); 
  $campana=998;
  //echo json_encode($telefono); die();
	$codigo_aleatorio = rand(1,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9) . rand(0,9);

    // customerid
    // surveyid
    // u_telefono
    // u_agente
    // codigo_aleatorio
    // respuesta_api
    // fecha

  $prod = intval($surveyid);
  //Maximo 160 caracteres si hay mas datos se envia por partes
  if($prod == 1){
    //$seguro = 'AP';//Acc
    $seguro = 'DE ACCIDENTES PERSONALES';//Acc
    $liga='www.hsbc.com.mx/accidentes';
    
    // $cadena = 'HSBC SEGUROS agradece tu preferencia el NIP para concluir la contratacion de tu SEGURO ' . $seguro.  ' ' . $codigo_aleatorio . ' mayor informacion en '.$liga;


  } else if($prod == 2){
    //$seguro = 'HC'; //hospitalizacion
    $seguro = 'DE APOYO POR HOSPITALIZACION'; //hospitalizacion
    $liga='www.hsbc.com.mx/seguros/apoyo-por-hospitalizacion/';

    // $cadena = 'Buen dia ' . $cliente . '. Tu numero de confirmacion para el seguro ' . $seguro . ' de HSBC es: ' . $codigo_aleatorio;

  }
  
  $cadena = 'HSBC SEGUROS agradece tu preferencia el NIP para concluir la contratacion de tu SEGURO ' . $seguro.  ' ' . $codigo_aleatorio . ' mayor informacion en '.$liga;

/*   $cadena = 'Buen dia ' . $cliente . '. Tu numero de confirmacion para el seguro ' . $seguro . ' de HSBC es: ' . $codigo_aleatorio; */

// $cadena = 'HSBC SEGUROS agradece tu preferencia el NIP para concluir la contratacion de tu SEGURO ' . $seguro.  ' ' . $codigo_aleatorio . ' mayor informacion en '.$liga;

 // $cadena = 'Estimado Jesus. Le informamos que su permiso por diarrea fue rechazado automaticamente, por lo que ya tiene varias faltas injustificadas. Tome sus precauciones.';

  //$ch = curl_init('172.20.1.72/sms/sms_hsbc/index.php');
  //$ch = curl_init('172.20.1.95/sms_amexinsurancedig_prueba/index4.php');
  //$ch = curl_init('172.20.1.95/sms_amexinsurancedig_prueba/index5.php');
  $ch = curl_init('172.20.1.95/sms_hsbc/index2.php');
  //$ch = curl_init('172.20.1.95/sms_hsbc/index2.php');

  //especificamos el POST
	curl_setopt($ch, CURLOPT_POST, 1);

  curl_setopt($ch, CURLOPT_POSTFIELDS, array(
    'numero' => $telefono,
    'proveedor' => $proveedor,
    'campana' => $campana,
    'mensaje' => $cadena
  ));

  //le decimos que queremos recoger una respuesta (si no esperas respuesta, ponlo a false)
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  //recogemos la respuesta
	$respuesta_api = curl_exec($ch);

	//o el error, por si falla
	$error_api = curl_error($ch);

	//y finalmente cerramos curl
	curl_close($ch);

  //si error está vacío insertar en db los datos
  // solicitud, id_telefono, nomina_agente(AVI), oferta, fecha

	if($error_api == ''){
    $rspta = insertLogEnvioCodigo($customerid, $surveyid, $u_telefono, $nomina, $codigo_aleatorio, $tipo_envio, $proveedor, $db);
          
    if(intval($rspta->_array[0]['RESPONSE']) == 1){
      $respuesta_interna = 'Mensaje enviado y datos insertados en BD';
    } else{
      $respuesta_interna = 'Mensaje enviado y datos NO insertados en BD';
    }
  } else{
    $respuesta_interna = 'Error en API';
  }

  $data = array(
    'respuesta_api' => $respuesta_api,
    'error_api' => $error_api,
    'respuesta_interna' => $respuesta_interna . '|' . $proveedor,
    'codigo_aleatorio' => $codigo_aleatorio
  );

  echo json_encode($data);







 
       

      

      


       