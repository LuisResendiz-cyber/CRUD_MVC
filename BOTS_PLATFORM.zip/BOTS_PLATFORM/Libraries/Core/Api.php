<?php
namespace Core;

class Api {
    protected $method = '';
    protected $endpoint = '';
    protected $params = [];
    protected $headers = [];
    protected $user = null;
    protected $rateLimitKey = '';
    
    public function __construct() {
        $this->headers = $this->getHeaders();
        $this->method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        
        // Habilitar CORS
        $this->enableCors();
        
        // Verificar rate limiting
        if (!$this->checkRateLimit()) {
            $this->response(429, ['error' => 'Demasiadas peticiones']);
        }
        
        // Parsear la URL
        $this->parseRequest();
    }
    
    private function enableCors() {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        
        if (in_array($origin, ALLOWED_ORIGINS)) {
            header("Access-Control-Allow-Origin: " . $origin);
        }
        
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key");
        header("Access-Control-Allow-Credentials: true");
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            exit(0);
        }
    }
    
    private function getHeaders() {
        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (substr($key, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))))] = $value;
            }
        }
        return $headers;
    }
    
    private function parseRequest() {
        $url = $_SERVER['REQUEST_URI'] ?? '';
        $path = parse_url($url, PHP_URL_PATH);
        
        // Extraer endpoint (ej: /api/v1/usuarios)
        $parts = explode('/', $path);
        $apiIndex = array_search('api', $parts);
        
        if ($apiIndex !== false) {
            $this->endpoint = $parts[$apiIndex + 2] ?? ''; // v1/endpoint
            $this->params = array_slice($parts, $apiIndex + 3);
        }
        
        // Obtener parámetros según método
        if ($this->method == 'POST' || $this->method == 'PUT') {
            $input = file_get_contents('php://input');
            $this->payload = json_decode($input, true);
            
            if (empty($this->payload)) {
                $this->payload = $_POST;
            }
        } elseif ($this->method == 'GET') {
            $this->payload = $_GET;
        }
    }
    
    protected function checkRateLimit() {
        $apiKey = $this->headers['Authorization'] ?? $_GET['api_key'] ?? '';
        $this->rateLimitKey = md5($apiKey . $_SERVER['REMOTE_ADDR']);
        
        // Implementar Redis o archivo temporal para rate limiting
        $cacheFile = sys_get_temp_dir() . '/ratelimit_' . $this->rateLimitKey;
        
        if (file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true);
            if (time() - $data['timestamp'] < 60 && $data['count'] >= API_RATE_LIMIT) {
                return false;
            }
        }
        
        return true;
    }
    
    protected function authenticate() {
        $authHeader = $this->headers['Authorization'] ?? '';
        
        if (empty($authHeader)) {
            $this->response(401, ['error' => 'No autorizado']);
        }
        
        list($bearer, $token) = explode(' ', $authHeader);
        
        if ($bearer != 'Bearer') {
            $this->response(401, ['error' => 'Formato de token inválido']);
        }
        
        // Decodificar JWT
        try {
            $this->user = $this->decodeJWT($token);
        } catch (Exception $e) {
            $this->response(401, ['error' => 'Token inválido']);
        }
    }
    
    protected function decodeJWT($token) {
        // Implementar JWT (usa firebase/php-jwt o similar)
        // composer require firebase/php-jwt
        return \Firebase\JWT\JWT::decode($token, JWT_SECRET, ['HS256']);
    }
    
    protected function generateJWT($data) {
        $payload = [
            'iss' => BASE_URL,
            'aud' => BASE_URL_API,
            'iat' => time(),
            'exp' => time() + (60 * 60 * 24), // 24 horas
            'data' => $data
        ];
        
        return \Firebase\JWT\JWT::encode($payload, JWT_SECRET, 'HS256');
    }
    
    protected function response($status, $data) {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }
    
    public function handle() {
        // Este método será sobrescrito por los controladores
    }
}