const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".sps_DatosSolicitud_SJR(:customerid, :surveyid, :user, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};
        
        if(!context.customerid || !context.surveyid || !context.user){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.customerid      = context.customerid;
            binds.surveyid      = context.surveyid;
            binds.user      = context.user;

            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;