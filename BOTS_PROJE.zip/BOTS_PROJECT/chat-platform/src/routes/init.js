const express = require('express');
const router = express.Router();
const UsersControllers = require("../controllers/Users.controller");
const check = require('../Middleware/error.Middleware')
const appController = require('../controllers/Users.controller')



//PERMISOS
router.post('/login', check.checkLogin, appController.login);
router.get("/getModules", appController.getModules);

//USERS
//router.post('/Createuser',check.checkUser, appController.setUser);
router.get('/', appController.getAllUsers);              // GET /api/users
router.get('/getUser/:id', appController.getUserById);          // GET /api/users/:id
router.post('/createUser',check.checkUser,appController.createUser);             // POST /api/users
router.put('/updateUser/:id', appController.updateUser);           // PUT /api/users/:id
router.delete('/deleteUser/:id', appController.deleteUser);        // DELETE /api/users/:id

//ROLES
router.post("/createRol", appController.createRole);
router.get("/getRoles", appController.getRoles);
router.get("/getRol", appController.getRoleById);
router.put("/updateRol/:id", appController.updateRol);
router.delete("/deleteRol/:id", appController.deleteRol);


module.exports = router;