const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN DBO.SPS_PUEDE_REFERIDO(:v_referido); END;"; //DBO
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.v_referido      = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
  
  const result = await database.simpleExecute(query, binds);

  return result;
}
 
module.exports.find = find;