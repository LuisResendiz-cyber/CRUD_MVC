<section class="contenedor forms">
    <div class="form login">
      <div class="form-content">    
        <header><img src="vistas/img/plantilla/hsbc.png" alt="" srcset="" width="150px"></header>
        <form method="post">
          <div class="field input-field">
            <input type="text" placeholder="Nomina" name="ingUsuario" class="input">
          </div>
          <div class="field input-field">
            <input type="password" placeholder="Password" name="ingPassword" class="password">
            <i class='bx bx-hide eye-icon'></i>
          </div>
          <div class="field">
            <select name="" id="">
              <option value="">Selecciona Una Opcion</option>
              <option value="">Asistido</option>
              <option value="">Predictivo</option>
            </select>
          </div>
          <div class="form-link">
            <a href="#" class="forgot-pass">Olvidaste tu Contraseña?</a>
          </div>
          <div class="field button-field">
            <button type="submit">Iniciar Sesion</button>
          </div>
          <?php
        $login = new ControladorUsuarios();
        $login -> ctrIngresoUsuario();
        ?>
        </form>
      </div>
    </div>
  </section>