import { Request, Response } from "express";
import { AuthModel, JwtService, PasswordService } from "../models/AuthModel";

class AuthController {
  private authModel: AuthModel;
  private jwtService: JwtService;
  private passwordService: PasswordService;

  constructor() {
    this.authModel = new AuthModel();
    this.jwtService = new JwtService();
    this.passwordService = new PasswordService();
  }

  public getToken = async (req: Request, res: Response): Promise<void> => {
    const { USERNAME, PASSWORD } = req.body;

    try {
      let userDb = await this.authModel.getUser(USERNAME);

      if (userDb.length === 0) {
        res
          .status(401)
          .json({ status: "Error", details: `${USERNAME} not found` });
        return;
      }
      const user = userDb[0];
      const isvalid = await this.passwordService.comparePasswords(
        PASSWORD,
        user.PASS
      );
      if (!isvalid) {
        res.status(401).json({ status: "Error", details: "Invalid password" });
        return;
      }
      const token = this.jwtService.generateToken(user);
      res.json({ token });
      return;
    } catch (error) {
      res.json({ message: "test" });
      return;
    }
  };

  public createUser = async (req: Request, res: Response): Promise<void> => {
    /**
     * Este metodo aun no esta completo
     */
    const { USERNAME, PASSWORD } = req.body;

    const existingUser = await this.authModel.getUser(USERNAME);
    if (existingUser.length > 0) {
      res.status(409).json({
        status: "Error",
        details: `Username '${USERNAME}' is already taken`,
      });
      return;
    }

    const hashedPassword = await this.passwordService.hashPassword(PASSWORD);

    const insertResult = await this.authModel.insertUser(
      USERNAME,
      hashedPassword
    );

    if (!insertResult || (insertResult as any).affectedRows === 0) {
      res.status(500).json({
        status: "Error",
        details: `Failed to create user '${USERNAME}'`,
      });
      return;
    }
    const createdUser = await this.authModel.getUser(USERNAME);
    if (createdUser.length === 0 || !createdUser[0].ID_USER) {
      throw new Error("User creation verification failed");
    }
    res.status(201).json({
      status: "success",
      details: `User '${USERNAME}' created successfully`,
      ID_USER: createdUser[0].ID_USER,
    });

    return;
  };
}

export default AuthController;
