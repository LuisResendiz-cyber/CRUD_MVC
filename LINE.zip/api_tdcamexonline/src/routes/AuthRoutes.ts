import {Router  } from "express";
import {validateSurvey,ValSurvey,ValSignIn,validate  } from "../validation/validators";
import AuthController from "../controllers/authController";

const router=Router();

const authController = new AuthController()

router.post("/login",validate(ValSignIn), authController.getToken );
router.post("/signUp",validate(ValSignIn), authController.createUser );
//router.post("/validateToken",validate(ValSignIn), authController.getAllSurveys );
 
export default router
