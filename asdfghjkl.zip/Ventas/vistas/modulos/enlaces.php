<div class="content-wrapper">

          <section class="content-header">

                    <h1>

                              Administrar Ligas de Campañas

                    </h1>

                    <ol class="breadcrumb">

                              <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>

                              <li class="active">Administrar usuarios</li>

                    </ol>

          </section>

          <section class="content">

                    <div class="box">

                              <div class="box-header with-border">

                                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalAgregarLiga">

                                                  Agregar Nueva Liga

                                        </button>

                              </div>

                              <div class="box-body">

                                        <table class="table table-bordered table-striped dt-responsive tablas" width="100%">

                                                  <thead>

                                                            <tr>

                                                                      <th style="width:10px">Id</th>
                                                                      <th>Liga</th>
                                                                      <th>Campana</th>
                                                                      <th>Acciones</th>

                                                            </tr>

                                                  </thead>

                                                  <tbody>


                                                  <?php

$item = null;
$valor = null;

$enlaces = ControladorLigas::ctrMostrarEnlaces($item, $valor);

// var_dump($enlaces);
// die();

foreach ($enlaces as $key => $value){
 
  echo ' <tr>
          <td>'.($key+1).'</td>
          <td>'.$value["url"].'</td>
          <td>'.$value["NOMBRE_CAMPANA"].'</td>';           
          
          echo '
          <td>

            <div class="btn-group">
                
              <button class="btn btn-warning btnEditarUsuario" idUsuario="'.$value["id"].'" data-toggle="modal" data-target="#modalEditarUsuario"><i class="fa fa-pencil"></i></button>

              <button class="btn btn-danger btnEliminarUsuario" idUsuario="'.$value["id"].'"><i class="fa fa-times"></i></button>

            </div>  

          </td>

        </tr>';
}


?> 

                                                  </tbody>

                                        </table>

                              </div>

                    </div>

          </section>

</div>


<div id="modalAgregarLiga" class="modal fade" role="dialog">

          <div class="modal-dialog">

                    <div class="modal-content">

                              <form role="form" method="post" enctype="multipart/form-data">


                                        <div class="modal-header" style="background:#3c8dbc; color:white">

                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                                                  <h4 class="modal-title">Administar Liga</h4>

                                        </div>


                                        <div class="modal-body">

                                                  <div class="box-body">
                                                            <div class="form-group">
                                                                      <div class="input-group">
                                                                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                                                <input type="text" class="form-control input-lg" name="nuevoLiga" placeholder="Ingresar la Liga de Asignacion" required>
                                                                      </div>
                                                            </div>
                                                            <div class="form-group">
                                                                      <div class="input-group">
                                                                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                                                                <select class="form-control input-lg" name="campana" required>
                                                                                          <option value="">Selecionar La Campaña</option>
                                                                                          <option value="1">HSBC</option>
                                                                                          <option value="2">BanorteCredito</option>
                                                                                          <option value="3">AmexInsuranceDigital</option>
                                                                                          <option value="4">AmexInsurance</option>
                                                                                          <option value="5">CitiSeguro</option>
                                                                                          <option value="6">CitiBanco</option>
                                                                                          <option value="7">CitiSofom</option>
                                                                                </select>

                                                                      </div>

                                                            </div>

                                                  </div>

                                        </div>

                                        <div class="modal-footer">

                                                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>

                                                  <button type="submit" class="btn btn-primary">Guardar usuario</button>

                                        </div>

                              </form>

                              <?php

                              $crearLiga = new ControladorLigas();
                              $crearLiga->ctrCrearLiga();

                              ?>

                    </div>

          </div>

</div>


<div id="modalEditarUsuario" class="modal fade" role="dialog">

          <div class="modal-dialog">

                    <div class="modal-content">

                              <form role="form" method="post" enctype="multipart/form-data">


                                        <div class="modal-header" style="background:#3c8dbc; color:white">

                                                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                                                  <h4 class="modal-title">Editar usuario</h4>

                                        </div>


                                        <div class="modal-body">

                                                  <div class="box-body">


                                                            <div class="form-group">

                                                                      <div class="input-group">

                                                                                <span class="input-group-addon"><i class="fa fa-user"></i></span>

                                                                                <input type="text" class="form-control input-lg" id="editarNombre" name="editarNombre" value="" required>

                                                                      </div>

                                                            </div>

                                                            <div class="form-group">

                                                                      <div class="input-group">

                                                                                <span class="input-group-addon"><i class="fa fa-key"></i></span>

                                                                                <input type="text" class="form-control input-lg" id="editarUsuario" name="editarUsuario" value="" readonly>

                                                                      </div>

                                                            </div>


                                                            <div class="form-group">

                                                                      <div class="input-group">

                                                                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>

                                                                                <input type="password" class="form-control input-lg" name="editarPassword" placeholder="Escriba la nueva contraseña">

                                                                                <input type="hidden" id="passwordActual" name="passwordActual">

                                                                      </div>

                                                            </div>


                                                            <div class="form-group">

                                                                      <div class="input-group">

                                                                                <span class="input-group-addon"><i class="fa fa-users"></i></span>

                                                                                <select class="form-control input-lg" name="editarPerfil" required>

                                                                                          <option value="" id="editarPerfil"></option>

                                                                                          <option value="Administrador">Administrador</option>

                                                                                          <option value="Usuario">Usuario</option>

                                                                                </select>

                                                                      </div>

                                                            </div>

                                                  </div>

                                        </div>


                                        <div class="modal-footer">

                                                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>

                                                  <button type="submit" class="btn btn-primary">Modificar usuario</button>

                                        </div>
                              </form>

                    </div>

          </div>

</div>