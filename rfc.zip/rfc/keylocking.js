document.onkeydown = disableF5;
document.onkeypress = disableF5;
document.onkeyup = disableF5;

function disableF5(e) {
    if (e.keyCode == 116) {
        e.preventDefault();
        return false;
    }
}
