// ============================================================
// CHAT / LOG HELPERS (para integrar IA)
// ============================================================

/**
 * Inserta un registro en whatsapp_webhook_log (útil para inbound/outbound y para IA)
 * Asegúrate de pasar role ('user'|'assistant' o como lo uses) y conversation_id si aplica.
 */
async function insertWebhookLogFull({
    event_type,
    wamid,
    from_number,
    status = null,
    message_text = null,
    raw_json = null,
    role = null,
    conversation_id = null,
    related_envio_id = null
  }) {
    const sql = `
      INSERT INTO whatsapp_webhook_log
        (event_type, wamid, from_number, status, message_text, raw_json, role, conversation_id, related_envio_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    `;
  
    const params = [
      event_type || null,
      wamid || null,
      from_number || null,
      status || null,
      message_text || null,
      raw_json ? JSON.stringify(raw_json) : null,
      role || null,
      conversation_id || null,
      related_envio_id || null
    ];
  
    const [result] = await db.query(sql, params);
    return result.insertId;
  }
  
  /**
   * Obtiene el último mensaje para un phone, opcionalmente filtrando por role (ej: 'assistant' para últimos OUTBOUND),
   * dentro de una ventana en minutos (por defecto 1440 = 24h).
   * Devuelve NULL si no hay resultados.
   */
  async function getLastMessageByPhone(phone, options = {}) {
    const { role = null, windowMinutes = 1440 } = options;
  
    let sql = `
      SELECT *
      FROM whatsapp_webhook_log
      WHERE from_number = ?
        AND created_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
    `;
    const params = [phone, windowMinutes];
  
    if (role) {
      sql += ` AND role = ?`;
      params.push(role);
    }
  
    sql += ` ORDER BY created_at DESC LIMIT 1`;
  
    const [rows] = await db.query(sql, params);
    return rows.length ? rows[0] : null;
  }
  
  /**
   * Obtiene los últimos N mensajes por conversation_id (útil para construir contexto para la IA).
   * Si conversation_id es null, retorna empty array.
   */
  async function getLastMessagesByConversation(conversation_id, limit = 20) {
    if (!conversation_id) return [];
  
    const sql = `
      SELECT role, message_text AS message, wamid, created_at
      FROM whatsapp_webhook_log
      WHERE conversation_id = ?
      ORDER BY created_at DESC
      LIMIT ?
    `;
    const [rows] = await db.query(sql, [conversation_id, limit]);
  
    // devolver en orden cronológico (del más viejo al más nuevo)
    return rows.reverse();
  }
  
  /**
   * Alternativa: obtener últimos N mensajes por phone (si no hay conversation_id)
   */
  async function getLastMessagesByPhone(phone, limit = 20) {
    const sql = `
      SELECT role, message_text AS message, wamid, conversation_id, created_at
      FROM whatsapp_webhook_log
      WHERE from_number = ?
      ORDER BY created_at DESC
      LIMIT ?
    `;
    const [rows] = await db.query(sql, [phone, limit]);
    return rows.reverse();
  }
  
  module.exports = {
    ...module.exports,
    insertWebhookLogFull,
    getLastMessageByPhone,
    getLastMessagesByConversation,
    getLastMessagesByPhone
  };
  