const express =  require('express');
const check = require('../Middleware/errorMiddleware')
const router = express.Router();
const jwt = require('../Middleware/authMiddelaware')
const appController = require('../controllers/appController')

router.get('/users', appController.getUser)
router.post('/Createuser',check.checkUser, appController.setUser)
router.get('/User/:id', check.checkGetUser, jwt, appController.getUserById)
router.post('/login', check.checkLogin, appController.login)


module.exports = router;