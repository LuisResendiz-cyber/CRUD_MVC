<footer class="main-footer">
	<p>Page</p>
</footer>