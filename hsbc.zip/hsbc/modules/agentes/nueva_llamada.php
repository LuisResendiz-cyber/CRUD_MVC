<?php
# @uthor Mark
# Nueva_llamada File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Llamada Cliente");
layout_menu($db, "ShowScript(1,1,1)");

$bines = get_bines($db);
$bandera = 0;
$id_registro = get_session_varname("id_registro");

if (strlen($id_registro) > 0) {
	$registro = get_detalle_registro($id_registro, $db);
	$bandera = 1;
}
?>	
<script>
    array_bines = new Array(<?=$bines?>);
</script>

	<p class="textbold">Agentes &gt; Llamada Cliente</p>
	<p>&nbsp;</p>
	<form method="post" action="modules.php?mod=agentes&op=process_data&act=11" name="frm15">
	<input type="hidden" name ="tipo_tdc" value="2">
    <table class="text" border="0">
		<tr>
			<td width="40%" align="center">
                <table border="0" width="90%">
                    <tr>
                        <td colspan="2"><?=form_oblmsg();?></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2">Buenos (as) d&iacute;as/tardes/noches, le atiende <b><?=get_session_varname("s_usr_nombre");?></b> del Grupo Financiero Santander, <br>me proporciona su nombre completo, por favor?</td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td><b>* Nombre Cliente: </b></td>
                        <td><input type="text" size="20" name="nombre" id="nombre" maxlength="20" value="<?=$registro->fields['CNOMBRE']?>" ></td>
                    </tr><tr>
                        <td><b>* Apellido Paterno:</b>
                        <td><input type="text" size="20" name="paterno" id="paterno" maxlength="20" value="<?=$registro->fields['CPATERNO']?>" ></td>
                    </tr><tr>
                        <td><b>Apellido Materno:</b>
                        <td><input type="text" size="20" name="materno" id="materno" maxlength="20" value="<?=$registro->fields['CMATERNO']?>" ></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2">Sr.(ita.) (Apellido del cliente), me puede indicar por favor los 16 d&iacute;gitos de su TDC</td>
                    </tr><tr>
                        <td><b>* TDC:</b>
                        <td><input type="text" size="20" name="tdc" id="tdc" maxlength="16" value="<?=$registro->fields['ITDC']?>" ></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2">Su n&uacute;mero telef&oacute;nico principal,</td>
                    </tr><tr>
                        <td><b>* N&uacute;mero Telef&oacute;nico:</b>
                        <td><input type="text" size="10" name="telefono" id="telefono" maxlength="10" value="<?=$registro->fields['ITELEFONO']?>" ></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2">Alg&uacute;n celular en el que lo podamos localizar por favor</td>
                    </tr><tr>
                        <td><b>N&uacute;mero Celular: </b>
                        <td><input type="text" size="10" name="celular" id="celular" maxlength="10" value="<?=$registro->fields['ICELULAR']?>" ></td>
                    </tr><tr>
                        <td colspan="2">Tiene alg&uacute;n correo electr&oacute;nico que pudiera proporcionarnos?</td>
                    </tr><tr>
                        <td><b>Correo Electr&oacute;nico </b>
                        <td><input type="text" size="20" name="email" id="email" maxlength="30" value="<?=$registro->fields['CEMAIL']?>" ></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                </table>
            </td>
			<td rowspan="2">
				<div id="script" align="center" class="script"></div>
			</td>
        </tr><tr>
            <td colspan="2">
                <input type="button" value="Calificar llamada" onclick="MotivoLlamada('2',<?=$bandera?>)"/>&nbsp;&nbsp;
                <input type="button" value="Buscar" onclick="MotivoLlamada('1',<?=$bandera?>)"/>&nbsp;&nbsp;
            </td>
        </tr>
    </table>
    </form>
<?
layout_footer();
?>