const oracledb = require('oracledb');
const database = require('../services/database.js');

//    $stmt = $db->PrepareSP("BEGIN " . $query . "(:cp, :id, :rc); END;");
//    $db->InParameter($stmt, $cp, 'cp');
//    $db->InParameter($stmt, $id, 'id');
//    $rs = $db->ExecuteCursor($stmt, 'rc');

async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".xsp_getStatusNoContacto(:camp, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.camp){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.camp      = context.camp;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};


            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;