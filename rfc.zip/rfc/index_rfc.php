<?php
require_once('calc_rfc.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="ISO-8859-1">
        <title>RFC</title>
        <script language="JavaScript" src="keylocking.js"></script>
    </head>
    <body>
        <form name="frmRFC">
            <table border="1">
                <thead>
                    <tr>
                        <th>Dato</th>
                        <th>Captura</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Nombre</td>
                        <td><input type="text" name="nombre" value="<?php echo $_GET['nombre'] ?>" /></td>
                    </tr>
                    <tr>
                        <td>Paterno</td>
                        <td><input type="text" name="paterno" value="<?php echo $_GET['paterno'] ?>" /></td>
                    </tr>
                    <tr>
                        <td>Materno</td>
                        <td><input type="text" name="materno" value="<?php echo $_GET['materno'] ?>" /></td>
                    </tr>
                    <tr>
                        <td>Fecha</td>
                        <td><input type="text" name="fecha" value="<?php echo $_GET['fecha'] ?>" /></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Calcular" name="cmdOk" />
                        </td>
                    </tr>
                    <?php
                    if ($_GET['cmdOk'] == 'Calcular') {
                        $nombre = $_GET['nombre'];
                        $paterno = $_GET['paterno'];
                        $materno = $_GET['materno'];
                        $fecha = $_GET['fecha'];

                        $rfc = CalcularRFC($nombre, $paterno, $materno, $fecha);
                        ?>
                        <tr>
                            <td colspan="2">
                                Resultado: <?php echo $rfc ?>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </form>
    </body>
</html>