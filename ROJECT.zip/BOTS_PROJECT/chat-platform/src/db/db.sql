CREATE DATABASE `WHATSAAP_ASSISTANT` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;


-- WHATSAAP_ASSISTANT.BOTS definition

CREATE TABLE `BOTS` (
  `id_bot` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo` enum('cobranza','ventas','seguros','tarjetas','soporte','gen') NOT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CHAT_SESSIONS definition

CREATE TABLE `CHAT_SESSIONS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT '1',
  `session_uuid` char(36) NOT NULL,
  `channel` enum('web','whatsapp') DEFAULT 'web',
  `status` enum('bot','human','closed') DEFAULT 'bot',
  `assigned_agent_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_uuid` (`session_uuid`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `CHAT_SESSIONS_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `CUSTOMERS` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CUSTOMERS definition

CREATE TABLE `CUSTOMERS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_key` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_key` (`client_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.DATA_NUMEROS definition

CREATE TABLE `DATA_NUMEROS` (
  `id_contacto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `lada` char(2) NOT NULL,
  `numero` char(10) NOT NULL,
  `PLATFORM_ID` int DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS definition

CREATE TABLE `ENVIOS` (
  `id_envio` int NOT NULL AUTO_INCREMENT,
  `id_contacto` int NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `mensaje_enviado` text NOT NULL,
  `fecha_envio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio`),
  KEY `id_contacto` (`id_contacto`),
  CONSTRAINT `ENVIOS_ibfk_1` FOREIGN KEY (`id_contacto`) REFERENCES `DATA_NUMEROS` (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS_STATUS definition

CREATE TABLE `ENVIOS_STATUS` (
  `id_envio_status` int NOT NULL AUTO_INCREMENT,
  `id_envio` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio_status`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `ENVIOS_STATUS_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.LOG_ENVIO definition

CREATE TABLE `LOG_ENVIO` (
  `id_log_local` int NOT NULL AUTO_INCREMENT,
  `id_envio` int DEFAULT NULL,
  `status_id` int NOT NULL,
  `errorApi` varchar(500) NOT NULL DEFAULT 'NA',
  `fecha_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log_local`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `LOG_ENVIO_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.PLATFORMS definition

CREATE TABLE `PLATFORMS` (
  `id_platform` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `activo` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_platform`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.STATUS_ENVIO definition

CREATE TABLE `STATUS_ENVIO` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `message` varchar(30) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.BOTS_CONVERSATION_LOG definition

CREATE TABLE `BOTS_CONVERSATION_LOG` (
  `id_webhook` int NOT NULL AUTO_INCREMENT,
  `event_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `from_number` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `message_text` text,
  `channel` enum('web','whatsapp','voice') NOT NULL DEFAULT 'web',
  `role` enum('user','assistant') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'assistant',
  `conversation_id` varchar(100) DEFAULT NULL,
  `raw_json` json NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_webhook`),
  KEY `idx_from_created` (`from_number`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=923 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.BOT_KNOWLEDGE definition

CREATE TABLE `BOT_KNOWLEDGE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `content` text NOT NULL,
  `tags` json DEFAULT NULL,
  `priority` int DEFAULT '0',
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_bot_knowledge_bot` (`id_bot`),
  CONSTRAINT `fk_bot_knowledge_bot` FOREIGN KEY (`id_bot`) REFERENCES `BOTS` (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(5, 2, '¿Quiero contratar?', 'Para contratar la tarjetas da clic al siguiente en lace para dejar tus datos para el proceso https://desarrollo.impulsesolutions.com.mx/control-reportes/', NULL, 0, 1, '2026-01-09 09:22:15', '2026-01-09 09:22:15');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(6, 2, '¿Quién puede recibir y activar la tarjeta de crédito?', 'Solo el titular de la tarjeta puede recibir y activar la tarjeta, para garantizar la seguridad tanto de la tarjeta como del titular.', NULL, 0, 1, '2026-01-09 09:23:16', '2026-01-09 09:23:16');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(7, 2, '¿Cómo se personaliza el kit de bienvenida de la tarjeta?', 'Para personalizar tu kit de bienvenida, necesitamos tu nombre completo y confirmar a dónde te gustaría que se enviara: a tu casa o a tu oficina.', NULL, 0, 1, '2026-01-09 09:23:16', '2026-01-09 09:23:16');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(8, 2, '¿El primer año de la tarjeta tiene algún costo?', 'Sí, el primer año de la tarjeta de crédito es totalmente libre de costo de anualidad. Esto te permite probar y comparar los servicios y beneficios de nuestra tarjeta con otros productos que ya utilices.', NULL, 0, 1, '2026-01-09 09:23:16', '2026-01-09 09:23:16');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(9, 2, '¿Qué hacer si estoy desempleado y no tengo ingresos?', 'Entendemos que es una situación difícil. Por eso, ofrecemos la tarjeta de crédito como un respaldo financiero para tus compras diarias. Esta tarjeta es MasterCard y participa en promociones a meses sin intereses en diversos establecimientos.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(10, 2, 'Si no tengo tiempo, ¿pueden explicarme los beneficios rápidamente?', 'Sí, podemos explicarte los beneficios de la tarjeta de crédito en menos de 5 minutos. Además, la tarjeta llega inactiva junto con un kit de bienvenida donde podrás leer todos los beneficios en detalle.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(11, 2, '¿Qué beneficios ofrece la tarjeta de crédito?', 'La tarjeta de crédito ofrece varios beneficios, que se detallan en el kit de bienvenida que se entrega junto con la tarjeta. Este kit incluye todos los beneficios, términos y condiciones para que el usuario pueda revisarlos.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(12, 2, '¿A quién está dirigida la oferta de la tarjeta de crédito?', 'La tarjeta de crédito está disponible para el público en general, no solo para aquellas personas que viajan con la aerolínea Volaris.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(13, 2, '¿De dónde se obtiene la información sobre la tarjeta de crédito que se ofrece?', 'La información sobre nuestra tarjeta de crédito se obtiene de las series de marcación que aparecen en la página web del Instituto Federal de Telecomunicaciones. Además, no contamos con datos personales de los solicitantes, solo con el número telefónico.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(14, 2, '¿Por qué recibí esta llamada y de dónde obtuvieron mis datos?', 'La fuente de nuestros datos es pública y obtenida de las series de marcación que aparecen en la página web del Instituto Federal de Telecomunicaciones. Esto asegura que nuestra llamada es legítima y está en conformidad con la normativa.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(15, 2, '¿Cómo puedo demostrar que la llamada es legítima y que estoy hablando con un representante de Banco Invex?', 'Para generar confianza, puedo proporcionarle el número de atención a clientes con lada 800, que solo se otorga a empresas certificadas. También le puedo dar mi nombre completo y número de empleado para que pueda verificar mi identidad. Además, hay una página web donde tiene acceso a un chat en línea para preguntar por mí.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(16, 2, '¿Qué beneficios tengo al tener una tarjeta de nivel Platinum?', 'Con nuestra tarjeta Platinum, usted tendrá acceso a todos los beneficios en una sola tarjeta, a diferencia de tener que adquirir varias tarjetas de menor categoría. La tarjeta es MasterCard, lo que le permite realizar compras en cualquier establecimiento, además de promociones y descuentos al viajar con Volaris, sin requerir compras mínimas mensuales.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(17, 2, '¿Por qué la anualidad de la tarjeta de crédito es considerada cara?', 'La tarjeta que ofrecemos es de nivel Platinum, que es la categoría más alta. A diferencia de otras tarjetas que comienzan como clásicas y escalan a mejores categorías, nosotros le ofrecemos el nivel Platinum desde el inicio, lo que incluye más beneficios en una sola tarjeta.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(18, 2, '¿Qué hacer si un cliente menciona que está en una situación difícil?', 'Si un cliente menciona que está en una situación difícil, es crucial tranquilizarlo y aclararle que la intención no es endeudarlo. Queremos que conozca un banco 100% mexicano y los beneficios que ofrecemos. Inicialmente, se podría autorizar hasta $100,000 pesos de línea de crédito como un tope de seguridad.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(19, 2, '¿Cómo puedo responder a alguien que ya tiene una tarjeta de crédito y dice que está bien con ella?', 'Es importante comunicarle que nuestra propuesta no es saturarlo de plásticos. Aunque ya tenga una tarjeta de crédito, le estamos ofreciendo una opción totalmente diferente. Si me permite unos minutos, podría demostrarle los beneficios de nuestra tarjeta.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(20, 2, '¿Qué debo decir si alguien me dice que no está interesado en la tarjeta de crédito?', 'Entiendo que no le pueda interesar algo que no conoce. Por eso, mi intención es darle a conocer los beneficios de nuestra tarjeta de crédito. Permítame explicarle brevemente lo que puede ofrecerle.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(21, 2, '¿Qué información adicional se me proporcionará tras mi atención?', 'Al finalizar tu atención, recibirás una encuesta sobre tu experiencia con nosotros, ya que tu opinión es muy valiosa para mejorar nuestro servicio.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(22, 2, '¿Cuál es el número de atención a clientes en el Distrito Federal y Área Metropolitana?', 'El número de atención a clientes en el Distrito Federal y Área Metropolitana es 554000 4000.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(23, 2, '¿Qué debo hacer para concluir mi solicitud?', 'Para concluir tu solicitud, solo debes confirmar el código OTP que te llegó a tu celular, lo cual te dará la bienvenida al servicio.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(24, 2, '¿Cómo puedo programar la entrega de mi tarjeta a través de WhatsApp?', 'Para programar la entrega de tu tarjeta a través de WhatsApp, puedes contactar al número 554000-6590.', NULL, 0, 1, '2026-01-09 17:07:07', '2026-01-09 17:07:07');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(25, 2, '¿Qué identificaciones son aceptadas si no tengo la INE para la entrega de mi tarjeta?', 'Si no cuentas con la INE, debes presentar dos identificaciones de las siguientes: Pasaporte Mexicano, Cédula profesional (con fotografía), Cartilla del servicio militar nacional, Certificado de matrícula consular, Tarjeta Única de identidad militar, Tarjeta de afiliación al INAPAM, credenciales del IMSS, ISSSTE, Fuerzas Armadas o Seguro Popular, licencia para conducir, y otras identificaciones nacionales aprobadas por la Comisión.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(26, 2, '¿Qué documentación debo presentar al asesor de INVEX que me estará visitando?', 'Para la visita del asesor INVEX, necesitarás presentar la documentación original que incluye: una identificación oficial, como la credencial de elector o pasaporte y licencia vigente; y un comprobante de domicilio, que puede ser la credencial de elector, recibo de teléfono, agua o estado de cuenta bancario a nombre del prospecto, no mayor a 3 meses y que no esté vencido.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(27, 2, '¿Qué documentación debo presentar al asesor INVEX durante la entrega de la tarjeta de crédito?', 'El asesor INVEX que te visitará te pedirá que presentes documentación original, como tu identificación. Asegúrate de tener todo listo para facilitar el proceso.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(28, 2, '¿Cuánto tiempo toma recibir una respuesta sobre mi solicitud de tarjeta de crédito?', 'Una vez que completes tu solicitud, recibirás una llamada en un lapso no mayor a 24 horas para agendar la entrega de tu nueva tarjeta de crédito si tu solicitud ha sido aprobada.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(29, 2, '¿Es necesario autorizar la grabación de la conversación para continuar con el trámite?', 'Sí, es obligatorio que autorices la grabación de la conversación para poder continuar con el trámite de tu tarjeta de crédito. Necesitamos una respuesta afirmativa para seguir adelante.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(30, 2, '¿Qué información necesito proporcionar durante la validación de mi tarjeta de crédito?', 'Durante la validación, necesitarás proporcionar tu nombre completo, domicilio, RFC, fecha de nacimiento y si eres titular de alguna tarjeta de crédito bancaria vigente. También se te preguntará de qué institución es tu tarjeta.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(31, 2, '¿Cuál es el costo de la anualidad de la tarjeta Volaris INVEX?', 'El costo de la anualidad de la tarjeta Volaris INVEX incluye el costo o comisiones por no uso más IVA. Si deseas más detalles, no dudes en preguntar.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(32, 2, '¿Qué debo hacer si tengo dudas sobre los beneficios de la tarjeta Invex?', 'Si tienes alguna duda sobre los beneficios de la tarjeta Invex, no dudes en preguntar. Estaremos encantados de proporcionarte la información que necesites sobre el producto.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(33, 2, '¿Cuál es el proceso para validar mis datos de buro de crédito para obtener una tarjeta de crédito Invex?', 'Para validar tus datos de buro de crédito y acelerar el trámite de tu tarjeta de crédito Invex, necesitas responder a 4 preguntas en línea que nos autorizan a acceder a tu buro de crédito sin necesidad de tu firma. Es importante que todos los datos que proporciones sean correctos para que podamos ofrecerte una respuesta oportuna a tu solicitud.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(34, 2, '¿Qué es la validación y cómo se lleva a cabo?', 'La validación es una etapa en el proceso de obtención de la tarjeta de crédito donde se solicitan documentos y datos al cliente para confirmar su identidad y situación crediticia. Es recomendable explicar al cliente qué se va a solicitar y por qué, para brindarles confianza y mantener su atención en la línea.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(35, 2, '¿Qué información debo capturar durante el proceso de venta?', 'Es importante capturar datos demográficos completos y correctos del cliente, incluyendo su teléfono de contacto (celular y local), fecha de nacimiento (DD/MM/AAAA), correo electrónico para enviar la activación de la tarjeta y la dirección de casa con números exteriores e interiores.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(36, 2, '¿Cómo se cierra la venta de la tarjeta de crédito Volaris?', 'El cierre de la venta se realiza asegurando que el cliente haya respondido afirmativamente a todas las preguntas de verificación. Es importante cerrar con seguridad, afirmando la venta, y no dejar silencios. Por ejemplo, confirmar el nombre completo del cliente antes de proceder con la captura de datos.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(37, 2, '¿Qué requisitos debo cumplir para obtener la tarjeta de crédito Volaris?', 'Para obtener la tarjeta de crédito Volaris, debes ser titular de una tarjeta de crédito bancaria o comercial con al menos un año de antigüedad, estar al corriente con los pagos de todas tus tarjetas de crédito, y tu línea de crédito debe ser mayor o igual a $7,000 MXP. Además, la edad del cliente debe estar entre 18 y 75 años con 11 meses.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(38, 2, '¿Cuáles son los beneficios de la tarjeta de crédito Volaris?', 'Los beneficios de la tarjeta de crédito Volaris incluyen 25 kg de equipaje gratis para ti y tus acompañantes, la opción de meses sin intereses (MSI) en vuelos de 3, 6 o 11 meses, y 30% de bonificación en Starbucks al pagar en línea con la tarjeta. También se ofrece 2x1 en Cinepolis en sala tradicional.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(39, 2, '¿Qué recomendaciones se dan al Ejecutivo Telefónico para atender al cliente?', 'El Ejecutivo debe esmerarse en atender al cliente, escuchar con atención, cuidar su vocabulario, hablar en afirmativo, responder a las preguntas de forma concreta, y proporcionar información correcta y actualizada.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(40, 2, '¿Qué beneficios se obtienen al utilizar la tarjeta de crédito Volaris Invex?', 'Los beneficios incluyen acumulaciones en Monedero Volaris INVEX que varían de 1.0% a 2.5% según el tipo de compra, y equipaje gratis de 25kg para el titular y sus acompañantes al volar.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(41, 2, '¿Cuáles son algunos de los beneficios de la tarjeta de crédito Volaris Invex que se deben mencionar al cliente?', 'Algunos beneficios incluyen un vuelo de bienvenida a tarifa aérea cero, la anulación de la anualidad el primer año, y la acumulación de porcentajes en Monedero Volaris INVEX dependiendo del uso de la tarjeta.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(42, 2, '¿Cuánto tiempo tarda el área de validación en responder si la tarjeta de crédito fue aprobada?', 'Una vez capturados los datos del cliente, el área de validación responde en un plazo de 5 minutos respecto a la aprobación de la tarjeta de crédito.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(43, 2, '¿Cuál es el propósito de la llamada según el script?', 'El propósito de la llamada puede ser ofrecer una línea de crédito, presentar la nueva tarjeta de crédito Volaris, o dar seguimiento a una solicitud previa.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(44, 2, '¿Qué términos no se deben utilizar al presentarse durante la llamada?', 'No está permitido presentarse con los nombres de Volaris, ni Banco INVEX y Volaris; hacerlo puede resultar en una penalización.', NULL, 0, 1, '2026-01-09 17:11:13', '2026-01-09 17:11:13');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(45, 2, '¿Qué información se debe proporcionar al prospecto al iniciar la llamada?', 'El Ejecutivo Telefónico debe presentarse diciendo su nombre y apellido paterno, además de solicitar ser comunicado con el Sr. o Sra. prospecto por su nombre y apellido.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(46, 2, '¿Quién es el ET en el contexto de este script de venta telefónica?', 'El ET se refiere al Ejecutivo Telefónico, quien realiza las llamadas a los clientes en el proceso de venta.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(47, 2, '¿Qué beneficios se ofrecen para compras en el extranjero con la tarjeta Volaris INVEX?', 'Los titulares de la tarjeta Volaris INVEX pueden disfrutar de 6 meses sin intereses en compras realizadas en el extranjero, con un monto mínimo de compra de $700 pesos. Este beneficio puede diferirse a través de la app INVEX control.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(48, 2, '¿Cuál es el bono de aniversario que ofrece el Monedero Volaris?', 'Se ofrece un bono de aniversario de $1,000 pesos en el Monedero Volaris, el cual se obtiene al facturar anualmente un total de $100,000 pesos. Este bono tiene vigencia de un año a partir de la fecha en que se abona.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(49, 2, '¿Cuánto dinero se necesita acumular para usar el Monedero Volaris?', 'Puedes utilizar el Monedero Volaris cada vez que acumules $1,000 pesos. El dinero se deposita en tu Monedero cuando llegas a esa cantidad.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(50, 2, '¿Qué tipo de gastos se pueden pagar con el dinero acumulado en el Monedero Volaris?', 'El dinero acumulado en tu Monedero Volaris se puede utilizar para tarifas aéreas (boletos de avión), servicios opcionales e impuestos. Sin embargo, no se puede utilizar para el pago de servicios tercerizados como Shuttle, Hoteles, Actividades, Renta de Autos, Salones OMA VIP, Vía Asistencia, Cielito Limpio y Puente Fronterizo CBX.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(51, 2, '¿Cuáles son los plazos sin intereses para la compra de boletos de avión?', 'Se ofrecen plazos de 3, 6 y 11 meses sin intereses para la compra de boletos de avión.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(52, 2, '¿Qué incluye el vuelo de bienvenida que se puede reservar con la tarjeta?', 'El vuelo de bienvenida permite reservar un vuelo en Volaris pagando únicamente la TUA (Tarifa de Uso de Aeropuerto) a un destino nacional.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(53, 2, '¿Qué monto mínimo de compra se requiere para diferir a meses sin intereses en el extranjero?', 'El monto mínimo de compra requerido para diferir a meses sin intereses en el extranjero es de $1,000 pesos.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(54, 2, '¿Cuáles son los requisitos para obtener el bono de aniversario en el Monedero Volaris?', 'Para obtener el bono de aniversario de $400 pesos, se requiere una facturación anual de $70,000 pesos, y el bono tiene vigencia de 1 año a partir de la fecha en que se abona.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(55, 2, '¿Qué porcentaje se acumula en el Monedero Volaris por compras?', 'Se acumula un 2.0% en el Monedero Volaris en todas las compras, y un 2.5% en compras realizadas en Volaris.com.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(56, 2, '¿Cuánto equipaje documentado se permite en rutas nacionales al pagar con la tarjeta Volaris?', 'Se permite 25 kg de equipaje documentado en rutas nacionales al pagar con la tarjeta Volaris.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(57, 2, '¿Cuál es el costo de la anualidad de la tarjeta después del primer año?', 'A partir del segundo año, el costo de la anualidad es de $4,621 pesos sin IVA.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(58, 2, '¿A quiénes se aplica el 15% de descuento en alimentos a bordo?', 'El 15% de descuento aplica solo para tarjetas aprobadas y activadas, y para clientes que estén al corriente con sus obligaciones de pago.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(59, 2, '¿Cuál es el límite de bonificación en alimentos a bordo por vuelo?', 'El límite de bonificación es de $150 pesos por tarjeta de crédito, por vuelo.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(60, 2, '¿Qué porcentaje de bonificación se ofrece en la compra de alimentos a bordo?', 'Se ofrece un 15% de bonificación en la compra de alimentos a bordo.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(61, 2, '¿Cuál es el monto mínimo para compras con meses sin intereses en el extranjero?', 'El monto mínimo para realizar compras con meses sin intereses en el extranjero es de $1,000 pesos, y puedes diferirlo a través de la app INVEX Control.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(62, 2, '¿Qué debo hacer para obtener el bono de aniversario en Monedero Volaris?', 'Para obtener el bono de aniversario de $300 pesos en Monedero Volaris, debes tener una facturación anual de al menos $50,000 pesos. Este bono tiene una vigencia de un año a partir de la fecha en que se abona.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(63, 2, '¿Qué es el Monedero Volaris y cómo se acumula?', 'El Monedero Volaris permite acumular un 1.0% de tus compras realizadas con la Tarjeta de Crédito Volaris. El dinero acumulado puede ser utilizado para tarifas aéreas, servicios opcionales e impuestos, y se acredita en múltiplos de $500.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(64, 2, '¿Cuánto equipaje documentado obtengo al utilizar mi Tarjeta de Crédito en Volaris?', 'Al utilizar tu Tarjeta de Crédito Volaris, podrás documentar hasta 25 kg de equipaje en rutas nacionales sin costo adicional, siempre que se mencione correctamente en la venta o validación.', NULL, 0, 1, '2026-01-09 17:14:57', '2026-01-09 17:14:57');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(65, 2, '¿Qué requisitos debo cumplir para no pagar anualidad en la Tarjeta de Crédito Volaris?', 'Para no pagar anualidad, solo necesitas usar tu Tarjeta de Crédito Volaris INVEX al menos una vez al mes. Además, debes realizar una compra mínima de $200 al mes; de lo contrario, se generará un cobro de $195 más IVA.', NULL, 0, 1, '2026-01-09 17:16:05', '2026-01-09 17:16:05');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(66, 2, '¿Cómo funciona la bonificación del 15% en alimentos a bordo?', 'La bonificación del 15% en la compra de alimentos a bordo se reflejará en tu próximo Estado de Cuenta y está limitada a $150 pesos por Tarjeta de Crédito, por vuelo. Este beneficio solo aplica para tarjetas aprobadas y activadas, y para clientes que estén al corriente con sus obligaciones de pago.', NULL, 0, 1, '2026-01-09 17:16:05', '2026-01-09 17:16:05');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(67, 2, '¿Qué promociones de meses sin intereses ofrece Volaris?', 'Volaris ofrece promociones de 3, 6 y 11 meses sin intereses en la compra de boletos de avión, siempre que se mencione correctamente el beneficio durante la venta o validación.', NULL, 0, 1, '2026-01-09 17:16:05', '2026-01-09 17:16:05');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(68, 2, '¿Cuáles son las condiciones para el vuelo de bienvenida en Volaris?', 'Para el vuelo de bienvenida, deberás pagar únicamente la TUA y el destino debe ser nacional. Este beneficio aplica para un vuelo sencillo o redondo y es válido durante la temporada baja.', NULL, 0, 1, '2026-01-09 17:16:05', '2026-01-09 17:16:05');
INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(69, 2, '¿Qué beneficios obtengo al activar mi Tarjeta de Crédito Volaris?', 'Al activar tu Tarjeta de Crédito Volaris, podrás disfrutar de varios beneficios, incluyendo la posibilidad de reservar un vuelo con tarifa aérea cero, pagar únicamente la Tarifa de Uso de Aeropuerto (TUA) en vuelos nacionales, y acceder a promociones como meses sin intereses en boletos de avión.', NULL, 0, 1, '2026-01-09 17:16:05', '2026-01-09 17:16:05');


INSERT INTO WHATSAAP_ASSISTANT.BOT_PROMPTS
(id, id_bot, system_prompt, is_active, created_at, updated_at)
VALUES(1, 2, 'Eres un agente virtual de atención al cliente.

REGLAS OBLIGATORIAS:
- SOLO puedes responder usando la información proporcionada en la base de conocimiento.
- NO inventes información.
- NO respondas con conocimiento general que no esté en la base.
- Si la pregunta no está cubierta por la información disponible, responde EXACTAMENTE:
  "No cuento con esa información por el momento. Un asesor humano podrá ayudarte mejor 😊"

TONO:
- Profesional
- Claro
- Amable
- Conciso

IMPORTANTE:
Nunca sugieras abogados, leyes, opiniones personales ni información externa
a menos que esté explícitamente en la base de conocimiento.', 1, '2026-01-05 11:25:00', '2026-01-05 15:53:33');


-- WHATSAAP_ASSISTANT.BOT_PROMPTS definition

CREATE TABLE `BOT_PROMPTS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `system_prompt` text NOT NULL,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_bot` (`id_bot`),
  CONSTRAINT `BOT_PROMPTS_ibfk_1` FOREIGN KEY (`id_bot`) REFERENCES `BOTS` (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.USERS definition

CREATE TABLE `USERS` (
  `idUser` bigint NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `phone_number` bigint NOT NULL,
  `email_user` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `password` varchar(75) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci DEFAULT NULL,
  `rolid` bigint NOT NULL DEFAULT '1',
  `status` int NOT NULL DEFAULT '1',
  `datecreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idUser`),
  KEY `rolid` (`rolid`),
  KEY `fk_users` (`customer_id`),
  CONSTRAINT `fk_users` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMERS` (`id`) ON DELETE CASCADE,
  CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`rolid`) REFERENCES `ROLES` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_swedish_ci;

-- WHATSAAP_ASSISTANT.MODULES definition

CREATE TABLE `MODULES` (
  `idmodulo` bigint NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`idmodulo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_swedish_ci;

-- WHATSAAP_ASSISTANT.PERMISSIONS definition

CREATE TABLE `PERMISSIONS` (
  `idpermiso` bigint NOT NULL AUTO_INCREMENT,
  `rolid` bigint NOT NULL,
  `moduloid` bigint NOT NULL,
  `r` int NOT NULL DEFAULT '0',
  `w` int NOT NULL DEFAULT '0',
  `u` int NOT NULL DEFAULT '0',
  `d` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`idpermiso`),
  KEY `rolid` (`rolid`),
  KEY `moduloid` (`moduloid`),
  CONSTRAINT `PERMISSIONS_ibfk_1` FOREIGN KEY (`rolid`) REFERENCES `ROLES` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PERMISSIONS_ibfk_2` FOREIGN KEY (`moduloid`) REFERENCES `MODULES` (`idmodulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_swedish_ci;

-- WHATSAAP_ASSISTANT.ROLES definition

CREATE TABLE `ROLES` (
  `idrol` bigint NOT NULL AUTO_INCREMENT,
  `nombrerol` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_swedish_ci NOT NULL,
  `status` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`idrol`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_swedish_ci;





CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_role_crud`(
    IN p_option INT,
    IN p_idRol INT,
    IN p_name VARCHAR(100),
    IN p_description VARCHAR(255),
    IN p_status TINYINT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_dependencia INT DEFAULT 0;
    DECLARE v_result BOOLEAN DEFAULT FALSE;
   
    CASE p_option
        WHEN 1 THEN
             SELECT 
	        idRol as ID,
        	name AS NOMBRE,
        	description AS DESCRIPCION,
        	created_at AS FECHA_CREACION,
        	status
    				FROM ROLES
    				ORDER BY idRol asc;            
        WHEN 2 THEN
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                SELECT 
                    idRol as ID,
                    name AS NOMBRE,
                    description AS DESCRIPCION,
                    created_at AS FECHA_CREACION,
                    status
                FROM ROLES
                WHERE idRol = p_idRol;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Message;
            END IF;
            
        WHEN 3 THEN
            -- Verificar si ya existe un rol con el mismo nombre
            SELECT COUNT(*) INTO v_exists 
            FROM ROLES 
            WHERE name = p_name;
            
            IF v_exists = 0 THEN
                INSERT INTO ROLES (name, description, status, created_at)
                VALUES (p_name, p_description, p_status, NOW());
                
                SELECT 
                    'Rol creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_name AS Nombre;
            ELSE
                SELECT 'Ya existe un rol con ese nombre' AS Error;
            END IF;
            
        WHEN 4 THEN
            -- Verificar si existe el rol a actualizar
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                UPDATE ROLES 
                SET 
                    name = COALESCE(p_name, name),
                    description = COALESCE(p_description, description),
                    status = COALESCE(p_status, status)
                WHERE idRol = p_idRol;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Rol actualizado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Error;
            END IF;
            
        WHEN 5 THEN
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                -- Verificar si hay usuarios asignados a este rol (dependiendo de tu modelo de datos)
                -- Si no hay dependencias, proceder con la eliminación
                
                -- Eliminación lógica (recomendado)
                UPDATE ROLES 
                SET status = 0 
                WHERE idRol = p_idRol;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Rol desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Error;
            END IF;
           
            WHEN 6 THEN      
          SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;         
          SELECT COUNT(*) INTO v_dependencia FROM USERS u WHERE rolid = p_idRol;
         
            IF v_exists > 0 THEN
                IF v_dependencia = 0 THEN
                SET v_result = TRUE;
                -- Eliminación
                DELETE FROM ROLES WHERE idRol = p_idRol;
                SELECT CONCAT('Rol eliminado exitosamente') AS Message, v_result as status;
               ELSE
                SELECT 'No es posible eliminar un Rol asociado a usuarios.' AS Message, v_result as status;
               END IF;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Message;
            END IF;           
        ELSE
            SELECT 'Opción no válida. Use: GET_ALL, GET_BY_ID, INSERT, UPDATE, DELETE' AS Error;
    END CASE;
    
    procedure_label: BEGIN END;
END





CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_user_crud`(
    IN p_option INT,
    IN p_idUser INT,
    IN p_name VARCHAR(100),
    IN p_last_name VARCHAR(50),
    IN phone_number VARCHAR(10),
    IN p_email VARCHAR(100),
    IN p_password VARCHAR(255),
    IN p_role_id INT,
    IN p_status TINYINT
)
main_block: BEGIN

    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_result BOOLEAN DEFAULT FALSE;

    CASE p_option

        WHEN 1 THEN
            -- GET ALL
            SELECT 
                u.idUser AS ID,
                CONCAT_WS(u.name, ' ', u.last_name) AS NOMBRE,
                r.name AS NOMBRE_ROL,
                u.status
            FROM USERS u
            LEFT JOIN ROLES r ON u.rolid = r.idRol
            ORDER BY u.idUser;

        WHEN 2 THEN
            -- GET BY ID
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE idUser = p_idUser;

            IF v_exists > 0 THEN
                SELECT 
                    u.idUser AS ID,
                    CONCAT_WS(u.name, ' ', u.last_name) AS NOMBRE,
                    u.phone_number,
                    u.email_user AS EMAIL,
                    u.rolid AS ID_ROL,
                    r.name AS NOMBRE_ROL,
                    u.created_at AS FECHA_CREACION,
                    u.status
                FROM USERS u
                LEFT JOIN ROLES r ON u.rolid = r.idRol
                WHERE u.idUser = p_idUser;
            ELSE
                SELECT 'No se encontró el usuario con el ID especificado' AS Error;
            END IF;

        WHEN 3 THEN
            -- INSERT
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE email_user = p_email;

            IF v_exists = 0 THEN            	
                SET v_result = TRUE;
               
                INSERT INTO USERS (name, last_name, phone_number, email_user, password, rolid, status, created_at)
                VALUES (p_name, p_last_name, phone_number, p_email, p_password, p_role_id, p_status, NOW());

                SELECT 
                    'Usuario creado exitosamente' AS Message, v_result as status;
            ELSE
                SELECT '¡Atención! el email o la identificación ya existe, ingrese otro' AS Message , v_result as status;
            END IF;

        WHEN 4 THEN
            -- UPDATE
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE idUser = p_idUser;

            IF v_exists = 0 THEN
                SELECT 'No se encontró el usuario con el ID especificado' AS Error, v_result as status;               
            END IF;

            -- Validar email duplicado
            IF p_email IS NOT NULL THEN
                SELECT COUNT(*) INTO v_exists
                FROM USERS
                WHERE email_user = p_email
                  AND idUser != p_idUser;

                IF v_exists > 0 THEN
                    SELECT 'Ya existe otro usuario con ese email' AS Error, v_result as status;
                END IF;
            END IF;

            UPDATE USERS
            SET
                name     = COALESCE(p_name, name),
                email_user = COALESCE(p_email, email_user),
                password = COALESCE(p_password, password),
                rolid  = COALESCE(p_role_id, rolid),
                status   = COALESCE(p_status, status)
            WHERE idUser = p_idUser;
           
            SELECT 'Usuario actualizado exitosamente.' AS Message, v_result as status;

        WHEN 5 THEN
            -- DELETE lógico
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE idUser = p_idUser;

            IF v_exists > 0 THEN
            SET v_result = TRUE;                
            DELETE from USERS WHERE idUser = p_idUser;                         
                SELECT 'Usuario Eliminado Exitosamente.' AS Message, v_result as status;
            ELSE
                SELECT 'No se encontró el usuario con el ID especificado' AS Error,v_result as status;
            END IF;

        WHEN 6 THEN
            -- LOGIN
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE email = p_email
              AND password = p_password
              AND status = 1;

            IF v_exists > 0 THEN
                SELECT
                    u.idUser AS ID,
                    u.name AS NOMBRE,
                    u.email AS EMAIL,
                    u.role_id AS ID_ROL,
                    r.name AS NOMBRE_ROL,
                    u.created_at AS FECHA_CREACION,
                    u.status,
                    'Login exitoso' AS Message
                FROM USERS u
                LEFT JOIN ROLES r ON u.role_id = r.idRol
                WHERE u.email = p_email
                  AND u.password = p_password
                  AND u.status = 1;
            ELSE
                SELECT 'Credenciales inválidas o usuario inactivo' AS Error;
            END IF;

        ELSE
            SELECT 'Opción no válida' AS Error;

    END CASE;

END





CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_bot_crud`(
    IN p_option INT,      -- Opciones: 'GET_ALL', 'GET_BY_ID', 'GET_BY_TYPE', 'INSERT', 'UPDATE', 'DELETE'
    IN p_id_bot INT,
    IN p_nombre VARCHAR(100),
    IN p_descripcion TEXT,
    IN p_tipo ENUM('cobranza','ventas','seguros','tarjetas','soporte','gen'),
    IN p_estado ENUM('activo','inactivo'),
    IN p_LLM INT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_llm_exists INT DEFAULT 0;
    
    -- Validar parámetros obligatorios según la operación
    IF UPPER(p_option) IN ('GET_BY_ID', 'UPDATE', 'DELETE') AND p_id_bot IS NULL THEN
        SELECT 'El parámetro p_id_bot es obligatorio para esta operación' AS Error;
    END IF;
    
    IF UPPER(p_option) = 'INSERT' AND (p_nombre IS NULL OR p_LLM IS NULL) THEN
        SELECT 'Los parámetros p_nombre y p_LLM son obligatorios para INSERT' AS Error;
    END IF;
    
    -- Validar que el LLM exista (si tienes tabla de LLMs)
    -- IF p_LLM IS NOT NULL THEN
    --     SELECT COUNT(*) INTO v_llm_exists FROM LLMS_TABLE WHERE id_llm = p_LLM;
    --     IF v_llm_exists = 0 THEN
    --         SELECT 'El LLM especificado no existe' AS Error;
    --         LEAVE procedure_label;
    --     END IF;
    -- END IF;
    
    CASE UPPER(p_option)
        WHEN 1 THEN
            -- Obtener todos los bots
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
            ORDER BY b.id_bot DESC;
            
        WHEN 2 THEN
            -- Obtener un bot específico por ID
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                SELECT 
                    b.id_bot as ID,
                    b.nombre AS NOMBRE,
                    b.descripcion AS DESCRIPCION,
                    b.tipo AS TIPO,
                    b.estado AS ESTADO,
                    b.LLM AS ID_LLM,
                    -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                    b.created_at AS FECHA_CREACION,
                    CASE 
                        WHEN b.estado = 'activo' THEN 1
                        WHEN b.estado = 'inactivo' THEN 0
                    END AS STATUS_NUMERIC
                FROM BOTS b
                -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
                WHERE b.id_bot = p_id_bot;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Message;
            END IF;
            
        WHEN 3 THEN
            -- Obtener bots por tipo
            IF p_tipo IS NULL THEN
                SELECT 'El parámetro p_tipo es obligatorio para GET_BY_TYPE' AS Error;
            END IF;
            
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            WHERE b.tipo = p_tipo
            AND b.estado = 'activo'  -- Solo bots activos
            ORDER BY b.nombre;
            
        WHEN 4 THEN
            -- Obtener solo bots activos
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION
            FROM BOTS b
            WHERE b.estado = 'activo'
            ORDER BY b.tipo, b.nombre;
            
        WHEN 5 THEN
            -- Verificar si ya existe un bot con el mismo nombre
            SELECT COUNT(*) INTO v_exists 
            FROM BOTS 
            WHERE nombre = p_nombre;
            
            IF v_exists = 0 THEN
                INSERT INTO BOTS (nombre, descripcion, tipo, estado, LLM, created_at)
                VALUES (
                    p_nombre, 
                    p_descripcion, 
                    COALESCE(p_tipo, 'gen'), 
                    COALESCE(p_estado, 'activo'), 
                    p_LLM, 
                    NOW()
                );
                
                SELECT 
                    'Bot creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_nombre AS Nombre,
                    p_tipo AS Tipo;
            ELSE
                SELECT 'Ya existe un bot con ese nombre' AS Error;
            END IF;
            
        WHEN 6 THEN
            -- Verificar si existe el bot a actualizar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Si se está actualizando el nombre, verificar que no exista otro bot con el mismo nombre
                IF p_nombre IS NOT NULL THEN
                    SELECT COUNT(*) INTO v_exists 
                    FROM BOTS 
                    WHERE nombre = p_nombre AND id_bot != p_id_bot;
                    
                    IF v_exists > 0 THEN
                        SELECT 'Ya existe otro bot con ese nombre' AS Error;
                    END IF;
                END IF;
                
                UPDATE BOTS 
                SET 
                    nombre = COALESCE(p_nombre, nombre),
                    descripcion = COALESCE(p_descripcion, descripcion),
                    tipo = COALESCE(p_tipo, tipo),
                    estado = COALESCE(p_estado, estado),
                    LLM = COALESCE(p_LLM, LLM)
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot actualizado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 7 THEN
            -- Verificar si existe el bot a eliminar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Eliminación lógica (recomendado)
                UPDATE BOTS 
                SET estado = 'inactivo'
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 8 THEN
            -- Cambiar solo el estado del bot
            IF p_id_bot IS NULL OR p_estado IS NULL THEN
                SELECT 'p_id_bot y p_estado son obligatorios para CHANGE_STATUS' AS Error;
            END IF;
            
            UPDATE BOTS 
            SET estado = p_estado
            WHERE id_bot = p_id_bot;
            
            SET v_rowcount = ROW_COUNT();
            
            IF v_rowcount > 0 THEN
                SELECT CONCAT('Estado del bot actualizado a: ', p_estado, '. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        ELSE
            SELECT 'Opción no válida. Use: GET_ALL, GET_BY_ID, GET_BY_TYPE, GET_ACTIVE, INSERT, UPDATE, DELETE, CHANGE_STATUS' AS Error;
    END CASE;
END






CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_bot_crud`(
    IN p_option INT,      -- Opciones: 'GET_ALL', 'GET_BY_ID', 'GET_BY_TYPE', 'INSERT', 'UPDATE', 'DELETE'
    IN p_id_bot INT,
    IN p_nombre VARCHAR(100),
    IN p_descripcion TEXT,
    IN p_tipo ENUM('cobranza','ventas','seguros','tarjetas','soporte','gen'),
    IN p_estado ENUM('activo','inactivo'),
    IN p_LLM INT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_llm_exists INT DEFAULT 0;
    
    -- Validar parámetros obligatorios según la operación
    IF UPPER(p_option) IN ('GET_BY_ID', 'UPDATE', 'DELETE') AND p_id_bot IS NULL THEN
        SELECT 'El parámetro p_id_bot es obligatorio para esta operación' AS Error;
    END IF;
    
    IF UPPER(p_option) = 'INSERT' AND (p_nombre IS NULL OR p_LLM IS NULL) THEN
        SELECT 'Los parámetros p_nombre y p_LLM son obligatorios para INSERT' AS Error;
    END IF;
    
    -- Validar que el LLM exista (si tienes tabla de LLMs)
    -- IF p_LLM IS NOT NULL THEN
    --     SELECT COUNT(*) INTO v_llm_exists FROM LLMS_TABLE WHERE id_llm = p_LLM;
    --     IF v_llm_exists = 0 THEN
    --         SELECT 'El LLM especificado no existe' AS Error;
    --         LEAVE procedure_label;
    --     END IF;
    -- END IF;
    
    CASE UPPER(p_option)
        WHEN 1 THEN
            -- Obtener todos los bots
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
            ORDER BY b.id_bot DESC;
            
        WHEN 2 THEN
            -- Obtener un bot específico por ID
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                SELECT 
                    b.id_bot as ID,
                    b.nombre AS NOMBRE,
                    b.descripcion AS DESCRIPCION,
                    b.tipo AS TIPO,
                    b.estado AS ESTADO,
                    b.LLM AS ID_LLM,
                    -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                    b.created_at AS FECHA_CREACION,
                    CASE 
                        WHEN b.estado = 'activo' THEN 1
                        WHEN b.estado = 'inactivo' THEN 0
                    END AS STATUS_NUMERIC
                FROM BOTS b
                -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
                WHERE b.id_bot = p_id_bot;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Message;
            END IF;
            
        WHEN 3 THEN
            -- Obtener bots por tipo
            IF p_tipo IS NULL THEN
                SELECT 'El parámetro p_tipo es obligatorio para GET_BY_TYPE' AS Error;
            END IF;
            
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            WHERE b.tipo = p_tipo
            AND b.estado = 'activo'  -- Solo bots activos
            ORDER BY b.nombre;
            
        WHEN 4 THEN
            -- Obtener solo bots activos
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION
            FROM BOTS b
            WHERE b.estado = 'activo'
            ORDER BY b.tipo, b.nombre;
            
        WHEN 5 THEN
            -- Verificar si ya existe un bot con el mismo nombre
            SELECT COUNT(*) INTO v_exists 
            FROM BOTS 
            WHERE nombre = p_nombre;
            
            IF v_exists = 0 THEN
                INSERT INTO BOTS (nombre, descripcion, tipo, estado, LLM, created_at)
                VALUES (
                    p_nombre, 
                    p_descripcion, 
                    COALESCE(p_tipo, 'gen'), 
                    COALESCE(p_estado, 'activo'), 
                    p_LLM, 
                    NOW()
                );
                
                SELECT 
                    'Bot creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_nombre AS Nombre,
                    p_tipo AS Tipo;
            ELSE
                SELECT 'Ya existe un bot con ese nombre' AS Error;
            END IF;
            
        WHEN 6 THEN
            -- Verificar si existe el bot a actualizar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Si se está actualizando el nombre, verificar que no exista otro bot con el mismo nombre
                IF p_nombre IS NOT NULL THEN
                    SELECT COUNT(*) INTO v_exists 
                    FROM BOTS 
                    WHERE nombre = p_nombre AND id_bot != p_id_bot;
                    
                    IF v_exists > 0 THEN
                        SELECT 'Ya existe otro bot con ese nombre' AS Error;
                    END IF;
                END IF;
                
                UPDATE BOTS 
                SET 
                    nombre = COALESCE(p_nombre, nombre),
                    descripcion = COALESCE(p_descripcion, descripcion),
                    tipo = COALESCE(p_tipo, tipo),
                    estado = COALESCE(p_estado, estado),
                    LLM = COALESCE(p_LLM, LLM)
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot actualizado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 7 THEN
            -- Verificar si existe el bot a eliminar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Eliminación lógica (recomendado)
                UPDATE BOTS 
                SET estado = 'inactivo'
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 8 THEN
            -- Cambiar solo el estado del bot
            IF p_id_bot IS NULL OR p_estado IS NULL THEN
                SELECT 'p_id_bot y p_estado son obligatorios para CHANGE_STATUS' AS Error;
            END IF;
            
            UPDATE BOTS 
            SET estado = p_estado
            WHERE id_bot = p_id_bot;
            
            SET v_rowcount = ROW_COUNT();
            
            IF v_rowcount > 0 THEN
                SELECT CONCAT('Estado del bot actualizado a: ', p_estado, '. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        ELSE
            SELECT 'Opción no válida. Use: GET_ALL, GET_BY_ID, GET_BY_TYPE, GET_ACTIVE, INSERT, UPDATE, DELETE, CHANGE_STATUS' AS Error;
    END CASE;
END



CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_inbox_crud`(
    IN p_option INT,
    session_id VARCHAR(50)
)
main_block: BEGIN

    CASE p_option

        WHEN 1 THEN
            -- GET CONVERSATION ACTIVE
            SELECT 
      cs.session_uuid,
      cs.status,
      cs.last_activity,
      cs.assigned_agent_id,
      cs.customer_name as name,
      b.nombre as bot_name,
      (
        SELECT message_text 
        FROM BOTS_CONVERSATION_LOG 
        WHERE conversation_id = cs.session_uuid
        ORDER BY created_at DESC 
        LIMIT 1
      ) AS last_message
    FROM CHAT_SESSIONS cs
    join BOTS b on cs.id_bot= b.id_bot
    ORDER BY cs.last_activity DESC
    LIMIT 50;
   		WHEN 2 THEN 
   		SELECT id_webhook, role, message_text
       FROM BOTS_CONVERSATION_LOG
       WHERE conversation_id = session_id
         AND channel = 'web'
       ORDER BY created_at ASC;
        ELSE
            SELECT 'Opción no válida' AS Error;
    END CASE;
END



CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_quick_replies_crud`(
    IN p_option INT,
    IN id_bot INT,
    IN channel varchar(10)   
)
main_block: BEGIN

    CASE p_option

        WHEN 1 THEN
           -- GET quick replies
    SELECT id, shortcut, title, message_text
    FROM QUICK_REPLIES
    WHERE id_bot = id_bot
      AND channel = channel
      AND is_active = 1
    ORDER BY title ASC;
        ELSE
            SELECT 'Opción no válida' AS Error;
    END CASE;
END





-- bots_db.QUICK_REPLIES definition

CREATE TABLE `QUICK_REPLIES` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `shortcut` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message_text` text NOT NULL,
  `channel` enum('web','whatsapp') DEFAULT 'web',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bot` (`id_bot`),
  KEY `idx_shortcut` (`shortcut`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
---------------------------------------------------------------------------------------------------------------------------------------------
-- bots_db.BOTS definition

CREATE TABLE `BOTS` (
  `id_bot` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('cobranza','ventas','seguros','tarjetas','soporte','gen') COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci DEFAULT 'activo',
  `llm` int NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bot`),
  KEY `idx_customer` (`customer_id`),
  CONSTRAINT `fk_bot_customer` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMERS` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




-- bots_db.BOTS_CONVERSATION_LOG definition

CREATE TABLE `BOTS_CONVERSATION_LOG` (
  `id_webhook` int NOT NULL AUTO_INCREMENT,
  `event_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `wamid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_text` text COLLATE utf8mb4_unicode_ci,
  `channel` enum('web','whatsapp','voice') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `role` enum('user','assistant','agent','system') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'assistant',
  `conversation_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_json` json NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_webhook`),
  KEY `idx_from_created` (`from_number`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=950 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- bots_db.CHAT_SESSIONS definition

CREATE TABLE `CHAT_SESSIONS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT '1',
  `session_uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` enum('web','whatsapp') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `status` enum('bot','human','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'bot',
  `assigned_agent_id` bigint DEFAULT NULL,
  `id_bot` int NOT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Anonimo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_uuid` (`session_uuid`),
  KEY `client_id` (`client_id`),
  KEY `fk_bot_chat_sessions` (`id_bot`),
  CONSTRAINT `CHAT_SESSIONS_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `CUSTOMERS` (`id`),
  CONSTRAINT `fk_bot_chat_sessions` FOREIGN KEY (`id_bot`) REFERENCES `BOTS` (`id_bot`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- bots_db.CUSTOMERS definition

CREATE TABLE `CUSTOMERS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_client_key` (`client_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- bots_db.MODULES definition

CREATE TABLE `MODULES` (
  `idmodule` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'folder',
  `route` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#',
  `order` int DEFAULT '0',
  `status` tinyint DEFAULT '1' COMMENT '1=Activo, 0=Inactivo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idmodule`),
  UNIQUE KEY `uk_titulo` (`title`),
  KEY `idx_status` (`status`),
  KEY `idx_orden` (`order`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- bots_db.PERMISSIONS definition

CREATE TABLE `PERMISSIONS` (
  `idpermiso` bigint NOT NULL AUTO_INCREMENT,
  `rolid` bigint NOT NULL,
  `submodule_id` int NOT NULL,
  `r` int NOT NULL DEFAULT '0',
  `w` int NOT NULL DEFAULT '0',
  `u` int NOT NULL DEFAULT '0',
  `d` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`idpermiso`),
  KEY `rolid` (`rolid`),
  KEY `module_id` (`submodule_id`),
  CONSTRAINT `PERMISSIONS_ibfk_1` FOREIGN KEY (`rolid`) REFERENCES `ROLES` (`idRol`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PERMISSIONS_ibfk_2` FOREIGN KEY (`submodule_id`) REFERENCES `SUB_MODULES` (`idsubmodule`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_swedish_ci;


-- bots_db.QUICK_REPLIES definition

CREATE TABLE `QUICK_REPLIES` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `shortcut` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` enum('web','whatsapp') COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bot` (`id_bot`),
  KEY `idx_shortcut` (`shortcut`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- bots_db.ROLES definition

CREATE TABLE `ROLES` (
  `idRol` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint DEFAULT '1' COMMENT '1=Activo, 0=Inactivo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idRol`),
  UNIQUE KEY `uk_nombre` (`name`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- bots_db.SUB_MODULES definition

CREATE TABLE `SUB_MODULES` (
  `idsubmodule` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `module_id` int NOT NULL,
  `route` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'circle',
  `order` int DEFAULT '0',
  `status` tinyint DEFAULT '1' COMMENT '1=Activo, 0=Inactivo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idsubmodule`),
  UNIQUE KEY `uk_titulo_module` (`title`,`module_id`),
  KEY `idx_module_id` (`module_id`),
  KEY `idx_status` (`status`),
  KEY `idx_orden` (`order`),
  CONSTRAINT `fk_submodules_module` FOREIGN KEY (`module_id`) REFERENCES `MODULES` (`idmodule`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- bots_db.USERS definition

CREATE TABLE `USERS` (
  `idUser` bigint NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_customer` (`customer_id`),
  KEY `fk_users_rol` (`role_id`),
  CONSTRAINT `fk_users_customer` FOREIGN KEY (`customer_id`) REFERENCES `CUSTOMERS` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_users_rol` FOREIGN KEY (`role_id`) REFERENCES `ROLES` (`idRol`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-------------------------------------------------------------------------------------------------------------------------------------
CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_bot_crud`(
    IN p_option INT,      -- Opciones: 'GET_ALL', 'GET_BY_ID', 'GET_BY_TYPE', 'INSERT', 'UPDATE', 'DELETE'
    IN p_id_bot INT,
    IN p_nombre VARCHAR(100),
    IN p_descripcion TEXT,
    IN p_tipo ENUM('cobranza','ventas','seguros','tarjetas','soporte','gen'),
    IN p_estado ENUM('activo','inactivo'),
    IN p_LLM INT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_llm_exists INT DEFAULT 0;
    
    -- Validar parámetros obligatorios según la operación
    IF UPPER(p_option) IN ('GET_BY_ID', 'UPDATE', 'DELETE') AND p_id_bot IS NULL THEN
        SELECT 'El parámetro p_id_bot es obligatorio para esta operación' AS Error;
    END IF;
    
    IF UPPER(p_option) = 'INSERT' AND (p_nombre IS NULL OR p_LLM IS NULL) THEN
        SELECT 'Los parámetros p_nombre y p_LLM son obligatorios para INSERT' AS Error;
    END IF;
    
    -- Validar que el LLM exista (si tienes tabla de LLMs)
    -- IF p_LLM IS NOT NULL THEN
    --     SELECT COUNT(*) INTO v_llm_exists FROM LLMS_TABLE WHERE id_llm = p_LLM;
    --     IF v_llm_exists = 0 THEN
    --         SELECT 'El LLM especificado no existe' AS Error;
    --         LEAVE procedure_label;
    --     END IF;
    -- END IF;
    
    CASE UPPER(p_option)
        WHEN 1 THEN
            -- Obtener todos los bots
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
            ORDER BY b.id_bot DESC;
            
        WHEN 2 THEN
            -- Obtener un bot específico por ID
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                SELECT 
                    b.id_bot as ID,
                    b.nombre AS NOMBRE,
                    b.descripcion AS DESCRIPCION,
                    b.tipo AS TIPO,
                    b.estado AS ESTADO,
                    b.LLM AS ID_LLM,
                    -- l.nombre AS NOMBRE_LLM, -- Si tienes tabla de LLMs
                    b.created_at AS FECHA_CREACION,
                    CASE 
                        WHEN b.estado = 'activo' THEN 1
                        WHEN b.estado = 'inactivo' THEN 0
                    END AS STATUS_NUMERIC
                FROM BOTS b
                -- LEFT JOIN LLMS l ON b.LLM = l.id_llm -- Si tienes tabla de LLMs
                WHERE b.id_bot = p_id_bot;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Message;
            END IF;
            
        WHEN 3 THEN
            -- Obtener bots por tipo
            IF p_tipo IS NULL THEN
                SELECT 'El parámetro p_tipo es obligatorio para GET_BY_TYPE' AS Error;
            END IF;
            
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION,
                CASE 
                    WHEN b.estado = 'activo' THEN 1
                    WHEN b.estado = 'inactivo' THEN 0
                END AS STATUS_NUMERIC
            FROM BOTS b
            WHERE b.tipo = p_tipo
            AND b.estado = 'activo'  -- Solo bots activos
            ORDER BY b.nombre;
            
        WHEN 4 THEN
            -- Obtener solo bots activos
            SELECT 
                b.id_bot as ID,
                b.nombre AS NOMBRE,
                b.descripcion AS DESCRIPCION,
                b.tipo AS TIPO,
                b.estado AS ESTADO,
                b.LLM AS ID_LLM,
                b.created_at AS FECHA_CREACION
            FROM BOTS b
            WHERE b.estado = 'activo'
            ORDER BY b.tipo, b.nombre;
            
        WHEN 5 THEN
            -- Verificar si ya existe un bot con el mismo nombre
            SELECT COUNT(*) INTO v_exists 
            FROM BOTS 
            WHERE nombre = p_nombre;
            
            IF v_exists = 0 THEN
                INSERT INTO BOTS (nombre, descripcion, tipo, estado, LLM, created_at)
                VALUES (
                    p_nombre, 
                    p_descripcion, 
                    COALESCE(p_tipo, 'gen'), 
                    COALESCE(p_estado, 'activo'), 
                    p_LLM, 
                    NOW()
                );
                
                SELECT 
                    'Bot creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_nombre AS Nombre,
                    p_tipo AS Tipo;
            ELSE
                SELECT 'Ya existe un bot con ese nombre' AS Error;
            END IF;
            
        WHEN 6 THEN
            -- Verificar si existe el bot a actualizar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Si se está actualizando el nombre, verificar que no exista otro bot con el mismo nombre
                IF p_nombre IS NOT NULL THEN
                    SELECT COUNT(*) INTO v_exists 
                    FROM BOTS 
                    WHERE nombre = p_nombre AND id_bot != p_id_bot;
                    
                    IF v_exists > 0 THEN
                        SELECT 'Ya existe otro bot con ese nombre' AS Error;
                    END IF;
                END IF;
                
                UPDATE BOTS 
                SET 
                    nombre = COALESCE(p_nombre, nombre),
                    descripcion = COALESCE(p_descripcion, descripcion),
                    tipo = COALESCE(p_tipo, tipo),
                    estado = COALESCE(p_estado, estado),
                    LLM = COALESCE(p_LLM, LLM)
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot actualizado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 7 THEN
            -- Verificar si existe el bot a eliminar
            SELECT COUNT(*) INTO v_exists FROM BOTS WHERE id_bot = p_id_bot;
            
            IF v_exists > 0 THEN
                -- Eliminación lógica (recomendado)
                UPDATE BOTS 
                SET estado = 'inactivo'
                WHERE id_bot = p_id_bot;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Bot desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        WHEN 8 THEN
            -- Cambiar solo el estado del bot
            IF p_id_bot IS NULL OR p_estado IS NULL THEN
                SELECT 'p_id_bot y p_estado son obligatorios para CHANGE_STATUS' AS Error;
            END IF;
            
            UPDATE BOTS 
            SET estado = p_estado
            WHERE id_bot = p_id_bot;
            
            SET v_rowcount = ROW_COUNT();
            
            IF v_rowcount > 0 THEN
                SELECT CONCAT('Estado del bot actualizado a: ', p_estado, '. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el bot con el ID especificado' AS Error;
            END IF;
            
        ELSE
            SELECT 'Opción no válida. Use: GET_ALL, GET_BY_ID, GET_BY_TYPE, GET_ACTIVE, INSERT, UPDATE, DELETE, CHANGE_STATUS' AS Error;
    END CASE;
END


CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_inbox_crud`(
    IN p_option INT,
    session_id VARCHAR(50)
)
main_block: BEGIN

    CASE p_option

        WHEN 1 THEN
            -- GET CONVERSATION ACTIVE
            SELECT 
      cs.session_uuid,
      cs.status,
      cs.last_activity,
      cs.assigned_agent_id,
      cs.customer_name as name,
      b.nombre as bot_name,
      (
        SELECT message_text 
        FROM BOTS_CONVERSATION_LOG 
        WHERE conversation_id = cs.session_uuid
        ORDER BY created_at DESC 
        LIMIT 1
      ) AS last_message
    FROM CHAT_SESSIONS cs
    join BOTS b on cs.id_bot= b.id_bot
    ORDER BY cs.last_activity DESC
    LIMIT 50;
   		WHEN 2 THEN 
   		SELECT id_webhook, role, message_text
       FROM BOTS_CONVERSATION_LOG
       WHERE conversation_id = session_id
       ORDER BY created_at ASC;
        ELSE
            SELECT 'Opción no válida' AS Error;
    END CASE;
END


CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_quick_replies_crud`(
    IN p_option INT,
    id_bot INT,
    channel varchar(10)   
)
main_block: BEGIN

    CASE p_option

        WHEN 1 THEN
           -- GET quick replies
    SELECT id, shortcut, title, message_text
    FROM QUICK_REPLIES
    WHERE id_bot = id_bot
      AND channel = channel
      AND is_active = 1
    ORDER BY title ASC;
        ELSE
            SELECT 'Opción no válida' AS Error;
    END CASE;
END



CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_role_crud`(
    IN p_option INT,
    IN p_idRol INT,
    IN p_name VARCHAR(100),
    IN p_description VARCHAR(255),
    IN p_status TINYINT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;
    
    CASE UPPER(p_option)
        WHEN 1 THEN
             SELECT 
	        idRol as ID,
        	name AS NOMBRE,
        	description AS DESCRIPCION,
        	created_at AS FECHA_CREACION,
        	status
    				FROM ROLES
    				ORDER BY idRol;            
        WHEN 2 THEN
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                SELECT 
                    idRol as ID,
                    name AS NOMBRE,
                    description AS DESCRIPCION,
                    created_at AS FECHA_CREACION,
                    status
                FROM ROLES
                WHERE idRol = p_idRol;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Message;
            END IF;
            
        WHEN 3 THEN
            -- Verificar si ya existe un rol con el mismo nombre
            SELECT COUNT(*) INTO v_exists 
            FROM ROLES 
            WHERE name = p_name;
            
            IF v_exists = 0 THEN
                INSERT INTO ROLES (name, description, status, created_at)
                VALUES (p_name, p_description, p_status, NOW());
                
                SELECT 
                    'Rol creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_name AS Nombre;
            ELSE
                SELECT 'Ya existe un rol con ese nombre' AS Error;
            END IF;
            
        WHEN 4 THEN
            -- Verificar si existe el rol a actualizar
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                UPDATE ROLES 
                SET 
                    name = COALESCE(p_name, name),
                    description = COALESCE(p_description, description),
                    status = COALESCE(p_status, status)
                WHERE idRol = p_idRol;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Rol actualizado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Error;
            END IF;
            
        WHEN 5 THEN
            -- Verificar si existe el rol a eliminar
            SELECT COUNT(*) INTO v_exists FROM ROLES WHERE idRol = p_idRol;
            
            IF v_exists > 0 THEN
                -- Verificar si hay usuarios asignados a este rol (dependiendo de tu modelo de datos)
                -- Si no hay dependencias, proceder con la eliminación
                
                -- Eliminación lógica (recomendado)
                UPDATE ROLES 
                SET status = 0 
                WHERE idRol = p_idRol;
                
                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Rol desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el rol con el ID especificado' AS Error;
            END IF;
            
        ELSE
            SELECT 'Opción no válida. Use: GET_ALL, GET_BY_ID, INSERT, UPDATE, DELETE' AS Error;
    END CASE;
    
    procedure_label: BEGIN END;
END


CREATE DEFINER=`bots_user`@`%` PROCEDURE `bots_db`.`sp_user_crud`(
    IN p_option INT,    
    IN p_customer_id INT,
    IN p_idUser INT,
    IN p_name VARCHAR(50),
    IN p_last_name VARCHAR(50),
    IN p_phone_number VARCHAR(10),
    IN p_email VARCHAR(100),
    IN p_password VARCHAR(255),
    IN p_role_id INT,
    IN p_status TINYINT
)
BEGIN
    DECLARE v_rowcount INT;
    DECLARE v_exists INT DEFAULT 0;

    CASE p_option

        WHEN 1 THEN
            -- GET ALL
            SELECT 
                u.idUser AS ID,
                CONCAT(u.name,' ', u.last_name) AS NOMBRE,
                u.email AS EMAIL,
                r.name AS NOMBRE_ROL,
                u.created_at AS FECHA_CREACION,
                u.status
            FROM USERS u
            LEFT JOIN ROLES r ON u.role_id = r.idRol
            ORDER BY u.idUser;

        WHEN 2 THEN
            -- GET BY ID
            SELECT COUNT(*) INTO v_exists 
            FROM USERS 
            WHERE idUser = p_idUser;

            IF v_exists > 0 THEN
                SELECT 
                    u.idUser AS ID,
                    u.name AS NOMBRE,
                    u.last_name AS APELLIDO,
                    u.phone_number,
                    u.email AS EMAIL,
                    u.password AS PASSWORD,
                    u.role_id AS ID_ROL,
                    r.name AS NOMBRE_ROL,
                    u.created_at AS FECHA_CREACION,
                    u.status
                FROM USERS u
                LEFT JOIN ROLES r ON u.role_id = r.idRol
                WHERE u.idUser = p_idUser;
            ELSE
                SELECT 'No se encontró el usuario con el ID especificado' AS Error;
            END IF;

        WHEN 3 THEN
            -- INSERT
            SELECT COUNT(*) INTO v_exists 
            FROM USERS 
            WHERE email = p_email;

            IF v_exists = 0 THEN
                INSERT INTO USERS (customer_id, name, email, password, role_id, status, created_at)
                VALUES (p_customer_id, p_name, p_email, p_password, p_role_id, p_status, NOW());

                SELECT 
                    'Usuario creado exitosamente' AS Message,
                    LAST_INSERT_ID() AS NewID,
                    p_name AS Nombre,
                    p_email AS Email;
            ELSE
                SELECT 'Ya existe un usuario con ese email' AS Error;
            END IF;

        WHEN 4 THEN
            -- UPDATE
            SELECT COUNT(*) INTO v_exists 
            FROM USERS 
            WHERE idUser = p_idUser;

            IF v_exists = 0 THEN
                SELECT 'No se encontró el usuario con el ID especificado' AS Error;
            END IF;

            -- Validar email duplicado
            IF p_email IS NOT NULL THEN
                SELECT COUNT(*) INTO v_exists
                FROM USERS
                WHERE email = p_email
                  AND idUser != p_idUser;

                IF v_exists > 0 THEN
                    SELECT 'Ya existe otro usuario con ese email' AS Error;
                END IF;
            END IF;

            UPDATE USERS
            SET
                name     = COALESCE(p_name, name),
                email    = COALESCE(p_email, email),
                last_name    = COALESCE(p_last_name, last_name),
                phone_number    = COALESCE(p_phone_number, phone_number),             
                password = COALESCE(p_password, password),
                role_id  = COALESCE(p_role_id, role_id),
                status   = COALESCE(p_status, status)
            WHERE idUser = p_idUser;

            SET v_rowcount = ROW_COUNT();
            SELECT CONCAT('Usuario actualizado exitosamente.') AS Message;

        WHEN 5 THEN
            -- DELETE (lógico)
            SELECT COUNT(*) INTO v_exists 
            FROM USERS 
            WHERE idUser = p_idUser;

            IF v_exists > 0 THEN
                UPDATE USERS
                SET status = 0
                WHERE idUser = p_idUser;

                SET v_rowcount = ROW_COUNT();
                SELECT CONCAT('Usuario desactivado exitosamente. Filas afectadas: ', v_rowcount) AS Message;
            ELSE
                SELECT 'No se encontró el usuario con el ID especificado' AS Error;
            END IF;

        WHEN 6 THEN
            -- LOGIN
            SELECT COUNT(*) INTO v_exists
            FROM USERS
            WHERE email = p_email
              AND password = p_password
              AND status = 1;

            IF v_exists > 0 THEN
                SELECT 
                    u.idUser AS ID,
                    u.name AS NOMBRE,
                    u.email AS EMAIL,
                    u.role_id AS ID_ROL,
                    r.name AS NOMBRE_ROL,
                    u.created_at AS FECHA_CREACION,
                    u.status,
                    'Login exitoso' AS Message
                FROM USERS u
                LEFT JOIN ROLES r ON u.role_id = r.idRol
                WHERE u.email = p_email
                  AND u.password = p_password
                  AND u.status = 1;
            ELSE
                SELECT 'Credenciales inválidas o usuario inactivo' AS Error;
            END IF;

        ELSE
            SELECT 'Opción no válida' AS Error;

    END CASE;
END
------------------------------------------------------------------------------------------------------------------------------------------