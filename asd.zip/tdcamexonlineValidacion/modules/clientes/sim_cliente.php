<?php
# sim_cliente File 
# @uthor Mark      

require_once("../includes/includes.inc.php");
require_once("clientes.inc.php");

$action = $_REQUEST["action"]; 
$plan_index = (isset($_REQUEST["plan_index"])?$_REQUEST["plan_index"]:0);

initialize("clientes","Busqueda de Clientes");

layout_menu($db);

$statement = get_cliente_by_folio(get_varname_session("folio_cliente"));
$cliente = get_row($statement);

$nombre = $cliente[0];
$oferta = $cliente[1];
$capital = convert_to_money($cliente[2]);
$tdc = $cliente[3];
/*****************************************************************/
//Simulador al 100 // 1 -> 100 --> 1
//Simulador Refin 100% con bonif cuota 612 y 18  // 2 -> 100B --> 2
//Simulador al 75  // 3 -> 75  -->  3
//Simulador al 75 Con Bonificacion  // 4 -> 75B  -->  4
//Simulador al 50  // 5 -> 50   -->  5  <-- mayores a 10000 -->
//Simulador al 50 Con Bonificacion  // 6 -> 50B  -->  6
//Simulador al 100% 6 meses  // 6 -> 50B  -->  7
//Simulador al 100% 12 meses  // 6 -> 50B  -->  8 <--light-->
//Simulador al 100% solo LIGHT --> 9
//Simulador al 75% solo LIGHT --> 10
//Simulador al 100% 18 meses --> 11
/*****************************************************************/
$nombre_planes = array("Simulador al 100%","Simulador Refin 100% con bonif cuota 6 12 y 18","Simulador al 75%","Simulador al 75% Con Bonificacion","Simulador al 50%","Simulador al 50% Con Bonificacion","Simulador al 100% 6 meses","Simulador al 100% 12 meses","Simulador al 100% solo LIGHT","Simulador al 75% solo LIGHT","Simulador al 100% 18 meses");

if($oferta == 1) {	//LIGHT

	$planes = array(9);
	(isset($plan_index) && $plan_index != 0?set_varname_session("plan_selected",$plan_index):set_varname_session("plan_selected",$planes[0])); 

}else{ 

	if($capital >= 10001){ //MAYOR A 10000
		$planes = array(5);
		(isset($plan_index) && $plan_index != 0?set_varname_session("plan_selected",$plan_index):set_varname_session("plan_selected",$planes[0])); 
	}else if($capital <= 10000){ //MENOR A 10000
		$planes = array(8);
		(isset($plan_index) && $plan_index != 0?set_varname_session("plan_selected",$plan_index):set_varname_session("plan_selected",$planes[0])); 
	}
	
}

set_varname_session("planes",$planes);
$plan_selected = get_varname_session("plan_selected");

if($plan_selected == 5 || $plan_selected ==6){
	$pago = 0.0384 * $capital; //50%
	$plazo = 22;
}else if($plan_selected == 3 || $plan_selected == 4){
	$pago = 0.0475 * $capital;//75%	
	$plazo = 22;
}else if($plan_selected == 1 || $plan_selected == 2){
	$pago = 0.07 * $capital;//100%	
	$plazo = 18;
}else if($plan_selected == 7){
	$pago = 0.1785 * $capital;//100%	
	$plazo = 6;
}else if($plan_selected == 8){
	$pago = 0.0946 * $capital;//100%	
	$plazo = 12;
}else if($plan_selected == 9){
	$pago = 0.0509 * $capital;//100%	
	$plazo = 24;
}else if($plan_selected == 10){
	$pago = 0.0425 * $capital;//75%	
	$plazo = 24;
}else if($plan_selected == 11){
	$pago = 0.0667  * $capital;//100%	
	$plazo = 18;
}

if($oferta == 1){
	$tasa = 20.0;
}else{
	$tasa = 24.0;
}
$porcentaje_pago_mensual = $pago / $capital;

$suma_pago_fijo_mensual =0;
$suma_interes_mensual = 0;
$suma_capital_amortizado = 0;
$suma_interes_mas_capital = 0;

$planes_arr = get_varname_session("planes");

echo '<p class="textbold">Clientes &gt; Simulador</p><p>&nbsp;</p>
		<form method="post" action="'.$linkpath.'clientes/sim_cliente.php" name="frm1" id="fmr_2">
			<input type="hidden" value="" name="action">
			<input type="hidden" value="" name="capital1" id="capital1">
			<input type="hidden" value="'.$pago.'" name="pago_mens" id="pago_mens">
			<input type="hidden" value="'.$plazo.'" name="plazo" id="plazo">
			<input type="hidden" value="'.number_format(($porcentaje_pago_mensual * 100)).'" name="porc_pago" id="porc_pago">
			<input type="hidden" value="" name="estatus_tdc" id="estatus_tdc">
			
			<table class="text" border="0">
				<tr>
					<td class="textright"><b>Cliente:&nbsp;</b></td>
					<td><p>'.$nombre.'</p></td>
				</tr><tr>
					<td class="textright"><b>TDC:&nbsp;</b></td>
					<td><p><input type="text" value="'.$tdc.'" maxlength="20" size="20" name="last4" id="last4"></p></td>
				</tr><tr>
					<td> &nbsp;</td>
				</tr>
			</table>
			
			<table border="0" width="45%">
				<tr>
					<td class="textleft" colspan="4">
						<p>
							<b>Oferta:</b>
							<select name="plan_index" id="plan_index">';
							foreach($planes_arr as $v){
								echo "<option value=\"".$v."\" ".($v==$plan_selected?"selected":"").">".$nombre_planes[$v-1]."</option>";			
							}
						echo '</select>
						</p>
					</td>
				</tr><tr>
					<td class="textleft"><b>Saldo:</b>&nbsp;</td>
					<td><input type="text" name="capital" value="'.get_money_format($capital,2).'" size="6" id="capital" onkeypress="return pulsar(event)"></td>
					<td class="textleft"><b>Tasa:</b>&nbsp;</td>
					<td>'.$tasa.'%</td>
				</tr><tr>
					<td class="textleft"><b>Pago:</b>&nbsp;</td>
					<td>'.get_money_format(round($pago),0).'</td>
					<td class="textleft"><b>Plazo:</b>&nbsp;</td>
					<td>'.$plazo.'</td>
				</tr><tr>
					'.(($oferta == "PPF8" && $plan_selected == 9) || ($oferta == "MENOS 10000")?'
					<td class="textleft"><b>Importe a Refinaciar:</b></td>
					<td class="textleft">'.get_money_format($capital,2).'</td>':'<td class="textleft" colspan="2">&nbsp;</td>').'
					<td class="textleft"><b>% de pago mensual:</b>&nbsp;</td>
					<td class="textleft">'.number_format($porcentaje_pago_mensual * 100).'%</td>
				</tr>
			</table>
			<br><br>
			<table border="0" width="70%" id="sim">
				<tr bgcolor="gray">
					<td class="textleft">&nbsp;</td>
					<td class="textleft">&nbsp;</td>
					<td class="textleft">&nbsp;</td>
					<td class="textleft">&nbsp;</td>
					<td colspan="2"><center><b>Pago Mensual</b>&nbsp;<center></td>
					<td class="textleft">&nbsp;</td>
				</tr><tr bgcolor="gray">
					<td class="textleft"><b>N� Pago</b>&nbsp;</td>
					<td><center><b>Saldo</b>&nbsp;</center></td>
					<td><center><b>Tasa Mensual</b>&nbsp;</center></td>
					<td><center><b>Pago Fijo Mensual</b>&nbsp;</center></td>
					<td><center><b>Interes Mensual</b>&nbsp;</center></td>
					<td><center><b>Capital Amortizado</b>&nbsp;</center></td>
					<td><center><b>Suma<br>interes + capital</b>&nbsp;</center></td>
				</tr>';
			for($num_pago = 1; $num_pago <= ($plazo+1); $num_pago++){

				$tasa_mensual = $tasa / 12;
				$pago_fijo_mensual = $pago;
				$saldo = ($num_pago==1?$capital:$saldo - $capital_amortizado);			
				$interes_mensual = ($tasa_mensual * $saldo)/100;
				$capital_amortizado = $pago_fijo_mensual - $interes_mensual;
				$interes_mas_capital = $interes_mensual + $capital_amortizado;
				
				if($plazo == 18)
					$plazo_1 = $plazo;
				else{
					if($oferta == "MENOS 10000" && $plan_selected == 7 ){
						$plazo_1 = 6;
					}elseif($oferta == "MENOS 10000" && $plan_selected == 8){
						$plazo_1 = 12;		
					}elseif($oferta == "MENOS 10000" && $plan_selected == 11){
						$plazo_1 = 18;		
					}else if($oferta == "PPF8"){
						$plazo_1 = 24;
					}else{
						$plazo_1 = 22;		
					}
				}	
				
				//if($num_pago <= $plazo){
				if($saldo >= 1){
					if($num_pago <= $plazo_1){
						$suma_pago_fijo_mensual += $pago_fijo_mensual;
						$suma_interes_mensual += $interes_mensual;
						$suma_capital_amortizado += $capital_amortizado;
						$suma_interes_mas_capital += $interes_mas_capital;
					}
				}
				
				
				/*if($plan_selected == 2){
					if($num_pago == 6 || $num_pago == 12 || $num_pago == 18){
						echo "<tr bgcolor=\"#e5aa6b\"><td>".$num_pago."</td><td>".get_money_format($saldo,0)."</td><td><center>".number_format($tasa_mensual,1)."%</center></td><td><center>&nbsp<center></td><td><center>&nbsp;</center></td><td><center>&nbsp;</center></td><td><center>&nbsp;</center></td></tr>";
					}else{
						echo "<tr><td>".$num_pago."</td><td>".get_money_format($saldo,0)."</td><td><center>".number_format($tasa_mensual,1)."%</center></td><td><center>".get_money_format(round($pago_fijo_mensual),0)."<center></td><td><center>".get_money_format(ceil($interes_mensual),0)."</center></td><td><center>".get_money_format(ceil($capital_amortizado),0)."</center></td><td><center>".get_money_format($interes_mas_capital,0)."</center></td></tr>";									
					}
				}else{*/
					echo "<tr><td>".$num_pago."</td><td>".get_money_format($saldo,0)."</td><td><center>".number_format($tasa_mensual,1)."%</center></td><td><center>".get_money_format(round($pago_fijo_mensual),0)."<center></td><td><center>".get_money_format(ceil($interes_mensual),0)."</center></td><td><center>".get_money_format(ceil($capital_amortizado),0)."</center></td><td><center>".get_money_format($interes_mas_capital,0)."</center></td></tr>";									
				//}
			}
			echo "<tr>
						<td><b>TOTAL</b></td>
						<td>&nbsp;</td>
						<td><center>&nbsp;</center></td>
						<td><center><b>".get_money_format(round($suma_pago_fijo_mensual),0)."</b><center></td>
						<td><center><b>".get_money_format(ceil($suma_interes_mensual),0)."</b></center></td>
						<td><center><b>".get_money_format(ceil($suma_capital_amortizado),0)."</b></center></td>
						<td><center><b>".get_money_format($suma_interes_mas_capital,0)."</b></center></td>
					</tr>
				</table>
				<br><br>
				<table>
					<tr>
						<td>&nbsp;</td>
					</tr><tr>";

			if($plan_selected == 5 || $plan_selected == 3 || $plan_selected == 10){
				echo "<td><b>% Monto pendiente</b></td><td>".number_format(($saldo/$capital)*100)." %</td>
					</tr><tr>
						<td><b>Monto pendiente de pago</b></td><td>$".get_money_format($saldo,0)."</td>
					</tr>";
			}else if($plan_selected == 2){
				echo "<td><b>% Monto total de 3 cuotas a bonificar</b></td><td>".number_format(($pago_fijo_mensual)*3)." </td>
					</tr>";
			}else if($plan_selected == 6){
				echo "<td><b>% Monto a bonificar</b></td><td>".number_format(($saldo/$capital)*100)." %</td>
					</tr><tr>
					<td><b> Monto bonificado por Santander</b></td><td>$".get_money_format($saldo/2,0)."</td>
					</tr><tr>
						<td><b>Monto pendiente de pago</b></td><td>$".get_money_format($saldo/2,0)."</td>
					</tr>";
			}else if($plan_selected == 4){
				echo "<td><b>% Monto a bonificar</b></td><td>".number_format(($saldo/$capital)*100)." %</td>
					</tr><tr>
					<td><b>Monto bonificado por Santander</b></td><td>$".get_money_format($saldo,0)."</td>
					</tr>";
			}
echo '</table></form>
	  <p>&nbsp;</p>
	  <input type="button" value="Regresar" onclick="back()"/>&nbsp;&nbsp;
	  <input type="button" value="Continuar" onclick="GuardaValidando()"/>';


layout_footer();
?>