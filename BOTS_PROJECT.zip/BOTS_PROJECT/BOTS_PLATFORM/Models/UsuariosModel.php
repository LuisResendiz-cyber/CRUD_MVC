<?php 

class UsuariosModel extends Mysql
{
    private $intIdUsuario;
    private $strIdentificacion;
    private $strNombre;
    private $strApellido;
    private $intTelefono;
    private $strEmail;
    private $strPassword;
    private $strToken;
    private $intTipoId;
    private $intStatus;
    private $strNit;
    private $strNomFiscal;
    private $strDirFiscal;

    public function __construct()
    {
        parent::__construct();
    }

    // ============================================
    // MÉTODO ORIGINAL (MANTENER)
    // ============================================
    public function insertUsuario(string $identificacion, string $nombre, string $apellido, int $telefono, string $email, string $password, int $tipoid, int $status){
        
        // DECISIÓN: ¿Usar API o BD directa?
        if (USE_API) {
            return $this->insertUsuarioAPI($identificacion, $nombre, $apellido, $telefono, $email, $password, $tipoid, $status);
        } else {
            return $this->insertUsuarioLocal($identificacion, $nombre, $apellido, $telefono, $email, $password, $tipoid, $status);
        }
    }

    // ============================================
    // NUEVO MÉTODO: Insertar usuario vía API (AJUSTADO)
    // ============================================
    private function insertUsuarioAPI(string $identificacion, string $nombre, string $apellido, int $telefono, string $email, string $password, int $tipoid, int $status) {
        
        // Mapear datos al formato que espera tu API Node.js
        $data = [
            'customer_id' => $identificacion,
            'name' => $nombre,
            'last_name' => $apellido,
            'phone_number' => (string)$telefono, // Convertir a string por si acaso
            'email_user' => $email,
            'passwordHash' => $password, // Ya viene hasheado desde el controlador
            'rolid' => $tipoid
            // Nota: No incluyo 'status' porque no está en tu JSON de ejemplo
            // Si tu API lo necesita, agrega: 'status' => $status
        ];

        // Llamar a la API Node.js
        $response = api_post('Users/CreateUser', $data);
        
        if ($response['success']) {
            // Éxito: retornar el ID del usuario creado
            // Verificamos la respuesta de tu API
            return $response['data']['id'] ?? 1; // Si no retorna ID, asumimos éxito
        } else {
            // Manejar errores de API
            if (isset($response['data']['error'])) {
                $errorMsg = strtolower($response['data']['error']);
                
                // Detectar si es error de duplicado
                if (strpos($errorMsg, 'ya existe') !== false || 
                    strpos($errorMsg, 'duplicate') !== false ||
                    strpos($errorMsg, 'already exists') !== false) {
                    return "exist"; // Mantener compatibilidad con tu código
                }
            }
            
            // Si la API falla, intentar con BD local como fallback
            log_api_error("API falló: " . json_encode($response));
            return $this->insertUsuarioLocal($identificacion, $nombre, $apellido, $telefono, $email, $password, $tipoid, $status);
        }
    }

    // ============================================
    // MÉTODO LOCAL (mantener como fallback)
    // ============================================
    private function insertUsuarioLocal(string $identificacion, string $nombre, string $apellido, int $telefono, string $email, string $password, int $tipoid, int $status){

        $this->strIdentificacion = $identificacion;
        $this->strNombre = $nombre;
        $this->strApellido = $apellido;
        $this->intTelefono = $telefono;
        $this->strEmail = $email;
        $this->strPassword = $password;
        $this->intTipoId = $tipoid;
        $this->intStatus = $status;
        $return = 0;

        $sql = "SELECT * FROM persona WHERE 
                email_user = '{$this->strEmail}' or identificacion = '{$this->strIdentificacion}' ";
        $request = $this->select_all($sql);

        if(empty($request))
        {
            $query_insert  = "INSERT INTO persona(identificacion,nombres,apellidos,telefono,email_user,password,rolid,status) 
                              VALUES(?,?,?,?,?,?,?,?)";
            $arrData = array($this->strIdentificacion,
                        $this->strNombre,
                        $this->strApellido,
                        $this->intTelefono,
                        $this->strEmail,
                        $this->strPassword,
                        $this->intTipoId,
                        $this->intStatus);
            $request_insert = $this->insert($query_insert,$arrData);
            $return = $request_insert;
        }else{
            $return = "exist";
        }
        return $return;
    }

    // ============================================
    // AGREGAR ESTOS NUEVOS MÉTODOS PARA API
    // ============================================
    
    /**
     * Obtener usuarios desde API con mapeo de campos
     */
    public function getUsuariosAPI() {
        $response = api_get('Users/GetAllUsers');
        
        if ($response['success']) {
            // Mapear la respuesta de la API a nuestro formato interno
            $usuarios = [];
            foreach ($response['data'] as $usuarioAPI) {
                $usuarios[] = [
                    'idpersona' => $usuarioAPI['id'] ?? $usuarioAPI['customer_id'] ?? null,
                    'identificacion' => $usuarioAPI['customer_id'] ?? '',
                    'nombres' => $usuarioAPI['name'] ?? '',
                    'apellidos' => $usuarioAPI['last_name'] ?? '',
                    'telefono' => $usuarioAPI['phone_number'] ?? '',
                    'email_user' => $usuarioAPI['email_user'] ?? '',
                    'status' => $usuarioAPI['status'] ?? 1,
                    'idrol' => $usuarioAPI['rolid'] ?? 0,
                    'nombrerol' => $this->getNombreRol($usuarioAPI['rolid'] ?? 0)
                ];
            }
            return $usuarios;
        }
        
        // Fallback a BD local
        log_api_error("API falló en getUsuariosAPI: " . json_encode($response));
        return $this->selectUsuarios();
    }
    
    /**
     * Obtener un usuario específico desde API
     */
    public function getUsuarioAPI($idpersona) {
        $response = api_get("Users/GetUser/{$idpersona}");
        
        if ($response['success']) {
            $usuarioAPI = $response['data'];
            
            // Mapear a nuestro formato
            return [
                'idpersona' => $usuarioAPI['id'] ?? $usuarioAPI['customer_id'] ?? null,
                'identificacion' => $usuarioAPI['customer_id'] ?? '',
                'nombres' => $usuarioAPI['name'] ?? '',
                'apellidos' => $usuarioAPI['last_name'] ?? '',
                'telefono' => $usuarioAPI['phone_number'] ?? '',
                'email_user' => $usuarioAPI['email_user'] ?? '',
                'nit' => $usuarioAPI['nit'] ?? '',
                'nombrefiscal' => $usuarioAPI['nombrefiscal'] ?? '',
                'direccionfiscal' => $usuarioAPI['direccionfiscal'] ?? '',
                'idrol' => $usuarioAPI['rolid'] ?? 0,
                'nombrerol' => $this->getNombreRol($usuarioAPI['rolid'] ?? 0),
                'status' => $usuarioAPI['status'] ?? 1,
                'fechaRegistro' => $usuarioAPI['datecreated'] ?? date('d-m-Y')
            ];
        }
        
        // Fallback a BD local
        log_api_error("API falló en getUsuarioAPI: " . json_encode($response));
        return $this->selectUsuario($idpersona);
    }
    
    /**
     * Método auxiliar para obtener nombre del rol
     */
    private function getNombreRol($rolid) {
        // Si estamos usando API, podrías necesitar un endpoint para roles
        // Por ahora, lo mantenemos local
        $sql = "SELECT nombrerol FROM rol WHERE idrol = ?";
        $request = $this->select($sql, [$rolid]);
        return $request['nombrerol'] ?? 'Sin rol';
    }
    
    /**
     * Método unificado que decide usar API o BD
     */
    public function getUsuariosUnified() {
        if (USE_API) {
            return $this->getUsuariosAPI();
        } else {
            return $this->selectUsuarios();
        }
    }
    
    /**
     * Método para probar conexión con API
     */
    public function testAPIConnection() {
        $response = api_get('Users/GetAllUsers');
        
        return [
            'success' => $response['success'],
            'code' => $response['code'],
            'message' => $response['success'] ? 'Conexión exitosa' : 'Error de conexión',
            'data' => $response['data'] ?? null
        ];
    }

    // ============================================
    // MANTENER TODOS TUS MÉTODOS EXISTENTES SIN CAMBIOS
    // ============================================
    public function selectUsuarios()
    {
        $whereAdmin = "";
        if(isset($_SESSION['idUser']) && $_SESSION['idUser'] != 1 ){
            $whereAdmin = " and p.idpersona != 1 ";
        }
        $sql = "SELECT p.idpersona,p.identificacion,p.nombres,p.apellidos,p.telefono,p.email_user,p.status,r.idrol,r.nombrerol 
                FROM persona p 
                INNER JOIN rol r
                ON p.rolid = r.idrol
                WHERE p.status != 0 ".$whereAdmin;
                $request = $this->select_all($sql);
                return $request;
    }
    
    public function selectUsuario(int $idpersona){
        $this->intIdUsuario = $idpersona;
        $sql = "SELECT p.idpersona,p.identificacion,p.nombres,p.apellidos,p.telefono,p.email_user,p.nit,p.nombrefiscal,p.direccionfiscal,r.idrol,r.nombrerol,p.status, DATE_FORMAT(p.datecreated, '%d-%m-%Y') as fechaRegistro 
                FROM persona p
                INNER JOIN rol r
                ON p.rolid = r.idrol
                WHERE p.idpersona = $this->intIdUsuario";
        $request = $this->select($sql);
        return $request;
    }

    public function updateUsuario(int $idUsuario, string $identificacion, string $nombre, string $apellido, int $telefono, string $email, string $password, int $tipoid, int $status){
        // Mantener igual por ahora
        $this->intIdUsuario = $idUsuario;
        $this->strIdentificacion = $identificacion;
        $this->strNombre = $nombre;
        $this->strApellido = $apellido;
        $this->intTelefono = $telefono;
        $this->strEmail = $email;
        $this->strPassword = $password;
        $this->intTipoId = $tipoid;
        $this->intStatus = $status;

        $sql = "SELECT * FROM persona WHERE (email_user = '{$this->strEmail}' AND idpersona != $this->intIdUsuario)
                                      OR (identificacion = '{$this->strIdentificacion}' AND idpersona != $this->intIdUsuario) ";
        $request = $this->select_all($sql);

        if(empty($request))
        {
            if($this->strPassword  != "")
            {
                $sql = "UPDATE persona SET identificacion=?, nombres=?, apellidos=?, telefono=?, email_user=?, password=?, rolid=?, status=? 
                        WHERE idpersona = $this->intIdUsuario ";
                $arrData = array($this->strIdentificacion,
                            $this->strNombre,
                            $this->strApellido,
                            $this->intTelefono,
                            $this->strEmail,
                            $this->strPassword,
                            $this->intTipoId,
                            $this->intStatus);
            }else{
                $sql = "UPDATE persona SET identificacion=?, nombres=?, apellidos=?, telefono=?, email_user=?, rolid=?, status=? 
                        WHERE idpersona = $this->intIdUsuario ";
                $arrData = array($this->strIdentificacion,
                            $this->strNombre,
                            $this->strApellido,
                            $this->intTelefono,
                            $this->strEmail,
                            $this->intTipoId,
                            $this->intStatus);
            }
            $request = $this->update($sql,$arrData);
        }else{
            $request = "exist";
        }
        return $request;
    
    }
    
    public function deleteUsuario(int $intIdpersona)
    {
        $this->intIdUsuario = $intIdpersona;
        $sql = "UPDATE persona SET status = ? WHERE idpersona = $this->intIdUsuario ";
        $arrData = array(0);
        $request = $this->update($sql,$arrData);
        return $request;
    }

    public function updatePerfil(int $idUsuario, string $identificacion, string $nombre, string $apellido, int $telefono, string $password){
        $this->intIdUsuario = $idUsuario;
        $this->strIdentificacion = $identificacion;
        $this->strNombre = $nombre;
        $this->strApellido = $apellido;
        $this->intTelefono = $telefono;
        $this->strPassword = $password;

        if($this->strPassword != "")
        {
            $sql = "UPDATE persona SET identificacion=?, nombres=?, apellidos=?, telefono=?, password=? 
                    WHERE idpersona = $this->intIdUsuario ";
            $arrData = array($this->strIdentificacion,
                            $this->strNombre,
                            $this->strApellido,
                            $this->intTelefono,
                            $this->strPassword);
        }else{
            $sql = "UPDATE persona SET identificacion=?, nombres=?, apellidos=?, telefono=? 
                    WHERE idpersona = $this->intIdUsuario ";
            $arrData = array($this->strIdentificacion,
                            $this->strNombre,
                            $this->strApellido,
                            $this->intTelefono);
        }
        $request = $this->update($sql,$arrData);
        return $request;
    }

    public function updateDataFiscal(int $idUsuario, string $strNit, string $strNomFiscal, string $strDirFiscal){
        $this->intIdUsuario = $idUsuario;
        $this->strNit = $strNit;
        $this->strNomFiscal = $strNomFiscal;
        $this->strDirFiscal = $strDirFiscal;
        $sql = "UPDATE persona SET nit=?, nombrefiscal=?, direccionfiscal=? 
                    WHERE idpersona = $this->intIdUsuario ";
        $arrData = array($this->strNit,
                        $this->strNomFiscal,
                        $this->strDirFiscal);
        $request = $this->update($sql,$arrData);
        return $request;
    }

}
?>