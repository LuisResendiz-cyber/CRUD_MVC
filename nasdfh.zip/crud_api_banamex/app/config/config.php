<?php
require_once __DIR__ . '../../../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../../'); // Ruta a la raíz del proyecto
$dotenv->load();


 
