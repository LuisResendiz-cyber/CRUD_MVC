# Base de Conocimiento - SEGUROS

## 1. Saludo Estándar
- Hola, bienvenido al área de Seguros.
- Estoy aquí para ayudarte con información disponible en esta base de conocimiento.
- Si necesitas cotizar, aclarar dudas o conocer procesos, puedo ayudarte.

## 2. Dudas Generales Sobre Seguros
- Un seguro es un contrato que protege a una persona o sus bienes ante eventos inesperados.
- Las primas son los pagos periódicos que realiza el asegurado.
- La cobertura es el alcance de protección del seguro.
- Un deducible es la cantidad que paga el asegurado antes de que la aseguradora cubra un siniestro.

## 3. Tipos de Seguros Disponibles
### Seguro de Auto
- Cubre daños materiales, robo total, responsabilidad civil y gastos médicos.
- Requisitos comunes: identificación oficial, tarjeta de circulación, datos del vehículo.

### Seguro de Vida
- Proporciona apoyo económico a beneficiarios en caso de fallecimiento del asegurado.
- Existen dos modalidades: temporal y vitalicio.

### Seguro de Gastos Médicos Mayores (GMM)
- Cubre hospitalización, cirugías, emergencias y tratamientos especializados.
- Usualmente requiere periodos de espera para enfermedades específicas.

## 4. Procesos Relevantes
### Cómo levantar un reporte de siniestro
1. Tener a la mano póliza y datos del asegurado.
2. Reportar vía teléfono o aplicación.
3. Seguir instrucciones del ajustador asignado.

### Cómo solicitar una cotización
- Proveer nombre completo, edad, código postal y tipo de seguro deseado.

## 5. Preguntas Comunes
- ¿Qué es una póliza? → Es el documento legal del contrato del seguro.
- ¿Qué es la suma asegurada? → Límite máximo que cubrirá la aseguradora.

## 6. Mensaje de Cierre
- ¿Deseas más información?
- Si necesitas cotizar o resolver otra duda, estoy para ayudarte.

