<?php 

class Inbox extends Controllers{
	
	private AuthService $auth;

	public function __construct()
	{
		parent::__construct();
		session_start();
		session_regenerate_id(true);
		if(empty($_SESSION['login']))
		{
			header('Location: '.base_url().'/login');
		}
		getPermisos(3);

	$this->auth = new AuthService();

	}

	public function Inbox()
	{
		if(empty($_SESSION['permisosMod']['r'])){
			header("Location:".base_url().'/dashboard');
		}
		$data['page_tag'] = "inbox";
		$data['page_title'] = "Inbox";
		$data['page_name'] = "bots";
		$data['page_functions_js'] = "functions_inbox.js";
		$this->views->getView($this,"inbox",$data);
	}
}

?>