CREATE DATABASE `WHATSAAP_ASSISTANT` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;


-- WHATSAAP_ASSISTANT.BOTS definition

CREATE TABLE `BOTS` (
  `id_bot` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo` enum('cobranza','ventas','seguros','tarjetas','soporte','gen') NOT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CHAT_SESSIONS definition

CREATE TABLE `CHAT_SESSIONS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT '1',
  `session_uuid` char(36) NOT NULL,
  `channel` enum('web','whatsapp') DEFAULT 'web',
  `status` enum('bot','human','closed') DEFAULT 'bot',
  `assigned_agent_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_uuid` (`session_uuid`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `CHAT_SESSIONS_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `CUSTOMERS` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CUSTOMERS definition

CREATE TABLE `CUSTOMERS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_key` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_key` (`client_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.DATA_NUMEROS definition

CREATE TABLE `DATA_NUMEROS` (
  `id_contacto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `lada` char(2) NOT NULL,
  `numero` char(10) NOT NULL,
  `PLATFORM_ID` int DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS definition

CREATE TABLE `ENVIOS` (
  `id_envio` int NOT NULL AUTO_INCREMENT,
  `id_contacto` int NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `mensaje_enviado` text NOT NULL,
  `fecha_envio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio`),
  KEY `id_contacto` (`id_contacto`),
  CONSTRAINT `ENVIOS_ibfk_1` FOREIGN KEY (`id_contacto`) REFERENCES `DATA_NUMEROS` (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS_STATUS definition

CREATE TABLE `ENVIOS_STATUS` (
  `id_envio_status` int NOT NULL AUTO_INCREMENT,
  `id_envio` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio_status`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `ENVIOS_STATUS_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.LOG_ENVIO definition

CREATE TABLE `LOG_ENVIO` (
  `id_log_local` int NOT NULL AUTO_INCREMENT,
  `id_envio` int DEFAULT NULL,
  `status_id` int NOT NULL,
  `errorApi` varchar(500) NOT NULL DEFAULT 'NA',
  `fecha_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log_local`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `LOG_ENVIO_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.PLATFORMS definition

CREATE TABLE `PLATFORMS` (
  `id_platform` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `activo` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_platform`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.STATUS_ENVIO definition

CREATE TABLE `STATUS_ENVIO` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `message` varchar(30) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.WHATSAPP_WEBHOOK_LOG definition

CREATE TABLE `WHATSAPP_WEBHOOK_LOG` (
  `id_webhook` int NOT NULL AUTO_INCREMENT,
  `event_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `from_number` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `message_text` text,
  `channel` enum('web','whatsapp','voice') NOT NULL DEFAULT 'web',
  `role` enum('user','assistant') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'assistant',
  `conversation_id` varchar(100) DEFAULT NULL,
  `raw_json` json NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_webhook`),
  KEY `idx_from_created` (`from_number`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=923 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.BOT_KNOWLEDGE definition

CREATE TABLE `BOT_KNOWLEDGE` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `title` varchar(150) DEFAULT NULL,
  `content` text NOT NULL,
  `tags` json DEFAULT NULL,
  `priority` int DEFAULT '0',
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_bot_knowledge_bot` (`id_bot`),
  CONSTRAINT `fk_bot_knowledge_bot` FOREIGN KEY (`id_bot`) REFERENCES `BOTS` (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO WHATSAAP_ASSISTANT.BOT_KNOWLEDGE
(id, id_bot, title, content, tags, priority, is_active, created_at, updated_at)
VALUES(4, 2, 'Horario de atención', 'Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00.', '[{"key": "horario", "weight": 3}, {"key": "atención", "weight": 2}, {"key": "abren", "weight": 1}, {"key": "cierran", "weight": 1}]', 10, 1, '2025-12-31 11:48:44', '2025-12-31 11:48:44');


INSERT INTO WHATSAAP_ASSISTANT.BOT_PROMPTS
(id, id_bot, system_prompt, is_active, created_at, updated_at)
VALUES(1, 2, 'Eres un agente virtual de atención al cliente.

REGLAS OBLIGATORIAS:
- SOLO puedes responder usando la información proporcionada en la base de conocimiento.
- NO inventes información.
- NO respondas con conocimiento general que no esté en la base.
- Si la pregunta no está cubierta por la información disponible, responde EXACTAMENTE:
  "No cuento con esa información por el momento. Un asesor humano podrá ayudarte mejor 😊"

TONO:
- Profesional
- Claro
- Amable
- Conciso

IMPORTANTE:
Nunca sugieras abogados, leyes, opiniones personales ni información externa
a menos que esté explícitamente en la base de conocimiento.', 1, '2026-01-05 11:25:00', '2026-01-05 15:53:33');


-- WHATSAAP_ASSISTANT.BOT_PROMPTS definition

CREATE TABLE `BOT_PROMPTS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_bot` int NOT NULL,
  `system_prompt` text NOT NULL,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_bot` (`id_bot`),
  CONSTRAINT `BOT_PROMPTS_ibfk_1` FOREIGN KEY (`id_bot`) REFERENCES `BOTS` (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;