<?php

##### OBTIENE EL NUMERO DE SOLICITUD DE PREDICTIVO

function get_preavail($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.xsp_getPreAvail_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}

##### INICIA EL NUMERO DE SOLICITUD DE PREDICTIVO

function set_preavail($s_usr_id, $customerid, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_setPreAvail(:p_usr_id,:p_customerid); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_usr_id');
    $db->InParameter($stmt, $customerid, 'p_customerid');
    $db->Execute($stmt);
}

##### OBTIENE EL TELEFONO DE SOLICITUD DE PREDICTIVO

function get_PreAvail_Telefono($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.xsp_getPreAvail_Telefono_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}

##### OBTIENE LA GRABACION DE SOLICITUD DE PREDICTIVO

function get_PreAvail_Grabacion($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.xsp_getPreAvail_Grabacion_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs->fields[0];
}

#####  OBTIENE REGISTRO ESPECICFICO PREDICTIVO

function get_registro_especifico_pred($u_registro, $telefono, $usr_id, $tipo_campana, $duracion, $grabacion, $db) {
//$rs = $db->ExecuteCursor("BEGIN HSBC.xsp_getRegistroEsp_Pred_Time(" . $u_registro . ",'" . $telefono . "', " . $usr_id . ",'" . $tipo_campana . "', '" . $duracion . "', :rc); END;", 'rc');
//$db->SetFetchMode(ADODB_FETCH_BOTH);
//return $rs;
    $query = "BEGIN HSBC.xsp_getRegistroEsp_Pred_Time(:u_registro, :telefono, :usr_id, :tipo_campana, :duracion, :grabacion, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'u_registro');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
    $db->InParameter($stmt, $duracion, 'duracion');
    $db->InParameter($stmt, $grabacion, 'grabacion');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    // var_dump($rs); die();
    return $rs;
}

function get_registro_especifico_pred_vicidial($u_persona_vici, $telefono, $usr_id, $tipo_campana, $duracion, $grabacion, $db) {
    //$rs = $db->ExecuteCursor("BEGIN HSBC.xsp_getRegistroEsp_Pred_Time(" . $u_registro . ",'" . $telefono . "', " . $usr_id . ",'" . $tipo_campana . "', '" . $duracion . "', :rc); END;", 'rc');
    //$db->SetFetchMode(ADODB_FETCH_BOTH);
    //return $rs;
        $query = "BEGIN HSBC.XSP_GETREGISTROVICIDIAL(:u_persona, :telefono, :usr_id, :tipo_campana, :duracion, :grabacion, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $u_persona_vici, 'u_persona');
        $db->InParameter($stmt, $telefono, 'telefono');
        $db->InParameter($stmt, $usr_id, 'usr_id');
        $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
        $db->InParameter($stmt, $duracion, 'duracion');
        $db->InParameter($stmt, $grabacion, 'grabacion');
        $rs = $db->ExecuteCursor($stmt, 'rc');
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        // var_dump($rs); die();
        return $rs;
    }


##### OBTIENE LAS NOTAS DEL USUARIO

function get_notas($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETNOTASPERSONALES(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### GUARDA LAS NOTAS PERSONALES DEL USUARIO

function set_notas($s_usr_id, $nota, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SETNOTASPERSONALES(:p_usr_id, :nota); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_usr_id');
    $db->InParameter($stmt, $nota, 'nota');
    $db->Execute($stmt);
}

##### OBTIENE EL POPUP DEL ESTATUS DEL REGISTRO

function get_ER($s_reg, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETESTATUSREGISTRO(" . $s_reg . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### OBTIENE UN NUEVO REGISTRO Y DEVUELVE EL NUMERO DE SOLICITUD

function get_registro_solicitud($s_usr_id, $camp, $prioridad, $estatus, $intentos, $rand_, $reg, $tipoCampana, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_GETNUEVOREGISTRO(:camp ,:prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :rc); END;");
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $prioridad, 'prioridad');
    $db->InParameter($stmt, $estatus, 'estatus');
    $db->InParameter($stmt, $intentos, 'intentos');
    $db->InParameter($stmt, $s_usr_id, 'user_');
    $db->InParameter($stmt, $rand_, 'rand_');
    $db->OutParameter($stmt, $reg, 'reg', 32); # return varchar(32)
    $db->InParameter($stmt, $tipoCampana, 'tipoCampana');
    $rs = $db->ExecuteCursor($stmt, 'rc');

//  echo "<pre>";
//  print_r($rs);
//  echo "</pre>";
//  die();
//  exit();

    return $rs;
}
//DESLOGUEO DE SESSION
function desocupar_usuario($s_usr_id, $db){
    $query = "BEGIN HSBC.XSP_LOGOUT(:v_userid); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $s_usr_id, 'v_userid');
    $db->Execute($stmt);
}

##### OBTIENE LAS CALIFICACIONES DE NO CONTACTO

function get_cal_NC($camp, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
//    $query = "BEGIN HSBC.xsp_getListaEstatusNoContacto(:camp, :rc); END;";
    $query = "BEGIN HSBC.xsp_getStatusNoContacto(:camp, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### OBTIENE LAS CALIFICACIONES DE NO CONTACTO, BASE SIN NOMBRE

function get_cal_NC_SN($camp, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
//    $query = "BEGIN HSBC.xsp_getListaEstatusNoContacto(:camp, :rc); END;";
    $query = "BEGIN HSBC.xsp_getStatusNoContacto_SN(:camp, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### OBTIENE LAS CALIFICACIONES DE SI CONTACTO

function get_cal_SC($camp, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
//    $query = "BEGIN HSBC.xsp_getListaEstatusNoContacto(:camp, :rc); END;";
    $query = "BEGIN HSBC.XSP_GETLISTAESTATUSSICONTACTO(:camp, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $camp, 'camp');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_califica_telefono($telefono, $cal_tel, $num_tel, $db) {
    set_session_varname("caltelefono" . $num_tel, $cal_tel);

    $stmt = $db->PrepareSP("BEGIN HSBC.spU_setRegistroTelefonico(:iRegTelefono, :iStatusLlamada); END;");
    $db->InParameter($stmt, $telefono, 'iRegTelefono');
    $db->InParameter($stmt, $cal_tel, 'iStatusLlamada');
    $db->Execute($stmt);
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_estatus_registro($id_registro, $s_usr_id, $telefono, $cal_tel, $elapsed, $comment, $camp, $segundos, $tipo_campana, $isPredictivo, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_setEstatusRegistro_pnd(:u_registro, :agente, :u_telefono, :cal_telefono, :elapsed, :comment, :campana, :segundos, :tipoCampana, :tipo_marcacion); END;");
    $db->InParameter($stmt, $id_registro, 'u_registro');
    $db->InParameter($stmt, $s_usr_id, 'agente');
    $db->InParameter($stmt, $telefono, 'u_telefono');
    $db->InParameter($stmt, $cal_tel, 'cal_telefono');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $comment, 'comment');
    $db->InParameter($stmt, $camp, 'campana');
    $db->InParameter($stmt, $segundos, 'segundos');
    $db->InParameter($stmt, $tipo_campana, 'tipoCampana');
    $db->InParameter($stmt, $isPredictivo, 'tipo_marcacion');
    $db->Execute($stmt);
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS EN NUXIBA, VICIDIAL

function set_estatus_registro_nux($id_registro, $s_usr_id, $telefono, $cal_tel, $elapsed, $comment, $camp, $segundos, $tipo_campana, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_setEstatusRegistro_pnd_nux(:u_registro, :agente, :u_telefono, :cal_telefono, :elapsed, :comment, :campana, :segundos, :tipoCampana); END;");
    $db->InParameter($stmt, $id_registro, 'u_registro');
    $db->InParameter($stmt, $s_usr_id, 'agente');
    $db->InParameter($stmt, $telefono, 'u_telefono');
    $db->InParameter($stmt, $cal_tel, 'cal_telefono');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $comment, 'comment');
    $db->InParameter($stmt, $camp, 'campana');
    $db->InParameter($stmt, $segundos, 'segundos');
    $db->InParameter($stmt, $tipo_campana, 'tipoCampana');
    $db->Execute($stmt);
}

##### GUARDA LA SUBCALIFICACIÓN

function set_subcalificacion_registro($id_registro, $id_subcalificacion, $telefono, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SETSUBCALIFICACIONREGISTRO(:u_registro, :u_subcalificacion, :telefono); END;");
    $db->InParameter($stmt, $id_registro, 'u_registro');
    $db->InParameter($stmt, $id_subcalificacion, 'u_subcalificacion');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->Execute($stmt);
}

##### GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_estatus_registro_normal($id_registro, $estatusllamada, $estatusregistro, $prioridad, $s_usr_id, $elapsed, $comment, $camp, $segundos, $tipo_campana, $tipo_marcacion, $db) {



    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_setEstatusRegistro(:reg, :stat, :llam, :pri, :user_, :elapsed, :comm, :camp, :segundosEnllamda, :tipoCampana, :tipo_marcacion); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $estatusllamada, 'stat');
    $db->InParameter($stmt, $estatusregistro, 'llam');
    $db->InParameter($stmt, $prioridad, 'pri');
    $db->InParameter($stmt, $s_usr_id, 'user_');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $comment, 'comm');
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $segundos, 'segundosEnllamda');
    $db->InParameter($stmt, $tipo_campana, 'tipoCampana');
    $db->InParameter($stmt, $tipo_marcacion, 'tipo_marcacion');
    $db->Execute($stmt);
}

##### OBTIENE LAS CALIFICACIONES DE SI CONTACTO

function get_valida_acceso($usr_id, $function, $languaje, $db) {
    $rs = $db->ExecuteCursor("BEGIN xsp_verifyAccess(" . $usr_id . ", " . $function . ", " . $languaje . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS CLIENTES EN LA BASE DE DATOS

function set_busca_cliente($solicitud, $nombre, $paterno, $materno, $agente, $telefono, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_BUSCAREGISTRO_WEB(" . $solicitud . ",'" . strtoupper($nombre) . "','" . strtoupper($paterno) . "','" . strtoupper($materno) . "', " . $agente . "," . $telefono . " ,:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE CLIENTES EN LA BASE DE DATOS

function set_busca_datos($solicitud = null, $nombre = null, $paterno = null, $materno = null, $clave = null, $rfc = null, $telefono = null, $tipo = null, $agente = null, $db) {
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
//    $query = "BEGIN HSBC.CSP_GETLISTACLIENTES(:nombre, :paterno, :materno, :rfc, :telefono, :clave, :solicitud, :rc); END;";
//    $stmt = $db->PrepareSP($query);
//    $db->InParameter($stmt, $nombre, 'nombre');
//    $db->InParameter($stmt, $paterno, 'paterno');
//    $db->InParameter($stmt, $materno, 'materno');
//    $db->InParameter($stmt, $rfc, 'rfc');
//    $db->InParameter($stmt, $telefono, 'telefono');
//    $db->InParameter($stmt, $clave, 'clave');
//    $db->InParameter($stmt, $solicitud, 'solicitud');
    try {
        $query = "BEGIN HSBC.SPS_BUSQUEDACLIENTE(:tipo, :nombre, :paterno, :materno, :solicitud, :clave, :telefono, :rfc, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $tipo, 'tipo');
        $db->InParameter($stmt, $nombre, 'nombre');
        $db->InParameter($stmt, $paterno, 'paterno');
        $db->InParameter($stmt, $materno, 'materno');
        $db->InParameter($stmt, $rfc, 'rfc');
        $db->InParameter($stmt, $telefono, 'telefono');
        $db->InParameter($stmt, $clave, 'clave');
        $db->InParameter($stmt, $solicitud, 'solicitud');
        $rs = $db->ExecuteCursor($stmt, 'rc');
    } catch (exception $e) {
        pa($e->getTrace());
        die();
        exit();
    }

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE CLIENTES EN LA BASE DE DATOS

function set_busca_datos2($solicitud = null, $nombre = null, $paterno = null, $materno = null, $clave = null, $rfc = null, $telefono = null, $tipo = null, $agente = null, $busqueda = null, $db) {
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
//    $query = "BEGIN HSBC.CSP_GETLISTACLIENTES(:nombre, :paterno, :materno, :rfc, :telefono, :clave, :solicitud, :rc); END;";
//    $stmt = $db->PrepareSP($query);
//    $db->InParameter($stmt, $nombre, 'nombre');
//    $db->InParameter($stmt, $paterno, 'paterno');
//    $db->InParameter($stmt, $materno, 'materno');
//    $db->InParameter($stmt, $rfc, 'rfc');
//    $db->InParameter($stmt, $telefono, 'telefono');
//    $db->InParameter($stmt, $clave, 'clave');
//    $db->InParameter($stmt, $solicitud, 'solicitud');
    try {
        $query = "BEGIN HSBC.SPS_BUSQUEDACLIENTE2(:tipo, :nombre, :paterno, :materno, :solicitud, :clave, :telefono, :rfc, :busqueda, :rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $tipo, 'tipo');
        $db->InParameter($stmt, $nombre, 'nombre');
        $db->InParameter($stmt, $paterno, 'paterno');
        $db->InParameter($stmt, $materno, 'materno');
        $db->InParameter($stmt, $rfc, 'rfc');
        $db->InParameter($stmt, $telefono, 'telefono');
        $db->InParameter($stmt, $clave, 'clave');
        $db->InParameter($stmt, $solicitud, 'solicitud');
        $db->InParameter($stmt, $busqueda, 'busqueda');
        $rs = $db->ExecuteCursor($stmt, 'rc');
    } catch (exception $e) {
        pa($e->getTrace());
        die();
        exit();
    }

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE SOLICITUD EN LA BASE DE DATOS (Mantenimiento)

function set_datos_solicitud($customerid, $surveyid, $user, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN HSBC.sps_DatosSolicitud_SJR(:customerid, :surveyid, :user, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $customerid, 'customerid');
    $db->InParameter($stmt, $surveyid, 'surveyid');
    $db->InParameter($stmt, $user, 'user');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS DATOS DE SOLICITUD EN LA BASE DE DATOS (Mantenimiento)

function set_datos_empresas($estado, $municipio, $empresa, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $query = "BEGIN HSBC.SPS_EMPRESAS(:estado, :municipio, :empresa, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $estado, 'estado');
    $db->InParameter($stmt, $municipio, 'municipio');
    $db->InParameter($stmt, $empresa, 'empresa');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

#####  REALIZA LA BUSQUEDA DE LOS CLIENTES EN LA BASE DE DATOS

function get_registro_especifico($u_registro, $usr_id, $tipo_campana, $db) {
//    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETREGISTROESPECIFICO(" . $u_registro . ", " . $usr_id . ",'" . $tipo_campana . "', :rc); END;", 'rc');
    $query = "BEGIN HSBC.XSP_GETREGISTROESPECIFICO(:registro,:u_user,:tipo_campana,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'registro');
    $db->InParameter($stmt, $usr_id, 'u_user');
    $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
    $rs = $db->ExecuteCursor($stmt, 'rc');
//$db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

#####  INSERT UN NUEVO REGISTRO EN BASE

function set_registro_especifico($campana, $usr_id, $nombre, $paterno, $materno, $rfc, $fec_nacimiento, $pais, $lada, $telefono, $localizacion, $tipobase, $db) {
//    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_insertaRegistroTelefonico(:campana, :usr_id, :nombre, :paterno, :materno, :rfc, :fec_nacimiento, :pais, :lada, :telefono, :localizacion, :u_persona, :u_telefono, :u_registro); END;");
    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_insertaRegistroTelefonico3(:campana, :usr_id, :nombre, :paterno, :materno, :rfc, :fec_nacimiento, :pais, :lada, :telefono, :localizacion, :u_persona, :u_telefono, :u_registro, :tipobase,:mensaje_error); END;");
    $db->InParameter($stmt, $campana, 'campana');
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $paterno, 'paterno');
    $db->InParameter($stmt, $materno, 'materno');
    $db->InParameter($stmt, $rfc, 'rfc');
    $db->InParameter($stmt, $fec_nacimiento, 'fec_nacimiento');
    $db->InParameter($stmt, $pais, 'pais');
    $db->InParameter($stmt, $lada, 'lada');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $localizacion, 'localizacion');
    $db->OutParameter($stmt, $u_persona, 'u_persona');
    $db->OutParameter($stmt, $u_telefono, 'u_telefono');
    $db->OutParameter($stmt, $u_registro, 'u_registro');
    $db->InParameter($stmt, $tipobase, 'tipobase');
    $db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $u_persona . '-' . $u_telefono . '-' . $u_registro . '-' . $mensaje_error;
}

#####  INSERT UN NUEVO REGISTRO EN BASE

function set_relacion_registro($referente, $referido, $tipobase, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_INSERTARELACIONREGISTRO_WS(:referente, :referido, :tipobase); END;");
    $db->InParameter($stmt, $referente, 'referente');
    $db->InParameter($stmt, $referido, 'referido');
    $db->InParameter($stmt, $tipobase, 'tipobase');
    $db->Execute($stmt);
}

#####  VERIFICA QUE LA SOLICITUD SE ENCUENTRE EN SURVEYPERSONAS

function set_valida_solicitud_capturada($id_registro, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_isSolicitudOK(:id_solicitud, :res); END;");
    $db->InParameter($stmt, $id_registro, 'id_solicitud');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}

#####  ACTUALIZA VALIDANDO A 2 PARA VER LA SOLICITU EN VALIDACION

function set_valida_solicitud($id_solicitud, $id_producto, $bandera, $segundosllamda, $origen, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_BLOQUEOBYVALIDACION(:id_solicitud, :id_producto, :bandera, :segundosllamda, :origen); END;");
    $db->InParameter($stmt, $id_solicitud, 'id_solicitud');
    $db->InParameter($stmt, $id_producto, 'id_producto');
    $db->InParameter($stmt, $bandera, 'bandera');
    $db->InParameter($stmt, $segundosllamda, 'segundosllamda');
    $db->InParameter($stmt, $origen, 'origen');

    $db->Execute($stmt);
}

##### DEVUELVE INFORMACION DE LOS REGISTROS AGENDADOS POR AGENTE

function get_detalle_agendados_usuario($id_usr, $anio, $mes, $dia, $campana, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETAGENDAXFECHA(" . $id_usr . ", " . $anio . ", " . $mes . ", " . $dia . ", " . $campana . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DEL 01800

function get_detalle_01800_usuario($s_usr_id, $anio, $mes, $dia, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SOL_REPORTE01800_WS(" . $s_usr_id . ", " . $anio . ", " . $mes . ", " . $dia . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DE LAS MEDIAS HORAS

function get_medias_horas($u_media_hora, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.CSP_GETMEDIASHORAS(" . $u_media_hora . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE INFORMACION DE LAS MEDIAS HORAS

function get_lista_medias_horas($number, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.CSP_GETLISTAMEDIASHORAS(:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### INSERTA UN NUEVO REGISTRO TELFONICO

function set_nuevo_telefono($id_solicitud, $lada, $telefono, $tipo, $s_usr_id, $db) {
    //$stmt = $db->PrepareSP("BEGIN HSBC.xsp_setNuevoTelefono3(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :mensaje_error); END;"); //, :mensaje_error
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SETNUEVOTELEFONO2(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :v_u_user,:v_bl_reus); END;"); //, :mensaje_error
    $db->InParameter($stmt, $id_solicitud, 'v_u_persona');
    $db->InParameter($stmt, $lada, 'v_lada');
    $db->InParameter($stmt, $telefono, 'v_telefono');
    $db->InParameter($stmt, $tipo, 'v_tipo');
    $db->InParameter($stmt, $s_usr_id, 'v_u_user');
    $db->OutParameter($stmt, $bl_reus, 'v_bl_reus');
    //$db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $bl_reus;
}

##### DEVUELVE EL CUESTIONARIO

function get_cuestionario($producto, $lang, $exist, $name, $desc, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.proc_Survey_GetSurvey(:SurveyId_, :Lang, :Exist, :Name_, :Desc_); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->OutParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $name, 'Name_');
    $db->OutParameter($stmt, $desc, 'Desc_');
    $db->Execute($stmt);

    return $name . '-' . $desc;
}

##### DEVUELVE LAS PREGUNTAS DE LA SOLICITUD

function get_preguntas($producto, $solicitud, $lang, $exist, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_SURVEY_GETQUESTIONS(:SurveyId_ ,:Lang, :Exist, :rc); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LAS REPUESTAS DE LAS PREGUNTAS

function get_respuestas($producto, $question, $lang, $solicitud, $mostrar, $exist, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_SURVEY_GETQUESTCHOICESCU2(:SurveyId_, :QuestionId_, :Lang, :persona, :mostrar, :Exist, :rc); END;");
    $db->InParameter($stmt, $producto, 'SurveyId_');
    $db->InParameter($stmt, $question, 'QuestionId_');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $solicitud, 'persona');
    $db->InParameter($stmt, $mostrar, 'mostrar');
    $db->InParameter($stmt, $exist, 'Exist');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LAS REPUESTAS POR DEFAUL

function get_respuestas_default($solicitud, $field, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_SURVEY_GETQUESTIONDEFAULT(:user_, :field, :rc); END;");
    $db->InParameter($stmt, $solicitud, 'user_');
    $db->InParameter($stmt, $field, 'field');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LOS VALORES DE UN QUERY DE LA SOLICITUD

function get_datos_query($query, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC." . $query . "(:rc); END;");
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

function get_datos_query2($query, $db) {

    $stmt = $db->PrepareSP("BEGIN HSBC." . $query . "; END;");
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### DEVUELVE LOS VALORES DE UN QUERY DE LA SOLICITUD PARA LOS CAMPOS CODIGO POSTAL

function get_datos_query_CP($query, $cp, $id, $db) {
//    $stmt = $db->PrepareSP("BEGIN HSBC." . $query . "(" . $cp . ", :rc); END;");
//    $stmt = $db->PrepareSP("BEGIN HSBC." . $query . "(:cp, :rc); END;");
    $stmt = $db->PrepareSP("BEGIN " . $query . "(:cp, :id, :rc); END;");
    $db->InParameter($stmt, $cp, 'cp');
    $db->InParameter($stmt, $id, 'id');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### ELIMINA LA SOLICITUD DEL PRODUCTO Y SOLICITUD

function set_delete_survey($id_solicitud, $id_producto, $lang, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_DELETESURVEY(:varUserID, :varSurveyID, :Lang); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->Execute($stmt);
}

//LIMPIAR DATOS DE CARACTERES ESPECIALES
function cleanData($texto){
    $data_error = array("á", "é", "í", "ó", "ú", "Á", "É", "Í", "Ó", "Ú", "ñ","Ñ");
    $data_fix   = array("a", "e", "i", "o", "u", "A", "E", "I", "O", "U", "n","N");
    $newRspta = str_replace($data_error, $data_fix, $texto);
    return $newRspta;
}
##### GUARDA LOS QUESTIONDS LA SOLICITUD EN SURVEYRESPONSE

function set_insert_survey($id_solicitud, $id_producto, $questionid, $choiceid, $date, $response, $lang, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_INSERTSURVEYINT(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :responseDate, :responseNo, :Lang); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $questionid, 'varQuestionNo');
    $db->InParameter($stmt, $choiceid, 'varChoiceNo');
    $db->InParameter($stmt, $date, 'responseDate');
    $db->InParameter($stmt, $response, 'responseNo');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYRESPONSE

function set_update_results($id_solicitud, $id_producto, $questionid, $choiceid, $lang, $respuesta, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.PROC_UPDATESURVEYRESULTS(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :Lang, :responseText); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $questionid, 'varQuestionNo');
    $db->InParameter($stmt, $choiceid, 'varChoiceNo');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $respuesta, 'responseText');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYPERSONAS MODO PROCESAR
//function set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud, $s_usr_id, $db) {
//function set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud, $db) {
function set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud, $u_telefono, $grabacion, $s_usr_id, $db) {
    //$stmt = $db->PrepareSP("BEGIN HSBC.XSP_SOLICITUDEXITOSA(:p_registro, :p_solicitud, :p_u_persona, :p_u_user); END;");
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SOLICITUDEXITOSA(:p_registro, :p_solicitud, :p_u_persona, :p_u_telefono, :p_grabacion, :p_u_user); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_producto, 'p_solicitud');
    $db->InParameter($stmt, $id_solicitud, 'p_u_persona');
    $db->InParameter($stmt, $u_telefono, 'p_u_telefono');
    $db->InParameter($stmt, $grabacion, 'p_grabacion');
    $db->InParameter($stmt, $s_usr_id, 'p_u_user');
    $db->Execute($stmt);
}

##### GUARDA LOS DATOS DE LA SOLICITUD EN SURVEYPERSONAS MODO GUARDAR

function set_datos_solicitud_exitosa_s($id_registro, $id_producto, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SOLICITUDEXITOSA_SAVE(:p_registro, :p_solicitud, :p_u_persona); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_producto, 'p_solicitud');
    $db->InParameter($stmt, $id_solicitud, 'p_u_persona');
    $db->Execute($stmt);
}

##### MUESTRA LA LISTA DE LOS PRODUTOS POR CAMPANA

function get_productos_campana($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.CSP_GETPRODUCTOS_WS(:u_persona, :rc); END;"); //-- Solo se ocupa si se vende por base o producto
    $db->InParameter($stmt, $id_solicitud, 'u_persona');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    //$rs = $db->ExecuteCursor("BEGIN HSBC.CSP_GETPRODUCTOS(1,:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}
##### MUESTRA LA LISTA DE LOS PRODUTOS POR AGENTES ESPECIFICOS

function get_productos_campana_agentes($id_solicitud,$nomina, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_GETPRODUCTOS_AGENTE(:v_nomina,:u_persona, :rc); END;"); //-- Solo se ocupa si se vende por base o producto
    $db->InParameter($stmt, $nomina, 'v_nomina');
    $db->InParameter($stmt, $id_solicitud, 'u_persona');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    //$rs = $db->ExecuteCursor("BEGIN HSBC.CSP_GETPRODUCTOS(1,:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

##### INSERTA UN NUEVO REGISTRO REFERIDO

function set_guarda_referdido($s_usr_id, $id_solicitud, $id_producto, $tipo_registro1, $nombre1, $nombre1_2, $paterno1, $materno1, $lada1_1, $telefono1_1/* , $lada1_2, $telefono1_2 */, $tipo_registro2, $nombre2, $nombre2_2, $paterno2, $materno2, $lada2_1, $telefono2_1/* , $lada2_2, $telefono2_2 */, $tipo_registro3, $nombre3, $nombre3_2, $paterno3, $materno3, $lada3_1, $telefono3_1/* , $lada3_2, $telefono3_2 */, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_INSERTAREGISTROREFERIDO_JL(:P_User, :P_Customerid, :P_surveyid, :P_Nombre1_1, :P_Nombre1_2 , :P_Paterno1, :P_Materno1, :P_Lada1_1, :P_Telefono1_1, :P_Nombre2, :P_Nombre2_2, :P_Paterno2, :P_Materno2, :P_Lada2_1, :P_Telefono2_1, :P_Nombre3, :P_Nombre3_2, :P_Paterno3, :P_Materno3, :P_Lada3_1, :P_Telefono3_1, :mensaje_error); END;");
    $db->InParameter($stmt, $s_usr_id, 'P_User');
    $db->InParameter($stmt, $id_solicitud, 'P_Customerid');
    $db->InParameter($stmt, $id_producto, 'P_surveyid');

    $db->InParameter($stmt, $nombre1, 'P_Nombre1_1');
    $db->InParameter($stmt, $nombre1_2, 'P_Nombre1_2');
    $db->InParameter($stmt, $paterno1, 'P_Paterno1');
    $db->InParameter($stmt, $materno1, 'P_Materno1');
    $db->InParameter($stmt, $lada1_1, 'P_Lada1_1');
    $db->InParameter($stmt, $telefono1_1, 'P_Telefono1_1');

    $db->InParameter($stmt, $nombre2, 'P_Nombre2');
    $db->InParameter($stmt, $nombre2_2, 'P_Nombre2_2');
    $db->InParameter($stmt, $paterno2, 'P_Paterno2');
    $db->InParameter($stmt, $materno2, 'P_Materno2');
    $db->InParameter($stmt, $lada2_1, 'P_Lada2_1');
    $db->InParameter($stmt, $telefono2_1, 'P_Telefono2_1');

    $db->InParameter($stmt, $nombre3, 'P_Nombre3');
    $db->InParameter($stmt, $nombre3_2, 'P_Nombre3_2');
    $db->InParameter($stmt, $paterno3, 'P_Paterno3');
    $db->InParameter($stmt, $materno3, 'P_Materno3');
    $db->InParameter($stmt, $lada3_1, 'P_Lada3_1');
    $db->InParameter($stmt, $telefono3_1, 'P_Telefono3_1');

    $db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $mensaje_error;
}

/* function get_registro_especifico($u_registro, $usr_id, $tipo_campana, $db) {
  //    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETREGISTROESPECIFICO(" . $u_registro . ", " . $usr_id . ",'" . $tipo_campana . "', :rc); END;", 'rc');
  $query = "BEGIN HSBC.XSP_GETREGISTROESPECIFICO(:registro,:u_user,:tipo_campana,:rc); END;";
  $stmt = $db->PrepareSP($query);
  $db->InParameter($stmt, $u_registro, 'registro');
  $db->InParameter($stmt, $usr_id, 'u_user');
  $db->InParameter($stmt, $tipo_campana, 'tipo_campana');
  $rs = $db->ExecuteCursor($stmt, 'rc');
  //$db->SetFetchMode(ADODB_FETCH_BOTH);
  return $rs;
  } */

##### VALIDA QUE EL RFC NO EXISTA EN LA APLICACION

function get_valida_rfc($id_solicitud, $id_producto, $num_reconocedor, $lang, $rfc, $existe, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.proc_CompareSurveyResults_WS1(:varUserID, :varSurveyID, :Varrecnocedor, :Lang, :responseText, :YaExiste); END;");
    $db->InParameter($stmt, $id_solicitud, 'varUserID');
    $db->InParameter($stmt, $id_producto, 'varSurveyID');
    $db->InParameter($stmt, $num_reconocedor, 'Varrecnocedor');
    $db->InParameter($stmt, $lang, 'Lang');
    $db->InParameter($stmt, $rfc, 'responseText');
    $db->OutParameter($stmt, $existe, 'YaExiste');
    $db->Execute($stmt);

    return $existe;
}

function get_datos_valida_rfc($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_RESULTRFC_WS_P(:customerid,:rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

##### MUESTRA LA LISTA DE LOS PRODUTOS POR CAMPANA

function get_datos_complementarios($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.CSP_GETDATOSSOLICITUD_WS(" . $id_solicitud . ", :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

##### OBTIENE LOS DATOS PREVIAMENTE GUARDADOS DE LA SOLICITUD

function get_datos_grabados($id_solicitud, $id_producto, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.PROC_SURVEY_GETQUESTCHOICESCU3(" . $id_solicitud . ",". $id_producto . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}

##### OBTIENE LOS DATOS PREVIAMENTE GUARDADOS DE LA SOLICITUD pero del otro producto

function get_datos_venta_previa($id_solicitud, $id_producto, $db) {
    $rs = $db->ExecuteCursor("BEGIN hsbc.SPS_OBTIENE_DATOS(" . $id_solicitud . ",". $id_producto . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    
    return $rs;
}

# OBTIENE UN NUEVO REGISTRO

function get_detalle_solicitud($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLESSOLICITUD(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

function get_detalle_telefono($s_usr_id, $action, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLESTELEFONO(" . $s_usr_id . "," . $action . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo($v_id_campo, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.spS_Catalogo('" . $v_id_campo . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo_prod($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CATALOGO_PROD('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_catalogo_prod_in($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CATALOGO_PROD_IN('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA PARA LA ZONA 998 (VISITAS DOMICILIARIAS)

function get_catalogo_prod_in_vd($v_id_campo, $p_id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CATALOGO_PROD_IN_VD('" . $v_id_campo . "'," . $p_id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA PARA IN

function get_catalogoin($v_id_campo, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.spS_CatalogoIn('" . $v_id_campo . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA EL NUMERO DE TELEFONO DE UN REGISTRO

function set_calificacion_telefono($p_solicitud, $p_telefono, $p_calificacion, $etapa, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPX_CALIFICA_TELEFONO(:p_solicitud, :p_telefono, :p_calificacion, :p_etapa, :p_actualiza); END;");
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $p_telefono, 'p_telefono');
    $db->InParameter($stmt, $p_calificacion, 'p_calificacion');
    $db->InParameter($stmt, $etapa, 'p_etapa');
    $db->OutParameter($stmt, $p_actualiza, 'p_actualiza');
    $db->Execute($stmt);
    return $p_actualiza;
}

# CALIFICA LOS NUMEROS DE TELEFONO DE UN REGISTRO

function set_calificacion_telefono_in($p_user, $p_solicitud, $p_calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPX_CALIFICA_TELEFONO_IN(:p_user, :p_solicitud, :p_calificacion, :p_actualiza); END;");
    $db->InParameter($stmt, $p_user, 'p_user');
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $p_calificacion, 'p_calificacion');
    $db->OutParameter($stmt, $p_actualiza, 'p_actualiza');
    $db->Execute($stmt);
    return $p_actualiza;
}

# BUSCA LA CALIFICACION PARA VERIFICAR SI EL REGISTRO FUE ABANDONADO

function set_busca_calif_reg_in($p_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_BUSCA_CAL_REG_IN(:p_solicitud, :p_calif); END;");
    $db->InParameter($stmt, $p_solicitud, 'p_solicitud');
    $db->OutParameter($stmt, $p_calif, 'p_calif');
    $db->Execute($stmt);
    return $p_calif;
}

#MUESTRA SCRIPT A MOSTRAR

function set_muestra_script($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_MUESTRA_SCRIPT(:p_solicitud, :p_script); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->OutParameter($stmt, $p_script, 'p_script');
    $db->Execute($stmt);

    return $p_script;
}

#TRAE LOS BINES  DE LAS TDC

function get_bines($db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_BINES(:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    $cont = 0;
    while (!$rs->EOF) {
        $bines .= $rs->fields["CPREFIJO"] . ',';
        $cont = $cont + 1;
        $rs->MoveNext();
    }

    return substr($bines . '0', 0, strlen($bines . '0') - 2);
}

##### ABANDONA EL REGISTRO PARA SALIR DE LA APLICACION

function set_libera_solicitud($id_registro, $elapsed, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_LIBERAREGISTRO(:reg, :elapsed, :tipoCampana); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $elapsed, 'elapsed');
    $db->InParameter($stmt, $camp, 'tipoCampana');
    $db->Execute($stmt);
}

##### BLOQUEA EL REGISTRO CLIENTE MUY MOLESTO

function set_bloquea_cliente_molesto($id_registro, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_BLOQUEAREGISTRO_CM(:reg); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->Execute($stmt);
}

##### ELIMINA EL REGISTRO DE LLAMADAS AGENDADAS PARA NO VOLVERLO A TOMAR

function set_libera_agendado($id_registro, $s_usr_id, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_LIBERAAGENDA(:id_registro, :s_usr_id); END;");
    $db->InParameter($stmt, $id_registro, 'id_registro');
    $db->InParameter($stmt, $s_usr_id, 's_usr_id');
    $db->Execute($stmt);
}

##### AGENDA EL REGISTRO CON SUS RESPECTIVOS COMENTARIOS

function set_agenda_registro($s_usr_id, $id_registro, $anio, $mes, $day, $hora, $nombre, $comentarios, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_SETAGENDAXFECHA(:agente, :reg, :ano, :mes, :dia, :media, :nombre_, :comment_, :camp); END;");
    $db->InParameter($stmt, $s_usr_id, 'agente');
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->InParameter($stmt, $anio, 'ano');
    $db->InParameter($stmt, $mes, 'mes');
    $db->InParameter($stmt, $day, 'dia');
    $db->InParameter($stmt, $hora, 'media');
    $db->InParameter($stmt, $nombre, 'nombre_');
    $db->InParameter($stmt, $comentarios, 'comment_');
    $db->InParameter($stmt, $camp, 'camp');
    $db->Execute($stmt);
//return $v_actualizado;
}

# DEVUELVE EL DETALLE DEL REGISTRO AGENDADO

function get_detalle_agendado($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLESAGENDADO(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS REGISTROS AGENDADOS POR EL AGENTE

function get_registros_agendado($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETLLAMADASAGENDADAS(" . $s_usr_id . ", 1, :rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS COMENTARIOS DE LAS DISTINTAS AGENDAS

function get_comentarios_agenda($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_COMENTARIOASAGENDA(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DATOS DEL CLIENTE

function get_detalle_cliente($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLE_CLIENTE(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA LOS REGISTROS PARA LOS CASOS DE FINADO Y NO QUIERE QUE LO MOLESTEN

function set_califica_registros($id_solicitud, $cal_reg, $producto, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPU_CALIFICAREGISTRO(" . $id_solicitud . "," . $cal_reg . "," . $producto . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# CALIFICA LOS REGISTROS PARA LA BUSQUEDA DE CLIENTES IN

function set_califica_registros_in($id_solicitud, $calificacion, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPU_CALIFICAREGISTRO_IN(" . $id_solicitud . "," . $calificacion . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# GUARDA EL HISTORICO DE LA CALIFICACION DE LOS TELEFONOS

function set_telefono_historico($s_usr_id, $id_solicitud, $telefono, $calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPI_TEL_CAL_HISTO(:p_id_user, :p_id_solicitud, :p_telefono, :p_calificacion); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_id_user');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $calificacion, 'p_calificacion');
    $db->Execute($stmt);
}

# ACTUALIZA A 0 LA CALIFICACION DE LOS TELEFONOS CUANDO EL REGISTRO ES ABANDONADO

function set_libera_telefonos_abandonado($id_solicitud, $s_usr_id, $producto, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_LIBERATELEFONOS(:p_id_solicitud, :s_usr_id, :p_producto); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $s_usr_id, 's_usr_id');
    $db->InParameter($stmt, $producto, 'p_producto');
    $db->Execute($stmt);
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_subcatalogo($v_id_campo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.spS_Sub_Catalogo('" . $v_id_campo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS CALIFICACIONES Contacto No Efectivo

function get_calcne($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CALCNE(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS CALIFICACIONES CONSUMIBLES

function get_calconsumibles($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CALCONSUMIBLES(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LA CALIFICACION DE CONTACTO EFECTIVO PARA ENV�AR A LA SOLICITUD // nO SE ESTA UTILIZANDO EN ESTE MOMENTO 22052009

function get_cal_ce_solicitud($id_etapa, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_CALCESOLICITUD(:p_id_etapa, :p_cal_ce); END;");
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->OutParameter($stmt, $p_cal_ce, 'p_cal_ce');
    $db->Execute($stmt);
    return $p_cal_ce;
}

# REGRESA LAS CALIFICACIONES  CE Y QUE ENV�A A SOLICITUD

function get_cal_ce($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CALCONTACTOEFECTIVO(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# REGRESA LAS DESCRIPCION DE LAS CALIFICACIONES

function get_desc_calif($id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DESC_CALIF(" . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# VERIFICA SI LA CALIFICACION DE CE TIENE O NO UNA SUBCALIF, PARA MOSTRAR LA PREGUNTA EN LA SOLICITUD.

function get_sub_calif($cal_telefono, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_CAL_SUBCALIF(:p_cal_telefono, :p_ban_subcalif); END;");
    $db->InParameter($stmt, $cal_telefono, 'p_cal_telefono');
    $db->OutParameter($stmt, $p_ban_subcalif, 'p_ban_subcalif');
    $db->Execute($stmt);

    return $p_ban_subcalif;
}

#GUARDA EL SEGUIMEINTO DE UNA SOLICITUD

function set_guardaseguimiento($id_solicitud, $etapa, $calificacion, $statuscalif, $telefono, $maquina, $id_usr, $usr_super, $activo, $id_zona, $sub_calregistro, $id_tipo_evento, $num_intentos, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPI_SEGUIMIENTO(:p_solicitud, :p_etapa, :p_calificacion, :p_statuscalif, :p_telefono, :p_id_user, :p_maquina, :p_usr_super, :p_activo, :p_id_zona, :p_sub_calregistro, :p_id_tipo_evento, :p_num_intentos ); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $etapa, 'p_etapa');
    $db->InParameter($stmt, $calificacion, 'p_calificacion');
    $db->InParameter($stmt, $statuscalif, 'p_statuscalif');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $maquina, 'p_maquina');
    $db->InParameter($stmt, $id_usr, 'p_id_user');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->InParameter($stmt, $activo, 'p_activo');
    $db->InParameter($stmt, $id_zona, 'p_id_zona');
    $db->InParameter($stmt, $sub_calregistro, 'p_sub_calregistro');
    $db->InParameter($stmt, $id_tipo_evento, 'p_id_tipo_evento');
    $db->InParameter($stmt, $num_intentos, 'p_num_intentos');
    $db->Execute($stmt);
}

# OBTIENE LA INFORMACI�N PARA LA SOLICITUD DE RP1 , RP2 Y PP, SI EXISTE TRAE LA INFORMACION SI NO  EXISTE TRAE LO VACIO.

function get_detalle_solicitud_pp($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLESSOLICITUD_PP(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# GUARDA EL ALTA DE UN NUEVO CLIENTE

function set_nuevo_registro($s_usr_id, $nombre, $paterno, $materno, $nombre_completo, $telefono, $tdc, $tipo_tdc, $celular, $email, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPI_GUARDAREGISTROLLAMADA(:p_user,:p_nombre,:p_paterno,:p_materno,:p_nombre_completo, :p_telefono , :p_tdc ,:p_tipo_tdc, :p_celular, :p_email, :v_reg_nuevo); END;");
    $db->InParameter($stmt, $s_usr_id, 'p_user');
    $db->InParameter($stmt, $nombre, 'p_nombre');
    $db->InParameter($stmt, $paterno, 'p_paterno');
    $db->InParameter($stmt, $materno, 'p_materno');
    $db->InParameter($stmt, $nombre_completo, 'p_nombre_completo');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $tdc, 'p_tdc');
    $db->InParameter($stmt, $tipo_tdc, 'p_tipo_tdc');
    $db->InParameter($stmt, $celular, 'p_celular');
    $db->InParameter($stmt, $email, 'p_email');
    $db->OutParameter($stmt, $v_reg_nuevo, 'v_reg_nuevo');
    $db->Execute($stmt);

    return $v_reg_nuevo;
}

# CALIFICA EL NUMERO DE REGISTRO QUE SE INGRESO A LA TABLA AUXILIAR DE TD_REGISTROS DE UNA NUEVA LLAMADA

function set_califica_llamada($user, $id_registro, $calificacion, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_CALIFICALLAMADA(:p_user, :p_id_registro, :p_calificacion, :p_cal_llamada); END;");
    $db->InParameter($stmt, $user, 'p_user');
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $calificacion, 'p_calificacion');
    $db->OutParameter($stmt, $p_cal_llamada, 'p_cal_llamada');
    $db->Execute($stmt);
    return $p_cal_llamada;
}

# OBTIENE LA INFORMACI�N DEL NUEVO REGISTRO DADO DE ALTA EN TD_REGISTROS

function get_detalle_calif($id_registro, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLESCALIF_NR(" . $id_registro . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# INFORMACION DEL CLIENTE DE UNA NUEVA LLAMADA

function get_seguimiento_registro($id_registro, $s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPX_SEGUIMIENTO(" . $id_registro . "," . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Devuelve los ultimos valores con los cuales esta guardado el registro en TBL_DATOS.

function set_status_registro($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_STATUS_REGISTRO(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DEVUELVE LOS REGISTROS AGENDADOS POR HORA

function get_agendados_dia($p_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_AGENDADOSDIA(" . $p_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DETALLE DE SOLICITUD INBOUND PARA INSCRIPCION

function get_detalle_solicitud_IN($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_SOLICITUDIN(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA

function get_subcatalogo_in($v_id_campo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_SUB_CATALOGO_IN('" . $v_id_campo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Verifica si la Calificacion arroja una Subcalificacion o no en las solicitudes inbound

function get_subcalifiacion($calif_, $id_etapa, $id_solicitud, $id_campo, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_ENVIASUBCALIFICACION (:p_calif, :p_id_etapa, :p_id_solicitud, :p_id_campo, :p_sub_calif); END;");
    $db->InParameter($stmt, $calif_, 'p_calif');
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->InParameter($stmt, $id_campo, 'p_id_campo');
    $db->OutParameter($stmt, $p_sub_calif, 'p_sub_calif');
    $db->Execute($stmt);
    return $p_sub_calif;
}

# Trae informaci�n para poner una nueva pregunta que es la de Cuanto va a Pagar o Cuanto Pago.

function get_promesadepago($calif_, $id_etapa, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_PROMESAPAGO (:p_calif, :p_id_etapa, :p_id_solicitud, :p_promesa); END;");
    $db->InParameter($stmt, $calif_, 'p_calif');
    $db->InParameter($stmt, $id_etapa, 'p_id_etapa');
    $db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
    $db->OutParameter($stmt, $p_promesa, 'p_promesa');
    $db->Execute($stmt);
    return $p_promesa;
}

#AGREGA AL REGISTRO ENCONTRADO EN TD_REGISTROS LA SOLICITUD QUE SE ENCONTRO DEL CLIENTE.

function set_guardasolicitud_registros($id_registro, $id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_GUARDASOL_REGISTROS(:p_registro,:p_solicitud); END;");
    $db->InParameter($stmt, $id_registro, 'p_registro');
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->Execute($stmt);
}

#RESERVA LA SOLICITUD PARA EL AGENTE QUE LO ENCONTRO

function set_reservasolicitud($id_solicitud, $usuario, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_RESERVA_SOLICITUD(:p_solicitud, :p_usuario, :p_usr_super, :p_u_registro); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_solicitud');
    $db->InParameter($stmt, $usuario, 'p_usuario');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->OutParameter($stmt, $p_u_registro, 'p_u_registro');
    $db->Execute($stmt);
    return $p_u_registro;
}

#GUARDA EN TBL_DATOS , EN TBL_TELEFONOS Y EN TD_REGISTRO Y OBTENEMOS LA SOLICITUD NUEVA.

function get_obtiene_guarda_sol($id_registro, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPX_OBTIENE_GUARDA_SOL(:p_id_registro, :p_usr_super, :p_id_solicitud); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $usr_super, 'p_usr_super');
    $db->OutParameter($stmt, $p_id_solicitud, 'p_id_solicitud');
    $db->Execute($stmt);
    return $p_id_solicitud;
}

# DETALLE DE SOLICITUDES NUEVAS PARA HACER LA VENTA DE INTERESADO

function get_detalle_solicitud_nueva($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_SOLICITUDNUEVA(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# DETALLE DE REGISTRO DE BUSQUEDA

function get_detalle_registro($id_registro, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_DETALLEREGISTRO(" . $id_registro . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# SI SE REGRESAN EN LA BUSQUEDA AL IREGISTRO DE TD_REGISTROS SOLO ACTUALIZA LOS DATOS Y NO INSERTA OTRO

function set_actualiza_registro($id_registro, $s_usr_id, $nombre, $paterno, $materno, $nombre_completo, $telefono, $tdc, $tipo_tdc, $celular, $email, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_ACTUALREGISTROLLAMADA(:p_id_registro,:p_user,:p_nombre,:p_paterno,:p_materno,:p_nombre_completo, :p_telefono , :p_tdc ,:p_tipo_tdc, :p_celular, :p_email, :v_reg_actual); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $s_usr_id, 'p_user');
    $db->InParameter($stmt, $nombre, 'p_nombre');
    $db->InParameter($stmt, $paterno, 'p_paterno');
    $db->InParameter($stmt, $materno, 'p_materno');
    $db->InParameter($stmt, $nombre_completo, 'p_nombre_completo');
    $db->InParameter($stmt, $telefono, 'p_telefono');
    $db->InParameter($stmt, $tdc, 'p_tdc');
    $db->InParameter($stmt, $tipo_tdc, 'p_tipo_tdc');
    $db->InParameter($stmt, $celular, 'p_celular');
    $db->InParameter($stmt, $email, 'p_email');
    $db->OutParameter($stmt, $v_reg_actual, 'v_reg_actual');
    $db->Execute($stmt);
    return $v_reg_actual;
}

#CALIFICA EL REGISTRO CUANDO EL AGENTE ABANDONA LA SOLICITUD SIN PROCESAR.

function set_cal_reg_nvo($id_registro, $cont, $maquina, $usr_super, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_CAL_REG_NVO_SOL(:p_id_registro,:p_cont,:p_maquina,:p_super); END;");
    $db->InParameter($stmt, $id_registro, 'p_id_registro');
    $db->InParameter($stmt, $cont, 'p_cont');
    $db->InParameter($stmt, $maquina, 'p_maquina');
    $db->InParameter($stmt, $usr_super, 'p_super');
    $db->Execute($stmt);
}

# REALIZA LA BUSQUEDA DE LOS CODIGOS POSATALES

function get_datos_cp($p_cp, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CODIGOSPOSTALES('" . $p_cp . "',:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## OBTIENE LAS CALIFICACIONES DISPONIBLES PARA EL REGISTRO

function get_calificacion($tipo, $id_solicitud, $id_etapa, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_CALIFICACION('" . $tipo . "'," . $id_solicitud . "," . $id_etapa . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## OBTIENE LAS SUBCALIFICACIONES PARA LA CACLIFICACION SELECCIONADA

function get_subcalificacion_m($tipo, $calif, $etapa, $id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_SUBCALIFICACION('" . $tipo . "'," . $calif . "," . $etapa . "," . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## VALIDA QUE LA SOLICITUD SEA CAPTURA COMPLETAMENTE

function get_valida_solicitud_capturada($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETDATOSCLIENTEINICIO(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## DATOS DE INICIO PARA SUPP

function get_datoscliente_sup($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.XSP_GETDATOSCLIENTEINICIO_SUPP(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# MUESTRA LOS DATOS TELEFONO EN LA SOLICITUD

function get_sps_telefonos_sol($id_solicitud, $db) {
    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_TELEFONOS_SOL(" . $id_solicitud . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

## CAMBIA EL ESTADO DE LA SOLICTUD PARA QUE SE PUEDA ABRIR EN VALIDACION

function set_validando_estado($id_solicitud, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.SPU_SOLICITUD_VALIDANDO(:p_id_registro); END;");
    $db->InParameter($stmt, $id_solicitud, 'p_id_registro');
    $db->Execute($stmt);
}

function get_validacionrfc($id_solicitud, $db) {
    $query = "BEGIN HSBC.CSP_VERIFICACIONRFC(:customerid, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_validarcps($id_solicitud, $db) {
    $query = "BEGIN HSBC.SPS_VALIDARCPs(:customerid, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function es_grabada($id_solicitud, $id_producto, $db) {
    $query = "BEGIN HSBC.SPS_GRABADA(:customerid, :id_producto, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $db->InParameter($stmt, $id_producto, 'id_producto');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_detalle_cp($cp, $colonia, $estado, $municipio, $ciudad, $db) {
    $query = "BEGIN HSBC.CSP_GETLISTACP2(:cp, :colonia, :estado, :municipio, :ciudad, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $cp, 'cp');
    $db->InParameter($stmt, $colonia, 'colonia');
    $db->InParameter($stmt, $estado, 'estado');
    $db->InParameter($stmt, $municipio, 'municipio');
    $db->InParameter($stmt, $ciudad, 'ciudad');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_procesos_detenidos($user, $db) {
    $query = "BEGIN HSBC.SPS_PROCESOSDETENIDOS(:user, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $user, 'user');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_registro_campaña($solicitud, $db) {
    $query = "BEGIN HSBC.SPS_REG_CAMP(:solicitud, :registro); END;";
    $stmt = $db->PrepareSP($query);
    $registro = -1;
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->OutParameter($stmt, $registro, 'registro');
    $db->Execute($stmt);

    return $registro;
}

function set_actualizarnombre($solicitud, $nombre, $apaterno, $amaterno, $db) {
    $query = "BEGIN HSBC.spU_NombrePersonas(:solicitud, :nombre,:apaterno,:amaterno); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $apaterno, 'apaterno');
    $db->InParameter($stmt, $amaterno, 'amaterno');
    $db->Execute($stmt);
}

function get_mensaje_registro($u_registro,$id_usr_super, $db) {
    $query = "BEGIN HSBC.SPS_MENSAJE_REGISTRO(:u_registro,:u_super, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_registro, 'u_registro');
    $db->InParameter($stmt, $id_usr_super, 'u_super');
//    $rs = $db->ExecuteCursor("BEGIN HSBC.SPS_MENSAJE_REGISTRO(" . $u_registro . ", :rc); END;", 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

# Genera el listado completo de la agenda del usuario

function get_agenda_usuario_dia($s_usr_id, $fecha, $db) {
    $query = "BEGIN HSBC.spS_AgendaUsuarioDia(:v_user, :v_date, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $s_usr_id, 'v_user');
    $db->InParameter($stmt, $fecha, 'v_date');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

/**
 * Obtener el u_telefono a partir de la solicitud y el telefono
 * @param int $solicitud
 * @param string $telefono
 * @param connection $db
 * @return int
 */
function get_id_telefono($solicitud, $telefono, $db) {
    $query = "SELECT hsbc.get_IdTelefono(:solicitud, :telefono) AS U_TELEFONO FROM DUAL";
    $rs = $db->Execute($query, array('solicitud' => $solicitud, 'telefono' => $telefono));
    return $rs->fields['U_TELEFONO'];
}

/**
 * Obtener recordset de llamadas al 01800
 * @param int $usr_id
 * @param connection $db
 * @return recordset
 */
function get_800($usr_id, $db) {
    $query = "BEGIN HSBC.SPS_LLAMADA800(:usr_id, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function set_verifica_tel($numero, $db) {
    $query = "BEGIN HSBC.sps_verifcar_numero(:numero,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $numero, 'numero');
    $db->OutParameter($stmt, $resultado, 'resultado');
    /* $rs = */$db->Execute/* Cursor */($stmt/* , 'rc' */);
    return $resultado;
}

##
//xsp_count_tel_ingresado
function set_count_tel($numero, $db) {
    $query = "BEGIN HSBC.xsp_count_tel_ingresado(:u_persona,:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $numero, 'u_persona');
    $db->OutParameter($stmt, $resultado, 'resultado');
    /* $rs = */$db->Execute/* Cursor */($stmt/* , 'rc' */);
    return $resultado;
}

#####  OBTIENE SI HAY REGISTROS REFERIDOS

function get_count_referidos($s_usr_id, $camp, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.XSP_GETCOUNTREFERIDOS(:user, :camp, :res); END;");
    $db->InParameter($stmt, $s_usr_id, 'user');
    $db->InParameter($stmt, $camp, 'camp');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}

function set_insert_nombre_grabacion($solicitud, $nomina, $telefono, $empresa, $db) {

    $query = "BEGIN HSBC.xsp_insert_nombregrabacion(:nomina,:telefono,:solicitud,:empresa,:v_result); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $nomina, 'nomina');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $empresa, 'empresa');
    $db->OutParameter($stmt, $result, 'v_result');
    $db->Execute($stmt);
    echo $result;
}

function get_datos_referido($customerid, $db) {
    $query = "BEGIN HSBC.xsp_datos_referido(:v_customerid,:v_nombre); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $customerid, 'v_customerid');
    $db->InParameter($stmt, $nombre, 'v_nombre');
    //$rs = $db->ExecuteCursor($stmt, 'rc');
    $db->Execute($stmt);
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $nombre;
}

function get_datos_prescrining($solicitud, $nombre, $apaterno, $amaterno, $fecha_nac, $rfc, $calle, $numero, $colonia, $municipio, $edo, $cp, $edo_nac, $nomina, $act2, $db) {
    $query = "BEGIN HSBC.XSP_PRESCREENING(:solicitud,:nombre,:apaterno,:amaterno,:fecha_nac,:rfc,:calle,:numero,:colonia,:municipio,:estado,:cp,:user,:edo_nac,:resultado,:act); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $solicitud, 'solicitud');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $apaterno, 'apaterno');
    $db->InParameter($stmt, $amaterno, 'amaterno');
    $db->InParameter($stmt, $fecha_nac, 'fecha_nac');
    $db->InParameter($stmt, $rfc, 'rfc');
    $db->InParameter($stmt, $calle, 'calle');
    $db->InParameter($stmt, $numero, 'numero');
    $db->InParameter($stmt, $colonia, 'colonia');
    $db->InParameter($stmt, $municipio, 'municipio');
    $db->InParameter($stmt, $edo, 'estado');
    $db->InParameter($stmt, $cp, 'cp');
    $db->InParameter($stmt, $nomina, 'user');
    $db->InParameter($stmt, $edo_nac, 'edo_nac');
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->InParameter($stmt, $act2, 'act');
    $db->Execute($stmt);

    return $resultado;
}

function set_datos_prescrining($nomina, $u_persona, $db) {
    $query = "BEGIN HSBC.SPS_REP_PRESCREENING_OPE(:user,:CUSTOMERID,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $nomina, 'user');
    $db->InParameter($stmt, $u_persona, 'CUSTOMERID');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

function get_cuestionario_calidad($sol,$prod,$db) {
    $query = "BEGIN HSBC.xsp_get_encuestacalidad(:v_solicitud,:v_producto,:rc); END;";
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $sol, 'v_solicitud');
    $db->InParameter($stmt, $prod, 'v_producto');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
    //var_dump($rs);
}

function get_select_bases_especiales($agente, $db) {
    $query = "BEGIN HSBC.XSP_SELECT_BASES_ESPECIALES(:user,:rc); END;";
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $agente, 'user');
    $rs = $db->ExecuteCursor($stmt, 'rc');

    return $rs;
}

function get_insert_bases_especiales($agente, $super_destino, $opcion, $db) {
    $query = "BEGIN HSBC.xsp_setsuper_cambio_base(:nomina,:super_destino,:asigno_base,:opcion,:result); END;";
    $db->SetFetchMode(ADODB_FETCH_ASSOC);
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $agente, 'nomina');
    $db->InParameter($stmt, $super_destino, 'super_destino');
    $db->InParameter($stmt, $agente, 'asigno_base');
    $db->InParameter($stmt, $opcion, 'opcion');
    $db->OutParameter($stmt, $result, 'result');
    $db->Execute($stmt);

    return $result;
}

function toScoreAgent($V_CAMPANA, $CUSTOMERID, $V_NOMINA_AGENTE, $id_usr_super, $V_NOMINA_VALIDADOR, $V_COMENTS, $V_SCORE, $db) {
    $stmt = $db->PrepareSP("BEGIN dbo.SPI_SCORE(:V_CAMPANA, :V_CUSTOMERID, :V_NOMINA_AGENTE, :V_SUPER_AGENTE ,:V_NOMINA_VALIDADOR, :V_COMENTS, :V_SCORE); END;");
    $db->InParameter($stmt, $V_CAMPANA, 'V_CAMPANA');
    $db->InParameter($stmt, $CUSTOMERID, 'V_CUSTOMERID');
    $db->InParameter($stmt, $V_NOMINA_AGENTE, 'V_NOMINA_AGENTE');
    $db->InParameter($stmt, $id_usr_super, 'V_SUPER_AGENTE');
    $db->InParameter($stmt, $V_NOMINA_VALIDADOR, 'V_NOMINA_VALIDADOR');
    $db->InParameter($stmt, $V_COMENTS, 'V_COMENTS');
    $db->InParameter($stmt, $V_SCORE, 'V_SCORE');
    $db->Execute($stmt);
}

##### TRAE LOS AGENTES DE VALIDACION

function getagentevalidacion($campaing, $validador, $db) {
    $stmt = $db->PrepareSP("BEGIN dbo.xsp_getagentevalidacion(:campaing, :validador, :rc); END;");
    $db->InParameter($stmt, $campaing, 'campaing');
    $db->InParameter($stmt, $validador, 'validador');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function getAgendas($NOMINA, $db) {
    $stmt = $db->PrepareSP("BEGIN HSBC.xsp_getAgendas(:V_NOMINA, :rc); END;");
    $db->InParameter($stmt, $NOMINA, 'V_NOMINA');
    $db->OutParameter($stmt, $rc, 'rc');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

// function insertLogEnvioCodigo($customerid, $surveyid, $u_telefono, $nomina, $codigo_aleatorio, $tipo_envio, $proveedor, $db){
//     $fuente = 'S';
//     try {
//     $stmt = $db->PrepareSP("BEGIN HSBC.SPI_LOG_SMS2(:v_customerid, :v_surveyid, :v_u_telefono, :v_nomina, :v_codigo_aleatorio, :v_fuente, :v_tipo_envio, :v_proveedor, :rc); END;");
//     $db->InParameter($stmt, intval($customerid), 'v_customerid');
//     $db->InParameter($stmt, intval($surveyid), 'v_surveyid');
//     $db->InParameter($stmt, intval($u_telefono), 'v_u_telefono');
//     $db->InParameter($stmt, intval($nomina), 'v_nomina');
//     $db->InParameter($stmt, intval($codigo_aleatorio), 'v_codigo_aleatorio');
//     $db->InParameter($stmt, $fuente, 'v_fuente');
//     $db->InParameter($stmt, $tipo_envio, 'v_tipo_envio');
//     $db->InParameter($stmt, intval($proveedor), 'v_proveedor');
//     $rs = $db->ExecuteCursor($stmt, 'rc');
//     return $rs;
//     } catch (exception $th) {
//         echo $th->getMessage();
//     } 
// }

function insertLogEnvioCodigo($customerid, $surveyid, $u_telefono, $nomina, $codigo_aleatorio, $tipo_envio, $proveedor, $db){
    $fuente = 'S';

    //$stmt = $db->PrepareSP("BEGIN HSBC.SPI_LOG_SMS(:v_customerid, :v_surveyid, :v_u_telefono, :v_nomina, :v_codigo_aleatorio, :v_fuente, :v_tipo_envio, :v_proveedor, :rc); END;");
    $stmt = $db->PrepareSP("BEGIN HSBC.SPI_LOG_SMS2(:v_customerid, :v_surveyid, :v_u_telefono, :v_nomina, :v_codigo_aleatorio, :v_fuente, :v_tipo_envio, :v_proveedor, :rc); END;");
    $db->InParameter($stmt, $customerid, 'v_customerid');
    $db->InParameter($stmt, $surveyid, 'v_surveyid');
    $db->InParameter($stmt, $u_telefono, 'v_u_telefono');
    $db->InParameter($stmt, $nomina, 'v_nomina');
    $db->InParameter($stmt, $codigo_aleatorio, 'v_codigo_aleatorio');
    $db->InParameter($stmt, $fuente, 'v_fuente');
    $db->InParameter($stmt, $tipo_envio, 'v_tipo_envio');
    $db->InParameter($stmt, $proveedor, 'v_proveedor');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_resto_tels($id_solicitud, $db){
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_RESTO_TELEFONOS(:v_customerid, :rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'v_customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function getAllShuffleCodes($id_solicitud, $db){
    $stmt = $db->PrepareSP("BEGIN HSBC.SPS_GET_CODIGOS2(:v_customerid, :rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'v_customerid');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}

function get_proveedor_sms($db){
    $query = "BEGIN HSBC.XPS_GETPROVEEDORSMS(:resultado); END;";
    $stmt = $db->PrepareSP($query);
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->Execute($stmt);
    return $resultado;
}

function getCodigo($customerid, $db){
    //$query = "BEGIN HSBC.SPS_OBTENER_CODIGO(:v_customerid, :resultado, :id_log); END;";
    $query = "BEGIN HSBC.SPS_OBTENER_CODIGO2(:v_customerid, :resultado, :id_log); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $customerid, 'v_customerid');
    $db->OutParameter($stmt, $resultado, 'resultado');
    $db->OutParameter($stmt, $id_log, 'id_log');
    $db->Execute($stmt);
    return $resultado . '|' . $id_log;
}

function insertRespuestaCliente($id, $customerid, $codigo_ingresado, $resultado, $db){
    //$query = "BEGIN HSBC.SPI_RESPUESTA_CLIENTE(:v_id, :v_codigo_ingresado, :v_resultado, :rc); END;";
    $query = "BEGIN HSBC.SPI_RESPUESTA_CLIENTE2(:v_id, :v_codigo_ingresado, :v_resultado, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $id, 'v_id');
    $db->InParameter($stmt, $codigo_ingresado, 'v_codigo_ingresado');
    $db->InParameter($stmt, $resultado, 'v_resultado');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    return $rs;
}


function get_datos_dominios_correo($db) {
  //$stmt = $db->PrepareSP("BEGIN " . $query . "(" . $cp . ", :rc); END;");
  $stmt = $db->PrepareSP("BEGIN hsbc.XSP_GETEXTEMAIL(:rc); END;");
  $rs = $db->ExecuteCursor($stmt, 'rc');
  //var_dump($rs);//die();
  $db->SetFetchMode(ADODB_FETCH_BOTH);
  return $rs;
}

function getDatosSolicitud_vicidial($db, $telefono, $solicitud){
    $query = "BEGIN HSBC.XSP_VALIDA_EXISTE_SOL(:v_telefono, :v_solicitud,:rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $telefono, 'v_telefono');
    $db->InParameter($stmt, $solicitud, 'v_solicitud');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
    die();
    // return $rs;
}

##### Inserta las respuestas de L4

function insert_respuestas_l4($u_persona, $fueVenta, $tarjetaFisica, $solicito, $db) {    
    $query = "BEGIN HSBC.XSI_RESPUESTAS_L4(:v_u_persona, :v_fueVenta, :v_tarjetaFisica, :v_solicito, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_persona, 'v_u_persona');
    $db->InParameter($stmt, $fueVenta, 'v_fueVenta');
    $db->InParameter($stmt, $tarjetaFisica, 'v_tarjetaFisica');
    $db->InParameter($stmt, $solicito, 'v_solicito');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    // echo($rs);
    return $rs;
    // die();
}

##### Devuelve el tipo zona de la solicitud

function get_tipo_zona($u_persona, $db) {    
    $query = "BEGIN HSBC.XPS_TIPO_ZONA(:v_u_persona, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_persona, 'v_u_persona');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    // echo($rs);
    return $rs;
    // die();
}

function get_suma_asegurada($u_persona, $db) {    
    $query = "BEGIN HSBC.SPS_SUMA_ASEGURADA(:v_u_persona, :rc); END;";
    $stmt = $db->PrepareSP($query);
    $db->InParameter($stmt, $u_persona, 'v_u_persona');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    // var_dump($rs);
    return $rs;
}