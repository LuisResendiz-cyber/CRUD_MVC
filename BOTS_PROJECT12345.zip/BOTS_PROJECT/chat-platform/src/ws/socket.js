const { Server } = require("socket.io");
const {
  processIncomingMessage,
  closeChatByInactivity,
  reopenSession,
} = require("../services/MessageFlow.service");

const customerModel = require("../models/webchat.models");

let ioInstance = null;

function initWebSocket(server) {
  const io = new Server(server, {
    cors: { origin: "*" },
  });

  ioInstance = io; // 🔑 CLAVE

  io.on("connection", (socket) => {
    const { session_id, type } = socket.handshake.auth;

     if (type === "crm") {
       socket.join("crm_inbox");
       console.log("🧑‍💼 CRM conectado al inbox");

       socket.on("inbox:init", async () => {
         const conversations = await customerModel.getConversations(1);

         socket.emit("inbox:conversations", conversations);
       });

       socket.on("inbox:load_messages", async ({ session_uuid }) => {
         console.log("📥 Backend recibió inbox:load_messages:", session_uuid);

        const messages = await customerModel.getConversations(2,session_uuid);

         console.log("📤 Mensajes encontrados:", messages.length);

         socket.emit("inbox:messages", messages);
       });
     }

    if (session_id) {
      socket.join(session_id); // 🔑 CLAVE
    }

    socket.on("user_message", async (text) => {
      // 1️⃣ Guardar + lógica IA
      const reply = await processIncomingMessage({
        session_id,
        message: text,
        channel: "web",
      });
    


      
      // 2️⃣ Emitir mensaje del usuario
      io.to(session_id).emit("new_message", {
        session_id,
        role: "user",
        message_text: text,
        created_at: new Date(),
      });
      
      console.log(reply);

      // 3️⃣ Emitir mensaje del bot
      if (reply?.events?.length) {
        reply.events.forEach((event) => {
          io.to(session_id).emit("new_message", {
            session_id,
            role: event.role,
            message_text: event.message_text,
            created_at: event.created_at,
          });
        });
      }
    });
    

    socket.on("chat_idle", async () => {
      console.log("⏳ Chat cerrado por inactividad:", session_id);
      await closeChatByInactivity(session_id);
      io.to(session_id).emit("chat_closed");

      socket.emit("chat_closed");
    });

    socket.on("chat_reactivate", async () => {
      console.log("⏳ Chat Reactivado:", session_id);
      await reopenSession(session_id);
    });
  });
}

function emitToSession(sessionId, event, payload) {
  if (!ioInstance) return;
  ioInstance.to(sessionId).emit(event, payload);
}

module.exports = { initWebSocket, emitToSession };
