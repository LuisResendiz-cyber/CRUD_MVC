const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
console.log(context);
// const baseQuery = "BEGIN " + context.schema + ".PROC_UPDATESURVEYRESULTS(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :Lang, :responseText, :llave); END;";
const baseQuery = "BEGIN " + context.schema + ".PROC_UPDATESURVEYRESULTS(:varUserID, :varSurveyID, :varQuestionNo, :varChoiceNo, :Lang, :responseText); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.varUserID || !context.varSurveyID || !context.varQuestionNo || !context.varChoiceNo || !context.Lang || !context.responseText){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.varUserID      = context.varUserID;
            binds.varSurveyID      = context.varSurveyID;
            binds.varQuestionNo      = context.varQuestionNo;
            binds.varChoiceNo      = context.varChoiceNo;
            binds.Lang      = context.Lang;
            binds.responseText      = context.responseText;
						// binds.llave         = context.llave;
            //binds.keys      = context.keyrig;

            const result = await database.simpleExecute(query, binds);

console.log(result);

            return result;
        }
}

module.exports.find = find;
