document.addEventListener("DOMContentLoaded", () => {
  const chatBody = document.querySelector(".chat-body");
  const input = document.querySelector(".chat-footer input");
  const sendBtn = document.querySelector(".chat-footer button");

  if (!localStorage.getItem("chat_session_id")) {
    localStorage.setItem("chat_session_id", crypto.randomUUID());
  }
  window.__CHAT_SESSION_ID__ = localStorage.getItem("chat_session_id");

  // Activar input
  input.disabled = false;
  sendBtn.disabled = false;

  /* =========================
       UTIL: AGREGAR MENSAJE
    ========================== */
  function addMessage(text, type = "bot") {
    const message = document.createElement("div");
    message.className = `message ${type}`;

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    message.appendChild(bubble);
    chatBody.appendChild(message);

    chatBody.scrollTop = chatBody.scrollHeight;
  }

  /* =========================
       MOCK RESPUESTA BOT
    ========================== */
  async function sendMessageToBackend(text) {
    const response = await fetch("http://localhost:4001/apiV1/webchat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        session_id: window.__CHAT_SESSION_ID__,
        message: text,
      }),
    });

    const data = await response.json();
    return data.reply;
  }

  let typingMessage = null;

  function showTyping() {
    if (typingMessage) return;

    typingMessage = document.createElement("div");
    typingMessage.className = "message bot typing";

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = "Escribiendo...";

    typingMessage.appendChild(bubble);
    chatBody.appendChild(typingMessage);

    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function hideTyping() {
    if (typingMessage) {
      typingMessage.remove();
      typingMessage = null;
    }
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
  
    input.value = "";
  
    addMessage(text, "user"); // 1️⃣ mostrar mensaje usuario
    showTyping();             // 2️⃣ mostrar escribiendo
  
    try {
      await sendMessageToBackend(text);
      // ❌ NO pintar bot aquí
      // ❌ NO quitar typing aquí
    } catch (err) {
      console.error(err);
      hideTyping();
      addMessage("Ocurrió un error, intenta más tarde.", "bot");
    }
  }
  

  sendBtn.addEventListener("click", sendMessage);

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  });

  const closeBtn = document.querySelector(".chat-close");

  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      window.parent.postMessage({ type: "CHAT_WIDGET_CLOSE" }, "*");
    });
  }

  let lastMessageId = 0;

  async function loadChatHistory() {
    try {
      const response = await fetch(
        `http://localhost:4001/apiV1/history/${window.__CHAT_SESSION_ID__}`
      );
      const data = await response.json();

      if (data.messages) {
        data.messages.forEach((msg) => {
          addMessage(msg.message_text, msg.role === "user" ? "user" : "bot");

          // 🔑 CLAVE: marcar último mensaje
          lastMessageId = msg.id_webhook;
        });
      }
    } catch (err) {
      console.error("Error cargando historial", err);
    }
  }

  loadChatHistory();

  async function pollMessages() {
    try {
      const response = await fetch(
        `http://localhost:4001/apiV1/messages?session_uuid=${window.__CHAT_SESSION_ID__}&last_id=${lastMessageId}`
      );
  
      const data = await response.json();
  
      if (!data.messages || data.messages.length === 0) return;
  
      data.messages.forEach(msg => {
  
        // 🔐 evitar duplicados
        if (msg.id_webhook <= lastMessageId) return;
  
        if (msg.role === "assistant" || msg.role === "agent") {
          hideTyping(); // 👈 AQUÍ se quita
          addMessage(msg.message_text, "bot");
        }
  
        lastMessageId = msg.id_webhook;
      });
  
    } catch (err) {
      console.error("Polling error", err);
    }
  }
  

  setInterval(pollMessages, 2000);
});
