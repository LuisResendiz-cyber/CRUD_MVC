const Users = require("../models/Users.models");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const secretKey = process.env.JWT_SECRET;


const UsersController = {
  async getUserById(req, res) {
    try {
      const { client } = req.query;

      if (!client) {
        return res.status(400).json({ active: false });
      }

      const data = await Users.getUser(client);

      if (!data) {
        return res.json({ active: false });
      }

      return res.json({
        active: true,
        customerId: data.customerId,
        bot: {
          id: data.botId,
          nombre: data.nombre,
          tipo: data.tipo,
        },
      });
    } catch (err) {
      console.error("INIT ERROR:", err);
      res.status(500).json({ active: false });
    }
  },
  async setUser(req, res) {
    const {
      customer_id,
      name,
      last_name,
      phone_number,
      email_user,
      passwordHash,
      rolid,
    } = req.body;
    const validaUser = await Users.getAcces({ email_user });

    if (validaUser) {
      console.log(
        "El email ya existe en registrado, favor de validar la informacion"
      );
      return res.json({
        message:
          "El email ya existe en registrado, favor de validar la informacion",
      });
    }

    const salt = await bcrypt.genSalt(10);
    const password = await bcrypt.hash(passwordHash, salt);

    try {
      const resp = await Users.CreateUser({
        customer_id,
        name,
        last_name,
        phone_number,
        email_user,
        password,
        rolid,
      });

      if (resp.affectedRows > 0) {
        console.log("Usuario registrado con éxito");
        res.json({
          message: "Usuario registrado con éxito",
          userId: resp.insertId,
        });
      } else {
        res.status(400).json({ message: " No se pudo insertar el usuario" });
      }
    } catch (error) {
      console.log(error.message);
      return res
        .status(500)
        .json({ message: " Error en el servidor, intenta más tarde" });
    }
  },
  async login(req, res) {
    const { email_user, passwordHash } = req.body;
    const user = await Users.getAcces({ email_user });

    console.log(user);

    if (!user) {
      return res.json({
        message: `El usuario ${email_user} no existe, favor de revisar`,
      });
    }
    const isMatch = await bcrypt.compare(passwordHash, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Contraseña incorrecta" });

    // Crear token JWT
    const token = jwt.sign(
      { userId: user.idUser, email_user: user.email_user },
      secretKey,
      { expiresIn: "90d" }
    );

    // Adjuntar token al usuario
    user.token = token;

    res.json({
      status: "success",
      user,
    });
  },
  async changePassword(req, res) {
    const { email_user, passwordHash } = req.body;
    const user = await Users.getAcces({ email_user });
  },
  async getModules(req,res){
    const { id_user } = req.body;
    const data = await Users.getModules(parseInt(id_user));
    return res.json(data)
  }
};

module.exports = UsersController;
