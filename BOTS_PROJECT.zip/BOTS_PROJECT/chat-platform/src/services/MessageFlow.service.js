const customerModel = require("../models/webchat.models");
const ChatResolver = require("../controllers/Knowledge.controller");

async function processIncomingMessage({ session_id, message, channel = "web" }) {

  if (!session_id || !message) {
    throw new Error("Datos incompletos");
  }

  console.log(message);

  // 1️⃣ Obtener o crear sesión
  const session = await customerModel.getOrCreateSession(session_id, channel);
  const conversation_id = session.session_uuid;

  // 2️⃣ Guardar mensaje del usuario
  await customerModel.insertWebhookLog({
    event_type: "web_reply",
    status: "received",
    message_text: message,
    channel,
    role: "user",
    id_envio: conversation_id,
  });

  // 3️⃣ Si está en humano → no responde bot
  if (session.status === "human" || session.status === "closed") {
    return null;
  }

  // 4️⃣ Resolver con IA
  const resolution = await ChatResolver.resolve({
    session,
    message
  });

  const replyText = resolution?.message || null;

  console.log("BOT_ANSWER: " + replyText);

  // 5️⃣ Guardar respuesta del bot
  if (replyText && session.status === "bot") {
    await customerModel.insertWebhookLog({
      event_type: "web_reply",
      status: "sent",
      message_text: replyText,
      channel,
      role: "assistant",
      id_envio: conversation_id,
    });
  }

  return replyText;
}

async function closeChatByInactivity(session_id) {
  await customerModel.closeSession(session_id);

  await customerModel.insertWebhookLog({
    event_type: "chat_closed",
    status: "system",
    message_text: "Chat cerrado por inactividad",
    channel: "web",
    role: "system",
    id_envio: session_id,
  });
}


async function reopenSession(session_id) {

  await customerModel.reopenSession(session_id);

  
  await customerModel.insertWebhookLog({
    event_type: "chat_open",
    status: "system",
    message_text: "El chat ha sido reactivado 😊",
    channel: "web",
    role: "system",
    id_envio: session_id,
  });

}

module.exports = { processIncomingMessage, closeChatByInactivity, reopenSession };
