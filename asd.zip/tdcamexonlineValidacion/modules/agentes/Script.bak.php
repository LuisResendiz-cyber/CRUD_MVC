<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
    <HEAD>
        <META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=iso-8859-1">
        <!--STYLE TYPE="text/css">
            @page { margin-right: 1.18in; margin-top: 0.49in; margin-bottom: 0.98in }
            P { margin-bottom: 0.08in; direction: ltr; color: #000000; line-height: 115%; widows: 2; orphans: 2 }
            P.western { font-family: "Calibri", sans-serif; font-size: 11pt; so-language: es-MX }
            P.cjk { font-family: "Calibri", sans-serif; font-size: 11pt }
            P.ctl { font-family: "Times New Roman", serif; font-size: 11pt; so-language: ar-SA }
        </STYLE-->
    </HEAD>
    <BODY LANG="es-MX" TEXT="#000000" DIR="LTR">
        <DIV TYPE=HEADER>
            <P LANG="" ALIGN=CENTER STYLE="margin-bottom: 0in; line-height: 100%">
                <FONT SIZE=5 STYLE="font-size: 20pt"><B>S<IMG SRC="Script_IN_html_m7c5b5204.jpg" NAME="0 Imagen" ALIGN=LEFT HSPACE=12 WIDTH=208 HEIGHT=68 BORDER=0>cript
                        de Venta – Sìcard</B></FONT></P>
            <P LANG="" STYLE="margin-bottom: 0.45in; line-height: 100%"><FONT FACE="Arial, sans-serif"><FONT SIZE=3>		</FONT></FONT><B>					</B></P>
        </DIV>
        <TABLE WIDTH=699 CELLPADDING=7 CELLSPACING=0 STYLE="page-break-before: always">
            <COLGROUP>
            <COL WIDTH=166>
            </COLGROUP>
            <COLGROUP>
            <COL WIDTH=464>
            <COL WIDTH=28>
            </COLGROUP>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1.50pt solid #800000; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <P CLASS="western"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><B>Elaborado
                                            por:</B></FONT></FONT></FONT></P>
                    </TD>
                    <TD WIDTH=464 STYLE="border-top: 1.50pt solid #800000; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">Blanca
                                        Alegria </FONT></FONT></FONT>
                        </P>
                    </TD>
                    <TD WIDTH=28 STYLE="border: none; padding: 0in">
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <P CLASS="western"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><B>Fecha:</B></FONT></FONT></FONT></P>
                    </TD>
                    <TD WIDTH=464 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">03
                                        de Octubre 2012</FONT></FONT></FONT></P>
                    </TD>
                    <TD WIDTH=28 STYLE="border: none; padding: 0in">
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <P CLASS="western"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><B>Definiciones:</B></FONT></FONT></FONT></P>
                    </TD>
                    <TD WIDTH=464 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">TOC:
                                        Teleoperador</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">CL:
                                        Cliente</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><SPAN STYLE="font-weight: normal">.</SPAN><B>
                                        </B></FONT></FONT></FONT>
                        </P>
                    </TD>
                    <TD WIDTH=28 STYLE="border: none; padding: 0in">
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px dotted #808080; border-left: none; border-right: none; padding: 0in">
                        <OL>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>CONTACTO
                                                    CLIENTE</B></FONT></FONT></FONT></P>
                        </OL>
                        <P STYLE="margin-left: 0.25in; margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#ff0000"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>CL</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=RIGHT><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px dotted #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Buenos
                                        días (tardes, noches) mi nombre es (…..) de Banco Invex sería
                                        tan amable en comunicarme por favor con el Sr(a) (nombre completo
                                        del cliente).</FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                                    <FONT FACE="Arial, sans-serif"><FONT SIZE=2><FONT COLOR="#ff0000">Si
                                                se encuentra.</FONT><FONT COLOR="#595959"> </FONT><FONT COLOR="#0070c0"><I><B>(Ir
                                                        a punto 2)</B></I></FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                                    <FONT FACE="Arial, sans-serif"><FONT SIZE=2><FONT COLOR="#ff0000">No
                                                se encuentra. </FONT><FONT COLOR="#0070c0"><I><B>(Ir a punto 5)</B></I></FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in"><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=2>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>INTRODUCCIÒN</B></FONT></FONT></FONT></P>
                        </OL>
                        <P STYLE="margin-left: 0.25in; margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=RIGHT><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Buenos
                                        días (tardes, noches) Sr.(a) (Nombre y Apellido del cliente), le
                                        habla (Nombre y Apellido del ejecutivo) del Banco Invex. </FONT></FONT></FONT>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P CLASS="western" STYLE="margin-bottom: 0.14in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>El
                                        motivo de mi llamada es para informarle que a los clientes Visa
                                        MC que cuentan con buen manejo de su Tarjeta de Crédito están
                                        siendo acreedores a una línea de crédito Sicard operada por
                                        Invex con beneficios como:</FONT></FONT></FONT></P>
                        <UL>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Un
                                                programa de Tasa Cero, con el cual podrá diferir todas las
                                                compras que UD, realice a 6,12 y 18 meses sin intereses.</FONT></FONT></FONT></P>
                        </UL>
                        <P STYLE="margin-left: 0.5in; margin-bottom: 0in"><BR>
                        </P>
                        <UL>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Un
                                                asistencia medica telefónica la cual cuenta con </FONT></FONT></FONT>
                                </P>
                                <UL>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Orientación
                                                        Médica</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Envío
                                                        de Médico Visitador</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Envío
                                                        de ambulancia gratuita</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Asistencia
                                                        Nutricional</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Asistencia
                                                        Emocional</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Referencia
                                                        a la Red de Médica</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Asistencia
                                                        y Referencias Funerarias</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Conserjería</FONT></FONT></FONT></P>
                                </UL>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Seguro
                                                de Accidentes en Viajes hasta por 75,000 mil dólares</FONT></FONT></FONT></P>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Reemplazo
                                                de emergencia de la Tarjeta de Crédito en el exterior: </FONT></FONT></FONT>
                                </P>
                                <UL>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Estados
                                                        Unidos y Canadá: 1 día hábil</FONT></FONT></FONT></P>
                                    <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Otros
                                                        países: 3 días hábiles</FONT></FONT></FONT></P>
                                </UL>
                        </UL>
                        <P STYLE="margin-left: 1in; margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Solamente
                                        habría que verificar unos datos para informarle  en este momento
                                        si es aprobada dicha tarjeta.</FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Adicional
                                        por ser cliente preferencial y por promoción este año
                                        domiciliando su recibo Telmex a la TDC quedaría exento del pago
                                        de anualidad.</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="font-weight: normal"><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=3>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>PROSPECTACIÒN</B></FONT></FONT></FONT></P>
                        </OL>
                        <P STYLE="margin-left: 0.25in; margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=RIGHT><FONT COLOR="#ff0000"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>CL</B></FONT></FONT></FONT></P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Sondeo:</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <UL>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#00b0f0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">¿Usted
                                                tiene LC a mayor igual a $7,000</FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#00b0f0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt">¿Usted
                                                cuenta con alguna tarjeta de crédito bancaria o comercial con
                                                más de 12 meses de antigüedad?</FONT></FONT></FONT></P>
                        </UL>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><FONT COLOR="#ff0000"><SPAN STYLE="font-weight: normal">Si
                                            contesto si a todas la preguntas. </SPAN></FONT><B><FONT COLOR="#0070c0"><I>(Ir
                                                a punto 4)</I></FONT></B></FONT></FONT></P>
                        <P STYLE="margin-bottom: 0in"><FONT COLOR="#ff0000"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Contesto
                                        no a todas o alguna las preguntas.</FONT></FONT></FONT><FONT COLOR="#ff0000">
                            </FONT><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><I><B>(Ir
                                                al punto 6)</B></I></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="font-weight: normal"><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=4>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>CIERRE
                                                    DE VENTA</B></FONT></FONT></FONT></P>
                        </OL>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#ff0000"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>CL</B></FONT></FONT></FONT></P>
                        <P CLASS="western" STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><SPAN STYLE="font-weight: normal">Gracias
                                        </SPAN><B>Sr(a) (nombre completo del cliente), en este momento
                                            completaremos los datos  para realizar su trámite</B><SPAN STYLE="font-weight: normal">,
                                            y en este mismo momento le informamos si su Tarjeta de crédito
                                            es aprobada.</SPAN></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><I><B>¿Correcto?</B></I></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><I><B>Realizar
                                                primera fase de llenado de solicitud:</B></I></FONT></FONT></FONT></P>
                        <UL>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><I><B>Nombre
                                                        completo</B></I></FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><I><B>RFC/
                                                        Fecha de Nacimiento</B></I></FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><I><B>Domicilio
                                                        completo</B></I></FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2 STYLE="font-size: 9pt"><I><B>Cuatro
                                                        últimos dígitos</B></I></FONT></FONT></FONT></P>
                        </UL>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>Sr(a)
                                            (nombre completo del cliente), en este momento lo transfiero con
                                            el área de calidad para que corroboren los datos que me
                                            proporcionó.</B></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=JUSTIFY><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TRANSFERENCIA
                                            DE LA LLAMADA A VALIDACIÓN </B></FONT></FONT></FONT>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=5>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>NO
                                                    SE ENCUENTRA</B></FONT></FONT></FONT></P>
                        </OL>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC
                                        </B></FONT></FONT></FONT>
                        </P>
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>¿Muchas
                                        gracias, con quien tengo el gusto?</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>Cliente
                                            indica su nombre completo.</B></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>¿Tendrá
                                        algún horario y/o teléfono en el que me pueda comunicar con
                                        Sr(a) (nombre completo del cliente)?</FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>Realizar
                                            la venta de la TDC a la persona que conteste siempre y cuando
                                            cumpla con los requisitos. (VENTA EN FRIO)</B></FONT></FONT></FONT></P>
                        <P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <OL>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Presentarte
                                                nuevamente para realzar la llamada y captar la atención de la
                                                persona con la que hablamos (Mi nombre es X y nos comunicamos de
                                                parte de Banco Invex.</FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Hacer
                                                una  breve introducción de Banco para que sepa de donde estamos
                                                marcando, y mencionar el producto que estamos ofertando (TDC
                                                categoría Oro respaldada por Visa)</FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Comienza
                                                a empatizar  con tu cliente.</FONT></FONT></FONT></P>
                        </OL>
                        <P ALIGN=JUSTIFY STYLE="margin-left: 0.55in; margin-bottom: 0in; font-weight: normal">
                            <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Aprovechando
                                        la llama podemos extender este beneficio para UD o cualquier
                                        persona que tenga como referencia alguna TDC vigente.</FONT></FONT></FONT></P>
                        <OL START=4>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Empezar
                                                a sondear si el cliente maneja actualmente una TDC Bancaria o
                                                Departamental, en caso de tener negativa del cliente hacer un
                                                realce de las tarjetas que aplica y poner ejemplos de cuales son
                                                estas.</FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>En
                                                caso de que la respuesta sea negativa hacer mención si algún
                                                familiar o conocido maneja TDC y nos lo pudiera recomendar para
                                                hacerle extensivo este beneficio.</FONT></FONT></FONT></P>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in; font-weight: normal">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Si
                                                la respuesta es positiva empezar a dar más beneficios de la TDC
                                                y hacer labor de venta.</FONT></FONT></FONT></P>
                        </OL>
                        <P ALIGN=JUSTIFY><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=6>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>NO
                                                    ES PROSPECTO</B></FONT></FONT></FONT></P>
                        </OL>
                        <P STYLE="margin-left: 0.25in; margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=RIGHT STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TOC</B></FONT></FONT></FONT></P>
                        <P STYLE="margin-left: 0.25in"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Le
                                        agradezco su atención, desgraciadamente para poder tramitar su
                                        tarjeta de crédito es necesario que contemos con referencias de
                                        al menos una referencia de Tarjeta de Crédito en Buró de
                                        crédito. Pero nos ponemos a sus órdenes en Línea Sícard al 01
                                        800 4000 4000, que tenga un buen día/ tarde / noche.</FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=JUSTIFY><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <P STYLE="margin-left: 0.25in"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <OL START=7>
                            <LI><P STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>MANEJO
                                                    DE OBJECIONES</B></FONT></FONT></FONT></P>
                        </OL>
                        <P CLASS="western"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P ALIGN=JUSTIFY><FONT COLOR="#0070c0"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><I><B>RESALTAR
                                                BENEFICIOS MÁS IMPORTANTES.</B></I></FONT></FONT></FONT></P>
                    </TD>
                </TR>
            </TBODY>
            <TBODY>
                <TR VALIGN=TOP>
                    <TD WIDTH=166 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: none; border-right: none; padding: 0in">
                        <P STYLE="margin-left: 0.5in"><BR>
                        </P>
                    </TD>
                    <TD COLSPAN=2 WIDTH=506 STYLE="border-top: 1px solid #808080; border-bottom: 1px solid #808080; border-left: 1px solid #808080; border-right: none; padding-top: 0in; padding-bottom: 0in; padding-left: 0.08in; padding-right: 0in">
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <OL>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Manejamos
                                                un programa, que ningún banco tiene de forma permanente, donde
                                                todas las compras que UD realice las podrá diferir a meses sin
                                                interés, UD no tendría que esperar a que las tiendas lancen
                                                promociones en temporadas especiales, todo el año puede diferir
                                                sus compras mayores a $500</FONT></FONT></FONT></P>
                        </OL>
                        <P ALIGN=JUSTIFY STYLE="margin-left: 0.25in; margin-bottom: 0in"><BR>
                        </P>
                        <OL START=2>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Tasa
                                                mensual del 3.75% mensual, pero por su buen comportamiento
                                                crediticio podrá llegar a disminuir hasta el 1.4% mensual</FONT></FONT></FONT></P>
                        </OL>
                        <P STYLE="margin-left: 0.5in; margin-bottom: 0in"><BR>
                        </P>
                        <OL START=3>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Por
                                                promoción este año domiciliando su recibo  Telmex a la TDC
                                                quedará exento del pago de anualidad.</FONT></FONT></FONT></P>
                        </OL>
                        <P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <OL START=4>
                            <LI><P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                                    <FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Ante
                                                cualquier eventualidad UD. puede disponer de hasta un 80% de su
                                                LDC en cualquier cajero RED, con una comisión del 10% del monto
                                                de lo retirado</FONT></FONT></FONT></P>
                        </OL>
                        <P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P ALIGN=JUSTIFY STYLE="margin-right: 0.03in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>YA
                                            TENGO MUCHAS TDC</B></FONT></FONT></FONT></P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Mas
                                                a mi favor Sr. El tener tantas TDC en ocasiones nos puede
                                                generar un descontrol con nuestras finanzas, a lo que si tenemos
                                                una tarjeta que nos de un buen limite de crédito y promociones
                                                tan atractivas como la tasa O ya no necesitaría tener tantas
                                                TDC que le generen descontrol en sus finanzas.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Tendría
                                                dobles beneficios ya que  tendría una TDC  nivel Oro donde
                                                todas sus compras las puede poner a meses sin intereses, y
                                                adicionalmente  le estamos incluyendo la asistencia de telemedic
                                                totalmente sin costo.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Pues
                                                mucho mejor ya que usted como titular se dará cuenta de lo
                                                mucho que ha estado pagando con sus demás TDC y podrá evaluar
                                                aun mejor el excelente servicio que le esta ofreciendo banco
                                                Invex.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.25in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0.14in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>TENGO
                                            DESCONFIANZA EN DAR MIS DATOS</B></FONT></FONT></FONT></P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Le
                                                voy a proporcionar mis datos y mi número telefónico 01 800, le
                                                pido de favor se comunique para que usted pueda verificar que
                                                efectivamente le estamos hablando de banco  INVEX.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Entiendo
                                                perfectamente la desconfianza que esto le puede causar por la
                                                situación que actualmente se vive en nuestro país, pero
                                                precisamente para darle seguridad y confianza, esta llamada esta
                                                siendo grabada y monitoreada, le voy a proporcionar mis datos y
                                                mi número telefónico 01 800 tiene donde anotar? Le pido de
                                                favor terminando la llamada se comunique para que usted pueda
                                                verificar que efectivamente le estamos hablando de banco  INVEX.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.25in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0.14in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>NO
                                            TENGO DINERO</B></FONT></FONT></FONT></P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Precisamente
                                                conociendo la situación económica el día de hoy le estamos
                                                obsequiando su primer  anualidad domiciliando su línea Telmex 
                                                para que se de la oportunidad de conocer una TDC con mejores
                                                beneficios al alcance de su bolsillo. </FONT></FONT></FONT>
                                </P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Precisamente
                                                por eso banco Invex le esta dando la oportunidad de tener una 
                                                TDC con un programa de tasa cero al cual usted puede Inscribirse
                                                y  pagar todas sus compras a meses sin intereses.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Con
                                                nuestras asistencias de Telemedic UD se ahorraría dinero ya que
                                                le estamos ofreciendo descuentos hasta del 30% con un gabinete
                                                de médicos, laboratorios, clínicas, etc.  </FONT></FONT></FONT>
                                </P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.25in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0.14in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2><B>DESCONFIANZA
                                            PARA PROPORCIONAR DIGITOS</B></FONT></FONT></FONT></P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Estos
                                                últimos le aparecen cuando retira efectivo, aparecen en
                                                asteriscos los primeros 12 números y los últimos 4 son los
                                                números comerciales que reportan en buró de crédito.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-left: 0.5in; margin-bottom: 0in">
                            <BR>
                        </P>
                        <UL>
                            <LI><P CLASS="western" ALIGN=JUSTIFY STYLE="margin-bottom: 0in"><FONT COLOR="#595959"><FONT FACE="Arial, sans-serif"><FONT SIZE=2>Los
                                                números que le estoy pidiendo únicamente son los dígitos
                                                comerciales de su TDC, pues NO tienen valor y yo no podría
                                                realizar nada con ellos.</FONT></FONT></FONT></P>
                        </UL>
                        <P CLASS="western" ALIGN=JUSTIFY STYLE="margin-right: 0.03in"><BR>
                        </P>
                    </TD>
                </TR>
            </TBODY>
        </TABLE>
        <P CLASS="western" STYLE="margin-bottom: 0.14in"><BR><BR>
        </P>
        <P CLASS="western" STYLE="margin-bottom: 0.14in"><BR><BR>
        </P>
        <P CLASS="western" STYLE="margin-bottom: 0.14in"><BR><BR>
        </P>
    </BODY>
</HTML>