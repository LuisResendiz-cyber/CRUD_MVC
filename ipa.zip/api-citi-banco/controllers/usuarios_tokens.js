const conexion = require('../services/database_pg.js');
module.exports = {
    obtenerToken(usuario_id){
     return new Promise((resolve, reject) => {
      conexion.query('select * from usuarios_tokens where usuario_id = $1',
      
        [usuario_id],
        (err, resultados,rows) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados);
            if(resultados.length > 0){
              resolve({token:resultados[0].token,uid:resultados[0].uid});
            }else{
              resolve({length:0});
            }
          }
        }
      );
    });
  },
  insertarUsuario(usuario_id,token,uid){
    //console.log("entro 4");
    return new Promise((resolve, reject) => {
      conexion.query('insert into usuarios_tokens values ($1,$2,$3)',
        [usuario_id,token,uid],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados.insertId);
            resolve(resultados[0]);
          }
        }
      );
    });
  },
  updateUsuario(usuario_id,token,uid){
   // console.log("entro 2");
    return new Promise((resolve, reject) => {
      conexion.query('update usuarios_tokens set token= $,uid = $1 where usuario_id = $2',
        [token,uid,usuario_id],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            resolve(resultados[0]);
          }
        }
      );
    });
  },
  cleanUsuario(usuario_id){
   // console.log("entro 2");
    return new Promise((resolve, reject) => {
      conexion.query('delete from usuarios_tokens where usuario_id = $1',
        [usuario_id],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            resolve(resultados[0]);
          }
        }
      );
    });
  }
}
