<?php
class DatabaseConnection {
    private $db;

    public function __construct($environment = 'dsa', $debug = false) {
        date_default_timezone_set('America/Mexico_City');
        
        require_once("adodb.inc.php");
        require_once('adodb-exceptions.inc.php');

        $this->db = newADOConnection("oci8");
        $this->db->debug = $debug;

        // Configuración de entorno de desarrollo
        if ($environment === 'production') {
            $server = '(DESCRIPTION =
               (LOAD_BALANCE = ON)
               (ADDRESS_LIST =
                   (ADDRESS =
                       (PROTOCOL = TCP)
                       (HOST = 192.168.1.13)
                       (PORT = 1521)
                   )
                   (ADDRESS =
                       (PROTOCOL = TCP)
                       (HOST = 192.168.1.14)
                       (PORT = 1521)
                   )
               )
               (CONNECT_DATA =
                   (SERVICE_NAME = xccmtaf)
               )
            )';
        }
        // Configuración de entorno de producción
        else {
            $server = '(DESCRIPTION =
               (ADDRESS =
                 (PROTOCOL = TCP)
                 (HOST = 172.20.1.116)
                 (PORT = 1521)
                )
            (CONNECT_DATA =
                 (SERVICE_NAME = XE)
             )
          )';
        }

        try {
            $this->db->charSet = 'utf8';
            $this->db->Connect($server, 'tdcamexonlineapp', 't32358d86f7');
        } catch (Exception $e) {
            die($e->getMessage());
        }

        $GLOBALS['ADODB_FETCH_MODE'] = ADODB_FETCH_ASSOC;
    }

    public function getConnection() {
        return $this->db;
    }
}
