import { Query } from "mysql2/typings/mysql/lib/protocol/sequences/Query";
import pool from "../config/dbMysqlConfig";
import { ISurvey } from "../interfaces/ISurvey";
import { RowDataPacket } from 'mysql2';

export class SurveyModel {
  public async createSurvey(survey: ISurvey, user_id: string) {
    const {
      CUSTOMERID,
      TYPIFICATIONID,
      CAMPAIGN,
      STATUS_FROM_TMK,
      PRODUCT,
      TDC,
      LINE_CREDIT,
      BASE_FOLIO,
      BIRTH_DATE,
      HOLDER_LAST_NAME_FATHER,
      HOLDER_LAST_NAME_MOTHER,
      HOLDER_NAME,
      RFC,
      HOMOCLAVE,
      CURP,
      COMMENTS,
      STREET,
      EXTERIOR_NUMBER,
      INTERIOR_NUMBER,
      POSTAL_CODE,
      COLONY,
      STATE,
      REFERENCE_MUNICIPALITY,
      MUNICIPALITY,
      CELL_PHONE,
      PHONE,
      CONTACT_PHONE,
      COUNTRY_BIRTH,
      FEDERAL_ENTITY,
      EMAIL,
      MONTHLY_INCOME,
      INCOME_RECEIPT_TYPE,
      IDENTIFICATION_TYPE,
      ADDRESS_RECEIPT_TYPE,
      NUMBER_REFERENCES,
      CREDIT_REFERENCE_1,
      LAST_4_DIGITS_CARD_1,
      CREDIT_REFERENCE_2,
      LAST_4_DIGITS_CARD_2,
      CREDIT_REFERENCE_3,
      LAST_4_DIGITS_CARD_3,
      PERSONAL_LAST_NAME_FATHER,
      PERSONAL_LAST_NAME_MOTHER,
      PERSONAL_NAME,
      PERSONAL_RELATIONSHIP,
      PERSONAL_PHONE,
      PERSONAL_EXTENSION,
      BRANCH_VISIT_DATE
    } = survey;

    try {
      const [result] = await pool.query(
        `INSERT INTO SURVEYDATA (
          ID_USER,
          CUSTOMERID,
          TYPIFICATIONID,
          CAMPAIGN,
          STATUS_FROM_TMK,
          PRODUCT,
          TDC,
          LINE_CREDIT,
          BASE_FOLIO,
          BIRTH_DATE,
          HOLDER_LAST_NAME_FATHER,
          HOLDER_LAST_NAME_MOTHER,
          HOLDER_NAME,
          RFC,
          HOMOCLAVE,
          CURP,
          COMMENTS,
          STREET,
          EXTERIOR_NUMBER,
          INTERIOR_NUMBER,
          POSTAL_CODE,
          COLONY,
          STATE,
          REFERENCE_MUNICIPALITY,
          MUNICIPALITY,
          CELL_PHONE,
          PHONE,
          CONTACT_PHONE,
          COUNTRY_BIRTH,
          FEDERAL_ENTITY,
          EMAIL,
          MONTHLY_INCOME,
          INCOME_RECEIPT_TYPE,
          IDENTIFICATION_TYPE,
          ADDRESS_RECEIPT_TYPE,
          NUMBER_REFERENCES,
          CREDIT_REFERENCE_1,
          LAST_4_DIGITS_CARD_1,
          CREDIT_REFERENCE_2,
          LAST_4_DIGITS_CARD_2,
          CREDIT_REFERENCE_3,
          LAST_4_DIGITS_CARD_3,
          PERSONAL_LAST_NAME_FATHER,
          PERSONAL_LAST_NAME_MOTHER,
          PERSONAL_NAME,
          PERSONAL_RELATIONSHIP,
          PERSONAL_PHONE,
          PERSONAL_EXTENSION,
          BRANCH_VISIT_DATE
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          user_id,
          CUSTOMERID,
          TYPIFICATIONID,
          CAMPAIGN,
          STATUS_FROM_TMK,
          PRODUCT,
          TDC,
          LINE_CREDIT,
          BASE_FOLIO,
          BIRTH_DATE,
          HOLDER_LAST_NAME_FATHER,
          HOLDER_LAST_NAME_MOTHER,
          HOLDER_NAME,
          RFC,
          HOMOCLAVE,
          CURP,
          COMMENTS,
          STREET,
          EXTERIOR_NUMBER,
          INTERIOR_NUMBER,
          POSTAL_CODE,
          COLONY,
          STATE,
          REFERENCE_MUNICIPALITY,
          MUNICIPALITY,
          CELL_PHONE,
          PHONE,
          CONTACT_PHONE,
          COUNTRY_BIRTH,
          FEDERAL_ENTITY,
          EMAIL,
          MONTHLY_INCOME,
          INCOME_RECEIPT_TYPE,
          IDENTIFICATION_TYPE,
          ADDRESS_RECEIPT_TYPE,
          NUMBER_REFERENCES,
          CREDIT_REFERENCE_1,
          LAST_4_DIGITS_CARD_1,
          CREDIT_REFERENCE_2,
          LAST_4_DIGITS_CARD_2,
          CREDIT_REFERENCE_3,
          LAST_4_DIGITS_CARD_3,
          PERSONAL_LAST_NAME_FATHER,
          PERSONAL_LAST_NAME_MOTHER,
          PERSONAL_NAME,
          PERSONAL_RELATIONSHIP,
          PERSONAL_PHONE,
          PERSONAL_EXTENSION,
          BRANCH_VISIT_DATE
        ]
      );

      return result;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  public async createSurveyNoSale(survey: ISurvey, user_id: string){
    try {
      const {CUSTOMERID,TYPIFICATIONID,PHONE} = survey;


      const [result] = await pool.query(`
        INSERT INTO SURVEYDATANOSALES (
          ID_USER,
          CUSTOMERID,
          TYPIFICATIONID,
          PHONE
          ) VALUES (?,?,?,?)`,[user_id,CUSTOMERID,TYPIFICATIONID,PHONE]
        )
      return result;
    } catch (error) {
      console.log(error);
      return false;
    }

  }

  public async getCustomerInfo(CUSTOMERID:string) {

    const query = 'SELECT CUSTOMERID,NAME,LAST_NAME_P,LAST_NAME_M,PRODUCT_TYPE,PRODUCT FROM API_BANAMEX.TEM_CUSTOMER_INFO WHERE CUSTOMERID = ?';
    // const [rows] = await pool.query(query, [CUSTOMERID]);
    const [rows] = await pool.query<RowDataPacket[]>(query, [CUSTOMERID]);

    return rows ;
  }

  public async getAllSurveys(): Promise<ISurvey[]> {
    const query = `SELECT ID_SURVEY,DATE_FORMAT(DATE_INSERT, '%d/%m/%Y') DATE_INSERT,CAMPANA,STATUS_FROM_TMK FROM API_BANAMEX.SURVEYDATA WHERE STATUS_SURVEY = 1 LIMIT 50`;
    const [rows] = await pool.query(query);
    return rows as ISurvey[];
  }

  public async updateSurvey(ID_SURVEY: number, STATUS_SURVEY: ISurvey) {
    const query = `UPDATE API_BANAMEX.SURVEYDATA SET STATUS_SURVEY = ? WHERE ID_SURVEY = ?`;
    const [result] = await pool.query(query, [STATUS_SURVEY, ID_SURVEY]);
    return result;
  }

  public async updateSurveys(ID_SURVEYS: number[], STATUS_SURVEYS: number[]) {
    let query = `UPDATE API_BANAMEX.SURVEYDATA SET STATUS_SURVEY = CASE ID_SURVEY `;

    const updates: string[] = [];
    const values: (string | number)[] = [];

    ID_SURVEYS.forEach((id, index) => {
      updates.push(`WHEN ? THEN ?`);
      values.push(id, STATUS_SURVEYS[index]);
    });

    query +=
      updates.join(" ") +
      ` END WHERE ID_SURVEY IN (${ID_SURVEYS.map(() => "?").join(",")})`;

    values.push(...ID_SURVEYS);
    const [result] = await pool.query(query, values);
    return result;
  }
}
