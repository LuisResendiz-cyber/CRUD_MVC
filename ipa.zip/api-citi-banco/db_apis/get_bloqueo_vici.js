const oracledb = require('oracledb');
const database = require('../services/database.js');

async function give(context){
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".SPS_BLOQUEO_VICI(:rc ); END;";
  let query = baseQuery;

  const binds = {};
  let result2 = {};

  // if(){
  //   result2.error_ = true;
  //   result2.mensaje = "Parametros Erroneos";
  //   return result2;
  //
  // } else{
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    console.log(binds);
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;

  // }
}

module.exports.give = give;
