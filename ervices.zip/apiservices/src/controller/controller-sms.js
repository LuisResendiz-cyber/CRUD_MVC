const { actionsMysql } = require("../model/model-mysql");
const {
  enviarSMS,
  smsMasivoDigital,
  smsMasivoScotiabank,
  smsMasivoHsbc,
  smsMasivoBanamex,
} = require("../model/model-sms");
const {
  oraExcProc,
  oraExcProcNoCursor,
  createConnObj,
  oraExcProc2,
} = require("../model/model-oracle");

const actSms = {
  test: (req, res) => {
    console.log("peticion test sms");
    res.json({ status: 200, rspta: "Mensaje enviado", proveedor: 1 });
  },
  sendSms: async (req, res) => {
    const { msg, tel, campana } = req.body;

    const credencialesSMS = await actionsMysql.credencialesSms(campana);

    if (credencialesSMS.length > 0) {
      const result = await enviarSMS(credencialesSMS, msg, tel);

      const rspta = JSON.stringify(result);
      await actionsMysql.saveLogSms(
        campana,
        tel + "|" + rspta.slice(0, 400),
        "INDIVIDUAL",
        result.proveedor
      );

      res.send(result);
    } else {
      await actionsMysql.saveLogSms(
        campana,
        "Sin Credenciales",
        "Sin Datos",
        "Sin Proveedor"
      );
      console.log("Sin Credenciales");
      res.send({ rspta: "Sin Credenciales para ejecutar envio masivo" });
    }
  },

  sendSmsMasivoDigital: async (req, res) => {
    const campaign = 1008;
    const nameProcedure = "XSP_GET_DATOS_SMS";
    objConnOracle = await createConnObj(campaign, nameProcedure);
    if (objConnOracle != null || objConnOracle != undefined) {
      try {
        const msjMasivos = await oraExcProc(objConnOracle);

        if (msjMasivos.length) {
          const credencialesSMS = await actionsMysql.credencialesSms(campaign);
          const result = await smsMasivoDigital(credencialesSMS, msjMasivos);

          const da = JSON.stringify(result);
          await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL", 1);
          await actionsMysql.saveLogSms(campaign, da, "MASIVO");
          res.send(result);
        } else {
          await actionsMysql.saveLogSms(
            campaign,
            "Sin numero para enviar mensajes",
            "MASIVO"
          );
          await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL", 0);
          console.log("Sin numeros para ejecutar envio masivo");
          res.status(402).json({
            status: 402,
            rspta: "Sin numeros para ejecutar envio masivo",
          });
        }
      } catch (error) {
        res.status(500).send({ error: error.message });
      }
    } else {
      console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    }
  },
  sendSmsMasivoScotiabank: async (req, res) => {
    const campaign = 1002;
    const { opcion } = req.query;
    const nameProcedure = "xsp_sanasPractivas";
    let parameters = { option: opcion, customerid: 0, surveyid: 0 };

    objConnOracle = await createConnObj(campaign, nameProcedure, parameters);
    if (objConnOracle == null || objConnOracle == undefined) {
      console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    } else {
      try {
        const oraRspta = await oraExcProc(objConnOracle);
        if (oraRspta == 0) {
          console.log("NO DATA IN ORACLE");
          res.json({ status: 402, rspta: "NO DATA IN ORACLE" });
        } else {
          // console.log('con datos')
          const credencialesSMS = await actionsMysql.credencialesSms(campaign);
          const smsScotiabank = await actionsMysql.smsScotiabank(campaign);

          const result = await smsMasivoScotiabank(
            oraRspta,
            credencialesSMS,
            smsScotiabank
          );

          const da = JSON.stringify(result.TOTAL);
          await actionsMysql.saveLogCron("SMS MASIVOS SCOTIABANK", 1);
          await actionsMysql.saveLogSms(
            campaign,
            `{"status":200,"desc":"Total mensajes enviados: ${da} "}`,
            "MASIVO",
            1
          );
          let detalles = { ...result.DETALLES };
          // console.log(detalles)
          for (const key in detalles) {
            if (detalles.hasOwnProperty(key)) {
              const elemento = detalles[key];
              let insertLogOra = { ...objConnOracle };
              insertLogOra.nameProcedure = "xsp_ingresa_log";
              insertLogOra.parameters = elemento;
              const oraRspta = await oraExcProcNoCursor(insertLogOra);
              console.log(oraRspta);
            }
          }
          res.send(result);
        }
      } catch (error) {
        res.status(500).send({ error: error.message });
      }
    }
  },
  sendSmsMasivoHsbc: async (req, res) => {
    const campaign = 998;
    const nameProcedure = "XSP_GET_SMS_EMAIL";
    objConnOracle = await createConnObj(campaign, nameProcedure);
    if (objConnOracle == null || objConnOracle == undefined) {
      console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    } else {
      try {
        const msjMasivos = await oraExcProc(objConnOracle);

        if (msjMasivos.length < 1) {
          res.status(402).json({
            status: 402,
            rspta: "Sin numeros para ejecutar envio masivo",
          });
          await actionsMysql.saveLogSms(
            campaign,
            "Sin numero para enviar mensajes",
            "MASIVO"
          );
        } else {
          const credencialesSMS = await actionsMysql.credencialesSms(campaign);
          const result = await smsMasivoHsbc(credencialesSMS, msjMasivos);
          const da = JSON.stringify(result);
          // await actionsMysql.saveLogCron("SMS MASIVOS DIGITAL",1)
          await actionsMysql.saveLogSms(campaign, da, "MASIVO");
          res.json(result);
        }
      } catch (error) {
        console.log(error);
      }
    }
  },
  bulkbanamexSeguros: async (req, res) => {
    try {
      const campaign = 1011;
      const nameProcedure = "XSP_POLIZA";
      const parameters = {
        v_opcion: 9,
        v_customerid: 1,
        v_surveyid: 1,
        v_nomina: 1,
        v_poliza: 1,
        v_rspta: 1,
        v_intento: 1,
      };
      const processCopy = structuredClone(parameters);
      objConnOracle = await createConnObj(campaign, nameProcedure, processCopy);

      if (objConnOracle == null || objConnOracle == undefined) {
        console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
        res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
        return;
      }
      const msjMasivos = await oraExcProc2(objConnOracle);

      if (msjMasivos?.length == 0) {
        await actionsMysql.saveLogSms(
          campaign,
          "Sin numero para enviar mensajes",
          "MASIVO"
        );

        res.status(402).json({
          status: 402,
          rspta: "Sin numeros para ejecutar envio masivo",
        });
        return;
      }
      const credencialesSMS = await actionsMysql.credencialesSms(campaign);

      const processMessage = async (element, message, messageNumber) => {

        const result = await smsMasivoBanamex(
          credencialesSMS,
          message,
          element.PHONE
        );
        const logParameters = {
          v_opcion: 3,
          v_customerid: element.CUSTOMERID,
          v_surveyid: element.SURVEYID,
          v_nomina: messageNumber,
          v_poliza: message,
          v_rspta: JSON.stringify(result),
          v_intento: 1,
        };
        // console.log(logParameters)

        await saveOracleLog(campaign, nameProcedure, logParameters);
        return true;
      };
      const processingPromises = msjMasivos.map(async (element) => {
        try {
          const [result1,result2,result3] = await Promise.all([
            processMessage(element, element.MESSAGE_1, 1),
            processMessage(element, element.MESSAGE_2, 2),
            processMessage(element, element.MESSAGE_3, 3),
          ]);
          return { success: true, results: [result1,result2,result3] };
        } catch (error) {
          console.error(
            `Error processing messages for phone ${element.PHONE}:`,
            error
          );
          return { success: false, error };
        }
      });

      await Promise.all(processingPromises);
      const r = JSON.stringify({ status: 200, desc: `Mensajes enviados` });
      
      await actionsMysql.saveLogSms(campaign, r, "MASIVO");

      res.json({ status: 200, desc: `Mensajes enviados` });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ status: "error", details: error.message });
    }
  },
  ProveedoresSms: async(req,res)=>{
    const {campaign} = req.query;
    const getProvedores = await actionsMysql.ProvSms(campaign);
    res.json(getProvedores);    
  },
  actualizarProv: async(req,res)=> {
    const {campaign, idCredenciales, activo} = req.body;
    const setProvedores = await actionsMysql.setProvSms(campaign, idCredenciales, activo);
    res.status(200).json(setProvedores);
  }
};

const saveOracleLog = async (campaign, nameProcedure, processCopy) => {
  try {
    const objConnOracle = await createConnObj(
      campaign,
      nameProcedure,
      processCopy
    );
    return await oraExcProc2(objConnOracle);
  } catch (error) {
    console.error("Error in saveOracleLog:", error);
    throw error; // Propagar el error para manejarlo arriba
  }
};

module.exports = { actSms };
