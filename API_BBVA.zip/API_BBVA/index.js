const express = require('express');
require('dotenv').config();
const app =  express();
const port = process.env.PORT || 3000;
const UseRoutesAuth = require('./src/routes/AuthRoutes');


const { initOraclePool } = require('./src/config/configOracleSql');

(async () => {
  await initOraclePool();
})();

app.use((req, res, next) => {
  console.log(`METHOD: ${req.method} | URL: ${req.url}`);
  next();
})


app.use(express.json());
//app.use('/api_bbva', UseRoutes);
app.use('/api_bbva/auth', UseRoutesAuth);



app.listen(port, ()=>{
    console.log(`Servicio corriendo en http://localhost:${port}`);    
});