import { Request, Response } from "express";
import { SurveyModel } from "../models/SurveyModel";
import { ISurvey } from "../interfaces/ISurvey";

export class SurveyController {
  private surveyModel: SurveyModel;

  constructor() {
    this.surveyModel = new SurveyModel();
  }

  public createSurvey = async (req: Request, res: Response): Promise<void> => {
    try {
      const surveyData: ISurvey = req.body;
      const { user_id } = req.params;

      const newSurvey = await this.surveyModel.createSurvey(
        surveyData,
        user_id
      );

      if (!newSurvey) {
        res.status(422).json({
          message: "No se pudo procesar la solicitud",
          details: newSurvey,
        });
        return;
      }
      res.status(201).json({
        message: "Registro guardado correctamente",
        // data: newSurvey
      });
    } catch (error) {
      res.status(500).json({ message: "Error al crear la encuesta" });
    }
  };

  public createSurveyNoSale = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const surveyData: ISurvey = req.body;
      const { user_id } = req.params;
      const newSurvey = await this.surveyModel.createSurveyNoSale(
        surveyData,
        user_id
      );
      if (!newSurvey) {
        res.status(422).json({
          message: "No se pudo procesar la solicitud",
          details: newSurvey,
        });
        return;
      }
      res.status(201).json({
        message: "Registro guardado correctamente",
        // data: newSurvey
      });
    } catch (error) {
      res.status(500).json({ message: "Error al guardar el registro" });
    }
  };

  public customerInformation = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { user_id } = req.params;
      const { CUSTOMERID } = req.body;

      const rspta = await this.surveyModel.getCustomerInfo(CUSTOMERID, user_id);

      if (rspta.length === 0) {
        res.json({
          status: "error",
          details: `NO INFORMATION FOUND WITH THIS CUSTOMERID: ${CUSTOMERID}`,
        });
        return;
      }

      res.json({
        status: "success",
        data: rspta,
      });
    } catch (error) {
      res.status(500).json({ message: "Error al crear la encuesta" });
    }
  };

  public getAllSurveySpecific = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const { user_id } = req.params;
      const surveys = await this.surveyModel.getSpecificAllSurveys(user_id);
      res.status(200).json(surveys);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener las encuestas" });
    }
  };

  public getAllSurveys = async (req: Request, res: Response): Promise<void> => {
    try {
      const surveys = await this.surveyModel.getAllSurveys();

      if (!surveys || surveys.length === 0) {
        res.status(200).json({
          status: "success",
          message: "No se encontraron ventas",
          data: [],
        });
        return;
      }

      res.status(200).json({
        status: "success",
        data: surveys,
      });
    } catch (error) {
      // res.status(500).json({ message: 'Error al obtener las encuestas' });
      console.log(error);
      res.status(500).json({
        status: "error",
        message: "Error interno al procesar la solicitud",
        error,
      });
    }
  };
  public getAllSurveysNoSales = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    try {
      const surveys = await this.surveyModel.getAllSurveysNoSales();
      if (!surveys || surveys.length === 0) {
        res.status(200).json({
          status: "success",
          message: "No se encontraron no ventas",
          data: [],
        });
        return;
      }

      res.status(200).json({
        status: "success",
        data: surveys,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        status: "error",
        message: "Error interno al procesar la solicitud",
        error,
      });
    }
  };

  public updateSurveys = async (req: Request, res: Response): Promise<void> => {
    const { ID_SURVEY, STATUS_SURVEY } = req.body;
    try {
      const surveys = await this.surveyModel.updateSurvey(
        ID_SURVEY,
        STATUS_SURVEY
      );

      res.status(200).json(surveys);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar registros" });
    }
  };

  public updateMassSurveys = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    const { option, surveys } = req.body;
    try {
      interface UpdateResult {
        affectedRows: number;
        changedRows?: number;
        // otras propiedades que devuelva tu consulta SQL
      }

      const ID_SURVEYS = surveys.map((survey: any) => survey.ID_SURVEY);
      const STATUS_SURVEYS = surveys.map((survey: any) => survey.STATUS_SURVEY);
      const result = (await this.surveyModel.updateSurveys(
        option,
        ID_SURVEYS,
        STATUS_SURVEYS
      )) as UpdateResult;
      if (result.affectedRows === 0) {
        res.status(200).json({
          status: "error",
          message: "No se realizaron cambios en los registros",
          details: {
            totalRecords: surveys.length,
            updatedRecords: 0,
          },
        });
        return;
      }

      res.status(200).json({
        status: "success",
        message: "Actualización masiva completada",
        data: {
          totalRecords: surveys.length,
          updatedRecords: result.affectedRows,
          changedRecords: result.changedRows || result.affectedRows,
        },
      });
    } catch (error) {
      res.status(500).json({
        status: "error",
        message: "Error interno al actualizar registros",
        error,
      });
    }
  };

  public loadCustomerInformation = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    const { data } = req.body;

    if (data && data.length == 0) {
      res.json({ message: "No data found" });
      return;
    }
    try {
      // await this.surveyModel.truncateTable("TEM_CUSTOMER_INFO");

      const rspta = await this.surveyModel.insertCustomerInfo(data);

      res.json({
        status: "success",
        dataCount: (rspta as any)[0].ROWSINSERT,
        data: `Conteo de registros insertados ${(rspta as any)[0].ROWSINSERT}`,
      });

      return;
    } catch (error) {
      res.status(500).json({ message: "Error al insertar datos" });
    }
  };

  public checkDataCustomer = async (
    req: Request,
    res: Response
  ): Promise<void> => {
    const { page = 1, limit = 10 } = req.body;
    const offset = (page - 1) * limit;

    try {
      const surveys = await this.surveyModel.getAllCustomerInfo(
        page,
        limit,
        offset
      );

      res.status(200).json({
        status: "success",
        data: surveys,
      });
    } catch (error) {
      console.log(error);
      res.status(500).json({
        status: "error",
        message: "Error interno al procesar la solicitud",
        error,
      });
    }
  };
}
