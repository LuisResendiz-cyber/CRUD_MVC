import dotenv from "dotenv";
import express from "express";
import routes from "./routes/Routes";
import authRoutes from "./routes/AuthRoutes";
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import helmet from "helmet";
import bodyParser from "body-parser";

dotenv.config();

class App {
  public app: express.Application;

  constructor() {
    this.app = express();
    this.config();
    this.security();
    this.routes();
    // this.errorHandling();
  }

  private config(): void {
    this.app.use(bodyParser.json({ limit: '50mb' }));
    this.app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
  }

  private security(): void {
    this.app.use(helmet());
    this.app.use(cors({
      origin: '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization']
    }));

    // Rate limiting
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000, // 15 minutos
      max: 100, // Limitar cada IP a 100 
      handler: (req, res) => {
        return res.status(429).json({
          error: "Too many requests from this IP, please try again after 15 minutes."
        });
      }
    });
    this.app.use(limiter);
  }

  private routes(): void {
    this.app.use('/api/v1', routes);
    this.app.use('/api/v1/auth', authRoutes);
    
    //test api
    this.app.get('/health', (req, res) => {
      res.status(200).json({ status: 'OK' });
    });
  }

  // private errorHandling(): void {
  //   // Manejo de errores
  //   this.app.use(errorHandler);
    
  //   // Ruta para manejar 404
  //   this.app.use((req, res) => {
  //     res.status(404).json({ message: 'Endpoint not found' });
  //   });
  // }
}

export default new App().app;
