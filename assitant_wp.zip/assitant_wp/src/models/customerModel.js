const db = require("../config/configmysql");
const { getOraclePool } = require("../config/configOracleSql");

const CustomersModel = {
  async getCustomers() {
    const [result] = await db.query(
      "SELECT nombre, lada, numero FROM WHATSAAP_ASSISTANT.DATA_NUMEROS di WHERE activo = 1"
    );
    return result;
  },
};

module.exports = CustomersModel;
