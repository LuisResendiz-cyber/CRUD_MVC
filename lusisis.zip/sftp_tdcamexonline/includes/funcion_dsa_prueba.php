<?php
class LocalFileHandler {
    private $localDir;

    public function __construct($localDir) {
        $this->localDir = $localDir;
    }

    public function nlist() {
        return scandir($this->localDir);
    }

    public function is_file($filename) {
        return is_file($this->localDir . '/' . $filename);
    }

    public function get($filename, $localPath) {
        return copy($this->localDir . '/' . $filename, $localPath);
    }

    public function rename($oldName, $newName) {
        return rename($this->localDir . '/' . 
        $oldName, 
        $this->localDir . '/' . 
        $newName);
    }

    public function chdir($dir) {
        // No es necesario en este caso, pero puedes implementar lógica si usas subdirectorios
    }
}


?>