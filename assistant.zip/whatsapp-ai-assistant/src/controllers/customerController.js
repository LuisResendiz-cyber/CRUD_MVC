const customerModel = require('../models/customerModel');

const CustomerController = {
    async getCustomers(req, res){
        try {
          const users = await customerModel.getCustomers();
            res.json(users);
        } catch (error) {
            
        }
    }
}

module.exports = CustomerController;