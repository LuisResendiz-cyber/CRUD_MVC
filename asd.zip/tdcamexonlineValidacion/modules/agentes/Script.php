<html xmlns="http://www.w3.org/1999/xhtml">
    <head profile="http://dublincore.org/documents/dcmi-terms/">
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=iso-8859-1"/>
        <title>Script TDC American Express</title>
        <style type="text/css">
            body, tbody {
                font-family: Verdana, Tahoma, Arial, sans-serif;
                font-size: 12px
            }
            .title {
                background: Navy;
                color: White;
            }
        </style>
    </head>        
<body lang="en-US" dir="ltr">
<table width="725" cellpadding="7" cellspacing="0" style="page-break-before: always">
    <col width="166">
    <col width="529">
    <tr>
        <td colspan="2" width="709" valign="top" bgcolor="#ffc000" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="center"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>INTRODUCCIÓN</b></span></font></font></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" height="5" bgcolor="#365f91" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="center"><font color="#ffffff"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>Etapas</b></span></font></font></font></p>
        </td>
        <td width="529" bgcolor="#365f91" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font color="#ffffff"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>   Script</b></span></font></font></font></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p style="margin-bottom: 0in"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Inicio
            / Contacto Inicial</b></span></font></font></font></p>
            <p lang="es-MX" style="margin-bottom: 0in"><br/>

            </p>
            <p lang="es-MX"><br/>

            </p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>TIP:
            Sé natural, escucha con atención, indica tu nombre con apellido
            e indica que eres de American Express. Representas a una gran
            marca, transmite profesionalismo</b></font></font></font><font color="#002060"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>.</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:</b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            Hola, muy buenos (días, tardes, noches). ¿Me podría comunicar
            con el Sr/Srita. </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Nombre
            del Prospecto)</b></u></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">?
            Muchas gracias.</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Si
            no se encuentra el Prospecto, deberás preguntar: </b></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Con
            quién tengo el gusto?</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¡Qué
            tal Sr./Srita! Es un placer saludarlo, mi nombre es </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Nombre
            del Asesor)</b></u></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">de
            American Express</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">.
            ¿</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Cómo
            se encuentra el día de hoy? ¿Qué tal su día?</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Además
            de saludarlo, me permite invitarlo a conocer y disfrutar los
            beneficios que ofrece American Express a personas como usted.
            ¿Sr/Srita. Usted ya es cliente American Express? </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Si
            el Cliente ya cuenta con una Tarjeta American Express deberás:</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Excelente
            Sr./Srita. </font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Nombre
            del Prospecto)</b></u></font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            me da mucho gusto que usted ya se encuentre disfrutando de alguno
            de nuestros servicios.</font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>
             </b></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>(En
            caso de seguir con la venta, si ya cuenta con Tarjeta de Servicio,
            verificar criterios de venta interna, con Script de Companion). Si
            ya cuenta con Tarjeta de Crédito deberá terminar la llamada.</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Si
            el Cliente NO cuenta con una Tarjeta American Express deberás:</b></font></font></font></p>
            <p align="justify"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Continuar
            flujo del Script</font></font></font></p>
        </td>
    </tr>
    <tr>
        <td colspan="2" width="709" valign="top" bgcolor="#ffc000" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="center"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>DESARROLLO</b></font></font></font></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p style="margin-bottom: 0in"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Objetivo
            de la llamada y apertura</b></span></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify"><br/>

            </p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>TIP:
            Modula tu voz para escucharte amable, dinámico, firme, con
            posicionamiento, contagia al cliente de tu seguridad, firmeza y
            decisión.</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Con
            esta Tarjeta, usted gozará de diferentes beneficios, que van
            desde descuentos, tarifas exclusivas y ahorros. </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Con
            American Express usted podrá disfrutar de una Tarjeta en donde:</font></font></font></p>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">El
                primer año no tendrá costo de anualidad </font></font></font>
                </p>
                <li/>
<p align="justify"><span style="display: inline-block; border: none; padding: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><font color="#000000">Protegemos
                prácticamente cualquier artículo mayor a $50 USD que adquieran
                en su totalidad con La Tarjeta ante situaciones como robo con
                violencia, incendio o explosión,</span></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b><font color="#000000">&nbsp;</b></span></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><font color="#000000">hasta
                por $3,000 USD ante robo con violencia.</span></font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">&nbsp;</span></font></font></font></p>
            </ul>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Perfilación
            / Prescreening</b></span></font></font></p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Obtener
            fecha de nacimiento con el objetivo de conformar su RFC</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr./Srita.
            Permítame hacerle algunas preguntas para poder asesorarlo
            correctamente y ofrecer La Tarjeta de Crédito que responderá a
            sus necesidades. </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Los
            datos personales que nos proporcione serán tratados por American
            Express Bank (México), S.A., Institución de Banca Múltiple, con
            domicilio en Patriotismo 635 Col. Ciudad de los Deportes,
            Delegación Benito Juárez, 03710 Ciudad de México, México, con
            la finalidad primaria y necesaria de </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">contactarle
            con el propósito de ofrecerle nuestros servicios, así como para
            dar seguimiento a sus solicitudes </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">de
            las Tarjetas American Express. Para conocer nuestro Aviso de
            Privacidad Integral visite: <a href="http://www.americanexpress.com.mx/">www.americanexpress.com.mx</a></span></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES"><b>A
            continuación encontrarás una serie de preguntas que podrás
            realizar al prospecto para poderlo perfilar&nbsp;adecuadamente.
            Realiza al menos 3 de ellas:</b></span></font></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Cuáles
            son sus ingresos mensuales comprobables? </span></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES"><b>(obligatorio
            realizarla)</b></span></font></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Actualmente
            tiene alguna Tarjeta de Crédito Bancaria activa?</span></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿A
            cuánto asciende su línea de crédito?&nbsp;</span></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Qué
            porcentaje de su línea de crédito tiene utilizada?</span></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Aproximadamente
            a cuánto asciende el monto de Mensualidades Sin Intereses en sus
            Tarjetas de Crédito, si es que las tiene?</span></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Ha
            tenido algún atraso en los últimos 12 meses?</span></font></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0.14in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-ES">¿Cómo
            paga sus tarjetas? ¿Mínimos, parciales o totales?</span></font></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Usted
            ¿utiliza su Tarjeta para hacer compras cotidianas o para pagar
            sus viajes?</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Obtener
            fecha de nacimiento con el objetivo de conformar su RFC</b></font></font></font></p>
            <ol>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Cuál
                es su fecha de nacimiento?</font></font></p>
            </ol>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Corroborar
            su nombre completo</font></font></p>
            <p align="justify" style="margin-bottom: 0.14in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>NO
            score Prescreening </b></span></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Sr/Srita.</span></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><u><b>
            </b></u></span></font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿P</font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">odemos
            corroborar su RFC?</font></font></p>
            <p align="justify" style="margin-bottom: 0.14in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">N</span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>O
            score Prescreening  </b></span></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0.14in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">Sr/Srita.
            </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Me
            podría indicar cómo aparece su nombre en alguno de sus Estados
            de Cuenta bancarios? </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>NO
            score Prescreening </b></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Me
            podría indicar cómo aparece su nombre en su Identificación
            oficial vigente?</font></font><font color="#002060"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>
            </b></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>(si
            es necesario deletrea los datos y verifica si existen
            abreviaturas, ya que no acepta errores de captura)</b></font></font></font><font color="#002060"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>
            </b></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Su
            dirección actualizada es..?</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Score
            menor a &lt; 525 (FIN DE LLAMADA)</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr./
            Srita. Con la información que nos ha proporcionado se realizará
            un análisis y en caso de que podamos continuar con el proceso nos
            comunicaremos con usted, de cualquier manera agradezco su tiempo y
            American Express sigue a sus órdenes.</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ffc000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Score
            mayor a 525 y menor a 630 (SONDEA) </b></font></font></font>
            </p>
            <ol>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Actualmente
                tiene alguna Tarjeta de Crédito Bancaria activa?</font></font></p>
            </ol>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Resp:
            </font></font><font color="#00b050"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">SI</font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>continúa
            flujo del script</b></u></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>
            </b></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in">           <font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>NO</b></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>concluye
            la llamada (ver párrafo de salida de Score menor a 525)</b></u></font></font></font></p>
            <p align="justify" style="margin-left: 0.5in; margin-bottom: 0in"><br/>

            </p>
            <ol start="2">
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">¿Cuánto
                tiempo tiene con ella?</font></font></p>
            </ol>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Resp:
            </span></font></font><font color="#00b050"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">1
            año o más  </font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><u><b>continúa
            flujo del script</b></u></span></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
             </span></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in">           <font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Menos
            de 1 año </b></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>concluye
            la llamada (ver párrafo de salida de Score menor a 525)</b></u></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify"><font color="#00b050"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Score
            mayor a &gt;630 (CONTINÚA VENTA)</b></font></font></font></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Beneficios
             TOP</b></span></font></font></p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>IMPORTANTE:
            Recuerda que dependiendo del ingreso del cliente será el producto
            a ofertar. </b></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>The
            Gold Elite Credit Card American Express </b></span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">(</span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">$15,000
            </span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">MXP
            a </span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US">29,999
            MXP) </span></font></font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Mil
            gracias por la información que me ha proporcionado, le comento
            que adicional a los beneficios que le compartí al inicio de la
            llamada con </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>The
            Gold Elite Credit Card American Express</b></span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">:</span></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in; orphans: 2; widows: 2">
                <font color="#000000"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Le
                ofrece el beneficio de </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Mensualidades
                en Automático, esto significa que todas sus compras  hechas en
                moneda local, iguales o  superiores a $1,200.00 pesos con la
                Tarjeta se diferirán en automático a  6 Mensualidades sin
                Intereses  CAT 0% sin IVA informativo.</b></span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
                Este beneficio es sin costo para usted, y aplicará a partir de
                su primera compra ya sean realizadas directamente en el
                establecimiento o por internet, tanto por el Titular como por los
                 Adicionales</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">.</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
                 </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Y
                si en el futuro requiere cancelar este beneficio, lo puede hacer 
                en cualquier momento de forma fácil llamando a Servicio a
                Clientes de American Express</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
                </span></font></font></font></font></font>
                </p>
            </ul>
            <p align="justify" style="margin-left: 0.11in; margin-bottom: 0in; orphans: 2; widows: 2">
            <font color="#000000"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Con
            este beneficio ya no tendrá que esperar ofertas o promociones
            especiales como por ejemplo, si tiene una emergencia médica puede
            sentirse tranquilo ya que el gasto se podrá diferir a 6 Meses sin
            Intereses, o bien pagar la colegiatura de sus hijos, la membresía
            del gimnasio, los gastos del supermercado o algún gusto como ropa
            o calzado en la tienda que quiera cuando quiera.</span></font></font></font></font></font></p>
            <p align="justify" style="margin-left: 0.11in; margin-bottom: 0in; orphans: 2; widows: 2">
            <font color="#000000"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Si
            desea consultar más información así como los Términos y
            Condiciones, lo invito a consultar la liga
            americanexpress.com.mx/mensualidadesenautomatico</span></font></font></font></font></font></p>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Al
                adquirir su nuevo guardarropa en las Tiendas H&amp;M de todo el
                país obtendrá un 20% de descuento en compras iguales o mayores
                a $1,500 M.N. únicamente tiene que solicitarlo al pagar en caja,
                vigente al 14 de abril del 2017.</span></font></font></p>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Usted
                podrá disfrutar de sus visitas al cine con un 40% de descuento
                al comprar sus  boletos directamente en las taquillas de CINEMEX
                de lunes a viernes para cualquier película o tipo de sala que
                desee incluyendo Salas Platino, con un máximo de 4 boletos al
                mes. Vigente al 30 de abril del 2017.</span></font></font></p>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Todos
                los miércoles en Starbucks disfrutará de su bebida favorita sin
                costo para usted, en una compra mínima de $115 M.N al pagar con
                The Gold Elite Credit Card American Express, solicitándolo en
                caja válido al 31 de diciembre del 2017.</span></font></font></p>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Ahora
                sus compras en línea serán más fáciles con Linio al obtener
                la membresía nivel PLUS, esta membresía tiene un costo en la
                página de Linio de $599 M.N anuales y con The Gold Elite Credit
                Card la podrá disfrutar sin costo. Dándole beneficios como
                envíos sin costo y descuentos especiales.</span></font></font></p>
            </ul>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">The
            Gold elite Credit Card American Express, cuenta con más
            beneficios que podrá revisar en:</span></font></font><font color="#1f497d"><span lang="es-MX">
            </span></font><span lang="es-MX"><a href="http://www.americanexpress.com.mx/beneficiosgoldelite">www.americanexpress.com.mx/beneficiosgoldelite</a>;
            </span><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">así
            como los Términos y Condiciones de las promociones que le acabo
            de mencionar.</span></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>The
            Platinum Credit Card </b></span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
            </span></font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">(A
            partir de $30,000 MXP)  </span></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Gracias
            por la información que me ha proporcionado, le comento que
            adicional a los beneficios que le compartí al inicio de la
            llamada con </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>The
            Platinum Credit Card American Express, </b></span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">usted:</span></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Cada
                vez que disfrute de unas vacaciones en el extranjero TODAS sus
                compras  facturadas en moneda extranjera serán diferidas a 6
                MESES SIN INTERESES </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>
                CAT 0% sin IVA informativo</b></span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
                 sin necesidad de inscribirse o pagar alguna comisión, y no solo
                eso, también TODAS sus compras por Internet.</span></font></font></p>
            </ul>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><i>Además,
                </i></span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">usted
                contará con la Membresía Priority Pass? sin costo, con la que
                podrá iniciar su viaje cómodo y seguro en más de 850 salas de
                espera VIP en distintos países alrededor del mundo &nbsp;teniendo
                4 accesos individuales anualmente sin costo con lo que ahorrará
                $27 USD </span></font></font><font color="#000000"><font face="Tahoma, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">(cantidad
                que ya incluye cualquier impuesto que resulte aplicable)</span></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">
                por cada entrada y $99 USD de la membresía e IVA aplicable.</span></font></font></p>
            </ul>
            <ul>
                <li/>
<p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Por
                otro lado, con la tarjeta The Platinum Credit Card se le otorgará
                la </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
                membresía nivel oro de Fiesta Rewards  con la que podrá  gozar
                de un 10% de descuento en todos los consumos  de restaurante,
                room service y bares, adicional también tiene acceso a WIFI sin
                costo y  cuidamos su comodidad por lo que ofrece registro de
                entradas temprano y salidas tarde (Sujeto a disponibilidad) en
                hoteles como </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Fiesta
                Americana, Fiesta Inn, Live Aqua, One y Explorean</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
                </font></font>
                </p>
            </ul>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">The
            Platinum Credit Card American Express, cuenta con más beneficios
            que podrá revisar en </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><a href="https://www.americanexpress.com/mx/content/cards/platinum-credit-card.html"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">https://www.americanexpress.com/mx/content/cards/platinum-credit-card.html</font></font></a></p>
            <p align="justify"><br/>

            </p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cuota
            Anual </b></font></font>
            </p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>The
            Gold Elite Credit Card American Express</b></span></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Todo
            esto es parte de los excelentes beneficios que usted podrá
            disfrutar al adquirir La Tarjeta The Gold Elite Credit Card&nbsp;</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>sin
            Costo durante el Primer Año</b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">,
            y tan solo pagando a partir del segundo año una cuota anual de
            $1200.00 M.N. + IVA diferido en 3 meses, incluyendo 3 Tarjetas
            adicionales sin costo</font></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">CAT
            promedio 64.6% sin IVA, calculado a agosto 2016. Con una tasa de
            interés anual variable promedio de 39.06% sin IVA la cual podrá
            variar de conformidad con los Términos y Condiciones del contrato
            de apertura de crédito en cuenta corriente</span></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="en-US"><b>The
            Platinum Credit Card American Express</b></span></font></font></font></p>
            <p lang="es-MX" align="justify" style="margin-bottom: 0in"><font face="Times New Roman, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Todo
            esto es parte de los excelentes beneficios que usted podrá
            disfrutar al adquirir La Tarjeta The Platinum Credit Card&nbsp;</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>sin
            Costo durante el Primer Año</b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">,
            y tan solo pagando a partir del segundo año una cuota anual de
            $2700.00 M.N.+ IVA diferido en 3 meses, incluyendo 3 Tarjetas
            adicionales sin costo.</font></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">CAT
            promedio 53.3% sin IVA, calculado a agosto 2016. Con una tasa de
            interés anual variable promedio de 31.25% sin IVA la cual podrá
            variar de conformidad con los Términos y Condiciones del contrato
            de apertura de crédito en cuenta corriente</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">.</span></font></font></p>
            <p style="margin-bottom: 0in"><br/>

            </p>
            <p><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Para
            cualquier detalle puede consultar el contrato de la Tarjeta </font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u>The
            Gold Elite/ The Platinum</u></font></font></font><font color="#000000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            Credit Card en </font></font></font><a href="http://www.americanexpress.com.mx/"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">www.americanexpress.com.mx</font></font></a></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Cierre
            </b></span></font></font>
            </p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr./Srita.
            Con la finalidad de corroborar y autenticar sus datos en Buró de
            Crédito para continuar con este trámite ¿Cuáles son los
            últimos 4 </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">dígitos</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            que aparecen en alguno de sus ticket/voucher de su última compra
            con su tarjeta de crédito? </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cliente:</b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">No,
            no tengo algún ticket/voucher a la mano.</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">No
            se preocupe Sr./Srita. podemos identificar esos mismos números en
            su tarjeta, en la parte de enfrente son los últimos 4.</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr/Srta.
            </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Apellido
            del Prospecto)</b></u></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">me
            podría confirmar sí está de acuerdo en adquirir La Tarjeta
            </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Nombre
            de la Tarjeta)</b></u></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>?</b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cliente:
            </b></font></font><font color="#00b050"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sí
            estoy de acuerdo/ si/ si acepto </font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">continúa</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cliente:
            </b></font></font><font color="#ffc000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Respuesta
            ambigua (déjame pensarlo/ necesito consultarlo/ silencio)  </font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u>Manejo
            de  1 objeción</u></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cliente:
            </b></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">NO/
            No quiero</font></font></font><font color="#ff0000"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u>
            </u></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>se
            califica como</b></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>
            ?Bloqueo 12 meses GRCC Gold Elite/ Platinum? </b></u></font></font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>dependiendo
            de la oferta realizada</b></font></font></font></p>
            <p align="justify" style="margin-bottom: 0in"><font color="#00b050">
            </font><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Correcto</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr/Srta.
            </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Apellido
            del Prospecto)</b></u></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">
            le confirmo que iniciaremos el trámite de solicitud de </font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">La
            Tarjeta </font></font><font color="#0070c0"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><u><b>(Nombre
            de la Tarjeta)</b></u></font></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">.</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Rep:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr./Srita.
            Para su comodidad, puedo enviar la solicitud a su hogar o bien a
            su oficina para que pueda firmarla, ¿le parece bien?, ¿en qué
            horario le parece mejor? </font></font>
            </p>
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><b>Cliente:
            </b></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sí
            de acuerdo?</font></font></p>
            <p align="justify"><br/>

            </p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>AML
            </b></span></font></font>
            </p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="margin-bottom: 0in"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">Sr.
            a partir de este momento capturaremos algunos datos como Titular
            en el sistema:</font></font></p>
            <p align="justify" style="margin-bottom: 0in"><br/>

            </p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">1.
            Nombre completo, sin abreviaturas (Nombres, apellidos paterno y
            materno)</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">2.&nbsp;Fecha
            de Nacimiento&nbsp;(DD/MM/AAAA)</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">3.&nbsp;Domicilio
            completo (calle, número exterior, número interior, colonia,
            delegación o municipio, ciudad o estado, código postal y país.)</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">4.&nbsp;RFC
            con Homoclave</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">5.&nbsp;Teléfono
            (clave de larga distancia y extensión del teléfono, cuando
            aplique)</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">6.&nbsp;Sr.
            /Srita. Su ocupación actual (COMBO)</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">a.&nbsp;Empleado&nbsp;</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">b.&nbsp;Negocio
            Propio&nbsp;</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">c.&nbsp;Profesionista&nbsp;</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">d.&nbsp;Otros</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">7.&nbsp;</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">En
            este momento cuenta con su Identificación Oficial vigente a la
            mano para poder indicarme el folio, siendo la misma que entregará
            a nuestro mensajero en copia y mostrará la original para su
            cotejo</font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">&nbsp;(en
            dado caso de ser afirmativa pasa a la pregunta 8, negativa realiza
            el proceso de las 9 X´s continua en la pregunta 10)</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">a.&nbsp;SI</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">b.&nbsp;NO&nbsp;</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">8.&nbsp;Selecciona
            la ID oficial vigente</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">a.&nbsp;IFE/INE</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">b.&nbsp;Pasaporte</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">c.&nbsp;Credencial&nbsp;Única
            Militar</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">9.&nbsp;Captura
            de folios</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">a.&nbsp;IFE/INE:
            OCR</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">b.&nbsp;Pasaporte/
            N° de Pasaporte</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">c.&nbsp;Credencial&nbsp;Única
            Militar/Folio&nbsp;</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">10.&nbsp;Me
            podría indicar su CURP completo (opcional)</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">a.&nbsp;SI</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">b.&nbsp;NO</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">11.&nbsp;País
            de&nbsp;Nacionalidad</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">12.&nbsp;País
            de Nacimiento</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">13.&nbsp;Estado
            de Nacimiento</font></font></p>
            <p align="justify" style="margin-left: 0.5in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">14.&nbsp;Estado
            civil</font></font></p>
            <p align="justify" style="margin-left: 1in; text-indent: -0.25in; margin-bottom: 0in">
            <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">c.&nbsp;Soltero</font></font></p>
            <p align="justify">                        <font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt">d.&nbsp;Casado</font></font></p>
        </td>
    </tr>
    <tr valign="top">
        <td width="166" height="56" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p lang="es-MX" style="margin-bottom: 0in"><br/>

            </p>
            <p><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX"><b>Despedida</b></span></font></font></p>
        </td>
        <td width="529" bgcolor="#ffffff" style="border: 1px solid #00000a; padding: 0in 0.08in">
            <p align="justify" style="orphans: 2; widows: 2"><font color="#000000"><font face="Arial, serif"><font size="3" style="font-size: 12pt"><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">Le
            reitero mi Nombre__________ ejecutivo/asesor de American Express,
            mi teléfono es_________</span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">,
            lo dejo con mi compañero (a)________de calidad quien validará su
            información y realizará una grabación en la cual usted autoriza
            su nueva Tarjeta. Agradezco </span></font></font><font face="BentonSans Regular, serif"><font size="2" style="font-size: 10pt"><span lang="es-MX">y
            le felicito por su decisión de formar parte de los TH American
            Express, que siga teniendo un(a) excelente día / tarde / noche.
            Hasta luego. </span></font></font></font></font></font>
            </p>
        </td>
    </tr>
</table>
<p style="margin-bottom: 0in; line-height: 100%"><br/>

</p>
</body>
</HTML>
