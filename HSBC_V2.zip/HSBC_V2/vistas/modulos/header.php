<?php
$url = $_GET['url'] ?? null; // Usar null coalescing para evitar errores

$url2 = base64_decode($url);

    header("Location: ". $url2);  


exit();

//<i _ngcontent-ng-c3108270628="" class="glyphicon glyph-small pbi-glyph-open-in-new-window"></i>
//<i _ngcontent-ng-c3108270628="" class="glyphicon glyph-small pbi-glyph-open-in-new-window"></i>

//<i _ngcontent-ng-c1948447989="" class="glyphicon pbi-glyph-share glyph-small socialIcon"></i>

?>