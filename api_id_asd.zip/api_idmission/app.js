const express = require('express')
const dotenv = require('dotenv');
const cors = require('cors')
const fs = require('fs');
const https = require('https');
dotenv.config();
const app = express()
const sandboxRoutes = require('./src/routes/sandboxRoutes')
const privateKey = fs.readFileSync('./src/cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./src/cert/cert.pem', 'utf8');  
const {getKey}= require('./src/controllers/authController')

const credentials = {
  key: privateKey,
  cert: certificate,
 };


app.use(express.json({ limit: '50mb' }));

app.use(cors())
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  next()
})

// app.use('/apiImpulse/v1', routes);

app.use('/sandboxApiImpulse/v1', sandboxRoutes);


(async () => {
  try {
    await getKey()  
  } catch (err) {
    console.error('Error al conectar con la base de datos:', err);
    
  }
})();



const httpsServer = https.createServer(credentials, app);
 


module.exports = httpsServer;
