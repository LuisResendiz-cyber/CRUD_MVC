const get_datos_ob = require('../db_apis/get_datos_ob.js');

async function post(req, res, next) {
  try {
    // console.log("autenticar",req.body)

    const rows = await get_datos_ob.find(req.body);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
      // return rows
      // next();
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;