<?php
ini_set('display_errors',1);
#Reporte Carga File 
#@uthor Mark   

require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

load_session();

header("Content-Type: text/plain");
header("content-disposition: attachment;filename=reporte.xls");

$ky = $_GET['ky'];
?>
	<table border ="2">
		<tr>
			<td># Reg.</td>
			<td>Folio</td>
			<td>Estado cargado</td>
			<td>Solicitud</td>
			<td>Fecha</td>
		</tr>
<?
		$contador = 1;
		$i = 0;
		$rs = get_rerporte_carga($ky, $db);
		while(!$rs->EOF) {
		
			echo '<tr style="background-color:'.getColor($i).'">
                    <td>'.$contador.'</td><td>'.$rs->fields["FOLIO"].'</td><td>'.$rs->fields["STATUS"].'</td><td>'.$rs->fields["SOLICITUD"].'</td><td>'.$rs->fields["FECHA"].'</td>
                  </tr>';
			$rs->MoveNext();
			$i++;
			$contador++;
		}
?>
		<tr>
			<td colspan="12"><b>Registros Encontrados:<?=$i?></b></td>
		</tr>
	</table>