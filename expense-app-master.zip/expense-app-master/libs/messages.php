<?php
    function showError($message){
        echo "<span class='error'>$message</span>";
    }
    function showInfo($message){
        echo "<span class='info'>$message</span>";
    }

    function showSuccess($message){
        echo "<span class='success'>$message</span>";
    }
?>