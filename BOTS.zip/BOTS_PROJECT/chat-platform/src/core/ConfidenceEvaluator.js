// src/core/ConfidenceEvaluator.js
module.exports = {
    evaluate({ userMessage, aiResponse }) {
  
      let score = 1.0;
  
      // Respuesta muy corta
      if (aiResponse.length < 40) score -= 0.3;
  
      // Frases inseguras
      const uncertainPhrases = [
        "no estoy seguro",
        "no tengo información",
        "no puedo",
        "no sé",
        "desconozco"
      ];
  
      if (uncertainPhrases.some(p => aiResponse.toLowerCase().includes(p))) {
        score -= 0.5;
      }
  
      // Usuario escribió algo complejo
      if (userMessage.length > 150) score -= 0.2;
  
      return Math.max(score, 0);
    }
  };
  