const db = require("../config/configmysql");

const CustomersModel = {
  // ============================================================
  // CONTACTOS Y ENVIOS LOCALES
  // ============================================================

  async getCustomers() {
    const [rows] = await db.query(
      `SELECT id_contacto, nombre, lada, numero 
       FROM DATA_NUMEROS 
       WHERE activo = 1`
    );
    return rows;
  },

  async insertEnvio(id_contacto, mensaje) {
    const sql = `
      INSERT INTO ENVIOS (id_contacto, mensaje_enviado)
      VALUES (?, ?)
    `;
    const [result] = await db.query(sql, [id_contacto, mensaje]);
    return result.insertId;
  },

  async updateWamid(id_envio, wamid) {
    await db.query(
      `UPDATE ENVIOS SET wamid = ? WHERE id_envio = ?`,
      [wamid, id_envio]
    );
  },

  async insertEnvioLog({ id_envio, status_id, errorApi }) {
    const sql = `
      INSERT INTO LOG_ENVIO (id_envio, status_id, errorApi)
      VALUES (?, ?, ?)
    `;
    await db.query(sql, [id_envio, status_id, errorApi]);
  },

  async deactivateContactsBatch(ids) {
    if (!ids || ids.length === 0) return;

    const placeholders = ids.map(() => "?").join(",");
    await db.query(
      `UPDATE DATA_NUMEROS SET activo = 0 WHERE id_contacto IN (${placeholders})`,
      ids
    );
  },

  // ============================================================
  // WEBHOOKS
  // ============================================================

  async insertWebhookLog({ event_type, wamid, from_number, status, message_text, role, raw_json }) {
    const sql = `
      INSERT INTO WHATSAPP_WEBHOOK_LOG 
      (event_type, wamid, from_number, status, message_text, role, raw_json)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      String(event_type).substring(0, 20),
      wamid || null,
      from_number || null,
      status || null,
      message_text || null,
      role || null,
      JSON.stringify(raw_json)
    ]);
  },

  async getEnvioByWamid(wamid) {
    const sql = `
      SELECT * 
      FROM ENVIOS
      WHERE wamid = ?
      LIMIT 1
    `;
    const [rows] = await db.query(sql, [wamid]);
    return rows.length ? rows[0] : null;
  },

  async insertEnvioStatus({ id_envio, status }) {
    const sql = `
      INSERT INTO ENVIOS_STATUS (id_envio, status)
      VALUES (?, ?)
    `;
    await db.query(sql, [
      id_envio,
      String(status).substring(0, 50)
    ]);
  },
  async insertSolicitudTarjeta({ telefono, wamid, boton_id, raw }) {
    const sql = `
      INSERT INTO whatsapp_webhook_log 
      (event_type, wamid, from_number, status, message_text, raw_json)
      VALUES (?, ?, ?, NULL, ?, ?)
    `;
  
    const params = [
      "button",
      wamid,
      telefono,
      boton_id,
      JSON.stringify(raw)
    ];
  
    const [result] = await db.execute(sql, params);
    return result.insertId;
  },
  async getLastMessagesByConversation(conversation_id) {
    if (!conversation_id) return [];
  
    const sql = `
      SELECT wwl.message_text
      FROM DATA_NUMEROS dn
      JOIN ENVIOS e ON e.id_contacto = dn.id_contacto 
      JOIN ENVIOS_STATUS es ON es.id_envio = e.id_envio
      LEFT JOIN WHATSAPP_WEBHOOK_LOG wwl ON wwl.from_number = dn.numero
      WHERE e.id_envio = 35 AND wwl.event_type = 'message'
      ORDER BY wwl.created_at ASC
    `;
    const [rows] = await db.query(sql, [conversation_id]);
  
    return Array.isArray(rows) ? rows : [];
  }  
};

module.exports = CustomersModel;
