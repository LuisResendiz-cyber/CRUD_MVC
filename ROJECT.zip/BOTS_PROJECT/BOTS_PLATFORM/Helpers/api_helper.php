<?php
// Helpers/api_helper.php

if (!function_exists('api')) {
    function api() {
        return \Core\ApiClient::getInstance();
    }
}

if (!function_exists('api_get')) {
    function api_get($endpoint, $params = []) {
        return api()->get($endpoint, $params);
    }
}

if (!function_exists('api_post')) {
    function api_post($endpoint, $data = []) {
        return api()->post($endpoint, $data);
    }
}

if (!function_exists('api_put')) {
    function api_put($endpoint, $data = []) {
        return api()->put($endpoint, $data);
    }
}

if (!function_exists('api_delete')) {
    function api_delete($endpoint) {
        return api()->delete($endpoint);
    }
}

if (!function_exists('api_set_token')) {
    function api_set_token($token) {
        return api()->setToken($token);
    }
}

if (!function_exists('log_api_error')) {
    function log_api_error($message, $context = []) {
        $logFile = __DIR__ . '/../logs/api_errors.log';
        
        if (!is_dir(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] {$message}";
        
        if (!empty($context)) {
            $logMessage .= " Context: " . json_encode($context, JSON_PRETTY_PRINT);
        }
        
        $logMessage .= "\n";
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
}
?>