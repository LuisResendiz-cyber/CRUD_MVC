import { config } from 'dotenv';
config();

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
import cron from "node-cron";
import { checkConn} from "./src/controller/mysqlController.js";
import { initPool} from "./src/config/dbOracle.js";
import { checkConnOra} from "./src/controller/gralController.js";
import { start } from "./src/controller/sftpController.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const FLAG_FILE = path.join(__dirname, 'process.flag');
const MAX_FLAG_AGE_MS = 3 * 60 * 1000; // 3 minutos en milisegundos



console.log("\x1b[33m%s\x1b[0m", "--Developed by dtrejo--");


async function verifyDatabaseConnection() {
  try {
    if (!await checkConn()) {
      // console.log("\x1b[35m%s\x1b[0m", "Conexión a MySQL exitosa *");
      console.log('Sin conexion a mysql');
      return false;
    }
    await initPool();
    console.log("Pool de conexiones ORACLE inicializado");
    if (!await checkConnOra()) {
      console.log('Sin conexion a oracle');
      // console.log("\x1b[35m%s\x1b[0m", "Conexion a Oracle exitosa *");      
    }
    console.log("\x1b[35m%s\x1b[0m", "Conexion a mysql y  Oracle exitosa *");      
    return true

  } catch (err) {
    console.error("Error al conectar con la base de datos:", err);
    process.exit(1);
  }
}

const cleanMemory = () => {
  const memoryUsage = process.memoryUsage();
  console.log("\x1b[31m%s\x1b[0m", `Uso de memoria:`);

  console.log({
    rss: memoryUsage.rss / 1024 / 1024 + " MB", //Memoria total asignada al proceso.
    heapTotal: memoryUsage.heapTotal / 1024 / 1024 + " MB", //Memoria total del heap
    heapUsed: memoryUsage.heapUsed / 1024 / 1024 + " MB", //Memoria V8 realmente usada.
    external: memoryUsage.external / 1024 / 1024 + " MB", //Memoria usada por buffers fuera de V8
  });
  console.log("\x1b[31m%s\x1b[0m",  '_'.repeat(40));
};



// Función para crear la bandera
function createFlag() {
  try {
      fs.writeFileSync(FLAG_FILE, `Process started at: ${new Date().toISOString()}`);
      console.log('Bandera creada');
      return true;
  } catch (err) {
      console.error('Error al crear bandera:', err);
      return false;
  }
}


// Función para eliminar la bandera
function removeFlag() {
  try {
      if (fs.existsSync(FLAG_FILE)) {
          fs.unlinkSync(FLAG_FILE);
      }
      console.log('Bandera eliminada');
      return true;
  } catch (err) {
      console.error('Error al eliminar bandera:', err);
      return false;
  }
}


// Función para verificar y limpiar banderas antiguas
function checkFlag() {
  try {
      if (fs.existsSync(FLAG_FILE)) {
          const stats = fs.statSync(FLAG_FILE);
          const now = new Date();
          const flagAge = now - stats.mtime;
          console.log(flagAge,'--------------', MAX_FLAG_AGE_MS);

          if (flagAge > MAX_FLAG_AGE_MS) {
              console.log(`Bandera antigua encontrada (${flagAge/1000} segundos), eliminando...`);
              fs.unlinkSync(FLAG_FILE);
              return false;
          }
          return true; // Bandera valida existe
      }
      return false; // No hay bandera
  } catch (err) {
      console.error('Error al verificar bandera:', err);
      return false;
  }
}

const safeExecute = async (fn) => {
  // Verificar si hay una ejecución en curso
  if (checkFlag()) {
    console.log("Proceso anterior aún en ejecución, saltando esta ejecución.");
    return;
  }

  // Crear bandera
  if (!createFlag()) {
    console.log('No se pudo crear bandera, saltando ejecución.');
    return;
}

  try {
    await fn();
  } catch (error) {
    console.error("Error en la tarea cron:", error);
  } finally {
    removeFlag();
    cleanMemory();
  }
};



await verifyDatabaseConnection();

const WORK_HOURS_DAILY = "*/3 8-19 * * 1-6";
const EVENING_HOURS = "*/10 20-23 * * 1-6";
const NIGHT_HOURS = "*/10 0-7 * * 1-6";
const SUNDAYS = "*/10 * * * 0";

cron.schedule(WORK_HOURS_DAILY, () => safeExecute(start));
cron.schedule(EVENING_HOURS, () => safeExecute(start));
cron.schedule(NIGHT_HOURS, () => safeExecute(start));
cron.schedule(SUNDAYS, () => safeExecute(start));

