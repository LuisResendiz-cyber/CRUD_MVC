const { createConnObj, oraExcProc2 } = require("../model/model-oracle");
const { Process } = require("../model/model-pg");

const availableProcess = [
  {
    id_process: "001", //Calificada auto
    campaign: 1008,
    nameProcedure: "XSP_REPORTES_AUTOMATICOS",
    parameters: { v_option: 3, v_tri: 1 },
    status: true,
  },
  // {
  //   id_process: "002",
  //   campaign: 1008,
  //   nameProcedure: "XSP_REPORTES_AUTOMATICOS",
  //   parameters: { v_option: 3, v_tri: 1 },
  //   status: true,
  // },
];

const automatic = async (req, res) => {
  try {
    const promises = availableProcess.map(element => getData(element));
    const results = await Promise.all(promises);
    
    res.json({
      status: 200,
      message: "All processes completed",
      details: results
    });
  } catch (error) {
    console.error("Error en el proceso completo:", error);
    // console.error(`Error in getData [${element.id_process}]:`, error.stack);
    res.status(500).json({
      status: 500,
      message: "INTERNAL SERVER ERROR",
      details: error.message
    });
  }
};

const getData = async (element) => {
  try {
    const processCopy = structuredClone(element);
    // Creamos el objeto con los datos de conexión
    const objConnOracle = await createConnObj(processCopy.campaign, processCopy.nameProcedure, processCopy.parameters);

    if (!objConnOracle) {
      return { status: false, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" };
    }
    // Ejecutamos el procedimiento de oracle
    const oraRspta = await oraExcProc2(objConnOracle);

    if (!oraRspta || oraRspta.length === 0) {
      return { status: false, rspta: "NO DATA IN ORACLE" };
    }
    // Insertamos los datos en pg
    const rSave = await saveData(processCopy.id_process, oraRspta);    
    // console.log(rSave)
    if (!rSave) {
      return { status: false, rspta: rSave };
    }
    return { status: true, rspta: "PROCESS SUCCESSFULLY COMPLETED" };
  } catch (error) {
    console.error("Error in getData:", error);
    return { status: false, rspta: "INTERNAL SERVER ERROR" };
  }
};

const saveData = async (id_process, data) => {
  let table=''
  try {
    switch (id_process) {
      case "001":
        table='amexinsurancedig.calificada_insurancedig_auto'
        const rspta = await Process.insertAuto(data,table);
        return rspta.rowCount != 0;
        case "002":
          table='amexinsurancedig.calificada_insurancedig_auto'
          const rspta2 = await Process.insertAuto(data,table);
          return rspta2.rowCount != 0;        
      default:
        console.error(`Unknown process ID: ${id_process}`);
        return false;
    }
  } catch (error) {
    console.error(`Error in saveData for process ${id_process}:`, error);
    return false;
  }
};

module.exports = {
  automatic,
};
