var tableUsuarios;
var divLoading = document.querySelector("#divLoading");

(async () => {
    try {
        const response = await getData(`${base_url}/Bots/getBots`);

        if (response.status == true) {
            renderBotsCards(response.bots);
        }else{            
            swal("¡Alerta!", "Sin registros de Bots", "warning");

        }
    } catch (error) {
        console.error('Error al cargar bots:', error);
    }
})();


function renderBotsCards(bots = []) {
    const container = document.getElementById('botsContainer');
    container.innerHTML = '';

    if (!bots.length) {
        container.innerHTML = '<p class="text-center">No hay bots disponibles</p>';
        return;
    }

    bots.forEach(bot => {
        const isIA = bot.ID_LLM === 1;
        const isActive = bot.STATUS_NUMERIC === 1;

        const card = document.createElement('div');
        card.className = 'chatbot-card';

        card.innerHTML = `
            ${isIA ? '<span class="badge badge-ai">IA</span>' : ''}
            <span class="badge ${isActive ? 'badge-active' : 'badge-inactive'}">
                ${isActive ? 'Activo' : 'Inactivo'}
            </span>

            <div class="card-body text-center">
                <div class="icon mb-3">
                    <i class="fa fa-robot"></i>
                </div>

                <h5>${bot.NOMBRE}</h5>

                <button onclick="goToBot(${bot.ID})" class="btn btn-primary btn-sm mt-3" data-id="${bot.ID}">Iniciar</button>
            </div>
        `;

        container.appendChild(card);
    });
}

function goToBot(id) {
    window.location.href = `${base_url}/bots/configuration/${id}`;
}

async function fntRolesUsuario(idRol = null) {
    const Url = `${base_url}/Roles/getRoles`;

    const response = await fetch(Url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: 1 })
    });

    const objData = await response.json();
    const roles = objData.roles;

    const $select = $('#listRolid');

    $select.empty();

    $select.append(`<option value="">Seleccione un rol</option>`);

    roles.forEach(role => {
        $select.append(`
            <option value="${role.ID}">
                ${role.NOMBRE}
            </option>
        `);
    });

    // 🔥 1. refresca opciones
    $select.selectpicker('refresh');

    // 🔥 2. fuerza el valor seleccionado
    if (idRol) {
        $select.selectpicker('val', idRol);
    }

    // 🔥 3. renderiza el texto visible
    $select.selectpicker('render');
}

function fntViewUsuario(data){
    const {EMAIL,FECHA_CREACION,  ID, ID_ROL, NOMBRE, NOMBRE_ROL, phone_number,status} = data.data;
    
            if(status)
            {
               var estadoUsuario = status == 1 ? 
                '<span class="badge badge-success">Activo</span>' : 
                '<span class="badge badge-danger">Inactivo</span>';

                document.querySelector("#celIdentificacion").innerHTML = ID;
                document.querySelector("#celNombre").innerHTML = NOMBRE;
                document.querySelector("#celTipoUsuario").innerHTML = NOMBRE_ROL;
                document.querySelector("#celEstado").innerHTML = estadoUsuario;
                document.querySelector("#celTelefono").innerHTML = phone_number;
                document.querySelector("#celEmail").innerHTML = EMAIL;
                document.querySelector("#celFechaRegistro").innerHTML = FECHA_CREACION;
                $('#modalViewUser').modal('show');
            }else{
                swal("Error", "Sin datos para Visualizar" , "error");
            }
}

async function editUsuarios(data){
    console.log(data);
    const {EMAIL,FECHA_CREACION,  ID, ID_ROL, NOMBRE, APELLIDO, NOMBRE_ROL, phone_number,status} = data.data;

    document.querySelector('#titleModal').innerHTML ="Actualizar Usuario";
    document.querySelector('.modal-header').classList.replace("headerRegister", "headerUpdate");
    document.querySelector('#btnActionForm').classList.replace("btn-primary", "btn-info");
    document.querySelector('#btnText').innerHTML ="Actualizar";
    
        document.querySelector("#idUsuario").value = ID;
        document.querySelector("#txtNombre").value = NOMBRE;
        document.querySelector("#txtApellido").value = APELLIDO;
        document.querySelector("#txtTelefono").value = phone_number;
        document.querySelector("#txtEmail").value = EMAIL;
        await fntRolesUsuario(ID_ROL,NOMBRE_ROL);
        //document.querySelector("#listRolid").value =NOMBRE_ROL;
        //$('#listRolid').selectpicker('render');

        if(status == 1){
            document.querySelector("#listStatus").value = 1;
        }else{
            document.querySelector("#listStatus").value = 2;
        }
        $('#listStatus').selectpicker('render');
        $('#modalFormUsuario').modal('show');
}

function fntDelUsuario(idpersona){

    var idUsuario = idpersona;
    swal({
        title: "Eliminar Usuario",
        text: "¿Realmente quiere eliminar el Usuario?",
        type: "warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar!",
        cancelButtonText: "No, cancelar!",
        closeOnConfirm: false,
        closeOnCancel: true
    }, function(isConfirm) {
        
        if (isConfirm) 
        {
            var request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'/Usuarios/delUsuario';
            var strData = "idUsuario="+idUsuario;
            request.open("POST",ajaxUrl,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status)
                    {
                        swal("Eliminar!", objData.msg , "success");
                        tableUsuarios.api().ajax.reload();
                    }else{
                        swal("Atención!", objData.msg , "error");
                    }
                }
            }
        }

    });

}

async function openModal()
{
    document.querySelector('#idUsuario').value ="";
    document.querySelector('.modal-header').classList.replace("headerUpdate", "headerRegister");
    document.querySelector('#btnActionForm').classList.replace("btn-info", "btn-primary");
    document.querySelector('#btnText').innerHTML ="Guardar";
    document.querySelector('#titleModal').innerHTML = "Nuevo Usuario";
    document.querySelector("#formUsuario").reset();
    $('#modalFormUsuario').modal('show');

    await fntRolesUsuario();
}

function openModalPerfil(){
    $('#modalFormPerfil').modal('show');
}