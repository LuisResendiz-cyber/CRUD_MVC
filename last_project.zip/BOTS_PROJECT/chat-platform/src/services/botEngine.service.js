const KnowledgeModel = require("../models/Knowledge.models");
const botInfo = require("../models/bots.models");
const ContextBuilder= require("../services/context.service");
const { generate } = require("./LLM.service");


const BotEngine = {
    async process({ botId, message }) {
  
      // 1. Traer configuración completa del bot

      const bot = await botInfo.Bot(9, {botId});
      const botConfig = bot[0];

      if (!botConfig || botConfig.estado !== "activo") {
        return { type: "BOT", message: "Bot no disponible." };
      }
  
      // 2. Traer prompts activos    
      const prompts = await KnowledgeModel.getActiveByBot(botId);
  
      // 3. Traer knowledge relevante (si está habilitado)
      let knowledgeList = [];

        if (botConfig.knowledge_enabled == 1) {
        knowledgeList = await KnowledgeModel.searchRelevant(
            message,
            botId,
            5
        );
        }        
      

        // 4. Construir contexto dinámico
      const context = ContextBuilder.build({
        botConfig,
        prompts,
        knowledgeList,
        userMessage: message
      });


      // 5. Generar respuesta usando tu pipeline actual
      const response = await generate(context);
      
      return {
        type: "BOT",
        message: response
      };
    }
  };
  

  module.exports = BotEngine;