const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
  //console.log(context);   
  const baseQuery = "BEGIN " + context.schema + ".proc_CompareSurveyResults_WS1(:varUserID, :varSurveyID, :Varrecnocedor, :Lang, :responseText, :YaExiste); END;";
  /*console.log(typeof(context.varUserID));   
  console.log(typeof(context.varSurveyID));    
  console.log(typeof(context.Varrecnocedor));   
  console.log(typeof(context.Lang));   
  console.log(typeof(context.responseText));*/
	
  let query = baseQuery;
	const binds = {};
	let result2 = {};

  if(!context.varUserID || !context.varSurveyID || !context.Lang || !context.responseText || !context.YaExiste){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    //{val:context.xxxxxx ,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.varUserID = {val:parseInt(context.varUserID) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER};
    binds.varSurveyID = {val:parseInt(context.varSurveyID) ,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_NUMBER};
    binds.Varrecnocedor = {val:context.Varrecnocedor ,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.Lang = {val:parseInt(context.Lang) ,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_NUMBER};
    binds.responseText = {val:context.responseText ,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    binds.YaExiste = {val:context.YaExiste, dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR}; 

    const result = await database.simpleExecute(query, binds);

    //console.log('---', result, '---'); 

    return result;
  }            
}
  
module.exports.find = find; 

