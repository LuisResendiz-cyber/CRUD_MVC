<?php
# @uthor Mark  
# Error File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Error");
layout_menu($db, "");
//$isPredictivo = get_EsPredictivo($db);
$isPredictivo = 0;

$error = $_REQUEST["e"];

$sol = $_REQUEST["customerid"];
$registro = $_REQUEST["u_registro"];
$hora = $_REQUEST["hora"];
$fecha = $_REQUEST["fecha"];
$coment = $_REQUEST["com"];

//if(isset($_REQUEST['activo_tz']))
//    $activo_tz = $_REQUEST['activo_tz'];
if(isset($_REQUEST['id_bloqueo']))
    $id_bloqueo = $_REQUEST['id_bloqueo'];
if(isset($_REQUEST['u_zona']))
    $u_zona = $_REQUEST['u_zona'];
if(isset($_REQUEST['estatus']))
    $estatus = $_REQUEST['estatus'];
if(isset($_REQUEST['agendas']))
    $agendas = $_REQUEST['agendas'];
if (isset($_REQUEST['texto']))
    $texto = $_REQUEST['texto'];


if($error == 1){
    $bnd = $_REQUEST['bnd'];
    if($bnd == 1){
        $msg_error = 'No est&aacute;s asignado a una zona';
    }else if($bnd == 2){
        $msg_error = 'Se excedi&oacute; el n&uacute;mero de registros permitidos por hora';
    }else if($bnd == 3){
        $msg_error = 'No hay mas registros Libres y Abandonados';
    }elseif ($bnd == 4) {
        
        $producto_agente = $_REQUEST["productoagente"];
        $producto_registro = $_REQUEST["productoregistro"];
        
        if($producto_agente != $producto_registro) { // no hace match el producto
            $msg_error .= 'No se puede entregar la agenda (PRODUCTO '.$producto_registro.') debido a que no pertenece al asignado al agente (PRODUCTO '.$producto_agente.')';
        } else {
        
            if($id_bloqueo == 16){
                $msg_error .= 'La solicitud ' . $sol . ' no es de la zona  de tu super :(' ;
            }
            else if ($id_bloqueo != 1) {
                $msg_error .= 'La solicitud ' . $sol . ' ha sido bloqueada por Inteligencia de Mercado <br>Descripci&oacute;n: ' . $texto;
            }elseif ($estatus == 0) {
                $msg_error .= 'La zona ' . $u_zona . ' esta inactiva de la solicitud ' . $sol . '. <br>';
            }elseif ($agendas == 0) {
                $msg_error .= 'No se pueden tomar agendados de la zona ' . $u_zona . ' de la solicitud ' . $sol . '. Más informacion en Inteligencia de Mercado <br>';
            }
        }
    }
} else if ($error == 2) {
    $msg_error = 'El registro no se pudo liberar correctamente, intente de nuevo!!!';
} else if ($error == 3) {
    $msg_error = 'No tienes permitido realizar busqueda de registros!!!';
} else if ($error == 4) {
    $msg_error = 'Se encontró un error al obtener un registro especifico!!!';
} else if ($error == 61) {
    $msg_error = 'Se encontró un error al obtener un registro de predictivo (29)!!!';
} else if ($error == 62) {
    $msg_error = 'Se encontró un error al obtener un registro de predictivo (28)!!!';
} else if ($error == 7) {
    $msg_error = 'Tienes un registro agendado!!! Por favor tómalo o reagéndalo...<br>Solicitud: ' . $sol . '<br>Hora: ' . $hora . '<br>Fecha: ' . $fecha . '<br>Comentario: ' . '<font size="4" color="green">' . $coment . '</font>';
} else if ($error == 8) {
    $msg_error = 'Tu linea esta colgada, favor de dar click en OBTENER REGISTRO';
} else if ($error == 9) {
    $msg_error = 'Error de Conexión a Predictivo';
} else if ($error == 10) {
    $msg_error = $_REQUEST['mensaje_error'];
} else if ($error == 11) {
    $msg_error = $_REQUEST['mensaje_error'];
}
?>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=1" name="frm1">
    <p class="textbold">Agentes &gt; Mensaje</p>
    <p>&nbsp;</p>
<table class="cuestionario" border="1" width="1200px">
        <tr>
        <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
        <td>Mensaje :&nbsp;</td>
        <td class="message"><b><?=$msg_error?></b></td>
        </tr>
        <tr>
            <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3">
                <input type="hidden" name="u_persona" id ="u_persona">
                <input type="hidden" name="u_registro" id ="u_registro">
                <input type="hidden" name="trabajado" id ="trabajado">
                <?php 
                if($error == 7) {?>
                <input type="button" class= "custionario_boton" value="Obtener Agenda" id="ObtAgenda" onclick="Mostrar_agendado2(0,<?= $registro ?>,<?= $sol ?>, '<?= encripta(3) ?>', 1)"/>&nbsp;&nbsp;
                <?php }elseif($error == 10) { ?>
                <a class="boton_error" id="agenda" href="<?= $linkpath ?>modules.php?mod=agentes&op=index">Regresar al Registro</a> &nbsp;
            <a class="boton_error" id="agenda" href="<?= $linkpath ?>modules.php?mod=agentes&op=process_data&act=<?= encripta(8)?>">Abandonar el Registro</a>
        <?php  } ?>
            </td>
        </tr>
        <tr>
            <td colspan="3">&nbsp;</td>
            </tr>
        <tr>
    </table>
</form>
<?
layout_footer();
?>