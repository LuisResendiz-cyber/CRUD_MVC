//keyring 8HCff2UFW5qT4q4e sicall  1.100

// DSA
/* const HR_USER = 'mresendiz';
const HR_PASSWORD = 'desarroll0';
const HR_DATABASE = 'citi';
const HR_CONNECTIONSTRING = '172.20.1.89';
 */

// PRODUCCION
 const HR_USER = 'citi';
 const HR_PASSWORD = 'C1t120231mpul53';
 const HR_DATABASE = 'citi';
 const HR_CONNECTIONSTRING = 'localhost';

module.exports = {
  	objConfiguracion: {
        host: HR_CONNECTIONSTRING,
        user: HR_USER,
        password: HR_PASSWORD,
        database:HR_DATABASE,
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 2000
	}
};
