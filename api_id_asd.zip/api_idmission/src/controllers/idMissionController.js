



const dataInsert = async (req,res) => {

  res.json({ "status": "success", "message": "Impulse API works!" })

}

const massiveDataInsert = async (req,res) => {

  res.json({ "status": "success", "message": "Impulse API works!" })

}


module.exports={
  dataInsert,
  massiveDataInsert
}