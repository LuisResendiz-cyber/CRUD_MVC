const oracledb = require('oracledb');
const database = require('../services/database.js');


 
async function find(context) {
	const baseQuery = "BEGIN "+ context.schema +".XSP_INSERTAREGISTROREFERIDO(:P_User, :P_Customerid, :P_surveyid, :P_Tipo_registro_1, :P_Nombre1_1, :P_Nombre1_2 , :P_Paterno1, :P_Materno1, :P_Lada1_1, :P_Telefono1_1, :P_Tipo_registro_2, :P_Nombre2, :P_Nombre2_2, :P_Paterno2, :P_Materno2, :P_Lada2_1, :P_Telefono2_1,           :P_Tipo_registro_3, :P_Nombre3, :P_Nombre3_2, :P_Paterno3, :P_Materno3, :P_Lada3_1, :P_Telefono3_1); END;";          
	// const baseQuery = "BEGIN "+ context.schema +".XSP_INSERTAREGISTROREFERIDO(:P_User, :P_Customerid, :P_surveyid, :P_Tipo_registro_1, :P_Nombre1_1, :P_Nombre1_2 , :P_Paterno1, :P_Materno1, :P_Lada1_1, :P_Telefono1_1, :P_Tipo_registro_2, :P_Nombre2, :P_Nombre2_2, :P_Paterno2, :P_Materno2, :P_Lada2_1, :P_Telefono2_1,           :P_Tipo_registro_3, :P_Nombre3, :P_Nombre3_2, :P_Paterno3, :P_Materno3, :P_Lada3_1, :P_Telefono3_1, :keys); END;";                                                  
	let query = baseQuery;
	const binds = {};
        let result2 = {};
        console.log(context);
        if (!context.schema) {
                // if (!context.schema || context.keys == "") {
                console.log("Parametros incorrectos");
                result2.error_ = true;
                result2.mensaje = "Parametros Erroneos";
                return result2;
        } else {
                binds.P_User = context.s_usr_id;
                binds.P_Customerid = context.id_solicitud;
                binds.P_surveyid = context.id_producto;

                binds.P_Tipo_registro_1 = context.tipo_registro1;
                binds.P_Nombre1_1 = context.nombre1;
                binds.P_Nombre1_2 = context.nombre1_2;
                binds.P_Paterno1 = context.paterno1;
                binds.P_Materno1 = context.materno1;
                binds.P_Lada1_1 = context.lada1_1;
                binds.P_Telefono1_1 = context.telefono1_1;

                binds.P_Tipo_registro_2 = context.tipo_registro2;
                binds.P_Nombre2 = context.nombre2;
                binds.P_Nombre2_2 = context.nombre2_2;
                binds.P_Paterno2 = context.paterno2;
                binds.P_Materno2 = context.materno2;
                binds.P_Lada2_1 = context.lada2_1;
                binds.P_Telefono2_1 = context.telefono2_1;

                binds.P_Tipo_registro_3 = context.tipo_registro3;
                binds.P_Nombre3 = context.nombre3;
                binds.P_Nombre3_2 = context.nombre3_2;
                binds.P_Paterno3 = context.paterno3;
                binds.P_Materno3 = context.materno3;
                binds.P_Lada3_1 = context.lada3_1;
                binds.P_Telefono3_1 = context.telefono3_1;
                // binds.keys = context.keyrig;

                const result = await database.simpleExecute(query, binds);

                console.log(result);

                return result;
}            
}
 
module.exports.find = find;
