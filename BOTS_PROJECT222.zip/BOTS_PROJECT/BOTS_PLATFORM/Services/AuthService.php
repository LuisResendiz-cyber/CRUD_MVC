<?php

class AuthService extends ApiClient
{



    //USERS
    public function login(string $email, string $password)
    {
        return $this->request('POST', 'Users/Login', [
            'email_user' => $email,
            'passwordHash'   => $password
        ]);
    }

    public function getAccesModules(int $idUser = 0)
    {
        return $this->request('GET', 'Users/getModules', [
            'id_user' => $idUser,
        ]);
    }

    //ROLES
    public function getRoles()
    {
        return $this->request('GET', 'Users/getRoles');
    }

}
