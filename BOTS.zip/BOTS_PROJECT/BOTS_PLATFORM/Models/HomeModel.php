<?php 

	class HomeModel extends Mysql
	{
		public function __construct()
		{
			parent::__construct();
		}	
	}
 ?>