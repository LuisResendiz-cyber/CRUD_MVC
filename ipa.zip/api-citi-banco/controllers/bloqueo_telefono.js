const bloqueo_telefono = require('../db_apis/bloqueo_telefono.js');
const fetch = require('node-fetch'); 
const jwt = require('./token_manager'); 
const config  = require('../config/web-server'); 
async function post(req, res, next) {
  try {
    const context = req.body;
    
    const rows = await bloqueo_telefono.find(context);
    
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;