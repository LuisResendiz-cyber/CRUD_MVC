const axios = require("axios");
require("dotenv").config();

const TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_ID = process.env.PHONE_NUMBER_ID;
const WA_API_URL = `https://graph.facebook.com/v19.0/${PHONE_ID}/messages`;

const axiosInstance = axios.create({
  timeout: 15000,
  headers: {
    Authorization: `Bearer ${TOKEN}`,
    "Content-Type": "application/json",
  },
});

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function sendWhatsAppMessage(to, name, retries = 3, ollamamessage) {
  let payload = {};

  if (ollamamessage) {
    payload = {
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body: ollamamessage },
    };
  } else {
    payload = {
      messaging_product: "whatsapp",
      to,
      type: "interactive",
      interactive: {
        type: "button",
        body: {
          text: `¡Hola ${name}! 👋✨\n\n¿Buscas una tarjeta que trabaje para ti? 💳💼\nCon nuestra *Tarjeta Oro Plus* disfruta de:\n\n✨ Cashback del 5% en todas tus compras\n🛒 Beneficios exclusivos en tiendas\n✈️ Acceso a salas VIP en aeropuertos\n🔒 Seguridad avanzada para tus transacciones\n\n¿Te gustaría conocer más o solicitarla ahora mismo? 🚀`,
        },
        action: {
          buttons: [
            {
              type: "reply",
              reply: {
                id: "solicitar_tarjeta",
                title: "Solicitar tarjeta",
              },
            },
            {
              type: "reply",
              reply: {
                id: "mas_beneficios",
                title: "Ver beneficios",
              },
            },
            {
              type: "reply",
              reply: {
                id: "hablar_asesor",
                title: "Hablar con asesor",
              },
            },
          ],
        },
      },
    };
  }

  let attempt = 0;
  let lastErr;

  while (attempt <= retries) {
    try {
      const start = Date.now();
      const response = await axiosInstance.post(WA_API_URL, payload);
      console.log(`[OK] ${to} (${Date.now() - start}ms)`);
      return response.data;
    } catch (err) {
      lastErr = err;
      attempt++;

      const status = err.response?.status;
      if (attempt > retries || (status && status < 500 && status !== 429)) {
        throw err;
      }

      const wait = Math.min(2000 * 2 ** attempt, 15000) + Math.random() * 300;
      console.log(`[RETRY] ${to} intento ${attempt} en ${wait}ms`);
      await sleep(wait);
    }
  }

  throw lastErr;
}

module.exports = { sendWhatsAppMessage };
