import Client from "ssh2-sftp-client";
import path from "path";
import { fileURLToPath } from "url";
import fs from 'fs';
import { config } from 'dotenv';
import { saveLog } from "../controller/mysqlController.js";
import { createWriteStream } from 'fs';
import { pipeline } from 'stream/promises';

config();

const sftp = new Client();
const pathSftp = process.env.sftpPath;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const regex = /(WINBACK|CALLME|RASTREATOR|AUTOCCP)/; 
const excludeRegex = /prueba/i;

const publicFolderPath = path.join(
  __dirname,
  "..",
  "..",
  "src/public/tempLeads"
);

let isConnected = false;
const credentials = {
  host: process.env.sftpHost,
  username: process.env.sftpUser,
  password: process.env.sftpPass,
};

export const openConn = async () => {
  if (isConnected) {
    console.log("Ya hay una conexion SFTP activa.");
    return true; 
  }

  try {
    await sftp.connect(credentials);
    isConnected = true;
    console.log("Conexion SFTP activa.");
    return true;
  } catch (error) {
    console.log("Error al conectar:", error);
    return false;
  }
};

export const closeConn = async () => {
  if (!isConnected) {
    console.log("No hay conexión SFTP activa para cerrar.");
    return true; 
  }

  try {
    await sftp.end();
    isConnected = false;
    console.log("Conexion sftp cerrada");
    return true;
  } catch (error) {
    console.log("Error al cerrar la conexión:", error);
    return false;
  }
};
 

export const checkFiles = async () => {
  try {
    const files = await sftp.list(pathSftp + "sent");
    // const files = await sftp.list(pathSftp + "outbox"); //!Importante descomentar
    return files.some(
      (element) =>
        element.type == "-" &&
        element.name.endsWith(".csv") &&
        regex.test(element.name)
    );
    // return hasMatchingFile
  } catch (error) {
    console.error(error);
    return false;
  }
};



export const downloadFiles = async (option) => {
  const pathfolder = option == 1 ? pathSftp + "outbox" : pathSftp + "sent";

  let countFilesFind = 0
  try {
    
    const files = await sftp.list(pathfolder);
    const csvFiles = files.filter(
      ({ type, name }) => 
        type === "-" && 
        name.endsWith(".csv") && 
        regex.test(name) && 
        !excludeRegex.test(name)
    );
    // let batchFiles = csvFiles.slice(0,50)
    let batchFiles = csvFiles.slice(0,100)

    for (const { name, size } of batchFiles) {
        let remoteFilePath = `${pathfolder}/${name}`;
        const localFilePath = path.join(publicFolderPath, name);
        
        try {
          const writableStream = createWriteStream(localFilePath);
          await pipeline(
            sftp.get(remoteFilePath),
            writableStream
          );
          // console.log(`Archivo descargado---> ${name} -- ${size}`);
          countFilesFind ++
        } catch (downloadError) {
          console.error(`Error al descargar el archivo ${name}:`, downloadError.message);
          if (fs.existsSync(localFilePath)) {
            fs.unlinkSync(localFilePath);
          }
        }

      }
      console.log('Total de archivos descargados: ',countFilesFind);
    return countFilesFind;
  } catch (error) {
    console.error("Error general en downloadFiles:", error);
    return false;
  }
};


export const logDig = async (statusProcess, data) => {
  console.log(data);
  await saveLog('CRON',1,data) 
};
