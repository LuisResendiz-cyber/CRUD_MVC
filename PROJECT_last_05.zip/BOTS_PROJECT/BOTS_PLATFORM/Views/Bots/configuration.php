<?php 
    headerAdmin($data); 
    getModal('modalClientes',$data);
?>
  <main class="app-content">    
      <div class="app-title">
        <div>
            <h1><i class="fas fa-user-tag"></i> <?= $data['page_title'] ?>
                <?php if($_SESSION['permisosMod']['w']){ ?>
                <button class="btn btn-primary" type="button" onclick="openModal();" ><i class="fas fa-plus-circle"></i> Nuevo</button>
              <?php } ?>
            </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?= base_url(); ?>/clientes"><?= $data['page_title'] ?></a></li>
        </ul>
      </div>
        <div class="row">
            <div class="col-md-12">
              <div class="tile">
                <div class="tile-body">
                  <div class="table-responsive">
                  <div class="container-fluid" x-data="{ section: 'conversation' }">

<!-- Header -->
<div class="bg-white rounded-2xl shadow-sm p-5 mb-4 flex items-center justify-between">
    <div>
        <h3 class="text-xl font-semibold flex items-center gap-2">
            🤖 <?= $data['bot']['nombre'] ?? 'Bot' ?>
            <span class="px-3 py-1 text-xs rounded-full bg-green-100 text-green-700">
                Activo · IA
            </span>
        </h3>
        <p class="text-sm text-gray-500">
            ID <?= $data['bot']['id'] ?> · Configuración avanzada del chatbot
        </p>
    </div>

    <a href="<?= base_url(); ?>/bots"
       class="btn btn-outline-secondary">
        ← Volver
    </a>
</div>

<div class="row">

    <!-- Sidebar -->
    <div class="col-lg-3 mb-3">
        <div class="bg-white rounded-2xl shadow-sm p-3 space-y-1">

            <?php
            $menu = [
                'conversation' => ['Conversación', 'message-circle'],
                'personality'  => ['Personalidad', 'brain'],
                'training'     => ['Entrenamiento', 'database'],
                'appearance'   => ['Apariencia', 'palette'],
                'integrations' => ['Integraciones', 'plug'],
                'channels'     => ['Canales', 'share-2'],
            ];
            ?>

            <?php foreach ($menu as $key => [$label, $icon]): ?>
                <button
                    @click="section='<?= $key ?>'"
                    :class="section === '<?= $key ?>'
                        ? 'bg-blue-50 text-blue-600'
                        : 'hover:bg-gray-100 text-gray-700'"
                    class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition">

                    <i data-lucide="<?= $icon ?>" class="w-4 h-4"></i>
                    <?= $label ?>
                </button>
            <?php endforeach; ?>

        </div>
    </div>

    <!-- Content -->
    <div class="col-lg-9">
        <div class="bg-white rounded-2xl shadow-sm p-5 min-h-[400px]">

            <!-- Conversación -->
            <template x-if="section === 'conversation'">
                <div>
                    <h4 class="text-lg font-semibold mb-2">Conversación</h4>
                    <p class="text-gray-500 mb-4">
                        Define el flujo de diálogo del bot.
                    </p>

                    <div class="grid md:grid-cols-2 gap-4">
                        <div class="p-4 border rounded-xl">
                            <h6 class="font-medium">Mensaje inicial</h6>
                            <p class="text-sm text-gray-500">
                                Texto con el que el bot inicia la conversación.
                            </p>
                        </div>

                        <div class="p-4 border rounded-xl">
                            <h6 class="font-medium">Flujos</h6>
                            <p class="text-sm text-gray-500">
                                Condiciones y respuestas automáticas.
                            </p>
                        </div>
                    </div>
                </div>
            </template>

            <!-- Personalidad -->
            <template x-if="section === 'personality'">
                <div>
                    <h4 class="text-lg font-semibold mb-2">Personalidad</h4>
                    <p class="text-gray-500">
                        Ajusta el tono, formalidad y estilo del bot.
                    </p>
                </div>
            </template>

            <!-- Entrenamiento -->
            <template x-if="section === 'training'">
                <div>
                    <h4 class="text-lg font-semibold mb-2">Entrenamiento</h4>
                    <p class="text-gray-500">
                        PDFs, preguntas frecuentes y base de conocimiento.
                    </p>
                </div>
            </template>

        </div>
    </div>

</div>
</div>

                  </div>
                </div>
              </div>
            </div>
        </div>
    </main>
<?php footerAdmin($data); ?>
    