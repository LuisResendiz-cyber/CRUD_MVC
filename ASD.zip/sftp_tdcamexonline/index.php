<?php
header('Content-Type: text/html; charset=UTF-8');
echo '<link rel="stylesheet" type="text/css" href="includes/style.css">';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "includes/openConnection.php";
include "includes/functions.php";
include "includes/read_data.php";
require 'includes/autoload.php';
require 'includes/funcion_dsa_prueba.php';


// $databaseConnection = new DatabaseConnection('development', false);  
$databaseConnection = new DatabaseConnection();
$db = $databaseConnection->getConnection();

$logger = new Logger($db);


// // // ----------------------------esto es para hacer pruebas
// $logger->log('CONECTADO AL SERVIDOR',0,1);
// sleep(1);

// start($db);

// die();
// // // ----------------------------esto es para hacer pruebas

use phpseclib\Net\SFTP;

$ftp_user_name = 'amex';
$ftp_user_pass = 'Tyn$t&/(q98Flv7#';
$ftp_server = '189.211.174.149';
$port = '9144';

$sftp = new SFTP($ftp_server, $port);
/*if (!$sftp->login($ftp_user_name, $ftp_user_pass)) {
  exit('Login Failed');
} else {
   $logger->log('CONECTADO AL SERVIDOR', 0, 1);
  sleep(1);
  
  $sftp->chdir('amex');
  $archivos = array_diff($sftp->nlist(), array('.', '..'));
  if (sizeof($archivos) > 0) {
    foreach ($archivos as $key => $value) {
      if (strpos($value, '_SBS') == false) {

        if ($sftp->is_file($value)) {
          $sftp->get($value, 'leads_Temporal/' . $value);
          $sftp->rename($value, 'PROCESADOS/' . $value);
        }
      }
    }

    $dirLocalFiles = scandir('leads_Temporal');
    $localFiles = array_diff($dirLocalFiles, array('.', '..'));
    if (count($localFiles) > 0) {
      $logger->log('INICIA CARGA AUTOMATICA', 0, 1);
      sleep(1);
      start($db);
    } else {
      $logger->log('SERVIDOR DE ONLINE SIN DATOS', 0, 1);
      die();
    }
  } else {
    $logger->log('SERVIDOR DE ONLINE SIN DATOS', 0, 1);
    die();
  } */

//PARA DESARROLLO
$localDir = 'leads_Temporal';
$processedDir = 'leads_Respaldo';

// Crear instancia del manejador de archivos locales
$fileHandler = new LocalFileHandler($localDir);

// Simulación del flujo de trabajo
$archivos = array_diff($fileHandler->nlist(), array('.', '..'));

//var_dump($archivos);
//die();

if (sizeof($archivos) > 0) {
  
    foreach ($archivos as $value) {

        if (strpos($value, '_SBS') === false) {
            if ($fileHandler->is_file($value)) {
                $fileHandler->get($value, $processedDir . '/' . $value);
                //echo $value;
                //die();

                $fileHandler->rename($value, 'PROCESADOS/' . $value);
            }
        }
    }

    $dirLocalFiles = scandir($processedDir);
    $localFiles = array_diff($dirLocalFiles, array('.', '..'));
    if (count($localFiles) > 0) {
        $logger->log('INICIA CARGA AUTOMATICA', 0, 1);
        sleep(1);
        start($db);
    } else {
        $logger->log('DIRECTORIO LOCAL SIN DATOS', 0, 1);
        die();
    }
} else {
    $logger->log('DIRECTORIO LOCAL SIN DATOS', 0, 1);
    die();
}

//}
