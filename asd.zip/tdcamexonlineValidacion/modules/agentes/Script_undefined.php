<html xmlns="http://www.w3.org/1999/xhtml">
    <head profile="http://dublincore.org/documents/dcmi-terms/">
        <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=iso-8859-1"/>
        <title>Script Bancomer</title>
        <style type="text/css">
            body, tbody {
                font-family: Verdana, Tahoma, Arial, sans-serif;
                font-size: 12px
            }
            .title {
                background: Navy;
                color: White;
            }
        </style>
    </head>
    <body>
    </body>
</html>
