<?php

$url_status_pred = "http://172.20.1.10/click2dial/invex/getemployeestatus.php?employeeid=2";

$ch = curl_init();
// set URL and other appropriate options
curl_setopt($ch, CURLOPT_URL, $url_status_pred);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$status_pred = curl_exec($ch);

curl_close($ch);

echo "CURL Status: $status_pred<br />\r\n";

$status_pred = file_get_contents($url_status_pred);

echo "FGC Status: $status_pred<br />\r\n";
