from fastapi import FastAPI
from app.core.database import engine, Base

# Importar modelos (importante para que SQLAlchemy registre las tablas)
import app.modules.calls.models  

# Importar router
from app.modules.calls.router import router as calls_router

app = FastAPI(title="SpeechLens API")


@app.on_event("startup")
def startup():
    print("🚀 Iniciando aplicación...")
    Base.metadata.create_all(bind=engine)
    print("✅ Tablas creadas correctamente")


@app.get("/")
def root():
    return {"message": "SpeechLens API running"}


# 🔥 AQUÍ ESTABA EL PROBLEMA
app.include_router(calls_router, prefix="/calls", tags=["Calls"])
