const oracledb = require('oracledb');
const database = require('../services/database.js');
 

 
async function find(context) {

	const baseQuery = "BEGIN CSP_ADDATTEMPT(:usr_id); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.usr_id = context.s_usr_id;

  const result = await database.simpleExecute(query, binds);
  // console.log(result); 
  return result;
}
 
module.exports.find = find;