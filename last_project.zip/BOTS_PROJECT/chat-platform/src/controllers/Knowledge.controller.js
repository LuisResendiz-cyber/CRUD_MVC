const BotEngine = require("../services/botEngine.service");


const ChatResolver = {
  resolve: async ({ session, message }) => {

    if (session.status !== "bot") return null;

    const botId = session.id_bot;
    
    const aiResponse =  await BotEngine.process({
      botId,
      message,
      session
    });

    return aiResponse;

  }
};

module.exports = ChatResolver;
