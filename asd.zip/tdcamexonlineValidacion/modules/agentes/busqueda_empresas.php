<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Solicitud");

$id_solicitud = get_session_varname('id_solicitud');

layout_menu($db, "");

$query = "BEGIN SPS_ESTADO(:rc); END;";
$rsEstados = $db->ExecuteCursor($query, 'rc');
$estado = 'AS';
if (isset($_POST['estado'])) {
    $estado = $_POST['estado'];
}

$query = "BEGIN SPS_MUNICIPIO(:v_estado, :rc); END;";
$stmt = $db->PrepareSP($query);
$db->InParameter($stmt, $estado, 'v_estado');
$rsMunicipios = $db->ExecuteCursor($stmt, 'rc');
?>
<p class="textbold">Agentes &gt; B&uacute;squeda de empresas</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=resultado_empresas" name="frm1">
    <table border="0">
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey">Solicitud</td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td class="textleft"><b>Estado:&nbsp;</b></td>
            <td class="label"><?php echo $rsEstados->GetMenu2('estado', $estado, false, false, 0, 'id="estado" onchange="ObtenerMunicipios()"'); ?></td>
        </tr>
        <tr>
            <td class="textleft"><b>Municipio:&nbsp;</b></td>
            <td class="label"><?php echo $rsMunicipios->GetMenu2('municipio', '', true, false, 0, 'id="municipio"'); ?></td>
        </tr>
        <tr>
            <td class="textleft"><b>Nombre (parcial o total):&nbsp;</b></td>
            <td class="label"><input type="text" name="empresa" size="40" id="empresa" value="" ></td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" value="Cancelar" onclick="window.location='index2.php'"/>&nbsp;&nbsp;
                <input type="submit" name="cmdBuscar" id="cmdBuscar" value="Buscar">
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>