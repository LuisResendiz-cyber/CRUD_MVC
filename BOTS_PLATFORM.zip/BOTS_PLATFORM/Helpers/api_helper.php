<?php
/**
 * Helpers para conexión a API Node.js
 */

if (!function_exists('api_request')) {
    /**
     * Realiza una petición a la API
     */
    function api_request($method, $endpoint, $data = null, $token = null) {
        // Si no estamos usando API, retornar false
        if (!USE_API) {
            return ['error' => 'API deshabilitada'];
        }
        
        $url = API_NODE_URL . $endpoint;

        echo $url .  "<br>";
        echo $method .  "<br>";

        
        // Configurar headers
        $headers = [
            'Content-Type: application/json'
        ];
        
        if ($token) {
            $headers[] = 'Authorization: Bearer ' . $token;
        }
        
        // Inicializar cURL
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Timeout de 10 segundos
        
        // Configurar según método
        switch (strtoupper($method)) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
                
            case 'PUT':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
                
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
                
            default: // GET
                if ($data) {
                    $url .= '?' . http_build_query($data);
                    curl_setopt($ch, CURLOPT_URL, $url);
                }
        }
        
        // Ejecutar
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        
        curl_close($ch);
        
        // Verificar errores de cURL
        if ($curl_error) {
            //log_api_error("cURL Error: " . $curl_error);
            var_dump($curl_error);
            return [
                'success' => false,
                'error' => 'Error de conexión con la API',
                'curl_error' => $curl_error,
                'code' => 0
            ];
        }
        
        // Decodificar respuesta
        $decoded = json_decode($response, true);
        
        // Si no se pudo decodificar JSON
        if (json_last_error() !== JSON_ERROR_NONE) {
            log_api_error("JSON Decode Error: " . json_last_error_msg() . " - Response: " . $response);
            return [
                'success' => false,
                'error' => 'Error decodificando respuesta de la API',
                'raw_response' => $response,
                'code' => $http_code
            ];
        }
        
        return [
            'success' => ($http_code >= 200 && $http_code < 300),
            'code' => $http_code,
            'data' => $decoded,
            'raw' => $response
        ];
    }
}

if (!function_exists('api_get')) {
    function api_get($endpoint, $params = [], $token = null) {
        return api_request('GET', $endpoint, $params, $token);
    }
}

if (!function_exists('api_post')) {
    
    function api_post($endpoint, $data = [], $token = null) {
        return api_request('POST', $endpoint, $data, $token);
    }
}

if (!function_exists('api_put')) {
    function api_put($endpoint, $data = [], $token = null) {
        return api_request('PUT', $endpoint, $data, $token);
    }
}

if (!function_exists('api_delete')) {
    function api_delete($endpoint, $token = null) {
        return api_request('DELETE', $endpoint, null, $token);
    }
}


if (!function_exists('get_api_token')) {
    /**
     * Obtiene el token de API de la sesión
     */
    function get_api_token() {
        // Si usas sesiones PHP
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        return $_SESSION['api_token'] ?? null;
    }
}