const geminiProvider = require("./gemini.provider");
const llamaProvider = require("./llama.provider");


const getProvider = (modelId = null) => {

  if (!modelId) {
    throw new Error("No se especificó modelo LLM en configuración del bot");
  }


  switch (modelId.toLowerCase()) {

    case "gemini":
      return geminiProvider;

    case "llama":
      return llamaProvider;

    case "ollama":
      return ollamaProvider;

    default:
      throw new Error(`Modelo LLM no soportado: ${modelId}`);
  }
};

module.exports = { getProvider };
