
    <link rel="stylesheet" href="<?php echo constant('URL'); ?>public/css/default.css">
    <div id="header">
        <ul>
            <li><a href="<?php echo constant('URL'); ?>">Home</a></li>
        </ul>
    </div>