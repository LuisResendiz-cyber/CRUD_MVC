<?php
# Layout File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize("mesa_control","Layout");
layout_menu($db, "");

$fecha_del = $_REQUEST['fecha_del'];
$fecha_al = $_REQUEST['fecha_al'];
$etapa_layout = (strlen($_REQUEST['etapa_layout']) > 0?$_REQUEST['etapa_layout']:1);

$registros = get_layout_clientes($fecha_del, $fecha_al, $etapa_layout, $db);
//print_r($registros->fields);
?>
	<h4>Layout de clientes</h4>
	<hr>
		<?	
        while(!$registros->EOF) {
            echo $registros->fields("ID_SOLICITUD").'|';
            echo $registros->fields("TDC").'|';
            echo $registros->fields("NOMBRE_COMPLETO").'|';
            echo $registros->fields("CALLE").' '.$registros->fields("NUM_EXT").' '.$registros->fields("NUM_INT").'|';
            echo $registros->fields("COLONIA").'|';
            echo $registros->fields("D_MNPIO").'|';
            echo $registros->fields("D_ESTADO").'|';
            echo $registros->fields("D_CODIGO").'|';
            echo $registros->fields("ITARJETA_ADI").'|';
            echo $registros->fields("ITDC1").' '.$registros->fields("ITDC2").' '.$registros->fields("ITDC3").'|';
            echo $registros->fields("FOLIO").'|';
            echo $registros->fields("OBSERVACIONES").'|';
            echo $registros->fields("TIPO").'|';
            //echo ($registros->fields("TIPO") == 1 ?'IN|' :'OUT|');
            echo '<br>';
            $registros->MoveNext();
        }
		?>
	<br>
	<input type="button" value="Cancelar" onclick="Atras()">
	<br>
<?
layout_footer();
?>