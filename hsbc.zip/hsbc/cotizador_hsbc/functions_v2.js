import {
  rates,
  objData,
  segmentos,
  descuentos,
  paymentSurcharges,
  objFuneralExpenses,
  objRate,
  derechoPoliza,
  medicalAssitance,
} from "./quotationObjects.js";

export const generateTable = (tableData) => {
  let tableHTML = `
      <thead>
        <tr class="table-danger">
          ${tableData.headers.map((header) => `<th>${header}</th>`).join("")}
        </tr>
      </thead>
      <tbody>
        ${tableData.rows
      .map(
        (row, rowIndex) => `
          <tr>
            ${row
            .map(
              (cell, colIndex) => `
              <td class="${tableData.headers[0]}-${rowIndex}-${colIndex}">${cell}</td>
            `
            )
            .join("")}
          </tr>
        `
      )
      .join("")}
      </tbody>
  `;
  return tableHTML;
};

export const saveData = (inputs) => {
  const elements = Array.from(inputs).map(({ id, value, checked }) => ({
    id,
    value,
    checked,
  }));

  elements.forEach(({ id, value, checked }) => {
    if (id === "D5") {
      //* Fecha de la cotización
      objData[id] = value;
    }
    if (id === "D6") {
      //* Suma Asegurada
      objData[id] = value;

      if (objData.O3 == 1) {

        if (countInRange(objData.CUSTOMER, 14, 22, "D") > 1) {
          objData["D7"] = 0; //S.A. AGFU
          objData["O4"] = 0; //O4
          document.getElementById("D7").value = "Sólo para pólizas Individuales";
        } else {
          objData["D7"] = min(objData.D6); //S.A. AGFU
          objData["O4"] = 1; //O4
          document.getElementById("D7").value = min(objData.D6);
        }
      } else {
        objData["D7"] = 0; //S.A. AGFU
        objData["O4"] = 0; //O4    0 False / 1 TRUE
        document.getElementById("D7").value = "No incluida";
      }
    }

    if (id === "D8") {
      //* Forma de Pago
      objData[id] = value;
      objData["R5"] = paymentSurcharges[value].value;
    }
    if (id === "D9") {
      //* Segmento
      objData[id] = value;
    }
    if (id === "D10") {
      //* Descuentos
      objData[id] = value;

      if (value == "Segmento") {
        objData["E10"] = segmentos[objData.D9];
        document.getElementById("E10").value = segmentos[objData.D9];
      } else {
        objData["E10"] = descuentos[value];
        document.getElementById("E10").value = descuentos[value];
      }
    }
    if (id === "funeralExpenses") {
      //* Boton Gastos funerarios
      objData[id] = checked ? 1 : 0;
    }
    calculateTblHea();
    calculateTblAgfu();
    calculateTblAsim();
    calculateTblAcsel()
  });

  // console.log("objData-->", objData);
  // document.getElementById("log").innerHTML = JSON.stringify(objData);
};

function calculateAge(birthDate, fechaReferencia) {
  const nacimiento = convertDate(birthDate); // Convertimos el string de fecha
  // console.log(nacimiento)
  if (!nacimiento) return "";

  const hoy = convertDate(fechaReferencia);
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mes = hoy.getMonth() - nacimiento.getMonth();
  if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
    edad--;
  }
  return edad;
}

function convertDate(fechaStr) {
  const [dia, mes, año] = fechaStr.split("/").map(Number);
  if (!dia || !mes || !año) return null;
  return new Date(año, mes - 1, dia);
}

export const quotationDate = () => {
  const actDate = new Date();
  const day = String(actDate.getDate()).padStart(2, "0");
  const month = String(actDate.getMonth() + 1).padStart(2, "0");
  const year = actDate.getFullYear();
  const formattedDate = `${day}/${month}/${year}`;
  objData["D5"] = formattedDate; //Se carga desde aqui para que no fallen las funciones
  document.getElementById("D5").value = formattedDate;
};

const countInRange = (obj, start, end, prefix) => {
  const keysInRange = Array.from(
    { length: end - start + 1 },
    (_, i) => `${prefix}${start + i}`
  );

  const count = keysInRange.filter(
    (key) => key in obj && obj[key] !== 0
  ).length;

  return count;
};

const min = (D6) => Math.min(rates.Z4, rates.Y4 * D6);

const findSpecificClass = (element, prefix) => {
  if (!element) return null; // Validación por si el elemento es null o undefined
  return [...element.classList].find((cls) => cls.startsWith(prefix));
};

function calculateAGFU(gender, age) {
  if (objFuneralExpenses[age]) {
    return gender == "M"
      ? objFuneralExpenses[age].Male
      : objFuneralExpenses[age].Female;
  } else {
    return "N/A";
  }
}

function calculateRate(gender, age) {
  // console.log(gender,'--------',age)
  if (objRate[age]) {
    return gender == "M" ? objRate[age].Male : objRate[age].Female;
  } else {
    return "N/A";
  }
}

export const updateCustomerTable = (event) => {
  const fila = event.target.closest("tr");
  const birthDate = fila.querySelector(".date-of-birth");
  const gender = fila.querySelector(".gender")?.value;
  const cellAge = fila.querySelector(".birth");
  const cellAgfu = fila.querySelector(".agfu");
  const cellRate = fila.querySelector(".rate");

  const specificClassBirthDate = findSpecificClass(birthDate, "D");
  const specificClassCellAge = findSpecificClass(cellAge, "F");
  const specificClassCellAgfu = findSpecificClass(cellAgfu, "G");
  const specificClassCellRate = findSpecificClass(cellRate, "H");
 



  if (birthDate?.value) {
    const age = calculateAge(birthDate.value, objData.D5);

    if (specificClassBirthDate == "D14") {
      if (age < 18) {
        cellAge.value = "Menor a 18 años";
      } else if (age > 65) {
        cellAge.value = "Mayor a 65 años";
      } else {
        const agfu = calculateAGFU(gender, age);
        const rate = calculateRate(gender, age);
        cellAge.value = age;
        cellAgfu.value = agfu;
        cellRate.value = rate;

        objData.CUSTOMER[specificClassBirthDate] = birthDate.value;
        objData.CUSTOMER[specificClassCellAge] = age;
        objData.CUSTOMER[specificClassCellAgfu] = agfu;
        objData.CUSTOMER[specificClassCellRate] = rate;
        objData["insuredIncluded"] = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
        document.getElementById("insuredIncluded").value = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
      }
    } //specificClassBirthDate
    else if (specificClassBirthDate == "D15") {
      // if (age < 3) {
      //   cellAge.value = "Menor a 3 meses";
      // } 
      if (age > 65) {
        cellAge.value = "Mayor a 65 años";
      } else {
        const agfu = calculateAGFU(gender, age);
        const rate = calculateRate(gender, age);
        cellAge.value = age;
        cellAgfu.value = agfu;
        cellRate.value = rate;

        objData.CUSTOMER[specificClassBirthDate] = birthDate.value;
        objData.CUSTOMER[specificClassCellAge] = age;
        objData.CUSTOMER[specificClassCellAgfu] = agfu;
        objData.CUSTOMER[specificClassCellRate] = rate;
        objData["insuredIncluded"] = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
        document.getElementById("insuredIncluded").value = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
      }
    } else {
      if (age > 25) {
        cellAge.value = "Mayor a 25 años";
      } else {
        const agfu = calculateAGFU(gender, age);
        const rate = calculateRate(gender, age);
        cellAge.value = age;
        cellAgfu.value = agfu;
        cellRate.value = rate;

        objData.CUSTOMER[specificClassBirthDate] = birthDate.value;
        objData.CUSTOMER[specificClassCellAge] = age;
        objData.CUSTOMER[specificClassCellAgfu] = agfu;
        objData.CUSTOMER[specificClassCellRate] = rate;
        objData["insuredIncluded"] = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
        document.getElementById("insuredIncluded").value = countInRange(
          objData.CUSTOMER,
          14,
          22,
          "H"
        );
      }
    }
  } else {
    cellAge.value = "";
    cellAgfu.value = "";
    cellRate.value = "";

    objData.CUSTOMER[specificClassBirthDate] = 0;
    objData.CUSTOMER[specificClassCellAge] = 0;
    objData.CUSTOMER[specificClassCellAgfu] = 0;
    objData.CUSTOMER[specificClassCellRate] = 0;

    objData["insuredIncluded"] = 0;
    document.getElementById("insuredIncluded").value = 0;
  }

  calculateTblHea();
  calculateTblAgfu();
  calculateTblAsim();
  calculateTblAcsel()
};

//!Estas funciones son muy importantes
function generateKeys(prefix, start, count) {
  return Array.from({ length: count }, (_, i) => `${prefix}${start + i}`);
}

function generateNestedKeys(prefix, groups, itemsPerGroup) {
  return Array.from({ length: groups }, (_, group) =>
    Array.from(
      { length: itemsPerGroup },
      (_, i) => `${prefix}-${group}-${i + 1}`
    )
  );
}
const updateCell = (cell, value) => {
  const formattedValue = parseFloat(value.toFixed(2));
  cell.textContent = `$${formattedValue}`;
  // cell.style.backgroundColor = "#ff6366";
  objData.HEA[cell.className] = value;
};

//?-----------------------  H-E-A  --------------------------------------------------------------------
const calculateTblHea = () => {
  const calculateSumHea = (prefix, groupIndex) => {
    const dataHeaKeys = generateNestedKeys("HEA", 7, 9);
    const sum = dataHeaKeys[groupIndex]
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`) // Exclude key ending in 10
      .reduce((acc, key) => acc + (objData.HEA[key] ?? 0), 0);
    // return Math.round(sum * 100) / 100;
    return sum 
  };

  const calTotalNetPremium = (index, cell) => {
    const rowOneKeys = generateKeys("H", 15, 9);
    const key = index === 0 ? "H14" : rowOneKeys[index - 1];
    const value = ((objData.CUSTOMER?.[key] ?? 0) / 1000) * objData.D6;
    updateCell(cell, value);
  };

  const calSpecialDiscount = (index, cell) => {
    const baseValue = objData.HEA[`HEA-0-${index + 1}`] ?? 0;
    const value = baseValue * objData.E10;
    updateCell(cell, value);
  };

  const calculateRPF = (index, cell) => {
    const E25 = objData.HEA[`HEA-0-${index + 1}`] ?? 0;
    const E26 = objData.HEA[`HEA-1-${index + 1}`] ?? 0;
    const value = (E25 - E26) * objData.R5;

    updateCell(cell, value);
  };

  const calDerPol = (index, cell) => {
    const value = 0;
    updateCell(cell, value);
  };

  const calIva = (index, cell) => {
    const E25 = objData.HEA[`HEA-0-${index + 1}`] ?? 0;
    const E26 = objData.HEA[`HEA-1-${index + 1}`] ?? 0;
    const E27 = objData.HEA[`HEA-2-${index + 1}`] ?? 0;
    const E28 = objData.HEA[`HEA-3-${index + 1}`] ?? 0;

    const value = (E25 - E26 + E27 + E28) * paymentSurcharges.Iva.value; //0.16

    updateCell(cell, value);
  };

  const calTotalPremium = (index, cell) => {
    const E25 = objData.HEA[`HEA-0-${index + 1}`] ?? 0;
    const E26 = objData.HEA[`HEA-1-${index + 1}`] ?? 0;
    const E27 = objData.HEA[`HEA-2-${index + 1}`] ?? 0;
    const E28 = objData.HEA[`HEA-3-${index + 1}`] ?? 0;
    const E29 = objData.HEA[`HEA-4-${index + 1}`] ?? 0;
    const value = E25 - E26 + E27 + E28 + E29;
    updateCell(cell, value);

    // =(E24-E25+E26+E27+E28)
  };

  const calPremiumSfp = (index, cell) => {
    const E30 = objData.HEA[`HEA-5-${index + 1}`] ?? 0;
    const value = E30 / paymentSurcharges[objData.D8]?.colS;
    updateCell(cell, value);
  };

  Array.from(tbl_hea.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      if (rowIndex === 1) {
        //Prima Neta Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calTotalNetPremium(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-0-", 0);
          updateCell(cell, sum);
        }
      }

      if (rowIndex === 2) {
        //Descuento Especial
        if (cellIndex >= 1 && cellIndex < 10) {
          calSpecialDiscount(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-1-", 1);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 3) {
        //R.P.F.
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRPF(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-2-", 2);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 4) {
        //Derecho Póliza
        if (cellIndex === 1) {
          const val = derechoPoliza;
          updateCell(cell, val);
        }

        if (cellIndex > 1 && cellIndex < 10) {
          calDerPol(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-3-", 3);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 5) {
        //IVA
        if (cellIndex >= 1 && cellIndex < 10) {
          calIva(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-4-", 4);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 6) {
        //Prima Total
        if (cellIndex >= 1 && cellIndex < 10) {
          calTotalPremium(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-5-", 5);
          updateCell(cell, sum);
        }
      }
      if (rowIndex === 7) {
        //Prima SFP
        if (cellIndex >= 1 && cellIndex < 10) {
          calPremiumSfp(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumHea("HEA-6-", 6);
          updateCell(cell, sum);
        }
      }
    });
  });
};

//?-----------------------  A-G-F-U  --------------------------------------------------------------------
const calculateTblAgfu = () => {
  const calculateSumAgfu = (prefix, groupIndex) => {
    const dataHeaKeys = generateNestedKeys("AGFU", 7, 9);
    const sum = dataHeaKeys[groupIndex]
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`)
      .reduce((acc, key) => acc + (objData.HEA[key] ?? 0), 0);
    // return Math.round(sum * 100) / 100;
    return sum
  };

  const calpremiumCoverage = (index, cell) => {
    let value;
    if (objData.O4 == 1) {
      const rowOneKeys = generateKeys("G", 15, 9);
      const key = index === 0 ? "G14" : rowOneKeys[index - 1];

      value = ((objData.CUSTOMER?.[key] ?? 0) * objData.D7) / 1000;
    } else {
      value = 0;
    }
    updateCell(cell, value);
  };

  const calculateRPF = (index, cell) => {
    const E34 = objData.HEA[`AGFU-0-${index + 1}`] ?? 0;
    const E35 = objData.HEA[`AGFU-1-${index + 1}`] ?? 0;
    const value = (E34 - E35) * objData.R5;

    updateCell(cell, value);
  };

  const calSpecialDiscount = (index, cell) => {
    const baseValue = objData.HEA[`AGFU-0-${index + 1}`] ?? 0;
    const value = baseValue * objData.E10;
    updateCell(cell, value);
  };

  const calTotalPremium = (index, cell) => {
    const E34 = objData.HEA[`AGFU-0-${index + 1}`] ?? 0;
    const E35 = objData.HEA[`AGFU-1-${index + 1}`] ?? 0;
    const E36 = objData.HEA[`AGFU-2-${index + 1}`] ?? 0;

    const value = E34 + E35 + E36;
    updateCell(cell, value);
  };

  const calPremiumSfp = (index, cell) => {
    const E37 = objData.HEA[`AGFU-3-${index + 1}`] ?? 0;
    const value = E37 / paymentSurcharges[objData.D8]?.colS;
    updateCell(cell, value);
  };

  Array.from(tbl_agfu.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      //------------------------------------ Prima Cobertura      ----------------------------------------
      if (rowIndex === 1) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calpremiumCoverage(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("AGFU-0-", 0);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ Descuento Especial      ----------------------------------------
      if (rowIndex === 2) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calSpecialDiscount(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("AGFU-1-", 1);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ R.P.F.      ----------------------------------------
      if (rowIndex === 3) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRPF(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("AGFU-2-", 2);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ Prima Total ----------------------------------------
      if (rowIndex === 4) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calTotalPremium(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("AGFU-3-", 3);
          updateCell(cell, sum);
        }
      }

      //------------------------------------ Prima SFP ----------------------------------------
      if (rowIndex === 5) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calPremiumSfp(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("AGFU-4-", 4);
          updateCell(cell, sum);
        }
      }
    });
  });
};

//?-----------------------  A - S- I - M  --------------------------------------------------------------------
const calculateTblAsim = () => {
  const calculateSumAgfu = (prefix, groupIndex) => {
    const dataHeaKeys = generateNestedKeys("ASIM", 7, 9);
    const sum = dataHeaKeys[groupIndex]
      .filter((key) => key.startsWith(prefix) && key !== `${prefix}10`)
      .reduce((acc, key) => acc + (objData.HEA[key] ?? 0), 0);
    // return Math.round(sum * 100) / 100;
    return sum
  };

  const calpremiumCoverage = (index, cell) => {
    let value;
    if (objData.O1 == 1) {
      const rowOneKeys = generateKeys("H", 15, 9);
      // console.log(rowOneKeys)
      const key = index === 0 ? "H14" : rowOneKeys[index - 1];
      // console.log('key-->',objData.CUSTOMER?.[key])
      // value = ((objData.CUSTOMER?.[key] ?? 0) * objData.D7) / 1000;
      if (objData.CUSTOMER[key]) {
        value = medicalAssitance;
      } else {
        value = 0;
      }
    } else {
      value = 0;
    }
    updateCell(cell, value);
  };
  const calSpecialDiscount = (index, cell) => {
    const baseValue = objData.HEA[`ASIM-0-${index + 1}`] ?? 0;
    const value = baseValue * objData.E10;
    updateCell(cell, value);
  };

  const calculateRPF = (index, cell) => {
    const E41 = objData.HEA[`ASIM-0-${index + 1}`] ?? 0;
    const E42 = objData.HEA[`ASIM-1-${index + 1}`] ?? 0;
    const value = (E41 - E42) * objData.R5;

    updateCell(cell, value);
  };

  const calIva = (index, cell) => {
    const E41 = objData.HEA[`ASIM-0-${index + 1}`] ?? 0;
    const E42 = objData.HEA[`ASIM-1-${index + 1}`] ?? 0;
    const E43 = objData.HEA[`ASIM-2-${index + 1}`] ?? 0;


    const value = (E41 - E42 + E43) * paymentSurcharges.Iva.value; //0.16

    updateCell(cell, value);
  };

  const calTotalPremium = (index, cell) => {
    const E41 = objData.HEA[`ASIM-0-${index + 1}`] ?? 0;
    const E42 = objData.HEA[`ASIM-1-${index + 1}`] ?? 0;
    const E43 = objData.HEA[`ASIM-2-${index + 1}`] ?? 0;
    const E44 = objData.HEA[`ASIM-3-${index + 1}`] ?? 0;

    const value = E41 + E42 + E43 + E44
    updateCell(cell, value);
  };

  const calPremiumSfp = (index, cell) => {
    const E45 = objData.HEA[`ASIM-4-${index + 1}`] ?? 0;
    const value = E45 / paymentSurcharges[objData.D8]?.colS;
    updateCell(cell, value);
  };

  Array.from(tbl_asim.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      //------------------------------------ Prima Asistencia      ----------------------------------------
      if (rowIndex === 1) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calpremiumCoverage(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-0-", 0);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ Descuento Especial      ----------------------------------------
      if (rowIndex === 2) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calSpecialDiscount(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-1-", 1);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ R.P.F.    ----------------------------------------
      if (rowIndex === 3) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calculateRPF(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-2-", 2);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ IVA ----------------------------------------
      if (rowIndex === 4) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calIva(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-3-", 3);
          updateCell(cell, sum);
        }
      }
      //------------------------------------ Prima Total ----------------------------------------
      if (rowIndex === 5) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calTotalPremium(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-4-", 4);
          updateCell(cell, sum);
        }
      }

      //------------------------------------ Prima SFP ----------------------------------------
      if (rowIndex === 6) {
        if (cellIndex >= 1 && cellIndex < 10) {
          calPremiumSfp(cellIndex - 1, cell);
        }
        if (cellIndex === 10) {
          const sum = calculateSumAgfu("ASIM-5-", 5);
          updateCell(cell, sum);
        }
      }
    });
  });
};


//?-----------------------  COTIZACION  --------------------------------------------------------------------
const calculateTblAcsel = () => {


  const calHospitalizationPremium_A = (index, cell) => {
    const N25 = objData.HEA[`HEA-0-10`] ?? 0;

    const value = N25
    updateCellQuoter(cell, value);
  };

  const calHospitalizationPremium_B = (index, cell) => {
    const N25 = objData.HEA[`HEA-0-10`] ?? 0;

    const value = N25 / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);
  };

  const calFuneralPremium_A = (index, cell) => {
    let value
    if (objData.O3 == 1) {
      if (countInRange(objData.CUSTOMER, 14, 22, "D") > 1) {
        value = 0//'No Incluida'
      } else {
        const N34 = objData.HEA[`AGFU-0-10`] ?? 0;
        value = N34
      }
    } else {
      value = 0
    }
    updateCellQuoter(cell, value);
  };

  const calFuneralPremium_B = (index, cell) => {
    let value
    if (objData.O3 == 1) {
      if (countInRange(objData.CUSTOMER, 14, 22, "D") > 1) {
        value = 0//'No Incluida' 
      } else {
        const N34 = objData.HEA[`AGFU-0-10`] ?? 0;
        value = N34 / paymentSurcharges[objData.D8]?.colS;
      }
    } else {
      value = 0
    }
    updateCellQuoter(cell, value);
  };

  const calPremiumAssistance_A = (index, cell) => {
    const N41 = objData.HEA[`ASIM-0-10`] ?? 0;

    const value = N41
    updateCellQuoter(cell, value);
  };
  const calPremiumAssistance_B = (index, cell) => {
    const N41 = objData.HEA[`ASIM-0-10`] ?? 0;
    const N34 = objData.HEA[`AGFU-0-10`] ?? 0;

    const value = N41 / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);
  };

  const calTotalRiskPremium_A = (index, cell) => {
    const N25 = objData.HEA[`HEA-0-10`] ?? 0;
    const N34 = objData.HEA[`AGFU-0-10`] ?? 0;
    const N41 = objData.HEA[`ASIM-0-10`] ?? 0;

    const value = N25 + N34 + N41

    updateCellQuoter(cell, value);

  };

  const calTotalRiskPremium_B = (index, cell) => {
    const N25 = objData.HEA[`HEA-0-10`] ?? 0;
    const N34 = objData.HEA[`AGFU-0-10`] ?? 0;
    const N41 = objData.HEA[`ASIM-0-10`] ?? 0;

    const value = (N25 + N34 + N41) / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);

  };

  const calSpecialDiscount_A = (index, cell) => {
    const N26 = objData.HEA[`HEA-1-10`] ?? 0;
    const N35 = objData.HEA[`AGFU-1-10`] ?? 0;
    const N42 = objData.HEA[`ASIM-1-10`] ?? 0;

    const value = N26 + N35 + N42

    updateCellQuoter(cell, value);

  };

  const calSpecialDiscount_B = (index, cell) => {
    const N26 = objData.HEA[`HEA-1-10`] ?? 0;
    const N35 = objData.HEA[`AGFU-1-10`] ?? 0;
    const N42 = objData.HEA[`ASIM-1-10`] ?? 0;


    const value = (N26 + N35 + N42) / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);

  };
  const calSurchargesMethodPayment_A = (index, cell) => {
    const N27 = objData.HEA[`HEA-2-10`] ?? 0;
    const N36 = objData.HEA[`AGFU-2-10`] ?? 0;
    const N43 = objData.HEA[`ASIM-2-10`] ?? 0;

    const value = N27 + N36 + N43

    updateCellQuoter(cell, value);

  };

  const calSurchargesMethodPayment_B = (index, cell) => {
    const N27 = objData.HEA[`HEA-2-10`] ?? 0;
    const N36 = objData.HEA[`AGFU-2-10`] ?? 0;
    const N43 = objData.HEA[`ASIM-2-10`] ?? 0;
    const value = (N27 + N36 + N43) / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);

  };

  const calInsurancePolicy_A = (index, cell) => {
    const N28 = objData.HEA[`HEA-3-10`] ?? 0;
    const value = N28
    updateCellQuoter(cell, value);

  };

  const calInsurancePolicy_B = (index, cell) => {
    const N28 = objData.HEA[`HEA-3-10`] ?? 0;
    const value = N28 / paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);

  };
  const calIva_A = (index, cell) => {
    const N29 = objData.HEA[`HEA-4-10`] ?? 0;
    const N44 = objData.HEA[`ASIM-3-10`] ?? 0;
    const value = N29 + N44
    updateCellQuoter(cell, value);

  };

  const calIva_B = (index, cell) => {
    const N29 = objData.HEA[`HEA-4-10`] ?? 0;
    const N44 = objData.HEA[`ASIM-3-10`] ?? 0;
    const value = (N29 + N44)/ paymentSurcharges[objData.D8]?.colS;

    updateCellQuoter(cell, value);

  };
   const calTotalPremium_A = (index, cell) => {
    const N30 = objData.HEA[`HEA-5-10`] ?? 0;
    const N37 = objData.HEA[`AGFU-3-10`] ?? 0;
    const N45 = objData.HEA[`ASIM-4-10`] ?? 0;
    const value = N30+N37+N45
    // console.log(N30,N37,N45,'R=>',value)
    updateCellQuoter(cell, value);

  };

  const calTotalPremium_B = (index, cell) => {
    const N30 = objData.HEA[`HEA-5-10`] ?? 0;
    const N37 = objData.HEA[`AGFU-3-10`] ?? 0;
    const N45 = objData.HEA[`ASIM-4-10`] ?? 0;
    const value = (N30+N37+N45) / paymentSurcharges[objData.D8]?.colS;
    updateCellQuoter(cell, value);
  };


  const calFirstPayment = (index, cell) => {
    const N30 = objData.HEA[`HEA-5-10`] ?? 0;
    const N37 = objData.HEA[`AGFU-3-10`] ?? 0;
    const N45 = objData.HEA[`ASIM-4-10`] ?? 0;
    const value = (N30+N37+N45) / paymentSurcharges[objData.D8]?.colS;
    updateCellQuoter(cell, value);
  };

  const calLastPayment = (index, cell) => {
    let value
    const M13 = objData.HEA[`Titulo-8-1`] ?? 0;
    const M14 = objData.HEA[`Titulo-9-1`] ?? 0;

    if (objData.D8 == 'Anual' ) {
      value = 0
    } else {
      const colS = paymentSurcharges[objData.D8]?.colS ?? 0;
      let M13R = M13;
      let M14R = M14;
      let operation = roundToTwo(M13R - M14R * (colS - 1));
      
      value = operation
      // console.log(M14,value);
    }
    updateCellQuoter(cell, value);

    // =SI.ERROR(SI(D8="Anual","",REDONDEAR(M13-(M14*(BUSCARV($D$8,$Q$10:$S$13,3,FALSO())-1)),2)),0)
    
  };
  
  Array.from(tblAcsel.rows).forEach((row, rowIndex) => {
    Array.from(row.cells).forEach((cell, cellIndex) => {
      //------------------------------------Prima Hospitalización  ----------------------------------------
      if (rowIndex === 1) {

        if (cellIndex == 1) {
          calHospitalizationPremium_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calHospitalizationPremium_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Prima Funerario  ----------------------------------------
      if (rowIndex === 2) {

        if (cellIndex == 1) {
          calFuneralPremium_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calFuneralPremium_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Prima Asistencia  ----------------------------------------
      if (rowIndex === 3) {

        if (cellIndex == 1) {
          calPremiumAssistance_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calPremiumAssistance_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Prima Riesgo Total  ----------------------------------------
      if (rowIndex === 4) {

        if (cellIndex == 1) {
          calTotalRiskPremium_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calTotalRiskPremium_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Descuento Especial  ----------------------------------------
      if (rowIndex === 5) {

        if (cellIndex == 1) {
          calSpecialDiscount_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calSpecialDiscount_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Recargos por forma de pago  ----------------------------------------
      if (rowIndex === 6) {

        if (cellIndex == 1) {
          calSurchargesMethodPayment_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calSurchargesMethodPayment_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Derecho Póliza----------------------------------------
      if (rowIndex === 7) {

        if (cellIndex == 1) {
          calInsurancePolicy_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calInsurancePolicy_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------IVA----------------------------------------
      if (rowIndex === 8) {

        if (cellIndex == 1) {
          calIva_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calIva_B(cellIndex - 1, cell);
        }
      }
      //------------------------------------Prima Total----------------------------------------
      if (rowIndex === 9) {

        if (cellIndex == 1) {
          calTotalPremium_A(cellIndex - 1, cell);
        }
        if (cellIndex == 2) {
          calTotalPremium_B(cellIndex - 1, cell);
        }
      } 
            //------------------------------------Primer pago----------------------------------------
            if (rowIndex === 10) {
              if (cellIndex == 1) {
                calFirstPayment(cellIndex - 1, cell);
              }
            } 
                  //------------------------------------Último pago----------------------------------------
      if (rowIndex === 11) {
        if (cellIndex == 1) {
          calLastPayment(cellIndex - 1, cell);
        }
      }      

    });
  });
};






function roundToTwo(value) {
  return Math.round(value * 100) / 100;
}


const updateCellQuoter = (cell, value) => {
  const formattedValue = parseFloat(value.toFixed(2));
  cell.textContent = `$${formattedValue}`;
  // cell.style.backgroundColor = "#ff6366";
  objData.HEA[cell.className] = formattedValue;
};