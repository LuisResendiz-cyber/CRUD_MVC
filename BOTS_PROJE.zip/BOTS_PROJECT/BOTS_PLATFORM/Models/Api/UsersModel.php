<?php
namespace Models\Api;

class UsersModel {
    
    public function getAllUsers($filters = []) {
        $response = api_get('Users/GetAllUsers', $filters);
        
        if ($response['success']) {
            $users = [];
            foreach ($response['data'] as $userData) {
                $users[] = $this->mapUserData($userData);
            }
            return $users;
        }
        
        log_api_error('Failed to get users', [
            'filters' => $filters,
            'response' => $response
        ]);
        
        return [];
    }
    
    public function getUserById($userId) {
        $response = api_get("Users/GetUser/{$userId}");
        
        if ($response['success']) {
            return $this->mapUserData($response['data']);
        }
        
        log_api_error('Failed to get user', [
            'userId' => $userId,
            'response' => $response
        ]);
        
        return false;
    }
    
    public function createUser($userData) {
        $data = [
            'customer_id' => $userData['identificacion'],
            'name' => $userData['nombre'],
            'last_name' => $userData['apellido'],
            'phone_number' => (string)$userData['telefono'],
            'email_user' => $userData['email'],
            'passwordHash' => $userData['password'], // Ya hasheado
            'rolid' => $userData['tipoid'],
            'status' => $userData['status'] ?? 1
        ];
        
        $response = api_post('Users/CreateUser', $data);
        
        if ($response['success']) {
            return [
                'id' => $response['data']['id'] ?? 0,
                'success' => true
            ];
        }
        
        // Manejar errores específicos
        if (isset($response['data']['error'])) {
            $error = strtolower($response['data']['error']);
            if (strpos($error, 'ya existe') !== false || 
                strpos($error, 'duplicate') !== false) {
                return ['exists' => true];
            }
        }
        
        return ['success' => false];
    }
    
    public function updateUser($userId, $userData) {
        $data = [
            'customer_id' => $userData['identificacion'],
            'name' => $userData['nombre'],
            'last_name' => $userData['apellido'],
            'phone_number' => (string)$userData['telefono'],
            'email_user' => $userData['email'],
            'rolid' => $userData['tipoid'],
            'status' => $userData['status'] ?? 1
        ];
        
        // Agregar password si se está actualizando
        if (!empty($userData['password'])) {
            $data['passwordHash'] = $userData['password'];
        }
        
        $response = api_put("Users/UpdateUser/{$userId}", $data);
        
        if ($response['success']) {
            return ['success' => true];
        }
        
        // Manejar errores de duplicado
        if (isset($response['data']['error'])) {
            $error = strtolower($response['data']['error']);
            if (strpos($error, 'ya existe') !== false) {
                return ['exists' => true];
            }
        }
        
        return ['success' => false];
    }
    
    public function deleteUser($userId) {
        $response = api_delete("Users/DeleteUser/{$userId}");
        
        if ($response['success']) {
            return ['success' => true];
        }
        
        return ['success' => false];
    }
    
    public function updateProfile($userId, $profileData) {
        $data = [
            'customer_id' => $profileData['identificacion'],
            'name' => $profileData['nombre'],
            'last_name' => $profileData['apellido'],
            'phone_number' => (string)$profileData['telefono']
        ];
        
        if (!empty($profileData['password'])) {
            $data['passwordHash'] = $profileData['password'];
        }
        
        $response = api_put("Users/UpdateProfile/{$userId}", $data);
        
        return ['success' => $response['success'] ?? false];
    }
    
    private function mapUserData($apiData) {
        return [
            'idpersona' => $apiData['idpersona'] ?? $apiData['id'] ?? 0,
            'identificacion' => $apiData['customer_id'] ?? '',
            'nombres' => $apiData['nombres'] ?? $apiData['name'] ?? '',
            'apellidos' => $apiData['apellidos'] ?? $apiData['last_name'] ?? '',
            'telefono' => $apiData['telefono'] ?? $apiData['phone_number'] ?? '',
            'email_user' => $apiData['email_user'] ?? '',
            'status' => $apiData['status'] ?? 1,
            'idrol' => $apiData['rolid'] ?? $apiData['role_id'] ?? 0,
            'nombrerol' => $apiData['nombrerol'] ?? $apiData['role_name'] ?? '',
            'created_at' => $apiData['created_at'] ?? $apiData['datecreated'] ?? ''
        ];
    }
}
?>