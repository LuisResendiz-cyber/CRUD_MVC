const get_agente_info = require('../db_apis/get_agente_info.js');
 
async function post(req, res, next) {
  try {
     //console.log("get_agente_info",req.body)
    const context = req.body;//{};

    // context.camp      = 1;
    // context.prioridad   = 1;
    // context.estatus     = 0;
    // context.intentos    = 10;
    // context.user_     = 8981;
    // context.rand_     = 0;    
    // context.tipoCampana   = '0';    
 
    const rows = await get_agente_info.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;