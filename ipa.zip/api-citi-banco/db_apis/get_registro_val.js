const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context){
  const baseQuery = "BEGIN " + context.schema + ".XPS_REGISTROVAL(:v_customer_id, :v_registroval); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(!context.schema || !context.u_persona ){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    //Se asignan los valores respecto a los parametros del SP
    binds.v_customer_id = context.u_persona;
    binds.v_registroval = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_NUMBER};

    const result = await database.simpleExecute(query, binds);
    //console.log('---', result, '-----');
    return result;
  }
}

module.exports.find = find;