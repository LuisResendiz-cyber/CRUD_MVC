const axios = require("axios");
require("dotenv").config();

async function textToSpeech(text) {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  const voiceId = "EXAVITQu4vr4xnSDxMaL"; // Voz por defecto de ElevenLabs

  const res = await axios.post(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      text,
      model_id: "eleven_multilingual_v2"
    },
    {
      responseType: "arraybuffer",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json"
      }
    }
  );

  return Buffer.from(res.data);
}

module.exports = { textToSpeech };
