const UsersModel = require('../models/appModel');
const bcrypt = require('bcryptjs');
const jwt  = require('jsonwebtoken');

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const secretKey = process.env.JWT_SECRET;

const appController = {
    async getUser(req, res) {
        try {
            const users = await UsersModel.getAll();
            res.json(users);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },
    async setUser(req, res) {
        const { username, email, passwordHash, bio, location } = req.body;

        const salt = await bcrypt.genSalt(10); // factor de costo
        const password = await bcrypt.hash(passwordHash, salt);

        try {
            const resp = await UsersModel.CreateUser({ username, email, password, bio, location });

            if (resp.affectedRows > 0) {
                res.json({
                    message: '✅ Usuario registrado con éxito',
                    userId: resp.insertId
                });
            } else {
                res.status(400).json({ message: '❌ No se pudo insertar el usuario' });
            }

        } catch (error) {
            console.log(error.message);
            return res.status(500).json({ message: '⚠️ Error en el servidor, intenta más tarde' });
        }
    },
    async getUserById(req, res) {
        const { id } = req.params; // 👈 aquí está el cambio

        try {
            const user = await UsersModel.getUser({ id });
            if (user.length > 0) {
                res.status(200).json(user);
            } else {
                res.status(404).json({ message: "Usuario no encontrado" });
            }
        } catch (error) {
            console.log(error.message);
            return res.status(500).json({ message: '⚠️ Error en el servidor, intenta más tarde' });
        }
    },
    async login(req, res) {
        const { email, passwordHash } = req.body;

        const user = await UsersModel.getAcces({ email });
        const isMatch = await bcrypt.compare(passwordHash, user.passwordHash);
        if (!isMatch) return res.status(400).json({ message: 'Contraseña incorrecta' });

        // Crear token JWT
        const token = jwt.sign(
            { userId: user.userId, username: user.username }, // payload
            secretKey,
            { expiresIn: '1h' }
        );

        res.json({ message: 'Login correcto', token });

    }

}

module.exports = appController;