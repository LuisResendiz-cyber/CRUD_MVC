const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context){
  // const baseQuery = "BEGIN DBO.XSP_BLOQUEAR_TELEFONO_CITI(:customerid, :tipo_bloqueo, :keys, :rc); END;";
  const baseQuery = "BEGIN DBO.XSP_BLOQUEAR_TELEFONO_CITI(:customerid, :tipo_bloqueo, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  // if(context.fecha_carga=='' || context.customerid=='' || context.tipo_bloqueo=='' || context.keys){
  if(context.fecha_carga=='' || context.customerid=='' || context.tipo_bloqueo==''){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.customerid = context.customerid;
    binds.tipo_bloqueo = context.tipo_bloqueo;
    // binds.keys = context.keyrig;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);

    return result;
  }
}

module.exports.find = find;

