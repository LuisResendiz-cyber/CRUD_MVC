const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
  
const baseQuery = "BEGIN "+ context.schema +".XSP_PRESCREENING(:solicitud,:nombre,:apaterno,:amaterno,:fecha_nac,:rfc,:calle,:numero,:colonia,:municipio,:estado,:cp,:user,:edo_nac,:resultado,:act); END;";

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   
  
  if(!context.solicitud || !context.nombre || !context.apaterno || !context.amaterno || !context.fecha_nac || !context.rfc || !context.calle || !context.numero || !context.colonia || !context.municipio || !context.estado || !context.cp || !context.user || !context.edo_nac || !context.act){
   //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.solicitud = context.solicitud;
    binds.nombre = context.nombre;
    binds.apaterno = context.apaterno;
    binds.amaterno = context.amaterno;
    binds.fecha_nac = context.fecha_nac;
    binds.rfc = context.rfc;
    binds.calle = context.calle;
    binds.numero = context.numero;
    binds.colonia = context.colonia;
    binds.municipio = context.municipio;
    binds.estado = context.estado;
    binds.cp = context.cp;
    binds.user = context.user;
    binds.edo_nac = context.edo_nac
    binds.resultado = context.resultado;
    binds.act = context.act;

    const result = await database.simpleExecute(query, binds);
    // console.log(result);
    return result;
  }


}

module.exports.find = find;