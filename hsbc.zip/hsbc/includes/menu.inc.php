<?php
# @uthor Mark
# Menu File
// ARMA EL MENU DINAMICO PARA LOS USUARIOS

function menu($db) {
    global $linkpath;

    $tu_base = true;
    if (isset($_REQUEST['mod']) || isset($_REQUEST['op'])) {
        $tu_base = false;
    }

    if (get_session_varname('s_puede_referido') == 0) {
        $tu_base = false;
    }

    $id_solicitud = get_session_varname('id_solicitud'); 
    $tipo_standby = get_session_varname("tipo_standby");
    $nomina = get_session_varname('s_usr_nomina');
    $isPredictivo = get_session_varname("s_usr_marcacion");
    	
    if (is_logged()) {
        echo '<input type="hidden" id="lg_marcacion" value="'.$isPredictivo.'">';

        
        
        if ($id_solicitud == 0) {
            echo '<input type="button" class="menulink" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=admin&op=process_data&act=2\'" value="Terminar sesi&oacute;n"><br />' . "\r\n";
        } else {
            echo '<input type="button" class="menulink2" value="Terminar sesi&oacute;n" disabled><br />' . "\r\n";
        }
        
        if (get_session_varname("s_usr_nivel") != 'S') {
            if ($tipo_standby == 0) {                
                //Boton inicio                
                if ($id_solicitud == 0) {
                    echo '<p>&nbsp;<input type="button" class="menulink" id="inicio" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=Mzc=\'" value="Inicio"></p>' . "\r\n";                    
                } else {
                    echo '<p>&nbsp;<input type="button" class="menulink" id="inicio" onclick="if (eval(\'document.frm1\') != null) {AbandonarV2(this,document.frm1.cont.value, \'MTg=\', null, '.$nomina.', '.$id_solicitud.')} else {this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=Mzc=\'}" value="Inicio"></p>' . "\r\n";                    
                }
     

                // echo '<p>&nbsp;<a href="'.$linkpath.'modules.php?mod=agentes&op=Script_simulador" target="_blank" class="menulink" id="simulador">Simulador HC</a></p>' . "\r\n";                                    
                echo '<p>&nbsp;<a href="'.$linkpath.'cotizador_hsbc/index_v2.html" target="_blank" class="menulink" id="simulador">Simulador HC</a></p>' . "\r\n";                                    
                
                //Boton agenda
                /*if ($id_solicitud == 0) {
                    echo '<p>&nbsp;<input type="button" class="menulink" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=registros_agenda\'" value="Agenda"></p>' . "\r\n";
                } else {
                    echo '<p>&nbsp;<input type="button" class="menulink2" value="Agenda" disabled></p>' . "\r\n";
                }*/
                
                //Verifica perfil de usuario
                if (in_array(get_session_varname("s_usr_nivel"), array('A', 'ACB'))) {

                    //Boton tu base
                    /*if ($tu_base) {
                        echo '<p>&nbsp;<input type="button" class="menulink" id="tu_base" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=nuevoregistro\'" value="Tu Base"></p>' . "\r\n";
                    } else {
                        echo '<p>&nbsp;<input type="button" class="menulink2" id="tu_base" value="Tu Base" disabled></p>' . "\r\n";
                    }*/

                    //Boton buscar registro
                    // if ($id_solicitud == 0) {
                    //     echo '<p>&nbsp;<input type="button" class="menulink" id="bsregistro" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('2') . '\'" value="Buscar Registro"></p>' . "\r\n";
                    // } else {
                    //     echo '<p>&nbsp;<input type="button" class="menulink2" id="bsregistro" value="Buscar Registro" disabled></p>' . "\r\n";
                    // }

                    //Boton agenda
                    if ($id_solicitud == 0) {
                        echo '<p id="btn_agenda_">&nbsp;<input type="button" class="menulink" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=registros_agenda\'" value="Agenda"></p>' . "\r\n";
                    } else {
                        echo '<p id="btn_agenda_">&nbsp;<input type="button" class="menulink2" value="Agenda" disabled></p>' . "\r\n";
                    }
                    
                    //Boton aviso de privacidad
                    if ($id_solicitud != 0) {
                        // echo '<p>&nbsp;<input type="button" class="menulink" id="aviso" onclick="this.disabled=false;Aviso_privacidad(this)" value="Aviso Privacidad"></p>' . "\r\n";
                    } else {
                        // echo '<p>&nbsp;<input type="button" class="menulink2" id="aviso" value="Aviso Privacidad" disabled></p>' . "\r\n";
                    }

                    //Boton obtener registro
                    if ($id_solicitud == 0) {
                        if (get_session_varname("s_usr_marcacion") == 1) {
                            echo '<p id="btn_obt_reg">&nbsp;<input type="button" class="menulink" id="obRegistroPred" onclick="this.disabled=true;obtenerRegistroPredictivo();" value="Obtener Registro"></p>' . "\r\n";
                        } else {
                            echo '<p id="btn_obt_reg">&nbsp;<input type="button" class="menulink" id="obRegistroAsis" onclick="this.disabled=true;obtenerRegistroAsistido();" value="Obtener Registro"></p>' . "\r\n";
                            // echo '<p id="btn_bus_reg">&nbsp;<input type="button" class="menulink" id="bsregistro" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('2') . '\'" value="Buscar Registro"></p>' . "\r\n";
                        }
                    } else {
                        echo '<p id="btn_obt_reg">&nbsp;<input type="button" class="menulink2" id="obRegistroAsis" value="Obtener Registro" disabled></p>' . "\r\n";
                    }

                    //Boton nuevo registro
                    } elseif (get_session_varname("s_usr_nivel") == 'ASB') {
                        echo '<p>&nbsp;<input type="button" class="menulink" onclick="window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=nuevoregistro\'" value="Nuevo Registro"></p>' . "\r\n";
                    }
                    ?> 
                    <hi id="nota_agenda">Script / Agenda</hi>
                    <div id="panel_notaagneda">
                        <div  class="accordion-resizer" style="height: 400px; ">
                            <div id="accordion">
                                <h3>Agenda</h3>
                                <div>
                                    <form method="post" name="frm3" id="frm3">
                                        <input type="hidden" name="u_persona" id ="u_persona">
                                        <input type="hidden" name="u_registro" id ="u_registro">
                                        <input type="text" name="fecha_agenda" id="fecha_agenda" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
                                        <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true; verAgenda(this, document.getElementById('fecha_agenda').value, 'agenda2', 1);" />
                                        <div id="agenda2" align="center" class="script"></div>
                                    </form>
                                </div>
                                <h3>Script</h3>
                                <div>
                                    <div id="script" class="script"></div>
                                </div>
                                <!--h3>Simulador</h3>
                                <div>
                                        <iframe src="<?php echo $linkpath; ?>modules.php?mod=agentes&op=Script_simulador" width="100%" height="320" frameborder="0">
                                        <p>El navegador no soporta IFrames.</p>
                                        </iframe>
                                </div-->                                
                                <?php if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'AI' || get_session_varname('s_usr_nivel') == 'AA' || get_session_varname('s_usr_nivel') == 'ACB')) { ?>
                                    <h3>Notas Personales</h3>
                                    <div>
                                        <iframe src="<?php echo $linkpath; ?>modules.php?mod=agentes&op=notas" width="100%" height="320" frameborder="0">
                                        <p>El navegador no soporta IFrames.</p>
                                        </iframe>
                                    </div>
                                    <?php
                                }
                                ?>
                                <h3>Aviso De Privacidad</h3>
                                    <div>                                
                                        Impulse Telecommunications de Mexico S.A de C.V. con domicilio en Av. 5 de febrero 1309 Nave A4 Col. Felipe Carrillo Puerto C.P. 76138 Quer&eacute;taro, Qro. M&eacute;xico; utiliza informaci&oacute;n personal de los titulares para la promoci&oacute;n y venta de productos y servicios. Para conocer nuestro aviso de privacidad integral por favor visite www.impulse-telecom.com.
                                        <h2 style="color:#59879D;">QUE CONTESTAR AL CLIENTE:</h2>
                                        <p style="color:red;">Si el cliente menciona que est&aacute; inscrito en REUS (Registro P&uacute;blico de Usuarios Personas F&iacute;sicas), CONDUSEF (Comisi&oacute;n Nacional para la Protecci&oacute;n y Defensa de los Usuarios de los Servicios Financieros) o ya requiri&oacute; derecho de ARCO:</p>
                                        <br>
                                        <p>De parte de (campa&ntilde;a) le ofrezco una disculpa, no ten&iacute;a conocimiento de esta situaci&oacute;n. Le agradezco que haya atendido mi llamada, muchas gracias.</p>
                                        <br>
                                        <p style="color:red;">Que responder ante la pregunta �C&oacute;mo obtuviste mis datos?</p>
                                        <br>
                                        <P>Se&ntilde;or (a)no se preocupe, el &uacute;nico dato con el que contamos es este tel&eacute;fono al que nos estamos comunicando.</P>
                                        <br>
                                        <p style="color:red;">Con insistencia, de d&oacute;nde los obtuvieron: </p>
                                        <br>
                                        <p>Se&ntilde;or (a), nuestra informaci&oacute;n fuente es p&uacute;blica, y es obtenida de correr las series de marcaci&oacute;n que aparecen en la p&aacute;gina web del Instituto Federal de Telecomunicaciones.</p>
                                        <br>
                                        <p style="color:red;">Tercera insistencia:</p>
                                        <br>
                                        <p>Se&ntilde;or (a), de parte de (campa&ntilde;a) le ofrezco una disculpa, definitivamente no es nuestro objetivo generarle desconfianza alguna, sin embargo entiendo su preocupaci&oacute;n. En estos momentos procedo al bloqueo de este tel&eacute;fono para que no lo volvamos a contactar. Le agradezco que haya atendido mi llamada, muchas gracias.</p>
                                        <br>
                                        <p>No darle a entender al cliente que alguna empresa externa nos proporcion&oacute; sus datos lo cual es incorrecto.</p> 
                                        <br>
                                        <p>Ejemplo:</p>
                                        <ul>
                                            <li>Es referido por Visa / Master Card</li>
                                            <li>Por sus buenas referencias crediticias.</li>
                                            <li>Por su buen historial en bur&oacute; de cr&eacute;dito</li>
                                        </ul>
                                        <br>
                                    </div>
                                <h3>Web-Sicall</h3>
                                <div>                                
                                    <ul id="menu">                                        
                                        <li>
                                            <a href="#">Procesos</a>
                                            <ul>
                                                <li> <a onclick="dialogo('<?php echo $linkpath; ?>modules.php?mod=agentes&op=busqueda_cp', 'Busqueda de Codigos Postales')" href="#">Busqueda de CP</a> </li><!--id="opener"-->
                                            </ul>
                                        </li>
                                        <li> 
                                            <a href="#">Reportes</a>
                                            <ul>
                                                <li><a onclick="dialogo('<?php echo $linkpath; ?>modules.php?mod=agentes&op=indicadores&nomina=<?php echo encripta(get_session_varname('s_usr_nomina')); ?>&u_user=<?php echo encripta(get_session_varname('s_usr_id')); ?>', 'Indicadores')" href="#">Indicadores</a></li><!--id="indicadores"-->
                                                <li><a onclick="dialogo('<?php echo $linkpath; ?>modules.php?mod=agentes&op=llamadas800&nomina=<?php echo encripta(get_session_varname('s_usr_nomina')); ?>&u_user=<?php echo encripta(get_session_varname('s_usr_id')); ?>', 'Llamadas 800')" href="#">Llamadas 800</a></li><!--id="llamadas800"-->
                                                <li><a onclick="dialogo('<?php echo $linkpath; ?>modules.php?mod=agentes&op=prescrining&nomina=<?php echo encripta(get_session_varname('s_usr_nomina')); ?>&u_user=<?php echo encripta(get_session_varname('s_usr_id')); ?>', 'Prescrining')" href="#">Prescrining</a></li><!--id="llamadas800"-->
                                            </ul>
                                        </li>
                                    </ul>
                                    <div id="indicador" title="Indicadores">
                                        <iframe src="" width="100%" height="100%" frameborder="0" id="iframeind" >
                                        <p>El navegador no soporta IFrames.</p>
                                        </iframe>
                                    </div>
                                </div>
                                <?php
                                $ip_ja = explode('.', $_SERVER['SERVER_ADDR']);
                                $hora = date("H");
                                $minutos = date("i");
                                
//                                if($hora == 10 || $hora == 11 || $hora == 12 || $hora == 13|| $hora == 14 || $hora == 15 || $hora == 16 || $hora == 17 || $hora == 18){
//                                    if($minutos > 01 && $minutos < 58){                                                        
                                if($hora == 11 || $hora == 15 ){
//                                    if($minutos >= 0 && $minutos < 5){                                                        
                                ?>
                                <h3>Juegos Antiestres</h3>
                                <div>                                
                                    <ul id="menu">                                        
                                        <!--li> <a onclick="dialogo('http://172.20.1.<?=$ip_ja[3]?>/JuegosAntiestres/clumsy-bird-gh-pages/', 'ClumsiBird')" href="#">ClumsiBird</a> </li-->
                                        <!--li> <a onclick="dialogo('http://172.20.1.<?=$ip_ja[3]?>/JuegosAntiestres/hextris-gh-pages/index.html', 'Hextris')" href="#">Hextris</a> </li-->
                                        <li> <a onclick="dialogo('http://172.20.1.<?=$ip_ja[3]?>/JuegosAntiestres/pacman-master/', 'Pacman')" href="#">Pac-man</a> </li>
                                        <li> <a onclick="dialogo('http://172.20.1.70/JuegosAntiestres/NaveEspacial/applet.html', 'Nave Espacial')" href="#">Nave Espacial</a> </li>
                                        <li> <a onclick="dialogo('http://172.20.1.70/JuegosAntiestres/Torres/applet.html', 'Torres')" href="#">Torres</a> </li>
                                        <!--li> <a onclick="dialogo('http://172.20.1.70/JuegosAntiestres/Puzzle/applet.html', 'Puzzle')" href="#">Puzzle</a> </li-->
                                    </ul>
                                </div>
                                <?php
//                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                    if ($id_solicitud == 0) {
                        echo '<p>&nbsp;<input type="button" class="menulink" id="btnbreak" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('58') . '\'" value="Break"></p>' . "\r\n";
			echo '<p>&nbsp;<input type="button" class="menulink" id="btnbano" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('59') . '\'" value="Ba&ntilde;o"></p>' . "\r\n";
			echo '<p>&nbsp;<input type="button" class="menulink" id="btncapa" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('60') . '\'" value="Capacitaci&oacute;n"></p>' . "\r\n";
                    } else {
                        echo '<p>&nbsp;<input type="button" class="menulink2" id="btnbreak" disabled value="Break"></p>' . "\r\n";
			echo '<p>&nbsp;<input type="button" class="menulink2" id="btnbano" disabled value="Ba&ntilde;o"></p>' . "\r\n";
			echo '<p>&nbsp;<input type="button" class="menulink2" id="btncapa" disabled value="Capacitaci&oacute;n"></p>' . "\r\n";
                    }
            } else {
                if ($tipo_standby == 1) {
                    echo '<p>&nbsp;<input type="button" class="menulink" id="btnbreak" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Break"></p>' . "\r\n";
		} elseif ($tipo_standby == 2) {
                    echo '<p>&nbsp;<input type="button" class="menulink" id="btnbano" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Ba&ntilde;o"></p>' . "\r\n";
		} elseif ($tipo_standby == 3) {
                    echo '<p>&nbsp;<input type="button" class="menulink" id="btncapa" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Capacitaci&oacute;n"></p>' . "\r\n";
		}
            }
        } else {
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=reporte_prod">Reportes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=nomina&op=activacion">Activacion</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('30') . '">Buscar Cliente</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=01800">01800</a></p>' . "\r\n";
            //echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=datos_solicitud">Datos de Solicitud</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('32') . '">Buscar Empresa</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('33') . '">Buscar CP</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=procesos_detenidos">Procs. detenidos</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=seguimiento_agentes">Seg. Agentes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=seguimiento_solicitudes">Seg. Solicitudes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=revivir_solicitud">Revivir Solicitud</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=layouts">Layouts</a></p>' . "\r\n";
        }
    } else {
        echo '&nbsp;';
    }
}

// OBTIENE LOS NIVELES DEL MENU
function get_profilemenu($action, $s_usr_nivel, $menuchild_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_PROFILEMENU('" . $s_usr_nivel . "'," . $menuchild_id . "," . $action . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}
