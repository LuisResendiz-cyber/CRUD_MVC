/* 
window.addEventListener('popstate', function (event) {
    history.pushState(null, null, document.URL);
});
*/

function ProductosId() {
    if (document.getElementById('IdProducto')) {        
        let producto = document.getElementById('IdProducto').value;
        sessionStorage.setItem("IdProducto", producto);
    }
}


$(document).ready(function() {


    f5($(document), true);
    drawBtnPrescreeningDir(2);
    //cargarActualizaciones();
    
    
    $("#nota_agenda").click(function() {
        $("#panel_notaagneda").slideToggle("slow");
    });


    $("#actualizaciones, #imgActualizaciones").click(function() {
        //$("#panel_actualizaciones").slideToggle("slow");
        $('#myModal').show();
    });
    
    // método para prescreening domicilio principal o alterno.
    $('select[name="txtQId12CId14"]').change(function(){
        $('.btnPrescreening_').hide();
        let valor = $(this).val();
        
        if(valor == 'S'){
            $('#btnPrescreening2').hide();
            $('#btnPrescreening3').show();
            drawBtnPrescreeningDir(3);
            
        } else{
            $('#btnPrescreening2').show();
            $('#btnPrescreening3').hide();
            drawBtnPrescreeningDir(2);
        }
    });
    
    localStorage.setItem("folioAutenticacion", 'SIN_FOLIO');
    var survey_id = $('#inputProducto').val();
    if(survey_id == 1){
        $('select[name="txtQId11CId8"]').parent().parent().attr('id', 'trEdoCuenta');
        $(`<tr style="background-color:#b2ebf2">
        <td width="70%">
        <div id="divFolioAut">
        <table>
        <tr>
        <td>Folio de Autenticacion:</td>
        <td><input id="folioAutenticacion" maxlength="20"></td>
        </tr>
        <tr>
        <td>Score</td>
        <td><input id="score" maxlength="3"></td>
        </tr>
        <tr>
        <td>Intentos</td>
                            <td><input id="intentos" maxlength="2"></td>
                        </tr>
                        </table>
                        </div>
                        </td>
                        <td style="vertical-align:middle">
                        <input type="button" value="Guardar" class="menulink" onclick="saveDataAutenticacion();">
                        </td>
                        </tr>`).insertBefore('#trEdoCuenta');
                    }
                    
                    
                    $("select[name='txtQId13CId12']").on("change", function() {
                        // Este código se ejecutará cuando se cambie la selección en el combo
                        var opcionSeleccionada = $("select[name='txtQId13CId12'] option:selected").text();
                        console.log("Opción seleccionada:" + opcionSeleccionada);
                        // Realizar la solicitud AJAX
                        $.ajax({
                            url: "modules.php?mod=agentes&op=process_data&act=OTU=", // Ruta al script PHP
                            method: "POST",
                            data:{'tarjeta':opcionSeleccionada},
                            dataType:"json",
                            success: function(data) {
                                // Manipular la respuesta del servidor
                                //$("#respuesta").html(data);
                                var miModal = document.getElementById("modalDescripcionTarjeta");
                                var cerrarModal = document.getElementById("cerrarModalDescripcionTarjeta");
                                var contenidoTarjeta = $('#modal-contenidoTarjeta');
                                // Obtén la altura de la propiedad que está invocando el modal
                                const alturaPropiedad = document.getElementsByName('txtQId13CId12').offsetHeight;
                                
                                //Aplica la altura al contenido del modal
                                document.getElementById('modalDescripcionTarjeta').style.height = alturaPropiedad + 'px';
                                
                                // Nuevo contenido HTML que quieres añadir
                                const nuevoContenido = '<h6><b>Tarjeta:</b> '+ opcionSeleccionada +'.</h6><br>'+
                                '<p><b>Ingresos:</b> '+ data[0]['INGRESOS'] +'.</p><br>'+
                                '<p><b>Anualidad:</b> '+ data[0]['ANUALIDAD'] +'.</p><br>'+
                                '<p><b>CAT:</b> '+ data[0]['CAT'] +'.</p><br>'+
                                '<p><b>TOP:</b> '+ data[0]['TOP'] +'.</p><br>';
                                
                                // Añadir el nuevo contenido al div
                                contenidoTarjeta.html(nuevoContenido);
                                
                                miModal.style.display = "block";
                                
                                // Agregar evento de clic al botón de cerrar para ocultar el modal
                                cerrarModal.addEventListener("click", function() {
                                    miModal.style.display = "none";
                                });
                                
                            },
                            error: function(error) {
                                console.error("Error en la solicitud AJAX:", error);
                            }
                        });
                    });

                        $.post("modules.php?mod=agentes&op=process_data&act=MTA0", {}, function(data) {
                            try {
                                let resultado = JSON.parse(data);
                                if (resultado.Resultado != "" && resultado.Resultado != null) {
                                    document.SurveyResponse.btn_Guadar.hidden=true;                                  
                                    document.SurveyResponse.btn_continue.hidden=true;
                                    document.SurveyResponse.si_contacto.hidden=true; 
                                    document.SurveyResponse.btn_calificar_si_contacto.hidden=true;
                                    $('#texto_calificacion').hide(); 
                                }
                            } catch (error) {
                                console.log("error");
                            }
                        });                
        setVentasButton();
    });
    
    let surveyId = sessionStorage.getItem("IdProducto");
    
    $.post("modules.php?mod=agentes&op=process_data&act=MTAy", {//102
        surveyId
}, function(data) {
valor = JSON.parse(data);
let inputs = document.querySelectorAll('input[name^="txtQId"], select[name^="txtQId"]');
//let inputs = document.getElementById('producto_');

let inputArray = Array.from(inputs);

// Iterar sobre cada objeto en la respuesta
valor.forEach(entry => {
let combinacion = entry.COMBINACION;
let texto = entry.TEXTO;

// Encontrar el input o select cuyo name coincide con combinacion
let input = inputArray.find(input => input.name === combinacion);

// Si encontramos un input o select con el name correspondiente, actualizamos su valor
if (input) {
 input.value = texto;
}
});
});

var selection = null;
var altDown = 0;

var coberturaCP1 = false;
var coberturaCP2 = false;

/*
 * @function createCookie
 * @param string name
 * @param string value
 * @param number/null days
 * @returns {undefined}
 * @author abarajas
 * @date 2014-03-19
 *
 * Establece una cookie con su nombre, valor y duraci�n (en d�as). Se puede
 * omitir la duraci�n para que nunca expire o colocarla en 0 para que se
 * destruya al cerrar el navegador.
 */
function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else
        var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

/*
 * @function readCookie
 * @param string name
 * @returns string
 * @author abarajas
 * @date 2014-03-19
 *
 * Lee las cookies locales para extraer un valor, y asi poder pasar datos
 * desde PHP hacia JavaScript
 */
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0)
            return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
    return null;
}

/*
 * @function eraseCookie
 * @param string name
 * @returns {undefined}
 * @author abarajas
 * @date 2014-03-19
 *
 * Elimina una cookie llamado a createCookie con un par�metro negativo,
 * destruy�ndola efectivamente en el momento.
 */
function eraseCookie(name) {
    createCookie(name, "", -1);
}

var linkpath = readCookie('linkpath');

//VALIDACION PARA NO USAR EL ALT <-
if (typeof window.event != 'undefined') {
    document.onkeydown = function() {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
    }

    document.onkeyup = function() {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
        altDown = 0;
    }

    document.onkeypress = function() {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
        altDown = 0;
    }
} else {
    document.onkeydown = function(e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
    }
    document.onkeypress = function(e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
        altDown = 0;
    }

    document.onkeyup = function(e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
        altDown = 0;
    }
}

//EVITA EL BOTON ATRAS
if (typeof window.event != 'undefined') {
    document.onkeydown = function() {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && event.srcElement.tagName.toUpperCase() != 'TEXTAREA')
            return (event.keyCode != 8);
    }
} else {
    document.onkeypress = function(e) {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && e.target.nodeName.toUpperCase() != 'TEXTAREA')
            return (e.keyCode != 8);
    }
}

// CREA EL OBJETO AJAX
function nuevoAjax() {
    var xmlhttp = false;
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            xmlhttp = false;
        }
    }

    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
}


function loadXMLDoc(dname) {
    if (window.XMLHttpRequest) {
        xhttp = new XMLHttpRequest();
    } else {
        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.open("GET", dname, false);
    xhttp.send("");
    return xhttp.responseXML;
}

function displayResult(producto) {

    xml = loadXMLDoc("./modules/agentes/cuestionario_" + producto + ".xml?i=2");
    xsl = loadXMLDoc("./modules/agentes/catalogo.xsl?i=2");

    if (window.ActiveXObject) { // code for IE
        ex = xml.transformNode(xsl);
        document.getElementById("cuestionario").innerHTML = ex;
    } else if (document.implementation && document.implementation.createDocument) { // code for Mozilla, Firefox, Opera, etc.
        xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xsl);
        resultDocument = xsltProcessor.transformToFragment(xml, document);
        document.getElementById("cuestionario").appendChild(resultDocument);
    }
}

// ENVIA DATOS USANDO EL OBJETO AJAX
function send_post_page_n(request, container, page) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            contenedor.innerHTML = ajax.responseText
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// CALIFICA LOS TELEFONOS CON AJAX
function send_post_page_califica_tel(request, page) {
    var contenedor;
    ajax = nuevoAjax();
    ajax.open("POST", page, false);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}



// MANDA EJECUTAR EL FLAG - REQ 800
function send_post_page_flag(request, container, page) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajaxFlag = nuevoAjax();
    ajaxFlag.open("POST", page, true);
    ajaxFlag.onreadystatechange = function() {
        if (ajaxFlag.readyState === 4) {
            //alert(ajaxFlag.responseText);
            //contenedor.innerHTML = ajaxFlag.responseText;
            contenedor.value = ajaxFlag.responseText;
        }
    };
    ajaxFlag.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajaxFlag.send(request);
}




// ENVIA LA SOLICITUD ENCONTRADA A TD_REGISTROS PARA DESPUES CALIFICAR
function send_post_page_sol(request, page) {
    var contenedor;
    //alert('Entra a esta funcion');
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// ENVIA DATOS POR AJAX PARA GUARDAR LA CALIFICACION DEL REGISTRO
function send_post_page(request, page) {
    var contenedor;
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            //alert(ajax.responseText)
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// MUESTRA EL SCRIPT DE VENTA
function ShowScript(script, solicitud, etapa) {
    request = "action=1";
    scriptMostrar = script;
    if (scriptMostrar == 1) { //Super Light  No Autom�tico
        send_post_page_n(request, "script", "modules.php?mod=agentes&op=Script_IN&sol=" + solicitud);
    } else {
//send_post_page_n(request,"script","modules.php?mod=agentes&op=Script_OUT&sol="+solicitud);
//send_post_page_n(request,"script","http://172.20.1.77/PagosFijos/cuestionarion.asp?surveyid=1&u_persona="+solicitud+"&u_registro="+solicitud+"&u_user=7&inicio=y");
    }


}

function ShowScript_V(script, solicitud, etapa) {
    request = "action=1";
    scriptMostrar = script;
    send_post_page_n(request, "script", "modules.php?mod=validacion&op=ScriptValidacion&sol=" + solicitud);
}

// MUESTRA EL SCRIPT DE VENTA
function ShowScript_GeneralIN() {
    request = "action=1";
    send_post_page_n(request, "script", "modules.php?mod=agentes&op=Script");
}

// CALIFICA EL NUMERO TELEFONICO
function califica_tel(valor, solicitud, contador, plan) {
    indice = document.getElementById("cont").value; //Cuenta el total de telefonos para el registro
    calificacion = valor.value;
    //etapa = document.frm1.id_etapa.value;
    telefono = document.getElementById('tel_' + contador).value;
    //request = "telefono="+telefono+"&calificacion="+calificacion+"&etapa="+etapa+"&solicitud="+solicitud;
    //send_post_page_califica_tel(request, "modules.php?mod=agentes&op=process_data&act=2");
    //alert(calificacion);
    swal(calificacion);

}

//ABRE VENTANA LLAMADA
function AbreVentana(boton, contador, nomina, tel, id_solicitud, extenagente, cc, u_telefono, u_zona) {
    u_telefono = typeof u_telefono !== 'undefined' ?  u_telefono : '';
    u_zona = typeof u_zona !== 'undefined' ?  u_zona : '';
    centro = readCookie('s_usr_centro');
    
    if (document.getElementById("Gif_" + contador)) {
        document.getElementById("Gif_" + contador).style.display = "block";

        setTimeout(function() {
            document.getElementById("Gif_" + contador).style.display = "none";
        }, 15000);
    }

    setTimeout(function() {
        document.getElementById("btnMarcar" + contador).disabled = false;
    }, 9000);

    switch (centro) {
        case "1"://ITQ Online
            var URL = "https://172.20.1.10/marcadoasistido/click2dial/tdcamexonline/marcadoasistido.php?employeeid=" + nomina + "&exten=01" + tel + "&sicallVarSolicitud=" + id_solicitud + "&extenagente=" + extenagente + "&centro=" + centro + "&cc=" + cc + "&schm=tdcamexonline&u_telefono="+u_telefono+"&u_zona="+u_zona;
            break;
        case "411": //ITR Online
            var URL = "https://172.20.1.10/marcadoasistido/click2dial/tdcamexonline_itr/marcadoasistido.php?employeeid=" + nomina + "&exten=01" + tel + "&sicallVarSolicitud=" + id_solicitud + "&extenagente=" + extenagente + "&centro=" + centro + "&cc=" + cc + "&schm=tdcamexonline&u_telefono="+u_telefono+"&u_zona="+u_zona;
            break;
    }
    
    document.getElementById("asistido").src = URL;
    swal("Marcando", "\n\n\Presiona <Enter> o da clic en \"Aceptar\" al recibir la llamada (o si no te contestan).", "success");
    document.getElementById('tel_0' + contador).focus();

    $.post("modules.php?mod=agentes&op=process_data&act=ODE=",{//81
            url_asistido:URL
        },function(data,status){
            
        });

    //Registra el nombre de la grabacion == 55
    $.post("modules.php?mod=agentes&op=process_data&act=NTU=",{
        nomina:nomina,
        telefono:tel,
        u_persona:id_solicitud
    },function(data,status){
    });
}

function Continuar(boton, telefonos, action, ispredictivo) {
    var suma = 0;
    var contacto = 0;
    var suma2 = 0;

    // obtener score buro
    var sb = '';
    var tkn = '';
    $('form[name="frm1"] table').each(function(){
        var clase = $(this).attr('class');

        if(clase=='cuestionario'){
            $(this).find('table tbody tr').each(function(){
                var tit_ = $(this).find('td:first b').text();
                var val_ = $(this).find('td:last').text();

                if(tit_ == 'Score Buro'){
                    sb = val_;
                }

                if(tit_.indexOf('TNKPAGE') != -1){
                    tkn = val_;
                }
            });
        }
    });

    for (i = 1; i <= telefonos; i++) {
        var tel = eval('document.frm1.tel_0' + i + '.value');
        if (tel != 0) {
            if (tel == 1010) {
                contacto += 1;
                if(eval('document.frm1.plan'+i) != null){
                    if(eval('document.frm1.plan'+i+'.value') == ""){
                        //alert("Favor seleccionar si es plan");
                        swal("Favor seleccionar si es plan");
                        boton.disabled = false;
                        return false;
                    }
                }
            } else {
                suma += 1;
            }
        }
    }

    if (contacto != 0) {
        if (document.frm1.producto_.value == "") {
            swal('Cuidado','Debes seleccionar un producto para continuar', 'warning');
            boton.disabled = false;
            return false;
        } else {
            document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&sb=' + sb + '&tkn=' + tkn;
            document.frm1.submit();
        }

    } else {
        if (suma != telefonos) {
            swal("¡Cuidado!", "Debes calificar lo(s) Telefono(s) disponibles para poder Abandonar", "info");
            boton.disabled = false;
            return false;
        }
    }

    if (ispredictivo == 1 && contacto == 0) {
        $(function() {
            $("#dialog-proceso").dialog({
                autoOpen: true,
                height: 150,
                width: 450,
                modal: true,
                closeOnEscape: false,
                open: function(event, ui) {
                    jQuery('.ui-dialog-titlebar-close').hide();
                }
            });
        });
    }
    
    document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&sb=' + sb + '&tkn=' + tkn;
    document.frm1.submit();

}



// ABANDONA EL REGISTRO SELECCIONADO
function Abandonar(boton,telefonos, action) {
    confirm_("¿Esta seguro de que deseas abandonar este registro?\nSolo usar para salir de la aplicacion",
        '',
        'modules.php?mod=agentes&op=process_data&act=' + action,
        'frm1'
    );
}

//INFORMA DE QUE LA LINEA ESTA OCUPADA PREDICTIVO.
function linea_ocupada_pred()
{
    //alert("linea ocupada");
    swal("linea ocupada");
    return false;
}

// ### ENVIA A LA PANTALLA DONDE CALIFICA LA LLAMADA QUE REALIZO EL CLIENTE,
function CalificarLlamada() {
    if (document.frm15.motivo_llamada.value == 0) {
        //alert('Seleccione una calificacion');
        swal('Seleccione una calificacion');
        return false;
    }
    document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=16';
    document.frm15.submit();
}

// CALIFICA EL NUEVO REGISTRO DE LA LLAMADA RECIBIDA
function cal_llamada(valor, registro) {
    calificacion = valor.value;
    request = "id_registro=" + registro + "&calificacion=" + calificacion;
    send_post_page_califica_tel(request, "modules.php?mod=agentes&op=process_data&act=12");

}


// CALIFICA EL NUEVO REGISTRO DE LA LLAMADA RECIBIDA
function ejecuta_flag(referente, valor) {
    request = "u_persona=" + referente + "&valor=" + valor;
    send_post_page_flag(request, "flag", "modules.php?mod=agentes&op=process_data&act=Mzg=");//38
}

// VALIDA LOS CAMPOS PARA EL INICIO DE SESSION
function ValidaLogin() {
    var id_user = document.getElementById("user").value;
    var pass_user = document.getElementById("password").value;
    var marcacion = document.frm1.marcacion.value;
    //var ext_user = document.getElementById("extension").value;

    if (id_user != "") {
        if (pass_user != "") {
            if(marcacion != "0"){
            //if (ext_user != "") {
              //  if (ext_user.length == 4) {
                    document.frm1.submit();
                    }else{
                        swal("Error", "Debe seleccionar el tipo de marcacion", "warning");
                     return false;
                     }
        } else {
            swal("Error", "Debes de capturar el campo Contraseña", "warning");
            return false;
        }
    } else {
        swal("Error", "Debes de capturar el campo Id Usuario.", "warning");
        return false;
    }
}


//REALIZA LA VALIDACION DE LA BUSQUEDA DE CLIENTES EN UNA NUEVA LLAMADA
function MotivoLlamada(nuevo, bandera) {

    if (nuevo == 1) {

        if (document.frm15.nombre.value == "" || document.frm15.paterno.value == "" || document.frm15.tdc.value == "" || document.frm15.telefono.value == "") {
            //alert('Captura los campos obligatorios.');
            swal('Captura los campos obligatorios.');
            document.frm15.nombre.focus();
            return false;
        }

        if (document.frm15.tdc.value != "") {

            if (!validatarjeta(document.frm15.tdc.value, "16 Digitos TC"))
                return false;
            if (!numeros(document.frm15.tdc, "TDC"))
                return false;
            if (!tamanos(document.frm15.tdc, "TDC", 16, 16))
                return false;
            if (document.frm15.tipo_tdc.value == 0) {
                //alert('Debes escoger que tipo de TDC es');
                swal('Debes escoger que tipo de TDC es');
                document.frm15.tipo_tdc.focus();
                return false;
            }
        } else {

            if (document.frm15.tipo_tdc.value != 0) {
                //alert('Falta capturar una TDC para escoger el tipo al que pertenece');
                swal('Falta capturar una TDC para escoger el tipo al que pertenece');
                document.frm15.tipo_tdc.focus();
                return false;
            }
        }

        if (document.frm15.telefono.value != "") {
            if (!numeros(document.frm15.telefono, "Telefono"))
                return false;
            if (!tamanos(document.frm15.telefono, "Telefono", 10, 10))
                return false;
        } else {
            //alert('El campo Telefono es obligatorio');
            swal('El campo Telefono es obligatorio');
            document.frm15.tipo_tdc.focus();
            return false;
        }
    }

    document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=11&nuevo=' + nuevo + '&bandera=' + bandera;
    document.frm15.submit();

}

//### CALIFICA LA LLAMADA SOBRE EL REGISTRO QUE INGRESAMOS O ABRE LA SOLICITUD SI NO TIENE VENTA.
function RegistroIncompleto(accion) {
    if (accion == 1) { // Boton califica llamada
        document.frm15.action = 'modules.php?mod=agentes&op=calificar_llamada'
    } else if (accion == 2) { // Boton solicitud
        //document.frm15.action = 'modules.php?mod=agentes&op=cuestionarioinbound'
        document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=19&nvo=0'
    } else if (accion == 3) {// Boton nuevo registro
        document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=19&nvo=1'
    } else if (accion == 4) {// Boton regresar
        document.frm15.action = 'modules.php?mod=agentes&op=nueva_llamada'
    }

    document.frm15.submit();
}

// REGRESAR A BUSQUEDA DE CLIENTE OUT
function NuevaLlamda() {
    document.frm15.action = 'modules.php?mod=agentes&op=nueva_llamada'
    document.frm15.submit();
}

// REALIZA LA ACCION DE BORRAR LO DE UN FORMULARIO
function LimpiaDatos() {
    document.frm11.reset();
}

//VALIDA EL NUMERO VERIFICADOR DE LA TDC
function PrefijoSS(tdc, campo) {
    var banprefijoss = true;
    Banco = 0;
    TDC_Cliente = tdc;
    numeroTarjeta = TDC_Cliente;
    arraytarjeta = new Array();
    numeroprefijos = '212121212121212';
    arrayprefijos = new Array();
    arrayproducto = new Array();
    prefijo = 0;
    dividendo = 0;
    verificador = 0;

    if (Banco == 8) {
        numeroTarjeta = 0 + numeroTarjeta;
        no_verificador = numeroTarjeta.substring(15, 16);
    } else {

        numeroTarjeta
        no_verificador = numeroTarjeta.substring(15, 16);
    }

    arraytarjeta = numeroTarjeta.split("");
    arrayprefijos = numeroprefijos.split("");
    for (i = 0; i < 15; i++) {
        prefijo += parseInt(validalongitudprefijos(parseInt(arraytarjeta[i]), parseInt(arrayprefijos[i])));
    }
    dividendo = prefijo % 10;
    if (dividendo == 0) {
        verificador = 0;
    }
    else {
        verificador = 10 - dividendo;
    }
    if (verificador == no_verificador) {
        banprefijoss = true;
    }
    else {
        //alert('Verifique los datos de la TDC para el campo " ' + campo + '", es incorrecto el numero verificador.');
        swal('Verifique los datos de la TDC para el campo " ' + campo + '", es incorrecto el numero verificador.');
        banprefijoss = false;
    }
    return banprefijoss;

}


function validalongitudprefijos(numtarjeta, numprefijo) {
    valor = numtarjeta * numprefijo;
    valor = valor + '';
    nuevovalor = 0;
    if (valor >= 10) {
        valor.split("");
        nuevovalor = parseInt(valor[0]) + parseInt(valor[1]);
    } else {
        nuevovalor = valor;
    }
    return nuevovalor;
}

//VALIDA QUE LOS BINES DE LA TDC SEAN CORRECTOS
function validatarjeta(tdc, campo) {
    bandera_telac = true;
    TDC_Cliente = tdc;
    validada = 100;

    if (TDC_Cliente.length == 16) {
        for (i = 0; i < (array_bines.length); i++) {
            Bines2 = eval(TDC_Cliente.substring(0, array_bines[i].toString().length));
            if (array_bines[i].toString() == Bines2) {
                validada = 0;
                break;
            }
        }

        if (validada == 100) {
            //alert('El prefijo de la TDC capturada en el campo "' + campo + '" no coincide con el prefijo del Banco.')
            swal('El prefijo de la TDC capturada en el campo "' + campo + '" no coincide con el prefijo del Banco.');
            bandera_telac = false;
        } else {
            bandera_telac = PrefijoSS(tdc, campo);
        }
    } else {
        //alert("La longitud de la TDC para el " + campo + " debe ser de 16 digitos");
        swal("La longitud de la TDC para el " + campo + " debe ser de 16 digitos");
        bandera_telac = false;
    }
    return bandera_telac;

}

//### BUSCA LA SOLICITUD QUE SE VA A VALIDAR
function BuscarSolicitud() {
    if (document.frm1.idsolicitud.value == "") {
        //alert('Debes capturar una solicitud');
        swal('Debes capturar una solicitud');
        document.frm1.idsolicitud.focus();
        return false;
    }
    if (!numeros(document.frm1.idsolicitud, "Numero de Solicitud"))
        return false;

    document.frm1.submit();
}

// REALIZA LA ACCION DE BORRAR LO DE UN FORMULARIO
function LimpiaDatosV() {
    document.frm1.reset();
}

// REALIZA LA VALIDACION DE LA SOLICITUD INBOUND
function ValidaSolicitud_Inbound() {

    if (document.frm12.nombre != null) {
        if (document.frm12.nombre.value == "") {
            //alert('El campo de "Nombre", no debe ir vacio');
            swal('El campo de "Nombre", no debe ir vacio');
            document.frm12.nombre.focus();
            return false;
        }
    }

    if (document.frm12.paterno != null) {
        if (document.frm12.paterno.value == "") {
            //alert('El campo de "Paterno", no debe ir vacio');
            swal('El campo de "Paterno", no debe ir vacio');
            document.frm12.paterno.focus();
            return false;
        }
    }

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            //alert('Debes selecionar un telefono de contacto o capturar el campo Otro')
            swal('Debes selecionar un telefono de contacto o capturar el campo Otro');
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            //alert('Ya tienes seleccionado un numero telefonico del combo')
            swal('Ya tienes seleccionado un numero telefonico del combo');
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            //alert("Ingrese una direccion de correo valida");
            swal("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar != null) {
        if (document.frm12.actualizar.value == 0) {
            //alert('Conteste si desea actualizar sus datos.');
            swal('Conteste si desea actualizar sus datos.');
            document.frm12.actualizar.focus();
            return false;
        } else {
            if (document.frm12.calificacion != null) {
                if (document.frm12.calificacion.value == 0) {
                    //alert('Selecciona una Calificacion');
                    swal('Selecciona una Calificacion');
                    document.frm12.calificacion.focus();
                    return false;
                }
                if (document.frm12.subcalificacion != null) {
                    if (document.frm12.subcalificacion.value == 0) {
                        //alert('Selecciona una Sub. Calificacion.');
                        swal('Selecciona una Sub. Calificacion.');
                        document.frm12.subcalificacion.focus();
                        return false;
                    }
                }
                if (document.frm12.rangopago != null) {
                    if (document.frm12.rangopago.value == 0) {
                        //alert('Selecciona el Rango de Pago.');
                        swal('Selecciona el Rango de Pago.');
                        document.frm12.rangopago.focus();
                        return false;
                    }
                }
            }

            if (document.frm12.edocta.value == 0) {
                //alert('La pregunta 4 es  obligatoria.');
                swal('La pregunta 4 es  obligatoria.');
                document.frm12.edocta.focus();
                return false;
            }
            if (document.frm12.actualizar.value == 1) {
                if (document.frm12.promo.value == 0) {
                    //alert('Constesta la pregunta 3')
                    swal('Constesta la pregunta 3');
                    return false;
                }

                if (document.frm12.mastdc.value == 0) {
                    //alert('Constesta la pregunta 5')
                    swal('Constesta la pregunta 5');
                    return false;
                }
            }
        }
    } else {
        if (document.frm12.calificacion != null) {
            if (document.frm12.calificacion.value == 0) {
                //alert('Selecciona una Calificacion');
                swal('Selecciona una Calificacion');
                document.frm12.calificacion.focus();
                return false;
            }
            if (document.frm12.subcalificacion != null) {
                if (document.frm12.subcalificacion.value == 0) {
                    //alert('Selecciona una Sub. Calificacion.');
                    swal('Selecciona una Sub. Calificacion.');
                    document.frm12.subcalificacion.focus();
                    return false;
                }
            }
            if (document.frm12.rangopago != null) {
                if (document.frm12.rangopago.value == 0) {
                    //alert('Selecciona el Rango de Pago.');
                    swal('Selecciona el Rango de Pago.');
                    document.frm12.rangopago.focus();
                    return false;
                }
            }
        }
    }

    if (document.frm12.ejecutivo_venta != null) {
        if (document.frm12.ejecutivo_venta.value == 0) {
            //alert('La pregunta 6 es obligatoria.');
            swal('La pregunta 6 es obligatoria.');
            document.frm12.rangopago.focus();
            return false;
        }

        if (document.frm12.ejecutivo_venta.value == 2) {
            if (document.frm12.calificacion.value == 525) {
                //alert('No puedes seleccionar esta calificacion "Firma Solicitud al Ejecutivo" cuando la pregunta 6 es "NO".');
                swal('No puedes seleccionar esta calificacion "Firma Solicitud al Ejecutivo" cuando la pregunta 6 es "NO".');
                document.frm12.ejecutivo_venta.focus();
                return false;
            }
        }

        if (document.frm12.folio_carta.value == "") {
            //alert('El cliente tiene que proporcionar este folio');
            swal('El cliente tiene que proporcionar este folio');
            document.frm12.folio_carta.focus();
            return false;
        }
    }


    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            //alert('Contesta SI o NO en la TDC 1');
            swal('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            //alert('Contesta SI o NO en la TDC 2');
            swal('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            //alert('Contesta SI o NO en la TDC 3');
            swal('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    //alert('Al menos una de las tres TDC debe ser inscripta');
                    swal('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        //alert('Al menos una de las dos TDC debe ser inscripta');
                        swal('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    //alert('La unica TDC que tiene debe ser inscripta');
                    swal('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }


    if (document.frm12.tdc != null) {
        if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
            return false;
        if (!numeros(document.frm12.tdc, "16 Digitos TdC"))
            return false;
        if (document.frm12.tdc.value != "") {
            if (!validatarjeta(document.frm12.tdc.value, "16 Digitos TdC"))
                return false;
        }
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;


    //alert('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".')
    swal('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".');

    document.frm12.submit();


}

// REALIZA LA VALIDACION DE LA SOLICITUD IN
function ValidaSolicitud_In() {

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            //alert('Debes selecionar un telefono de contacto o capturar el campo Otro')
            swal('Debes selecionar un telefono de contacto o capturar el campo Otro');
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            //alert('Ya tienes seleccionado un numero telefonico del combo')
            swal('Ya tienes seleccionado un numero telefonico del combo');
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            //alert("Ingrese una direccion de correo valida");
            swal("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar != null) {
        if (document.frm12.actualizar.value == 0) {
            //alert('Conteste si desea actualizar sus datos.');
            swal('Conteste si desea actualizar sus datos.');
            document.frm12.actualizar.focus();
            return false;
        } else {
            if (document.frm12.subcalificacion != null) {
                if (document.frm12.subcalificacion.value == 0) {
                    //alert('Selecciona una Sub. Calificacion.');
                    swal('Selecciona una Sub. Calificacion.');
                    document.frm12.subcalificacion.focus();
                    return false;
                }
            }

            if (document.frm12.edocta.value == 0) {
                //alert('La pregunta 3 es  obligatoria.');
                swal('La pregunta 3 es  obligatoria.');
                document.frm12.edocta.focus();
                return false;
            }
            if (document.frm12.actualizar.value == 1) {
                if (document.frm12.promo.value == 0) {
                    //alert('Constesta la pregunta 2')
                    swal('Constesta la pregunta 2');
                    return false;
                }

                if (document.frm12.mastdc.value == 0) {
                    //alert('Constesta la pregunta 4')
                    swal('Constesta la pregunta 4');
                    return false;
                }
            }
        }
    } else {
        if (document.frm12.subcalificacion != null) {
            if (document.frm12.subcalificacion.value == 0) {
                //alert('Selecciona una Sub. Calificacion.');
                swal('Selecciona una Sub. Calificacion.');
                document.frm12.subcalificacion.focus();
                return false;
            }
        }
    }

    if (document.frm12.nueva_tdc != null) {
        if (document.frm12.nueva_tdc.value == 0) {
            //alert('La pregunta " Ya recibio su nueva TdC" es Obligatoria');
            swal('La pregunta " Ya recibio su nueva TdC" es Obligatoria');
            document.frm12.nueva_tdc.focus();
            return false;
        }
    }



    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            //alert('Contesta SI o NO en la TDC 1');
            swal('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            //alert('Contesta SI o NO en la TDC 2');
            swal('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            //alert('Contesta SI o NO en la TDC 3');
            swal('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    //alert('Al menos una de las tres TDC debe ser inscripta');
                    swal('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        //alert('Al menos una de las dos TDC debe ser inscripta');
                        swal('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    //alert('La unica TDC que tiene debe ser inscripta');
                    swal('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }


    if (document.frm12.tdc != null) {
        if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
            return false;
        if (!numeros(document.frm12.tdc, "16 Digitos TdC"))
            return false;
        if (document.frm12.tdc.value != "") {
            if (!validatarjeta(document.frm12.tdc.value, "16 Digitos TdC"))
                return false;
        }
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;


    swal('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".');
    document.frm12.submit();


}

function NoProcesar(solicitud) {
    request = "solicitud=" + solicitud;
    send_post_page(request, "modules.php?mod=validacion&op=process_data&act=3");
}

function ProcesarValidacion() {
    if (document.frm2.nombre != null) {
        if (document.frm2.nombre.value == "") {
            swal('El campo de "Nombre", no debe ir vacio');
            document.frm2.nombre.focus();
            return false;
        }
    }

    if (document.frm2.paterno != null) {
        if (document.frm2.paterno.value == "") {
            swal('El campo de "Paterno", no debe ir vacio');
            document.frm2.paterno.focus();
            return false;
        }
    }
    if (document.frm2.tel_contacto.value == 0) {
        if (document.frm2.otro_contacto.value == "") {
            swal('Debes selecionar un telefono de contacto o capturar el campo Otro');
            document.frm2.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm2.otro_contacto.value != "") {
            document.frm2.otro_contacto.select();
            swal('Ya tienes seleccionado un numero telefonico del combo');
            return false;
        }
    }

    if (document.frm2.email.value != "") {
        var s = document.frm2.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {
            swal("Ingrese una direccion de correo valida");
            document.frm2.email.focus();
            return false;
        }
    }

    if (document.frm2.actualizar.value == 0) {
        swal('Conteste si desea actualizar sus datos.');
        document.frm2.actualizar.focus();
        return false;
    } else {

        if (document.frm2.edocta.value == 0) {
            swal('La pregunta 3 es  obligatoria.');
            document.frm2.edocta.focus();
            return false;
        }
        if (document.frm2.actualizar.value == 1) {

            if (document.frm2.promo.value == 0) {
                swal('Constesta la pregunta 2');
                return false;
            }

            if (document.frm2.mastdc.value == 0) {
                swal('Constesta la pregunta 4');
                return false;
            }

        }
    }

    if (document.frm2.ejecutivo_venta != null) {
        if (document.frm2.ejecutivo_venta.value == 0) {
            //alert('La pregunta 6 es obligatoria.');
            swal('La pregunta 6 es obligatoria.');
            document.frm2.rangopago.focus();
            return false;
        }

        if (document.frm2.folio_carta.value == "") {
            //alert('El cliente tiene que proporcionar este folio');
            swal('El cliente tiene que proporcionar este folio');
            document.frm2.folio_carta.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc1.value == 0) {
            //alert('Contesta SI o NO en la TDC 1');
            swal('Contesta SI o NO en la TDC 1');
            document.frm2.tdc1.focus();
            return false;
        }
    }

    if (document.frm2.tdc2 != null) {
        if (document.frm2.tdc2.value == 0) {
            //alert('Contesta SI o NO en la TDC 2');
            swal('Contesta SI o NO en la TDC 2');
            document.frm2.tdc2.focus();
            return false;
        }
    }

    if (document.frm2.tdc3 != null) {
        if (document.frm2.tdc3.value == 0) {
            //alert('Contesta SI o NO en la TDC 3');
            swal('Contesta SI o NO en la TDC 3');
            document.frm2.tdc3.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc2 != null) {
            if (document.frm2.tdc3 != null) {
                if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2 && document.frm2.tdc3.value == 2) {
                    //alert('Al menos una de las tres TDC debe ser inscripta');
                    swal('Al menos una de las tres TDC debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm2.tdc1 != null && document.frm2.tdc2 != null) {
                    if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2) {
                        //alert('Al menos una de las dos TDC debe ser inscripta');
                        swal('Al menos una de las dos TDC debe ser inscripta');
                        document.frm2.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm2.tdc1 != null) {
                if (document.frm2.tdc1.value == 2) {
                    //alert('La unica TDC que tiene debe ser inscripta');
                    swal('La unica TDC que tiene debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm2.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm2.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_celular, "Telefono Celular"))
        return false;

    //alert('La solicitud fue procesada con exito!.');
    swal('La solicitud fue procesada con exito!.');
    document.frm2.submit();
}

// REALIZA LA VALIDACION DE LA SOLICITUD
function ValidaSolicitud() {

    if (document.frm2.tel_contacto.value == 0) {
        if (document.frm2.otro_contacto.value == "") {
            //alert('Debes selecionar un telefono de contacto o capturar el campo Otro');
            swal('Debes selecionar un telefono de contacto o capturar el campo Otro');
            document.frm2.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm2.otro_contacto.value != "") {
            document.frm2.otro_contacto.select();
            //alert('Ya tienes seleccionado un numero telefonico del combo');
            swal('Ya tienes seleccionado un numero telefonico del combo');
            return false;
        }
    }

    if (document.frm2.email.value != "") {
        var s = document.frm2.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            //alert("Ingrese una direccion de correo valida");
            swal("Ingrese una direccion de correo valida");
            document.frm2.email.focus();
            return false;
        }
    }

    if (document.frm2.actualizar.value == 0) {
        //alert('Conteste si desea actualizar sus datos.');
        swal('Conteste si desea actualizar sus datos.');
        document.frm2.actualizar.focus();
        return false;
    } else {
        if (document.frm2.subcalificacion != null) {
            if (document.frm2.subcalificacion.value == 0) {
                //alert('Selecciona una Sub. Calificacion.');
                swal('Selecciona una Sub. Calificacion.');
                document.frm2.subcalificacion.focus();
                return false;
            }
        }

        if (document.frm2.edocta.value == 0) {
            //alert('La pregunta 3 es  obligatoria.');
            swal('La pregunta 3 es  obligatoria.');
            document.frm2.edocta.focus();
            return false;
        }
        if (document.frm2.actualizar.value == 1) {

            if (document.frm2.promo.value == 0) {
                //alert('Constesta la pregunta 2');
                swal('Constesta la pregunta 2');
                return false;
            }

            if (document.frm2.mastdc.value == 0) {
                //alert('Constesta la pregunta 4');
                swal('Constesta la pregunta 4');
                return false;
            }

        }
    }


    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc1.value == 0) {
            //alert('Contesta SI o NO en la TDC 1');
            swal('Contesta SI o NO en la TDC 1');
            document.frm2.tdc1.focus();
            return false;
        }
    }

    if (document.frm2.tdc2 != null) {
        if (document.frm2.tdc2.value == 0) {
            //alert('Contesta SI o NO en la TDC 2');
            swal('Contesta SI o NO en la TDC 2');
            document.frm2.tdc2.focus();
            return false;
        }
    }

    if (document.frm2.tdc3 != null) {
        if (document.frm2.tdc3.value == 0) {
            //alert('Contesta SI o NO en la TDC 3');
            swal('Contesta SI o NO en la TDC 3');
            document.frm2.tdc3.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc2 != null) {
            if (document.frm2.tdc3 != null) {
                if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2 && document.frm2.tdc3.value == 2) {
                    //alert('Al menos una de las tres TDC debe ser inscripta');
                    swal('Al menos una de las tres TDC debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm2.tdc1 != null && document.frm2.tdc2 != null) {
                    if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2) {
                        //alert('Al menos una de las dos TDC debe ser inscripta');
                        swal('Al menos una de las dos TDC debe ser inscripta');
                        document.frm2.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm2.tdc1 != null) {
                if (document.frm2.tdc1.value == 2) {
                    //alert('La unica TDC que tiene debe ser inscripta');
                    swal('La unica TDC que tiene debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm2.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm2.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_celular, "Telefono Celular"))
        return false;

    document.frm2.submit();


}


// REALIZA LA VALIDACION DE LA SOLICITUD IN
function ValidaSolicitud_PP() {

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            //alert('Debes selecionar un telefono de contacto o capturar el campo Otro');
            swal('Debes selecionar un telefono de contacto o capturar el campo Otro');
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            //alert('Ya tienes seleccionado un numero telefonico del combo');
            swal('Ya tienes seleccionado un numero telefonico del combo');
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            //alert("Ingrese una direccion de correo valida");
            swal("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar.value == 0) {
        //alert('Conteste si desea actualizar sus datos.');
        swal('Conteste si desea actualizar sus datos.');
        document.frm12.actualizar.focus();
        return false;
    } else {
        if (document.frm12.subcalificacion != null) {
            if (document.frm12.subcalificacion.value == 0) {
                //alert('Selecciona una Sub. Calificacion.');
                swal('Selecciona una Sub. Calificacion.');
                document.frm12.subcalificacion.focus();
                return false;
            }

            if (document.frm12.subcalificacion.value == 20 || document.frm12.subcalificacion.value == 29) {
                var a = 0;
                var ArreFecha = new Array();
                var ArrePegunta = new Array();

                if (document.frm12.fec_comp != null) {
                    ArreFecha[a] = document.frm12.fec_comp.value;
                    ArrePegunta[a] = "Fecha Compromiso";
                    a++;
                }

                for (a = 0; a < ArreFecha.length; a++) {
                    if (!isDate2(ArreFecha[a], "DD/MM/AAAA") && ArreFecha[a].length > 0) {
                        //alert("ERROR en la Pregunta \n\n--   " + ArrePegunta[a] + "   --\n\n FORMATO: DD/MM/AAAA ");
                        swal("ERROR en la Pregunta \n\n--   " + ArrePegunta[a] + "   --\n\n FORMATO: DD/MM/AAAA ");
                        return false;
                        break;
                    }
                }
                if (document.frm12.fec_comp.value == "") {
                    //alert('Para esta Sub. Calificacion: "PAGARA DE INMEDIATO", debes capturar la fecha compromiso.');
                    swal('Para esta Sub. Calificacion: "PAGARA DE INMEDIATO", debes capturar la fecha compromiso.');
                    document.frm12.fec_comp.focus();
                    return false;
                }
            }
        }

        if (document.frm12.rangopago != null) {
            if (document.frm12.rangopago.value == 0) {
                //alert('Llene la pregunta de "Cuanto va a pagar?" o "Cuanto pago?".');
                swal('Llene la pregunta de "Cuanto va a pagar?" o "Cuanto pago?".');
                document.frm12.rangopago.focus();
                return false;
            }
        }

        if (document.frm12.edocta.value == 0) {
            //alert('La pregunta 3 es  obligatoria.');
            swal('La pregunta 3 es  obligatoria.');
            document.frm12.edocta.focus();
            return false;
        }

        if (document.frm12.actualizar.value == 1) {

            if (document.frm12.promo.value == 0) {
                //alert('Constesta la pregunta 2');
                swal('Constesta la pregunta 2');
                return false;
            }

            if (document.frm12.mastdc.value == 0) {
                //alert('Constesta la pregunta 4');
                swal('Constesta la pregunta 4');
                return false;
            }
        }
    }


    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            //alert('Contesta SI o NO en la TDC 1');
            swal('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            //alert('Contesta SI o NO en la TDC 2');
            swal('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            //alert('Contesta SI o NO en la TDC 3');
            swal('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    //alert('Al menos una de las tres TDC debe ser inscripta');
                    swal('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        //alert('Al menos una de las dos TDC debe ser inscripta');
                        swal('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    //alert('La unica TDC que tiene debe ser inscripta');
                    swal('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
        return false;
    if (!numeros(document.frm12.tdc, "16 Digitos TdC"))
        return false;
    if (document.frm12.tdc.value != "") {
        if (!validatarjeta(document.frm12.tdc.value, "16 Digitos TdC"))
            return false;
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;

    //alert('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".')
    swal('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".');
    document.frm12.submit();
}

// VALIDA QUE LOS CAMPOS SEAN SOLO DE TIPO NUMERICO
function numeros(campo, nombre) {
    var valor
    var numeros
    if (campo != null) {
        if (campo.value != "") {
            valor = campo.value;
            numeros = "0123456789";
            for (i = 0; i < valor.length; i++) {
                if (numeros.indexOf(valor.substring(i, i + 1)) < 0) {
                    //alert("El campo \"" + nombre + "\" debe tener solamente numeros sin espacios");
                    swal("El campo \"" + nombre + "\" debe tener solamente numeros sin espacios");
                    campo.select();
                    return false;
                }
            }
        }
    }
    return true;
}

// VALIDA LA EDAD DE LOS CONDUCTORES
function validarAdulto(edad, campo) {

    dateUser = edad;
    anioUser = dateUser;
    var dinami_edad = 0;

    dinami_edad = 95;

    if (edad < 18) {
        //alert('El usuario es menor de edad, tiene ' + edad + ' años. En el campo' + campo);
        swal('El usuario es menor de edad, tiene ' + edad + ' años. En el campo' + campo);
        return false;
    } else {
        if (edad <= dinami_edad) {
            return true;
        } else {
            //alert('El usuario NO tiene la edad requerida, tiene ' + anioUser + ' años. En el campo' + campo);
            swal('El usuario NO tiene la edad requerida, tiene ' + anioUser + ' años. En el campo' + campo);
            return false;
        }
    }

}

//VALIDA LOS TAMaños DE LOS DIFERENTES CAMPOS
function tamanos(campo, nombrecampo, log_min, log_max) {
    var a = 0;
    var contDigitos = 0;
    var Arretamano = new Array();
    var ArrePeguntatam = new Array();
    var Arrelongitudmin = new Array();
    var Arrelongitudmax = new Array();
    var arreNumDigitos = new Array();
    var arreNumDigitosTexto = new Array();
    //var banderatamanos=true;

    if (campo != null) {
        Arretamano[a] = campo.value.length;
        ArrePeguntatam[a] = nombrecampo;
        Arrelongitudmin[a] = log_min;
        Arrelongitudmax[a] = log_max;
        a++;
    }

    contDigitos = 0;

    for (a = 0; a < Arretamano.length; a++) {
        if ((Arretamano[a] < Arrelongitudmin[a] && Arretamano[a] > 0) || (Arretamano[a] > Arrelongitudmax[a] && Arretamano[a] > 0)) {
            contDigitos = arreNumDigitos.length;
            if (Arrelongitudmin[a] == Arrelongitudmax[a]) {
                //alert(ArrePeguntatam[a] + "  --\n\n Longitud debe ser igual a " + Arrelongitudmax[a]);
                swal(ArrePeguntatam[a] + "  --\n\n Longitud debe ser igual a " + Arrelongitudmax[a]);
            } else {
                //alert(ArrePeguntatam[a] + "  --\n\n Longitud entre " + Arrelongitudmin[a] + " y " + Arrelongitudmax[a]);
                swal(ArrePeguntatam[a] + "  --\n\n Longitud entre " + Arrelongitudmin[a] + " y " + Arrelongitudmax[a]);
            }
            return false;
            break;
        }
    }

    return true;
}



//  LIMITA EL NUMERO DE CARACTERES PERMITIDOS EN EL TEXTAREA DE COMENTARIOS
function limita_texto(limitField, limitCount, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } else {
        limitCount.value = limitNum - limitField.value.length;
    }
}

// REALIZA EL PROCESO DE AGENDAR EL REGISTRO  #####
function Agenda_registro(/*action,ispredictivo*/action, hora, nombre, solicitud,ispredictivo) {
    if (document.frm1.comentarios.value == "") {
        swal('Cuidado','Debes capturar los comentarios para este registro', 'warning');
        return false;
    } else if (document.frm1.fecha_agenda.value == "") {
        swal('Debes capturar la fecha en el que se agenda el registro');
        return false;
    }

    // Fecha de la agenda no permite dias anteriores
    anio = document.frm1.fecha_agenda.value.substring(6, 10);
    mes = document.frm1.fecha_agenda.value.substring(3, 5);
    dia = document.frm1.fecha_agenda.value.substring(0, 2);
    today = mes + '/' + dia + '/' + anio

    var fecha_cita = new Date(today);
    var now_date = new Date();
    var max_date = new Date();

    if (fecha_cita.getDay() == 0) {
        //alert("La fecha seleccionada para la agenda no es un dia habil");
        swal("La fecha seleccionada para la agenda no es un dia habil");
        return false;
    }

    now_date.setDate(now_date.getDate() - 1);

    if (fecha_cita < now_date) {
        //alert("La fecha de la agenda no puede ser anterior al dia de hoy");
        swal("La fecha de la agenda no puede ser anterior al dia de hoy");
        return false
    }

    max_date.setDate(max_date.getDate() + 15);

    if (fecha_cita > max_date) {
        swal("La fecha de la agenda no puede mayor a 15 dias");
        return false
    }
    
    confirm_(
        "Se agendara el registro " + solicitud + " de " + nombre + " a las " + hora,
        "Registro agendado correctamente",
        'modules.php?mod=agentes&op=process_data&act=' + action,
        'frm1',
        ispredictivo
    );
}

function redirige(action_, form_, ispredictivo_){
    if(ispredictivo_ == 1){
        $(function(){
            $( "#dialog-proceso" ).dialog({
                autoOpen: true,
                height: 150,
                width: 450,
                modal: true,
                closeOnEscape: false,
                resizable: false,
                position: {my: "center"},
                draggable: false,
                open: function(event, ui){
                    jQuery('.ui-dialog-titlebar-close').hide();
                }
            });
        });
    }

    $('form[name="'+form_+'"]').attr('action', action_);
    setTimeout(function(){
        $('form[name="'+form_+'"]').submit();
    },300);
}


// CANCELA LA ACCION DE AGENDAR REGISTRO
function Cancelar() {
    document.frm3.action = 'modules.php?mod=agentes&op=process_data&act=1'
    document.frm3.submit();
}

// REGRESAR A BUSQUEDA DE CLIENTE IN
function RegresarBusqueda(solicitud, etapa) {
    if (solicitud == 0) {
        document.frm12.action = 'modules.php?mod=agentes&op=index'
        document.frm12.submit();
    } else {
        document.frm12.action = 'modules.php?mod=agentes&op=process_data&act=13&etapa=' + etapa
        document.frm12.submit();
    }
}

// ELIMINA EL REGISTRO AGENDADO
function Elimina_agendado() {
    document.frm3.action = 'modules.php?mod=agentes&op=process_data&act=1'
    document.frm3.submit();
}

function Atras() {
    javascript:history.back();
//javascript:history.back(alert("Este usuario ya existe"));
}

// ACTIVAR SESION DEL USUARIO
function Activar() {
    document.getElementById('resp_act').innerHTML = "";
    if (document.frm1.s_usr_id.value == "") {
        //alert('Debes capturar el numero de nomina del usuario');
        swal('Debes capturar el numero de nomina del usuario');
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";
        s_usr_id = document.frm1.s_usr_id.value;
        request = "s_usr_id=" + s_usr_id;
        send_post_page_n(request, "resp_act", "modules.php?mod=nomina&op=process_data&act=1");
    }

}


// ASIGNACION DE VENTAS
function Busca_Venta() {
    if (document.frm11.id_solicitud.value == "") {
        //alert('Debes capturar el numero de Solicitud.');
        swal('Debes capturar el numero de Solicitud.');
        return false;
    } else {
        id_solicitud = document.frm11.id_solicitud.value;
        document.frm11.action = 'modules.php?mod=supervisor&op=resultado_venta&sol=' + id_solicitud
        document.frm11.submit();
    }

}

// MUSTRA LA LISTA DE LOS USUARIOS DEL SISTEMA
function Buscar_usuarios() {
    if (document.frm1.nombre.value == "" && document.frm1.id_usuario.value == "") {
        //alert('Debes capturar por lo menos un campo para realizar la busqueda');
        swal('Debes capturar por lo menos un campo para realizar la busqueda');
        return false;
    } else {
        document.frm1.submit();
    }
}

// DA UN SALTO A LA PAGINA ANTERIOR
function Atras() {
    history.back();
}

//SELECCIONA EL ELEMENTO DE UNA BUSQUEDA
function select_elem(objlink, id) {
    if (selection)
        selection.style.fontWeight = 'normal';
    document.fmr2.idSelected.value = id;
    selection = objlink;
    selection.style.fontWeight = 'bold';
    document.getElementById("linkeditar").style.display = 'inline';
    document.getElementById("linknuevo").style.display = 'inline';
}

// VALIDACIONES PARA MOSTRAR EL RERPORTE DE PRODUTIVIDAD
function Mostrar_Reporte() {
    //document.getElementById('resp_act').style.display = "none";

    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        //alert('Los campos de fecha estan vacios');
        swal('Los campos de fecha estan vacios');
        return false;
    } else {

        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }
        document.getElementById('resp_act').style.display = "inline";
        tipo_reporte = document.frm1.tipo_reporte.value;

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;

        turno = 0;
        request = "tipo_rep=" + tipo_rep + "&fecha_del=" + fecha_del + "&fecha_al=" + fecha_al + '&tipo_reporte=' + tipo_reporte;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=1");
    }
}

// VALIDACIONES PARA MOSTRAR EL RERPORTE DE PRODUTIVIDAD X ZONA Y ETAPA
function Mostrar_Reporte_P() {
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        //alert('Los campos de fecha estan vacios');
        swal('Los campos de fecha estan vacios');
        return false;
    } else {

        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;

        turno = 0;
        document.frm1.action = 'modules.php?mod=supervisor&op=mostrar_rp'
        document.frm1.submit();
    }
}

//VALIDA EL FORMULARIO PARA MOSTRAR EL LAYOUT
function Mostrar_Layout() {
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        //alert('Los campos de fecha estan vacios.');
        swal('Los campos de fecha estan vacios.');
        return false;
        /*}else if(document.frm1.etapa_layout.value == 0){
         alert('Seleccione un "Tipo de LayOut" para mostrarlo.');
         return false;*/
    } else {
        document.frm1.mostrar_layout.style.display = "none";
        document.frm1.submit();
    }
}

//HABILITA LA OPCION EDITAR DEL MODULO DE ABC USUARIOS
function select(object, id) {
    if (selection)
        selection.style.fontWeight = 'normal';
    document.frm2.idSelected.value = id;
    selection = object;
    selection.style.fontWeight = 'bold';
    document.getElementById("linkeditar").style.display = 'inline';
}

// MUESTRA EL FORMULARIO PARA EDITAR EL REGISTRO SELECCIONADO
function edit_data() {
    document.frm2.submit();
}

// VALIDA EL FORMULARIO PARA LA EDICION DEL USUARIO
function valida_edicion_usuario(dinamic_var) {

    if (dinamic_var == 1) {
        if (document.frm1.idSelected.value == "") {
            swal('Error', 'Debes capturar el campo Id Usuario', 'warning');
            return false;
        }
    }

    if (document.frm1.nombre.value == "") {
        //alert('Debes capturar el nombre del usuario');
        swal('Debes capturar el nombre del usuario');
        return false;
    } else if (document.frm1.perfil.value == 0) {
        //alert('Debes seleccionar el perfil del usuario');
        swal('Debes seleccionar el perfil del usuario');
        return false;
    }

    if (dinamic_var == 1) {
        if (document.frm1.contrasena.value.length == 0 || document.frm1.re_contrasena.value.length == 0) {
            //alert('Debes capturar los siguientes campos:\n -Contraseña.\n -Reescribir contraseña.');
            swal('Debes capturar los siguientes campos:\n -Contraseña.\n -Reescribir contraseña.');
            return false;
        }
    }

    if (document.frm1.contrasena.value.length != 0) {
        if (document.frm1.re_contrasena.value.length == 0) {
            //alert('Debes capturar los 2 campos de contraseña');
            swal('Debes capturar los 2 campos de contraseña');
            return false;
        }
    } else {
        if (document.frm1.re_contrasena.value.length != 0) {
            //alert('Debes capturar los 2 campos de contraseña');
            swal('Debes capturar los 2 campos de contraseña');
            return false;
        }
    }

    if (document.frm1.contrasena.value.length != 0 && document.frm1.re_contrasena.value.length != 0) {
        if (document.frm1.contrasena.value != document.frm1.re_contrasena.value) {
            //alert('Las contraseñas no coinciden');
            swal('Las contraseñas no coinciden');
            return false;
        }
    }

    document.frm1.submit();
}

// HABILITA LA LISTA DE SUPERVISORES PARA CUANDO EL PERFIL ES DE AGENTE
function muestra_super(obj) {
    if (obj.value == "A" || obj.value == "AI") {
        document.getElementById('super').style.display = 'inline';
    } else {
        document.getElementById('super').style.display = 'none';
    }
}


//ENVIA AL FORMULARIO PARA DAR DE ALTA EL USUARIO
function nuevo_usuario() {
    document.location = 'modules.php?mod=nomina&op=nuevo_usuario';
}


//ASIGAN UN NUEVO AGENTE A UNA SOLICITUD YA PROCESADA
function Nvo_Agente() {

    if (document.frm3.nuevo_agente.value == null || document.frm3.nuevo_agente.value == 0) {
        //alert('Captura el numero de Nomina del nuevo agente');
        swal('Captura el numero de Nomina del nuevo agente');
        document.frm3.nuevo_agente.focus();
        return false;
    }

    if (!tamanos(document.frm3.nuevo_agente, "Nomina del Nuevo Agente", 3, 6))
        return false;
    if (!numeros(document.frm3.nuevo_agente, "Nomina del Nuevo Agente"))
        return false;

    document.frm3.action = 'modules.php?mod=supervisor&op=process_data&act=2'
    document.frm3.submit();
}

function AsignaZona(zona, usuario, obj) {
    if (obj.checked) {
        //alert('Agregar al usuario '+ usuario+'de la zona-->'+zona)
        calificacion = 1;
    } else {
        //alert('Quitar al usuario '+ usuario+'de la zona-->'+zona)
        calificacion = 2;
    }

    request = "izona=" + zona + "&iusr_id=" + usuario + "&calificacion=" + calificacion;
    send_post_page_n(request, "showproc", "modules.php?mod=mesa_control&op=process_data&act=4");


}

function Sub_calif(obj, solicitud, etapa) {
    calif = obj.value;

    document.getElementById('sub_calif').innerHTML = "";
    document.getElementById('sub_calif').style.display = "inline";

    request = "calif=" + calif + "&id_solicitud=" + solicitud + "&id_etapa=" + etapa;
    send_post_page_n(request, "sub_calif", "modules.php?mod=agentes&op=process_data&act=17");
}

//SELECCIONA  TODAS LAS ZONAS
function Todas_Z() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s <= long_; s++) {
        //alert(''+eval('form['+s+'].name')); // Para debugear el codigo
        eval('document.frm1.id_zona' + s).checked = true;
    }
}

//QUITA LA SELECCION A   TODAS LAS ZONAS
function Ning_Z() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s < long_; s++) {
        eval('form.id_zona' + s).checked = false;
    }
}

//SELECCIONA  TODAS LAS ETAPA
function Todas_E() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s <= long_; s++) {
        //alert(''+eval('form['+s+'].name'));
        eval('document.frm1.id_etapa' + s).checked = true;
    }
}

//QUITA LA SELECCION A  TODAS LAS ETAPA
function Ning_E() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s < long_; s++) {
        eval('form.id_etapa' + s).checked = false;
    }
}

//##### REALIZA LA VALIDACION DE LOS CAMPOS OBLIGATORIOS PARA INICIAR LA BUSQUEDA
function BuscarCliente() {

    if (document.frm1.solicitud.value == "" && document.frm1.nombre.value == "" && document.frm1.paterno.value == "" && document.frm1.materno.value == "" && document.frm1.telefono.value == "") {
        swal('Cuidado', 'Debes capturar por lo menos un campo para iniciar la busqueda.', 'warning');
        return false;
    }

    if (document.frm1.telefono != null) {
        if (!numeros(document.frm1.telefono, "Telefono"))
            return false;
        if (!tamanos(document.frm1.telefono, "Telefono", 10, 10))
            return false;
    }

    if (document.frm1.solicitud != null) {
        if (!numeros(document.frm1.solicitud, "Solicitud"))
            return false;
        if (!tamanos(document.frm1.solicitud, "Solicitud", 1, 10))
            return false;
    }

    document.frm1.submit();
}



//##### REALIZA LA VALIDACION DE LOS CAMPOS OBLIGATORIOS PARA INICIAR LA BUSQUEDA DE DATOS
function BuscarDatos() {
    document.frm1.submit();
}

//##### OBTIENE LOS DATOS DEL REGISTRO BUSCADO Y LO MUESTRA EN PANTALLA
function mostrar_registro(u_persona, registro,action) {
    let bloqueo = 0;
      if (bloqueo == 1) {
          swal('Atencion','La calificacion/Bloqueo de este registro no permite mostrar mas informacion.', 'warning');
          return false;
      }else{
          document.frm1.u_persona.value = u_persona;
          document.frm1.u_registro.value = registro;
      }


    confirm_(
        "Se mostrara el siguiente registro en pantalla\nDeseas Continuar?",
        "",
        "modules.php?mod=agentes&op=process_data&act=" + action,
        'frm1'
    );
}

//##### VALIDA EL FORMULARIO PARA LA CAPTURA DE UN NUEVO CLIENTE
function nuevo_registro(bandera,boton) {
    if (bandera == 1) {
        confirm_(
            "Se va a dar de alta un nuevo cliente\nDeseas Continuar?",
            "",
            "modules.php?mod=agentes&op=nuevoregistro",
            'frm1'
        );
    } else {
        if (document.frm1.nombre.value == "") {
            swal('Error', 'Debes capturar el campo Nombre (s)', 'warning');
            document.frm1.nombre.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.paterno.value == "") {
            swal('Error','Debes capturar el campo Paterno', 'warning');
            document.frm1.paterno.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.telefono.value == "") {
            swal('Error','Debes capturar el campo Telefono', 'warning');
            document.frm1.telefono.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.lada.value == "") {
            swal('Error','Debes capturar el campo Lada', 'warning');
            document.frm1.lada.focus();
            boton.disabled = false;
            return false;
        }
        //414, 419, 427, 441, 442, 448, 487.
        tel = document.frm1.lada.value+document.frm1.telefono.value;
        if(tel.substring(0,3) == '414'||
            tel.substring(0,3) == '419'||
            tel.substring(0,3) == '427'||
            tel.substring(0,3) == '441'||
            tel.substring(0,3) == '442'||
            tel.substring(0,3) == '448'||
            tel.substring(0,3) == '487'){
            swal('Error', 'La lada no es permitida', 'warning');
            document.frm1.lada.focus();
            boton.disabled = false;
            return false;
        }

        if (!tamanos(document.frm1.telefono, "Solo se permite de 7 u 8 digitos para el campo Telefono", 7, 8))
            return false;
        if (!tamanos(document.frm1.lada, "Solo se permite 2 o 3 digitos para el campo lada", 2, 3))
            return false;

        if (!numeros(document.frm1.telefono, "Telefono"))
            return false;
        if (!numeros(document.frm1.lada, "Lada"))
            return false;


        if ((document.frm1.telefono.value.length + document.frm1.lada.value.length) != 10) {
            //alert('La suma de lada y telefono es a 10 posiciones');
            swal('La suma de lada y telefono es a 10 posiciones');
            return false;
        } else {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=OQ==";
            document.frm1.submit();
        }
    }
}

//##### VALIDA EL FORMULARIO PARA LA CAPTURA DE UN NUEVO CLIENTE
function actualiza_nombre() {

    if (document.frm1.nombre.value == "") {
        swal('Debes capturar el campo Nombre (s)');
        document.frm1.nombre.focus();
        return false;
    } else if (document.frm1.paterno.value == "") {
        swal('Debes capturar el campo Paterno');
        document.frm1.paterno.focus();
        return false;
    }else {
        document.frm1.action = "modules.php?mod=agentes&op=process_data&act=NDQ=";
        document.frm1.submit();
    }
}

function datos_solicitud() {
    if (document.frm1.txt_solicitud.value == "") {
        //alert('Debes capturar el número de solicitud');
        swal('Debes capturar el número de solicitud');
        document.frm1.txt_solicitud.focus();
        return false;
    } else if (document.frm1.txt_producto.value == "") {
        //alert('Debes capturar el número de producto (generalmente 1)');
        swal('Debes capturar el número de producto (generalmente 1)');
        document.frm1.txt_producto.focus();
        return false;
    }

    if (!numeros(document.frm1.txt_solicitud, "Solicitud"))
        return false;
    if (!numeros(document.frm1.txt_producto, "Producto"))
        return false;

    document.frm1.action = "modules.php?mod=agentes&op=process_data&act=MzE=";
    document.frm1.submit();
}


function ActivaZonas(zona, obj) {
    libres = eval('document.frm1.libres' + zona + '.value')
    abandonados = eval('document.frm1.abandonados' + zona + '.value')


    if (obj.checked) {
        if (libres == 0 && abandonados == 0) {
            //alert('No puedes activar una zona sin registros libres y abandonados');
            swal('No puedes activar una zona sin registros libres y abandonados');
            obj.checked = false;
            return false;
        }
        calificacion = 1;
    } else {
        calificacion = 2;
    }

    request = "izona=" + zona + "&calificacion=" + calificacion;
    send_post_page_n(request, "showproc", "modules.php?mod=mesa_control&op=process_data&act=5");
}


function boton_der_deshabilitado() {
    /*
     var message = "";

     function clickIE(){
     if (document.all){
     (message);
     return false;
     }
     }

     function clickNS(e){
     if (document.layers || (document.getElementById && !document.all)){
     if (e.which == 2 || e.which == 3){
     (message);
     return false;
     }
     }
     }

     if (document.layers){
     document.captureEvents(Event.MOUSEDOWN);
     document.onmousedown = clickNS;
     }else{
     document.onmouseup = clickNS;
     document.oncontextmenu = clickIE;
     }

     document.oncontextmenu = new Function("return false")
     return true;*/
}

function actualizar() {
    document.onkeydown = function() {
        if (window.event && (window.event.keyCode == 116)) {
            window.event.keyCode = 505;
        }
        if (window.event && window.event.keyCode == 505) {
            return false;
        }
    }
}


//FUNCION PARA HABILITAR LOS DIFERENTES BOTONES DEPENDIENDO DEL REGISTRO
function habilita_sol(base) {
    document.frm15.btn_solicitud.disabled = true;
    if (base == 1) {
        document.frm15.btn_solicitud.disabled = false;
    }
}


function isDate2(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "DD/MM/AAAA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[1];
        year = matchArray[5];
    }

    if (year.length < 4) {
        return false;
    } // chequeo de numero de digitos en A?
    if (year >= 2079) {
        return false;
    } // chequeo del A? para smalldate
    if (month < 1 || month > 12 || month.length < 2) {
        return false;
    } // checa rango mes
    if (day < 1 || day > 31 || day.length < 2) {
        return false;
    }
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    }
    if (month == 2) { // check para febrero 29
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}

/*
 function fechas(){
 var a=0;
 var ArreFecha = new Array();
 var ArrePegunta = new Array();
 //var banderaFechas=true;

 if(document.frm12.fec_comp !=null){
 ArreFecha[a] = document.frm12.fec_comp.value;
 ArrePegunta[a] = "Fecha Compromiso";
 a++;
 }

 for(a=0;a<ArreFecha.length;a++){
 if(!isDate2(Trim(ArreFecha[a]),"DD/MM/AAAA") && Trim(ArreFecha[a]).length > 0){
 alert("ERROR en la Pregunta \n\n--   "+ ArrePegunta[a] +"   --\n\n FORMATO: DD/MM/AAAA ")
 return false;
 break;
 }
 }

 }*/

//REALIZA LA BUSQUEDA DE CODIGOS POSTALES
function search_cp(p_cp) {
    if (p_cp == null) {
        re_cp = 0;
    } else {
        re_cp = p_cp
    }
    var re_cp;
    var myvar;
    myvar = "top=400,left=550,resizable=no,width=680,height=350,toolbar=no,location=0,status=no,directories=no,scrollbars=yes,menubar=no"
    cp_window = window.open("modules.php?mod=agentes&op=codigos_postales&p_cp=" + re_cp, "cp_window", myvar);

}

//### CALCULA EL RFC DEL CLIENTE
function calcula_rfc() {
    if (document.getElementById('nombre').value == "") {
        //alert("Debes capturar el Nombre");
        swal("Debes capturar el Nombre");
        return false;
    } else if (document.getElementById('paterno').value == "") {
        //alert("Debes capturar el apellido Paterno");
        swal("Debes capturar el apellido Paterno");
        return false;
    } else if (document.getElementById('fecha_nac').value == "") {
        //alert("Debes capturar la fecha de nacimiento");
        swal("Debes capturar la fecha de nacimiento");
        return false;
    } else if (document.getElementById('fecha_nac').value.length > 0) {
        if (!isDate(document.getElementById('fecha_nac').value)) {
            //alert("El formato de fecha no es correcto");
            swal("El formato de fecha no es correcto");
            return false;
        } else {
            document.getElementById('loading').style.display = "inline";
            nombre = document.getElementById('nombre').value;
            paterno = document.getElementById('paterno').value;
            materno = document.getElementById('materno').value;
            fecha_nac = document.getElementById('fecha_nac').value;
            request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac;
            send_post_page_rfc(request, "rfc", "modules.php?mod=agentes&op=process_data&act=20");
        }
    }
}

// VALIDA EL FORMATO DE FECHA
function isDate(dateStr) {
    var datePat;
    var matchArray;
    datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
    matchArray = dateStr.match(datePat); // si formato esta bien
    if (matchArray == null) {
        return false;
    }
    month = matchArray[3];
    day = matchArray[1];
    year = matchArray[5];

    if (year.length < 4)
        return false;
    if (year >= 2079)
        return false;
    if (year <= 1900)
        return false;
    if (month < 1 || month > 12 || month.length < 2)
        return false;
    if (day < 1 || day > 31 || day.length < 2)
        return false;
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31)
        return false;
    if (month == 2) {
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}

//### Envia datos por ajax para corroborar datos
function send_post_page_rfc(request, container, page, valor) {
    var contenedor;
    //contenedor = document.getElementById(container);
    contenedor = eval('document.SurveyResponse.' + container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            //alert(ajax.responseText.substr(0, 7));
            if (ajax.responseText.substr(0, 7) == "000-000") {
                contenedor.value = ajax.responseText.substr(7, 13);
                document.getElementById('btn_continue').style.display = "none";
                document.getElementById('rfc_e' + valor).innerHTML = "<font color='red'>Error!!!<br>El RFC: " + ajax.responseText.substr(7, 13) + " ya existe en base de datos</font>";
            } else {
                contenedor.value = ajax.responseText
                document.getElementById('btn_continue').style.display = "inline";
            }

        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

//### VALIDA LA LONGITUD DEL CODIGO POSTAL PARA HACER LA BUSQUEDA
function valida_cp() {
    if (document.frm1.p_cp.value.length < 5) {
        //alert('La longitud del Codigo postal debe ser de 5 posisciones');
        swal('La longitud del Codigo postal debe ser de 5 posisciones');
        return false;
    } else {
        if (!numeros(document.frm1.p_cp, "Codigo Postal"))
            return false;
    }
    document.frm1.submit();
}

//### REGRESA LOS PARAMETROS DE LA BUSQUEDA DE CP A LA PAGINA PRINCIPAL
function resultados_cp(r_id_codigo, r_cp, r_colonia, r_municipio, r_estado) {
    window.parent.opener.document.frm1.id_codigo.value = r_id_codigo
    window.parent.opener.document.frm1.cp.value = r_cp;
    window.parent.opener.document.frm1.colonia.value = r_colonia
    window.parent.opener.document.frm1.municipio.value = r_municipio;
    window.parent.opener.document.frm1.estado.value = r_estado;
    self.close();
}

// ### funcion que valida el campo correo
function valida_mail(mail) {
    bandera = true;
    if (mail.value != "") {
        var s = mail.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {
            bandera = false;
        }
    }
    return bandera;
}

// ### REGRESAR A LA PAGINA DE SI CONTACTO
function regresar_no_contacto() {
    /*document.SurveyResponse.action = 'modules.php?mod=agentes&op=index'
    document.SurveyResponse.submit();*/
    Atras();
}

function calificar_si_contacto(boton,u_persona, action, ispredictivo) {
    document.SurveyResponse.action = '';

    if (document.SurveyResponse.si_contacto.value == 0) {
        swal("Cuidado", "Debes seleccionar una calificacion", "warning");
        boton.disabled = false;
        return false;
    } else if (document.SurveyResponse.si_contacto.value == 10000) {
        document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=MjA=';
        request = "act=MjE=&u_persona=" + u_persona;//21
        send_post_page_valida_capturada(request, "modules.php?mod=agentes&op=process_data&act=MjE=");
    } else if (document.SurveyResponse.si_contacto.value == 406 || document.SurveyResponse.si_contacto.value == 407) {
        document.SurveyResponse.action = 'modules.php?mod=agentes&op=agenda';
        document.SurveyResponse.submit();
    } else {

        if (ispredictivo == 1) {
            $(function() {
                $("#dialog-proceso").dialog({
                    autoOpen: true,
                    height: 150,
                    width: 450,
                    modal: true,
                    closeOnEscape: false,
                    resizable: false,
                    position: {my: "center"},
                    draggable: false,
                    open: function(event, ui) {
                        jQuery('.ui-dialog-titlebar-close').hide();
                    }
                });
            });
        }

        var spanElement = document.getElementById("spanTK");
        var valorDelSpan = spanElement.innerText;
        var flag = false;
        var folio = localStorage.getItem("folioAutenticacion");


        if (valorDelSpan == 3 ||valorDelSpan == 5) {
         if(folio=='SIN_FOLIO' || folio==null){
            var fecha_nac = $('#fechanacimiento1').val();
            
            if(fecha_nac == ''){
                flag = true;
            } else{
                flag = false;
            }
        } else{
            flag = true;
        }

       if(flag == true){
            document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
            document.SurveyResponse.submit();
        } else{
            $('#folioAutenticacion').focus();
            alert('Por favor ingresa los datos de autenticacion.');
        }
    }else{
        document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
        document.SurveyResponse.submit();
    }
    } 
    return false;
}

// VALIDA LAS EXTENSIONES PERMITIDAS ASI COMO LOS CAMPOS OBLIGATORIOS PARA LA CARGA DE ARCHIVOS
function validaFicheroForm() {
    if (document.frm1.fichero.value.length == 0) {
        //alert('Para continuar, ingresa la ruta donde se encuentra el archivo que deseas cargar.');
        swal('Para continuar, ingresa la ruta donde se encuentra el archivo que deseas cargar.');
        return false;
    } else {
        extensiones_permitidas = new Array(".txt", ".csv");
        extension1 = (document.frm1.fichero.value.substring(document.frm1.fichero.value.lastIndexOf("."))).toLowerCase();
        permitida = false;

        for (var i = 0; i < extensiones_permitidas.length; i++) {
            if (extensiones_permitidas[i] == extension1) {
                permitida = true;
                break;
            }
        }

        if (!permitida) {
            //alert('El archivo que intentas cargar no es correcto.\nSolo se pueden Adjuntar archivos de tipo:' + extensiones_permitidas.join());
            swal('El archivo que intentas cargar no es correcto.\nSolo se pueden Adjuntar archivos de tipo:' + extensiones_permitidas.join());
            return sel;
        } else {
            document.frm1.continuar.style.visibility = "hidden";
            document.frm1.submit();
        }
    }
}


// VALIDA EL FORMULARIO PARA CLASIFICAR LOS DATOS
function validaFormEstatus(registros) {
    if (registros > 0) {
        document.frm1.continuar.style.visibility = "hidden";
        document.frm1.submit();
    } else {
        //alert('No se puede ejecutar esta accion sin registros');
        swal('No se puede ejecutar esta accion sin registros');
        return false;
    }
}

function ShowSolicitud() {
    var u_persona = document.frm1.u_persona.value;
    var u_registro = document.frm1.u_registro.value;
    request = "action=1&u_persona=" + u_persona + "&u_registro=" + u_registro;
    send_post_page_n(request, "script", "modules.php?mod=agentes&op=cuestionarion_1");
}

//Permite realizar la grabacion
function GuardaValidando() {
    var u_persona = document.frm1.u_persona.value;
    var u_registro = document.frm1.u_registro.value;
    request = "act=21&u_persona=" + u_persona + "&u_registro=" + u_registro;
    send_post_page_valida_capturada(request, "modules.php?mod=agentes&op=process_data&act=21");
}


// CALIFICA LOS TELEFONOS CON AJAX
function send_post_page_valida_capturada(request, page) {
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            if (ajax.responseText == '0') {
                //alert("No se puede realizar esta accion, porque la solicitud aun no se procesa..")
                swal("No se puede realizar esta accion, porque la solicitud aun no se procesa..");
                return false;
            } else {
                document.frm1.submit();
            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// CONTINUAR CON LA AGENDA
function Continuar_Agenda() {
    if (document.frm1.fecha_busqueda.value == "") {
        swal('Debes capturar el campo de fecha');
        return false;
    }

    document.frm1.submit();
}

// CONTINUAR CON 01800
function Continuar_01800() {
    if (document.frm1.fecha_busqueda.value == "") {
        swal('Debes capturar el campo de fecha');
        return false;
    }

    document.frm1.submit();
}


// Cancela la accion de agendar registro #####
function Cancelar_agenda(action) {
    document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
    document.frm1.submit();
}

function Mostrar_agendado(existe, registro, u_persona, action) {
    document.frm1.u_persona.value = "";
    document.frm1.u_registro.value = "";
    if (existe == 0) {

        document.frm1.u_persona.value = u_persona;
        document.frm1.u_registro.value = registro;

        /*if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm1.submit();
        } else {
            return false;
        }*/
        confirm_(
            "Se mostrara el siguiente registro en pantalla\nDeseas continuar?",
            "",
            "modules.php?mod=agentes&op=process_data&act=" + action,
            'frm1'
        );
    } else {
        //alert('Necesitas abandonar el registro actual');
        swal('Necesitas abandonar el registro actual');
        return false;
    }
}

function Mostrar_agendado2(existe, registro, u_persona, action) {
    document.frm1.u_persona.value = "";
    document.frm1.u_registro.value = "";
    if (existe == 0) {
        document.frm1.u_persona.value = u_persona;
        document.frm1.u_registro.value = registro;

        /*if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm1.submit();
        } else {
            return false;
        }*/
        confirm_(
            "Se mostrara el siguiente registro en pantalla\nDeseas continuar?",
            "",
            "modules.php?mod=agentes&op=process_data&act=" + action,
            'frm1'
        );
    } else {
        //alert('Necesitas abandonar el registro actual');
        swal('Necesitas abandonar el registro actual');
        return false;
    }
}

function Mostrar_agendado3(existe, registro, u_persona, action) {
    document.frm3.u_persona.value = "";
    document.frm3.u_registro.value = "";
    /*var u_registro2 = document.getElementById("u_registro").value = "";
    var u_persona2 = document.getElementById("u_persona").value = "";*/

    if (existe == 0) {
        document.frm3.u_persona.value = u_persona;
        document.frm3.u_registro.value = registro;
        /*u_registro2.value = registro;
        u_persona2.value = u_persona;*/


        /*if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm3.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm3.submit();
        } else {
            return false;
        }*/
        confirm_(
            "Se mostrara el siguiente registro en pantalla\nDeseas continuar?",
            "",
            "modules.php?mod=agentes&op=process_data&act=" + action,
            'frm3'
        );
    } else {
        //alert('Necesitas abandonar el registro actual');
        swal('Necesitas abandonar el registro actual');
        return false;
    }
}



function Mostrar_agendado10(existe, registro, u_persona, action) {
    document.frm3.u_persona.value = "";
    document.frm3.u_registro.value = "";
    if (existe == 0) {
        document.frm3.u_persona.value = u_persona;
        document.frm3.u_registro.value = registro;

        confirm_(
            "Regresaras al producto Uno\nDeseas continuar?",
            "",
            "modules.php?mod=agentes&op=process_data&act=" + action,
            'frm3'
        );
    } else {
        swal('Necesitas abandonar el registro actual');
        return false;
    }
}


// BOTON PARA ENVIAR AL FORMULARIO PARA LA CAPTURA DE UN NUEVO NUMERO TELEFONICO
function Agregar_Telefono(boton) {
    /*if (confirm('Se va a agregar un nuevo numero telefonico\nDeseas Continuar?')) {
        document.frm1.action = "modules.php?mod=agentes&op=nuevo_telefono";
        document.frm1.submit();
    } else {
        boton.disabled = false;
        return false;
    }*/
    confirm_(
        "Se va a agregar un nuevo numero telefonico\nDeseas Continuar?",
        "",
        "modules.php?mod=agentes&op=nuevo_telefono",
        'frm1'
    );
}

// BOTON PARA ENVIAR AL FORMULARIO PARA LA ACTUALIZACION DE NOMBRE
function Actualizar_Nombre(boton) {
    /*if (confirm('Debe ingresar los datos correctos del cliente que contesto,\nSi aun no cuenta con el nombre real del cliente, presione cancelar!!!\nDeseas Continuar?')) {
        document.frm1.action = "modules.php?mod=agentes&op=actualiza_nombre";
        document.frm1.submit();
    } else {
        boton.disabled = false;
        return false;
    }*/
    confirm_(
        "Debe ingresar los datos correctos del cliente que contesto,\nSi aun no cuenta con el nombre real del cliente, presione cancelar!!!\nDeseas Continuar?",
        "",
        "modules.php?mod=agentes&op=actualiza_nombre",
        'frm1'
    );
}


// BOTON PARA ENVIAR AL FORMULARIO PARA LA CAPTURA DE UN NUEVO NUMERO TELEFONICO
function Valida_Telefono(action) {
    if (document.frm1.lada.value == "") {
        swal("Cuidado", "Debes capturar el campo Lada", "warning");
        return false;
    } else if (document.frm1.telefono.value == "") {
        swal("Cuidado", "Debes capturar el campo Telefono", "warning");
        return false;
    }

    //414, 419, 427, 441, 442, 448, 487.
    tel = document.frm1.lada.value+document.frm1.telefono.value;
    if(tel.substring(0,3) == '414'||
        tel.substring(0,3) == '419'||
        tel.substring(0,3) == '427'||
        tel.substring(0,3) == '441'||
        tel.substring(0,3) == '442'||
        tel.substring(0,3) == '448'||
        tel.substring(0,3) == '487'){
        swal('Error', 'La lada no es permitida', 'warning');
        document.frm1.lada.focus();
        return false;
    }

    if (!numeros(document.frm1.lada, "LADA"))
        return false;
    if (!numeros(document.frm1.telefono, "TELEFONO"))
        return false;

    if ((document.frm1.telefono.value.length + document.frm1.lada.value.length) < 10) {
        //alert('La suma de lada y telefono es a 10 posiciones');
        swal('La suma de lada y telefono es a 10 posiciones');
        return false;
    } else {
        document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
        document.frm1.submit();
    }
}


//### Envia datos por ajax para corroborar datos DEL CP
function send_post_page_cp1(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            contenedor.innerHTML = ajax.responseText
            document.getElementById(boton).style.display = "inline";
            if (valor_loading == 1) {
                document.body.removeChild(document.getElementById('div_padre'));
            }

            if (ajax.responseText.substr(0, 17) == '<option value=-1>' /*&& id == 1*/) {
                document.getElementById('btn_continue').style.display = "none";
                swal("CP sin cobertura");
            } else {
                document.getElementById('btn_continue').style.display = "inline";
            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

function send_post_page_cp2(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax1 = nuevoAjax();
    ajax1.open("POST", page, true);
    ajax1.onreadystatechange = function() {
        if (ajax1.readyState == 4) {
            contenedor.innerHTML = ajax1.responseText
            document.getElementById(boton).style.display = "inline";
            if (valor_loading == 1) {
                document.body.removeChild(document.getElementById('div_padre'));
            }
        }
    }
    ajax1.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax1.send(request);
}

function send_post_page_cp3(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    var ajax2 = nuevoAjax();
    ajax2.open("POST", page, true);
    ajax2.onreadystatechange = function() {
        if (ajax2.readyState == 4) {
            contenedor.innerHTML = ajax2.responseText;
            document.getElementById(boton).style.display = "inline";
            if (valor_loading == 1) {
                var divPadre = document.getElementById('div_padre');
                if (divPadre) {
                    document.body.removeChild(divPadre);
                }
            }
        }
    };
    ajax2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax2.send(request);
}


function loading_fun() {
    Html = '<div id="ajControl" width="100%">' +
            '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
            '<tr id="ajControlBody">' +
            '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

    var div = document.createElement('div');
    div.id = 'div_padre';
    div.innerHTML = Html;

    document.body.appendChild(div);
}

//### CALCULA EL RFC DEL CLIENTE
function Generar_1(valor) {
    var nombre, paterno, materno, fecha_nac;
    //Nombre
    if (eval("document.getElementById('nombrepila" + valor + "')") != null) {
        if (eval("document.getElementById('nombrepila" + valor + "').value") == "") {
            //alert("Debes capturar el Nombre");
            swal("Debes capturar el Nombre");
            return false;
        } else {
            nombre = eval("document.getElementById('nombrepila" + valor + "').value");
        }
    }

    //Segundo nombre
    if (eval("document.getElementById('nombreseg" + valor + "')") != null) {
        if (eval("document.getElementById('nombreseg" + valor + "').value") != "") {
            nombre += ' ' + eval("document.getElementById('nombreseg" + valor + "').value");
        }
    }

    //Apellido paterno
    if (eval("document.getElementById('appaterno" + valor + "')") != null) {
        if (eval("document.getElementById('appaterno" + valor + "').value") == "") {
            //alert("Debes capturar el Apellido Paterno");
            swal("Debes capturar el Apellido Paterno");
            return false;
        } else {
            paterno = eval("document.getElementById('appaterno" + valor + "').value");
        }
    }

    //Apellido materno
    if (eval("document.getElementById('apmaterno" + valor + "')") != null) {
        if (eval("document.getElementById('apmaterno" + valor + "').value") != "") {
            materno = eval("document.getElementById('apmaterno" + valor + "').value");
        }
    }

    //Fecha de nacimiento
    if (eval("document.getElementById('fechanacimiento" + valor + "')") != null) {
        if (eval("document.getElementById('fechanacimiento" + valor + "').value") == "") {
            //alert("Debes capturar la fecha de nacimiento");
            swal("Debes capturar la fecha de nacimiento");
            return false;
        } else {
            fecha_nac = eval("document.getElementById('fechanacimiento" + valor + "').value");
        }
    }

    //---document.getElementById('Generar').style.display = "none";
    request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac;
    send_post_page_rfc(request, "rfc" + valor, "modules.php?mod=agentes&op=process_data&act=MjM=");
}

function submitCP(id, valor_cp) {
    if (valor_cp.value == "") {
        swal("Favor de escribir el CP de la Direccion");
        return false;
    } else {
        if (!/^([0-9])*$/.test(valor_cp.value)) {
            swal("El CP debe ser numerico de la Direccion ");
            return false;
        } else {
            if (!tamanos(valor_cp, "CP", 5, 5)) {
                swal("El CP debe ser de 5 digitos");
                return false;
            }
        }

        document.getElementById("ESTADO" + id).innerHTML = "";
        document.getElementById("MUNICIPIO" + id).innerHTML = "";
        document.getElementById("COLONIA" + id).innerHTML = "";

        var boton = 'CP' + id;
        document.getElementById(boton).style.display = "none";
        cp_ = valor_cp.value;
        request = "cp=" + cp_;
        
        send_post_page_cp1(request, "ESTADO" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjQ=", 0, id);//24
        send_post_page_cp2(request, "MUNICIPIO" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjU=", 0, id);//25
        send_post_page_cp3(request, "COLONIA" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjY=", 1, id);//26
    }
    return false;
}

function comprueba_RFC(valor) {
    var nombre, paterno, materno, fecha_nac, contador = 0;
    //alert(valor);
    //Nombre
    if (eval("document.getElementById('nombrepila" + valor + "')") != null) {
        if (eval("document.getElementById('nombrepila" + valor + "').value") != "") {
            contador += 1;
            nombre = eval("document.getElementById('nombrepila" + valor + "').value");
        }
    }

    //Segundo nombre
    if (eval("document.getElementById('nombreseg" + valor + "')") != null) {
        if (eval("document.getElementById('nombreseg" + valor + "').value") != "") {
            nombre += ' ' + eval("document.getElementById('nombreseg" + valor + "').value");
        }
    }

    //Apellido paterno
    if (eval("document.getElementById('appaterno" + valor + "')") != null) {
        if (eval("document.getElementById('appaterno" + valor + "').value") != "") {
            contador += 1;
            paterno = eval("document.getElementById('appaterno" + valor + "').value");
        }
    }

    //Apellido materno
    if (eval("document.getElementById('apmaterno" + valor + "')") != null) {
        if (eval("document.getElementById('apmaterno" + valor + "').value") != "") {
            materno = eval("document.getElementById('apmaterno" + valor + "').value");
        }
    }

    //Fecha de nacimiento
    if (eval("document.getElementById('fechanacimiento" + valor + "')") != null) {
        if (eval("document.getElementById('fechanacimiento" + valor + "').value") != "") {
            contador += 1;
            fecha_nac = eval("document.getElementById('fechanacimiento" + valor + "').value");

            if(!isDate2(fecha_nac,"DD/MM/AAAA")){
                swal("[ERROR!] Fecha Incorrecta");
                //alert("[ERROR!] Fecha Incorrecta");
                contador -= 1;
            }
        }
    }
    //alert(contador);
    if (contador == 3) {
        //alert("entro");
        document.getElementById('rfc_e' + valor).innerHTML = "";
        request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac + "&num_reconocedor=" + valor;
        send_post_page_rfc(request, "rfc" + valor, "modules.php?mod=agentes&op=process_data&act=MjM=", valor);
    }

}

function ObtenerMunicipios() {
    document.frm1.action = '';
    document.frm1.submit();
}

function seg_agente() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.nomina.value == "") {
        //alert("El número de nómina está vacío");
        swal("El número de nómina está vacío");
        document.frm1.nomina.focus();
        return false;
    }
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        //alert('Los campos de fecha estan vacios');
        swal('Los campos de fecha estan vacios');
        document.frm1.fecha_del.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }
        document.getElementById('resp_act').style.display = "inline";

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;
        nomina = document.frm1.nomina.value;

        request = "nomina=" + nomina + "&tipo_rep=" + tipo_rep + "&fecha_del=" + fecha_del + "&fecha_al=" + fecha_al;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=3");
    }
}

function seg_solicitud() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.solicitud.value == "") {
        //alert("El número de solicitud está vacío");
        swal("El número de solicitud está vacío");
        document.frm1.solicitud.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";

        solicitud = document.frm1.solicitud.value;

        request = "solicitud=" + solicitud;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=4");
    }
}

function revivir_solicitud() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.solicitud.value == "") {
        //alert("El número de solicitud está vacío");
        swal("El número de solicitud está vacío");
        document.frm1.solicitud.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";

        solicitud = document.frm1.solicitud.value;

        request = "solicitud=" + solicitud;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=5");
    }
}

function habilitar(boton) {
    //document.getElementById('seleccionado').value = boton;
    switch (boton) {
        case "1":
            document.getElementById('nombre').disabled = false;
            document.getElementById('paterno').disabled = false;
            document.getElementById('materno').disabled = false;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('nombre').focus();
            break;
        case "2":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = false;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('solicitud').focus();
            break;
        case "3":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = false;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('clave').focus();
            break;
        case "4":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = false;
            document.getElementById('rfc').disabled = true;
            document.getElementById('telefono').focus();
            break;
        case "5":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = false;
            document.getElementById('rfc').focus();
            break;
        default:
            //alert("No seleccionaste opción");
            swal("No seleccionaste opción");
    }
}

function liberar_registro(id_solicitud) {
    if (confirm("¿Deseas liberar el registro " + id_solicitud + "?")) {
        request = "solicitud=" + id_solicitud;
        document.getElementById('resp_act').style.display = "inline";
        send_post_page_n(request, "resp_act", "modules.php?mod=agentes&op=process_data&act=MzQ="); // 34
    }
}


function actulizar_tipo_seguro(selectd){
    
    $.post("modules.php?mod=agentes&op=process_data&act=OTY=",{//96
          prod_value:selectd.value
      },function(data,status){
              document.getElementById('TIPO_SEGURO_CROSS').innerHTML = data;
      });


}


function avisoPrivacidad(sApellido, inicio) {
    var tipozona = $('#34').val();
    if (inicio == "y") {

        var aviso = "\t\t\t\t\t\tAviso de Privacidad\n\n";
        aviso = aviso + "\tLos datos personales que nos proporcione seran tratados por ";
        aviso = aviso + "American Express Company (Mexico), S.A. de C.V., con domicilio en Patriotismo 635 ";
        aviso = aviso + "Col. Ciudad de los Deportes, Alcaldia Benito Juurez, 03710 Ciudad de Mexico, Mexico, ";
        aviso = aviso + "con la finalidad primaria y necesaria de contactarle con el proposito de ofrecerle nuestros servicios, ";
        aviso = aviso + "asi como para dar seguimiento a sus solicitudes de las Tarjetas American Express. ";
        aviso = aviso + "\nPara conocer nuestro Aviso de Privacidad Integral visite: \nwww.americanexpress.com.mx. ";


        // alert(aviso);
        swal({
            html:true,
            //input: 'range',
            button: {
            text: "ok",
             closeModal: false,
               },

            input: 'text',
            title: "Aviso de Privacidad",
            text: "Los datos pAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAersonales que nos proporcione seran tratados por American Express Company (Mexico), S.A. de C.V., con domicilio en Patriotismo 635 Col. Ciudad de los Deportes, Alcaldia Benito Juarez, 03710 Ciudad de Mexico, Mexico, con la finalidad primaria y necesaria de contactarle con el proposito de ofrecerle nuestros servicios, asi como para dar seguimiento a sus solicitudes de las Tarjetas American Express. Para conocer nuestro Aviso de Privacidad Integral visite: www.americanexpress.com.mx."+
            "<input style= 'display:none;'id='Appfunc'  type = 'text' >",
            //text: '<div><input type="text"></div>',
            //type: "info",
            showConfirmButton: true
        });
       // var tipozona = $('#34').val();
       //var tipozona = 14358;
        if(tipozona == 14358 || tipozona == 14357 ){
        $('.confirm').attr('onclick', 'encsms();');
        var Verzona = $('#34').val();
        $('#Appfunc').attr('value', Verzona);
    }
    }
}



//var jsvar = '<?php $datos_cliente[0]['U_ZONA']?>';
/*
function quitarped(){

    $('.sweet-overlay').css('display','none');
    $('.showSweetAlert').css('display','none');
}*/


//includes/js/formulario_test.php
function encsms(){

    var tipozona = $('#34').val();

//var  tipozona = 14358;
    if(tipozona == 14358 || tipozona == 14357){


    var valormost = $('#valorcuestionario').val();


    $('.confirm').attr('id', 'chuy1234');
    $('#chuy1234').css('display','none');
    $('.showSweetAlert').find('h2').html('FORMULARIO');
    $('.showSweetAlert').find('p').remove();
    $('.showSweetAlert').find($("h2" )).after(`

        <div><p>Por que no ingresaste el codigo que te enviamos a tu celular?</p></div>
        <div id="divMensaje">

            <select name="opcion" id="opcion" >
                <option value="0">No entendi lo que debia introducir (entendimiento)</option>
                <option value="1">NO quise confirmar el codigo (desconfianza)</option>
                <option value="2">El SMS me llego despues de que el tiempo expiro (tiempo que llega el SMS) </option>
                <option value="3">son demasiados campos a llenar (muchos campos)</option>
                <option value="4">Otro</option>
            </select>

            <div id = "chuy100" style= "display:none;">
            <label for="fname">Razon:</label>
            <input type="text" id="fname"  name="fname" style="margin-top: 10px;margin-left: 123px;">

            </div>
            <div>
            <label for="fname" style = "margin-top: 9px;">A que estado de la republica nos estamos comunicando?</label>
             <select name="estados" id="estados" required >

                <option value="0"></option>
                <option value= "1">AGUASCALIENTES</option>
                <option value= "2">BAJA CALIFORNIA</option>
                <option value= "3">BAJA CALIFORNIA SUR</option>
                <option value= "4">CAMPECHE</option>
                <option value= "7">CHIAPAS</option>
                <option value= "8">CHIHUAHUA</option>
                <option value= "5">COAHUILA DE ZARAGOZA</option>
                <option value= "6">COLIMA</option>
                <option value= "9">DISTRITO FEDERAL</option>
                <option value= "10">DURANGO</option>
                <option value= "12">GUANAJUATO</option>
                <option value= "13">GUERRERO</option>
                <option value= "14">HIDALGO</option>
                <option value= "15">JALISCO</option>
                <option value= "11">MEXICO</option>
                <option value= "16">MICHOACAN DE OCAMPO</option>
                <option value= "17">MORELOS</option>
                <option value= "18">NAYARIT</option>
                <option value= "19">NUEVO LEON</option>
                <option value= "20">OAXACA</option>
                <option value= "21">PUEBLA</option>
                <option value= "22">QUERETARO ARTEAGA</option>
                <option value= "23">QUINTANA ROO</option>
                <option value= "24">SAN LUIS POTOSI</option>
                <option value= "25">SINALOA</option>
                <option value= "26">SONORA</option>
                <option value= "27">TABASCO</option>
                <option value= "28">TAMAULIPAS</option>
                <option value= "29">TLAXCALA</option>
                <option value= "30">VERACRUZ</option>
                <option value= "31">YUCATAN</option>
                <option value= "32">ZACATECAS</option>
            </select>
            </div>
        <button id = "bergas1" onclick ="carga_valor();" > Aceptar</button>

        <button id = "bergas" style="display:none;margin: 0 auto;" onclick ="carga_valor2();" > Aceptar</button>

        </div>
    `);

    validaRespuesta();

    $('.confirm').attr('onclick', 'cerrarSwal();');

    /*console.log('fjapojapodjgposadgpamodg');
    setTimeout(function(){
        $('chuy123456').click();
    }, 5000);*/
}
 $('.confirm').attr('onclick', 'cerrarSwal();');


}

function validaRespuesta(){
    $('#opcion').change(function(){
      var opcion = $(this).val();

        if(opcion==4 || opcion=='4'){
        $('#chuy100').show();
      } else{
            $('#chuy100').hide();
            $('#chuy100 input').val('');
        }
    });
}

function carga_valor(){
    var envio = 0;
    if($('#estados').val() == 0){
        //alert("debes elegir un estado");
        swal("debes elegir un estado");
        envio = 0;


    }else{


    var selectbox = $('#opcion').val();
    var valorInput = $('#fname').val();
    var estado = $('#estados').val();

    var msgError = '';
    const regExp = /[A-Za-z 0-9]{5,50}/g;
    var valormin = $( "#fname" ).val().length;



    if (selectbox == 4){
      //  alert("ddddd");
         // valida que ei input no este vacio

         //si viene con datos
         //if(valorInput!='' || regExp.test(valorInput)){
            if(valorInput!='' && valormin > 5  && valormin < 50){
            envio = 1;
             //alert("dddfffffdd");
        } else{
            // alert("dd333333ddd");
            envio = 0;
            msgError = 'Por favor ingresa un texto entre 5 y 50 caracteres.';
        }

     } else{
        // alert("d444dddd");
        envio = 1;
    }

    if(envio == 1){
    //  alert("ddd5555dd");

        $('#spanError').remove();
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: "modules.php?mod=agentes&op=process_data&act=OTI=", //92
            data: {'respuestaSelect':selectbox,
                    'respuestaRazon':valorInput,
                    'estado':estado
                   },
            beforeSend: function(){
            },
            success: function(data){
                console.log(data);
                $('.sweet-overlay').css('display','none');
                $('.showSweetAlert').css('display','none');
                console.log(data);
            }
        });

    } else{
        $('#chuy100').after('<span id="spanError" style="color:red;">'+msgError+'</span>');
    }
}
}


function cerrarSwal(){

    $('.sweet-overlay').css('display','none');
    $('.showSweetAlert').css('display','none');

}

function revisa_calificacion(combo, tipo, referente, telefono) {
    var referido = false;
    var cliente_molesto = false;
    var calificacion = combo.value;
    
    $.ajax({
        type: 'POST',
        url: "modules.php?mod=agentes&op=process_data&act=OTQ=", //94
        data: {'calificacionCAPI':calificacion
               },
        success: function(data){
            console.log(data);
        }
    });

    if (combo.options[combo.selectedIndex].text.indexOf("[R]") >= 0) {
        if (tipo == 1 || tipo == 2) {
            if (confirm("¿Deseas agregar un recomendado?")) {
                referido = true;
            }
        } else {
            referido = false;
        }
        if (referido == true) {
            window.location = "modules.php?mod=agentes&op=nuevoregistro&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono;
        }
    }

    //Bloqueo de clientes muy molestos
    if (combo.options[combo.selectedIndex].text.indexOf("[B]") >= 0) {
        if (confirm("¿Estas seguro de calificar como 'CLIENTE MUY MOLESTO'?")) {
            cliente_molesto = true;
        }else{
            cliente_molesto = false;
        }

        if(cliente_molesto == true){
            avisoPrivacidadImpulse_bloqueo();
            window.location = "modules.php?mod=agentes&op=process_data&act=NjAw&cal="+calificacion;
        }
    }

    for (i = 1; i <= frm1.cont.value; i++) {
        tel = (i < 10 ? "0" + i : i);
        document.getElementById("tel_" + tel).disabled = false; //Habilitar todos los combos
    }
    if (combo.value == "1010") {
        for (i = 1; i <= frm1.cont.value; i++) {
              tel = (i < 10 ? "0" + i : i);
             flag = true;
             if (combo.name == "tel_" + tel) {
                 flag = false;
             }
             document.getElementById("tel_" + tel).disabled = flag; //Deshabilitar los no 1010
         }
    }

}

function avisoPrivacidadImpulse() {
    swal("Aviso de Privacidad:\n\n" +
                        "Los datos personales que nos proporcione seran tratados por American Express Company\n" +
                        "(Mexico), S.A. de C.V. y/o American Express Bank (Mexico), S.A., Institucion de Banca\n" +
                        "Multiple, con domicilio en Patriotismo 635 Col. Ciudad de los Deportes, Alcaldia Benito\n" +
                        "Juarez, 03710, Ciudad de Mexico, Mexico, con la finalidad primaria y necesaria de contactarle con el\n" +
                        "proposito de ofrecerle nuestros servicios, asi como para dar seguimiento a sus solicitudes\n" +
                        "de las Tarjetas American Express. Para conocer nuestro Aviso de Privacidad Integral\n" +
                        "visite: www.americanexpress.com.mx.\n\n\n");

}

function avisoPrivacidadImpulse_bloqueo() {
    swal("Aviso de Privacidad:\n\n" +
            "Los datos personales que nos proporcione seran tratados por American Express Company\n" +
            "(Mexico), S.A. de C.V. y/o American Express Bank (Mexico), S.A., Institucion de Banca\n" +
            "Multiple, con domicilio en Patriotismo 635 Col. Ciudad de los Deportes, Delegacion Benito\n" +
            "Juarez, 03710 Mexico, D.F., con la finalidad primaria y necesaria de contactarle con el\n" +
            "proposito de ofrecerle nuestros servicios, asi como para dar seguimiento a sus solicitudes\n" +
            "de las Tarjetas American Express. Para conocer nuestro Aviso de Privacidad Integral\n" +
            "visite: www.americanexpress.com.mx.\n\n\n"+

                        "QUE CONTESTAR AL CLIENTE hola:\n\n" +
                        "Si el cliente menciona que esta inscrito en REUS (Registro Publico de Usuarios Personas Fisicas), CONDUSEF (Comision Nacional para la Proteccion y Defensa de los Usuarios de los Servicios Financieros) o ya requirio derecho de ARCO:\n\n" +
                        "De parte de (campaña) le ofrezco una disculpa, no tenia conocimiento de esta situacion. Le agradezco que haya atendido mi llamada, muchas gracias.\n\n" +
                        "Que responder ante la pregunta ¿Como obtuviste mis datos?\n\n" +
                        "Señor (nombre y apellido), no se preocupe, los unicos datos con los que contamos son nombre y telefono, son datos publicos y no tenemos ningun dato confidencial.\n\n" +
                        "Con insistencia, de donde los obtuvieron: \n\n" +
                        "Señor (nombre y apellido), nuestra informacion fuente es publica, como por ejemplo la seccion blanca o amarilla, o bien alguno de nuestros clientes distinguidos lo refirio para que contara con nuestro excelente servicio.\n\n" +
                        "Tercera insistencia:\n\n" +
                        "Señor (nombre y apellido), de parte de (campaña) le ofrezco una disculpa, definitivamente no es nuestro objetivo generarle desconfianza alguna, sin embargo entiendo su preocupacion. En estos momentos procedo al bloqueo de sus datos para que no lo volvamos a contactar. Le agradezco que haya atendido mi llamada, muchas gracias.\n\n"
            );
}

$(function(){
    
    $("#dialog-proceso").dialog({
        autoOpen: false,
        height: 100,
        width: 500,
        modal: true,
        closeOnEscape: false,
        resizable: false,
        position: {my: "center"},
        draggable: false,
        open: function(event, ui) {
            jQuery('.ui-dialog-titlebar-close').hide();
        }
    });
  
    $("#progressbar").progressbar({
        value: false
    });


    $( "#btnbano_pred" )
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );//
    $( "#btncapa_pred" )
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );//
    $( "#btnbusqueda_pred" )
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );//

    $( "#obRegistroPred" )
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );


    $("#obRegistroPredContinuar")
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );
    $("#obRegistroPredAgenda")
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );
    $("#obRegistroPredCancelarRefe")
        //.button()
        .click(function() {
            $( "#dialog-proceso" ).dialog("open");
        }
    );

    $( "#progressbar" ).progressbar({
        value: false
    });

    $("#accordion").accordion({
            collapsible: true,
            heightStyle: "fill",
        active: false
    });

    $("#accordion-resizer").resizable({
        minHeight: 140,
        minWidth: 200,
        resize: function() {
            $("#accordion").accordion("refresh");
        }
    });

    $("#datepicker").datepicker({
        inline: true
    });

    $("#dialog2").dialog({
        autoOpen: false,
        height: 400,
        width: 600,
        closeOnEscape: false,
        resizable: false,
        position: {my: "center"},
        /*show: {
         effect: "blind",
         duration: 1000
         },*/
        /*hide: {
         effect: "explode",
         duration: 1000
         }*/
});

    $("#opener").click(function() {
        $("#dialog2").dialog("open");
    });

    /*$( "#indicadores" ).click(function() {
     $( "#indicador" ).dialog( "open" );
     });*/

    $("#menu").menu();

});


function RegresoPredictivo(event, action){
    event.preventDefault();
    
    swal({
        title: "Esperando Registro Nuevo",
        text: '<img src="' + linkpath + 'includes/imgs/cargando.gif">',
        html: true,
        showConfirmButton: false,
        allowOutsideClick: false 
    },
    function(isConfirm) {
        if (isConfirm) {
            // Acción cuando el usuario confirme
        }
    });
    
    window.location = "modules.php?mod=agentes&op=process_data&act=" + action;
}

function marcarpredictivo(act) {
    window.location = "modules.php?mod=agentes&op=process_data&act=" + act;
    //alert (url);
    //document.getElementById("pred").src = url;
}

function score2() {

        if (document.getElementById("calificavalidador").value == '') {
            //alert("Debes Incluir Validador");
            swal("Debes Incluir Validador");
        }else{
        var comen = document.getElementById("comentario").value;
        var validador = document.getElementById("calificavalidador").value;
        var antsol = document.getElementById("antiguasolicitud").value;
        var puntaje = $(".rate_row").find(":hidden").val();
        var page = 'modules.php?mod=agentes&op=process_data&act=Q1Y=&comen=' + comen + '&validador=' + validador + '&puntaje=' + puntaje+'&antsol='+antsol;

//    var page = 'modules.php?mod=agentes&op=process_data&act=Q1Y=';
        ajaxPrima = nuevoAjax();
        ajaxPrima.open("POST", page, true);
        ajaxPrima.onreadystatechange = function () {
            if (ajaxPrima.readyState == 4) {
                swal("Calificacion Guardada.");
            }
        };
        ajaxPrima.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajaxPrima.send(request);
    }
}
/* function Finalizar_venta(id_solicitud, action) {
    $.post("modules.php?mod=agentes&op=process_data&act=MTAz", {
        id_solicitud
    }, function(data) {
        let parseData = JSON.parse(data);    
        
        try {            
            
            if (parseData.Resultado >= 2) {
                document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
                let PCN = sessionStorage.getItem("PCN");
                let rs = sessionStorage.getItem("rs");
            
                //ENVIAMOS EL RESULTADO/PCN PARA BLOQUEAR LA SOL UNA VEZ FINALIZADA LA VENTA           
                $.post("modules.php?mod=agentes&op=process_data&act=MTAx", {
                    PCN, rs
                }, function (data) {
                });
                
                document.frm1.submit();
            } else {
                swal("Cuidado", "Procesa ambos Productos/Agenda Tu Solicitud/ Califica No Contacto y Continua", "warning")
            } 

        } catch (error) {
            console.log(error);    
        }
    });

} */


function Finalizar_venta(id_solicitud, action) {
    $.post("modules.php?mod=agentes&op=process_data&act=MTAz", {
        id_solicitud
    }, function(data) {
        let parseData = JSON.parse(data);    
        
        try {            
            if (parseData.Resultado >= 2) {
                let PCN = sessionStorage.getItem("PCN");
                let rs = sessionStorage.getItem("rs");
            
                // ENVIAMOS EL RESULTADO/PCN PARA BLOQUEAR LA SOL UNA VEZ FINALIZADA LA VENTA           
                $.post("modules.php?mod=agentes&op=process_data&act=MTAx", {
                    PCN, rs
                }, function (data) {
                    // Mover la acción y el envío del formulario aquí
                    document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
                    document.frm1.submit();
                });
                                
            } else {
                swal("Cuidado", "Procesa ambos Productos/Agenda Tu Solicitud/ Califica No Contacto y Continua", "warning");
            } 
        } catch (error) {
            console.log(error);    
        }
    });
}




// Enviar datos para agenda
function send_post_page_agenda(request, container, page) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax_agenda = nuevoAjax();
    ajax_agenda.open("POST", page, true);
    ajax_agenda.onreadystatechange = function() {
        if (ajax_agenda.readyState == 4) {
            contenedor.innerHTML = ajax_agenda.responseText;
        }
    }
    ajax_agenda.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax_agenda.send(request);
}

function verAgenda(boton, fecha, contenedor, tipo_agenda) {
    boton.disabled = false;
    request = "fecha=" + fecha + "&tipo_agenda=" + tipo_agenda;
    send_post_page_agenda(request, contenedor, "modules.php?mod=agentes&op=process_data&act=NDA2");
}

function guardaAgenda(agenda, hora, nombre, solicitud, ispred) {
    mediahora = document.getElementById("hora");
    mediahora.value = agenda;
    Agenda_registro('Ng==', hora, nombre, solicitud, ispred); //Action 6
}


function f5(that, val) {
    //alert("entro");
    if (val)
    {
        that.on('keydown', function(e) {
            var code = (e.keyCode ? e.keyCode : e.which);
            if (code == 116 /*|| code == 8*/) {
                e.preventDefault();
            }
        });
    } else {
        that.off('keydown');
    }
}

function dialogo(src, indicadores) {

    
    
    document.getElementById("iframeind").src = src;
    $("#indicador").dialog({
        autoOpen: true,
        height: 400,
        width: 600,
        closeOnEscape: false,
        resizable: true,
        title: indicadores,
        position: {my: "center"},
        /*show: {
         effect: "blind",
         duration: 1000
         },*/
        /*hide: {
         effect: "explode",
         duration: 1000
         }*/
    });

}

function generar_layouts() {

    if (document.layouts.fecha.value == "") {
        //alert('Los campos de fecha estan vacios')
        swal('Los campos de fecha estan vacios');
        return false;
    } else if (document.layouts.t_layout.value == "") {
        //alert('Seleccione el Layout')
        swal('Seleccione el Layout');
        return false;
    } else {

        document, layouts.l_button.disabled = true;

        loading_fun()

        fecha = document.layouts.fecha.value;
        t_layout = document.layouts.t_layout.value;

        request = "fecha=" + fecha + "&t_layout=" + t_layout;
        sen_post_layots(request, "result", "modules.php?mod=supervisor&op=process_data&act=6", 1);
    }
}

function sen_post_layots(request, container, page, valor_loading) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4) {
            contenedor.innerHTML = ajax.responseText
            if (valor_loading == 1) {
                document.body.removeChild(document.getElementById('div_padre'));
                document, layouts.l_button.disabled = false;
            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

function loading_fun() {
    Html = '<div id="ajControl" width="100%">' +
            '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
            '<tr id="ajControlBody">' +
            '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

    var div = document.createElement('div');
    div.id = 'div_padre';
    div.innerHTML = Html;

    document.body.appendChild(div);
}





//## Prepara las variables para mandar liberar extension
function liberar_extension(extension, action, boton) {

        //loading_fun();
        boton.disabled = true;

        document.getElementById("LibExtContainer").innerHTML = "";

        request = "extension=" + extension;

        send_post_page_lib_ext(request, "LibExtContainer", "modules.php?mod=external&op=process_data&act=" + action);//1 (external)

    return false;
}

//## Ejecuta la funcion de liberar extension
function send_post_page_lib_ext(request, container, page) {
//  alert(request);
    //ajax5

    var contenedor;
    contenedor = document.getElementById(container);

    ajax5 = nuevoAjax();
    ajax5.open("POST", page, true);
    ajax5.onreadystatechange = function() {
        if (ajax5.readyState == 4) {
            contenedor.innerHTML = ajax5.responseText
        }
    }
    ajax5.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax5.send(request);

}

function verify_movil(boton,tel){
    if(boton.value != ''){
        if(tel == 1){
            numero = document.SurveyResponse.txtQId32CId23.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_1", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 2){
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_2", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 3){
            numero = document.SurveyResponse.txtQId37CId89.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_3", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 4){
            numero = document.SurveyResponse.txtQId37CId94.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_4", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 5){
            numero = document.SurveyResponse.txtQId37CId102.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_5", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 6){
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_6", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 7){
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_7", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 8){
             numero = document.SurveyResponse.txtQId33CId13.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request,"tel_8", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }else if(tel == 9){
            var tel_valido_9 = 0;
            var count_tel = 0;
            numero = document.frm1.lada.value + boton.value;

            request = "numero=" + numero;
            send_post_get_count_tel(request,"","modules.php?mod=agentes&op=process_data&act=NTY=",tel);
            send_post_page_verifica_numero(request,"tel_9", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
        }

    }else{
        if(tel == 1){
            tel_valido_1 = 0;
        }else if(tel == 2){
            tel_valido_2 = 0;
        }else if(tel == 3){
            tel_valido_3 = 0;
        }else if(tel == 4){
            tel_valido_4 = 0;
        }else if(tel == 5){
            tel_valido_5 = 0;
        }else if(tel == 6){
            tel_valido_6 = 0;
        }else if(tel == 7){
            tel_valido_7 = 0;
        }else if(tel == 8){
            tel_valido_8 = 0;
        }
    }
}

function send_post_page_verifica_numero(request, container, page,tel) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax5 = nuevoAjax();
    ajax5.open("POST", page, true);
    ajax5.onreadystatechange = function() {
        if (ajax5.readyState == 4) {
            contenedor.innerHTML = "<font color='red'>"+ajax5.responseText+"</font>";

            if(tel == 1 /*|| tel == 3*/){
                if(ajax5.responseText != 'FIJO'){
                    //alert("En el campo de telefono de casa debe ser fijo");
                    swal("En el campo de telefono de casa debe ser fijo");
                    //return false;
                    if(ajax5.responseText == 'No valido'){
                        //alert("Ha ingresado un telefono no valido");
                        swal("Ha ingresado un telefono no valido");
                        tel_valido_1 = 1;
                        return false;
    }else{
                        tel_valido_1 = 0;
                        return true;
    }
                }else{
                    if(ajax5.responseText == 'No valido'){
                        //alert("Ha ingresado un telefono no valido");
                        swal("Ha ingresado un telefono no valido");
                        tel_valido_1 = 1;
                        return false;
                    }else{
                        tel_valido_1 = 0;
                        return true;
}
                }
            }else if(tel == 2){
                if(ajax5.responseText != 'MOVIL'){
                    //alert("En el campo de celular debe ser Movil");
                    swal("En el campo de celular debe ser Movil");
                    //return false;
                    if(ajax5.responseText == 'No valido'){
                        //alert("Ha ingresado un telefono no valido");
                        swal("Ha ingresado un telefono no valido");
                        tel_valido_1 = 1;
                        return false;
                    }else{
                        tel_valido_1 = 0;
                        return true;
                    }
                }else{
                     if(ajax5.responseText == 'No valido'){
                        //alert("Ha ingresado un telefono no valido");
                        swal("Ha ingresado un telefono no valido");
                        tel_valido_2 = 1;
                        return false;
                    }else{
                        tel_valido_2 = 0;
                        return true;
                    }
                }

            }else if(tel == 3){
                if(ajax5.responseText == 'No valido'){
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    tel_valido_3 = 1;
                    return false;
                }else{
                    tel_valido_3 = 0;
                    return true;
                }
            }else if(tel == 4){
                if(ajax5.responseText == 'No valido'){
                    tel_valido_4 = 1;
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    return false;
                }else{
                    tel_valido_4 = 0;
                    return true;
                }
            }else if(tel == 5){
                if(ajax5.responseText == 'No valido'){
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    tel_valido_5 = 1;
                    return false;
                }else{
                    tel_valido_5 = 0;
                    return true;
                }
            }else if(tel == 6){
                if(ajax5.responseText == 'No valido'){
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    tel_valido_6 = 1;
                    return false;
                }else{
                    tel_valido_6 = 0;
                    return true;
                }
            }else if(tel == 7){
                if(ajax5.responseText == 'No valido'){
                    tel_valido_7 = 1;
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    return false;
                }else{
                    tel_valido_7 = 0;
                    return true;
                }
            }else if(tel == 8){
                if(ajax5.responseText == 'No valido'){
                    //alert("Ha ingresado un telefono no valido");
                    swal("Ha ingresado un telefono no valido");
                    tel_valido_8 = 1;
                    return false;
                }else{
                    tel_valido_8 = 0;
                    return true;
                }
            }else if(tel == 9){
                if(ajax5.responseText == 'No valido'){
                    swal("Ha ingresado un telefono no valido");
                    tel_valido_9 = 0;
                    return false;
                }else{

                    tel_valido_9 = 1;
                    if(ajax5.responseText == 'MOVIL'){
                        document.getElementById('tipo_telefonico').value = 3
                    }else if(ajax5.responseText == 'FIJO'){
                        document.getElementById('tipo_telefonico').value = 1
                    }
                    return true;
                }
            }

        }
    }
    ajax5.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax5.send(request);

}

function Actualizar2(boton) {
    var sb = $('#spanSB').text();

    console.log(sb);
    if(parseInt(sb) >= valScore){
        //alert('No hay nada que actualizar. El SCORE es ' + sb);
        swal('No hay nada que actualizar. El SCORE es ' + sb);
        return false;

    } else{
        boton.disabled = true;

        var xmlhttp;
        if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        document.getElementById(boton.id).setAttribute("class","menulink2");
        setTimeout(function(){ boton.disabled = false; document.getElementById(boton.id).setAttribute("class","menulink"); }, 3000);

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("result2").innerHTML = xmlhttp.responseText;
                //boton.disabled = false;
            }
        };

        xmlhttp.open("POST", "modules.php?mod=agentes&op=process_data&act=ODU=", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send("nomina=<?= $nomina ?>&u_user=<?= $u_user ?>");
    }
}

function send_post_get_count_tel(request, container, page,tel) {
//  alert(request);
    //ajax5

    ajax6 = nuevoAjax();
    ajax6.open("POST", page, true);
    ajax6.onreadystatechange = function() {
        if (ajax6.readyState == 4) {
            count_tel = ajax6.responseText;
        }
    }
    ajax6.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax6.send(request);

}

function actulizar_forma_pago(producto,selectd){
    //alert(selectd.options[selectd.selectedIndex].text);
    /*if(producto == 1){
        v_prod_value = selectd.options[selectd.selectedIndex].text;
    }else {*/
        v_prod_value = selectd.value;
    //}

    $.post("modules.php?mod=agentes&op=process_data&act=NDc=",{
        producto:producto,
        prod_value:v_prod_value
    },function(data,status){
        /*if(producto == 1){
            document.SurveyResponse.txtQId11CId17.innerHTML = data;
        }else{**/
            document.getElementById('FORMA_PAGO').innerHTML = data;
        //}

        //alert(data);
    });
}

function actulizar_prima(producto,selectd){
    $.post("modules.php?mod=agentes&op=process_data&act=NDc=",{
        producto:producto,
        prod_value:selectd.value
    },function(data,status){
            document.getElementById('PRIMA').innerHTML = data;
    });
}

function inicio_marcar(inicio_marcar){
    $.post("modules.php?mod=agentes&op=process_data&act=MTA0", {}, function(data) {
        try {
            let resultado = JSON.parse(data);
            if (resultado.Resultado != "" && resultado.Resultado != null) {
                return;
            }else{
                if(inicio_marcar == 2){
                    $("#btnMarcar1").click();
                }
            }
        } catch (error) {
            console.log("error");
        }
    });    
}

function guarda_click(id){
    jQuery("#bntagenda").attr("class", "menulink2");
    jQuery("#btnretro").attr("class", "menulink2");
    jQuery("#btnrep").attr("class", "menulink2");
    jQuery("#btndes").attr("class", "menulink2");
    jQuery("#btnjunta").attr("class", "menulink2");
    jQuery("#bntagenda").attr("disabled", "disabled");
    jQuery("#bsregistro").attr("disabled", "disabled");
    jQuery("#btnbreak").attr("disabled", "disabled");
    jQuery("#btnbano").attr("disabled", "disabled");
    jQuery("#btncapa").attr("disabled", "disabled");
    jQuery("#btnretro").attr("disabled", "disabled");
    jQuery("#btnrep").attr("disabled", "disabled");
    jQuery("#btndes").attr("disabled", "disabled");
    jQuery("#btnjunta").attr("disabled", "disabled");
    jQuery("#terminar_ss").attr("disabled", "disabled");

    $.post("modules.php?mod=agentes&op=process_data&act=Njc=",{
        id:id
    },function(data,status){

    });
}

var valScore = 640;
var arrayTKN = ['', '3', '4', '5']; // tk permitidos para hacer prescreening

function prescrining_(boton, num_proceso=null){
    var tkn = $('#spanTK').text();
    var sb = $('#spanSB').text();
    var flag = true;

    if(arrayTKN.includes(tkn)){

        console.log("entre aqui");;
        // validar numero de procesos prescrining solicitados
        var tblResult = $('#result2').length;
        if(tblResult == 1){
            $('#result2 table tr').each(function(index){
                value_ = $(this).find('td:first').text();

                if(index > 1){
                    num_consulta = $(this).find('td:eq(2)').text();
                }

                if(index == 2 && num_proceso==null){
                    if(isNaN(parseInt(value_)) && num_consulta!=''){
                        swal('Aun no se obtiene el resultado de la primer consulta');
                        flag = false;
                        return false;

                    } else if(isNaN(parseInt(value_))){ // si NO hay un valor n�merico
                        swal('Se enviara la primer consulta de Prescreening SIN datos de direccion.');
                        return false;

                    } else if(parseInt(value_) < valScore){
                        swal('Se detecto un score muy bajo en la primera consulta. Ingresa los datos de direccion para hacer un segundo Prescreening.');
                        flag = false;
                        return false;
                    } else if(parseInt(value_) > valScore){
                        swal('Ya se habia solicitado el Score y es ' + parseInt(value_) + '. No es necesario hacerlo nuevamente.');
                        flag = false;
                        return false;
                    }

                } else if(index == 2 && num_proceso!=null){
                    if(isNaN(parseInt(value_)) && num_consulta!=''){
                        swal('Aun no se obtiene el resultado de la primer consulta');
                        flag = false;
                        return false;

                    } else if(parseInt(value_) <= 0){
                        swal('La primer consulta de Prescreening arrojo ' + value_ + '. Se enviara una segunda consulta');
                        return false;

                    } else if(parseInt(value_) > 0){
                        swal('Ya se habia solicitado el Score y es ' + parseInt(value_) + '. No es necesario hacerlo nuevamente.');
                        flag = false;
                        return false;
                    }
                }

                if(index > 3){
                    swal('Ya se realizo el numero maximo (2) de consultas de Score.');
                    return false;
                }
            });
        }

        var pri_nombre = eval("document.SurveyResponse.txtQId11CId2.value");
        var seg_nombre = eval("document.SurveyResponse.txtQId11CId3.value");
        var ap_paterno = eval("document.SurveyResponse.txtQId11CId4.value");
        var ap_materno = eval("document.SurveyResponse.txtQId11CId5.value");
        var fec_nac = eval("document.SurveyResponse.txtQId11CId6.value");
        var rfc = eval("document.SurveyResponse.txtQId11CId7.value");
        var direccion = '';
        var ciudad = '';
        var cp = '';
        var num_int = '';
        var proceso_presc = '';

        if(num_proceso == 2){
            direccion = $("input[name='txtQId12CId3']").val();
            ciudad = $("#ESTADO1 option:selected").text();
            cp = $("input[name='txtQId12CId8']").val();
            num_int = $("input[name='txtQId12CId4']").val();

        } else if(num_proceso == 3){
            direccion = $("input[name='txtQId12CId15']").val();
            ciudad = $("#ESTADO2 option:selected").text();
            cp = $("input[name='txtQId12CId18']").val();
            num_int = $("input[name='txtQId12CId16']").val();
            proceso_presc = ' Alterno';
        }


        if(parseInt(sb) >= valScore){
            swal('No es necesario hacer el proceso de PRESCREENING. El SCORE es ' + sb);
            flag = false;
            return false;

        } else{
            if(pri_nombre == ""){
                swal("Ingrese el nombre");
                return false;
            }
            if(ap_paterno == ""){
                swal("Ingrese el Ap. Paterno");
                return false;
            }
            if(fec_nac == ""){
                swal("Cuidado", "Ingrese la Fecha de Nacimiento", "warning");
                return false;
            }
            if(rfc == ""){
                swal("Ingrese el RFC de Nacimiento");
                return false;
            }

            if(num_proceso!=null){
                if(cp == ""){
                    swal("Ingrese el CP en Domicilio" + proceso_presc);
                    return false;
                }

                if(direccion == ""){
                    swal("Ingresa la Calle en Domicilio" + proceso_presc);
                    return false;
                }

                if(num_int == ""){
                    swal("Ingresa el numero exterior en Domicilio" + proceso_presc);
                    return false;
                }

                if(ciudad == ""){
                    swal("Seleccione el Estado en Domicilio" + proceso_presc);
                    return false;
                }
            }
        }


        if(flag == true){
            $.post("modules.php?mod=agentes&op=process_data&act=ODc=",{//89
                nombre:pri_nombre +" "+seg_nombre,
                ap_panterno:ap_paterno ,
                ap_materno: ap_materno,
                fec_nac:fec_nac ,
                rfc:rfc,
                cp:cp,
                direccion:direccion,
                num_int:num_int,
                ciudad:ciudad,
                act2:1,
                num_proceso : num_proceso
            },function(data,status){
                swal(data);
            });
        }


    } else{
        swal('TK es igual a ' + tkn + '. No se requiere hacer Prescreening');
        return false;
    }
}

function AbandonarV2(boton, telefonos, action, ispredictivo) {
    var suma = 0;
    var contacto = 0;

    $.post("modules.php?mod=agentes&op=process_data&act=MTA0", {}, function(data) {
        try {
            let resultado = JSON.parse(data);
            if (resultado.Resultado != "" && resultado.Resultado != null) {
                document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=MTA1';
                document.frm1.submit();
                return;
            }

            // Mover la lógica que depende del resultado de $.post aquí
            for (var i = 1; i <= telefonos; i++) {
                var tel = eval('document.frm1.tel_0' + i + '.value');
                if (tel != 0) {
                    if (tel == 1010) {
                        contacto += 1;
                    } else {
                        suma += 1;
                    }
                }
            }

            if (contacto != 0) {
                swal('Error', 'Si vas a Abandonar el registro no debes calificar Contacto', 'warning');
                boton.disabled = false;
                return false;
            } else {
                if (suma < telefonos) {
                    swal("¡Cuidado!", "Debes calificar lo(s) Telefono(s) disponibles para poder Abandonar", "info");
                    boton.disabled = false;
                    return false;
                }
            }

            if (ispredictivo == 1 && contacto == 0) {
                $(function() {
                    $("#dialog-proceso").dialog({
                        autoOpen: true,
                        height: 100,
                        width: 350,
                        modal: true,
                        closeOnEscape: false,
                        create: function(event, ui) {
                            jQuery('.ui-dialog-titlebar-close').hide();
                        }
                    });
                });
            }
            

            document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
            document.frm1.submit();
        } catch (error) {
            console.log("error");
        }
    });
}


function NoAgendar(){
    swal("Error","Recuerda que ya llegaste al limite de tus agendas de hoy!","warning");
}

function barra(ispredictivo){
    if (ispredictivo == 1) {
            $(function() {
                $("#dialog-proceso").dialog({
                    autoOpen: true,
                    height: 150,
                    width: 450,
                    modal: true,
                    closeOnEscape: false,
                    resizable: false,
                    position: {my: "center"},
                    draggable: false,
                    open: function(event, ui) {
                        jQuery('.ui-dialog-titlebar-close').hide();
                    }
                });
            });
        }
}

// pintar bot�n para prescreening con direccion.
function drawBtnPrescreeningDir(num_proceso){
    $('#CP'+(num_proceso-1)).parent().find('br').remove(); // eliminar salto de l�nea
    if($('#btnPrescreening'+num_proceso).length == 0){
        $('#CP'+(num_proceso-1)).parent().append(
            '<button id="btnPrescreening'+num_proceso+'" class="custionario_boton btnPrescreening_" style="margin-left:1rem;" onclick="prescrining_(this, '+num_proceso+');return false;">'+
                'PRESCREENING'+
            '</button>'
        );
    }
}

function closeModal(){
    $('#myModal').hide();
}

function showHideAct(e, id){
    e.preventDefault();
    // ocultar todos los div abiertos
    $('.divAct').hide();
    $('#resultAct_'+id).remove();

    //mostrar la información del div clickeado
    var id_ = id.replace('tituloActualizacion_', 'divActualizacion_');
    $('#'+id_).show();
}

function cargarActualizaciones(){
    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'modules.php?mod=agentes&op=process_data&act=OTA=',    //90
        success: function(response){
            console.log(response);         
            var len = response.length;
            var cont = 0; // contador de actualizaciones pendientes

            for(var i=0; i<len; i++){
                var data = response[i];

                var display_ = 'none;'; // variable para mostrar/ocultar botón de actualización leída
                var display__ = 'none;';
                var read = ''; // variable para estilo de actualización leída

                var id = data.slice(0,1)[0];
                var act = data.slice(1,2)[0];
                var fec_creado = data.slice(2,3)[0];
                var creado_por = data.slice(3,4)[0];
                var nomina = data.slice(4,5)[0];
                var nombre_agente = data.slice(5,6)[0];
                var leido = data.slice(6,7)[0];
                var fec_leido = data.slice(7,8)[0];
                var estatus = data.slice(8)[0];

                if(leido==null){
                    cont++;
                    display_ = 'block;';
                } else{
                    read = 'style="background-color:#28a745;border:1px solid #28a745;color:#000;"';
                }

                if(estatus == 1){
                    display__ = 'block;';
                }

                var msgs = msgs +
                '<div class="direct-chat-msg shadow" style="display:'+display__+'">'+
                    '<div class="direct-chat-infos clearfix">'+
                        '<span class="direct-chat-name float-left">'+creado_por+'</span>'+
                        '<span class="direct-chat-timestamp float-right">'+fec_creado+'</span>'+
                    '</div>'+
                    '<div id="tituloActualizacion_'+id+'" '+read+' onclick="showHideAct(event, this.id);" class="direct-chat-text">'+act.substring(0, 30)+'...</div>'+
                        '<div id="divActualizacion_'+id+'" class="divAct" style="display:none;">'+
                            '<p>'+act+'</p>'+
                            '<div style="text-align:right;display:'+display_+'"><button id="btnMarcarLeido_'+id+'" class="btn btn-success" onclick="marcarLeido(event, '+id+');">Ya lo le&iacute;</button></div>'+
                        '</div>'+
                '</div>';
            }

            if(cont==0){
                $('#closeModal').show();
                $('#imgActualizaciones').hide();
            } else{
                $('#imgActualizaciones').show();
            }

            $('#totalAct').html(cont+' Pendiente(s)');
            $('#divActualizaciones').html(msgs); 
        }
    });
}

function marcarLeido(e, id){
    e.preventDefault();

    $.ajax({
        type: 'POST',
        url: 'modules.php?mod=agentes&op=process_data&act=OTE=',    //91
        data: {'id':id},
        success: function(response){
            console.log(response);
            $('#divActualizacion_'+id).append('<p id="resultAct_'+id+'" style="color:green;font-weight:bold;">'+response+'</p>');
            $('#btnMarcarLeido_'+id).hide(); // ocultar btn leido
            $('#tituloActualizacion_'+id).css({'background-color':'#28a745','border':'1px solid #28a745','color':'#000'}); // dar estilo de leído

            evaluaActPendientes();
        }
    });
}

function evaluaActPendientes(){
    tot_p = parseInt($('#totalAct').text().replace(' Pendiente(s)', ''));

    $('#totalAct').html((tot_p-1) + ' Pendiente(s)');

    if(parseInt($('#totalAct').text().replace(' Pendiente(s)', '')) == 0){
        $('.close').show();
    }
}


function saveDataAutenticacion(){
    var folio = document.getElementById('folioAutenticacion').value;
    var score = document.getElementById('score').value;
    var intentos = document.getElementById('intentos').value;

    var valida = validaDatosAutenticacion(folio, score, intentos);

    
    
    if(valida == 1){
        console.log('Folio:', folio);
        console.log('Score:', score);
        console.log('Intentos:', intentos);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: "modules.php?mod=agentes&op=process_data&act=OTMK", //93
            data:{
                'folio' : folio,
                'score' : score,
                'intentos' : intentos
            },
            success: function(response){
                if(response == '1'){
                    swal("Exitoso","Se guardaron correctamente los datos de autenticacion.", "success");
                    localStorage.setItem("folioAutenticacion", folio);
                } else{
                    swal("Cuidado", "ERROR. No se pudo guardar la informacion, favor de recargar la pagina respaldando previamente tu informacion en tus notas", "error");
                    localStorage.setItem("folioAutenticacion", 'SIN_FOLIO');
                }
            },
            error: function (xhr, status, error) {
                swal("Cuidado", "ERROR. No se pudo guardar la informacion, favor de recargar la pagina respaldando previamente tu informacion en tus notas", "error");
                localStorage.setItem("folioAutenticacion", 'SIN_FOLIO');

            }
        });
    } else{
        swal("Cuidado",valida, "error");
    }
}

function validaDatosAutenticacion(folio, score, intentos) {
    var errores = '';
    var contErrores = 0;

    if (folio == '' || score == '' || intentos == '') {
        errores = 'Todos los campos deben llenarse para continuar.\n\n\n';
        contErrores = 3;
    } else {
        var regExp_folio = /^[A-Za-z0-9]{10,}$/;
        var regExp_score = /^[0-9]{1,3}$/;
        var regExp_intentos = /^[0-9]{1,2}$/;

        if (!regExp_folio.test(folio)) {
            contErrores++;
            errores += 'El folio debe ser alfanumérico y compuesto por 10 o más caracteres.\n';
        }

        if (!regExp_score.test(score)) {
            contErrores++;
            errores += 'En el score solo se aceptan números desde 0 hasta 999.\n';
        }

        if (!regExp_intentos.test(intentos)) {
            contErrores++;
            errores += 'En intentos debes ingresar un número entre 0 y 99';
        } 
    }

    if (contErrores > 0) {
        return errores;
    } else {
        return 1;
    }
}


function confirm_(text_, msg, action_, form_, ispredictivo=null){
    swal({
        title: "ATENCION",
        text: text_,
        type: "warning",
        showCancelButton: true,
        confirmButtonText: "Continuar",
        confirmButtonClass: "btn-warning",
        cancelButtonText: "Cancelar",
        cancelButtonClass: "btn-danger"
    },
    function(isConfirm) {
        if (isConfirm){
            swal(msg, {
                icon: "success",
            });
            redirige(action_, form_, ispredictivo);
        }
    });
}

function setVentasButton(){

        // Consulta de ventas por agente
        $("#consultarVentasPred, #consultarVentasAsis").click(function() {
            const contenedor = document.getElementById('dataConsultaVenta');
            while(contenedor.firstChild){
                contenedor.removeChild(contenedor.firstChild);
            }

            if($(this).attr('data-state') == 0){
                contenedor.innerHTML = '<div id="lcontainer"><img src="includes/imgs/LoadingV.gif" alt="loading" class="loader"/><br/><p class="loader">Un momento, por favor...</p></div> ';
                $(this).attr('data-state', '1');
                $(this).val('Cerrar consulta');
                $(this).removeClass( "btn btn-primary btn-nuevo_diseno" ).addClass( "btn btn-warning btn-nuevo_diseno" );
                //$('#lcontainer').fadeIn();

                // Petición de datos
                const url= "modules.php?mod=agentes&op=process_data&act=MTA2"
                fetch(url)
                .then(response => {
                    if (!response.ok) { throw new Error('Error en la consulta: ' + response.statusText);                    
                    }
                    return response.json(); // Procesar la respuesta como JSON
                })
                .then(data => {
                    //console.log(data);
                    $('#lcontainer').fadeOut();
                    generatedTable(data);
                          
                })
                .catch(error => {
                    console.log('Fetch error: ', error);
                });

            }else{
                $(this).attr('data-state', '0')
                $(this).val('Consultar ventas');
                $(this).removeClass( "btn btn-warning btn-nuevo_diseno" ).addClass( "btn btn-primary btn-nuevo_diseno" );
            }
            $("#containerConsultaVenta").slideToggle("slow");
        });
}

function generatedTable(data){
    const contenedor = document.getElementById('dataConsultaVenta'); 
    if(data[1] == "Sin datos"){
        contenedor.innerHTML = '<div class="notificacion" id="notificacion">Sin datos</div>';
    }else{
        //contenedor.classList.add("tableStyle");       
    
        // Crear la tabla y el encabezado
        const tabla = document.createElement('table');
        const thead = document.createElement('thead');
        const tbody = document.createElement('tbody');
        
        tabla.className = "cell-border";
        tabla.id = "result";
        tabla.classList.add("table");
        tabla.classList.add("table-striped");
        tabla.classList.add("table-hover");
        tabla.classList.add("table-sm");
        thead.classList.add("table-primary");
    
        // Crear encabezados a partir del primero objeto del arreglo
        const encabezados = Object.keys(data[0]);
        const filaEncabezado = document.createElement('tr');
    
        encabezados.forEach(encabezado => {
        const th = document.createElement('th');
        th.textContent = encabezado.charAt(0).toUpperCase() + encabezado.slice(1); 
        filaEncabezado.appendChild(th);
        });
    
        thead.appendChild(filaEncabezado);
        tabla.appendChild(thead);
    
    
        // Crear filas de datos
        data.forEach(item => {
            const fila = document.createElement('tr');
            encabezados.forEach(encabezado => {
                const td = document.createElement('td');
                if(item[encabezado] === null){
                td.textContent = "0";
                }else{
                td.textContent = item[encabezado];
                }
                fila.appendChild(td);
            });
            tbody.appendChild(fila);
        });
    
        tabla.appendChild(tbody);
        contenedor.appendChild(tabla);
    }

}
