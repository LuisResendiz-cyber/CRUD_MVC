const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN CSP_GETPRODUCTOS_WSF(:customerid, :u_user, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.customerid || !context.u_user){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.customerid = context.customerid;
            binds.u_user = context.u_user;
            binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};


            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;

/*
function get_productos_campanaf($id_solicitud,$user, $db) {
    $stmt = $db->PrepareSP("BEGIN CSP_GETPRODUCTOS_WSF(:customerid,:u_user, :rc); END;");
    $db->InParameter($stmt, $id_solicitud, 'customerid');
    $db->InParameter($stmt, $user, 'u_user');
    $rs = $db->ExecuteCursor($stmt, 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    return $rs;
}*/