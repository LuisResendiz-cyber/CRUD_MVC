import { Request, Response } from "express";
import {AuthModel,JwtService,PasswordService} from "../models/AuthModel";

class AuthController {
  private authModel: AuthModel;
  private jwtService: JwtService;
  private passwordService: PasswordService;

  constructor() {
    this.authModel = new AuthModel();
    this.jwtService = new JwtService();
    this.passwordService = new PasswordService();

  }

  public getToken = async (req: Request, res: Response): Promise<void> => {
    const { USERNAME, PASSWORD } = req.body;

    try {
      let userDb = await this.authModel.getUser(USERNAME);

      if (userDb.length === 0) {
        res
          .status(401)
          .json({ status: "Error", details: `${USERNAME} not found` });
        return;
      }
      const user = userDb[0];
      const isvalid = await this.passwordService.comparePasswords(PASSWORD, user.PASS);
      if (!isvalid) {
        res.status(401).json({ status: "Error", details: "Invalid password" });
        return
      }
      const token = this.jwtService.generateToken(user);
      res.json({ token })
      return       

    } catch (error) {
      res.json({ message: "test" });
      return;
    }
  };

  public createUser = async (req: Request, res: Response): Promise<void> => { 
    /**
   * Este metodo aun no esta completo
   */
    const { USERNAME, PASSWORD } = req.body;

    let pass = await this.passwordService.hashPassword(PASSWORD);
    console.log(pass);
    res.json({ pass })
      return  

  }
}



export default AuthController;
