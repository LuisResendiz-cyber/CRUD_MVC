<?php
class ControladorUsuarios
{
	//	INGRESO DE USUARIO
	public function ctrIngresoUsuario(){
		if (isset($_POST["ingUsuario"])) {
			if (preg_match('/^[a-zA-Z0-9]+$/', $_POST["ingUsuario"])) {

				$encriptar = crypt($_POST["ingPassword"], '$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');

				$tabla = "usuarios";

				$item = "usuario";

				$valor = $_POST["ingUsuario"];

				$respuesta = ModeloUsuarios::MdlMostrarUsuarios($tabla, $item, $valor);
				$respuesta_enlaces = ModeloUsuarios::mdlMostrarEnlaces($item, $valor);


				if ($respuesta["usuario"] == $_POST["ingUsuario"] && $respuesta["password"] == $encriptar) {
					if ($respuesta["estado"] == 1) {
						$_SESSION["iniciarSesion"] = "ok";
						$_SESSION["id"] = $respuesta["id"];
						$_SESSION["nombre"] = $respuesta["nombre"];
						$_SESSION["usuario"] = $respuesta["usuario"];
						$_SESSION["perfil"] = $respuesta["perfil"];
						$_SESSION['enlaces_usuario'] = $respuesta_enlaces;
						
						date_default_timezone_set('America/Bogota');
						//Mexico_City
						$fecha = date('Y-m-d');
						$hora = date('H:i:s');
						$fechaActual = $fecha . ' ' . $hora;
						$item1 = "ultimo_login";
						$valor1 = $fechaActual;
						$item2 = "id";
						$valor2 = $respuesta["id"];
						$ultimoLogin = ModeloUsuarios::mdlActualizarUsuario($tabla, $item1, $valor1, $item2, $valor2);



						if ($ultimoLogin == "ok") {



							echo '<script>



								window.location = "?ruta=inicio";



							</script>';
						}
					} else {



						echo '<script>



					swal({



						type: "error",

						title: "¡El usuario aún no está activado!",

						showConfirmButton: true,

						confirmButtonText: "Cerrar"



					});

				</script>';
					}
				} else {

					echo '<script>

					swal({

						type: "error",

						title: "¡Error al ingresar, vuelve a intentarlo!",

						showConfirmButton: true,

						confirmButtonText: "Cerrar"

					});

				</script>';
				}
			}
		}
	}

	static public function ctrCrearUsuario()
	{



		if (isset($_POST["nuevoUsuario"])) {



			if (
				preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevoNombre"]) &&

				preg_match('/^[a-zA-Z0-9]+$/', $_POST["nuevoUsuario"]) &&

				preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ@$%&()*]+$/', $_POST["nuevoPassword"])
			) {





				$tabla = "usuarios";



				$encriptar = crypt($_POST["nuevoPassword"], '$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');



				$datos = array(
					"nombre" => $_POST["nuevoNombre"],

					"usuario" => $_POST["nuevoUsuario"],

					"password" => $encriptar,

					"perfil" => $_POST["nuevoPerfil"]
				);



				$respuesta = ModeloUsuarios::mdlIngresarUsuario($tabla, $datos);



				if ($respuesta == "ok") {



					echo '<script>



					swal({



						type: "success",

						title: "¡El usuario ha sido guardado correctamente!",

						showConfirmButton: true,

						confirmButtonText: "Cerrar"



					}).then(function(result){



						if(result.value){

						

							window.location = "?ruta=usuarios";



						}



					});

				



					</script>';
				}
			} else {



				echo '<script>



					swal({



						type: "error",

						title: "¡El usuario no puede ir vacío o llevar caracteres especiales!",

						showConfirmButton: true,

						confirmButtonText: "Cerrar"



					}).then(function(result){



						if(result.value){

						

							window.location = "?ruta=usuarios";



						}



					});

				



				</script>';
			}
		}
	}

	static public function ctrAsignarCampanas(){
	    if (isset($_POST["Usuario_id"])) {
	        $tabla = "usuario_campana";

	        // Construcción de los datos a partir de los checkboxes
	        $datos = [
		  "id_Usuario" => intval($_POST["Usuario_id"]) ?? 100,
	        ];
	
	        $checkboxes = [
		  "Invex_Internet" => "id_Invex_Internet",
		  "BanorteCredito" => "id_BanorteCredito",
		  "Amex_Insurance" => "id_Amex_Insurance",
		  "HSBC" => "id_HSBC",
		  "TDCAMEXONLINE" => "id_TDCAMEXONLINE",
		  "OpenPay" => "id_OpenPay",
		  "Amex_Insurance_Digital" => "id_Amex_Insurance_Digital",
		  "Citibanamex" => "id_Citibanamex",
		  "CitiBanco" => "id_CitiBanco",
		  "CitiSofom" => "id_CitiSofom",
		  "INVEXINT" => "id_INVEXINT"
	        ];
	
	        // Solo incluir en $datos aquellos checkboxes que están definidos en $_POST
	        foreach ($checkboxes as $postKey => $dbKey) {
		  if (isset($_POST[$postKey])) {
		      $datos[$dbKey] = intval($_POST[$postKey]);
		  }
	        }
	
	        // Mostrar datos antes de enviar al modelo
	       // var_dump($datos);
	
	        // Llamada al modelo
	        $respuesta = ModeloUsuarios::mdlAsignarCampaña($tabla, $datos);

	        // Verificar respuesta y mostrar alertas
	        if ($respuesta == "ok") {
		  echo '<script>
		      swal({
			type: "success",
			title: "¡Se ha Agregado Correctamente el Usuario a las Campañas Seleccionadas!",
			showConfirmButton: true,
			confirmButtonText: "Cerrar"
		      }).then(function(result){
			if(result.isConfirmed){        
			    window.location = "?ruta=enlaces";
			}
		      });
		  </script>';
	        } else {
		  echo '<script>
		      swal({
			type: "error",
			title: "¡Ocurrió un error al guardar el Registro!",
			showConfirmButton: true,
			confirmButtonText: "Cerrar"
		      }).then(function(result){
			if(result.isConfirmed){
			    window.location = "?ruta=enlaces";
			}
		      });
		  </script>';
	        }
	    }
	}
	

	//MOSTRAR USUARIO
	static public function ctrMostrarUsuarios($item, $valor)
	{



		$tabla = "usuarios";



		$respuesta = ModeloUsuarios::MdlMostrarUsuarios($tabla, $item, $valor);



		return $respuesta;
	}

	//	EDITAR USUARIO
	static public function ctrEditarUsuario()
	{
		if (isset($_POST["editarUsuario"])) {
			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarNombre"])) {
				$tabla = "usuarios";
				if ($_POST["editarPassword"] != "") {
					if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ@$%&()* ]+$/', $_POST["editarPassword"])) {
						$encriptar = crypt($_POST["editarPassword"], '$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');
					} else {
						echo '<script>
								swal({
									  type: "error",

									  title: "¡La contraseña no puede ir vacía o llevar caracteres especiales!",

									  showConfirmButton: true,

									  confirmButtonText: "Cerrar"

									  }).then(function(result) {

										if (result.value) {



										window.location = "?ruta=usuarios";



										}

									})



						  	</script>';



						return;
					}
				} else {



					$encriptar = $_POST["passwordActual"];
				}



				$datos = array(
					"nombre" => $_POST["editarNombre"],

					"usuario" => $_POST["editarUsuario"],

					"password" => $encriptar,

					"perfil" => $_POST["editarPerfil"]
				);



				$respuesta = ModeloUsuarios::mdlEditarUsuario($tabla, $datos);



				if ($respuesta == "ok") {



					echo '<script>



					swal({

						  type: "success",

						  title: "El usuario ha sido editado correctamente",

						  showConfirmButton: true,

						  confirmButtonText: "Cerrar"

						  }).then(function(result) {

									if (result.value) {



									window.location = "?ruta=usuarios";



									}

								})



					</script>';
				}
			} else {



				echo '<script>



					swal({

						  type: "error",

						  title: "¡El nombre no puede ir vacío o llevar caracteres especiales!",

						  showConfirmButton: true,

						  confirmButtonText: "Cerrar"

						  }).then(function(result) {

							if (result.value) {



							window.location = "?ruta=usuarios";



							}

						})



			  	</script>';
			}
		}
	}

	static public function ctrBorrarUsuario()
	{



		if (isset($_GET["idUsuario"])) {



			$tabla = "usuarios";

			$datos = $_GET["idUsuario"];



			$respuesta = ModeloUsuarios::mdlBorrarUsuario($tabla, $datos);



			if ($respuesta == "ok") {



				echo '<script>



				swal({

					  type: "success",

					  title: "El usuario ha sido borrado correctamente",

					  showConfirmButton: true,

					  confirmButtonText: "Cerrar",

					  closeOnConfirm: false

					  }).then(function(result) {

								if (result.value) {



								window.location = "?ruta=usuarios";



								}

							})



				</script>';
			}
		}
	}
}
