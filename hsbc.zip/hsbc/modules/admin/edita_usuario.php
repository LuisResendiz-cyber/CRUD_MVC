<?php
ini_set("display_errors",1);
# @uthor Mark 
# edita_usuario File

require_once("includes/includes.inc.php");
require_once("admin.inc.php");

initialize("administrador","Editar Usuario", $db);
get_menu($db, "");

$id_user = trim($_REQUEST['idSelected']);
$usuarios = get_informacion_usuario($id_user, $db);
$var = $usuarios->fields['ISUPERVISOR_ID'];
?>
	<h4>Editar Usuario</h4>
	<p id="text">Capture los datos del usuario y d&eacute; click en el bot&oacute;n continuar</p>
	<br>

	<form name="frm1" method="post" action="modules.php?mod=admin&op=process_data&act=5">
		<input type="hidden" name="idSelected" value="<?=$id_user?>">
		<table  id="t1" border="0">
		   <tr>
		        <td colspan="2"><?=form_oblmsg()?></td>
		    </tr><tr>
				<td colspan="2">&nbsp;</td>
			</tr><tr>
				<td><b>Id Usuario:</b></td>
				<td class="label"><?=$usuarios->fields['IUSR_ID']?></td>
			</tr><tr>
				<td><b>* Nombre:</b></td>
				<td><input type="text" name="nombre" maxlength="80" size="80" value="<?=$usuarios->fields['VNOMBRE']?>" class="label"></td>
		    </tr><tr>
				<td><b>Contrase&ntilde;a:</b></td>
				<td><input type="password" name="contrasena"  maxlength="8" size="10" class="label"></td>
		    </tr><tr>
				<td><b>Reescribir contrase&ntilde;a:</b></td>
				<td><input type="password" name="re_contrasena"  maxlength="8" size="10" class="label"></td>
			</tr><tr>
				<td><b>* Perfil:</b></td>
				<td>
					<select name="perfil" onchange="muestra_super(this)">
						<option value="0">Seleccione perfil</option>
						<?
						$catalogos = get_perfiles('USR_NIVEL', $db);
						while(!$catalogos->EOF) {
							echo '<option value="'.$catalogos->fields["VVALOR"].'" '.(trim($catalogos->fields["VVALOR"])==trim($usuarios->fields['VNIVEL'])?"selected":"").'>'.$catalogos->fields["VVALOR"].' - '.$catalogos->fields["VETIQUETA"].'</option>';
							$catalogos->MoveNext();
						}
						?>
					</select>
				</td>
			</tr><tr>
				<!--td colspan="2">
				<br>
					<table <?//=((trim($usuarios->fields['VNIVEL']) == "A" || trim($usuarios->fields['VNIVEL']) == "AI")?"":"style='display:none'")?> id="super">
						<tr>
							<td width="36%"><b>* Supervisor:</b></td>
							<td>
								<select name="supervisor">
									<?
									/*$supervisores = get_supervisores(1,$db);
									while(!$supervisores->EOF) {
										//echo '<option value="'.$supervisores->fields["USR_ID"].'" '.($supervisores->fields["USR_ID"]==trim($usuarios->fields['USR_NIVEL'])?"selected":"").'>'.$supervisores->fields["USR_NOMBRE"].'</option>';
										echo '<option value="'.$supervisores->fields["IUSR_ID"].'" '.($supervisores->fields["IUSR_ID"]==$var?"selected":"").'>'.$supervisores->fields["VNOMBRE"].'</option>';
										$supervisores->MoveNext();
									}*/
									?>
								</select>
							</td>
						<tr>
					</table>
				</td>
			</tr><tr-->
				<td><b>Activo</b></td>
				<td><input type="checkbox" name="activo" <?=($usuarios->fields["VACTIVO"]==1?"checked":"")?>></td>
			</tr><tr>
				<td><b>Etapa</b></td>
				<td>
					<select name="etapa">
						<?
						$catalogos = get_perfiles('IETAPA_ID', $db);
						while(!$catalogos->EOF) {
							echo '<option value="'.$catalogos->fields["VVALOR"].'" '.(trim($catalogos->fields["VVALOR"])==trim($usuarios->fields['VGENERACION_ID'])?"selected":"").'>'.$catalogos->fields["VETIQUETA"].'</option>';
							$catalogos->MoveNext();
						}
						?>
					</select>
				</td>
			</tr><tr>
				<td><b>Generacion</b></td>
				<td><input type="text" name="generacion" value="<?=$usuarios->fields["VGENERACION_ID"]?>" maxlength="10"></td>
			</tr>
		</table>
		<br>
		<input type="button" value="Cancelar" onclick="back()">
		<input type="button" value="Continuar" onclick="valida_edicion_usuario(2)">
	</form>
	<br>
<?php
get_footer();
?>

         
          