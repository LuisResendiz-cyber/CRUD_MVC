<?php
$url = "https://app.powerbi.com/view?r=eyJrIjoiNGRlNzY2NWItYjA3NC00Y2JhLWJhMjEtYjkyYmMzMjRmMWE0IiwidCI6IjdlMTI5ZjVjLWYxNjItNDhlYi05NTQ1LTEwYTNkODRkNDQwNSJ9";
echo file_get_contents($url);
?>


