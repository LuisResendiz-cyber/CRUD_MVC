const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find() {
  // console.log(context);

  // const baseQuery = "BEGIN " + context.schema + ".XSP_TIPIFICACION_RETROACTIVO(:u_persona, :rc); END;";
  const baseQuery = "BEGIN CITI.XSP_TIPIFICACION_RETROACTIVO(:rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  // binds.u_persona      = context.u_persona;
  binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

  const result = await database.simpleExecuteRC(query, binds);

  console.log("---", result, "....");

  return result;
}

module.exports.find = find;
