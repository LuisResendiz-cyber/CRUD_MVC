<?php
# @uthor Mark
# resultado_busq_cliente File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente,supervisor", "Resultado de la Busqueda");
layout_menu($db, "");

$estado = $_POST['estado'];
$municipio = $_POST['municipio'];
$empresa = $_POST['empresa'];
$registros = set_datos_empresas($estado, $municipio, $empresa, $db);

if ($registros->EOF) {
    $encontro = 0;
} else {
    $encontro = 1;
}
?>
<p class="textbold">Agentes &gt; Resultado de la Busqueda</p>
<p>&nbsp;</p>
    <?php
    if (!$registros->EOF) {
        echo "<table border=\"1\" align=\"center\">";
        echo "<tr>\r\n";
        for ($i = 0; $i < $registros->FieldCount(); $i++) {
            $field = $registros->FetchField($i);
            echo "<th>";
            echo $field->name;
            echo "</th>\r\n";
        }
        echo "</tr>\r\n";
        while (!$registros->EOF) {
            echo "<tr>\r\n";
            for ($i = 0; $i < $registros->FieldCount(); $i++) {
                echo "<td class=\"label\">{$registros->fields[$i]}</td>\r\n";
            }
            echo "</tr>\r\n";
            $registros->MoveNext();
        }
        echo "</table>\r\n";
    } else {
        echo "No existen registros con ese criterio.<br />\r\n";
    }
    ?>
<?php
    layout_footer();
?>