// services/chat/rules.service.js

module.exports = {
    evaluate(session) {
      if (session.status === "human") {
        return { type: "HUMAN" };
      }
  
      return { type: "BOT" };
    }
  };
  