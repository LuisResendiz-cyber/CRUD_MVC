// services/whatsappService.js
const axios = require("axios");

const TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_ID = process.env.PHONE_NUMBER_ID;
const WA_API_URL = `https://graph.facebook.com/v19.0/${PHONE_ID}/messages`;

const axiosInstance = axios.create({
  timeout: 15000,
  headers: {
    Authorization: `Bearer ${TOKEN}`,
    "Content-Type": "application/json"
  }
});

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function sendWhatsAppMessage(to, message, retries = 3) {
  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: { body: message }
  };

  let attempt = 0;
  let lastErr;

  while (attempt <= retries) {
    try {
      const start = Date.now();
      const response = await axiosInstance.post(WA_API_URL, payload);
      console.log(`[OK] ${to} (${Date.now() - start}ms)`);
      return response.data;

    } catch (err) {
      lastErr = err;
      attempt++;

      const status = err.response?.status;
      if (attempt > retries || (status && status < 500 && status !== 429)) {
        throw err;
      }

      const wait = Math.min(2000 * 2 ** attempt, 15000) + Math.random() * 300;
      console.log(`[RETRY] ${to} intento ${attempt} en ${wait}ms`);
      await sleep(wait);
    }
  }

  throw lastErr;
}

module.exports = { sendWhatsAppMessage };
