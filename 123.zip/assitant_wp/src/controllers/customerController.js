const customerModel = require("../models/customerModel");
const { sendWhatsAppMessage } = require("../services/whatsappService");

const CONCURRENCY = 15;
const BATCH_SIZE = 100;

// Controlador de concurrencia
async function promisePool(items, handler, concurrency) {
  const executing = new Set();

  for (const item of items) {
    const p = Promise.resolve().then(() => handler(item));
    executing.add(p);

    p.finally(() => executing.delete(p));

    if (executing.size >= concurrency) {
      await Promise.race(executing);
    }
  }

  await Promise.all(executing);
}

const CustomerController = {
  async sendMessages(req, res) {
    res.json({
      status: "processing",
      message: "El envío masivo comenzó en background."
    });

    console.log("=== INICIANDO ENVÍO MASIVO ===");

    setImmediate(async () => {
      try {
        const users = await customerModel.getCustomers();
        console.log(`Usuarios por enviar: ${users.length}`);

        if (!users.length) return;

        const contactsToDeactivate = [];

        await promisePool(
          users,
          async user => {
            const fullNumber = `${user.lada}${user.numero}`;
            const name = `${user.nombre}`;

            // 1. Crear registro en ENVIOS
            const id_envio = await customerModel.insertEnvio(
              user.id_contacto,
              'test'
            );

            try {
              // 2. Enviar WhatsApp
              const resp = await sendWhatsAppMessage(fullNumber, name);
              console.log(`[OK] ${fullNumber}`);

              // 3. Obtener wamid devuelto por API
              const wamid = resp.messages?.[0]?.id || null;

              if (wamid) {
                await customerModel.updateWamid(id_envio, wamid);
              }

              // 4. Log de éxito
              await customerModel.insertEnvioLog({
                id_envio,
                status_id: 1,
                errorApi: JSON.stringify(resp)
              });

            } catch (err) {
              console.log(`[ERR] ${fullNumber} -> ${err.message}`);

              // 4b. Log de error
              await customerModel.insertEnvioLog({
                id_envio,
                status_id: 2,
                errorApi: JSON.stringify(err.response?.data || err.message)
              });
            }

            // Agregar contacto al batch para desactivar
            contactsToDeactivate.push(user.id_contacto);

            if (contactsToDeactivate.length >= BATCH_SIZE) {
              console.log("Desactivando batch contactos...");
              await customerModel.deactivateContactsBatch(
                contactsToDeactivate.splice(0)
              );
            }
          },
          CONCURRENCY
        );

        // Guardar contactos restantes
        if (contactsToDeactivate.length) {
          await customerModel.deactivateContactsBatch(contactsToDeactivate);
        }

        console.log("=== ENVÍO MASIVO FINALIZADO ===");

      } catch (error) {
        console.error("Error general:", error);
      }
    });
  },

  // Webhook GET
  async verifyWebhook(req, res) {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    const verifyToken = process.env.VERIFY_TOKEN;

    if (mode && token === verifyToken) {
      return res.status(200).send(challenge);
    }

    return res.sendStatus(403);
  },

  // Webhook POST (FUNCIONAL)
  async receiveWebhook(req, res) {
    const body = req.body;

    console.log("WEBHOOK POST RECIBIDO:");
    console.log(JSON.stringify(body, null, 2));

    try {
      const entries = body.entry || [];

      for (const entry of entries) {
        const changes = entry.changes || [];

        for (const change of changes) {
          const value = change.value || {};

          // ============================================================
          // 1) STATUS CALLBACKS
          // ============================================================
          if (Array.isArray(value.statuses)) {
            for (const st of value.statuses) {
              const wamid = st.id || null;
              const from = st.recipient_id || null;
              const status = st.status || null;

              // Guardar en WHATSAPP_WEBHOOK_LOG
              try {
                await customerModel.insertWebhookLog({
                  event_type: "status",
                  wamid,
                  from_number: from,
                  status,
                  message_text: null,
                  raw_json: st
                });
              } catch (e) {
                console.error("Error insertWebhookLog(status):", e);
              }

              // Relacionar con ENVIOS
              try {
                const envio = await customerModel.getEnvioByWamid(wamid);

                if (envio && envio.id_envio) {
                  await customerModel.insertEnvioStatus({
                    id_envio: envio.id_envio,
                    status
                  });

                  console.log(
                    `ENVIOS_STATUS agregado -> envio ${envio.id_envio}, status ${status}`
                  );
                } else {
                  console.log(`No existe ENVIOS con wamid=${wamid}`);
                }
              } catch (e) {
                console.error("Error insertEnvioStatus:", e);
              }
            }
          }

          // ============================================================
          // 2) MENSAJES INBOUND (SI TE CONTESTAN)
          // ============================================================
          if (Array.isArray(value.messages)) {
            for (const msg of value.messages) {
              const wamid = msg.id || null;
              const from = msg.from || null;

              let text = null;

              // 🔥 1. Si es mensaje de texto normal
              if (msg.type === "text") {
                text = msg.text?.body || null;
              }

              // 🔥 2. Si es un botón interactivo
              else if (msg.type === "interactive") {
                if (msg.interactive.type === "button_reply") {
                  text = msg.interactive.button_reply.id; // id del botón
                } else if (msg.interactive.type === "list_reply") {
                  text = msg.interactive.list_reply.id; // si algún día usas listas
                }
              }

              // Guardar en WHATSAPP_WEBHOOK_LOG
              try {
                await customerModel.insertWebhookLog({
                  event_type: "message",
                  wamid,
                  from_number: from,
                  status: null,
                  message_text: text,
                  raw_json: msg
                });
              } catch (e) {
                console.error("Error insertWebhookLog(message):", e);
              }

              console.log(`Inbound WhatsApp: ${from} → "${text}"`);

              // 🔥🔥🔥 Si el botón fue "solicitar_tarjeta", registramos la solicitud 🔥🔥🔥
              if (text === "solicitar_tarjeta") {
                try {
                  await customerModel.insertSolicitudTarjeta({
                    telefono: from,
                    fecha: new Date()
                  });
          
                  console.log("Solicitud de tarjeta registrada en la BD.");
                } catch (error) {
                  console.error("Error insertSolicitudTarjeta:", error);
                }
              }
            }
          }
        }
      }

    } catch (err) {
      console.error("Error procesando webhook:", err);
    }

    res.sendStatus(200);
  }
};

module.exports = CustomerController;
