const { Server } = require("socket.io");
const { processIncomingMessage, closeChatByInactivity, reopenSession } = require("../services/MessageFlow.service");

const customerModel =  require("../models/webchat.models");

let ioInstance = null;

function initWebSocket(server) {
  const io = new Server(server, {
    cors: { origin: "*" }
  });

  ioInstance = io; // 🔑 CLAVE

  io.on("connection", (socket) => {
    const { session_id } = socket.handshake.auth;

    if (session_id) {
      socket.join(session_id); // 🔑 CLAVE
    }

    socket.on("user_message", async (text) => {
      const reply = await processIncomingMessage({
        session_id,
        message: text,
        channel: "web"
      });

      if (reply) {
        io.to(session_id).emit("bot_message", reply);
      }
    });

    socket.on("chat_idle", async () => {
      console.log("⏳ Chat cerrado por inactividad:", session_id);
      await closeChatByInactivity(session_id);
      io.to(session_id).emit("chat_closed");

      socket.emit("chat_closed");

    });

    socket.on("chat_reactivate", async () => {
      console.log("⏳ Chat Reactivado:", session_id);
      await reopenSession(session_id);
    });
    
  });
}

function emitToSession(sessionId, event, payload) {
  if (!ioInstance) return;
  ioInstance.to(sessionId).emit(event, payload);
}

module.exports = { initWebSocket, emitToSession };
