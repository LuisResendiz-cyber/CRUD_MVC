const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".XSP_SETESTATUSREGISTRO(:reg, :stat, :llam, :pri, :user_, :elapsed, :comm, :camp, :segundosEnllamda, :tipoCampana); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

    if(!context.reg || !context.stat || !context.llam || !context.pri || !context.user_ || !context.elapsed || !context.comm || !context.camp || !context.segundosEnllamda || !context.tipoCampana){
      //console.log("Parametros incorrectos")
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;

    } else{
        binds.user_     = context.user_;
        binds.reg      = context.reg;
        binds.elapsed      = context.elapsed;
        binds.stat      = context.stat;
        binds.llam      = context.llam;
        binds.comm      = context.comm;
        binds.camp      = context.camp;
        binds.pri      = context.pri;
        binds.tipoCampana      = context.tipoCampana;
        binds.segundosEnllamda      = context.segundosEnllamda;        

        const result = await database.simpleExecute(query, binds);
        // console.log(result);	
        return result;
    }            
}
 
module.exports.find = find;