const oracledb = require('oracledb');
const database = require('../services/database.js');
 

 
async function find(context) {

  const baseQuery = "BEGIN "+ context.schema +".SPS_GRABADA(:customerid, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  	binds.customerid     = context.customerid;
  	binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
	
  const result = await database.simpleExecuteRC(query, binds);
  // console.log(result); 
  return result;
}
 
module.exports.find = find;