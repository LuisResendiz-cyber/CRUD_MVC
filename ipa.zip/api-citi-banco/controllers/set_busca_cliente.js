const get_agente_info = require('../db_apis/set_busca_cliente.js');
const fetch = require('node-fetch'); 
const jwt = require('./token_manager'); 
const config  = require('../config/web-server'); 
async function post(req, res, next) {
  try {
    const context = req.body;//{};
    const params = {
      fecha_carga: context.fecha_carga,
      schema: context.schema
    };

    // let data = await fetch(config.keyRingHost, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'access_token': jwt.get(),
    //     'Accept': 'application/json'
    //   },
    //   body: JSON.stringify(params)
    // })
    // .then(res=>res.json())
    // .then(data=>{
    //   if(!data.error){
    //     jwt.set(data.idtoken)
    //     context.keyrig=data.dataKey;
    //   }
    //   else{
    //     res.status(500);
    //     throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );       
    //   }
    // })
    // .catch(err=>{
    //   res.status(500);
    //   return err;
    // })    
 
    const rows = await get_agente_info.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;
