const insert_tucargabase = require("../db_apis/insert_tucargabase.js");

async function post(req, res, next) {
  try {
    const context = req.body;
    console.log('funcion para insertar datos en tu_cargabase');
    console.log(context);

    const rows = await insert_tucargabase.find(context);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
