const http = require('http');
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const morgan = require('morgan');
const helmet = require('helmet');

//const tokenConfig = require('../config/confingToke.js');
const webServerConfig = require('../config/web-server.js');
// const database = require('./database.js');
const router = require('./router.js');
 
let httpServer;
 
function initialize() {
  return new Promise((resolve, reject) => {
    const app = express();
    app.use(helmet());
    app.disabled('x-powered-by');
    httpServer = http.createServer(app);
   
    app.use(morgan('dev'));

    app.use(bodyParser.urlencoded({ extended: true }));
   
    app.use(bodyParser.json());

    // app.use('/api_sicall',router);
    app.use("/api_citi_banco",router);

   
 
    httpServer.listen(webServerConfig.port)
      .on('listening', () => {
        console.log(`Web server listening on localhost:${webServerConfig.port}`);
 
        resolve();
      })
      .on('error', err => {
        reject(err);
      });
  });
}
 
module.exports.initialize = initialize;
function close() {
  return new Promise((resolve, reject) => {
    httpServer.close((err) => {
      if (err) {
        reject(err);
        return;
      }
 
      resolve();
    });
  });
}
 
module.exports.close = close;