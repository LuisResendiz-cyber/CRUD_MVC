const customerModel = require("../models/customerModel")
const  {sendWhatsAppMessage} = require("../services/whatsappService.js")


const dotenv = require('dotenv');
dotenv.config();


const CustomerController = {
  async getCustomers(req, res) {
    try {
      const users = await customerModel.getCustomers();
    
            for (const user of users) {
                const numeroCompleto = `52${user.numero}`;
        
                const mensaje = `Hola ${user.nombre}! 👋  
        Gracias por tu interés. Para más información visita: www.callback.com`;
        
                await sendWhatsAppMessage(numeroCompleto, mensaje);
              }
        
              res.json({
                status: "success",
                message: "Mensajes enviados a todos los usuarios."
              });



    } catch (error) {}
  },
  async verifyWebhook(req, res) {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];
  
    const verificacionToken = process.env.VERIFY_TOKEN; // el mismo que pones en Meta

    console.log(verificacionToken);
    console.log(mode);
    console.log(token);

  
    if (mode && token === verificacionToken) {
      console.log("WEBHOOK_VERIFIED");
      return res.status(200).send(challenge);
    }
  
    return res.sendStatus(403);
  },
  async receiveMessage(req, res) {
    console.log("WEBHOOK EVENT:", JSON.stringify(req.body, null, 2));
    res.sendStatus(200);
  }
};

module.exports = CustomerController;
