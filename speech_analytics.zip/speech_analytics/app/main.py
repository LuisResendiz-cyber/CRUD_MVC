from fastapi import FastAPI
from app.api.health import router as health_router
from app.api.calls import router as calls_router

app = FastAPI(
    title="SpeechLens API",
    version="1.0.0"
)

app.include_router(health_router, prefix="/health", tags=["Health"])
app.include_router(calls_router, prefix="/calls", tags=["Calls"])
