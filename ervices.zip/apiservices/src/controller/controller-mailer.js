const path = require('path');
const actMailer = require('../model/model-mailer')
const { actionsMysql } = require("../model/model-mysql");
const { oraExcProc,oraExcProcNoCursor,createConnObj,oraExcProc2 } = require("../model/model-oracle");


const sendMailSmtp = {
  test : async (req,res) => {

    const csvPath = path.join(__dirname,`../public/csv/asistencia.csv` );

    const mailOptions = {
      to: "dtrejo@impulse-telecom.com",
      // cc: "dsa@impulse-telecom.com",
      subject: 'Reporte de Asistencia',      
      html: `<h1> Hola mundo </h1>`,
      attachments: [
        {
          filename: 'Asistencia.csv',
          path: csvPath 
        }
      ]
    };


    let nObjMailer = await actMailer.createObjMailer(mailOptions)

    console.log(nObjMailer)
    if (nObjMailer == 200) {
      console.log('Reporte de asistencia enviado: ', nObjMailer)
      await actionsMysql.saveLogCron("REPORTE DE ASISTENCIA",1);

      res.send('Reporte de asistencia enviado')
    }else {
      await actionsMysql.saveLogCron("REPORTE DE ASISTENCIA",0);
      console.log('Error al enviar reporte de asistencia: ', nObjMailer)
      res.send('Error al enviar reporte de asistencia')
    }   

  } ,

  sendMailDigital: async (req, res) => {
    const { email, subject, content } = req.body;
    try {
      const mailOptions = {
        to: email,
        subject: `${subject}`,
        html: content,
      };
      let nObjMailer = await actMailer.createObjMailerDigital(mailOptions);
      if (nObjMailer == 200) {
        await actionsMysql.saveLogCron(subject, 1);
        res.json({ status: 200});
      } else {
        await actionsMysql.saveLogCron(subject, 0);
        res.send("Error al enviar correo");
      }
    } catch (error) {
      console.log(error);
      res.status(400).send(error);
    }
  },
}
 







module.exports = { sendMailSmtp };
