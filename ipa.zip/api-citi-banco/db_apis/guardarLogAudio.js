const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
    try {
        const baseQuery = "BEGIN "+ context.schema +".XSP_LOG_AUDIOS(:v_nomina,:v_customerid, :v_surveyid, :v_estatus, :v_IdAudio, :rc); END;";
        let query = baseQuery;
        const binds = {};
        let result2 = {};
        
        binds.v_nomina = context.Nomina;
        binds.v_customerid = context.Customerid;
        binds.v_surveyid = context.SurveyId;
        binds.v_estatus = context.Status;
        binds.v_IdAudio = context.IdAudio;
        binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
        
        const result = await database.simpleExecuteRC(query, binds);
        
        return result;
    } catch (error) {
        console.log(Error);
    }
}

module.exports.find = find;
