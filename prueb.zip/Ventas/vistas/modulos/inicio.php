<div class="content-wrapper">

  <section class="content-header">
    
    <h1>
      
      Tablero
      
      <small>Panel de Control</small>
    
    </h1>

    <ol class="breadcrumb">
      
      <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      
      <li class="active">Tablero</li>
    
    </ol>

  </section>

  <section class="content">

    <div class="row">
      

    </div> 

     <div class="row">
       
        <div class="col-lg-12">

        </div>

        <div class="col-lg-6">

        </div>

         <div class="col-lg-6">


        </div>

        <div class="col-lg-12">



        <!-- Contenedor del iframe -->
       <!-- <div id="iframeContainer" style="height:700px;width:1000px;overflow:hidden;"></div> -->

<?php

// URL encriptada (debe ser la misma que en el código JavaScript)
$encryptedURL ="aHR0cHM6Ly9hcHAucG93ZXJiaS5jb20vdmlldz9yPWV5SnJJam9pTkdSbE56WTJOV0l0WWpBM05DMDBZMkpoTFdKaE1qRXRZamt5WW1Nek1qUm1NV0UwSWl3aWRDSTZJamRsTVRJNVpqVmpMV1l4TmpJdE5EaGxZaTA1TlRRMUxURXdZVE5rT0RSa05EUXdOU0o5";
// Desencriptar la URL
$decodedURL = base64_decode($encryptedURL);

?>



         <div class="box box-success">
                  <div class="box-header">
                    <!-- <iframe id="miiframe" src="vistas/modulos/Liga.php" height="700" width="1380"></iframe> -->
                    <iframe id="miiframe" src="https://app.powerbi.com/view?r=eyJrIjoiNGRlNzY2NWItYjA3NC00Y2JhLWJhMjEtYjkyYmMzMjRmMWE0IiwidCI6IjdlMTI5ZjVjLWYxNjItNDhlYi05NTQ1LTEwYTNkODRkNDQwNSJ9" height="700" width="1380"></iframe> 
                  </div>
        </div> 
          
        </div>


     </div>

  </section>
 
</div>

