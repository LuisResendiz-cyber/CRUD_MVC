import fs from "fs";
import path from "path";
import axios from "axios";
import { fileURLToPath } from "url";

import { construirPrompt } from "../utils/promptBuilder.js";

export async function procesarPregunta1(req, res) {
  try {
    const { pregunta } = req.body;

    const prompt = construirPrompt(pregunta);

    const response = await axios.post(
      "http://127.0.0.1:11434/api/generate",
      {
        model: "phi3:latest",
        prompt,
        stream: true,
      },
      { headers: { "Content-Type": "application/json" } }
    );

    return res.json({
      respuesta: response.data.response.trim(),
    });
  } catch (error) {
    console.error("Error:", error.message);
    return res.status(500).json({ error: "Error procesando la solicitud" });
  }
}

export const chatStream = async (req, res) => {
  const { pregunta } = req.body;

  if (!pregunta) {
    return res.status(400).send("Falta el campo: pregunta");
  }

  // Construir texto final
  const promptFinal = construirPrompt(pregunta);

  // Streaming headers
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Transfer-Encoding", "chunked");

  try {
    const response = await axios({
      method: "post",
      url: "http://127.0.0.1:11434/api/generate",
      data: {
          model: "phi3:latest",
          prompt: promptFinal,
          stream: true,
          options: {  // ¡ESTA SECCIÓN ES LO MÁS IMPORTANTE!
              temperature: 0.1,      // Reduce la creatividad/aleatoriedad
              top_p: 0.95,
              stop: ["<|end|>"],     // Secuencia de parada CRÍTICA para Phi-3
              num_predict: 500       // Límite de tokens en la respuesta
          }
      },
      responseType: "stream"
  });

  // Configurar encabezados para streaming
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Transfer-Encoding', 'chunked');

  // Recibir tokens uno por uno
  response.data.on('data', (chunk) => {
      try {
          const dataStr = chunk.toString();
          const lines = dataStr.split('\n').filter(line => line.trim());
          
          for (const line of lines) {
              const json = JSON.parse(line);
              if (json.response) {
                  res.write(json.response);
              }
              if (json.done) {
                  res.end();
                  return;
              }
          }
      } catch (err) {
          console.error("Error procesando chunk:", err.message);
      }
  });
  } catch (error) {
    console.error("Error en streaming:", error);
    res.status(500).send("Error interno en el servidor");
  }
};

export const procesarPregunta = async (req, res) => {
  try {
    const { pregunta } = req.body;

    if (!pregunta) {
      return res.status(400).json({ error: "La pregunta es requerida" });
    }
    const ollamaResponse = await axios({
      method: "post",
      url: "http://127.0.0.1:11434/api/generate",
      data: {
        model: "phi3:mini",
        prompt: pregunta,
        stream: true,
      },
      responseType: "stream",
    });

    let fullResponse = "";

    ollamaResponse.data.on("data", (chunk) => {
      const text = chunk.toString().trim();
      try {
        const parsed = JSON.parse(text);

        if (parsed.response) {
          fullResponse += parsed.response;
        }
      } catch {}
    });

    ollamaResponse.data.on("end", () => {
      return res.json({
        respuesta: fullResponse,
      });
    });
  } catch (error) {
    console.error("Error en procesarPregunta:", error.message);
    return res.status(500).json({ error: "Error al generar respuesta" });
  }
};
