const Users = require('../models/Users.models');

const MenuService = {
    async getUserMenu(idUser) {
        if (!idUser) {
          throw new Error('idUser es requerido');
        }
    
        // 1️⃣ Datos planos desde el modelo
        const rows = await Users.getModules(idUser);
    
        if (!rows || rows.length === 0) {
          return [];
        }
    
        // 2️⃣ Agrupar por módulo
        const menuMap = {};
    
        for (const row of rows) {
          const moduleTitle = row.title;
          const moduleIcon = row.icon;

    
          if (!menuMap[moduleTitle]) {
            menuMap[moduleTitle] = {
              title: moduleTitle,
              icon: moduleIcon,
              submodules: []
            };
          }
    
          menuMap[moduleTitle].submodules.push({
            id: row.idsubmodule,
            title: row.submodulo_titulo,
            route: row.submodulo_ruta,
            icon: row.submodulo_icono,
            order: row.submodulo_orden
          });
        }
    
        // 3️⃣ Convertir map a array
        return Object.values(menuMap);
      }
}


module.exports = MenuService;
