const bases_contacto = require("../db_apis/bases_contacto.js");

async function post(req, res, next) {
  try {
    console.log('funcion para obtener bases.');
    const rows = await bases_contacto.get();

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
