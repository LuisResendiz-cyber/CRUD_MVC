
const customerModel = require("../models/webchat.models");



const webchatController = {
    async receiveMessage(req, res) {
        try {
            const { session_id, message } = req.body;


            const session = await customerModel.getOrCreateSession(
                session_id,
                "web"
              );

            
            if (!session_id || !message) {
                return res.status(400).json({ error: "Datos incompletos" });
            }                     
            
            console.log("ok", session.id, message);

             await customerModel.insertWebhookLog({
                 event_type: "message",
                 wamid: session_id,            
                 status: "received",
                 message_text: message,
                 id_envio: 0,
                });
                
              const reply = "Gracias por tu mensaje, en un momento te atendemos 😊";

              await customerModel.insertWebhookLog({
                event_type: "message",
                wamid: session_id,            
                status: "sent",
                message_text: reply,
                id_envio: 0,
               });

              res.json({reply})


        } catch (error) {
            console.log(error);
        }
    }
};


module.exports = webchatController;