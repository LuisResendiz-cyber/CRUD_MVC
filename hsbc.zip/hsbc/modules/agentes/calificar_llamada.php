<?php
# @uthor Mark
# Index File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Califica Llamada");


$id_registro = get_session_varname("id_registro");
$id_solicitud = get_session_varname("id_solicitud");
$maquina = get_session_varname("s_usr_maquina");
$usr_super = get_session_varname("s_usr_super");

$calificar = get_session_varname("calificar");
$cont =$_REQUEST['cont'];

//Califica el registro tanto de tbl_datos como td_registro cuando le dan nueva llamada sin procesar la solicitud.
if(isset($cont) && $cont > 0){
set_cal_reg_nvo($id_registro,$cont,$maquina,$usr_super,$db);
//En este procedimiento insertamos el seguimiento de Salida para Inbound
}


layout_menu($db, "ShowScript_GeneralIN()");

?>	
	<p class="textbold">Agentes &gt;Calificar Llamada</p>
	<p>&nbsp;</p>
	<form method="post" action="modules.php?mod=agentes&op=process_data&act=16" name="frm15">
	<table class="text" border="0">
		<tr>
			<td width="60%">
				<table border="0">
					<tr>					
						<td colspan="3">&nbsp;</td>
					</tr><tr>		
						<td colspan="2">Selecciona una de las calificaciones.</td>
					</tr><tr>					
						<td colspan="3">&nbsp;</td>
					</tr><tr>					
						<td colspan="3">&nbsp;</td>
					</tr><tr>
						<td colspan="3">
							<table border="0">
								<tr align="center">
									<td class="textleft"><b>Motivo de Llamada </b></td>									
									<td colspan="2">									
									<?	
										echo '<select name="motivo_llamada" style="width:190px">
										<option value="0">Elige opcion </option>';
										$catalogos = get_catalogo('MOTIVO_LLAMADA',  $db);
										while(!$catalogos->EOF) {										
											echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$detalle_calif->fields["ICALIFICACION"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';											
											$catalogos->MoveNext();
										}
										echo '</select>';
									?>
									</td>
								</tr>						
							</table>
							<br>
						</td>
					</tr><tr>
						<td>
							<? 	if(isset($cont) && $cont > 0){
									echo '<p><font color="red">Debes calificar la llamada antes de ir al Men&uacute;  de Agentes.</font></p>';
								}		
							?>
						</td>
					</tr><tr>
						<td colspan="3">&nbsp;</td>
					</tr><tr>
						<td colspan="3">														
							<input type="button" value="Calificar Llamada" onclick="CalificarLlamada()"/>&nbsp;&nbsp;&nbsp;&nbsp;
							&nbsp; &nbsp;							
							<input type="button" value="Regresar" onclick="RegistroIncompleto('4')" />	
						</td>
					</tr>
				</table>
			</td>
			<td rowspan="2">
				<div id="script" align="center" class="script"></div>
			</td>
		</tr>
	</table>
	</form>
<?
layout_footer();
?>