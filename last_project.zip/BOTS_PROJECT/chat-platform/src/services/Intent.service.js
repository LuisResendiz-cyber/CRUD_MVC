const { generate } = require("./LLM.service");

const classifyIntent = async (message) => {
  const response = await generate({
    systemPrompt: `
      Clasifica la intención del usuario en una sola palabra:
      greeting, question, complaint, opinion, farewell, farewell_soft.
      Responde SOLO la palabra.
    `,
    userMessage: message
  });

  return response.trim().toLowerCase();
};

module.exports = { classifyIntent };
