// src/scripts/enqueueInboundTest.js
const { jobsQueue } = require("../config/queue"); // ajusta ruta si la tienes en otro folder

(async () => {
  try {
    const job = await jobsQueue.add("inboundMessage", {
      from: "524411003234",
      wamid: `wamid.test.${Date.now()}`,
      text: "Hola, me puedes explicar la Tarjeta Oro?",
      timestamp: Date.now()
    }, {
      removeOnComplete: true,
      attempts: 2
    });

    console.log("Job enqueued:", job.id);
    process.exit(0);
  } catch (err) {
    console.error("Error encolar inbound test:", err);
    process.exit(1);
  }
})();
