<?php

require_once "../controladores/campanas.controlador.php";

require_once "../modelos/campanas.modelo.php";

class AjaxUsuarios{
	/*=============================================
	EDITAR ENLACES
	=============================================*/	
	public $idEnlace;

	public function ajaxEditarEnlace(){
		$item = "id";
		$valor = $this->idEnlace;
		$respuesta = ControladorCampanas::ctrMostrarCampanas($item, $valor);
		echo json_encode($respuesta);
	}
}

/*=============================================
EDITAR ENLACES
=============================================*/
if(isset($_POST["idCampana"])){
	$editar = new AjaxUsuarios();
	$editar -> idEnlace = $_POST["idCampana"];
	$editar -> ajaxEditarEnlace();
}