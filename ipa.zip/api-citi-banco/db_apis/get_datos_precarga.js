const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  // const baseQuery = "BEGIN CITI.SPS_GET_DATOS_PRECARGA(:rc, :keys); END;";
  const baseQuery = "BEGIN CITI.SPS_GET_DATOS_PRECARGA(:rc); END;";

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  // if(context.keys== ''){
  //   //console.log("Parametros incorrectos")
  //   result2.error_ = true;
  //   result2.mensaje = "Parametros Erroneos";
  //   return result2;

  // }else{
    // console.log(binds.keys);
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    // binds.keys  = context.keyrig;
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  // }
}

module.exports.find = find;

