const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN "+ context.schema +".xsp_editar_bases_especiales(:act, :valor1, :valor2, :result); END;"; //DBO

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   
  
  if(!context.act || !context.valor1 || !context.valor2){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  }else{
   // console.log("Parametros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.act = context.act;
    binds.valor1 = context.valor1;
    binds.valor2 = context.valor2;
    binds.result = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
    // binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecute(query, binds);
    // console.log(result);
    return result;
  }


}

module.exports.find = find;