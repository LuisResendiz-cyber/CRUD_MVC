const multer = require('multer')

const html = multer.diskStorage({
  destination:(req,file,cb) => {
    cb(null,'./src/public/html')
  },
  filename : (req,file,cb) => {
    cb(null,file.originalname)
  }

})

const uploadHtml = multer({storage: html})

const csvStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './src/public/csv');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const uploadCsv = multer({ storage: csvStorage });


const uploads = {
  html: uploadHtml,
  csv: uploadCsv
};

// module.exports = { uploadHtml, uploadCsv };
module.exports = uploads;