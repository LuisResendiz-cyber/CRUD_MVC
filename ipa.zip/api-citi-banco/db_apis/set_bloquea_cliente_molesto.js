const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {

const baseQuery = "BEGIN " + context.schema +".XSP_BLOQUEAREGISTRO_CM(:reg); END;";
	let query = baseQuery;
	const binds = {};

	let result2 = {};

        if(!context.reg){
         // console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.reg = {val:parseInt(context.reg) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER};


            const result = await database.simpleExecute(query, binds);

            // console.log(result); 

            return result;
        }            
}
  
module.exports.find = find; 


//----------------------------------------
//BLOQUEA EL REGISTRO CLIENTE MUY MOLESTO
/*function set_bloquea_cliente_molesto($id_registro, $db) {
    $stmt = $db->PrepareSP("BEGIN XSP_BLOQUEAREGISTRO_CM(:reg); END;");
    $db->InParameter($stmt, $id_registro, 'reg');
    $db->Execute($stmt);
}*/