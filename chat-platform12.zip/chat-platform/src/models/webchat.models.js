const db = require("../db/mysql");

const CustomersModel = {

  async insertWebhookLog({ event_type, wamid = null, from_number = 0, status  = null, message_text  = null, role= "user", id_envio = 0, raw_json = null}) {
    const sql = `
      INSERT INTO WHATSAPP_WEBHOOK_LOG 
      (event_type, wamid, from_number, status, message_text, role, conversation_id, raw_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.query(sql, [
      String(event_type).substring(0, 20),
      wamid || null,
      from_number || null,
      status || null,
      message_text || null,
      role || null,
      id_envio || null,
      JSON.stringify(raw_json)
    ]);
  },
  async getOrCreateSession(conversationId, channel = "web") {
    // 1️⃣ Buscar sesión existente
    const [rows] = await db.query(
      `
      SELECT *
      FROM CHAT_SESSIONS
      WHERE session_uuid = ?
      LIMIT 1
      `,
      [conversationId]
    );
  
    if (rows.length > 0) {
      // 2️⃣ Actualizar última actividad
      await db.query(
        `
        UPDATE CHAT_SESSIONS
        SET last_activity = NOW()
        WHERE session_uuid = ?
        `,
        [conversationId]
      );
  
      return rows[0];
    }
  
    // 3️⃣ Crear nueva sesión
    const [result] = await db.query(
      `
      INSERT INTO CHAT_SESSIONS
        (session_uuid, channel, status)
      VALUES (?, ?, 'bot')
      `,
      [conversationId, channel]
    );
  
    // 4️⃣ Devolver la sesión creada
    const [newSession] = await db.query(
      `
      SELECT *
      FROM CHAT_SESSIONS
      WHERE id = ?
      `,
      [result.insertId]
    );
  
    return newSession[0];
  },
  async getHistory(conversation_id){
    const [rows] = await db.query(
      `SELECT id_webhook, role, message_text
       FROM WHATSAPP_WEBHOOK_LOG
       WHERE conversation_id = ?
         AND channel = 'web'
       ORDER BY created_at ASC`,
      [conversation_id]
    );

    if (rows.length) return rows;
  }
  ,
  async getConversationById(conversation_id) {
    const [rows] = await db.query(
      `SELECT *
       FROM WHATSAPP_WEBHOOK_LOG
       WHERE conversation_id = ?`,
      [conversation_id]
    );
    return rows[0];
  },
  async switchSessionToHuman(sessionUuid) {
    const sql = `
      UPDATE CHAT_SESSIONS
      SET status = 'human',
          last_activity = NOW()
      WHERE session_uuid = ?
        AND status = 'bot'
    `;
  
    await db.execute(sql, [sessionUuid]);
  },
  async setSessionHuman({ session_uuid, agent_id }) {
    const sql = `
      UPDATE CHAT_SESSIONS
      SET status = 'human',
          assigned_agent_id = ?,
          last_activity = NOW()
      WHERE session_uuid = ?
    `;
    await db.query(sql, [agent_id, session_uuid]);
  },
  async getNewMessages(conversation_id, last_id) {
    const sql = `
      SELECT id_webhook, message_text, role, created_at
      FROM WHATSAPP_WEBHOOK_LOG
      WHERE conversation_id = ?
        AND id_webhook > ?
      ORDER BY id_webhook ASC
    `;
    const [rows] = await db.query(sql, [conversation_id, last_id]);
    return rows;
  }
  

};

module.exports = CustomersModel;
