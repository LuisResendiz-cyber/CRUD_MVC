const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  const baseQuery =
    "BEGIN CITI.XSP_BLOQUEAR_TELEFONO(:telefono, :tipo, :opcion, :rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  let result = {};

  if (context.telefonos == "" || context.tipo == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
  } else if (context.opcion == 1){
    binds.telefono = null;
    binds.tipo = null;
    binds.opcion = context.opcion;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
    return result;

  } else if (context.opcion == 2){
    binds.telefono = context.telefonos;
    binds.tipo = context.tipo;
    binds.opcion = context.opcion;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
    return result;
  }
}

module.exports.find = find;
