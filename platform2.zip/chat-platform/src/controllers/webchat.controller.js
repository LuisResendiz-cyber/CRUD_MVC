const customerModel = require("../models/webchat.models");
//const { resolveCustomerService } = require("../services/chat/customerBotResolver");
//const ChatResolver = require("../services/chat/chat.resolver");
const ChatResolver = require("./Knowledge.controller");
const { processIncomingMessage } = require("../services/MessageFlow.service");

const webchatController = {
  async receiveMessage(req, res) {
    try {
      const { session_id, message } = req.body;
  
      await processIncomingMessage({
        session_id,
        message,
        channel: "web"
      });
  
      return res.json({ ok: true });
  
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: "Error interno" });
    }
  },
  async historyConversation(req, res) {
    try {
      const { conversation_id } = req.params;

      const history = await customerModel.getHistory(conversation_id);

      res.json({ messages: history });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Error al obtener historial" });
    }
  },
  /* async getOrCreateSession(session_id, channel) {
    let session = await db.query(
      "SELECT * FROM chat_conversations WHERE conversation_id = ?",
      [session_id]
    );

    if (!session.length) {
      const conversation_id = "conv_" + crypto.randomUUID();

      await db.query(
        `INSERT INTO chat_conversations
         (conversation_id, channel, status)
         VALUES (?, ?, 'bot')`,
        [conversation_id, channel]
      );

      return { session_id, conversation_id, status: "bot" };
    }

    return session[0];
  }, */
  async sendHumanMessage(req, res) {
    try {
      const { session_uuid, agent_id, message } = req.body;

      if (!session_uuid || !agent_id || !message) {
        return res.status(400).json({ error: "Datos incompletos" });
      }


      console.log("ok");
      // 1️⃣ Cambiar sesión a HUMAN
      await customerModel.setSessionHuman({
        session_uuid,
        agent_id,
      });

      // 2️⃣ Guardar mensaje humano
      await customerModel.insertWebhookLog({
        event_type: "human_reply",
        status: "sent",
        message_text: message,
        channel: "web",
        role: "agent",
        id_envio: session_uuid,
      });

      res.json({ ok: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error interno" });
    }
  },
  async getMessages(req, res) {
    try {
      const { session_uuid, last_id = 0 } = req.query;
  
      if (!session_uuid) {
        return res.status(400).json({ error: "session_uuid requerido" });
      }
  
      const messages = await customerModel.getNewMessages(
        session_uuid,
        Number(last_id)
      );
  
      res.json({ messages });
  
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error interno" });
    }
  }
  
};

module.exports = webchatController;
