<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agente", "Solicitud");

// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";
// echo desencripta("NTg=");

set_session_varname("url_contacto", "cuestionario");

$RESP = array();

$id_solicitud = get_session_varname('id_solicitud');
$id_producto = get_session_varname('id_producto');
$id_registro = get_session_varname('id_registro');
$datos_cliente = get_session_varname("datos_persona");
// var_dump($datos_cliente[0][TIPO_ZONA]);
$nomina = get_session_varname('s_usr_nomina');
$extenagente = get_session_varname('extension');
$telefono = get_session_varname("s_telefono");
$u_telefono = get_session_varname("s_tel_contacto");
$isPredictivo2 = get_session_varname("s_usr_marcacion");
$s_usr_centro = get_session_varname("s_usr_centro");
$limit_credit = get_session_varname('LIMIT_CREDIT');
$tipo_zona_l4 = get_tipo_zona($id_solicitud, $db);
//var_dump($tipo_zona_l4->_array[0]['CENTRO']);
//var_dump($datos_cliente);

$origen = $tipo_zona_l4->_array[0]['ORIGEN'];
$producto_seleccionado = $_REQUEST['producto_'];
// echo $tipo_zona_l4->_array[0]['ORIGEN'];
// echo '------';
// echo $producto_seleccionado;

$inicio = '';
if (!isset($_REQUEST['inicio'])) {
    $inicio = 'y';
}

$datos_iniciales = get_valida_solicitud_capturada($id_solicitud, $db); //PARA LA FEC. NAC

$TipoZona = $datos_iniciales->fields["TIPOZONA"];
$DescBase = $datos_iniciales->fields["DESCBASE"];

$nombre_cliente = trim($datos_cliente[0]['NOMBRE']) . ' ' . trim($datos_cliente[0]['APATERNO']) . ' ' . trim($datos_cliente[0]['AMATERNO']);

?>
<!-- <div id="chec_list" title="Indicadores">
    <div align="left">MANDATORIOS a cubrir, previo a procesar solicitud.<BR>
        Recuerda brindar cada informaci&oacute;n en el momento justo, de otra forma no ser&aacute; venta correcta.</div>
    <table>
    <?php
    // style="display:none"
    // $preguntas = get_cuestionario_calidad($id_solicitud,$id_producto,$db);
    // while (!$preguntas->EOF) {
    //     echo "<tr>";
    //     foreach ($preguntas->fields as $name => $value) {
    //         echo "<td>".$value."</td>";
    //     }
    //     echo "</tr>";
    //     $preguntas->MoveNext();
    // }
    ?>
    </table>
</div> -->

        
<?php
//layout_menu($db, "displayResult(".$id_producto.");ShowScript_GeneralIN()");
// layout_menu($db, "ShowScript_GeneralIN();avisoPrivacidad('$nombre_cliente', '$inicio');");
layout_menu($db, "ShowScript_GeneralIN();");
// layout_menu($db, "displayResult()");
?>
<script>
    var survey_id = <?= $id_producto ?>;
    var customer_id = <?= $id_solicitud ?>;
    var v_conteo = 0;
    var v_conteo_chec = <?= count($preguntas->_array) ?>;
</script>
<script LANGUAGE="JavaScript" src="./includes/js/jsCode_cuestionario.js?r=<?php echo rand(); ?>"></script>
<script LANGUAGE="JavaScript" src="./includes/js/jsCode_cuestionario<?= $id_producto ?>.js?r=<?php echo rand(); ?>"></script>
 <!-- Cotizador JS -->
 <script LANGUAGE="JavaScript" src="./includes/js/include_cotizador.js?r=<?php echo rand(); ?>"></script>
<script LANGUAGE="JavaScript" src="./cotizador_hsbc/quotationAut.js?r=<?php echo rand(); ?>"></script>
<!-- Cotizador JS -->

<p class="textbold">Agentes &gt; Solicitud</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=<?= encripta(14) ?>" name="SurveyResponse" id="frm">
    <input type="hidden" name="inicio" id="inicio" value="<?php echo $inicio ?>">
    <input type="hidden" name="survey_id" id="survey_id" value="<?php echo $id_producto ?>">
    <input type="hidden" name="modo" id="modo" value="procesar">
    <input type="hidden" name="tipozona" id="tipozona" value="<?=trim($TipoZona);?>">
    <input type="hidden" name="descbase" id="descbase" value="<?=$DescBase;?>">
    <input type="hidden" name="s_usr_centro" id="s_usr_centro" value="<?=$s_usr_centro;?>">
    <input type="hidden" name="nombre_base" id="nombre_base" value="<?= (isset($datos_cliente[0]['BASE']) ? $datos_cliente[0]['BASE'] : ' ');?>">
    <input type="hidden" name="iniciativasL4" id="iniciativasL4" value="<?=$tipo_zona_l4->_array[0]['ORIGEN'];?>">


    <input type="hidden" name="tdd" id="tdd" value="<?=$datos_cliente[0]['ULT_TDD'];?>">
    <input type="hidden" name="tdc" id="tdc" value="<?=$datos_cliente[0]['ULT_TDC'];?>">


    <table border="0" width="100%">
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey">Calificaciones del registro</td>
        </tr>
        <tr>
            <td colspan="2">Seleccione la razon por la cual no se logr&oacute; la venta:
                <select name="si_contacto" id="si_contacto" onchange="revisa_calificacion_cuestionario(this, 2, <?php echo $id_solicitud ?>, '<?php echo $telefono ?>');">
                    <option value="0">Elige opci&oacute;n</option>
                    <!--option value="10000">VENTA</option-->
                    <?
                    $cal_SC = get_cal_SC(1, $db); //RAZONES NO VENTA
                    for ($indice_cal = 0; $indice_cal < count($cal_SC->_array); $indice_cal++) {
                        echo '<option value="' . $cal_SC->_array[$indice_cal]['U_ESTATUSLLAMADA'] . '" >' . $cal_SC->_array[$indice_cal]['ESTATUS'] . '</option>';
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <input type="hidden" name="cont" value="1" id="cont">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" class="custionario_boton" value="Regresar a no Contacto" onclick="this.disabled = true;
        regresar_no_contacto()"/>&nbsp;&nbsp;
                <input type="button" class="custionario_boton" value="Calificar" onclick="this.disabled = true;
        calificar_si_contacto(this,<?= $id_solicitud ?>, '<?= encripta(7) ?>',<?= $isPredictivo2 ?>,<?php echo $nomina.', '.$id_solicitud; ?> )"/>&nbsp;&nbsp;
            </td>
        </tr>
        <tr>
            <td colspan="2" class="label_td">Datos</td>
        </tr>
        <tr>
            <td colspan="2" class="label">
                <table class="label">
                    <tr class="label" align="middle">
                        <td class="label">Solicitud:</td>
                        <td class="label">
                            <input id="customerid" type="text" class="label" value="<?= $id_solicitud ?>" readonly>
                            <input type="hidden" name="surveyid" id="surveyid" value="<?=$id_producto?>">
                        </td>

                    </tr>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Oferta:</td>
                        <td class="label"><span style="color:red;"><?=$datos_cliente[0]['LIMIT_CREDIT']?></span></td>

                    </tr>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Nombre:</td>
                        <td class="label"><span style="color:black;"><?=$datos_cliente[0]['NOMBRE']?></span></td>

                    </tr>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Edad:</td>
                        <td class="label"><span style="color:black;"><?=$datos_iniciales->fields["EDAD"]?></span></td>

                    </tr>
                    <!--   <input type="hidden" name="tdd" id="tdd" value="<?= $ULT_TDD;?>"> $datos_cliente[0]['NOMBRE']
                      <input type="hidden" name="tdc" id="tdc" value="<?= $ULT_TDD;?>">CHUY -->


                     <tr class="label" align="middle">
                        <td class="label" style = "color:black;">TDC:</td>
                        <td class="label"><span style="color:black;"><?=$datos_cliente[0]['ULT_TDC']?></span></td>

                    </tr>
                     <tr class="label" align="middle">
                        <td class="label" style = "color:black;">TDD:</td>
                        <td class="label"><span style="color:black;"><?=$datos_cliente[0]['ULT_TDD']?></span></td>

                    </tr>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Tipo Cliente:&nbsp;</td>
                        <td class="label"><span style="color:black;"><?=$datos_cliente[0]['ESTRATEGIA_16']?></span></td>

                    </tr>
                    <?php if ($origen == 'TDC') { ?>
                    <tr class="label" align="middle">
                        <td class="label" style = "color:black;">Tipo Tarjeta:&nbsp;</td>
                        <td class="label"><span style="color:black;"><?php echo  $datos_cliente[0]['PRODUCTO']?></span></td>
                    </tr>
                    <?php }?>

                    <?php 
                    if (  $datos_cliente[0]['PRIMA'] != '1' ){   
                        ?>
                        <!-- <tr class="label" align="middle">
                        <td class="label" style = "color:black;">PRIMA:</td>
                        <td class="label"><span style="color:black;"> -->
                            <?php

                            // if($datos_cliente[0]['ESTRATEGIA_16'] == 'Advance' || $datos_cliente[0]['ESTRATEGIA_16'] == 'Premier'){
                            //     echo $datos_cliente[0]['PRIMA']." /DESC ".$datos_cliente[0]['PRIMA_DESC'];
                            // }else{
                            //     echo $datos_cliente[0]['PRIMA'] ;
                            // }
                         ?>
                        <!-- </span></td> -->

                    <!-- </tr> -->
                    <!-- <tr class="label" align="middle">
                        <td class="label" style = "color:black;">PRIMA A 30 DIAS:</td>
                        <td class="label"><span style="color:red;"> -->
                            <?php
                        //    if($datos_cliente[0]['ESTRATEGIA_16'] == 'Advance' || $datos_cliente[0]['ESTRATEGIA_16'] == 'Premier'){
                        //         echo $datos_cliente[0]['PRIMA2']." /DESC ".$datos_cliente[0]['PRIMA2_DESC'];
                        //     }else{
                        //         echo $datos_cliente[0]['PRIMA2'] ;
                        //     }
                         ?>
                        <!-- </span></td>

                    </tr> -->
                    <?php 
                    if (  $datos_cliente[0]['PRIMA'] != $datos_cliente[0]['PRIMA2']){ 
                        ?>

                    <tr class="label" align="middle">
                        <td class="label" colspan="4"><span style="color:blue; font-size:18px;"><b>CLIENTE CUMPLE A&Ntilde;OS DENTRO DE LOS PROXIMOS 30 DIAS</b></span></td>

                    </tr>

                    <?php 
                        }
                    ?>

                <?php 
                    }
                    ?>
                    <br>
                    <br>
                        <?php
                            $arrayTels = get_session_varname('arrayTels');
                            // var_dump($arrayTels); 
                            for($i=0; $i<count($arrayTels); $i++){
                                $contacto = '';
                                $ivr = '';
                                $background_fila = '';
                                if($arrayTels[$i][0] == $telefono){
                                    $contacto = '<span style="display:inline-block;padding:.3rem 1rem;background-color:green;border-radius:4px;color:#fff;margin-left:1rem;text-shadow:1px 1px #000;">CONTACTO</span>';
                                    //$background_fila = 'background-color:#aee5ae';
                                    $background_fila = 'background-color:#bdbdbd';
                                    /*$ivr = '<button style="background-color:red;color:#fff;padding:0 2rem;" class="btn" id="btnIVR_'.$contador.'" onclick="enlazarIVR(event, ' . $id_solicitud .', '. $id_producto .', '. $u_telefono . ', '. $telefono .', ' . $nomina.');">
                                        <b>IVR</b>
                                    </button>';*/
                                    $ivr = '<input type="button" style="background-color:red;color:#fff;padding:0 2rem;" class="btn" id="btnIVR_'.$contador.'" onclick="enlazarIVR(event, ' . $id_solicitud .', '. $id_producto .', '. $u_telefono . ', '. $telefono .', ' . $nomina.');" value="IVR">';
                                } ?>


                                <tr class="label" align="middle" style="vertical-align: middle;<?=$background_fila?>">
                                <!-- if($arrayTels[$i][0] != $telefono){ -->
                                    <?php $contador++; ?>
                                    <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                        <input type="button" class="menulink" id="btnMarcar<?=$contador?>" value="Marcar tel. <?=$contador?>" onclick="this.disabled=true;AbreVentana(this, <?=$contador?>, '<?=$nomina?>','<?=$arrayTels[$i][0]?>','<?=$id_solicitud?>',<?=$extenagente?>,'<?=get_session_varname("s_usr_cc")?>','<?= $arrayTels[$i][1]?>', <?=$datos_cliente[0]['U_ZONA']?>)">
                                        <input type="hidden" id="tel_0<?=$contador?>">
                                    </td>
                                    <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                        <input type="text" id="ev_tel" class="label" value="******<?= substr($arrayTels[$i][0], 6) ?>" readonly>
                                    </td>
                                    <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                        <?php     
                                        //    if($arrayTels[$i][2] == 3 || $arrayTels[$i][2] == '3'){
                                                echo '<input type="button" onclick="sendSMS(event, '.$contador.', '.$arrayTels[$i][1].', '.$arrayTels[$i][0].', '.$nomina.');" class="btn" style="background-color:red; color:#fff;" id="btnSendSMS_'.$contador.'" value="Enviar SMS">';
                                        //    }                                
                                        ?>
                                    </td>
                                    <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                        <?=$contacto?>
                                    </td>
                                    <td style="vertical-align:middle;background-color:#fff;padding-left: 2rem;" id="tdResponseSMS_<?=$contador?>"></td>
                                    <td style="vertical-align:middle;background-color:#fff;padding-left: 2rem;" id="tdSMS_<?=$contador?>"></td>
                                    <!-- <td style="vertical-align:middle;background-color:#fff;padding-left:2rem;" id="tdIVR_<?=$contador?>"><?=$ivr?></td>                                     -->
                                    <?php if($isPredictivo2 != 3){
                                        echo '<td style="vertical-align:middle;background-color:#fff;padding-left:2rem;" id="tdIVR_'.$contador.'">'.$ivr.'</td> ';
                                    } ?>
                                </tr>
                                <?php //}
                            }
                        ?>
                </table>
            </td>
        </tr>
        <tr>
            <td colspan="4">&nbsp;</td>
        </tr>

        <?php
        if($producto_seleccionado == 2) { 
            // if($tipo_zona_l4->_array[0]['ORIGEN'] == 'HC') { 
            ?>
            <tr>
                <td>   
                    <table style="background-color: gainsboro; padding: .5rem .5rem; vertical-align: middle;">
                        <tr>
                            <td style="vertical-align:middle;padding:.5rem .5rem;" id="">
                                <input type="button" style="background-color:red;color:#fff;" class="menulink" id="cotizador_btn" onclick="cotizarDatos()" value="COTIZAR">
                            </td>
                        </tr>
                        <tr class="label" align="middle" style="vertical-align:middle;padding:.5rem .5rem;">
                            <td class="label" style = "color:black; vertical-align:middle;padding:.5rem .5rem; text-align: end;">Suma Asegurada:</td>
                            <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                <input id="suma_asegurada_1" type="text" class="label" value="" style = "color:black;" readonly>
                            </td>
                            <td class="label" style = "color:black; vertical-align:middle;padding:.5rem .5rem;">Precio:</td>
                            <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                <input id="valor_precio_1" type="text" class="label" value="" style = "color:black;" readonly>
                            </td>
                        </tr>
                        <tr class="label" align="middle">
                            <td class="label" style = "color:black; vertical-align:middle;padding:.5rem .5rem; text-align: end;">Suma Asegurada:</td>
                            <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                <input id="suma_asegurada_2" type="text" class="label" value="" style = "color:black;" readonly>
                            </td>
                            <td class="label" style = "color:black; vertical-align:middle;padding:.5rem .5rem;">Precio:</td>
                            <td class="label" style="vertical-align:middle;padding:.5rem .5rem;">
                                <input id="valor_precio_2" type="text" class="label" value="" style = "color:black;" readonly>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        <?php
            }
        ?>

        <tr>
            <td colspan="4">&nbsp;</td>
        </tr>
        <?php
            if ($tipo_zona_l4->_array[0]['ORIGEN'] == 'L4') { ?>
                <tr style="display:block;" class="bloquel4">
                <td style="color: red;"><b>Debes de responder las siguientes preguntas para las solicitudes L4</b></td>
                </tr>
                <tr class="bloquel4">
                    <td class="td_bloque_l4">
                        Fue Venta
                        <select name="fueVenta" id="fueVenta" style="margin-left:4.5rem;">
                            <option value=""></option>
                            <option value="1">SI</option>
                            <option value="0">NO</option>
                        </select>
                    </td>
                </tr>
                <tr class="bloquel4">
                    <td class="td_bloque_l4">
                        Tiene la tarjeta fisica
                        <select name="tarjetaFisica" id="tarjetaFisica" style="margin-left:1.0rem;">
                            <option value=""></option>
                            <option value="1">SI</option>
                            <option value="0">NO</option>
                            <option value="2">NO RECIBIO</option>
                        </select>
                    </td>
                </tr>
                <tr class="bloquel4">
                    <td class="td_bloque_l4">
                        Solicito
                        <select name="solicitoL4" id="solicitoL4" style="margin-left:5.5rem;">
                            <option value=""></option>
                            <option value="1">SUCURSAL</option>
                            <option value="0">DOMICILIO</option>
                        </select>
                    </td>
                </tr>
        <?php
            }
        ?>
        <br>
        <tr style="display:inline-flex;">
            <td style="color: red;"><b>El cliente debe autenticarse con la siguiente pregunta antes de poder continuar.</b></td>
            <td id="conteoErrores" style="display:none;padding:.1rem 1rem;background-color:#2E2E2E;color:#fff;border-radius:4px;"></td>
        </tr>
        <?php $p_aleatoria = rand(1,2);?>
        <input type="hidden" id="input_rand" value="<?=$p_aleatoria?>">
        <tr>
            <td id="td_1" style="display:none;">
                RFC? <input type="text" id="input_R" name="validacionRFC" class="validaRespuesta" onchange="validaRespuesta('R');" style="margin-left:5.5rem;">

                <span id="resp_R" style="display:none;"><?=substr($datos_cliente[0]["RFC"],0,10)?></span>
                <span class="icono_R" id="spanResp_1_R" style="display:none;color:green;"><i class="fa-solid fa-check"></i></span>
                <span class="icono_R" id="spanResp_0_R" style="display:none;color:red;"><i class="fa-solid fa-xmark"></i></span>
            </td>
        </tr>
        <tr>
            <td id="td_2" style="display:none;">
                Fecha Nacimiento? <input type="text" id="input_F" name="validacionFecNac" class="validaRespuesta" onchange="validaRespuesta('F');" style="margin-left:1rem;">

                 <span id="resp_F" style="display:none;"><?=$datos_cliente[0]["FECHA_NAC"]?></span>
                <span class="icono_F" id="spanResp_1_F" style="display:none;color:green;"><i class="fa-solid fa-check"></i></span>
                <span class="icono_F" id="spanResp_0_F" style="display:none;color:red;"><i class="fa-solid fa-xmark"></i></span>
            </td>
            <td style="vertical-align:middle;background-color:#fff;padding-left: 2rem;display:none;" id="tdAutenticacion">
                <input type="button" class="btn" value="CALIFICAR NO AUTENTICA" style="background-color:red;color:#fff;padding:0 2rem;" onclick="calificar_si_contacto(this,<?=$id_solicitud?>, '<?=encripta(7)?>',<?=$isPredictivo2?>,<?php echo $nomina.', '.$id_solicitud . ', 201'; ?>)">
            </td>
          <!--   <td>VHUY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!</td> -->
        </tr>

        <tr>
            <td colspan="2">
                <table border="0" width="100%">
                    <tr>
                        <td colspan="2">
                            <div id="cuestionario" style="display:none;">
                            <?php

                            $rs = es_grabada($id_solicitud, $id_producto, $db);
                            // die();
                            $venta_obtenida_previa = get_datos_venta_previa($id_solicitud, $id_producto, $db);
                            // var_dump($venta_obtenida_previa);
                            // die();
                            if (!$rs->EOF){
                            //   echo 'a';
                                echo '<input type="hidden" id="tipo_formulario" value="1">'; // mañota
//                                ECHO "ANTES";
                                $datos_grabados = get_datos_grabados($id_solicitud, $id_producto, $db); //PRODUCTOS
                                if (!$datos_grabados->EOF) {
                                    while (!$datos_grabados->EOF) {
                                        $RESP[$datos_grabados->fields['QUESTIONID']][$datos_grabados->fields['CHOICEID']] = $datos_grabados->fields['TEXTANSWER'];
                                        $datos_grabados->MoveNext();
                                    }
                                }
                                $datos_grabados->MoveFirst();
                                $xslDoc = new DOMDocument();
                                $xslDoc->load("modules/agentes/catalogo.xsl");

                                $xmlDoc = new DOMDocument();
                                $xmlDoc->load("modules/agentes/cuestionario_" . $id_producto . ".xml");

                                $proc = new XSLTProcessor();
                                $proc->importStylesheet($xslDoc);

                                if (!$datos_grabados->EOF) {
                                    while (!$datos_grabados->EOF) {
                                        $proc->setParameter(NULL, 'RESP_' . $datos_grabados->fields['QUESTIONID'] . '_' . $datos_grabados->fields['CHOICEID'], $RESP[$datos_grabados->fields['QUESTIONID']][$datos_grabados->fields['CHOICEID']]);

                                        // echo 'RESP_' . $datos_grabados->fields['QUESTIONID'] . '_' . $datos_grabados->fields['CHOICEID'] . '|' .
                                        //     $RESP[$datos_grabados->fields['QUESTIONID']][$datos_grabados->fields['CHOICEID']] . '<br>';

                                        $question = $datos_grabados->fields['QUESTIONID'];
                                        $choice = $datos_grabados->fields['CHOICEID'];
                                        if(
                                            ($question== 2 && $choice==5) || // datos del titular
                                            ($question== 2 && $choice==6) ||
                                            ($question== 2 && $choice==7) ||
                                            ($question== 2 && $choice==9) ||
                                            ($question== 6 && $choice==16) || // datos del beneficiario 1
                                            ($question== 6 && $choice==17) ||
                                            ($question== 6 && $choice==18) ||
                                            ($question== 6 && $choice==19) ||
                                            ($question== 61 && $choice==16) || // datos del beneficiario 2
                                            ($question== 61 && $choice==17) ||
                                            ($question== 61 && $choice==18) ||
                                            ($question== 61 && $choice==19) ||
                                            ($question== 62 && $choice==16) || // datos del beneficiario 3
                                            ($question== 62 && $choice==17) ||
                                            ($question== 62 && $choice==18) ||
                                            ($question== 62 && $choice==19)
                                        ){
                                            echo '<input type="hidden" id="MANA_'.$question.'_'.$choice.'" value="'.
                                                $RESP[$datos_grabados->fields['QUESTIONID']][$datos_grabados->fields['CHOICEID']]
                                            .'">';
                                        }




                                        $datos_grabados->MoveNext();
                                    }
                                }
                                $proc->setParameter(NULL, 'INICIO', $inicio);

                                echo $proc->transformToXML($xmlDoc);
                             }
                            //  elseif(!isset($venta_obtenida_previa->fields['SIN_VENTA'])) {
                            // //    echo 'b';
                            // //      var_dump($venta_obtenida_previa);
                            // //      die();
                            //      while (!$venta_obtenida_previa->EOF) {
                            //          $RESP[$venta_obtenida_previa->fields['QUESTIONID']][$venta_obtenida_previa->fields['CHOICEID']] = $venta_obtenida_previa->fields['TEXTANSWER'];
                            //          $venta_obtenida_previa->MoveNext();
                            //      }
                            //      // print_r($RESP);
                            //      // die();
                            //      $venta_obtenida_previa->MoveFirst();
                            //      $xslDoc = new DOMDocument();
                            //      $xslDoc->load("modules/agentes/catalogo.xsl");

                            //      $xmlDoc = new DOMDocument();
                            //      $xmlDoc->load("modules/agentes/cuestionario_" . $id_producto . ".xml");

                            //      $proc = new XSLTProcessor();
                            //      $proc->importStylesheet($xslDoc);

                            //      if (!$venta_obtenida_previa->EOF) {
                            //          while (!$venta_obtenida_previa->EOF) {
                            //              $proc->setParameter(NULL, 'RESP_' . $venta_obtenida_previa->fields['QUESTIONID'] . '_' . $venta_obtenida_previa->fields['CHOICEID'], $RESP[$venta_obtenida_previa->fields['QUESTIONID']][$venta_obtenida_previa->fields['CHOICEID']]);

                            //              //echo 'RESP_' . $datos_grabados->fields['QUESTIONID'] . '_' . $datos_grabados->fields['CHOICEID'];
                            //              //     $RESP[$datos_grabados->fields['QUESTIONID']][$datos_grabados->fields['CHOICEID']] . '<br>';

                            //              $question = $venta_obtenida_previa->fields['QUESTIONID'];
                            //              $choice = $venta_obtenida_previa->fields['CHOICEID'];
                            //              if(
                            //                  ($question== 2 && $choice==5) || // datos del titular
                            //                  ($question== 2 && $choice==6) ||
                            //                  ($question== 2 && $choice==7) ||
                            //                  ($question== 2 && $choice==9) ||
                            //                  ($question== 6 && $choice==16) || // datos del beneficiario 1
                            //                  ($question== 6 && $choice==17) ||
                            //                  ($question== 6 && $choice==18) ||
                            //                  ($question== 6 && $choice==19) ||
                            //                  ($question== 61 && $choice==16) || // datos del beneficiario 2
                            //                  ($question== 61 && $choice==17) ||
                            //                  ($question== 61 && $choice==18) ||
                            //                  ($question== 61 && $choice==19) ||
                            //                  ($question== 62 && $choice==16) || // datos del beneficiario 3
                            //                  ($question== 62 && $choice==17) ||
                            //                  ($question== 62 && $choice==18) ||
                            //                  ($question== 62 && $choice==19)
                            //              ){
                            //                  echo '<input type="hidden" id="MANA_'.$question.'_'.$choice.'" value="'.
                            //                      $RESP[$venta_obtenida_previa->fields['QUESTIONID']][$venta_obtenida_previa->fields['CHOICEID']]
                            //                  .'">';
                            //              }

                            //              $venta_obtenida_previa->MoveNext();
                            //          }
                            //      }
                            //      $proc->setParameter(NULL, 'INICIO', $inicio);

                            //      echo $proc->transformToXML($xmlDoc);

                            //  }
                             else {
                            //    echo 'c';
                                echo '<input type="hidden" id="tipo_formulario" value="0">'; // mañota
//                                ECHO "DESPUES";
                                $datos_complementarios = get_datos_complementarios($id_solicitud, $db); //PRODUCTOS
                                $NOMBRE_1 = $datos_cliente[0]['NOMBRE'];
                                $NOMBRE_2 = "";
                                $PATERNO = $datos_cliente[0]['APATERNO'];
                                $MATERNO = $datos_cliente[0]['AMATERNO'];
                                $LADA = $datos_cliente[0]['CLAVELADA'];
                                $TELEFONO = $datos_cliente[0]['TELEFONO'];
                                $RFC = $datos_cliente[0]['RFC'];
                                $FECHA_NAC = $datos_cliente[0]['FECHA_NAC'];
                                $DIRECCION = $datos_cliente[0]['DIRECCION'];
                                $ULT_TDD = $datos_cliente[0]['ULT_TDD'];
                                $ULT_TDC = $datos_cliente[0]['ULT_TDC'];


                                #ohernandez @ 20150303 -> REQ. 1223; quitar que aparezca dirección
                                //$DIRECCION = $datos_complementarios->fields['DIRECCION'];
                                $CP = $datos_complementarios->fields['CP'];
                                $COLONIA = $datos_complementarios->fields['COLONIA'];


                                $xslDoc = new DOMDocument();
                                $xslDoc->load("modules/agentes/catalogo_bk.xsl");

                                $xmlDoc = new DOMDocument();
                                $xmlDoc->load("modules/agentes/cuestionario_" . $id_producto . ".xml");

                                $proc = new XSLTProcessor();
                                $proc->importStylesheet($xslDoc);
                                $proc->setParameter(NULL, 'NOMBRE_1', $NOMBRE_1);
                                $proc->setParameter(NULL, 'NOMBRE_2', $NOMBRE_2);
                                $proc->setParameter(NULL, 'PATERNO', $PATERNO);
                                $proc->setParameter(NULL, 'MATERNO', $MATERNO);
                                $proc->setParameter(NULL, 'LADA', $LADA);
                                $proc->setParameter(NULL, 'TELEFONO', $TELEFONO);
                                $proc->setParameter(NULL, 'RFC', $RFC);
                                $proc->setParameter(NULL, 'FECHA_NAC', $FECHA_NAC);
                                $proc->setParameter(NULL, 'DIRECCION', $DIRECCION);
                                $proc->setParameter(NULL, 'ULT_TDD', $ULT_TDD);
                                $proc->setParameter(NULL, 'ULT_TDC', $ULT_TDC);

                                #ohernandez @ 20150303 -> REQ. 1223; quitar que aparezca dirección; se quitó arriba
                                //$proc->setParameter(NULL, 'DIRECCION', $DIRECCION);
                                $proc->setParameter(NULL, 'CP', $CP);
                                $proc->setParameter(NULL, 'COLONIA', $COLONIA);

                                $proc->setParameter(NULL, 'INICIO', $inicio);

                                echo $proc->transformToXML($xmlDoc);
                            }
                            ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                </table>
            </td>
            <td colspan>
                <div id="script" align="center" class="script"></div>&nbsp;
            </td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
    </table>
</form>
<div valign="bottom" id="dial-layer" style="display:none">
    <script>
        function conteo(boton){
            if(boton.checked == true){
                v_conteo = v_conteo +1;
            }else{
                v_conteo = v_conteo -1;
            }
        }


//alert('zzzz');

  //  console.log( "ready!" );

//   var input = document.getElementsByTagName('input');

// for(indice in input){

//         if(typeof input[indice] == 'object'){

//                 input[indice].addEventListener('blur',function(){//agregammos la funcion sin onclick html

//         //cambiocaracter("'"+input[indice].value+"'");
//         //cambiocaracter("'"+input[indice].value+"'");
//         //console.log(input[indice].value);

//             var texto = $(this).val();

//                     //console.log(texto);
//                     //texto.normalize('NFD').replace(/[\u0300-\u036f]/g,"");
//             // console.log(texto.replace('ñ', 'n')+"-<--<-<-");
//             $(this).val(texto.replaceAll('ñ', 'n'));

//         });
//         }


// }




    </script>
</div>

<div class="loader" style="display:none;">
    <img src="includes/imgs/loader.gif">
    <div>Espera mientras se recupera la llamada del IVR</div>
</div>

<?
layout_footer();
?>
<script>





</script>
