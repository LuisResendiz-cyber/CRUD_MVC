const express = require('express');
const router = express.Router();
const CustomerController = require("../controllers/customerController");

router.get('/', (req, res) => {
    res.json({1: "ok"});
});
router.get('/getCustomers',CustomerController.getCustomers);
router.get("/webhook", CustomerController.verifyWebhook);
router.post('/webhook', CustomerController.receiveMessage);

module.exports = router;
