
function traeEdo(estado) {
    estado.style.visibility = "hidden";
    startclock();
    document.SurveyResponse.submit();
}
function traeDeleg(delegacion) {
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId29') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId29.value') == '') {
            alert("Selecciona primero el 'Estado' de la Sucursal a recoger TDC");
            return false;
        } else {
            delegacion.style.visibility = "hidden";
            startclock();
            document.SurveyResponse.submit();
        }
    }

}

function LTrim(s) {
    // Devuelve una cadena sin los espacios del principio
    var i = 0;
    var j = 0;
    // Busca el primer caracter <> de un espacio
    for (i = 0; i <= s.length - 1; i++)
        if (s.substring(i, i + 1) != ' ') {
            j = i;
            break;
        }
    return s.substring(j, s.length);
}
function RTrim(s) {
    // Quita los espacios en blanco del final de la cadena
    var j = 0;
    // Busca el ltimo caracter <> de un espacio
    for (var i = s.length - 1; i > - 1; i--)
        if (s.substring(i, i + 1) != ' ') {
            j = i;
            break;
        }
    return s.substring(0, j + 1);
}
function Trim(s) {
    // Quita los espacios del principio y del final
    return LTrim(RTrim(s));
}


function isDate2(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAAA-MM-DD") {
        datePat = /^(\d{4})(-)(\d{1,2})(-)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[5];
        year = matchArray[1];
    }

    if (formato == "MM/AA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[1];
        //day = matchArray[5];
        year = matchArray[4];
    }


    if (formato == "DD/MM/AAAA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[1];
        year = matchArray[5];
    }

    //alert(month.length);
    if (year.length < 4) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year >= 2079) { // chequeo del A? para smalldate
        return false;
    }
    if (month < 1 || month > 12 || month.length < 2) { // checa rango mes
        return false;
    }
    if (day < 1 || day > 31 || day.length < 2) {
        return false;
    }
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    }
    if (month == 2) { // check para febrero 29
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}

function isDate3(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "MM/AA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[1];
        day = '01';
        year = matchArray[3];
    }

    //alert(month.length);
    if (year.length < 2) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year < 5) { // chequeo del A? para smalldate
        return false;
    }
    if (year >= 79) { // chequeo del A? para smalldate
        return false;
    }
    if (month < 1 || month > 12 || month.length < 2) { // checa rango mes
        return false;
    }

    return true;
}

function isDate4(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAMM") {
        datePat = /^(\d{2})(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        year = matchArray[1];
        month = matchArray[2];
        day = '01';
    }

    if (year.length < 2) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year > 99) { // chequeo del A? para smalldate
        return false;
    }
    if (month > 11 || month.length < 2) { // checa rango mes
        return false;
    }

    return true;
}


function isDate5(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAAA") {
        datePat = /^(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = '01';
        day = '01';
        year = matchArray[1];
    }

    //alert(month.length);
    if (year.length < 4) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year >= 2079) { // chequeo del A? para smalldate
        return false;
    }
    return true;
}


function fechas() {
    var a = 0;
    var ArreFecha = new Array();
    var ArrePegunta = new Array();
    var ArreTipo = new Array();

    var banderaFechas = true;

    if (survey_id == 100) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') == '') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
                                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value');
                                    ArrePegunta[a] = "Fecha de Cita";
                                    ArreTipo[a] = "";
                                    a++;
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6') != null) {
            ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId6.value');
            ArrePegunta[a] = "Fecha de Nacimiento de Titular";
            ArreTipo[a] = "T";
            a++;
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') == 'S') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Alterno";
                    ArreTipo[a] = "T";
                    a++;
                }
            }
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '1') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 1";
                    ArreTipo[a] = "";
                    a++;
                }
            }
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '2') {

                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 1";
                    ArreTipo[a] = "";
                    a++;
                }

                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId11') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId11.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 2";
                    ArreTipo[a] = "";
                    a++;
                }
            }
        }
    }


    for (a = 0; a < ArreFecha.length; a++) {
        if (Trim(ArreFecha[a]).length > 0) {
            if (!isDate2(Trim(ArreFecha[a]), "DD/MM/AAAA")) {
                alert("ERROR en la Pregunta \n\n--   " + ArrePegunta[a] + "   --\n\n FORMATO: DD/MM/AAAA ")
                banderaFechas = false;
            } else {
                if (ArreTipo[a] == 'T') {
                    if (!validarAdulto(ArreFecha[a], ArrePegunta[a], ArreTipo[a])) {
                        banderaFechas = false;
                    }
                }
            }
        } else {
            swal("Cuidado",`El campo  ${ArrePegunta[a]} no puede ser vacio`, "info")
            banderaFechas = false;
        }
    }
    return banderaFechas;
}


function GoHome() {
    history.back()
}

function GoBack() {
    history.back();
}

function cerrarVentana() {
//window.close();
}

function SubmitSurvey() {
    document.prueba.submit();
}
 

function validarQuestion() {
    bandera_telac = true;
    campo = " Datos del Titular";

    //-- Nombre
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value') == '') {
            swal("Cuidado","Favor de escribir el Nombre de los " + campo, "info");
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId2'), "Nombre de los " + campo, 1, 25)) {
                return false;
            }
            if (!/^([a-zA-Z ������������])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value'))) {
                swal("Cuidado",`El nombre de los ${campo} debe ser solo alfabetico`, "info");
                return false;
            }
        }
    }

    //-- Paterno
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == '') {
            swal("Cuidado","Favor de escribir el Apellido Paterno de los " + campo, "info");

            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId4'), "Apellido Paterno de los " + campo, 1, 50)) {
                return false;
            }
            if (!/^([a-zA-Z ������������])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value'))) {
            swal("Cuidado",`El apellido paterno de los ${campo} "debe ser solo alfabetico`, "info");
                return false;
            }
        }
    }
    
    //-- Fecha de nacimiento
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6.value') == '') {
            swal("Cuidado","Favor de escribir la fecha de nacimiento de los " + campo, "info");
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId6'), "fecha de nacimiento de los " + campo, 1, 10))
                return false;
        }
    }
    
    //-- RFC
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') == '') {
            swal("Cuidado","Favor de escribir el RFC de los" + campo, "info");
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId7'), "RFC de los" + campo, 1, 13))
                return false;
        }
    }
    
     //-- Nacionalidad
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value') == '') {
            swal("Cuidado"," Favor de seleccionar la Nacionalidad de los " + campo, "info");
            return  false;
        }
    }
    
    //-- Sexo
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') == '') {
            swal("Cuidado","Favor de seleccionar el Sexo de los " + campo, "info");
            return  false;
        }
    }
    
    //-- Estado Civil
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId18') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId18.value') == '') {
            swal("Cuidado","Favor de seleccionar el Edo Civil de los" + campo, "info");
            return  false;
        }
    }
    
    //-- Dependientes economicos:
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') == '') {
            swal("Cuidado","Favor de seleccionar los Dependientes economicos de los" + campo, "info");
            return  false;
        }
    }
    
     //-- �Estado donde nacio?
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') == '') {
            swal("Cuidado","Favor de seleccionar el Estado donde Nacio en los" + campo, "info");
            return  false;
        }
    }
   

     //-- Ocupacion del titular
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId26') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId26.value') == '') {
            swal("Cuidado","Favor de seleccionar la Ocupacion de los" + campo, "info");
            return  false;
        }
    }
		//-- Ingresos Fijos de la Empresa
	if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28') != null){
		if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value') ==''){		
            swal("Cuidado","Favor de escribir los Ingresos Fijos comprobables" + campo, "info");
			return  false;
		}else {
			if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value'))){
            swal("Cuidado","El campo Ingresos debe tener solo d�gitos de los " + campo, "info");
				return  false;
			}else {
				if(parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value')) < 15000){
                    swal("Cuidado","Los ingresos deben ser por lo menos de 15000" + campo, "info");
					return  false;
				}				
			}				
		}
	}    
    return bandera_telac;
}


function validarQuestion2() {
    bandera_telac = true;
    campo = "Datos de Domicilio";

    //-- Calle
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId3.value') == '') {
            swal("Cuidado","Favor de escribir la Calle de la " + campo, "info");
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId3'), "Direcci�n de la " + campo, 1, 100))
                return false;
        }
    }

    //-- Numero Exterior
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId4.value') == '') {
            swal("Cuidado","Favor de escribir el N�mero Exterior de los " + campo, "info");
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId4.value'))) {
                swal("Cuidado","El N�mero Exterior debe tener solo d�gitos de los " + campo, "info");
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId4'), "N�mero Exterior de la " + campo, 1, 10))
                    return false;
            }
        }
    }

    //-- CP
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8.value') == '') {
            swal("Cuidado","Favor de escribir el CP de los " + campo, "info");
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId8.value'))) {
                swal("Cuidado","El CP debe tener solo d�gitos de los " + campo, "info");
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId8'), "CP de " + campo, 5, 5))
                    return false;
            }
        }
    }
    
    //-- Otra Colonia
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId9') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId9.value') == '') {
            swal("Cuidado","Favor de Escribir la Otra Colonia de " + campo, "info");
            return  false;
        }
    }

    //-- Municipio
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId12') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId12.value') == '') {
            swal("Cuidado","Favor de seleccionar el Municipio de " + campo, "info");
            return  false;
        }
    }

    //-- Estado
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId13') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId13.value') == '') {
            swal("Cuidado","Favor de seleccionar el Estado de " + campo, "info");
            return  false;
        }
    }

    //-- Lada Casa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value'))) {
                swal("Cuidado","La Lada debe tener solo d�gitos de " + campo, "info");
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value.length') < 2) {
                    swal("Cuidado","La Lada debe ser 2 o 3 d�gitos de " + campo, "info");
                    return  false;
                }
            }
        } else {
            swal("Cuidado","Favor de escribir la Lada de " + campo, "info");
            return  false;
        }
    }

    //-- Telefono
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value'))) {
                swal("Cuidado","El Tel�fono Casa debe tener solo d�gitos de " + campo, "info");
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value.length') != 10) {
                    swal("Cuidado","Entre el Tel�fono y la Lada de la Casa se deben de conjuntar 10 d�gitos de " + campo, "info");
                    return  false;
                }
            }
        } else {
            swal("Cuidado","Favor de escribir el Tel�fono Casa de " + campo, "info");
            return  false;
        }
    }

    //-- Correo electr�nico
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId28') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId28.value') == '') {
            swal("Cuidado","Favor de escribir el Correo Electr�nico de " + campo, "info");
            return false;
        } 
    }


    //-- Dominio de correo
   if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId35') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId35.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId36') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId36.value') == '') {
                    swal("Cuidado","Favor de seleccionar o escribir el Dominio de correo de " + campo, "info");
                    return false;
                }
            } else {
                swal("Cuidado","Favor de seleccionar o escribir el Dominio de correo de" + campo, "info");
                return false;
            }
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId35') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId35.value') != '') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId36') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId36.value') != '') {
                            swal("Cuidado","Favor de solo proporcionar un dominio de correo de los " + campo, "info");
                            return false;
                        }
                    }
                }
            }
        }
    }


    return bandera_telac;
}

function validarQuestion3() {
    bandera_telac = true;
    campo = "DATOS DE EMPRESA";

    //-- Nombre de la Empresa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5.value') == '') {
            swal("Cuidado","Favor de escribir el Nombre de la Empresa en los " + campo, "info");
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId5'), "Nombre de la Empresa en los " + campo, 1, 100))
                return false;
        }
    }

    //-- Lada Oficina
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value'))) {
                swal("Cuidado","La Lada debe tener solo d�gitos de " + campo, "info");
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value.length') < 2) {
                    swal("Cuidado","La Lada debe ser 2 o 3 d�gitos de " + campo, "info");
                    return  false;
                }
            }
        } else {
            swal("Cuidado","Favor de escribir la Lada de " + campo, "info");
            return  false;
        }
    }
    
    
    //-- Tel�fono Oficina
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value'))) {
                swal("Cuidado","El Tel�fono Casa debe tener solo d�gitos de " + campo, "info");
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value.length') != 10) {
                    swal("Cuidado","Entre el Tel�fono y la Lada de la Oficina se deben de conjuntar 10 d�gitos de " + campo, "info");
                    return  false;
                }
            }
        } else {
            swal("Cuidado","Favor de escribir el Tel�fono Oficina de " + campo, "info");
            return  false;
        }
    }
    
    //-- TDC Ofrecida
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId12') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId12.value') == '') {
            swal("Cuidado","Favor de seleccionar la TDC ofrecida de " + campo, "info");
            return  false;
        }
    }

    //-- Env�o de Estados de Cuenta
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') == '') {
            swal("Cuidado","Favor de seleccionar el Env�o de Estados de Cuenta de " + campo, "info");
            return  false;
        }
    }
    
    //-- �Autoriza le enviemos informaci�n de promociones v�a telef�nica?
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId16') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId16.value') == '') {
            swal("Cuidado","Favor de seleccionar la Autoriza le enviemos informaci�n de promociones v�a telef�nica de " + campo, "info");
            return  false;
        }
    }
    
    //-- �Autoriza le enviemos informaci�n de promociones v�a email?
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17.value') == '') {
            swal("Cuidado","Favor de seleccionar la Autoriza le enviemos informaci�n de promociones v�a email de " + campo, "info");
            return  false;
        }
    }

    
    return bandera_telac;
}



function validarQuestion4 (){

    bandera_telac = true;
    campo = "REFERENCIAS BANCARIAS";

    // Campo numerico para antiguedad tdc 1 
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId7') != null) {
        let field = eval('document.SurveyResponse.txtQId' + survey_id + '4CId7');
        let fieldValue = field.value;
    
        if (fieldValue === '') {
            swal("Cuidado", " Favor de escribir el Número de Antigueda del " + campo, "info");
            return false;
        } else {
            if (!/^([0-9])*$/.test(fieldValue)) {
                swal("Cuidado", "El campo de Antiguedad debe tener solo dígitos en" + campo, "info");
                return false;
            } 
        }
    }

   // Campo numerico para digitos tdc 
   if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId2') != null) {
    let field = eval('document.SurveyResponse.txtQId' + survey_id + '4CId2');
    let fieldValue = field.value;

    if (fieldValue === '') {
        swal("Cuidado", "Favor de escribir el Número de Digitos del " + campo, "info");
        return false;
    } else {
        if (!/^([0-9])*$/.test(fieldValue)) {
            swal("Cuidado", "El campo de Digitos debe tener solo dígitos en" + campo, "info");
            return false;
        } 
    }
}

    return bandera_telac;
}

function validarQuestion5() {
    bandera_telac = true;
    campo = "VALIDACION";

    //-- TITULAR TDC VIGENTE
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId1.value') == '') {
            swal("Cuidado","Favor de seleccionar si es titular de una TDC vigente " + campo, "info");
            return  false;
        }
    }
    
    return bandera_telac;
}

function getDOY(fecha_actual) {
    var onejan = new Date(fecha_actual.getFullYear(), 0, 1);
    return Math.ceil((this - onejan) / 86400000);
}

function ChecaEmail() {
    var a = 0;
    var ArreEmail = new Array();
    var ArrePeguntaEmail = new Array();
    var banderaEmail = true;

    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26') != null) {
        ArreEmail[a] = eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value');
        ArrePeguntaEmail[a] = "Email:";
        a++;
    }

    for (a = 0; a < ArreEmail.length; a++) {
        if (ArreEmail[a].length > 0 && !emailCheck(ArreEmail[a])) {
            banderaEmail = false;
        }
    }

    return banderaEmail;
}

function emailCheck(emailStr) {

    var emailPat = /^(.+)@(.+)$/
    var specialChars = "\\(\\)<>@,;:\\\\\\\"\\.\\[\\]"
    var validChars = "\[^\\s" + specialChars + "\]"
    var quotedUser = "(\"[^\"]*\")"
    var ipDomainPat = /^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/
    var atom = validChars + '+'
    var word = "(" + atom + "|" + quotedUser + ")"
    var userPat = new RegExp("^" + word + "(\\." + word + ")*$")
    var domainPat = new RegExp("^" + atom + "(\\." + atom + ")*$")
    var matchArray = emailStr.match(emailPat)
    if (matchArray == null) {
        alert("EMAIL - LA DIRECCION DE CORREO ES INCORRECTA (CHECA QUE TENGAN @ Y .)")
        return false
    }
    var user = matchArray[1]
    var domain = matchArray[2]

    if (user.match(userPat) == null) {
        alert("EMAIL - EL NOMBRE DE USUARIO NO PUEDE SER VALIDO")
        return false
    }

    var IPArray = domain.match(ipDomainPat)
    if (IPArray != null) {
        for (var i = 1; i <= 4; i++) {
            if (IPArray[i] > 255) {
                alert("EMAIL - EL DESTINATARIO IP ES INVALIDO!")
                return false
            }
        }
        return true
    }

    var domainArray = domain.match(domainPat)
    if (domainArray == null) {
        alert("EMAIL - EL DOMINIO NO PUEDE SER VALIDO")
        return false
    }


    var atomPat = new RegExp(atom, "g")
    var domArr = domain.match(atomPat)
    var len = domArr.length
    if (domArr[domArr.length - 1].length < 2 ||
            domArr[domArr.length - 1].length > 3) {
        alert("EMAIL - LA DIRECCION DEL DOMINIO DEBE TERMINAR EN TRES LETRAS O DOS LETRAS PARA EL PAIS")
        return false
    }

    if (len < 2) {
        var errStr = "EMAIL - A la direcci�n le est� faltando un hostname!"
        alert(errStr)
        return false
    }

    return true;
}

//VALIDA LOS TAMA�OS DE LOS DIFERENTES CAMPOS
function tamanos(campo, nombrecampo, log_min, log_max) {
    var a = 0;
    var contDigitos = 0;
    var Arretamano = new Array();
    var ArrePeguntatam = new Array();
    var Arrelongitudmin = new Array();
    var Arrelongitudmax = new Array();
    var arreNumDigitos = new Array();
    var arreNumDigitosTexto = new Array();
    //var banderatamanos=true;

    if (campo != null) {
        Arretamano[a] = campo.value.length;
        ArrePeguntatam[a] = nombrecampo;
        Arrelongitudmin[a] = log_min;
        Arrelongitudmax[a] = log_max;
        a++;
    }

    contDigitos = 0;

    for (a = 0; a < Arretamano.length; a++) {
        if ((Arretamano[a] < Arrelongitudmin[a] && Arretamano[a] > 0) || (Arretamano[a] > Arrelongitudmax[a] && Arretamano[a] > 0)) {
            contDigitos = arreNumDigitos.length;
            if (Arrelongitudmin[a] == Arrelongitudmax[a]) {
                alert(ArrePeguntatam[a] + "  \n\n Longitud debe ser igual a " + Arrelongitudmax[a]);
                campo.select();
            } else {
                alert(ArrePeguntatam[a] + "  \n\n La Longitud debe estar entre " + Arrelongitudmin[a] + " y " + Arrelongitudmax[a]);
                campo.select();
            }
            return false;
            break;
        }
    }
    return true;
}




function SubmitForm(boton) {
    //document.SurveyResponse.submit();
    
 if (fechas() && validarQuestion() && validarQuestion2() && validarQuestion3() && validarQuestion5()
            && validarcobertura() && validarQuestion4()) {
        
        var nombre = document.getElementById('nombrepila1').value;
        var apaterno = document.getElementById('appaterno1').value;
        var amaterno = document.getElementById('apmaterno1').value;
    
             
        if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId12CId27.value'))) {
                alert("El CELULAR debe tener solo DIGITOS o VACIO!!");
                return  false;
        }        		
        alert('La solicitud que estas procesando es: ' + customer_id + '\n' + 'Nombre: '+nombre+" "+apaterno+" "+amaterno);
         document.SurveyResponse.submit();
    }
}

function validarcoberturaBK(){
    cp1 = 0;
    cp2 = 0;
    if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId12') != null){
        if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId12.value') == '-1'){
            alert("CP sin Cobertura PRIMERA DIRECCION");
            cp1 = 1;
        }
    }
    
    if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId23') != null){
        if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId23.value') == '-1' || 
            eval('document.SurveyResponse.txtQId'+survey_id+'2CId23.value') == ''){
            alert("CP sin Cobertura DIRECCION ALTERNA");
            cp2 = 1;
        }
    }
    
    if(cp1 == 0 || cp2 == 0){
        return true;
    }else{
        return false;
    }
    
}

//OK

function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
}

function validarcobertura(){
    cp1 = 0;
    cp2 = 0;
    
    if (getSelectedText('COLONIA1').substr(0, 19) == 'NO HAY COBERTURA - ')
        cp1 = 1;
    
    if(cp1 == 1 && cp2 == 1){
        alert("NO HAY COBERTURA para ambos CP, no se procesara la solicitud.");
        return false;
    }else{
        return true;        
    }
    
}

function SaveForm(boton) {
    if(conteo_agendas <= 4){
        document.getElementById("modo").value = "guardar";
        alert('La solicitud que estas guardando es: ' + customer_id);
        document.SurveyResponse.submit();
    }else{
        alert("No puedes agendar, ya tienes 5 o mas agendas para hoy!!!");
    }
    
}


/*Inicio de Validaci�n de edad para AP, CV , AP Recuperados y CV Recuperados*/
function validarAdulto(fecha, campo, limite) {
    dateUser = fecha;
    anioUser = dateUser.substr(6, 4)
    mesUser = dateUser.substr(3, 2)
    diaUser = dateUser.substr(0, 2)
    var dinami_edad = 0;

    currentDate = new Date();
    currentDay = currentDate.getDate();
    currentMonth = (currentDate.getMonth() + 1);
    currentYear = currentDate.getFullYear();

    if (currentMonth == 1 || currentMonth == 2 || currentMonth == 5 || currentMonth == 7 || currentMonth == 8 || currentMonth == 10 || currentMonth == 12) {
        daysinmonth = 31
    } else if (currentMonth == 2) {
        if (currentYear % 4 == 0) {
            daysinmonth = 28
        } else {
            daysinmonth = 29
        }
    } else if (currentMonth == 4 || currentMonth == 6 || currentMonth == 9 || currentMonth == 11) {
        daysinmonth = 30
    }

    mod_year = currentYear - anioUser;
    mod_day = currentDay - diaUser;
    mod_month = currentMonth - mesUser;

    if (mod_month < 0) {
        mod_year = mod_year - 1;
        mod_month = 12 + mod_month;
        if (mod_day < 0) {
            mod_month = mod_month - 1;
            mod_day = 30 + mod_day;
        }
    } else {
        if (mod_month == 0) {
            if (mod_day < 0) {
                mod_year = mod_year - 1;
                mod_month = 11;
                mod_day = 30 + mod_day;
            }
        } else {
            if (mod_day < 0) {
                mod_month = mod_month - 1;
                mod_day = 30 + mod_day;
            }
        }
    }
    if (limite == "T") {
        dinami_edad = 82;
        dinami_edadminima = 18;
    }

    if (mod_year < dinami_edadminima) {
        alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
        return false;
    } else {
        if (dinami_edad == mod_year) {
            alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
            return false;
        } else {
            if (dinami_edad > mod_year) {
                return true;
            } else {
                alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
                return false;
            }
        }
    }

}

/*Fin de Validaci�n de edad*/

function VerificaCapturaRFC(objeto, tipoobjeto) {
    alert(objeto.value);
}

function quitaEspaciosDobles(texto) {
    var cadena = texto;
    var aux = '';
    for (i = 0; i < texto.length - 1; i++) {
        if (texto.charAt(i) == ' ') {
            aux = aux + texto.charAt(i);
            if (texto.charAt(i + 1) != ' ') {
                cadena = cadena.replace(aux, ' ');
                aux = '';
            }
        }
    }

    return cadena;
}


function camposNumericos(){




}



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//			Funcion que va ha validar caracteres especiales
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
function checaCaracteresInvalidos(boton) {
    var forma = boton.form
    var a = 0;
    var banderaCaracterEspecial;
    banderaCaracterEspecial = false;
    var matchArray;
    var cadena;

    var strCadena2 = "";
    var strCadena = "";
    for (a = 0; a < forma.elements.length - 1; a++) {
        if (forma.elements[a].type == 'hidden') {
            if (forma.elements[a].name == 'hdntxt') {
                strCadena2 = "";
                strCadena = "";
                cadena = document.all.item(forma.elements[a].value).value;
                while (hayCaracteres(cadena).length > 0) {
                    strCadena2 = hayCaracteres(cadena);

                    // 	    alert("ENTRO WHILE: " + strCadena2);
                    strCadena = cadena;
                    if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'a')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'e')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'i')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'o')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'u')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'n')
                    } else {
                        arrText = strCadena.split(strCadena2);
                        strCadena = arrText.join("");
                    }
                    cadena = strCadena;
                    document.all.item(forma.elements[a].value).value = strCadena;
                }
            }//if  hdntxt
        }// if hidden
    }//for

    if (banderaCaracterEspecial) {
        window.scroll(1, a * 7.5)
        alert("REVISA QUE EL CAMPO NO TENGA CARACTERES ESPECIALES \n                                    %,$,?,?,(,),{,},[,],*,+,#,&");
        return true;
    } else {
        return false;
    }
}// fin checaCaracteresInvalidos

function hayCaracteres(cadena) {
    ExpreReg = /%|\$|\?|\?|\(|\)|\{|\}|\[|\]|\*|\+|\t|\c13|\#|\&|\?|\||\?|\,|\;|\:|\_|\:|\~|\?|\?|\?|\?|\?|\'|\!|\?|\<|\>|\^/;		  		//'
    matchArray = cadena.match(ExpreReg); // si algun caracter es igual a %,$,?,?,(,),{,},[,],*,+,#,&,?,|,?,,,;,:
    if (matchArray == null) {
        return "";
    } else {
        return matchArray;
    }
}