import * as Yup from "yup";
import { AnySchema } from "yup";

export const ValSignIn = Yup.object().shape({
  USERNAME: Yup.string()
    .required("username is required")
    .min(6, "username must contain 6 characters"),
  PASSWORD: Yup.string()
    .required("password is required")
    .min(8, "password must contain 8 characters"),
});

export const ValUpdateSurvey = Yup.object().shape({
  ID_SURVEY: Yup.string().required("ID_SURVEY is required"),
  STATUS_SURVEY: Yup.number().required("password is required").integer(),
});

export const validate =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate(req.body, { abortEarly: false });
      next();
    } catch (err: any) {
      res.status(400).json({ errors: err.errors });
    }
  };

export const validateSurvey =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate({
        params: req.params,
        body: req.body,
      });

      next();
    } catch (err: any) {
      return res.status(400).json({ type: err.name, message: err.message });
    }
  };

export const ValSurvey = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .max(100),
    TYPIFICATIONID: Yup.string()
      .required("The TYPIFICATIONID field is required.")
      .max(100),
  }),
});


export const ValSurveyNoSale = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .matches(/^[0-9]+$/, "The CUSTOMERID must be a numeric value.")
      .max(100),
    ID_PHONE: Yup.string()
      .required("The ID_PHONE field is required.")
      .matches(/^[0-9]+$/, "The ID_PHONE must be a numeric value.")
      .max(20),
    TYPIFICATIONID: Yup.string()
      .required("The TYPIFICATIONID field is required.")
      .matches(/^[0-9]+$/, "The TYPIFICATIONID must be a numeric value.")
      .max(100),
  }),
});


export const ValCustomerInformation = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .max(100)
  }),
});
