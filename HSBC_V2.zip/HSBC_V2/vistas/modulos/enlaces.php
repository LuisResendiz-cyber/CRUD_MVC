<?php
if ($_SESSION["perfil"] != "Administrador") {
    echo '<script>
        window.location = "?ruta=inicio";
    </script>';
    exit;
}
?>


<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Administrar Ligas de Campañas
        </h1>
        <ol class="breadcrumb">
            <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Administrar usuarios</li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <button class="btn btn-primary" data-toggle="modal" data-target="#modalAgregarLiga">
                    Agregar Nueva Liga
                </button>
                <button class="btn btn-primary" data-toggle="modal" data-target="#modalLigasMasivas">
                    Carga Masiva Ligas
                </button>
            </div>
            <div class="box-body">

                <table class="table table-bordered table-striped dt-responsive tablas" width="100%">

                    <thead>

                        <tr>

                            <th style="width:10px">Id</th>
                            <th>Titulo</th>
                            <th>Liga</th>
                            <th>Campana</th>
                            <th>Acciones</th>

                        </tr>

                    </thead>

                    <tbody>


                        <?php

$item = null;
$valor = null;

$enlaces = ControladorLigas::ctrMostrarEnlaces($item, $valor);


foreach ($enlaces as $key => $value){
  echo ' <tr>
          <td>'.($key+1).'</td>
          <td>'.$value["titulo"].'</td>
          <td>'.$value["url"].'</td>
          <td>'.$value["NOMBRE_CAMPANA"].'</td>';                   
          echo '
          <td>
            <div class="btn-group">            
              <button class="btn btn-warning btnEditarEnlace" idEnlace="'.$value["id"].'" data-toggle="modal" data-target="#modalEditarEnlace"><i class="fa fa-pencil"></i></button>
              <button class="btn btn-danger btnEliminarEnlace" idEnlace="'.$value["id"].'"><i class="fa fa-times"></i></button>
            </div>  
          </td>
        </tr>';
}
?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>

<div id="modalAgregarLiga" class="modal fade" role="dialog">

    <div class="modal-dialog">

        <div class="modal-content">

            <form role="form" method="post" enctype="multipart/form-data">


                <div class="modal-header" style="background:#3c8dbc; color:white">

                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <h4 class="modal-title">Administar Liga</h4>

                </div>

                <div class="modal-body">
                    <div class="box-body">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" name="titulo"
                                    placeholder="Ingresar el Titulo Descriptivo del Enlace" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" name="nuevoLiga"
                                    placeholder="Ingresar la Liga de Asignacion" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                <select class="form-control input-lg" id="cat_campanas" name="campana" required>
                                    <option value="">Selecionar La Campaña</option>
                                    <!--<option value="1">Invex_Internet</option>
                                                                                          <option value="2">BanorteCredito</option>
                                                                                          <option value="3">Amex_Insurance</option>
                                                                                          <option value="4">HSBC</option>
                                                                                          <option value="5">TDCAMEXONLINE</option>
                                                                                          <option value="6">OpenPay</option>
                                                                                          <option value="7">Amex_Insurance_Digital</option>
                                                                                          <option value="8">Banamex Seguros</option>
                                                                                          <option value="9">Banamex Banco</option>
                                                                                          <option value="10">Banamex TDC</option>
                                                                                          <option value="11">INVEXINT</option>
                                                                                          <option value="12">Auto Aseguradoras</option>
                                                                                          <option value="13">AUTO</option> -->
                                </select>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>

                    <button type="submit" class="btn btn-primary">Guardar usuario</button>

                </div>

            </form>

            <?php

                              $crearLiga = new ControladorLigas();
                              $crearLiga->ctrCrearLiga();

                              ?>

        </div>

    </div>

</div>



<!-- <div id="modalLigasMasivas" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form role="form" method="post" enctype="multipart/form-data">
                <div class="modal-header" style="background:#3c8dbc; color:white">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Administar Liga</h4>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="card">
                            <h3>Upload Files</h3>
                            <div class="drop_box">
                                <header>
                                    <h4>Select File here</h4>
                                </header>
                                <p>Files Supported: PDF, TEXT, DOC , DOCX</p>
                                <input type="file" hidden accept=".doc,.docx,.pdf" id="fileID" style="display:none;">
                                <button class="btn">Choose File</button>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>
                    <button type="submit" class="btn btn-primary">Subir Archivo</button>
                </div>

            </form>

        </div>

    </div>

</div> -->

<!-- Modal -->
<div class="modal fade" id="modalLigasMasivas" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <div class="container">
                        <div class="card">
                            <h3>Upload Files</h3>
                            <div class="drop_box">
                                <header>
                                    <h4>Select File here</h4>
                                </header>
                                <p>Files Supported: PDF, TEXT, DOC , DOCX</p>
                                <input type="file" hidden accept=".doc,.docx,.pdf" id="fileID" style="display:none;">
                                <button class="btn">Choose File</button>
                            </div>

                        </div>
                    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>


<style>

 .container {
  height: 50vh;
  width: 100%;
  align-items: center;
  display: flex;
  justify-content: center;
  background-color: #fcfcfc;
}

.card {
  border-radius: 10px;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.3);
  width: 600px;
  height: 260px;
  background-color: #ffffff;
  padding: 10px 30px 40px;
}

.card h3 {
  font-size: 22px;
  font-weight: 600;
  
}

.drop_box {
  margin: 10px 0;
  padding: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  border: 3px dotted #a3a3a3;
  border-radius: 5px;
}

.drop_box h4 {
  font-size: 16px;
  font-weight: 400;
  color: #2e2e2e;
}

.drop_box p {
  margin-top: 10px;
  margin-bottom: 20px;
  font-size: 12px;
  color: #a3a3a3;
}

.btn {
  text-decoration: none;
  background-color: #005af0;
  color: #ffffff;
  padding: 10px 20px;
  border: none;
  outline: none;
  transition: 0.3s;
}

.btn:hover{
  text-decoration: none;
  background-color: #ffffff;
  color: #005af0;
  padding: 10px 20px;
  border: none;
  outline: 1px solid #010101;
}
.form input {
  margin: 10px 0;
  width: 100%;
  background-color: #e2e2e2;
  border: none;
  outline: none;
  padding: 12px 20px;
  border-radius: 4px;
} 

</style>

<div id="modalEditarEnlace" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form role="form" method="post" enctype="multipart/form-data">
                <div class="modal-header" style="background:#3c8dbc; color:white">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Administar Liga</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div class="form-group">
                            <input type="hidden" class="form-control input-lg" name="Enlace_id" value="" id="id_Enlace">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" id="Editartitulo" name="Editartitulo"
                                    placeholder="Ingresar el Titulo Descriptivo del Enlace" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" id="EditarLiga" name="EditarLiga"
                                    placeholder="Ingresar la Liga de Asignacion" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                <select class="form-control input-lg" id="Editarcampana" name="Editarcampana" required>
                                    <option value="">Selecionar La Campaña</option>
                                    <option value="1">Invex_Internet</option>
                                    <option value="2">BanorteCredito</option>
                                    <option value="3">Amex_Insurance</option>
                                    <option value="4">HSBC</option>
                                    <option value="5">TDCAMEXONLINE</option>
                                    <option value="6">OpenPay</option>
                                    <option value="7">Amex_Insurance_Digital</option>
                                    <option value="8">Citibanamex</option>
                                    <option value="9">CitiBanco</option>
                                    <option value="10">CitiSofom</option>
                                    <option value="11">INVEXINT</option>
                                </select>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>
                    <button type="submit" class="btn btn-primary">Editar Enlace</button>

                </div>

            </form>

            <?php

                              $EditarLiga = new ControladorLigas();
                              $EditarLiga->ctrEditarEnlace();

                              ?>

        </div>

    </div>

</div>


<?php
$crearLiga = new ControladorLigas();
$crearLiga->ctrBorrarEnlace();

?>