<?php
# @uthor Mark 
# Process_data File 

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize_nolayout("agente,supervisor", "");

$action = desencripta($_REQUEST['act']);
//$isPredictivo = get_EsPredictivo($db);
$isPredictivo = get_session_varname("s_usr_marcacion");
$empresa = get_session_varname("s_usr_centro");
$s_usr_id = get_session_varname("s_usr_id");
$header = "index.php";


$usr_id = get_session_varname("s_usr_id");
$u_persona = get_session_varname("id_solicitud");
$u_registro = get_session_varname("id_registro");
$nomina = get_session_varname('s_usr_nomina');
$t_registro = get_session_varname('t_registro');
$tipo_marcacion = get_session_varname("s_usr_marcacion");

if (isset($action) && $action == 1) { ##### OBTIENE UN REGISTRO Y RECUPERA EL NUMERO DE SOLICITUD ##
    unset_session_varname("calificados");

    //$usr_id = get_session_varname("s_usr_id");
    $name = get_session_varname('s_usr_nombre');
    if ($isPredictivo == 2) {
        if (get_session_varname("agenda") == 1) {
            unset_session_varname("agenda");
            unset_session_varname("id_solicitud");
        }

        //Verifica si tiene registros agendados
        $data = get_registros_agendado($usr_id, $db);
        $agendas = array();

        for ($s = 0; $s < count($data->_array); $s++) {
            $agenda = array();
            $agenda['REGISTRO'] = $data->_array[$s]['REGISTRO'];
            $agenda['PERSONA'] = $data->_array[$s]['PERSONA'];
            $agenda['HORA'] = $data->_array[$s]['HORA'];
            $agenda['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $agenda['DATE_'] = $data->_array[$s]['DATE_'];
            $agenda['FECHA'] = $data->_array[$s]['FECHA'];
            $agenda['COMENTARIO'] = $data->_array[$s]['COMENTARIO'];
            $agendas[$s] = $agenda;
        }

        set_session_varname("agenda", $agendas);

        $datos_cliente = get_session_varname("agenda");
        $agendados = count($datos_cliente[0]['U_PERSONA']);

        if ($agendados != 0) {
            $header = "modules.php?mod=agentes&op=error&e=7&customerid=" . $datos_cliente[0]['U_PERSONA'] . "&hora=" . $datos_cliente[0]['HORA'] . "&fecha=" . $datos_cliente[0]['FECHA'] . "&u_registro=" . $datos_cliente[0]['REGISTRO'] . "&com=" . urlencode($datos_cliente[0]['COMENTARIO']); # ERROR GENERICO
        } else if (strlen(get_session_varname("id_solicitud")) == 0) {
            $rnd = rand(1, 100) + 1;
            $data = get_registro_solicitud(get_session_varname('s_usr_id'), 1, 1, 0, 10, $rnd, 0, 0, $db);
            $id_solicitud = $data->fields['U_PERSONA'];
            $id_registro = $data->fields['U_REGISTRO_CAMP'];

            $telefonos_disponibles = count($data->_array);
            $customers = array();

            for ($s = 0; $s < count($data->_array); $s++) {
                $customer = array();
                $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
                $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
                $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
                $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
                $customer['RFC'] = $data->_array[$s]['RFC'];
                $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
                $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO'];
                $customer['PAIS'] = $data->_array[$s]['PAIS'];
                $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
                $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
                $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'];
                $customer['LOCALIZACIONRT'] = $data->_array[$s]['LOCALIZACIONRT'];// tipo
                $customer['ACTIVO'] = $data->_array[$s]['ACTIVO'];//visto pero no marcable
                $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
                $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
                $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
                $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
                $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
                $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
                $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
                $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
                $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'];
                $customer['REFERIDO_POR'] = $data->_array[$s]['REFERIDO_POR'];
                $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
                $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
                $customer['COBERTURA'] = $data->_array[$s]['COBERTURA'];
                $customer['FECHA_CADUCIDAD'] = $data->_array[$s]['FECHA_CADUCIDAD'];
                $customer['BASE'] = $data->_array[$s]['BASE'];
                $customers[$s] = $customer;
            }

            set_session_varname("datos_persona", $customers);
            set_session_varname("id_solicitud", $id_solicitud);
            set_session_varname("id_registro", $id_registro);

            if (isset($id_solicitud) && $id_solicitud > 0) {
                set_traking(get_session_varname("s_usr_id"), 'OBTUVO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
                set_session_varname("inicio",1);
                $header = "modules.php?mod=agentes&op=index";
            } else {
                $header = "modules.php?mod=agentes&op=error&e=1&bnd=3"; //.$id_bnd; # ERROR CUANDO NO TIENE MAS REGISTROS LIBRES
            }
        } else {
            set_traking(get_session_varname("s_usr_id"), 'OBTUVO REGISTRO ELSE', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
            set_session_varname("inicio",1);
            $header = "modules.php?mod=agentes&op=index"; # AUN NO SE ABANDONA ESTE REGISTRO
        }
        unset_session_varname("CE");
        unset_session_varname("caltelefono0");
        unset_session_varname("caltelefono1");
        unset_session_varname("caltelefono2");
        unset_session_varname("caltelefono3");
        unset_session_varname("caltelefono4");
        unset_session_varname("caltelefono5");
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
    }

    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
} elseif (isset($action) && $action == 2) { ##### VALIDA EL ACCESO A LA BUSQUEDA DE REGISTROS
    //$usr_id = get_session_varname("s_usr_id");
    $function = 11000;
    $languaje = 1;

    $rs = get_valida_acceso($usr_id, $function, $languaje, $db);
    $acceso = count($rs->fields);

    if ($acceso != 0) {
        $header = "modules.php?mod=agentes&op=busqueda_cliente";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=3"; # ERROR CUANDO NO TIENE PERMITIDO REALIZAR BUSQUEDAS
    }
} elseif (isset($action) && $action == 3) { ##### MUESTRA EN PANTALLA EL REGISTRO SELECCIONADO DE LA BUSQUEDA    
    if (get_session_varname('id_solicitud') != null) {
        if (!isset($_REQUEST['tipo'])) {
            set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
            set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        } else {
            set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO POR REFERIDO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        }
        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");
    }
    $u_persona = $_REQUEST['u_persona'];
    $u_registro = $_REQUEST['u_registro'];
    $trabajado = $_REQUEST['trabajado'];
    set_session_varname("trabajado", $trabajado);

    //$usr_id = get_session_varname("s_usr_id");

    set_libera_agendado($u_registro, $usr_id, $db);
    unset_session_varname("agenda");

    $data = get_registro_especifico($u_registro, $usr_id, 'O', $db);

    $id_solicitud = $data->fields['U_PERSONA'];
    $id_registro = $u_registro;

    //die();

    $telefonos_disponibles = count($data->_array);
    $customers = array();

    for ($s = 0; $s < count($data->_array); $s++) {
        $customer = array();
        $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
        $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
        $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
        $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
        $customer['RFC'] = $data->_array[$s]['RFC'];
        $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
        $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO'];
        $customer['PAIS'] = $data->_array[$s]['PAIS'];
        $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
        $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
        $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'];
        $customer['LOCALIZACIONRT'] = $data->_array[$s]['LOCALIZACIONRT'];
        $customer['ACTIVO'] = $data->_array[$s]['ACTIVO'];
        $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
        $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
        $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
        $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
        $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
        $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
        $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
        $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
        $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'];
        $customer['REFERIDO_POR'] = $data->_array[$s]['REFERIDO_POR'];
        $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
        $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
        $customer['COBERTURA'] = $data->_array[$s]['COBERTURA'];
        $customer['FECHA_CADUCIDAD'] = $data->_array[$s]['FECHA_CADUCIDAD'];                
		
        $customers[$s] = $customer;
    }
    //echo $id_registro." 1";
    //echo $id_solicitud;
    //die();
    set_session_varname("datos_persona", $customers);
    if (isset($id_solicitud) && $id_solicitud > 0) {
        set_session_varname("id_solicitud", $id_solicitud);
        set_session_varname("id_registro", $id_registro);

        set_session_varname("inicio",1);
        $header = "modules.php?mod=agentes&op=index&t_reg=".$_REQUEST['tipo'];
    } else {
        $data = get_mensaje_registro($id_registro, $db);

        for ($s = 0; $s < count($data->_array); $s++) {
            $mensaje = array();
            $mensaje['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $mensaje['ID_BLOQUEO'] = $data->_array[$s]['ID_BLOQUEO'];
            $mensaje['U_ZONA'] = $data->_array[$s]['U_ZONA'];
            $mensaje['ESTATUS'] = $data->_array[$s]['ESTATUS'];
            $mensaje['AGENDAS'] = $data->_array[$s]['AGENDAS'];
            $mensaje['TEXTO'] = $data->_array[$s]['TEXTO'];			
        }
        //die();
        $header = "modules.php?mod=agentes&op=error&e=1&bnd=4&customerid=" . $mensaje['U_PERSONA'] . "&id_bloqueo=" . $mensaje['ID_BLOQUEO'] . "&u_zona=" . $mensaje['U_ZONA'] . "&estatus=" . $mensaje['ESTATUS'] . "&agendas=" . $mensaje['AGENDAS'] . "&texto=" . $mensaje['TEXTO']; # ERROR GENERICO
    }
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
} elseif (isset($action) && $action == 4) { ##### LIBERA EL REGISTRO SELECCIONADO Y OBTIENE EL SIGUIENTE DISPONIBLE
    unset_session_varname("calificados");
    unset_session_varname("url_contacto");
    
    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_usr_id = get_session_varname('s_usr_id');
    $contador = $_REQUEST['cont'];
    $contacto_efectivo = 0;
    
    if ($contador == 1) {
        $telefono = $_REQUEST['tel_1'];
        $cal_tel = $_REQUEST['tel_01'];
        $u_telefono = $datos_persona[0]['U_TELEFONO'];
        if ($_REQUEST['tel_01'] == 1010) {
            $contacto_efectivo += 1;
            set_session_varname("s_telefono", $datos_persona[0]['CLAVELADA'] . $datos_persona[0]['TELEFONO']);
            set_session_varname("s_tel_contacto", $datos_persona[0]['U_TELEFONO']);
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
        } else {
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
            set_estatus_registro($id_registro, $s_usr_id, $u_telefono, $cal_tel, 1, '', 1, 0, 'O', $db);				
        }
    } else {

        for ($s = 1, $t = 0; $s <= $contador; $s++, $t++) {
            if ($_REQUEST['tel_0' . $s] == 1010) {
                $_REQUEST['tel_0' . $s] . " if";
                $contacto_efectivo += 1;
                set_session_varname('CE', $t);
                set_session_varname("s_telefono", $datos_persona[$t]['CLAVELADA'] . $datos_persona[$t]['TELEFONO']);
                set_session_varname("s_tel_contacto", $datos_persona[$t]['U_TELEFONO']);
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
            } else if ($_REQUEST['tel_0' . $s] > 0) {
                $cal_tel = $_REQUEST['tel_0' . $s];
                echo $_REQUEST['tel_0' . $s] . " else if";
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
                set_estatus_registro($id_registro, $s_usr_id, $datos_persona[$t]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);				
            }
        }
    }
    //die();
    if ($contacto_efectivo >= 1) {
        set_session_varname("id_producto", $_REQUEST['producto_']);
        $header = "modules.php?mod=agentes&op=cuestionario";
    } else {
//        enviar_aviso_privacidad($usr_id, $nomina, $t_registro, $isPredictivo, $u_persona);
        set_traking(get_session_varname("s_usr_id"), 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");

        if ($isPredictivo == 1) {
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
        } else {
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
        }
    }
} elseif (isset($action) && $action == 5) { ##### REENVIA A LA AGENDA
    $id_solicitud = get_session_varname('id_solicitud');
    $id_sol_req = (isset($_REQUEST['id']) && $_REQUEST['id'] != 0 ? $_REQUEST['id'] : $id_solicitud);

    if ($id_solicitud > 0) {
        if ($id_sol_req != $id_solicitud) {
            set_session_varname("agenda", 1);
            set_session_varname("id_solicitud", $id_sol_req);
        } else {
            //set_session_varname("id_solicitud",$id_solicitud);
        }
    } else {
        set_session_varname("agenda", 1);
        set_session_varname("id_solicitud", $id_sol_req);
    }

    $header = "modules.php?mod=agentes&op=agenda";
} elseif (isset($action) && $action == 6) { ##### AGENDA EL REGISTRO SELECCIONADO
    $datos_cliente = get_session_varname("datos_persona");
    $nombre = $datos_cliente[0]['NOMBRE'] . ' ' . $datos_cliente[0]['APATERNO'] . ' ' . $datos_cliente[0]['AMATERNO'];
    $id_registro = get_session_varname('id_registro');
    $s_usr_id = get_session_varname('s_usr_id');
    $fecha_agendado = $_REQUEST['fecha_agenda'];
    $comentarios = $_REQUEST['comentarios'];
    $hora = $_REQUEST['hora'];
    $id_telefono = get_session_varname('s_u_telefono');
    $array_fecha = explode("/", $fecha_agendado);
    $anio = $array_fecha[2];
    $mes = $array_fecha[1];
    $day = $array_fecha[0];

    $agenda_registro = set_agenda_registro($s_usr_id, $id_registro, $anio, $mes, $day, $hora, $nombre, $comentarios, 1, $db);
    set_estatus_registro_normal($id_registro, 406, 'AGENDADO', 1, $s_usr_id, 1, $id_telefono, 1, 0, '1', $db);

    set_traking($s_usr_id, 'AGENDO REGISTRO', get_session_varname("s_usr_maquina"), $id_registro, '', $db);
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    if ($isPredictivo == 1) {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
    //$header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
} elseif (isset($action) && $action == 7) { # CANCELA LA ACCION DE AGENDADO
    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_usr_id = get_session_varname('s_usr_id');
    $calificacion = $_REQUEST['si_contacto'];
    
    set_califica_telefono($datos_persona[get_session_varname('CE')]['U_TELEFONO'], $calificacion, 0, $db);
    set_estatus_registro($id_registro, $s_usr_id, $datos_persona[get_session_varname('CE')]['U_TELEFONO'], $calificacion, 1, '', 1, 0, 'O', $db);

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");

    if ($isPredictivo == 1) {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
} elseif (isset($action) && $action == 8) { ##### ACCION PARA ABANDONAR UN REGISTRO
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    
    set_session_varname("solicitud_previa", $id_solicitud);

    set_libera_solicitud($id_registro, 1, 1, $db);
    set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("agenda");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    if ($isPredictivo == 1) {
        $url_logout_pred = "http://172.20.1.10/click2dial/hsbc/softemployeelogout.php?employeeid=" . $s_usr_id;
        
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION
} elseif (isset($action) && $action == 9) { ##### CREA UN NUEVO REGISTRO
    //$usr_id = get_session_varname("s_usr_id");
    $campana = 1;
    $nombre = quitarCaracteresEspeciales(strtoupper($_REQUEST['nombre']));
    $paterno = quitarCaracteresEspeciales(strtoupper($_REQUEST['paterno']));
    $materno = quitarCaracteresEspeciales(strtoupper($_REQUEST['materno']));
    $lada = $_REQUEST['lada'];
    $telefono = $_REQUEST['telefono'];
    $calificacion = $_REQUEST['calificacion'];
    
    if (empty($_REQUEST['tipo'])) {
        $tipo = 3; // Base blanca por default
        //$referente = 0;
        $referente = get_session_varname('solicitud_previa');
    } else {
        $tipo = $_REQUEST['tipo'];
        if ($tipo == 3){
            $referente = get_session_varname('solicitud_previa');
        }else{
            $referente = $_REQUEST['referente'];
        }  
    }

    $result = set_registro_especifico($campana, $usr_id, $nombre, $paterno, $materno, "", "- -", 1, $lada, $telefono, "", $tipo, $db);

    $datos_registro = explode("-", $result);
    
    //print_r($datos_registro);
    //die();

    $u_persona = $datos_registro[0];
    $u_registro = $datos_registro[2];
    $mensaje_error = $datos_registro[6];

    if ($mensaje_error != null) {
        //$header = "modules.php?mod=agentes&op=error&e=11&mensaje_error=" . $mensaje_error; # ERROR GENERICO
        $header = "modules.php?mod=agentes&op=nuevoregistro&tipo=".$_REQUEST['tipo']."&referente=".$referente."&calificacion=".$calificacion."&telefono=".$lada.$telefono."&error=1"; # Redirige a ingresar nuevo registro por existencia
    } else {
        set_traking(get_session_varname("s_usr_id"), 'CREO UN REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), $u_persona, '', $db);

        if ($referente != 0) {
            set_relacion_registro($referente, $u_persona, $tipo, $db);
        }
        
        if ($tipo != 2){
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_persona=" . $u_persona . "&u_registro=" . $u_registro . "&tipo=" . $tipo;
        }else{
            if ($isPredictivo == 1) {
                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
            }else{
                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
            }            
        }
        
    }
} elseif (isset($action) && $action == 10) { # ACCION PARA MOSTRAR EL REGISTRO AGENDADO
    $id_solicitud = $_REQUEST['id'];
    unset_session_varname("id_solicitud");
    set_session_varname("id_solicitud", $id_solicitud);
    set_traking(get_session_varname("s_usr_id"), 'TOMO REGISTRO AGENDADO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    $header = "modules.php?mod=agentes&op=index&sol=" . base64_encode($id_solicitud);
} elseif (isset($action) && $action == 11) { ##### CREA UN NUEVO TELEFONO
    $u_persona = get_session_varname('id_solicitud');
    $u_registro = get_session_varname('id_registro');
    //$usr_id = get_session_varname("s_usr_id");
    $telefono = $_POST['telefono'];
    $lada = $_POST['lada'];
    $tipo_tel = $_POST['tipo_telefonico'];    
    
    //$result = set_nuevo_telefono($u_persona, $lada, $telefono, 3, $db);
    //set_nuevo_telefono($u_persona, $lada, $telefono, $tipo_tel, $usr_id, $db);
    //eresendiz:result != 0 hay mensaje al agregar tel
    $result = set_nuevo_telefono($u_persona, $lada, $telefono, $tipo_tel, $usr_id , $db);
    set_session_varname('resul_reus',$result);
    
    /*if($result != '0'){

        //$header = "modules.php?mod=agentes&op=error&e=10&mensaje_error=".$nuevo_telefono; # ERROR GENERICO
        $header = "modules.php?mod=agentes&op=nuevo_telefono&tipo=1&error=1"; # Redirige a ingresar nuevo telefono por existencia

    } else { */
        if (get_session_varname('id_solicitud') != null) {
            set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
            set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
            unset_session_varname("datos_persona");
            unset_session_varname("id_solicitud");
            unset_session_varname("id_registro");
        }
        $data = get_registro_especifico($u_registro, $usr_id, '2', $db);

        $id_solicitud = $data->fields['U_PERSONA'];
        $id_registro = $u_registro;

        $telefonos_disponibles = count($data->_array);
        $customers = array();
        for ($s = 0; $s < count($data->_array); $s++) {
            $customer = array();
            $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
            $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
            $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
            $customer['RFC'] = $data->_array[$s]['RFC'];
            $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
            $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO'];
            $customer['PAIS'] = $data->_array[$s]['PAIS'];
            $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
            $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
            $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'];
            $customer['LOCALIZACIONRT'] = $data->_array[$s]['LOCALIZACIONRT'];
            $customer['ACTIVO'] = $data->_array[$s]['ACTIVO'];
            $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
            $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
            $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
            $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
            $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
            $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
            $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
            $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
            $customer['REFERIDO_POR'] = $data->_array[$s]['REFERIDO_POR'];
            $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
            $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'];
            $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
            $customer['COBERTURA'] = $data->_array[$s]['COBERTURA'];
            $customer['FECHA_CADUCIDAD'] = $data->_array[$s]['FECHA_CADUCIDAD'];                
			
            $customers[$s] = $customer;
        }

        set_session_varname("datos_persona", $customers);

        if (isset($id_solicitud) && $id_solicitud > 0) {
            
            set_session_varname("id_solicitud", $id_solicitud);
            set_session_varname("id_registro", $id_registro);
            set_session_varname("inicio",1);
            $header = "modules.php?mod=agentes&op=index";
        } else {
            $data = get_mensaje_registro($id_registro, $db);

            for ($s = 0; $s < count($data->_array); $s++) {
                $mensaje = array();
                $mensaje['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
                $mensaje['ID_BLOQUEO'] = $data->_array[$s]['ID_BLOQUEO'];
                $mensaje['U_ZONA'] = $data->_array[$s]['U_ZONA'];
                $mensaje['ESTATUS'] = $data->_array[$s]['ESTATUS'];
                $mensaje['AGENDAS'] = $data->_array[$s]['AGENDAS'];
                $mensaje['TEXTO'] = $data->_array[$s]['TEXTO'];						
            }
            //die();
            $header = "modules.php?mod=agentes&op=error&e=1&bnd=4&customerid=" . $mensaje['U_PERSONA'] . "&id_bloqueo=" . $mensaje['ID_BLOQUEO'] . "&u_zona=" . $mensaje['U_ZONA'] . "&estatus=" . $mensaje['ESTATUS'] . "&agendas=" . $mensaje['AGENDAS'] . "&texto=" . $mensaje['TEXTO']; # ERROR GENERICO
            //$header = "modules.php?mod=agentes&op=error&e=1"; # ERROR GENERICO
        }
    //}
} elseif (isset($action) && $action == 12) { # ACCION DEL CALIFICAR REGISTRO INBOUNT	
    $user = get_session_varname("s_usr_id");
    $id_solicitud = get_session_varname("id_registro");
    if (isset($id_solicitud)) {
        $id_solicitud = get_session_varname("id_registro");
    } else {
        $id_solicitud = $_REQUEST['id_registro'];
    }

    $calificacion = $_REQUEST['calificacion'];
    $califica = set_califica_llamada($user, $id_solicitud, $calificacion, $db);

    if ($califica >= 1) { //SE CALIFICO EL REGISTRO QUE SE ACABA DE DAR DE ALTA	
        set_traking($user, 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, $calificacion, $db);
        $header = "modules.php?mod=agentes&op=nueva_llamada";
    } else {
        unset_session_varname("calificar");
        set_traking($user, 'ERROR CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, $calificacion, $db);
        $header = "modules.php?mod=agentes&op=error&e=6"; # NO SE CALIFICO EL REGISTRO NUEVO
    }
    die();
} elseif (isset($action) && $action == 13) { # ACCION DE ABANDONO REGISTRO IN  CUANDO ESTABA EN LA SOLICITUD ##
    $id_solicitud = get_session_varname('id_solicitud');
    $user = get_session_varname("s_usr_id");
    $etapa = $_REQUEST['etapa'];

    if ($id_solicitud != 0) {
        set_traking($user, 'ABANDONO REGISTRO IN SOLICITUD', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);
        $header = "modules.php?mod=agentes&op=index";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=7"; # NO SE CALIFICO EL NUMERO DE TELEFONO
    }
} elseif (isset($action) && $action == 14 && $_REQUEST["modo"] == "procesar") { ##### PROCESA LA INFORMACION CAPTURADA EN LA SOLICITUD  ##
    $s_usr_id = get_session_varname('s_usr_id');
    $datos_persona = get_session_varname('datos_persona');
    $id_producto = get_session_varname('id_producto');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');

    
    set_delete_survey($id_solicitud, $id_producto, 1, $db);

    $preguntas_ = get_preguntas($id_producto, $id_solicitud, 1, 0, $db);

    if (count($preguntas_->_array) > 0) {
        for ($indice_ = 0; $indice_ < count($preguntas_->_array); $indice_++) {
            $respuestas_ = get_respuestas($id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], 1, $id_solicitud, 1, 0, $db);
            if (count($respuestas_->_array) > 0) {
                for ($indice_resp_ = 0; $indice_resp_ < count($respuestas_->_array); $indice_resp_++) {
                    if ($respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 5 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 6 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 8 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 9) {
                        $respuesta_solicitud = $_REQUEST["txtQId" . $id_producto . $preguntas_->_array[$indice_]['QUESTIONID'] . "CId" . $respuestas_->_array[$indice_resp_]['CHOICEID']];
                        $respuesta_solicitud = trim(preg_replace('/\s+/', ' ', $respuesta_solicitud));
                        if (strlen($respuesta_solicitud) > 0) {
                            set_insert_survey($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], date("Y/n/j"), 1, 1, $db);
                            set_update_results($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], 1, $respuesta_solicitud, $db);
                        }
                    }
                }
            }
        }
    }
    //set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud, $s_usr_id, $db);
    //set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud, $db);
    set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud,get_session_varname("s_tel_contacto"),get_session_varname("grabacion"), $s_usr_id,$db);

    //set_valida_solicitud($id_solicitud, $id_producto, 2, 0, 1, $db);

    set_estatus_registro($id_registro, $s_usr_id,get_session_varname("s_tel_contacto")/* $datos_persona[0]['U_TELEFONO']*/, 1003, 1, 'TELEFONO VENTA', 1, 0, 'O', $db);
    set_traking(get_session_varname("s_usr_id"), 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
        
    if ($isPredictivo == 1) {

        $url_logout_pred = "http://172.20.1.10/click2dial/hsbc/softemployeelogout.php?employeeid=" . $s_usr_id;
        
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }
    
    $header = "modules.php?mod=agentes&op=index";		
    set_session_varname("aprocesado", 1);
} elseif (isset($action) && $action == 14 && $_REQUEST["modo"] == "guardar") { ##### GUARDA LA INFORMACION CAPTURADA EN LA SOLICITUD  ##
    $s_usr_id = get_session_varname('s_usr_id');
    $id_producto = get_session_varname('id_producto');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');

    /* if ($id_producto == 2) {
      $tipo_registro1 = $_REQUEST["txtQId21CId26"];
      $nombre1 = $_REQUEST["txtQId21CId1"];
      $nombre1_2 = $_REQUEST["txtQId21CId2"];
      $paterno1 = $_REQUEST["txtQId21CId3"];
      $materno1 = $_REQUEST["txtQId21CId4"];
      $lada1_1 = $_REQUEST["txtQId21CId5"];
      $telefono1_1 = $_REQUEST["txtQId21CId6"];
      $lada1_2 = $_REQUEST["txtQId21CId7"];
      $telefono1_2 = $_REQUEST["txtQId21CId8"];

      $tipo_registro2 = $_REQUEST["txtQId21CId27"];
      $nombre2 = $_REQUEST["txtQId21CId9"];
      $nombre2_2 = $_REQUEST["txtQId21CId10"];
      $paterno2 = $_REQUEST["txtQId21CId11"];
      $materno2 = $_REQUEST["txtQId21CId12"];
      $lada2_1 = $_REQUEST["txtQId21CId13"];
      $telefono2_1 = $_REQUEST["txtQId21CId14"];
      $lada2_2 = $_REQUEST["txtQId21CId15"];
      $telefono2_2 = $_REQUEST["txtQId21CId16"];

      $tipo_registro3 = $_REQUEST["txtQId21CId28"];
      $nombre3 = $_REQUEST["txtQId21CId17"];
      $nombre3_2 = $_REQUEST["txtQId21CId18"];
      $paterno3 = $_REQUEST["txtQId21CId19"];
      $materno3 = $_REQUEST["txtQId21CId20"];
      $lada3_1 = $_REQUEST["txtQId21CId21"];
      $telefono3_1 = $_REQUEST["txtQId21CId22"];
      $lada3_2 = $_REQUEST["txtQId21CId23"];
      $telefono3_2 = $_REQUEST["txtQId21CId24"];

      if ($nombre1 != "" && $paterno1 != "" && $lada1_1 != "" && $telefono1_1 != "") {
      set_guarda_referdido($s_usr_id, $id_solicitud, $id_producto, $tipo_registro1, $nombre1, $nombre1_2, $paterno1, $materno1, $lada1_1, $telefono1_1, $lada1_2, $telefono1_2, $tipo_registro2, $nombre2, $nombre2_2, $paterno2, $materno2, $lada2_1, $telefono2_1, $lada2_2, $telefono2_2, $tipo_registro3, $nombre3, $nombre3_2, $paterno3, $materno3, $lada3_1, $telefono3_1, $lada3_2, $telefono3_2, $db);
      set_traking(get_session_varname("s_usr_id"), 'GENERO UN REGISTRO REFERIDO DE LA SOLICITUD:' . $id_solicitud, get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
      }
      } else */ //{
    set_delete_survey($id_solicitud, $id_producto, 1, $db);

    $preguntas_ = get_preguntas($id_producto, $id_solicitud, 1, 0, $db);

    if (count($preguntas_->_array) > 0) {
        for ($indice_ = 0; $indice_ < count($preguntas_->_array); $indice_++) {
            $respuestas_ = get_respuestas($id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], 1, $id_solicitud, 1, 0, $db);
            if (count($respuestas_->_array) > 0) {
                for ($indice_resp_ = 0; $indice_resp_ < count($respuestas_->_array); $indice_resp_++) {
                    if ($respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 5 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 6 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 8 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 9) {
                        $respuesta_solicitud = $_REQUEST["txtQId" . $id_producto . $preguntas_->_array[$indice_]['QUESTIONID'] . "CId" . $respuestas_->_array[$indice_resp_]['CHOICEID']];
                        if (strlen($respuesta_solicitud) > 0) {
                            set_insert_survey($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], date("Y/n/j"), 1, 1, $db);
                            set_update_results($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], 1, $respuesta_solicitud, $db);
                        }
                    }
                }
            }
        }
    }
    set_datos_solicitud_exitosa_s($id_registro, $id_producto, $id_solicitud, $db);

    //set_valida_solicitud($id_solicitud, $id_producto, 2, 0, 1, $db);
    set_traking(get_session_varname("s_usr_id"), 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);

    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(5);
    
} elseif (isset($action) && $action == 15) { # ACCION DE ABANDONO REGISTRO OUT CUANDO ESTABA EN LA SOLICITUD
    if (isset($id_solicitud) && $id_solicitud != 0) {
        $id_solicitud = get_session_varname('id_solicitud');
    } else {
        $id_solicitud = $_REQUEST['solicitud'];
    }
    $user = get_session_varname("s_usr_id");
    $etapa = $_REQUEST['etapa'];

    if ($id_solicitud != 0) {
        $cal_reg = 1001;

        $rs = set_califica_registros($id_solicitud, $cal_reg, $etapa, $db);
        set_traking($user, 'ABANDONO REGISTRO OUT SOLICITUD', get_session_varname("s_usr_maquina"), $id_solicitud, $cal_reg, $db);
        $header = "modules.php?mod=agentes&op=index&sol=" . base64_encode($id_solicitud);
    } else {
        $header = "modules.php?mod=agentes&op=error&e=8"; # NO SE CALIFICO EL NUMERO DE TELEFONO
    }
} elseif (isset($action) && $action == 16) { ### Califica una llamada  del cliente.
    $user = get_session_varname("s_usr_id");
    $id_solicitud = get_session_varname("id_registro");
    $calificacion = $_REQUEST["motivo_llamada"];
    $califica = set_califica_llamada($user, $id_solicitud, $calificacion, $db);

    if ($califica == 1) {
        //unset_session_varname("calificar");
        unset_session_varname("id_registro");
        $header = "modules.php?mod=agentes&op=nueva_llamada";
    } else {
        $header = "modules.php?mod=agentes&op=calificar_llamada";
    }
} elseif (isset($action) && $action == 17) { ### BUSCA LA SUBCALIFICACION PARA LA CALIFICACION SELECCIONADA
    $calif_ = $_REQUEST['calif'];
    $id_solicitud = $_REQUEST['id_solicitud'];
    $id_etapa = $_REQUEST['id_etapa'];

    $sub_calif = get_subcalifiacion($calif_, $id_etapa, $id_solicitud, 'TEL_CALIFICACION_IN', $db);

    if ($sub_calif == 1) {
        echo '<b>2. Sub. Calificaci&oacute;n del Registro:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
              <select name="subcalificacion" style="width:160px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <option value="0">Respuesta:</option>';
        $sub_catalogos_in = get_subcalificacion_m('TEL_SUBCALIFICACION_IN', $calif_, $id_etapa, $id_solicitud, $db);
        while (!$sub_catalogos_in->EOF) {
            echo '<option value="' . $sub_catalogos_in->fields["VALOR"] . '" ' . ($sub_catalogos_in->fields["VALOR"] == 0 ? " selected" : "") . '>' . $sub_catalogos_in->fields["ETIQUETA"] . '</option>';
            $sub_catalogos_in->MoveNext();
        }
        echo '</select>';
    }
    die();
} elseif (isset($action) && $action == 18) { ##### ACCION PARA ABANDONAR (V2)
	//PASO 1: a partir de aqu� califica
    unset_session_varname("calificados");
    unset_session_varname("url_contacto");
    
    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_usr_id = get_session_varname('s_usr_id');
    $contador = $_REQUEST['cont'];
    $contacto_efectivo = 0;

    if ($contador == 1) {
        $telefono = $_REQUEST['tel_1'];
        $cal_tel = $_REQUEST['tel_01'];
        $u_telefono = $datos_persona[0]['U_TELEFONO'];
        if ($_REQUEST['tel_01'] == 1010) {
            $contacto_efectivo += 1;
            set_session_varname("s_telefono", $datos_persona[0]['CLAVELADA'] . $datos_persona[0]['TELEFONO']);
            set_session_varname("s_tel_contacto", $datos_persona[0]['U_TELEFONO']);
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
        } else {
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
            set_estatus_registro($id_registro, $s_usr_id, $u_telefono, $cal_tel, 1, '', 1, 0, 'O', $db);				
        }
    } else {

        for ($s = 1, $t = 0; $s <= $contador; $s++, $t++) {
            if ($_REQUEST['tel_0' . $s] == 1010) {
                $_REQUEST['tel_0' . $s] . " if";
                $contacto_efectivo += 1;
                set_session_varname('CE', $t);
                set_session_varname("s_telefono", $datos_persona[$t]['CLAVELADA'] . $datos_persona[$t]['TELEFONO']);
                set_session_varname("s_tel_contacto", $datos_persona[$t]['U_TELEFONO']);
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
            } else if ($_REQUEST['tel_0' . $s] > 0) {
                $cal_tel = $_REQUEST['tel_0' . $s];
                echo $_REQUEST['tel_0' . $s] . " else if";
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
                set_estatus_registro($id_registro, $s_usr_id, $datos_persona[$t]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);				
            }
        }
    }
    //die();
    if ($contacto_efectivo >= 1) {
        set_session_varname("id_producto", $_REQUEST['producto_']);
        $header = "modules.php?mod=agentes&op=cuestionario";
    } else {
        //set_estatus_registro($id_registro, $s_usr_id, $datos_persona[0]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);
        set_traking(get_session_varname("s_usr_id"), 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    }


	
	//PASO 2: a partir de aqu� abandona (ya calificado)
    set_session_varname("solicitud_previa", $id_solicitud);

    set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("agenda");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    if ($isPredictivo == 1) {
        $url_logout_pred = "http://172.20.1.10/click2dial/hsbc/softemployeelogout.php?employeeid=" . $s_usr_id;
        
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION    
} else if (isset($action) && $action == 19) { ### CREA UN REGISTRO EN BASE A PARTIR DE LA LLAMADA

    $id_solicitud = $_REQUEST['id_solicitud'];
    set_session_varname("id_solicitud", $id_solicitud);

    ##Guarda la solicitud en la tabla de td_registros
    $id_registro = get_session_varname("id_registro");
    set_guardasolicitud_registros($id_registro, $id_solicitud, $db);

    ##Reserva la solicitud al agente que tenemos
    $id_usr_super = get_session_varname("s_usr_super");
    $id_usuario = get_session_varname("s_usr_id");
    $u_registro = set_reservasolicitud($id_solicitud, $id_usuario, $id_usr_super, $db);
    set_session_varname("u_registro", $u_registro);

    $header = "modules.php?mod=agentes&op=cuestionarioinbound";

} elseif (isset($action) && $action == 20) { ##### REALIZA EL BLOQUEO DE SOLICITUD PARA VALIDACION
    $id_solicitud = get_session_varname('id_solicitud');
    set_valida_solicitud($id_solicitud, 1, 2, 0, 1, $db);
    set_traking(get_session_varname("s_usr_id"), 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");

    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
} elseif (isset($action) && $action == 21) { ##### VALIDA QUE LA SOLICITUD ESTE CAPTURADA
    $id_registro = get_session_varname('id_registro');
    $count_valida = set_valida_solicitud_capturada($id_registro, $db);
    die($count_valida);
} elseif (isset($action) && $action == 22) { ### VALIDA QUE LA SOLICITUD ESTE CAPTURADA
    $id_solicitud = $_REQUEST["u_persona"];
    set_validando_estado($id_solicitud, $db);
    unset_session_varname("id_solicitud");
    unset_session_varname("u_registro");
    unset_session_varname("id_registro");
    $header = "modules.php?mod=agentes&op=nueva_llamada";
} elseif (isset($action) && $action == 23) { ### GENERA EL CAMPO DE RFC
        $id_solicitud = get_session_varname('id_solicitud');
        $id_producto = get_session_varname('id_producto');
        $num_reconocedor = (($id_producto != 1 && $id_producto != 3) ? $_REQUEST['num_reconocedor'] : '');
        $apellidoPaterno = $_REQUEST['paterno'];
        $apellidoMaterno = $_REQUEST['materno'];
        $nombre = $_REQUEST['nombre'];
        $fechaNacimiento = $_REQUEST['fecha_nac'];

        ini_set("soap.wsdl_cache_enabled", "0");
        require_once("includes/lib/nusoap.php");
//        $client = new soapclient("http://172.20.1.70/rfc/server.php?wsdl");
        $client = new soapclient("http://". $_SERVER['SERVER_ADDR'] ."/rfc/server.php?wsdl");
        $rfc = $client->CalcularRFC($nombre, $apellidoPaterno, $apellidoMaterno, $fechaNacimiento);

        $rfc_valido = get_valida_rfc($id_solicitud, $id_producto, $num_reconocedor, 1, $rfc, 0, $db);

        if ($rfc_valido != 'X') {
            //�Muy buena soluci�n, en lugar del SPLIT!
            $sol_cat = get_datos_valida_rfc($rfc_valido, $db);
            if (trim($sol_cat->fields['PRONCESAR']) == 1){
                echo "000-001" . $rfc . "|<font color='red'>&iexcl;Error!<br>El RFC: " . $rfc . " ya existe en base de datos</font>";
                echo "<br>Solicitud : <strong>" . $sol_cat->fields['CUSTOMERID'] . "</strong>";
                echo "<br>Fecha de Venta : <strong>" . $sol_cat->fields['FECHAAUTENTICACION'] . "</strong>";
                echo "<br>Status : <strong>" . $sol_cat->fields['RESULTADO'] . "</strong>";
                echo "<br>Folio LUCI : <strong>" . $sol_cat->fields['CLAVEAUTENTICACION'] . "</strong>";
                echo "<br>Campa&ntilde;a : <strong>" . $sol_cat->fields['CAT_VNT'] . "</strong>";
            }else{
                echo "000-000" . $rfc . "|<font color='red'>&iexcl;Error!<br>El RFC: " . $rfc . " ya existe en base de datos</font>";
                echo "<br>Solicitud : <strong>" . $sol_cat->fields['CUSTOMERID'] . "</strong>";
                echo "<br>Fecha de Venta : <strong>" . $sol_cat->fields['FECHAAUTENTICACION'] . "</strong>";
                echo "<br>Status : <strong>" . $sol_cat->fields['RESULTADO'] . "</strong>";
                echo "<br>Folio LUCI : <strong>" . $sol_cat->fields['CLAVEAUTENTICACION'] . "</strong>";
                echo "<br>Campa&ntilde;a : <strong>" . $sol_cat->fields['CAT_VNT'] . "</strong>";
            }        
        
        } else {
            echo $rfc;
        }
    die();
} elseif (isset($action) && $action == 24) { ### GENERA EL CAMPO DE ESTADO
    $cp = $_REQUEST['cp'];
    $valor_ = "";
    $id = $_REQUEST['id'];
    $datos_ = get_datos_query_CP("hsbc.xsp_getdelEstado3_ws", $cp, $id, $db);

    $valor_ .= "hsbc.xsp_getdelEstado3_ws". "-" .$cp. "-" .$id;

    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }
    
    if (count($datos_->_array) > 0) {

        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $datos_ ->fields['COBERTURA'];
    echo $valor_;
    die();
} elseif (isset($action) && $action == 25) { ### GENERA EL CAMPO DE MUNICIPIO
    $cp = $_REQUEST['cp'];
    $id = $_REQUEST['id'];
    $valor_ = "";

    $datos_ = get_datos_query_CP("hsbc.XSP_GETDELMUNICIPIOCLIENTE3_WS", $cp, $id, $db);

    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }

    if (count($datos_->_array) > 0) {
        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $valor_;
    die();
} elseif (isset($action) && $action == 26) { ### GENERA EL CAMPO DE COLONIA
    $cp = $_REQUEST['cp'];
    $id = $_REQUEST['id'];
    $valor_ = "";

    $datos_ = get_datos_query_CP("hsbc.xsp_getColonia3_ws", $cp, $id, $db);

    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }
    if (count($datos_->_array) > 0) {
        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $valor_;
    die();
} elseif (isset($action) && $action == 27) {
	unset_session_varname("calificados");


    $blnContinuarPredictivo = true;
    //$usr_id = get_session_varname("s_usr_id");
    $name = get_session_varname('s_usr_nombre');
    //$nomina = get_session_varname('s_usr_nomina'); //
    //Variable para saber a que predictivo se dirije para tomar registro.
    $tipo_base = get_session_varname('s_usr_tipo_base'); 
    $s_usr_cc = get_session_varname('s_usr_cc');     
    
    $extension = get_session_varname('extension');    
            
    unset_session_varname("agenda");
    //Verifica si tiene registros agendados
    $data = get_registros_agendado($usr_id, $db);
    $agendas = array();

    for ($s = 0; $s < count($data->_array); $s++) {
        $agenda = array();
        $agenda['REGISTRO'] = $data->_array[$s]['REGISTRO'];
        $agenda['PERSONA'] = $data->_array[$s]['PERSONA'];
        $agenda['HORA'] = $data->_array[$s]['HORA'];
        $agenda['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
        $agenda['DATE_'] = $data->_array[$s]['DATE_'];
        $agenda['FECHA'] = $data->_array[$s]['FECHA'];
        $agenda['COMENTARIO'] = $data->_array[$s]['COMENTARIO'];
        $agendas[$s] = $agenda;
    }

    set_session_varname("agenda", $agendas);

    $datos_cliente = get_session_varname("agenda");
    $agendados = count($datos_cliente[0]['U_PERSONA']);

    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    if ($agendados != 0) {
        $header = "modules.php?mod=agentes&op=error&e=7&customerid=" . $datos_cliente[0]['U_PERSONA'] . "&hora=" . $datos_cliente[0]['HORA'] . "&fecha=" . $datos_cliente[0]['FECHA'] . "&u_registro=" . $datos_cliente[0]['REGISTRO'] . "&com=" . urlencode($datos_cliente[0]['COMENTARIO']); # ERROR GENERICO
    } else {
        $refer = get_count_referidos(get_session_varname('s_usr_id'), 1, $db);
        //die("*" . $refer . "*");
        if ($refer != 0) {
                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_registro=" . $refer;
        } else {
            
            //No tiene llamadas agendadas obtiene un registro de predictivo
            $url_status_pred = "http://172.20.1.10/click2dial/hsbc/getemployeestatus.php?employeeid=" . $usr_id;
            $url_clear_pred = "http://172.20.1.10/click2dial/hsbc/clearmeetme.php?employeeid=" . $usr_id;
            $url_startsession_pred = "http://172.20.1.10/click2dial/hsbc/startsession.php?r1=11&employeeid=" . $usr_id . "&extension=" . $extension . "&employeename=" . urlencode($name) . "&nomina=" . $nomina."&base_tipo=".$tipo_base."&cc=".$s_usr_cc."&empresa=".$empresa;
            
            while ($blnContinuarPredictivo) {
                
                $handler_status = curl_init();

                curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
                curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

                $status_pred = curl_exec($handler_status);
                
                //Verifica que el usuario este activo en predictivo
                if ($status_pred == 1) {
                    //Sesion de predictivo iniciada
                    
                    //Limpia al agente de predictivo
                    $handler_clear = curl_init($url_clear_pred);
                    $clear_pred = curl_exec($handler_clear);
                    curl_close($handler_clear);

                    //Se inicializa el registro
                    $u_registro = 0;
                    
                    //Se inicializa la tabla de pre_avail...
                    set_preavail($usr_id, "0", $db);

                    //Verifica que obtenga un registro precargado...
                    $u_registro = get_preavail($usr_id, $db);

                    //Ciclo para obtener registro
                    while ($u_registro == 0) {
                        //usleep(1000000);
                        usleep(500000);
                        $u_registro = get_preavail($usr_id, $db);

                        //$status_pred = file_get_contents($url_status_pred);
                        $status_pred = curl_exec($handler_status);

                        if ($status_pred === false) {
                            $status_pred = 1;
                        }
                        if ($status_pred == 0 && $u_registro == 0) {
                            $header = "modules.php?mod=agentes&op=error&e=8"; # ERROR GENERICO
                            $blnContinuarPredictivo = false;
                            break;
                        }
                    }

                    if ($status_pred != 0 || $u_registro != 0) {
                        if ($u_registro != 0 || $u_registro != -1) {
                            $telefono = get_PreAvail_Telefono($usr_id, $db);
                            $telefono = substr($telefono, 2, 10);

                            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(29) . "&u_registro=" . $u_registro . "&tel=" . $telefono;
                        }
                    }
                    $blnContinuarPredictivo = false;
                } else {
                    //Sesion de predictivo desocupada
                    //Inicia sesion de predictivo
                    $handler_start = curl_init($url_startsession_pred);
                        
                    curl_exec($handler_start);
                    curl_close($handler_start);

                    //Verifica si se logueo en predictivo
                    $status_pred = curl_exec($handler_status);
                    

                    if ($status_pred == 0) {
                        //Inicia preavail con -1
                        set_preavail($usr_id, "-1", $db);                            
                        $blnContinuarPredictivo = false;
                    } else {
                        $blnContinuarPredictivo = true;
                    }
                }
                curl_close($handler_status);
            }
        }        
    }
    //Salio de obtener registro predictivo
} elseif (isset($action) && $action == 28) { ##### MUESTRA EN PANTALLA EL REGISTRO SELECCIONADO DE LA BUSQUEDA
    if (get_session_varname('id_solicitud') != null) {
        set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
        set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");
    }

    $u_persona = $_REQUEST['u_persona'];
    $u_registro = $_REQUEST['u_registro'];
    $telefono = $_REQUEST['telefono'];
    //$usr_id = get_session_varname("s_usr_id");
    $grabacion = $_REQUEST['grabacion'];

    $data = get_registro_especifico_pred($u_registro, $telefono, $usr_id, '0', '0', $grabacion, $db);

    $id_solicitud = $data->fields['U_PERSONA'];
    $id_registro = $u_registro;

    $telefonos_disponibles = count($data->_array);
    $customers = array();

    for ($s = 0; $s < count($data->_array); $s++) {
        $customer = array();
        $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
        $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
        $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
        $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
        $customer['RFC'] = $data->_array[$s]['RFC'];
        $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
        $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO'];
        $customer['PAIS'] = $data->_array[$s]['PAIS'];
        $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
        $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
        $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'];
        $customer['LOCALIZACIONRT'] = $data->_array[$s]['LOCALIZACIONRT'];
        $customer['ACTIVO'] = $data->_array[$s]['ACTIVO'];
        $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
        $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
        $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
        $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
        $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
        $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
        $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
        $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
        $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'];
        $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
        $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];		
        $customer['COBERTURA'] = $data->_array[$s]['COBERTURA'];	
        $customer['BASE'] = $data->_array[$s]['BASE'];	
        $customers[$s] = $customer;
    }

    set_session_varname("datos_persona", $customers);
    if (isset($id_solicitud) && $id_solicitud > 0) {
        set_session_varname("id_solicitud", $id_solicitud);
        set_session_varname("id_registro", $id_registro);
        $header = "modules.php?mod=agentes&op=index&t_reg=1";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=62"; # ERROR GENERICO
    }
} elseif (isset($action) && $action == 29) { ##### OBTIENE EL REGISTRO DE PREAVAIL
    $u_registro = $_REQUEST['u_registro'];
    $telefono_pred = $_REQUEST['tel'];
    //$usr_id = get_session_varname("s_usr_id");
    $grabacion = get_PreAvail_Grabacion($usr_id, $db);
    set_session_varname("grabacion", $grabacion);

    if ($u_registro != 0 && $u_registro != "-1") {
        //trae registro especifico que obtuvo de predictivo
        //$rstelefono = get_PreAvail_Telefono($usr_id, $db);
        //$telefono_pred = $rstelefono->fields['TELEFONO'];

        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(28) . "&u_registro=" . $u_registro . "&telefono=" . $telefono_pred."&grabacion=".$grabacion; 
    } else {
        $header = "modules.php?mod=agentes&op=error&e=61"; # ERROR GENERICO
    }
} elseif (isset($action) && $action == 30) { ##### VALIDA EL ACCESO A LA BUSQUEDA DE DATOS
    //$usr_id = get_session_varname("s_usr_id");
    $function = 15000;
    $languaje = 1;

    $rs = get_valida_acceso($usr_id, $function, $languaje, $db);
    $acceso = count($rs->fields);

    if ($acceso != 0) {
        $header = "modules.php?mod=agentes&op=busqueda_datos";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=3"; # ERROR CUANDO NO TIENE PERMITIDO REALIZAR BUSQUEDAS
    }
} elseif (isset($action) && $action == 31) { ##### Busqueda de solicitudes (Mantenimiento)
    $customerid = $_REQUEST['txt_solicitud'];
    $surveyid = $_REQUEST['txt_producto'];
    $header = "modules.php?mod=agentes&op=mtto_solicitud&customerid=$customerid&surveyid=$surveyid";
} elseif (isset($action) && $action == 32) { ##### Busqueda de empresas
    $header = "modules.php?mod=agentes&op=busqueda_empresas";
} elseif (isset($action) && $action == 33) { ##### Busqueda por CP
    $act2 = $_REQUEST['act2'];
    if (isset($act2) && $act2 == 1) {//se utiliza en busqueda de empresas
        $cp = $_POST['cp'];
        $edo = $_POST['edo'];
        $mun = $_POST['mun'];
        $cdd = trim(strtoupper($_POST['cdd']));
        $col = strtoupper($_POST['col']);

        try {
            $query = "BEGIN SPS_GETBUSQUEDA_CP(:cp,:col,:edo,:mun,:cdd,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $cp, 'cp');
            $db->InParameter($stmt, $col, 'col');
            $db->InParameter($stmt, $edo, 'edo');
            $db->InParameter($stmt, $mun, 'mun');
            $db->InParameter($stmt, $cdd, 'cdd');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }
        if (!$rs->EOF) {
            ?>
            <table class="cp">
                <tr class="cp">
                    <th class="cp">
                        <label for="edo">Estado</label>
                    </th>
                    <th class="cp">
                        <label for="cdd">Ciudad</label>
                    </th>
                    <th class="cp">
                        <label for="mun">Municipio</label>
                    </th>
                    <th class="cp">
                        <label for="col">Colonia</label>
                    </th>
                    <th class="cp">
                        <label for="cp">CP</label>
                    </th>
                </tr>
                <?php while (!$rs->EOF) { ?>
                    <tr> <?php
                        $ie = $rs->fieldCount() - 1;
                        for ($i = 0; $i <= $ie; $i++) {
                            ?>

                            <td class="cp">
                                <?php echo $reg = $rs->fields[$i]; ?>
                            </td>

                            <?php
                        }
                        $rs->MoveNext();
                        ?></tr> <?php
                }
                ?>
            </table><?php
        } else {
            echo "<label for='cp'>CP no encontrado</label> ";
        }
    } elseif (isset($act2) && $act2 == 2) {// se utuliza en busqueda de CP
        echo $_POST['edo'];
        try {
            $query = "BEGIN SPS_GETMUNICIPIO(:edo,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $_POST['edo'], 'edo');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }
        //echo '<select id="mun2">';
        echo "<option value=''>Seccione uno..</option>";
        while (!$rs->EOF) {
            $ie = $rs->fieldCount() - 1;
            //$ii=0;
            for ($i = 0; $i <= $ie; $i++) {
                echo "<option value='" . $rs->fields[$i] . "'>" . $rs->fields[$i] . "</option>";
                //$ii++;
            }
            $rs->MoveNext();
        }
    } elseif (isset($act2) && $act2 == 3) {// se utuliza en busqueda de CP
        try {
            $query = "BEGIN SPS_GETCIUDAD(:edo,:mun,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $_POST['edo'], 'edo');
            $db->InParameter($stmt, $_POST['mun'], 'mun');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }

        while (!$rs->EOF) {
            $ie = $rs->fieldCount() - 1;
            for ($i = 0; $i <= $ie; $i++) {
                echo $cdd = $rs->fields[$i];
            }
            $rs->MoveNext();
        }
    }
    die();
    exit();
} elseif (isset($action) && $action == 34) { ##### Liberaci�n de registros
    $id_solicitud = $_REQUEST['solicitud'];
    $elapsed = -1;
    $camp = 1;
    try {
        $id_registro = get_registro_campaña($id_solicitud, $db);
        set_libera_solicitud($id_registro, $elapsed, $camp, $db);
        echo "Registro $id_solicitud ($id_registro) liberado.";
    } catch (Exception $e) {
        echo "<pre>{$e->getTrace()}</pre>";
    }
    die();
    exit();
} elseif (isset($action) && $action == 35) { ##### Actualiza los datos    
    $nombre_completo = $_GET['nombre'] . ' ' . $_GET['nombre2'];
    $apaterno = $_GET['apaterno'];
    $amaterno = $_GET['amaterno'];
    $customerid = $_GET['solicitud'];
    $agente = get_session_varname("s_usr_id");
    set_actualizarnombre($customerid, $nombre_completo, $apaterno, $amaterno, $db);
    $registros = set_busca_cliente($customerid, $nombre, $paterno, $materno, $agente, $db);

    $header = "modules.php?mod=agentes&op=process_data&act=Mw==&u_persona=" . $customerid . "&u_registro=" . $registros->fields["REGISTRO"];
}/* elseif (isset ($action) && $action == 36) { ### Finaliza la Venta en caso de Conver
  unset_session_varname("datos_persona");
  unset_session_varname("id_solicitud");
  unset_session_varname("id_registro");
  unset_session_varname("id_producto");

  $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
  } */ elseif (isset($action) && $action == 37) { ### Finaliza la Venta en caso de Conver
    if(get_session_varname('id_registro') == ''){
        set_traking(get_session_varname("s_usr_id"), 'PRESIONO BOTON INICIO - SIN REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    }else {
        set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
        set_traking(get_session_varname("s_usr_id"), 'PRESIONO BOTON INICIO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    }
      
      
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");

    $header = "index2.php";
} elseif (isset($action) && $action == 38) { ### 
    $nomina = $_REQUEST['nomina'];
    $u_user = $_REQUEST['u_user'];

    //$indicadores = getindicadores(554472,4431,$db);
    $indicadores = getindicadores($nomina, $u_user, $db);
    ?>
    <tr class="indicadores">
            <th colspan="12" class="indicadores">Indicadores</th>
        </tr>
        <tr class="indicadores">
            <th colspan="2" class="indicadores">Hoy</th>
            <th colspan="8" class="indicadores">Acumulado 1 - 15 / 16 - 31 Ultima Act. del ScoreCard : <?php echo $indicadores->_array[0]['FECHA']; ?></th>
        </tr>
        <tr class="indicadores" style="background: #006666;">
            <td class="indicadores">Au</td>
            <td class="indicadores">Ap</td>
            <!--td class="indicadores">Ocupaci&oacute;n</td-->

            <td class="indicadores">Cumplimiento</td>
            <td class="indicadores">Comisiones</td>
            <td class="indicadores">Ocupaci&oacute;n</td>

            <td class="indicadores">Calidad</td>
            <td class="indicadores">Ap (vta en fr&iacute;o)</td>
            <td class="indicadores">Ap (vta en fr&iacute;1o) Auditadas exitosamente</td>
            <td class="indicadores">Au</td>
            <td class="indicadores">Ap</td>
        </tr>
        <tr>
            <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['AU_COLOR']; ?>;" >
                <?php echo $indicadores->_array[0]['AU']; ?>
            </td>
            <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['AP_COLOR']; ?>;" >
                <?php echo $indicadores->_array[0]['AP']; ?>
            </td>
            <!--td class="indicadores">
            </td-->

            <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['CUM_COLOR']; ?>;" >
                <?php echo substr($indicadores->_array[0]['CUMPLIMIENTO'] * 100, 0, 5) . " %"; ?>
            </td>
            <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['COM_COLOR']; ?>;" >
                <?php echo $indicadores->_array[0]['COMICIONES']; ?>
            </td>
            <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['OCU_COLOR']; ?>;" >
                <?php echo substr(($indicadores->_array[0]['OCUPACION']) * 100, 0, 5) . " %"; ?>
            </td>

            <td class="indicadores"><?php echo $indicadores->_array[0]['CALIDAD']; ?></td>
            <td class="indicadores"><?php echo $indicadores->_array[0]['AP_FRIO']; ?></td>
            <td class="indicadores"><?php echo $indicadores->_array[0]['VNTS_EXITOSAMENTE']; ?></td>
            <td class="indicadores"><?php echo $indicadores->_array[0]['AU_Q']; ?></td>
            <td class="indicadores"><?php echo $indicadores->_array[0]['AP_Q']; ?></td>
        </tr>    
    <?php
    die();
    exit();
} elseif (isset($action) && $action == 40) { //Obtener lista de llamadas al 01800 del usuario
    $u_user = $_REQUEST['u_user'];
    $rs800 = get_800($u_user, $db);
    if (!$rs800->EOF) {
        ?>
        <table class="indicadores">
            <tr class="indicadores">
                <th colspan="8" class="indicadores">Llamadas 800</th>
            </tr>
            <tr class="indicadores" style="background: #006666;">
                <td>Reporte</td>
                <td>Registro</td>
                <td>Cliente</td>
                <td>Tel&eacute;fono</td>
                <td>Comentario</td>
                <td>Motivo Llamada</td>
                <td>Fecha</td>
                <td>Reportado a</td>
            </tr>
            <?php
            while (!$rs800->EOF) {
                ?>
                <tr class="indicadores">
                    <td><?php echo $rs800->fields['Reporte'] ?></td>
                    <td><?php echo $rs800->fields['Registro'] ?></td>
                    <td><?php echo $rs800->fields['Cliente'] ?></td>
                    <td><?php echo $rs800->fields['Tel�fono'] ?></td>
                    <td><?php echo $rs800->fields['Comentario'] ?></td>
                    <td><?php echo $rs800->fields['Motivo Llamada'] ?></td>
                    <td><?php echo $rs800->fields['Fecha'] ?></td>
                    <td><?php echo $rs800->fields['Reportado a'] ?></td>
                </tr>
                <?php
                $rs800->MoveNext();
            }
            ?>
        </table>
        <?php
    } else {
        echo "No existen llamadas";
    }
    die();
    exit();
}elseif (isset($action) && $action == 41) { //Obtener lista de llamadas al 01800 del usuario
    
    //print_r($_REQUEST);
    
    $dd = set_verifica_tel($_REQUEST['numero'],$db);
    
    echo $dd;
    die();
    exit();
}elseif (isset($action) && $action == 42) { //Enviar la subcalificaci�n
    if($_REQUEST['origen'] == 1){
        set_subcalificacion_registro($_REQUEST['referente'],$_REQUEST['calificacion'],$_REQUEST['telefono'],$db);
    }

    set_session_varname("calificados", get_session_varname("calificados") . $_REQUEST['calificado']);
    die();
    exit();	
} elseif (isset($action) && $action == 43) { ### Finaliza la Venta en caso de Converse, NYLIFE o Santander
    set_valida_solicitud(get_session_varname("id_solicitud"), get_session_varname("id_producto"), 2, 0, 1, $db);    
    $id_producto=get_session_varname("id_producto");
    if ($id_producto == 3) {
        $score = array(1, get_session_varname("id_solicitud"));
        set_session_varname("sc", $score);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("aprocesado");
    unset_session_varname("CE");
    if ($isPredictivo == 1) {
        
        $url_logout_pred = "http://172.20.1.10/click2dial/hsbc/softemployeelogout.php?employeeid=" . $s_usr_id;
        
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);

        $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
        //$header = "modules.php?mod=agentes&op=index&aprocesado=1";
    }	
} elseif (isset($action) && $action == 406) { ### Obtener lista de agendados para el usuario
    $tipo_agenda = $_POST['tipo_agenda'];
    $usr_id = get_session_varname("s_usr_id");
    $id_solicitud = get_session_varname("id_solicitud");
    $datos_cliente = get_session_varname("datos_persona");
    $cliente = $datos_cliente[0]['NOMBRE'] . '&nbsp;' . $datos_cliente[0]['APATERNO'] . '&nbsp;' . $datos_cliente[0]['AMATERNO'];

    $fecha = $_POST['fecha'];
    $rs = get_agenda_usuario_dia($usr_id, $fecha, $db);
    if ($tipo_agenda == 0) {
        if (!$rs->EOF) {
            echo "<table border='1' width='98%' class='agenda'>\r\n";
            echo "<caption>$fecha</caption>\r\n";
            echo "<tr class='agenda'>\r\n";
            echo "<th width='16%' class='agenda'>Hora</th>";
            echo "<th width='45%' class='agenda'>Nombre</th>";
            echo "<th width='45%' class='agenda'>Comentario</th>";
            echo "</tr>\r\n";
            while (!$rs->EOF) {
                echo "<tr class='agenda'>\r\n";
                if ($rs->fields['MEDIAHORA'] != -1) {
                    echo "<td class='agenda'><a href=\"#\" onclick=\"guardaAgenda({$rs->fields['MEDIAHORA']}, '{$rs->fields['HORAREAL']}', '$cliente', $id_solicitud,$isPredictivo);\">{$rs->fields['HORAREAL2']}</a></td>\r\n";
                } else {
                    echo "<td class='agenda'>{$rs->fields['HORAREAL2']}</td>\r\n";
                }
                echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                echo "<td class='agenda'>{$rs->fields['COMENTARIO']}</td>\r\n";
                echo "</tr>\r\n";
                $rs->MoveNext();
            }
            echo "</table>";
        }
    } elseif ($tipo_agenda == 1) {
        if (!$rs->EOF) {
            echo "<table border='1' width='98%' class='agenda'>\r\n";
            echo "<caption>$fecha</caption>\r\n";
            echo "<tr class='agenda'>\r\n";
            echo "<th width='12%' class='agenda'>Hora</th>";
            echo "<th width='45%' class='agenda'>Nombre</th>";
            echo "<th width='45%' class='agenda'>Comentario</th>";
            echo "<th width='45%' class='agenda'>Accion</th>";
            echo "</tr>\r\n";
            while (!$rs->EOF) {
                echo "<tr class='agenda'>\r\n";
                if ($rs->fields['MEDIAHORA'] != -1) {
                    echo "<td class='agenda'><!--a href=\"#\" onclick=\"guardaAgenda({$rs->fields['MEDIAHORA']}, '{$rs->fields['HORAREAL']}', '$cliente', $id_solicitud,$isPredictivo);\"-->{$rs->fields['HORAREAL2']}</a></td>\r\n";
                    echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                    echo '<td class=\'agenda\'>' . $rs->fields['COMENTARIO'] . '</td>
        <td></td>';
                } else {
                    echo "<td class='agenda'>{$rs->fields['HORAREAL2']}</td>\r\n";
                    echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                    echo '<td class=\'agenda\'>' . $rs->fields['COMENTARIO'] . '</td>';
                    //echo '<td><a href="#" onclick="Mostrar_agendado3(0, ' . $rs->fields['U_REGISTRO'] . ', ' . $rs->fields['U_REGISTRO'] . ', \'' . encripta(3) . '\')"><img src="' . $linkpath . 'includes/imgs/Comenzar.gif"></td>';
                }
                echo "</tr>\r\n";
                $rs->MoveNext();
            }
            echo "</table>";
        }
    } else {
        echo "No hay agenda para este d�a.";
    }
    $rs->Close();
    die();
}elseif (isset($action) && $action == 600) { //Bloqueo de clientes molestos
    set_bloquea_cliente_molesto(get_session_varname('id_registro'), $db);
    set_traking(get_session_varname("s_usr_id"), 'BLOQUEO REGISTRO CLIENTE MUY MOLESTO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
      
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");

    $header = "index2.php";
}elseif (isset($action) && $action == 44) { //Actualiza nombre base sin nombre (SN)
    //$usr_id = get_session_varname("s_usr_id");
    $nombre = quitarCaracteresEspeciales(strtoupper($_REQUEST['nombre']));
    $paterno = quitarCaracteresEspeciales(strtoupper($_REQUEST['paterno']));
    $materno = quitarCaracteresEspeciales(strtoupper($_REQUEST['materno']));
    //$u_persona = get_session_varname("id_solicitud");
    //$u_registro = get_session_varname("id_registro");
    $tipo = 1;

    set_actualizarnombre($u_persona, $nombre, $paterno, $materno, $db);
    set_traking($usr_id, 'ACTUALIZO NOMBRE DE CLIENTE, BASE SIN NOMBRE', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    set_traking_aviso($usr_id, 'ACTUALIZO NOMBRE DE CLIENTE, BASE SIN NOMBRE', get_session_varname("s_usr_maquina"), $u_registro, get_session_varname('tel_predictivo'), $db);
    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_persona=" . $u_persona . "&u_registro=" . $u_registro . "&tipo=" . $tipo;
    
}elseif (isset($action) && $action == 46) { //Grabaci�n de aviso de privacidad

    $url_registro = get_session_varname("url_contacto");
    $usr_id = get_session_varname("s_usr_id");
    $u_persona = get_session_varname("id_solicitud");
    $u_registro = get_session_varname("id_registro");
    $nomina = get_session_varname('s_usr_nomina');
    $t_registro = get_session_varname('t_registro');
    $tipo_marcacion = get_session_varname("s_usr_marcacion");

//    enviar_aviso_privacidad($usr_id, $nomina, $t_registro, $isPredictivo, $u_persona);
    
    if($isPredictivo == 1 && $t_registro == 1){        
        if($empresa == 'ITQ' || $empresa == 'ITS'){
            $url_aviso_privacidad = "http://172.20.1.10/click2dial/hsbc/clearmeetme-aviso.php?employeeid=" . $usr_id;
        }else {
            $url_aviso_privacidad = "http://172.20.19.11/click2dial/hsbc/clearmeetme-aviso.php?employeeid=" . $usr_id;
        }
    }else{
        if($empresa == 'ITQ' || $empresa == 'ITS'){
            $url_aviso_privacidad = "http://172.20.1.10/marcadoasistido/click2dial/hsbc/transfiere-aviso-privacidad.php?agentenomina=".$nomina."&solicitud=".$u_persona;
        }else {
            $url_aviso_privacidad = "http://172.20.19.11/click2dial/hsbc/transfiere-aviso-privacidad.php?agentenomina=".$nomina."&solicitud=".$u_persona;
        }
    }
    
    //Manda la llamada a la grabacion de aviso de privacidad
    $handler_aviso = curl_init($url_aviso_privacidad);
    $aviso_privacidad = curl_exec($handler_aviso);
    curl_close($handler_aviso);
    
    set_traking($usr_id, 'TRANSFIRIO A AVISO DE PRIVACIDAD', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    set_traking_aviso($usr_id, 'TRANSFIRIO A AVISO DE PRIVACIDAD', get_session_varname("s_usr_maquina"), $u_registro, get_session_varname('tel_predictivo'), $db);
    
    if($url_registro == 'index'){
        $header = "modules.php?mod=agentes&op=index&t_reg=1";
    }else if($url_registro == 'cuestionario'){
        $header = "modules.php?mod=agentes&op=cuestionario";
    }else if($url_registro == 'agenda'){
        $header = "modules.php?mod=agentes&op=agenda";
    }
    
}elseif (isset($action) && $action == 47) { 
    $act2 = $_POST['act2'];
    if($act2 == 1){
    $nombre = $_POST['nombre'];
    $apaterno = $_POST['ap_panterno'];
    $amaterno = $_POST['ap_materno'];
    $fecha_nac = $_POST['fec_nac'];
    $rfc = $_POST['rfc'];    
    $calle = $_POST['calle'];
    $numero = $_POST['numero'];    
    $colonia = $_POST['colonia'];
    $municipio = $_POST['municipio'];
    $estado = $_POST['edo'];
    $edo_nac = $_POST['edo_nac'];
    $cp = $_POST['cp'];
    //$usr_id = get_session_varname("s_usr_id");
    //$u_persona = get_session_varname("id_solicitud");
        echo $rsultado = get_datos_prescrining($u_persona,$nombre,$apaterno,$amaterno,$fecha_nac,$rfc,$calle,$numero,$colonia,$municipio,$estado,$cp,$edo_nac,$usr_id,$act2,$db);
    }else if($act2 == 2){
        $nombre = "";
        $apaterno = "";
        $amaterno = "";
        $fecha_nac = "";
        $rfc = "";
        $calle = "";
        $numero = "";
        $colonia = "";
        $municipio = "";
        $estado = "";
        $edo_nac = "";
        $cp = "";
        //$usr_id = get_session_varname("s_usr_id");
        //$u_persona = get_session_varname("id_solicitud");
        echo $rsultado = get_datos_prescrining($u_persona,$nombre,$apaterno,$amaterno,$fecha_nac,$rfc,$calle,$numero,$colonia,$municipio,$estado,$cp,$edo_nac,$usr_id,$act2,$db);
    }
    
    die();    
    exit();
} elseif (isset($action) && $action == 48) { //Prescrining
    //$u_persona = get_session_varname("id_solicitud");
    $u_user = get_session_varname("s_usr_id");;
    $rs800 = set_datos_prescrining($u_user,$u_persona, $db);    
    
    if($rs800->fields['STATUS'] == 'No Exitoso'){
        $color = 'red';
    }else{
        $color = 'green';
    }
    if (!$rs800->EOF) {
        ?>
        <table class="indicadores">
            <tr class="indicadores">
                <th colspan="8" class="indicadores">Prescrining</th>
            </tr>
            <tr class="indicadores" style="background: #006666;">
                <td>Solicitud</td>                
                <td>Estatus</td>
                <td>Folio luci</td>
            </tr>
            <?php
            while (!$rs800->EOF) {
                ?>
                <tr class="indicadores">
                    <td><?php echo $rs800->fields['CUSTOMERID'] ?></td>                    
                    <td style="color: <?= $color ?>; font-size: 14px; font-style: initial;"><?php echo $rs800->fields['STATUS'] ?></td>
                    <td><?php echo $rs800->fields['LUCI'] ?></td>
                </tr>
                <?php
                $rs800->MoveNext();
            }
            ?>
        </table>
        <?php
    } else {
        echo "No se ha actualizado";
    }
    die();
    exit();
}elseif (isset($action) && $action == 55) { //Guarda nombre de grabaci�n

    $solicitud = $_REQUEST['u_persona'];
    $nomina = $_REQUEST['nomina'];
    $telefono = $_REQUEST['telefono'];
    $url = $_REQUEST['url'];

    //set_session_varname("tel_predictivo", $telefono);
    $handler_clear = curl_init($url);
    $clear_pred = curl_exec($handler_clear);
    curl_close($handler_clear);

    $grabacion = set_insert_nombre_grabacion($solicitud,$nomina,$telefono, $empresa, $db);
    set_session_varname("grabacion", $grabacion);

    $t_registro = 0;
    set_session_varname("t_registro", $t_registro);
    
    die();
    exit();
}elseif (isset($action) && $action == 56) { //verifica cuantos tel ha ingresado el agente
    
    //print_r($_REQUEST);
    //$u_persona = get_session_varname("id_solicitud");
    
    $dd = set_count_tel($u_persona,$db);
    
    echo trim($dd);
    die();
    exit();
}elseif (isset($action) && $action == 57) { ### Regreso de Break
    $tipo_standby = get_session_varname("tipo_standby");

    if ($tipo_standby == 1) {
        set_traking(get_session_varname("s_usr_id"), 'REGRESO BREAK', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    } elseif ($tipo_standby == 2) {
        set_traking(get_session_varname("s_usr_id"), 'REGRESO BANIO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    } elseif ($tipo_standby == 3) {
        set_traking(get_session_varname("s_usr_id"), 'REGRESO CAPACITACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
}
    

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");

    unset_session_varname("tipo_standby");

    $header = "index2.php";
} elseif (isset($action) && $action == 58) { ### Break
    set_traking(get_session_varname("s_usr_id"), 'INICIO BREAK', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
            
    $header = "modules.php?mod=agentes&op=standby&e=1";
} elseif (isset($action) && $action == 59) { ### Ba�o
    set_traking(get_session_varname("s_usr_id"), 'INICIO BANIO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
            
    $header = "modules.php?mod=agentes&op=standby&e=2";
} elseif (isset($action) && $action == 60) { ### Capacitacion
    set_traking(get_session_varname("s_usr_id"), 'INICIO CAPACITACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
            
    $header = "modules.php?mod=agentes&op=standby&e=3";
} elseif (isset($action) && $action == 67) {
    $tipo_standby = $_REQUEST['id'];
    
    //Pone preavail en -1 para que no se considere para llamada nueva automatica
    set_preavail($usr_id, "-1", $db);
    
    set_session_varname('tipo_standby2', $tipo_standby );
    die();    
}
elseif (isset($action) && $action == 'BV') {
      $rcAV =  getagentevalidacion(311, 1, $db);
      $validadores = array();
      if (count($rcAV->_array) > 0) {
        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($rcAV->_array); $indice_datos_query_++) {
            $rows = array(
                'label' => $rcAV->_array[$indice_datos_query_]['NOMBRE'],
                'value' => $rcAV->_array[$indice_datos_query_]['NOMINA']
             );
        array_push($validadores, $rows);    
        }
      }
       echo json_encode($validadores);
    exit();
}elseif (isset($action) && $action == 'CV') {
       $s_usr_id = get_session_varname("s_usr_id");
       $solicitud =$_REQUEST['antsol'];
       $id_usr_super = get_session_varname("s_usr_super");
       toScoreAgent(311, $solicitud, $s_usr_id, $id_usr_super, $_REQUEST['validador'],$_REQUEST['comen'],$_REQUEST['puntaje'], $db);
       echo $id_usr_super."...";
    exit();
}elseif (isset($action) && $action == 'CA') {
       $s_usr_nomina = get_session_varname("s_usr_nomina");
//       $evento= getAgendas(get_session_varname('s_usr_nomina'), $db);
       echo $s_usr_nomina;
//       echo "<prev>".$evento."</prev>";
       exit();
//       for ($a = 0; count($evento) > $a; $a++) {
//            $allday = ($evento[$a]['Evento']['allday'] == "true") ? true : false;
//            $editable = ($evento[$a]['Evento']['editable'] == 1) ? true : false;
//            if ($evento[$a]['Evento']['status'] == 1 || $evento[$a]['Evento']['status'] == 0 || $evento[$a]['Evento']['status'] == "") {
//                $color = '#D95459';
//            }
//            if ($evento[$a]['Evento']['status'] == 2) {
//                $color = '#FBB03B';
//            }
//            if ($evento[$a]['Evento']['status'] == 3) {
//                $color = '#1FB5AD';
//            }
//            $diafinal = $this->compararfechas($evento[$a]['Evento']['start'],$evento[$a]['Evento']['end']);
//            $allday = ($diafinal===$evento[$a]['Evento']['end']) ? false : true;
////            if($evento[$a]['Evento']['end']==$evento[$a]['Evento']['start']){
////                $diafinal=$evento[$a]['Evento']['end'];
//////                $diafinal = date('Y-m-d', strtotime($evento[$a]['Evento']['end']. ' + 1 days'));
////                
////            }else{
////                $diafinal=$evento[$a]['Evento']['end']; 
////            }
//            $rows = array(
//                'id' => $evento[$a]['Evento']['id'],
//                'title' => $evento[$a]['Evento']['title'],
//                'start' => $evento[$a]['Evento']['start'],
//                'end' => $diafinal,
//                'allDay' => $allday,
//                'backgroundColor' => $color,
//                'editable' => $editable,
//                'eliminar' => $evento[$a]['Evento']['eliminar']                
//             );
//            array_push($events, $rows);
//            }
//        
    exit();
} elseif (isset($action) && $action == 81) { 
    
    $url_asistido = $_REQUEST['url_asistido'];
    
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );
    
    $handler_marcacion = curl_init($url_asistido);
    curl_setopt_array( $handler_marcacion, $options );
    
    curl_exec($handler_marcacion);
    
    curl_errno( $handler_marcacion );
    curl_error( $handler_marcacion );
    curl_getinfo( $handler_marcacion );
    
    curl_close($handler_marcacion);
    
    
} elseif (isset($action) && $action == 82) { 
    
    $url_asistido = $_REQUEST['url_asistido'];
    
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
    );
    
    $handler_marcacion = curl_init($url_asistido);
    curl_setopt_array( $handler_marcacion, $options );
    
    curl_exec($handler_marcacion);
    
    curl_errno( $handler_marcacion );
    curl_error( $handler_marcacion );
    curl_getinfo( $handler_marcacion );
    
    curl_close($handler_marcacion);
    
    
}

header("location: " . $header);
