<?php
// diagnostico_api.php
require_once("Config/Config.php"); // Asegúrate de cargar la configuración

echo "<h1>Diagnóstico de conexión a API</h1>";

// Test 0: Verificar constantes
echo "<h3>0. Constantes de configuración:</h3>";
echo "API_NODE_URL: " . (defined('API_NODE_URL') ? API_NODE_URL : 'No definida') . "<br>";
echo "USE_API: " . (defined('USE_API') ? (USE_API ? 'TRUE' : 'FALSE') : 'No definida') . "<br>";

// Test 1: DNS Resolution
echo "<h3>1. Resolución DNS de localhost:</h3>";
$ip = gethostbyname('localhost');
echo "localhost -> $ip<br>";

// Test 2: Puerto abierto - probar con localhost y 127.0.0.1
echo "<h3>2. Verificando puerto 4001 en localhost y 127.0.0.1:</h3>";
$hosts = ['localhost', '127.0.0.1'];
foreach ($hosts as $host) {
    $fp = @fsockopen($host, 4001, $errno, $errstr, 2);
    if ($fp) {
        echo "✅ Puerto 4001 está ABIERTO en $host<br>";
        fclose($fp);
    } else {
        echo "❌ Puerto 4001 CERRADO en $host - Error: $errstr ($errno)<br>";
    }
}

// Test 3: cURL directo a la URL definida
echo "<h3>3. Probando cURL directamente a la URL de API:</h3>";
if (!defined('API_NODE_URL')) {
    die("API_NODE_URL no está definida. Revisa Config.php");
}

$test_url = API_NODE_URL . 'Users/GetAllUsers';
echo "URL a probar: $test_url<br>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $test_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
// Deshabilitar verificación SSL para desarrollo
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
$errno = curl_errno($ch);

echo "Código HTTP: $http_code<br>";
echo "cURL Error #: $errno<br>";
echo "Error: " . ($error ?: 'Ninguno') . "<br>";
if ($response) {
    echo "Respuesta (primeros 500 chars): " . htmlspecialchars(substr($response, 0, 500)) . "...<br>";
} else {
    echo "Sin respuesta<br>";
}

curl_close($ch);

// Test 4: Probar con file_get_contents usando stream_context
echo "<h3>4. Probando con file_get_contents:</h3>";
$context = stream_context_create([
    'http' => [
        'method' => 'GET',
        'timeout' => 3
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false,
    ]
]);

$response = @file_get_contents($test_url, false, $context);
if ($response === FALSE) {
    $error = error_get_last();
    echo "Error: " . $error['message'] . "<br>";
} else {
    echo "✅ Conexión exitosa<br>";
    echo "Respuesta (primeros 300 chars): " . htmlspecialchars(substr($response, 0, 300)) . "...<br>";
}

// Test 5: Verificar si hay algún proceso escuchando en el puerto 4001
echo "<h3>5. Verificando procesos en el puerto 4001:</h3>";
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    // Windows
    exec('netstat -ano | findstr :4001', $output);
} else {
    // Linux/Unix
    exec('netstat -tulpn | grep :4001', $output);
    // Alternativa con lsof
    exec('lsof -i :4001', $output2);
}

if (!empty($output)) {
    echo "Netstat output:<br>";
    foreach ($output as $line) {
        echo htmlspecialchars($line) . "<br>";
    }
} else {
    echo "No se encontró ningún proceso en el puerto 4001 según netstat<br>";
}

if (!empty($output2)) {
    echo "Lsof output:<br>";
    foreach ($output2 as $line) {
        echo htmlspecialchars($line) . "<br>";
    }
}

// Test 6: Probar conectividad desde la línea de comandos
echo "<h3>6. Comando de verificación desde sistema:</h3>";
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    exec('curl -I http://localhost:4001/Users/GetAllUsers 2>&1', $cmd_output);
} else {
    exec('curl -I http://localhost:4001/Users/GetAllUsers 2>&1', $cmd_output);
}
echo "Salida del comando curl:<br>";
foreach ($cmd_output as $line) {
    echo htmlspecialchars($line) . "<br>";
}
?>