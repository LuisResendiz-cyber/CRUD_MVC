<?php
# @uthor Mark 
# Cuestionario File 

require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize("validacion","Validar Solicitud");

$id_solicitud = get_session_varname("id_solicitud");
$script = 1;

$registro = get_detalle_solicitud_validacion($id_solicitud, $db);
$id_etapa = $registro->fields["ID_ETAPA"];

layout_menu($db, "ShowScript_V(".$script.",".$id_solicitud.",".$id_etapa .")");
?>
	<p class="textbold">Validaci&oacute;n &gt; Solicitud </p>
	<p>&nbsp;</p>
	<form method="post" action="modules.php?mod=validacion&op=process_data&act=2" name="frm1">
	<input type="hidden" name="id_etapa" value="<?=$id_etapa?>">
    <input type="hidden" name="calificacion" value="1000">
    <table border="0" width="1000">
		<tr>
			<td width="450">
                <table border="0">
                    <tr>
                        <td colspan="2"><?=form_oblmsg()?></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td colspan="2" class="label_td" bgcolor="grey">Datos del Cliente</td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr><tr>
                        <td class="textleft"><b>Solicitud:&nbsp;</b></td>
                        <td class="label"><?=$id_solicitud?></td>
                    </tr><tr>
                        <td class="textleft"><b>* Nombre(s):&nbsp;</b></td>
                        <td class="label"><input type="text" name="nombre" id="nombre" value="<?=$registro->fields["NOMBRE"]?>" size="25"></td>
                    </tr><tr>
                        <td class="textleft"><b>* Paterno:&nbsp;</b></td>
                        <td class="label"><input type="text" name="paterno" id="paterno" value="<?=$registro->fields["PATERNO"]?>" size="25"></td>
                    </tr><tr>
                        <td class="textleft"><b>Materno:&nbsp;</b></td>
                        <td class="label"><input type="text" name="materno" id="materno" value="<?=$registro->fields["MATERNO"]?>" size="25"></td>
                    </tr><tr>
                        <td><b>* Fecha de Nacimiento: <br>(dd/mm/yyyy)</b></td>
                        <td>
                            <script language="JavaScript">
                                var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_nac','dateFormat' : 'd/m/Y'}
                                new sCalendar(SC_SET_1, '<?=$registro->fields["FECHA_NAC"]?>');
                            </script>
                        </td>
                    </tr><tr>
                        <td><b>* RFC:&nbsp;</b></td>
                        <td>
                            <input type="text" name="rfc" id="rfc" maxlength="15" value="<?=$registro->fields["RFC"]?>" readonly>
                            <a name="rfc_c" href="#" onclick="calcula_rfc()" title="Calcular RFC">
                                <img src="<?=$linkpath?>includes/imgs/calcula.jpg" border="0" width="20">
                            </a>
                            <br>
                            <div id="loading" style="display:none">Realizando peticion, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif\" border="0"></div>
                        </td>
                    </tr><tr>
                        <td class="textleft"><b>* TDC:&nbsp;</b></td>
                        <td class="label"><input type="text" name="tdc" id="tdc" value="<?=$registro->fields["TDC"]?>" size="20" maxlength="16"></td>
                    </tr><tr>
                        <td class="textleft"><b>TDC Adicional 1:&nbsp;</b></td>
                        <td class="label"><input type="text" name="tdc1" id="tdc1" value="<?=$registro->fields["ITDC1"]?>" size="20" maxlength="16"></td>
                    </tr><tr>
                        <td class="textleft"><b>TDC Adicional 2:&nbsp;</b></td>
                        <td class="label"><input type="text" name="tdc2" id="tdc2" value="<?=$registro->fields["ITDC2"]?>" size="20" maxlength="16"></td>
                    </tr><tr>
                        <td class="textleft"><b>TDC Adicional 3:&nbsp;</b></td>
                        <td class="label"><input type="text" name="tdc3" id="tdc3" value="<?=$registro->fields["ITDC3"]?>" size="20" maxlength="16"></td>
					</tr><tr>
                        <td class="textleft"><b>* Acepta el cambio de tarjeta Clasica a Oro?:&nbsp;</b></td>
                        <td class="label">
                            <select name="promociones">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                    $catalogos = get_catalogo('DESICION', $db);
                                    while(!$catalogos->EOF) {
                                        echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["IPROMO"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                        $catalogos->MoveNext();
                                    }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <input type="hidden" name="estados_cuenta" value="1">
                    <!--tr>
                        <td class="textleft"><b>* Le llegan sus Edos de Cuenta ?:&nbsp;</b></td>
                        <td class="label">
                            <select name="estados_cuenta">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                    /*$catalogos = get_catalogo('DESICION', $db);
                                    while(!$catalogos->EOF) {
                                        echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["IEDOCTA"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                        $catalogos->MoveNext();
                                    }*/
                                ?>
                            </select>
                        </td>
                    </tr--><tr>
                        <td class="textleft"><b>* Tiene Tarjetas adicionales para esta TDC ?:&nbsp;</b></td>
                        <td class="label">
                            <select name="tarjetas_adicionales">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                    $catalogos = get_catalogo('TARJETA_ADICIONAL', $db);
                                    while(!$catalogos->EOF) {
                                        echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["ITARJETA_ADI"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                        $catalogos->MoveNext();
                                    }
                                ?>
                            </select>
                        </td>
                    </tr><tr>
                        <td colspan="2" class="label_td" bgcolor="grey">Domicilio</td>
                    </tr><tr>
                        <td class="textleft"><b>* Calle:&nbsp;</b></td>
                        <td class="label"><input type="text" size="30" name="calle" id="calle" value="<?=$registro->fields["CALLE"]?>"></td>
                    </tr><tr>
                        <td class="textleft"><b>* N&uacute;mero Exteri&oacute;r:&nbsp;</b></td>
                        <td class="label"><input type="text" size="15" name="num_ext" id="num_ext" value="<?=$registro->fields["NUM_EXT"]?>"></td>
                    </tr><tr>
                        <td class="textleft"><b>N&uacute;mero Interior:&nbsp;</b></td>
                        <td class="label"><input type="text" size="15" name="num_int" id="num_int" value="<?=$registro->fields["NUM_INT"]?>"></td>
                    </tr><tr>
                        <td class="textleft"><b>* CP:&nbsp;</b></td>
                        <td class="label">
                            <input type="hidden" size="10" name="id_codigo" id="id_codigo" value="<?=$registro->fields["ID_CODIGO_CP"]?>">
                            <input type="text" size="10" name="cp" id="cp" value="<?=$registro->fields["D_CODIGO"]?>" maxlength="5" readonly>
                            &nbsp;<a name="c_p" href="#c_p" onclick="search_cp('<?=$registro->fields["D_D_CODIGO"]?>')" title="Buscar"><img src="<?=$linkpath?>includes/imgs/Buscar.gif" width="22px" border="0"></a>
                        </td>
                    </tr><tr>
                        <td class="textleft"><b>* Colonia:&nbsp;</b></td>
                        <td class="label"><input type="text" size="20" name="colonia" id="colonia" value="<?=$registro->fields["COLONIA"]?>"></td>
                    </tr><tr>
                        <td class="textleft"><b>* Municipio:&nbsp;</b></td>
                        <td class="label"><input type="text" size="20" name="municipio" id="municipio" value="<?=$registro->fields["D_MNPIO"]?>" readonly></td>
                    </tr><tr>
                        <td class="textleft"><b>* Estado:&nbsp;</b></td>
                        <td class="label"><input type="text" size="20" name="estado" id="estado" value="<?=$registro->fields["D_ESTADO"]?>" readonly></td>
                    </tr><tr>
                        <td class="textleft"><b>* Telefono 1:&nbsp;</b></td>
                        <td class="label"><input type="text" size="15" name="tel1" id="tel1" value="<?=$registro->fields["TELEFONO"]?>" maxlength="10"></td>
                    </tr><tr>
                        <td class="textleft"><b>* Tipo Tel&eacute;fono:&nbsp;</b></td>
                        <td class="label">
                            <select name="tipo_tel1">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                $catalogos = get_catalogo('TIPO_TEL', $db);
                                while(!$catalogos->EOF) {
                                    echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["TIPO_TELEFONO1"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                    $catalogos->MoveNext();
                                }
                                ?>
                            </select>
                        </td>
                    </tr><tr>
                        <td class="textleft"><b>Telefono 2:&nbsp;</b></td>
                        <td class="label"><input type="text" size="15" name="tel2" id="tel2" value="<?=$registro->fields["TELEFONO2"]?>" maxlength="10"></td>
                    </tr><tr>
                        <td class="textleft"><b>Tipo de Tel&eacute;fono:&nbsp;</b></td>
                        <td class="label">
                            <select name="tipo_tel2">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                $catalogos = get_catalogo('TIPO_TEL', $db);
                                while(!$catalogos->EOF) {
                                    echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["TIPO_TELEFONO2"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                    $catalogos->MoveNext();
                                }
                                ?>
                            </select>
                        </td>
                    </tr><tr>
                        <td class="textleft"><b>Celular:&nbsp;</b></td>
                        <td class="label"><input type="text" size="15" name="celular" id="celular"  value="<?=$registro->fields["ICELULAR"]?>" maxlength="10"></td>
                    </tr><tr>
                        <td class="textleft"><b>Correo Electronico:</b></td>
                        <td><input type="text" size="30" name="email" id="email" value="<?=$registro->fields["CEMAIL"]?>" maxlength="50"></td>
                    </tr><tr>
                        <!--td colspan="2" class="label_td" bgcolor="grey">Banco</td>
                    </tr><tr>
                        <td class="textleft"><b>* Autoriza que SANTANDER revise su historial del buro de credito?</b></td>
                        <td class="label">
                            <select name="autoriza_buro">
                                <option value="0" selected> Elige opcion</option>
                                <?
                                /*$catalogos = get_catalogo('DESICION', $db);
                                while(!$catalogos->EOF) {
                                    echo '<option value="'.$catalogos->fields["VALOR"].'" '.($catalogos->fields["VALOR"]==$registro->fields["TIPO_TELEFONO2"]?" selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
                                    $catalogos->MoveNext();
                                }*/
                                ?>
                            </select>
                        </td>
                    </tr><tr-->
                        <td class="textleft"><b>Comentarios: <br>(70 caracteres maximo)</b></td>
                        <td><textarea name="comentarios" rows="4" cols="30"><?=$registro->fields["CCOMENTARIOS"]?></textarea></td>
                    </tr><tr>
                        <td colspan="2">&nbsp;</td>
                    </tr>
                </table>
                <input type="hidden" name="autoriza_buro" value="1">
            </td>
            <td rowspan="2">
                <div id="script" align="center" style="width:550px;overflow:auto;height:790px;padding-left:4px;"></div>
            </td>
        </tr><tr>
            <td colspan="2">
                <input type="button" value="Regresar" onclick="Atras()"/>&nbsp;&nbsp;
                <input type="button" value="Procesar" onclick="valida_solicitud(<?=$id_solicitud?>, 'VAL','IN')"/>&nbsp;&nbsp;
            </td>
        </tr>
    </table>
    </form>
	
<?
layout_footer();
?>