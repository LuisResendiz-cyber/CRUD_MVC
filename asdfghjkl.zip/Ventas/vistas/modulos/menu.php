<aside class="main-sidebar">

	 <section class="sidebar">

		<ul class="sidebar-menu">

		<li class="active">

				<a href="?ruta=inicio">

					<i class="fa fa-home"></i>
					<span>Ver Enlace</span>
				</a>
		</li>
		<?php
		if($_SESSION["perfil"] == "Administrador"){
		echo '<li>
				<a href="?ruta=usuarios">
					<i class="fa fa-user"></i>
					<span>Usuarios</span>
				</a>
			</li>';

			echo '<li>
			<a href="?ruta=enlaces">
				<i class="fas fa-user-cog"></i>
				<span>Administrar Ligas</span>
			</a>
		</li>';
		}
		?>
		</ul>
	 </section>
</aside>