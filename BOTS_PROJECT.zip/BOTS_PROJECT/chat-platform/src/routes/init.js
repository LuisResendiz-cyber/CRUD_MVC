const express = require('express');
const router = express.Router();
const UsersControllers = require("../controllers/Users.controller");
const check = require('../Middleware/error.Middleware')
const appController = require('../controllers/Users.controller')

router.get("/init", UsersControllers.getUserById);
router.post('/Createuser',check.checkUser, appController.setUser)
router.post('/login', check.checkLogin, appController.login)

module.exports = router;