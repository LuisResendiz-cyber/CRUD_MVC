//var arrayTitular = ['nombrepila', 'nombreseg', 'appaterno', 'apmaterno', 'FECHA_NAC', 'RFC'];


//alert("gdgdg");



$( document ).ready(function() {
    console.log( "ready!" );
    $( '.bloque_beneficiarios' ).css( "display","revert" )
});


//var arrayTitular = ['nombrepila', 'nombreseg', 'appaterno', 'apmaterno', 'FECHA_NAC', 'RFC'];
var arrayCamps = [
    ['nombrepila', 'nombreseg', 'appaterno', 'apmaterno', 'FECHA_NAC', 'RFC'],
    ['nombre_bene1', 'nombre_bene1', 'appaterno_bene1', 'apmaterno_bene1', 'fechanacimiento_bene1', 'rfc_bene1'],
    ['nombre_bene2', 'nombre_bene2', 'appaterno_bene2', 'apmaterno_bene2', 'fechanacimiento_bene2', 'rfc_bene2'],
    ['nombre_bene3', 'nombre_bene3', 'appaterno_bene3', 'apmaterno_bene3', 'fechanacimiento_bene3', 'rfc_bene3']
];

$(function() {
    /*$(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno, #fechanacimiento', function(event) {
        event.preventDefault();
        verifica_RFC();
    });*/

    var parar = 4;
    for(var i=0; i<parar; i++){
        //console.log(arrayCamps[i]);
        for(var j=0; j<(arrayCamps[i].length-1); j++){
            if(i>0){
                var param_extra = 1;
            } else{
                var param_extra = null;
            }
            
            //$(document).on('change', '#'+arrayCamps[i][j], function(event){
            //if($('#'+arrayCamps[i][j]).length > 0){
                $('#'+arrayCamps[i][j]).attr('onchange', 'verifica_RFC(['+arrayCamps[i]+'], '+parar+', '+param_extra+');');
            //}
            
                //event.preventDefault();
                
            //}); 
        }
    }

    // $(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno, #fechanacimiento', function(event) {
    //     event.preventDefault();
    //     verifica_RFC();
    // });

    $(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno', function(event) {
        event.preventDefault();
        var str = $(this).val();


        if (str.match(/(\d+)/)[1]) {
            alert("No se permiten números");
            $(this).val("");
        }
    });

    // // arreglo de inputs CPs
    // const array_botones_cp = ["CP1", "CP_A1", "CP_A2", "CP_A3"];
    // // const array_selects = [
    // //     /*['COLONIA1', 'MUNICIPIO1', 'ESTADO1', 'CIUDAD1'],*/
    // //     ['COLONIA_A1', 'MUNICIPIO_A1', 'ESTADO_A1', 'CIUDAD_A1'],
    // //     ['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'],
    // //     ['COLONIA_A3', 'MUNICIPIO_A3', 'ESTADO_A3', 'CIUDAD_A3']
    // // ]
    // // const array_valores = [
    // //     /*['MANA_2_5', 'MANA_2_6', 'MANA_2_7', 'MANA_2_8'], // titular*/
    // //     ['MANA_6_16', 'MANA_6_17', 'MANA_6_18', 'MANA_6_19'], // beneficiario 1
    // //     ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'], // beneficiario 2
    // //     ['MANA_62_16', 'MANA_62_17', 'MANA_62_18', 'MANA_62_19'] // beneficiario 3
    // // ];

    // // obtener el total de beneficiarios
    // var num_beneficiarios = parseInt($('#num_beneficiarios').val());
    // var total_recorrer = 1 + num_beneficiarios; // titular + número de beneficiarios
    // /*for(var i=0; i<total_recorrer; i++){
    //     clickea_boton(array_botones_cp[i]);
    // }*/   


    // setTimeout(function(){clickea_boton('CP1')},1000);
    // setTimeout(function(){selecciona_valores(['COLONIA1', 'MUNICIPIO1', 'ESTADO1', 'CIUDAD1'], ['MANA_2_5', 'MANA_2_6', 'MANA_2_7', 'MANA_2_9'])},1500);

    // setTimeout(function(){clickea_boton('CP_A1')},2000);
    // setTimeout(function(){selecciona_valores(['COLONIA_A1', 'MUNICIPIO_A1', 'ESTADO_A1', 'CIUDAD_A1'], ['MANA_6_16', 'MANA_6_17', 'MANA_6_18', 'MANA_6_19'])},2500);

    // if(total_recorrer == 3){
    //     setTimeout(function(){clickea_boton('CP_A2')},3000);
    //     setTimeout(function(){selecciona_valores(['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'], ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'])},3500);
    // }

    // if(total_recorrer == 4){
    //     setTimeout(function(){clickea_boton('CP_A2')},3000);
    //     setTimeout(function(){selecciona_valores(['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'], ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'])},3500);
    //     setTimeout(function(){clickea_boton('CP_A3')},4000);
    //     setTimeout(function(){selecciona_valores(['COLONIA_A3', 'MUNICIPIO_A3', 'ESTADO_A3', 'CIUDAD_A3'], ['MANA_62_16', 'MANA_62_17', 'MANA_62_18', 'MANA_62_19'])},4500);
    // }
    //for(var i=0; i<total_recorrer; i++){
    /*for(var i=0; i<num_beneficiarios; i++){
        var id_cp = array_botones_cp[i];
        //setTimeout(function(){
            obtener_demograficos(id_cp, array_valores[i], array_selects[i]);
        //},100);
    }*/
// fin del ready
    //$('#email').attr('onblur', 'validarEmail(event, this.value);');
    $('#email').attr('onblur', 'validarDato(event, this.value, this.id);');
    $('#fecha_cobro').attr('onblur', 'validarDato(event, this.value, this.id);');
});

$(document).ready(function(){
    // let date = new Date();

    // let day = date.getDate();
    // let month = date.getMonth() + 1;
    // let year = date.getFullYear();

    // if(month < 10){
    //   var fecha = `${day}/0${month}/${year}`;
    // }else{
    //   var fecha = `${day}/${month}/${year}`;
    // }

    // var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'txtQId21CId8','dateFormat' : 'd/m/Y'}
    // //var fecha = '<?=(strlen($txtQId21CId8)!=0?$txtQId21CId8:$today)?>';
    // new sCalendar(SC_SET_1,fecha);
    $("#fecha_cobro").datepicker({
        changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'dd/mm/yy'
            // ,
            // onClose: function(dateText, inst) { 
            //     var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            //     var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            //     $(this).datepicker('setDate', new Date(year, month, 1));
            // }
    });
});

function clickea_boton(id_boton){
    $("#"+id_boton).click();
}

function selecciona_valores(array_selects, array_valores){
    for(var i=0; i<array_valores.length; i++){
        var valor = $('#'+array_valores[i]).val();
        recorreSelect(array_selects[i], valor);
    }
}

/*function obtener_demograficos(id_boton, array_valores, array_selects){
    setTimeout(function(){
        $("#"+id_boton).click();
    },500);

    setTimeout(function(){
        for(var i=0; i<array_valores.length; i++){
            var valor = $('#'+array_valores[i]).val();
            recorreSelect(array_selects[i], valor);
        }
    },2000);
}*/

function recorreSelect(id_select, valor){
    $('#'+id_select+' option').each(function(){
        if($(this).val() == valor){
            $(this).attr('selected', true);
        }
    });
}

function SubmitForm(){

    var num_asegurados = $('#num_asegurados').val();

   
        if (num_asegurados == 1 || num_asegurados == 2 || num_asegurados == 3){

        
        var nombreA1 = $("input[name=txtQId26CId1]").val();

         var camposA1 = new Array();

         if(nombreA1 == ''){camposA1.push('nombre')}



        }
        

    






     /*  var fecha_change = $("#fecha_cobro").val();  
       var fecha_splitchan = fecha_change.split('/');   

     $('#fecha_cobro').val(fecha_splitchan[1]+"/"+fecha_splitchan[0]+"/"+fecha_splitchan[2]);*/

    var resultadolefechab = false;


    var fecha_lenb = $("input[name=txtQId26CId4]").val();



    var numro_adic = $("select[name=txtQId210CId1]").val();//numero de adicionales

    if(numro_adic == ""){alert("Numero de adicionales no puede ir vacio"); return false;}
    if (numro_adic != ""){



    var fecha_splitb = fecha_lenb.split('/');
    if (fecha_splitb[0].length == 2 && fecha_splitb[1].length == 2 && fecha_splitb[2].length == 4){ 
        resultadolefechab =  true; 
      //  alert("fecha "+resultadolefecha);
    }else{
        alert("fecha formato beneficiario incorrecto (dd/mm/yyyy)");
        return false;
    } 


    }
    if (numro_adic == 1 || numro_adic == 2 || numro_adic == 3){
     //con beneficiario 1
     /* var adicionala1 = $("input[name=txtQId26CId1]").val();
      if(adicionala1 == "" ){

        alert("el nombre de adicional no puede estar vacio");
        return false;
      }*/
      //VALIDACION DE VACIOS BENEFICIARIO (1) 
      var nombreb1 = $("input[name=txtQId26CId1]").val();
      var apellidopb1 = $("input[name=txtQId26CId2]").val();
      var apellidopm1 = $("input[name=txtQId26CId3]").val();
      var sexob1 = $("select[name=txtQId26CId9]").val();
      var naciolidadb1 = $("select[name=txtQId26CId6]").val();
      var ocupacionb1 = $("select[name=txtQId26CId7]").val();
      var parentescob1 = $("select[name=txtQId26CId8]").val();
      var civilb1 = $("select[name=txtQId26CId10]").val();
      var rfcb1 = $("input[name=txtQId26CId11]").val();

      var camposb1 = new Array();

    if(sexob1 == ''){camposb1.push('Genero B1')}
    if(nombreb1 == ''){camposb1.push('nombre B1')}
    if(apellidopb1 == ''){camposb1.push('apellidoP B1')}
    if(apellidopm1 == ''){camposb1.push('apellidoM B1')}
    if(naciolidadb1 == ''){camposb1.push('Nacionalidad B1')}
    if(ocupacionb1 == ''){camposb1.push('Ocupacion B1')}
    if(parentescob1 == ''){camposb1.push('Parentesco B1')}
    if(civilb1 == ''){camposb1.push('edo. Civil B1')}
    if(rfcb1 == ''){camposb1.push('rfc B1')}    

    if (sexob1 == "" || nombreb1 == "" || apellidopb1 == "" || apellidopm1 == ""|| naciolidadb1 == ""|| ocupacionb1 == ""|| parentescob1 == ""||civilb1 == "" || rfcb1 == ""){
        //alert("debe llenar todos los campos que son obligatorios: "+campos);
        var campos_b1 = '';
        for(var j=0; j<camposb1.length; j++){
            campos_b1 = campos_b1 + camposb1[j] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b1);
        return false;
    }
    }



        if (numro_adic == 2 || numro_adic == 3){

     //con beneficiario 2

     
      //VALIDACION DE VACIOS BENEFICIARIO (2) 
      var nombreb2 = $("input[name=txtQId261CId1]").val();
      var apellidopb2 = $("input[name=txtQId261CId2]").val();
      var apellidopm2 = $("input[name=txtQId261CId3]").val();
      var sexob2 = $("select[name=txtQId261CId9]").val();
      var naciolidadb2 = $("select[name=txtQId261CId6]").val();
      var ocupacionb2 = $("select[name=txtQId261CId7]").val();
      var parentescob2 = $("select[name=txtQId261CId8]").val();
      var civilb2 = $("select[name=txtQId261CId10]").val();
      var rfcb2 = $("input[name=txtQId261CId11]").val();

      var camposb2 = new Array();

    if(sexob2 == ''){camposb2.push('Genero B2')}
    if(nombreb2 == ''){camposb2.push('nombre B2')}
    if(apellidopb2 == ''){camposb2.push('apellidoP B2')}
    if(apellidopm2 == ''){camposb2.push('apellidoM B2')}
    if(naciolidadb2 == ''){camposb2.push('Nacionalidad B2')}
    if(ocupacionb2 == ''){camposb2.push('Ocupacion B2')}
    if(parentescob2 == ''){camposb2.push('Parentesco B2')}
    if(civilb2 == ''){camposb2.push('edo. Civil B2')}
    if(rfcb2 == ''){camposb2.push('RFC B2')}

    if (sexob2 == "" || nombreb2 == "" || apellidopb2 == "" || apellidopm2 == ""|| naciolidadb2 == ""|| ocupacionb2 == ""|| parentescob2 == ""||civilb2 == "" || rfcb2 == ""){
        //alert("debe llenar todos los campos que son obligatorios: "+campos);
        var campos_b2 = '';
        for(var z=0; z<camposb2.length; z++){
            campos_b2 = campos_b2 + camposb2[z] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b2);
        return false;
}

    var resultadolefechab2 = false;
    var fecha_lenb2 = $("input[name=txtQId261CId4]").val();


    var fecha_splitb2 = fecha_lenb2.split('/');
    if (fecha_splitb2[0].length == 2 && fecha_splitb2[1].length == 2 && fecha_splitb2[2].length == 4){ 
        resultadolefechab2 =  true; 
      //  alert("fecha "+resultadolefecha);
    }else{
        alert("fecha formato del bebeficiario "+numro_adic+" incorecta");
        return false;
    }

      


    }



            if (numro_adic == 3){

     //con beneficiario 3

    

    var resultadolefechab3 = false;
    var fecha_lenb3 = $("input[name=txtQId262CId4]").val();


    var fecha_splitb3 = fecha_lenb3.split('/');
    if (fecha_splitb3[0].length == 2 && fecha_splitb3[1].length == 2 && fecha_splitb3[2].length == 4){ 
        resultadolefechab3 =  true; 
      //  alert("fecha "+resultadolefecha);
    }else{
        alert("fecha formato del bebeficiario "+numro_adic+" incorecta");
        return false;
    }


      //VALIDACION DE VACIOS BENEFICIARIO (2) 
      var nombreb3 = $("input[name=txtQId262CId1]").val();
      var apellidopb3 = $("input[name=txtQId262CId2]").val();
      var apellidopm3 = $("input[name=txtQId262CId3]").val();
      var sexob3 = $("select[name=txtQId262CId9]").val();
      var naciolidadb3 = $("select[name=txtQId262CId6]").val();
      var ocupacionb3 = $("select[name=txtQId262CId7]").val();
      var parentescob3 = $("select[name=txtQId262CId8]").val();
      var civilb3 = $("select[name=txtQId262CId10]").val();
      var rfcb3 = $("input[name=txtQId262CId11]").val();

      var camposb3 = new Array();

    if(sexob3 == ''){camposb3.push('Genero B3')}
    if(nombreb3 == ''){camposb3.push('nombre B3')}
    if(apellidopb3== ''){camposb3.push('apellidoP B3')}
    if(apellidopm3 == ''){camposb3.push('apellidoM B3')}
    if(naciolidadb3 == ''){camposb3.push('Nacionalidad B3')}
    if(ocupacionb3 == ''){camposb3.push('Ocupacion B3')}
    if(parentescob3 == ''){camposb3.push('Parentesco B3')}
    if(civilb3 == ''){camposb3.push('edo. Civil B3')}
    if(rfcb3 == ''){camposb3.push('RFC B3')}

    if (sexob3 == "" || nombreb3 == "" || apellidopb3 == "" || apellidopm3 == ""|| naciolidadb3 == ""|| ocupacionb3 == ""|| parentescob3 == ""||civilb3 == "" || rfcb3 == "" ){
        //alert("debe llenar todos los campos que son obligatorios: "+campos);
        var campos_b3 = '';
        for(var zz=0; zz<camposb3.length; zz++){
            campos_b3 = campos_b3 + camposb3[zz] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b3);
        return false;
}

      


    }




//ADICIONALES 
    var adicionala1 = $("input[name=txtQId210CId1]").val();
    
    var nombre_a1 = $("input[name=txtQId26CId1]").val();


   //Fecha nacimiento valida
    var nombre_a1 = $("input[name=fechanacimiento_bene1]").val();

    if(nombre == ''){
        campos.push(' Fecha beneficiario 1')



    }



/*
    if(porcetaje_a1 == ''){campos_a1.push(' Porcentaje adicionala1')}
    if(nombre_a1 == ''){campos_a1.push(' Nombre Adicional')}
*/


    /*
    var campos_a1 = new Array();
    if (adicionala1 = 1){  */
     //si existe adicional 
     //DATOS ADICIONAL



 
     var porcetaje_a1 = $("select[name=txtQId26CId5]").val(); //porcentaje a1
     var porcetaje_a2 = $("select[name=txtQId261CId5]").val(); // porcentaje a2
     var porcetaje_a3 = $("select[name=txtQId262CId5]").val(); // porcentaje a2



     if (numro_adic == 1 && porcetaje_a1 != 100){

        alert("el porcentaje debe sumar 100");
        return false;
     }else if (numro_adic == 2 && (parseInt(porcetaje_a1)+parseInt(porcetaje_a2) != 100)){
         alert("el porcentaje debe sumar 100");
        return false;

     }else if (numro_adic == 3 && (parseInt(porcetaje_a1)+parseInt(porcetaje_a2)+parseInt(porcetaje_a3)) != 100){
         alert("el porcentaje debe sumar 100");
        return false;

     }

    



     /* if (nombre_a1 == "" || porcetaje_a1 == ""){
     
       var campos_ = '';
        for(var i=0; i<campos.length; i++){
            campos_ = campos_ + campos[i] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_);
        return false;

   
   }*/

   // $("input[name=txtQId21CId13]").get(0).type = 'email';
    var resultadolefecha = false;
    var fecha_len = $("input[name=txtQId21CId8]").val();
    var fecha_split = fecha_len.split('/');
    if (fecha_split[0].length == 2 && fecha_split[1].length == 2 && fecha_split[2].length == 4){ 
        resultadolefecha =  true; 
      //  alert("fecha "+resultadolefecha);
    }else{
        alert("fecha format");
        return false;
    }

    //alert('lkdangflksdngoskid');
//VALIDAR VACIOS DATOS DE TITULAR -------------------------------------------------------------
    var nombre = $("input[name=txtQId21CId1]").val();//NOMBRE
    var ap = $("input[name=txtQId21CId3]").val();
    var rfc = $("input[name=txtQId21CId7]").val();
    var f_nac = $("input[name=txtQId21CId8]").val();
    var r_mex = $("select[name=txtQId21CId9]").val();
    var est_civil = $("select[name=txtQId21CId10]").val();//estado civil verify 
    var est = $("select[name=txtQId21CId11]").val();//estado origen  verify 
    var pais_ori = $("select[name=txtQId21CId12]").val();//pais origen  verify 
    var email_ver = $("input[name=txtQId21CId13]").val(); //email
    
//DATOS DE DOMICILIO 

    var dom_vac = $("input[name=txtQId22CId1]").val();
    var dom_ext = $("input[name=txtQId22CId2]").val();
    var cp = $("input[name=txtQId22CId4]").val();
    var munici_ti = $("input[name=txtQId22CId6]").val();
    var estado_dom  = $("select[name=txtQId22CId7]").val(); 



//ACTIVIDAD LABORAL 

    var activ_lab = $("select[name=txtQId23CId1]").val(); 
    var ocup_lab = $("select[name=txtQId23CId2]").val(); 
    var desc_lab = $("input[name=txtQId23CId3]").val();

//DATOS BANCARIOS 

    var tdd_tdc_ban = $("select[name=txtQId24CId1]").val(); 
    var nombre_td_ban = $("input[name=txtQId24CId2]").val(); 
    var dig_ban = $("input[name=txtQId24CId3]").val();

//MENSAJERIA
   var llego_sms = $("select[name=txtQId27CId1]").val(); 
   var nip_sms = $("select[name=txtQId27CId2]").val(); 
//DATOS DE PRODCTO 
   var aut_prod = $("select[name=txtQId28CId1]").val(); 
   var plan_prod = $("select[name=txtQId28CId2]").val(); 
   var pago_prod = $("select[name=txtQId28CId3]").val(); 
   var metodop_prod = $("select[name=txtQId28CId4]").val(); 
   var futuro_prod = $("select[name=txtQId28CId5]").val(); 
   var acept_cargo_prod = $("select[name=txtQId28CId6]").val(); 
//AUTENTICACION 


//BENEFICIARIO  


    var lada = $("input[name=txtQId21CId7]").val();
    var cel = $("input[name=txtQId21CId8]").val();
    var col = $("select[name=txtQId21CId15]").val();
    var otra_col = $("input[name=txtQId21CId18]").val();
    var cd = $("select[name=txtQId21CId16]").val();
    
    var banco_ref1 = $("input[name=txtQId22CId1]").val();
    var dig_ref1 = $("input[name=txtQId22CId2]").val();
   // var anti_ref1 = $("input[name=txtQId22CId3]").val();
    var usr_correo = $("input[name=txtQId21CId10]").val();
    var dominio = $("select[name=txtQId21CId9] option:selected").text();
    var correo = usr_correo+dominio;
    var campos = new Array();

//----------------------------------------------------------------------------------------------------------VALIDACION DE 4 NUMEROS 


if (dig_ban.length != 4){
    alert("longitud de los digitos tarjeta incorrecta ");
    return false ;
}

//-----------------------------------------------------------------------------------------------------------

    //var campos = '';


    if(fecha_lenb == ''){campos.push(' Beneficiario fecha1')}
 //TITULAR 
    if(nombre == ''){campos.push(' Nombre')}
    if(ap == ''){campos.push(' Apellido Paterno')}
    if(f_nac == ''){campos.push(' Fecha De Nacimiento')}
    if(r_mex == ''){campos.push(' Reside en mexico')}   
    if(est_civil == ''){campos.push(' Edo Civil')}  
    if(est == ''){campos.push(' Estado')}  
    if(pais_ori == ''){campos.push(' pais origen')}  
    if(email_ver == ''){campos.push(' Email')}  
//DOMICILIO 
    if(dom_vac == ''){campos.push(' Calle')}
    if(dom_ext == ''){campos.push(' Numero Ext')}
    if(cp == ''){campos.push(' Código Postal')}
    if(munici_ti == ''){campos.push(' Municipio del titular')} 
    if(estado_dom == ''){campos.push(' Estado del titular')}       
//ACTIVIDAD LABORAL 
    if(activ_lab == ''){campos.push(' Actividad laboral')}  
    if(ocup_lab == ''){campos.push(' Ocupacion')}  
    if(desc_lab == ''){campos.push(' Descripcion de la Ocupacion')}     
//DATOS BANCARIOS
    if(tdd_tdc_ban == ''){campos.push(' Tarjeta de credito debito')}  
    if(nombre_td_ban == ''){campos.push(' Nombre tarjeta')}  
    if(dig_ban == ''){campos.push(' Ultimos 4 digitos')}  
//MENSAJERIA   
    if(llego_sms == ''){campos.push(' Llego SMS')}  
    if(nip_sms == ''){campos.push(' Es correcto el NIP')}    
//DATOS DE PRODCTO 
    if(aut_prod == ''){campos.push(' Esta de Acuerdo con la Oferta')}
    if(plan_prod == ''){campos.push(' Tipo de Plan')}
    if(pago_prod == ''){campos.push(' Forma de Pago:')}
    if(metodop_prod == ''){campos.push(' Metodo de Pago')}   
    if(futuro_prod == ''){campos.push(' Cobro a Futuro')}  
    if(acept_cargo_prod == ''){campos.push(' ACEPTA CARGO')}  



        //fecha beneficiario

    if(numro_adic == ''){campos.push(' numeros de beneficiario ')}  

    


    if(rfc == ''){campos.push(' RFC')}
    if(lada == ''){campos.push(' Lada')}
    if(cel == ''){campos.push(' Celular')}

//

if(rfc == ''){campos.push(' num adicional')}
    
    //if(banco_ref1 == ''){campos.push(' Banco de Referencia Bancaria 1')}
    //if(dig_ref1 == ''){campos.push(' Digitos de TDC Referencia Bancaria 1')}
    //if(anti_ref1 == ''){campos.push(' Antiguedad TDC 1 (YYMM)')}
    if(cd == ''){campos.push(' Ciudad o Municipio')}
   
//---------------------------------------------------------------------------------------------------------------------------------------------
    /*if(nombre == ''){campos = campos + 'Nombre\r\n'}  
    if(ap == ''){campos = campos + 'Apellido Paterno\r\n'}*/      

    if (numro_adic == "" ||fecha_lenb == "" || aut_prod == ""||plan_prod == ""|| pago_prod == ""||metodop_prod == ""|| futuro_prod == ""  || acept_cargo_prod == "" ||nombre == "" || ap == "" || f_nac == "" || rfc == "" || lada == "" || cel == "" || cp == ""    || cd == ""  || est == "" || r_mex == "" || est_civil == "" || est == "" ||pais_ori == "" || email_ver == "" || nip_sms == "" || dom_vac == "" || llego_sms =="" || dom_ext == "" || munici_ti == "" || estado_dom == "" || activ_lab == "" || tdd_tdc_ban == "" || nombre_td_ban == "" || dig_ban == ""){
        //alert("debe llenar todos los campos que son obligatorios: "+campos);
        var campos_ = '';
        for(var i=0; i<campos.length; i++){
            campos_ = campos_ + campos[i] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_);
        return false;
    }

    if(dato_valido < 1){
        alert("Debes agregar un dato valido en donde se pide.");
        return false;
    }


   /* if(!isDate2(f_nac, "DDMMAAAA")) {
        alert("[ERROR!] Fecha de Nacimiento Incorrecta");
        return false;
    }*/
/*
    if(lada.length+cel.length < 9 || lada.length+cel.length > 10){
        alert("[ERROR!] Lada Celular + Teléfono Celular debe ser de 9 o 10 dígitos");
        return false;
    }

    if (usr_correo.length > 0 || dominio.length > 0) {
        if (dominio == 'Otro') {
            if(!validarEmail(usr_correo)){
                alert("[ERROR!] Correo electronico invalido");
                return false;
            }
        }else{
            if(!validarEmail(correo)){
                alert("[ERROR!] Correo electronico invalido");
                return false;
            }
        }
    }
    */
/*
    if (otra_col.length > 0 && col.length > 0) {
        alert("[ERROR!] Si seleccionas una colonia, el campo de otra colonia debe estar vacio");
        return false;
    }
    if (otra_col == "" && col == "") {
        alert("[ERROR!] debe llenar todos los campos que son obligatorios: colonia");
        return false;
    }
    if (dig_ref1.length != 4) {
        alert("[ERROR!] Los Digitos de TDC Referencia Bancaria 1 deben ser 4");
        return false;
    }
    if (!isDate2(anti_ref1, "MMYY")) {
        alert("[ERROR!] Antiguedad TDC 1 en formato YYMM");
        return false;
    }*/
    
    //if (v_conteo_chec == v_conteo) {
        //alert('La solicitud que estas procesando es: ' + customer_id + '\n Base de Registro: '+$('#nombre_base').val()+'\n Marca la extension ' + extension);
        alert('La solicitud que estas procesando es: ' + customer_id);

      //  return false;
        document.SurveyResponse.submit();
    /*} else {
        alert("Te falta completar tu check list");
        return false;
    }*/
    
};

function verifica_RFC(arrayCampos, parar, tipo=null){
    var len = arrayCampos.length;

    if(tipo!=null){ // titular
        var ini = 1;
    } else{
        var ini = 0;
    }

    var arrayDatos = [];
    var dato = '';
    var contador = 0;

    for(var i=ini; i<len; i++){
        if($('#'+arrayCampos[i].id).length > 0){
            if ($('#'+arrayCampos[i].id).val() != ""){
                contador += 1;
                
                if(i<2 && tipo==null){
                    dato += $('#'+arrayCampos[i].id).val() + ' ';
                    arrayDatos.push(dato.replace(/^\s+|\s+$/gm,''));
                } else{
                    arrayDatos.push($('#'+arrayCampos[i].id).val());    
                }
                //nombre = eval("document.getElementById('nombrepila').value");
                
            }
        }
    }

    //console.log(ini, tipo, contador, arrayCampos);
    if(contador>3){
            //document.getElementById('rfc').innerHTML = "";
        $('#'+arrayCampos[5].id).html('');
        request = "action=5&nombre=" + arrayDatos[0] + "&paterno=" + arrayDatos[1] + "&materno=" + arrayDatos[2] + "&fecha_nac=" + arrayDatos[3] + "&num_reconocedor=";
        send_post_page_rfc(request, arrayCampos[5].id, "modules.php?mod=agentes&op=process_data&act=MjM=", "");
    }
    





    // var nombre, paterno, materno, fecha_nac, contador = 0;

    // for(var i=0; i<parar; i++){
    //     var arrayDatos = [];
    //     var dato = '';

    //     for(var j=0; j<(arrayCampos[i].length - 1); j++){
    //         console.log($('#'+arrayCampos[i][j]), $('#'+arrayCampos[i][j]).length);
    //         if($('#'+arrayCampos[i][j]).length > 0){
    //             if ($('#'+arrayCampos[i][j]).val() != ""){
    //                 contador += 1;
                    
    //                 // if(i==0 && j<2){
    //                 //     dato += $('#'+arrayCampos[i][j]).val() + ' ';
    //                 //     arrayDatos.push(dato.replace(/^\s+|\s+$/gm,''));
    //                 // } else{
    //                     arrayDatos.push($('#'+arrayCampos[i][j]).val());    
    //                 // }
    //                 //nombre = eval("document.getElementById('nombrepila').value");
                    
    //             }
    //         }
    //     }

    //     if(contador==3){
    //         //document.getElementById('rfc').innerHTML = "";
    //         $('#'+arrayCampos[i][5]).html('');
    //         request = "action=5&nombre=" + arrayDatos[0] + "&paterno=" + arrayDatos[1] + "&materno=" + arrayDatos[2] + "&fecha_nac=" + arrayDatos[3] + "&num_reconocedor=";
    //         send_post_page_rfc(request, arrayCampos[i][5], "modules.php?mod=agentes&op=process_data&act=MjM=", "");
    //     }

    // }

    

    // var nombre, paterno, materno, fecha_nac, contador = 0;
    // if (eval("document.getElementById('nombrepila')") != null) {
    //     if (eval("document.getElementById('nombrepila').value") != "") {
    //         contador += 1;
    //         nombre = eval("document.getElementById('nombrepila').value");
    //     }
    // }

    // //Segundo nombre
    // if (eval("document.getElementById('nombreseg')") != null) {
    //     if (eval("document.getElementById('nombreseg').value") != "") {
    //         nombre += ' ' + eval("document.getElementById('nombreseg').value");
    //     }
    // }

    // //Apellido paterno
    // if (eval("document.getElementById('appaterno')") != null) {
    //     if (eval("document.getElementById('appaterno').value") != "") {
    //         contador += 1;
    //         paterno = eval("document.getElementById('appaterno').value");
    //     }
    // }

    // //Apellido materno
    // if (eval("document.getElementById('apmaterno')") != null) {
    //     if (eval("document.getElementById('apmaterno').value") != "") {
    //         materno = eval("document.getElementById('apmaterno').value");
    //     }
    // }

    // //Fecha de nacimiento
    // if (eval("document.getElementById('fechanacimiento')") != null) {
    //     if (eval("document.getElementById('fechanacimiento').value") != "") {
    //         contador += 1;
    //         fecha_nac = eval("document.getElementById('fechanacimiento').value");

    //         if (!isDate2(fecha_nac, "DDMMAAAA")) {
    //             alert("[ERROR!] Fecha Incorrecta");
    //             contador -= 1;
    //         }
    //         fecha_nac = fecha_nac.substring(0, 2)+'/'+fecha_nac.substring(2, 4)+'/'+fecha_nac.substring(4, 8);
    //     }
    // }

    // if (contador == 3) {
    //     document.getElementById('rfc').innerHTML = "";
    //     request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac + "&num_reconocedor=";
    //     send_post_page_rfc(request, "rfc", "modules.php?mod=agentes&op=process_data&act=MjM=", "");
    // }
}

var dato_valido = 0;



function validarDato(e, valor, id){
    e.preventDefault();

    $('#errorDato').remove();
    
    var dato_ = 1;
    if(id == 'email'){
        var regExp_dato = /(([^<>()[\]\.\s@\"]+(\.[^<>()[\]\.\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.\s@\"]+\.)+[^<>()[\]\.\s@\"]{2,})/i;
        var dato = 'Correo Invalido.';
        
    } else if(id == 'fecha_cobro'){



     

        var regExp_dato = /^(?:(?:(?:0?[1-9]|1\d|2[0-8])[/-](?:0?[1-9]|1[0-2])|(?:29|30)[/-](?:0?[13-9]|1[0-2])|31[/](?:0?[13578]|1[02]))[/-](?:0{2,3}[1-9]|0{1,2}[1-9]\d|0?[1-9]\d{2}|[1-9]\d{3})|29[/-]0?2[/-](?:\d{1,2}(?:0[48]|[2468][048]|[13579][26])|(?:0?[48]|[13579][26]|[2468][048])00))$/;
        var dato = 'Fecha Invalida.';
 

       
      
//JEMJOSRAA36
            
      
   //   $('#fecha_cobro').val(fecha_splitchan[1]+"/"+fecha_splitchan[0]+"/"+fecha_splitchan[2]);

        if(valor.split('/')[2].length != 4){
            dato_ = 0;
        }
    }


    if (!regExp_dato.test(valor) || dato_==0){
       $('#'+id).parent().append('<span style="color:red;" id="errorDato">'+dato+'</span>');
       return false;
    } else{
       dato_valido = 1;
       return true;
    }



}




function oculta_beneficiarios(){  
    // agregar clase a los bloques de beneficiario
    $('.bloque_beneficiarios2').hide();
}


$( document ).ready(function() {//display ASEGURADOS----------------------------------------------------------------

 // var array_leyendas2 = [21]; revisar bine que pedo 

 //    for(var i=0; i<array_leyendas2.length; i++){
 //        $('#cuestionario tbody tr:eq('+array_leyendas2[i]+')').attr('class', 'bloque_beneficiarios2');
 //       // $('#cuestionario tbody tr:eq('+array_cuerpo[i]+')').attr('class', 'bloque_beneficiarios2');
 //    }
//const array_leyendas = [28,42,56];
//var array_leyendas2 = [21];
//var array_cuerpo = [29,43,57];  
//
$('#cuestionario tbody tr:eq(23)').attr('class','oculta_adicionales1');
$('#cuestionario tbody tr:eq(24)').attr('class','oculta_adicionales1');
$('#cuestionario tbody tr:eq(36)').attr('class','oculta_adicionales2');
$('#cuestionario tbody tr:eq(37)').attr('class','oculta_adicionales2');
$('#cuestionario tbody tr:eq(49)').attr('class','oculta_adicionales3');
$('#cuestionario tbody tr:eq(50)').attr('class','oculta_adicionales3');


$('.oculta_adicionales1').hide();
$('.oculta_adicionales2').hide();
$('.oculta_adicionales3').hide();

$('#num_asegurados').attr("onchange", "mostar_aseg()");

});

function mostar_aseg(){

  var num_aseg =   $('#num_asegurados').val();

 // alert(num_aseg);

  if(num_aseg == 1){

    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').hide();
    $('.oculta_adicionales3').hide();

  }else if(num_aseg == 2){
     $('.oculta_adicionales1').show();
     $('.oculta_adicionales2').show();
     $('.oculta_adicionales3').hide();

  }else if(num_aseg == 3){

    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').show();
    $('.oculta_adicionales3').show();

  }else{

    $('.oculta_adicionales1').hide();
    $('.oculta_adicionales2').hide();
    $('.oculta_adicionales3').hide();

  }
   
}

//--------------------------------------------------------------------------------------------------------------------