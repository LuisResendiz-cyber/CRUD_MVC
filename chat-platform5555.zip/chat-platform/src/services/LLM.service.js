const axios = require("axios");

const OLLAMA_URL = "http://localhost:11434/api/generate";
const MODEL = "phi3:latest";

function buildKnowledgeContext(knowledgeList = []) {
  if (!knowledgeList.length) return "NO HAY INFORMACIÓN DISPONIBLE.";

  return knowledgeList
    .map(k => `• ${k.title}:\n${k.content}`)
    .join("\n\n");
}

const LLMService = {
  async generate({ systemPrompt, userMessage, knowledge }) {

    const knowledgeContext = buildKnowledgeContext(knowledge);

    const finalPrompt = `
${systemPrompt}

==============================
CONTEXTO DE CONOCIMIENTO
(ÚNICA FUENTE DE VERDAD)
==============================
${knowledgeContext}

==============================
INSTRUCCIONES CRÍTICAS
==============================
- Usa EXCLUSIVAMENTE la información del CONTEXTO DE CONOCIMIENTO
- NO inventes
- NO supongas
- NO extrapoles
- Si la respuesta no está explícitamente en el contexto, responde EXACTAMENTE:
"No cuento con esa información por el momento. Un asesor humano podrá ayudarte mejor 😊"

==============================
PREGUNTA DEL USUARIO
==============================
${userMessage}
`;

    const response = await axios.post(OLLAMA_URL, {
      model: MODEL,
      prompt: finalPrompt,
      stream: false,
      options: {
        temperature: 0,
        top_p: 0.1,
        repeat_penalty: 1.2
      }
    });

    return response.data.response.trim();
  },
  async generateChat({ userMessage }) {
    const prompt = `
  Eres un agente virtual de atención al cliente.
  Responde de forma natural, empática y profesional.
  
  REGLAS:
  - No proporciones información técnica
  - No inventes datos
  - No prometas soluciones específicas
  - Ofrece ayuda humana si es necesario
  
  Mensaje del usuario:
  "${userMessage}"
  `;
  
    const response = await axios.post(OLLAMA_URL, {
      model: MODEL,
      prompt,
      stream: false,
      options: {
        temperature: 0.4
      }
    });
  
    return response.data.response.trim();
  }
  
};

module.exports = LLMService;
