const { Worker } = require('bullmq');
const customerModel = require("../models/customerModel");
const { sendWhatsAppMessage } = require('../services/whatsappService');
const axios = require('axios');
const { SYSTEM_PROMPT } = require("../public/systemPrompt.js");

// === CONFIG ===
const REDIS_CONN = {
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: process.env.REDIS_PORT ? Number(process.env.REDIS_PORT) : 6379
};

const LLM_TIMEOUT = 60000;
const CONTEXT_LIMIT = 8;

async function callOllama(messages) {
  try {
    const payload = {
      model: 'phi3',
      stream: false,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages
      ]
    };

    const { data } = await axios.post('http://localhost:11434/api/chat', payload, { timeout: LLM_TIMEOUT });

    const content = data?.message?.content ?? null;
    if (!content) throw new Error('Respuesta vacía de LLM');
    return content;
  } catch (err) {
    console.error('[ERROR] callOllama:', err?.message || err);
    throw err;
  }
}

// === Worker principal ===
const worker = new Worker(
  'jobs',
  async (job) => {
    console.log(`=== Nuevo job recibido ===\nTipo: ${job.name}\nID: ${job.id}`);

    const { from, text, wamid, conversation_id } = job.data;

    console.log('📩 Mensaje del usuario:', { from, text, wamid, conversation_id });

    // --- 1) Obtener contexto (últimos mensajes)
    let history = [];
    try {
      // TODO: Ajusta conversation_id si tu DB lo requiere, sino usa número
      history = await customerModel.getLastMessagesByConversation(conversation_id || from);
    } catch (err) {
      console.error('[ERROR] Obteniendo historial:', err?.message || err);
      history = [];
    }

    // --- 2) Formatear mensajes para LLM
    const messagesForLLM = history.slice(-CONTEXT_LIMIT).map(h => ({
      role: h.role === 'assistant' ? 'assistant' : 'user',
      content: h.message_text || h.message || ''
    }));

    // Incluir el mensaje actual del usuario
    messagesForLLM.push({ role: 'user', content: text || '' });

    // --- 3) Llamar al LLM
    let aiResponse = '';
    try {
      aiResponse = await callOllama(messagesForLLM);
      console.log('[INFO] Respuesta LLM generada:', aiResponse);
    } catch (err) {
      aiResponse = "Disculpa, en este momento no puedo generar una respuesta. Intenta más tarde.";
    }

    // --- 4) Guardar respuesta en DB
    try {
      await customerModel.insertWebhookLog({
        event_type: 'message',
        wamid: null,
        from_number: from,
        status: null,
        message_text: aiResponse,
        role: 'assistant',
        raw_json: { generated_by: 'ollama', timestamp: Date.now() }
      });
    } catch (err) {
      console.error('[ERROR] Guardando respuesta en DB:', err?.message || err);
    }

    // --- 5) Enviar WhatsApp
    try {
      await sendWhatsAppMessage(from, 'Asistente', 3, aiResponse);
      console.log(`[INFO] Respuesta enviada a ${from}`);
    } catch (err) {
      console.error('[ERROR] Enviando WhatsApp:', err?.message || err);
    }

    return { processed: true };
  },
  { connection: REDIS_CONN }
);

// === Manejo de eventos ===
worker.on('completed', job => console.log(`✔️ Job completado: ${job.id}`));
worker.on('failed', (job, err) => console.error(`❌ Job falló: ${job.id}`, err));

module.exports = worker;