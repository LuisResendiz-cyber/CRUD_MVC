const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN DBO.TL_CAMPANA_NOMINA(:nomina, :rc); END;";
	let query = baseQuery;
	const binds = {};
  
            binds.nomina = context.nomina;
            binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;
                    
}
 
module.exports.find = find;

