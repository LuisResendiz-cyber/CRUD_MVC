const db = require("../db/mysql");

const KnowledgeModel = {
  async getByBot(idBot) {
    const [rows] = await db.query(
      `
        SELECT id, title, content, tags, priority
        FROM BOT_KNOWLEDGE
        WHERE id_bot = ?
          AND is_active = 1
        ORDER BY priority DESC, id ASC
        `,
      [idBot]
    );

    return rows.map((row) => ({
        title: row.title,
        content: row.content
        
      }));
  },
  async searchRelevant(message, botId, limit = 5) {


    console.log(message);
    console.log(botId);


    const sql = `
      SELECT id, title, content, priority,
             MATCH(title, content) AGAINST (? IN NATURAL LANGUAGE MODE) AS score
      FROM BOT_KNOWLEDGE
      WHERE id_bot = ?
        AND is_active = 1
        AND MATCH(title, content) AGAINST (? IN NATURAL LANGUAGE MODE)
      ORDER BY (score + priority) DESC
      LIMIT ?
    `;
  
    const [rows] = await db.query(sql, [
      message,
      botId,
      message,
      Number(limit)   // 👈 IMPORTANTE
    ]);
  
    return rows;
  },  
  async getActiveByBot(botId) {

    const sql = `
      SELECT 
        id,
        system_prompt,
        prompt_type,
        priority,
        is_active
      FROM BOT_PROMPTS
      WHERE id_bot = ?
        AND is_active = 1
      ORDER BY priority DESC, id ASC
    `;
  
    const [rows] = await db.query(sql, [botId]);
  
    return rows.map(row => ({
      id: row.id,
      prompt_type: row.prompt_type,     // base | sales | retention | etc.
      content: row.system_prompt,
      priority: row.priority,
      is_active: row.is_active

    }));
  }
   
};

module.exports = KnowledgeModel;


