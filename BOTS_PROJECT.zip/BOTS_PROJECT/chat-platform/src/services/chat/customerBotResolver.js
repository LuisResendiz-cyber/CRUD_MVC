// services/customerBotResolver.js

const CUSTOMER_KNOWLEDGE = [
    {
      keywords: ["horario", "abren", "cierran"],
      answer: "Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00."
    },
    {
      keywords: ["precio", "costo", "plan", "tarifa"],
      answer: "Para información de precios, un asesor puede ayudarte mejor."
    },
    {
      keywords: ["ubicación", "direccion", "dónde están"],
      answer: "Estamos ubicados en la ciudad. Un asesor puede darte la dirección exacta."
    }
  ];
  
  function normalize(text) {
    return text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  }
  
  function resolveCustomerService(message) {
    const normalizedMessage = normalize(message);
  
    for (const item of CUSTOMER_KNOWLEDGE) {
      for (const keyword of item.keywords) {
        if (normalizedMessage.includes(keyword)) {
          return item.answer;
        }
      }
    }
  
    // 🔴 Fallback controlado
    return "Gracias por tu mensaje. Un asesor continuará la conversación contigo.";
  }
  
  module.exports = {
    resolveCustomerService
  };
  