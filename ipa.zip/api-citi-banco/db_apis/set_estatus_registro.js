const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".xsp_setEstatusRegistro_pnd(:u_registro, :agente, :u_telefono, :cal_telefono, :elapsed, :comment, :campana, :segundos, :tipoCampana, :uuid); END;";
console.log(context);
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.u_registro || !context.agente || !context.u_telefono || !context.cal_telefono || !context.elapsed /*|| !context.comment*/ || !context.campana || !context.segundos || !context.tipoCampana){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.agente     = context.agente;
            binds.u_registro      = context.u_registro;
            binds.u_telefono      = context.u_telefono;
            binds.cal_telefono      = context.cal_telefono;
            binds.elapsed      = context.elapsed;
            binds.comment      = context.comment;
            binds.campana      = context.campana;
            binds.segundos      = context.segundos;
            binds.tipoCampana      = context.tipoCampana;
						binds.uuid      = context.uuid;

            const result = await database.simpleExecute(query, binds);

            

            return result;
        }
}

module.exports.find = find;
