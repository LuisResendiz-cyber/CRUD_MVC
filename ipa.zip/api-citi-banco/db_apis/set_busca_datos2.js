const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".SPS_BUSQUEDACLIENTE2(:tipo, :nombre, :paterno, :materno, :solicitud, :clave, :telefono, :rfc, :busqueda, :rc); END;";
  let query = baseQuery;
  const binds = {};
        let result2 = {};
        
        if(!context.tipo || !context.nombre || !context.paterno || !context.materno || !context.solicitud || !context.clave || !context.telefono || !context.rfc || !context.busqueda){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.tipo     = context.tipo;
            binds.nombre      = context.nombre;
            binds.paterno      = context.paterno;
            binds.materno     = context.materno;
            binds.solicitud      = context.solicitud;
            binds.clave      = context.clave;
            binds.telefono     = context.telefono;
            binds.rfc      = context.rfc;
            binds.busqueda      = context.busqueda;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};        

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result); 

            return result;
        }            
}
 
module.exports.find = find;