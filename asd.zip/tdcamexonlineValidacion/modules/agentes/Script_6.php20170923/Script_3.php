<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title></title>
	<meta name="generator" content="LibreOffice 4.2.8.2 (Linux)">
	<meta name="author" content="Christoper Gaytan Chavez">
	<meta name="created" content="20170123;185800000000000">
	<meta name="changed" content="20170923;105854089861589">
	<meta name="AppVersion" content="16.0000">
	<meta name="Company" content="Microsoft">
	<meta name="DocSecurity" content="0">
	<meta name="HyperlinksChanged" content="false">
	<meta name="LinksUpToDate" content="false">
	<meta name="ScaleCrop" content="false">
	<meta name="ShareDoc" content="false">
	<style type="text/css">
	<!--
		@page { margin: 1.27cm }
		p { margin-bottom: 0cm; direction: ltr; line-height: 100%; text-align: justify; widows: 2; orphans: 2 }
		p.western { font-family: "Times New Roman", serif; font-size: 10pt; so-language: es-ES }
		p.cjk { font-family: "Times New Roman"; font-size: 10pt; so-language: es-ES }
		p.ctl { font-family: "Times New Roman"; font-size: 10pt }
		a:link { color: #0000ff; so-language: zxx }
	-->
	</style>
</head>
<body lang="en-US" link="#0000ff" dir="ltr">
<div title="header">
	<p lang="es-MX" align="left"><br>
	</p>
	<center>
		<table width="709" cellpadding="5" cellspacing="0">
			<col width="225">
			<col width="226">
			<col width="225">
			<tr>
				<td width="225" height="6" valign="top" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font color="#1f497d">&nbsp;</font></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: none; border-right: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Nombre
					de Documento:</b></font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: 1px solid #1f497d; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Emisi&oacute;n</b></font></font></font></font></p>
				</td>
			</tr>
			<tr>
				<td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font color="#1f497d">&nbsp;</font></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">Script
					Comercial de Venta</font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="center"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">03/09/2015</font></font></font></font></p>
				</td>
			</tr>
			<tr>
				<td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font color="#1f497d">&nbsp;</font></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Producto:</b></font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>&Uacute;ltima
					Actualizaci&oacute;n</b></font></font></font></font></p>
				</td>
			</tr>
			<tr>
				<td width="225" height="7" valign="top" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font color="#1f497d">&nbsp;</font><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAABhCAYAAAByBazAAAAACXBIWXMAABcMAAAXDAGKAo5mAAAo90lEQVR4nO2dB1hUxxbHz6UjCoKAiiCoWLBr7L3XGI1J7DEmJnlpJjFGE43lxcTENEuMpltib1ETKwgCIgJ2QUBQpCO9d9h558wusGyBRdDN+zK/L6tx9965c+fO/OecmTNzjRhjIBAIBPrESN8ZEAgEAiFEAoFA7wghEggEekcIkUAg0DtCiAQCgd4RQiQQCPSOECKBQKB3hBAJBAK9I4RIIBDoHSFEAoFA7wghEggEekcIkUAg0DtCiAQCgd4RQiQQCPSOECKBQKB3hBAJBAK9I4RIIBDoHSFEAoFA7wghEggEekcIkUAg0DtCiAQCgd5pECH68cR19u32i2DYxKzG4+h9IcZGBmBhaowfI+jToQV8+84YqaZzxi87xDIy8kAyMqw1H5S+If7Zyt4Spg/rCHPHdKlM++Tle2z1z95gZEa3LP+alcvAoVljOLH+hRrzoMryX32Yx8UIMLAwAZZfDKOHdoD1r42olsaOM7fZ1gOBYGBuUj1/eM0eHVvAzx9OrNM1NbFujz/D+4Ky0nKQDAw0HiNjDMyNDcERy2R4N0d449mn6n1dgaChaRAhSs4sgKiIhwBNG9V8IDUBao0y/AMbiM+le/DzsWts1esjYNnM/hobiF9wHBQ8zAYwqUNWsbH/eTYEfvv7JruweS5P9+mBrtLUFUeYLKcQ71pJ1PKKYVRJGfPaMFvnBrrLPRiSIpPleSoshRmTe6gd84d7CFy7Fg2ouNV/wPsOvBwJjS1M2Xdvjqq3KATciAUoLZP/o7hM/QBJcQlDAzjw901YiSL6+rTe8MXrI4QgCf4xNIgQkZUDZsbyjzIkOMWlVf8mESIRMKsSgrzCEvjou7PQprkVe2FEJ7XG0RgtioJGJupCVFLGBacSanB0jIFUeW1v73AY/9Ehdu6rGfzLcf3awlmvUIBGVVYKoGV24Xo0BIYlsv5uDrU2To9r0SwpMQvACkVXJgMzawtYqkFEb95Llh9josGSw/La5xkKKES1Xa5WjPBeyooksMZ8PIWWlgGWQ8Wb6qgoUrIKITOnAGKSc4Ch6KZn5cOXP3pBWFwGO/bZdCFGgn8Ej2+MCBtpk8Zm0KOHE28cZA2VlskgPCYdMtNyUIwUYoBuGpQUwZZjVwGFSLe00aro3L4F2KEFRq4HNbhUbHCh1PiZxHt//iX+7u57Fzyvx7DRvZ2lKQNd4ax3mFwQK5ogHZtbBH9digQUolovfTYoSi6CJHpF5dC7R3O1Y3adC2ZZ2PChkamGFICUGx4mZMKhC2Fsxki3+otBUSl0a2sHHt/O0pqW5/Vo9uuJG3Dw/B1UdzM4fuombOzhxBY/31eIkUDvPD4hKioDty62cPH7eWoVfcBbf7DA6zEA5goLCq2SmIc5uqVLVhZaQusWDoNpQztUS/vr/QHsY+ztGR1DQkQCiOJ3LyEDUIjgrWm9pQ+2nmfF5MIYKo2poIVy7soDWPfq8FovfykkvsrqwnxM7N9O7RiPq9FVYqfILxgrWUZ0fmk5HEfxQyHS7b5ro5YX9o7u7SLhB1raNWGb9vhzMfwFXTUUooa5vkBQDx7rrJm2rjZg23zJatJ3LCe3mIsAYSDVrWOWDNSPXzZ7gBQSncZ2H7tWNTYjVU+7f5dW4HvpHloFStYKWje37ifrdN3r4UlyKw7FxQAti5G9Wqsdc+FmrFx40FozQ3fV1soc4lNyqxcIpuFJYtxA6Pri8I3vjJH2nL/D0tBiu4dWmUDwT+CxClFNjaNLW3u4fPUB5gBdtJJycG5hWae0ZTLNqY/r4wK7D19RZIDxMak2Dk0rf5+MFgwXImUMDKAspwi+OxTElszop1URNx+9ykrzitCSM+VjX+3b28Hgro7Vjj8VcJ8lJWbKhQitwh6dW8FL47vCW1+fkX9XcTQKcEpSFhzwCmOzRjWAe1YHuraxA+/4TChDMfW4+oCN7dOmxutfCo5n0cnZkJiWB0XoBpqgBUuzjS+O61prvn1uxrIStP7G9tV8jRN+kSw2JQeycgvBFDuEDo42apauLhz3i2BkVefkF3FLuLm1Bbi1toGhPVrXKS16HjF4ryXofjexMIM2Laxg6pD2OqXhdT2GUZ83spez2vHeWA4R8RmQnJ4HRlgnOznZwLPDOmpNNygskQU/SIVEPJ46UsrHHKVZYF3541wIS0jL5TOr1k3NoUMrGxin5Vkoc+ryPTZ5oKvacVQX6D7Kyhk42TeBCf3aNkjd1VscUUpmgdw94rNoMpg2pEODpBuXqmR5YKPp3NkBxqBbUvE7WU2rfvdlVNEq3TM+m8fQkokBFCKtaXuQcMoUx+P54/u6qB3jfiUKGF4XLI241fRUhxbw5tTe0opffVhWVkGVi6Zwz2j6HYWoQe5dV8xpfIsLOeNarYnz16IZjSedvRYNSVim5YV4TwVowZaVc7eOBvxf//o069exBaxaOBzLWL3xETPWnoCU6DRYMKMf2/HxZH7MUZ9wtvtsMPjcSYCsjHyAwhJeFvx5YLrtWlmzr94ZA8/V0FCJAGysmw4Ewnl8bunpmE5BiTx/BFqihmgVd3SyYQsm9YClszTPyhKnLt9nmw8Ggn9oAuRTR5OvSIcsX8yPjY0Fow7sj0+m1Jif59Ycgxy0Mpe9MZJ9qZiVXIl17QCWY1RiFjDKH03e0H2am4Cbiy3bsHg8TFAShm8OBLL9HiEQgiJUmlfM6zCvK3j8u5vOsY/nD4EPa+gsiUt34tn6XZfA+3Y85GUqyoWGB2goBMvEuYUVmz++G6xdOExjOnvRYp639CBNxDCfbS9Cv04O0u+nbrItR67CHXyWZfS8MM1WHVtC/OG3a8qKzuhFiDahZXE/KkX+oPGmOqC79H4DDZpu/fOavMAVFtNHs/qrHUPu2UUUgGpT65gXv+D4GtPGii8fpMa0Jazoo3o7qx3jTuNDdAxdHuvbqF7yY/q6OYCHd3j1sSJMw4Om+J8wobHpPB9GhoYae8cl27zYht99FbOSTH4/jUzBrqUVF7HU7AIoRFEtyi4E38AomHwnEXb/dxqboWHWs5zSKC8H6t2xfNma33zAC8+BfGxkhpL8GViayw+msTss2/vR6TB7zZ/gvnEOG9FTs8BtOnKFrfjpAhSSkJGaopUG6AIbKFx2GXYU5Zi/0OwEWHYrFo6hxeT/w4tqaX2wzZNt3HtZ3ljpV2zwps2toAkKUEZOIchQfDPiMmA3WgEnMY0tH06EuaM7a8wT3asMP77BcbDhcBD7DkUykcI8KH90n/iRmpgCU9xnGP72/Mqj4L5hNkvF8lz6w3mIJNefRJDiz/Bj0MQMZCTSeA6J7dLvzoKTXRM2U8skx0Ysl+U/ekExWlJcwPCaNi3s+HNLRlEqw2cXcz8FPtvmyTsb/23z1dJhTB5eU4T3fvxiJGw7foPtOnaVey583JVmxy1M4LWn1cNWHhW9CNGaX73lhUQza5Zm8MN74xok3ZlrT7AErPBUsaWiEpg1pSeg8qsV9CTs3bgQKc+eoauUja7HAa9QdJXUKxq5EOk0E0YVHiuGPZnsg6u7EP4hCex+nLyRU2yPfUtreG64vFcnl9HDJ1xtxo67Z554TS2Vu6FZvz+AxTxI4/lop+SyKjO0uyNsb2YBWdiYR/V2gWfRWn1nevVAyO2nb7NNR69AMFo1JdiZvLflPMzQMOtpSL0/NoYwFL/RS/ZDCcWEYRl2wGs8M7QjDOvuBFMGyV2AnWeD2ae7/CA6Jh1K0VX+en8goBCppblurz9budmjMmRjaL82MHtMF3jzmV6VeTx35QEP9jzmcxcSYlLB0a6JWjrvbPZgW//w4+67YdNGMAvTmDO6M0wa0K4yne2nbzHMF1y88gAysXHP//Q4fc00iRG/VxSOwNBE8MfjqZO1RFdo8mBXtJ7boIsur4s0q/rfnXifWCb56EpO/eQoZKBrKqNxRCz30U+5UN2CRYoy97gazb7cdxkuBMiHFD7Fc2dqmOT46e+b7INvTqMiMjCyaQwLJnWH+eO64vN0qszrdwcD2feHr0AsiutlLJ9xSw8y929mVrsXSZIqrdOvDgSAjKzEMhm0dm0OM7B8BmCnWlGvG4onLkRD3t3DckitG5vxB9UDLYaxT7nU+6Z2e4SwQ6dvydOlB2FizB+CJj6eg+7Zdl9WVs09k7tK7liBUIjUzjlJlYB6KuoN8Lzh2IBUIdeuNKuQ98xkUvdGt6WCD2f2l5b/4s3KKlwQgrtnZTSuBChEj37zTNEIamHLn9fYyl+85UKIPfcHWtxQdJOlae5La0zrlUndJfxAx7k/sYj7qfAwMRP2e4Wx2ZrGu/A+C8gCQgujNbqqH84eAIue66N23IIJ3SQ352Zs9Ht7IR/zd+Oe+gQChSGs+tm7MkTj09dHwOqXhqilhQ1fosa/5d2xGvNPYrB1r3z2sFFjU9j+yTPYuNUtulcm9cD77AErfvNhX/7mCzJ0rd7+5gxZRZoLButROVk8+ExemPYUHPr0WbU0SZCc7C3ZhA/2QylaRmmpOTwwtjvm9/NXh1cKcwVj+7hI+AHXOT+y+/dStU4yLN3iwa/b2NoCdqycAs8PV7+fJVgP8QOdX/yFhUU85Fb6zjO32YKJ3TW2QRm5hnhP/8Fn9lMDrAbQxhMVImoIly6EYa+hMMWxUV++GQtj3t/Lzm+aW6+bXIZmOj1MUCypKMWKvODzv2DFgiHs3enqlb4nqvvVGzHVgxuxd+UzXhq4SG4bBWNyi0aCCRqm7XmMUUUAo8QbQ7Xfu7Wzhxu34lQCKo3Bvb7uGVpgcSk58D26vCRITDHwQz1bNgpABPZ+gehWhlP0OzZeIzz+zbkD4fWne9a7Yi2c0gs++vYMN+Vvo3DM1jTehY3NCPM15/m+sGvlMzVek4JKu7jas6CgB5BNYyQqrNnhJx9rwfv4YP5QjSKkC2v/uMT/ltAS3rp0okYRUuaLV4dLWMZsz/HrkI1lPf+Lk+yPFU+rn4OdlSVa+V+8MRrefra31jTRZZfaONmwCHTPDDAPb8wbBFs/GF9jHnphx3YfXTfqQP/2v8eUBWvmp8dZXlour6MrXxmmUYSU+X7xOBi/eD/IsH78+NcNQCFSPwitIFMU6vWLRzfY0Ik2nqgQkamJhcjWoZmZToVmZoIdsww8/SKhxdTN7NBn08lUf6Qb3r5sMgrdVThD7g9ZLfhwk9HVem/9KbifkMU2L6q+po1E4ioNPiuDDTQae5sLN2LZyF5Vsy3+dxJYJLkzNFaCFa0JmvkvT1B3+a5RQyexQhE0QbFVfXjDezjBjRsqU/Z4fEpSdv2CG00NgVzC9746pf0YsiD4rJ0E/31tOHwyb1CDVCwXdFF5eecWQXaBunBwisqgs1urWkWogmaWjbiwGaiEaPjeimOXbsXyZ9umrT086hKZg1jWUfdTuECOHeQKCzS475rYvWKKdDbwPktD9/KYX4Tmg9CC6DPQtUYRqqB5UwuIQFExb2pVqwgRFQcwtPhLKwblFZxEqxrNYnBFi/Oj2doH5iugCZw+XVqxoCtRcD1SS+gK3suLaDU/bhEinrhrtnhWf2lgdyc28cMDkEXrvqhxoF+dnJQFM9ccg6Rj7z5SuhP7t5XwA7PWnmAHT97ig2l8PAcr7fc7L0IzK3O2ev7gygJ9Bv32L/b484Wv1Vwl7IVP40NVjg8id01GMwUUe1RUDn07tlS7/o9/XWeFNHNDx2Av001DlPYzg9rDpv2B8oH0ikamcM+O+Nytf3Ajq/xDBUk+8CyTD+ruOX0bCgtL2eevDa93BbOk6HHDWmLBaOGtme5VTVtoBrc46Tngz1pdIx1wvxINUEwDwkbw4tgudTp3XL92sA87vLz0XO7evaRBxAy0LEDWhq4hdJUznJJiHEfBbydvsQIa7sBO/YXhOq5OQEb2bA1B/pF8FmyPxx02b6xKeABeo72jtc7p1Qe9DFYP6OwgfTCrP1v9w3l5QKMkH91/GJsOkz4+zE7XcTW8MgdWT5W8rkWzVHowJHKKqdK1231hzFMubFCXVjxtmpLs0b45u3k7rtKd42BeaNZDGRr7qeyOystppkntuueClKwrBjySWxWKL3F2tGExsWnyGcMK0KI4fz36UW9ZYXE4wOevDsPbVS+6Iux1b99PBU90AQPwfslFW4eu2uXQBOa5cU69xMhA0ShqC6jUJi514SZZMWgNSCj2QzSM0enKnZhUPqNpgRbJvLG1x0IpQ1btvpM3ubVwi/KjAaYtJuIxwcuFxh6xXFraNtb5PEMSTLLyS8ohidqLBmhZ1pNAb3FEq9A6+WKvPysqKMVcKOpCYzM4c/Eu9XysPoFSk9A03oW9VuVUOf5dnkuzMAFw/PPnqo7r1xZuUnSz8kwWisLNu0nV0rsZkSy3rshnxsr70ewBannjY0imVVP7kzEPmqAp/x0Uxa0sRCjGmSk5sOss9rAaXL5awXxRAN+zQ7QHAs4Y4QafLxwGe7Hne+97D0jHiuflHQaLvvdgW94dq/G845ci2Z/e4RAclQLxeHwxbTcCJDqMjx04N1cEoZIaaRDAhoamuOk5NbE054PRj5rOQ8XUNm1FU1da21vK3W/DcohP0XFZ0mMmNiVbXtcxX6t+94X/7rhYqxbSygTqoPh6yOwCSKGy1SN63RitbUtrCKVGb6TkGmFPQ24KCtEjp9u3U0vYpdoDY6XzVhmInoKu0ld7L8tjXSrdMwMoQdGieAxaEPrrqVssh4IkKQ6kuAQ6Ks2EVXDEJ5xl0DE0UI29i4uLrdaxrhFoDu84cb26e6ZYE0d+PgpR3W+YTi/Xreeai+a3sbEhm7XqKDC0BLefua1xZmnq8sPsL4p7KlQEw0nyoDr+N5NBbmEppNGYGDVm2v7lCQQfZOXJo6bNjOtXbQsVs1otmuluPVTAO0hDiVcuXcv8ccPzoSj/bIrqLy2v+YQKyCKiep9ZALnaxveeEHoVInuswKGqgoEFc4digeoBre1SCxnGHiMbe8IT2MtPHSwP2ScX0a2tHQsJTcDrKtwz+gXP9b4RyxeEkjvDv6MPPmBNLhctmOURs4oxqUwUsoFv/yGPC1O+NWxE+TQdWhHwqAxaURdUB7IfExR4uLF7axZwJQoKsCekZQDzx1e5KEMW7WaX/CL5/Zg1t4Jpg9vDsJ5O+LwseJgACTdZJ7QU4gKWUyAtBH4C3oipYv1efV0fSfE8izTt31QLtPSiwoJ+wh6YVng2yBLHv5a/PRocmqnHTNUIlkPPLrXvPPE40asQZVIPp2rSY0WnKef6QBGxaiOA9G8UixyVtMegsISQpaS8uSS6TVeptweF/00WGwmmmQm6BOqWGl+8WuFqYf5pED5A25Q89UIkWKoWBF4jHRv2bvcQpssarvrS09UOAi5H8lnAqKSsyu9pvd0lmhHCe3Vp3QweHHyrxryQGz3xw4OVkeyPE2uKEcPWn6+8x9Uj0JQmRzC7adl1d0do7Re3EDEfTZTDMPRIxZId2nVi3cL6T0DoA70KUSQFZqluAUsrCoxr3xa2Jvh0pKYxCxQJE5XrPT3AFTYdDKruKuExyRn5PDYjivJoYsxFzMm5mdrYxPmr0exBfEbVeJQiPL7GHSWpIpMgKaekcM/+vnyPFpM+ym3XCdMK9wbvm48VKDhOIoT3b4CfLe/XHvHOlMfXHjMONBCL5VSArsRhdIdfqCVWRhvOaOXdDU6AHHRHKBp+UNdWOqcTGZ8p3xGznEE7R5tHuXyD49Kiqbz+4nP86a8b7A2lCPP/F/QmRLQWp4DWCZmr7OqIPbSjXd1W4qtyNvB+9TVdBDZ+I0tzaE1xL0qMfspFau9syyKVB5D5bLcMDtEYCbU0hUgM66Y+U+NF7hRZWRXrpYA2FDDSPkskyWdVKBZEzWp7gu4ZrcjmYoj/WSmtueOLhlEnHVtZ8+11a0tH03Ysjwsa+zt06havI7Smry5T1cr0aGsP7lIolGUVgu/tWEAh0vnccxR7RjNJWGb9O6mHceiDbm1sK2e/fG7FAQqRvrNUZ/QiREHhSeybPZerpu4rULTd8f3Up8dV0RazsuDLkyw+NqN69DKBfnBH1+YwsLP6drCTB7SFTTROZKoiikxJLPCvyQM1bIJGLpixIuIaraZFcwbA94vGSgGhiRqViIL0aFuMtzadg+DQxOrb62J5ULAcrX6e+whbPtQFr4rFuZgf2hakAvlFmc4DIAU05vWEBm1pmczq33xZYW4RHPAIgV+XTHikdKYNaQ/fHgjgEdo7ztyGj+cM1Ok8bOTMl8oNLWtyWxtqC4z68vLE7tLibZ4sOyUXTvtH6js7j8Tj3RhNw2OiN36s3ekHD5Oz5WKhXN8LS8AJe6tFOrxpQrUnppXdmw9fgSPngtWtLGpUaOG8qaWnmEzu2YEgfgwoB6NV3ACavDZoSc3WsBiW703NB59lYGhuwkWIvh+gQfCUmdS/HQumKGFlIZLkgYd/+d+jN5DUdHq9GPfhAZZB65vwXsnyUV4qYGvVCKKxocUmZvL9uWtbB0ir6Xn5Gj6ZNkmLLncdDIS8DBmMWryPeT1CHNSgro7ShAGu7Ix7CETcfQivfHWKbf9ocq3pvLPxLJQqZhG11SV9MQOtw1/3XYac9HyYuOwgO/P1zH+ESOrK4xMiUyO+P/X4pQcZBdll5RVDDPb2iTS9SCKiKkJ8AaoEmxaNrjldHkFnAGt2XISf0R+mUHdyJ+4nZPAV2zxdVQXMKoAJE7rB29M0h92PIffMpcI90xAVixZMHw3R1N8eDGJlNDBOsRhFJdCtm+6mOoUnfEVbtiqPTRFolXlceaD9RC3ossPlPs9QtvlQEATRejfFG0g+mTuo2jEU53Q1QO7aLtpwFsL3vqExLQpZWLrVE6Jp6QtFk1MDfQLs/HiydPryPZaalAUX/CJgDIrR+RrEaM3Oi+yQ+x3o0akFHFg9rfI4Cpq1uhXLcjLyYcef1/hY786PNYtRUFgSewfLIoQsWBSh/v3bwrIa9jfSB798OJEvP4mLToOzPnd5uXzx+gjop+WFEIFosf984jqcv3wPHB1tQNN2IE+SxydENPuFJjRtXs+R5N/JZ4ykKhGi3jS/BExQQNYvGgPTh+qwvQCef/NOAtyscAmoIZN7pPrqHhpUxLRHDOsEZ9bPqDHdCegORt7R4J4RWEtp+Ygq7jReUDFYWyZDQVOf2tfGiJ6t+aLHB9SQlQPrjAx5cOPvp2+xhZN66FY58PyQ6FR4ZsURxi1FRdmSG0izhKlZ+ZCSXQjJSdmKmCDgIrTk1eGgOrD51esjpP0eIbxC372fArbTNjMKhnRDV4TGtpKw4XrfiOER2nxsjMr8CVfhfWumwnPLjwDt4uB5KRLMxn7NKNK6bycHaEnbl2Cndw0tnUB8nsk02YAuc3hYIrkwbHzfKndqx4opMG/NMSjEzoQCYEngRqAQ0/v2zLEeUIhCALrsF1G4i7AMoYyBW1cHCNj20j9KhCrYt3oaTFtxGNITs/j6zWEhCdC/iwPr6mLH1wSWYKdNK/eDo1IhGJ9tCW2aVlwGqeii0k6aw3vWbTfLhqRBhIhukPeImiJVlW+Nb5Kl2OKQyeS7HaIV1Asr0Weo3pP7q/vcPO6mIqhOW9pMPmNQ+eI0xXvTrG0bw39eHAxf/mdkrQU89qk2sGXXJXnjUrZQUGDoxZGaFv55Xnsgvw++yZcBjOtT+9iWMqN6OsPv9F4yS+XYAYmnt+/8HUAhqjWNMtpxAC22dLQQ/tYUfyUp/qC/jeRLXtqgqCyZM1Crhbh/zbMwb+1xiMbKmh6bAT/u8lNYmYzPFnEX1tgI+g105eEPX1C55RbzyGtVKp5fYR1idvgsHp7Dz9UALdg8s2E2e2/jObgaHAfFaShI50PB0zOMD77Ln7/i3jGfLm4OsA7rl7IIEdOHdpBOfDOTLfnhPARjo02NSYPDKMCH6Si+X5aiLin25pk2thMc++J5rXWp8l5LdLtXXiY13Ke2cqFnoSmYckg3R+n0N7PYki3nwQ87yeK0XPC9EA6+Bner3inIlO4JO5Gnx3SBv7+q3knztOk6WF9KynQMjqwnDSJErWybQOduTnw3OV2gGaUm5sbQ2dkWnhnSnu9/o+1Y2mo1HXs5SYdoWuqxjbEC2ds0hol9XOB9LS9t1ASNk4wY1pGlpuZUuxZt++rWQT2amrZh6OBgDUZ4DwzFyg7LoLa9n1WZOrg9BPLV5IbVxQ8bdJmOcTk93FpCufIeRxphYGVhRtumkhsKs2vZhG1w11bSg0Nvw+rffNjJy/chFl3frPwivpWHvZU5uLS0hulDOsD7M+TiHBGfyULRSnJRmZEk6PmlYYXvSjM7OtIJhTK1qyNY1BD5TGsGr/z2Cl+sedQnHMJRQNLQEqL35NG78Kzxmq6ONPPXDt6apn3MkcbAbu94lW/KRulExKZDGopqAVpRlphGc6zTvTu1pP2ia93ruU/HFpDdtBG3HnWhs4stFGQ6QmMdAxDbowvVuasTSNh2bCw1t7V+nVpKF7e+CAe9wvj9UHBwGnomuWj1mKGhQO2uBbYPmvGbPrwTt8xV06CA4M5Y/vR2ZWrbT4IGESLa1wY/DZGUGj6b6rcosy5cqMPbXkm48FOv69U3DdrKAz/1ykNNrH11uLRW8YqloLAk6OemeQzs8H+naS23R3l+P/EtMcbrdCytGJ9XxxX0mqBN2RY8yvIaJTRtRVsTu5bXPkCuzIa3RkvwVi1jqApmjnKTZj7iXuiTB7hKkw/Vr27XFb0GNAr+f9AmQgJBQyCESCAQ6B0hRAKBQO8IIRIIBHpHCJFAINA7QogEAoHeEUIkEAj0jhAigUCgd4QQCQQCvSOESCAQ6B0hRAKBQO8IIRIIBHqnwYTIPz6f7Q1Og6tJ9GYECdxszeDpDk3h+U5NKxf2rb2YxHzvZUORgQSlyqvL6X/LymHRoJYwr6tNtYWAP1xJYZ7RuZCYUwIGhhJ0wXQntW8K0ztWpbs3JIPtuJgIU/vYw6K+9moLCQ+EZrDfLj2E1eOdYFjrJvz3cfsjWXmZDPLK5FuGNDIxhEEOFrBuVM0bqa+8kMB84vKgBM/tamcOz7lZwyRXK63nLPeMZ954vKycQeumpvC0qyW81MP2H7mfjUCgLxpEiHaHpLOXjkahUBhAGxv55mSHwjJgl28irH+uLftoYAve8AIS8sEzOB2aYoO3baR0aS5EMihSer3t4bBMtvhcLCSkFEIzW3OwNpNvhv/7zXT43TMefp7fib3eS96gw9MLwfNWOjg7at42IiK9iF934cCq7Tw8wjP5fkhtWjTiu5zG55WCd1gm/BCYzPa90A4mq4jLNwHJbDnmh7bjaYsCRLt27AnJgO3+D2FmX3t2YHr1vW68Y3LZtP2RkF1UDu3szfl2MBEPcuAIHu89Mo/teLrmLVgFgn8TDSJE75yJBUdLE4hdXH1HwQ894lhzi6odDxsZy1+hs2mcE7zUvZnWhugXl8fmHroPpahQ255vB2/2tqt27KxD95jyFslmtAm/uRGYG2vek8dU8bux8kn4XTPMW9TbVe8Q+8L/Ifvk72hY5pVAQlR56A9XU9my41HQEYXul6ltYJhT48pzZhyNYgdRXOjdoUeUxOg99zgoLJXBuZc6wrg2lpXff4ZWodET2t9ZIPh/od5C5BWdy3IyimHhGEe1374dq/m1y+W1vCFiuXcClOaXwmdTXdREiDgwo/bX3DwKKwa1kMgVDEXLTZmVXvFg3tgEwt9Rfy/9oefaSoNzS9jRwGTY17Epm9NF7lreTi6EMShmyiJErBraUqiQQKBCvYXIULGtZnhqoc7n1PamGr/oXLBFl2nl4CffaE2MpGoZ3ILClJ1WBLMGqe/SWMG7/ezBPzwLdqJ7iELEv6MNExOy9Ps+cYHg/4V6C9Fw5yZSB0cLdgYb4XQjA7agezN4pkNT7QKCbbyJifY3uWJjZpBbCj3b1e8li7qg+m7As1HZLC6lCBxsq7bhvPawgLuTI1pr37Z0ZmcbaZ6VCbuTViXGY9tawtnraTD0j7sMrTqYozIILxAIqmiQMaKdz7jAvD8fwLHAFDiGja+5nRmbiG7J69gAB7ayqGyA/H9MDGDn7TS4/rBAbnaUy6CDvTm8ophJis4u5hu0NzV7vJEF9IaLvOJyWHI+ntE+11lF5XA0LANkMhl8MrhqN8LITLlVQ2NgNWFlagiJ2VWv1Dkzq73UJ7+M+d3JAL/QTHijmSkb38YSXu5lB5PaWQpREgiUaJDWPrBVY+n+om7wfVAK++tuFvjE58FO30Q4eDsddjzbls3sbF3V8IwM4ExENpxBV4aDYjC8szUJEf9nmcIrUm2ph8My2NwjUWBgbAgW6Pa0sjaF26/VvAl8TdBrd2gweYNfkvwL/H9At2zrs23hLeVxKS350YiKy3l1oZu041YaO4H3eiE2D44EpcCR4HRYP6F15UyiQCBo4IDGd/vZSzReQrx8Mprt9E+GNShIKET8O95Oi8rguyku8EH/5hoborOlMW/1uSXVX5fygpuNdG9UCUstKIONmKah0gwZH/xm6q5WBQZKbxmqPKdMBtaNjCBjSU9+1vvucWyzVwIabNUTcUXB88e/k/JqfuVLDgqqg5W61fQyWnovK0R2pXciW3chgeKp4KOB2secBIJ/G4/N/6E4mUux+exumsogNoqBrbn2y3awMQOwMIJbKQVqvy0fLLciNl5KYkZKgsHHnAwlbtRoorhc/kpkM6PqImOo9HbUTeOcpN+vp7LVKEav9qx69U2P5uY83sgPrbyFPTW/Eud4RBYrzSmBLs7ax5GIz0c4SNeTC9iZW2nwd2Q2m9JeeyCkQPBv4rEOxNDrwTS9Crmmd3bR4HeXVo3Znahs+OlGKnujl/r0vSqdm6FYmBtCUGK+xt8volsEZoZqg+iquXitjz1sPBsDq30T2dph8lf1kuX2qU8i+/N2BomrxvTRJeXm1ryutb/PisdSoclnJmKJBIJK6i1Eq7CR+kXlwIWXO1VfmnE1hYXG5MGA9uov3TPS5kMpWDO0JcyIyYUVHnFkPbHnO1WNMblH5TBq9MpR2OPbWUrdnJuw6xFZsPxCAvtyZNUyja3XUpl7SAb0ca19Fm7DGEfpx6Bk9hMKCwpR5fefjWwF7x25D31+DWXbJjtDP4eqAfhXT8WwC2jhTHjKDuYrgjT3hGSw7y4mwneTnGGUc5PKY0+g5XQyNBPs7cxpVk0okUCgoN5CZN/ICLzDs0Bae5W1szXjIlOAPlLcwwKwszaFDWOdKo+l78kMWXw+nkcxV0uosAzmokVCAX8vuFlLm6a1Ycvd4+CF3RHQukUjRlHTMsbgQaZ8Vq0LNmZlaOC6/ZZgtv5cHPyELhZFdNO4TVJSPrRq3gi2jm9dPeNF5ZBjpB6JPRfdr9/PxsJijzi2URGQ+W5feymvVMZWYn76/xoK7e3NGVl68dklkJ9VAtP7NoejM9pVCosdup43Ewtg9PZwcLYzYxT5XYp5jkouAFO8jy0TnNSuKxD8m6m3ENEi094tG7G/72bBZXSN8rGBN7cwhf9gg/5EJYq4v4MFFHW14YteS1TdM5khmCq5K+9huviBzy8mMW90rbIKS8EMfb0Jba1gaOvGQGKlmpfIRd2krVdSWACKQERGEXRsZgaDUdyWDVafoRrZqSlYaggR+G2SsxSVUsgKSqvnj6Ku8cMXsfrG50FxGYPn3ZrC9E7Wai4fWWjss37wGbp4PnH5PO/G6Bq+gFbWerS6dCpYgeBfRIOMEQ12bCwN1rLgVJk1w1CYhtXtjaErUcxW1uH4t1HA3tbhOK8XO2oVBK8FnbT+9uVo3YVk1TAHaZWuBwsE/2LEfkQCgUDvCCESCAR6RwiRQCDQO0KIBAKB3hFCJBAI9I4QIoFAoHeEEAkEAr0jhEggEOgdIUQCgUDvCCESCAR6RwiRQCDQO0KIBAKB3hFCJBAI9I4QIoFAoHeEEAkEAr0jhEggEOgdIUQCgUDvCCESCAR6RwiRQCDQO0KIBAKB3vkfjCacaYqWdYcAAAAASUVORK5CYII=" name="Picture 1" align="left" hspace="12" width="186" height="62" border="0"></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">Gastos
					Funerarios (Venta Cruzada)</font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="center"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">03/09/2015</font></font></font></font></p>
				</td>
			</tr>
			<tr>
				<td width="225" height="7" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Canal
					de Venta:</b></font></font></font></font></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Proveedor:</b></font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: none; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt"><b>Pagina:</b></font></font></font></font></p>
				</td>
			</tr>
			<tr>
				<td width="225" height="7" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: 1px solid #1f497d; border-right: none; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0.12cm; padding-right: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">Telemarketing</font></font></font></font></p>
				</td>
				<td width="226" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: none; border-right: none; padding: 0cm">
					<p lang="es-MX" class="western" align="left"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="2" style="font-size: 10pt">BBDD
					Propias</font></font></font></font></p>
				</td>
				<td width="225" bgcolor="#ffffff" style="border-top: none; border-bottom: 1px solid #1f497d; border-left: none; border-right: 1px solid #1f497d; padding-top: 0cm; padding-bottom: 0cm; padding-left: 0cm; padding-right: 0.12cm">
					<p lang="es-MX" class="western" align="center"><font color="#1f497d">&nbsp;<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="2" style="font-size: 10pt">~
					<sdfield type=PAGE subtype=RANDOM format=PAGE>6</sdfield> ~</font></font></font></font></p>
				</td>
			</tr>
		</table>
	</center>
	<p lang="es-MX" align="left"><br>
	</p>
	<p lang="es-MX" align="left" style="margin-bottom: 0cm"><br>
	</p>
</div>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f3864"><font size="4" style="font-size: 16pt"><b>Script
de Venta - Base Outbound BBDD Propias Sanas Pr&aacute;cticas</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Presentaci&oacute;n-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Identificarse
como Seguros BBVA Bancomer y asegurar la identificaci&oacute;n del
prospecto de venta. </i></font></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.61cm; text-indent: -1.61cm; margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt">Buenos
</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><u>d&iacute;as
/ tardes / noches.</u></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Mi
nombre es </b></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos} </b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">de</font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
Seguros BBVA Bancomer.</b></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt">&iquest;Ser&iacute;a
tan amable en comunicarme por favor con </font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
completo del prospecto}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">?</font></font></p>
<ol type="A">
	<li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
	<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">
	se encuentra: </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Pedir
	por el prospecto en caso de que no sea el que contest&oacute;.</i></font></font></font></p>
	<li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
	<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>No
	</b></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt">se
	encuentra: </font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Preguntar
	a qu&eacute; hora le pueden volver a llamar y reprogramar.</i></font></font></font></p>
</ol>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="4" style="font-size: 14pt"><b>--Introducci&oacute;n--</b></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm; margin-bottom: 0.21cm">
<font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>Aclarar
y dar seguridad al cliente sobre el motivo de la llamada.</i></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm; margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="text-indent: 0.01cm; margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">&iquest;Tengo
el gusto con el </span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><u>Sr.
/ Sra. / Srta.:</u></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
</span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos del prospecto},</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
titular de la tarjeta con terminaci&oacute;n </span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{XXXX}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">?</span></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm; margin-bottom: 0.21cm">
<font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><i>{Se
debe asegurar la confirmaci&oacute;n de la terminaci&oacute;n de la
tarjeta/cuenta con el cliente}</i></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-left: 2.49cm; text-indent: -2.49cm; margin-bottom: 0.21cm">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Introducci&oacute;n
</b></font></font></font>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><u>Sr.
/ Sra. / Srta.:</u></span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
{apellido del prospecto},</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
mi nombre es </span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{nombre
y apellidos}</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">
le hablo de </span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>Seguros
BBVA Bancomer</b></span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">,
y aprovecho esta llamada para comentarle los beneficios de nuestro
plan de protecci&oacute;n </span></font></font><font size="3" style="font-size: 12pt"><u><b>Seguro
Gastos Funerarios Bancomer</b></u></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">.
</span></font></font>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">Me
tomar&aacute; un minuto explicarle </span></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>como
proteger (se)</b></span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>
</b></font></font></font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX">en
caso de que usted lamentablemente llegara a Fallecer</span></font></font><font size="3" style="font-size: 12pt">
</font><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><b>&iquest;Est&aacute;
usted de acuerdo? </b></span></font></font><font color="#4472c4"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>{Esperar
respuesta y pasar a "Respuesta a Introducci&oacute;n"}</b></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">En
agradecimiento por brindarnos su confianza siendo ya uno de nuestros
clientes, ponemos a su disposici&oacute;n nuestro </font><font size="3" style="font-size: 12pt"><u><b>Seguro
Gastos Funerarios Bancomer</b></u></font><font size="3" style="font-size: 12pt">,
con el cual protege a sus Beneficiarios con una suma de</font><font size="3" style="font-size: 12pt"><b>
200</b></font><font size="3" style="font-size: 12pt"><u><b> </b></u></font><font size="3" style="font-size: 12pt"><b>
m</b></font><font size="3" style="font-size: 12pt"><b>il pesos</b></font><font size="3" style="font-size: 12pt">
en caso de que usted lamentablemente llegara a Fallecer, esto por tan
solo una prima mensual de </font><font size="3" style="font-size: 12pt"><u><b>$92</b></u></font><font size="3" style="font-size: 12pt"><b>pesos</b></font><font size="3" style="font-size: 12pt">.
</font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Adicionalmente
</font><font size="3" style="font-size: 12pt"><u>Sr. / Sra. / Srta.</u></font><font size="3" style="font-size: 12pt">:
</font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{nombre
y apellido del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
sus beneficiarios recibir&aacute;n </font><font size="3" style="font-size: 12pt"><u><b>$200
</b></u></font><font size="3" style="font-size: 12pt"><b>mil pesos</b></font><font size="3" style="font-size: 12pt">
m&aacute;s en caso de que usted llegara a Fallecer a causa de un </font><font size="3" style="font-size: 12pt"><b>Accidente
amparado</b></font><font size="3" style="font-size: 12pt">.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Adicionalmente
</font><font size="3" style="font-size: 12pt"><u>Sr. / Sra. / Srta.</u></font><font size="3" style="font-size: 12pt">:
</font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{nombre
y apellido del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
este servicio se ligar&aacute; a su cuenta para su mayor comodidad y usted
estar&iacute;a protegido desde los </font><font size="3" style="font-size: 12pt"><b>18
hasta los 99 a&ntilde;os</b></font><font size="3" style="font-size: 12pt">.
</font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{Contrataci&oacute;n
inicial 18 a 69 a&ntilde;os, renovaci&oacute;n 18 a 99 a&ntilde;os}</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Qu&eacute;
edad tiene actualmente?</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>ME
GUSTAR&Iacute;A QUE USTED CONSIDERE LO SIGUIENTE:</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<ul>
	<li><p lang="es-MX" align="justify" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">En
	el IMSS un plan de Previsi&oacute;n Funeraria cuesta $350 al mes, con
	nosotros usted queda protegido con $92 al mes, menos del 15% del
	costo m&aacute;s popular.</font></font></font></p>
</ul>
<p lang="es-MX" class="western" align="justify" style="line-height: 100%">
<br>
</p>
<ul>
	<li><p lang="es-MX" align="justify" style="line-height: 100%"><font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Cada
	hora se registran 60 defunciones, de las cuales, s&oacute;lo 9% de los
	finados contaban con alg&uacute;n plan de previsi&oacute;n funeraria y que m&aacute;s
	de 119 mil personas dejan a su familia sin un plan para enfrentar
	esta situaci&oacute;n y totalmente endeudados.</font></font></font></p>
</ul>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Confirmaci&oacute;n
de la Compra----- </b></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srta.</u></font><font size="3" style="font-size: 12pt">:
</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto},</b></font></font><font size="3" style="font-size: 12pt">
en este momento est&aacute; </font><font size="3" style="font-size: 12pt"><b>CONTRATANDO</b></font><font size="3" style="font-size: 12pt">
el Plan de Protecci&oacute;n </font><font size="3" style="font-size: 12pt"><u><b>Seguro
Gastos Funerarios Bancomer</b></u></font><font size="3" style="font-size: 12pt">
 con cargo a su </font><font size="3" style="font-size: 12pt"><u>Tarjeta/Cuenta</u></font><font size="3" style="font-size: 12pt">,
por una </font><font size="3" style="font-size: 12pt"><b>PRIMA
MENSUAL</b></font><font size="3" style="font-size: 12pt"> de </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>$92.00
</b></font></font><font size="3" style="font-size: 12pt">pesos,</font><font size="3" style="font-size: 12pt"><b>
correcto?</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ol type="A">
	<li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
	<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si
	la respuesta es afirmativa: </b></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Asegura
	el cierre de llamada con la </i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i><b>marcaci&oacute;n
	del c&oacute;digo de aceptaci&oacute;n</b></i></span></font></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>.</i></span></font></font></font></p>
	<li><p lang="es-ES" class="western" align="justify" style="margin-bottom: 0.21cm">
	<font face="Calibri, serif"><font size="3" style="font-size: 12pt"><b>Si
	la respuesta es negativa: </b></font></font><font color="#7030a0"><font face="Calibri, serif"><font size="3" style="font-size: 12pt"><span lang="es-MX"><i>Sondeo
	del motivo, realiza vencimiento de objeci&oacute;n mediante labor de venta
	con escenarios reales y utiliza alguno de estos cierres:</i></span></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ul>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Est&aacute;
	de acuerdo en la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
	del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{nombre
	del producto}</b></font></font><font size="3" style="font-size: 12pt">
	con cargo a su tarjeta?</font></font></font></p>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Podemos
	iniciar con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
	del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{nombre
	del producto}</b></font></font><font size="3" style="font-size: 12pt">
	con cargo a su tarjeta?</font></font></font></p>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Desea
	que iniciemos con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
	del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{nombre
	del producto}</b></font></font><font size="3" style="font-size: 12pt">
	con cargo a su tarjeta?</font></font></font></p>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">&iquest;Autoriza
	que iniciemos con la </font><font size="3" style="font-size: 12pt"><b>contrataci&oacute;n</b></font><font size="3" style="font-size: 12pt">
	del plan </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{nombre
	del producto}</b></font></font><font size="3" style="font-size: 12pt">
	con cargo a su tarjeta?</font></font></font></p>
</ul>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.35cm; line-height: 115%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Marcaci&oacute;n
de C&oacute;digo de Aceptaci&oacute;n-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Cumplimiento
a normativa asegurando la confirmaci&oacute;n de la compra.</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
/ Sra. / Srita:</u></font><font size="3" style="font-size: 12pt">
</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}, </b></font></font><font size="3" style="font-size: 12pt">con
la finalidad de </font><font size="3" style="font-size: 12pt"><b>confirmar
su respuesta positiva</b></font><font size="3" style="font-size: 12pt">,
por favor necesitamos que cuando yo le indique, teclee su </font><font size="3" style="font-size: 12pt"><b>clave
de confirmaci&oacute;n de venta</b></font><font size="3" style="font-size: 12pt">
en el teclado num&eacute;rico de su aparato telef&oacute;nico, la cual es: </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{Se
proceder&aacute; a generar el folio de 4 d&iacute;gitos y se indicara al
cliente}</b></font></font><font size="3" style="font-size: 12pt">,
por favor h&aacute;galo ahora.</font></font></font></p>
<ol type="A">
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Si
	digita teclas (folio): </b></font><font size="3" style="font-size: 12pt"><u>Sr.
	/ Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
	</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
	del prospecto} </b></font></font><font size="3" style="font-size: 12pt">gracias
	por su confirmaci&oacute;n, una vez cobrada su p&oacute;liza le estaremos
	enviando un correo electr&oacute;nico o </font><font size="3" style="font-size: 12pt"><span lang="es-ES">mensaje
	de texto</span></font><font size="3" style="font-size: 12pt">, con
	las cl&aacute;usulas, exclusiones y caracter&iacute;sticas de su producto, as&iacute;
	como su clave de Confirmaci&oacute;n. </font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Continuamos
	las frases obligatorias.</i></font></font></font></font></p>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>No
	digita teclas (folio): </b></font><font size="3" style="font-size: 12pt"><u>Sr.
	/ Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
	</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
	del prospecto} </b></font></font><font size="3" style="font-size: 12pt">es
	necesario que </font><font size="3" style="font-size: 12pt"><u>teclee
	/ digite</u></font><font size="3" style="font-size: 12pt"> estos
	n&uacute;meros para confirmar su aprobaci&oacute;n.</font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
	En caso de que el cliente </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>no
	digite el folio</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
	de confirmaci&oacute;n no se puede continuar con el proceso, </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>en
	caso de vencimiento</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
	de objeciones y que el cliente </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>acepte
	digitar el folio</b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
	se cierra con la frase de la </i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>opci&oacute;n
	A, </b></i></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><u><b>si
	el cliente no desea el servicio se concluye la llamada</b></u></i></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="4" style="font-size: 14pt"><b>-----Frases
Obligatorias-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>Dar
cumplimiento a las frases obligatorias establecidas por las
autoridades y Seguros Bancomer.</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Aceptaci&oacute;n
del envi&oacute; de informaci&oacute;n contractual</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES"><u>Sr.
/ Sra. / Srita:</u></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
</span></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
del prospecto}, </b></font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">le
</span></font><font size="3" style="font-size: 12pt">menciono que la
renovaci&oacute;n es autom&aacute;tica y anual, y transcurridas 48 hr</font><font size="3" style="font-size: 12pt"><span lang="es-ES">s.
posteriores a la confirmaci&oacute;n, le haremos llegar un correo
electr&oacute;nico o un mensaje de texto inform&aacute;ndole que su p&oacute;liza ha
quedado activada, su p&oacute;liza y documentaci&oacute;n le ser&aacute; entregada en
un lapso no mayor a 30 d&iacute;as naturales por el medio que nos indique, </span></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">&iquest;Me
puede proporcionar un numero celular y/o cuenta de correo
electr&oacute;nico?</span></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>
</i></font></font></font></font>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{En
caso de contar con la informaci&oacute;n el ejecutivo deber&aacute; corroborarla}</i></font></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
</span></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>____________________</b></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i>{Deletrear
las palabras at&iacute;picas o alfanum&eacute;ricas de las que frecuentemente
est&aacute;n compuestos los correos electr&oacute;nicos}</i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<ol type="A">
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>Proporciona
	el correo: </b></font><font size="3" style="font-size: 12pt"><u>Sr.
	/ Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
	</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
	del prospecto}</b></font></font><font size="3" style="font-size: 12pt">,
	su informaci&oacute;n contractual, p&oacute;liza y condiciones generales le ser&aacute;
	enviada por correo electr&oacute;nico, &iquest;Est&aacute; de acuerdo? </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
	respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.25cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{S&iacute;,
est&aacute; bien, muy bien, de acuerdo, ok, por supuesto, perfecto,
adelante, claro, en caso de que el cliente desee el env&iacute;o a otro
mail el ejecutivo deber&aacute; capturarlo en el sistema</b></i></font></font></font></font></p>
<ol type="A" start="2">
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><b>No
	proporciona correo y solo celular</b></font><font size="3" style="font-size: 12pt">:
	</font><font size="3" style="font-size: 12pt"><u>Sr. / Sra. / Srita</u></font><font size="3" style="font-size: 12pt">:
	</font><font color="#4472c4"><font size="3" style="font-size: 12pt"><b>{apellido
	del prospecto}. </b></font></font><font size="3" style="font-size: 12pt">En
	ese caso, en un plazo no mayor a 30 naturales d&iacute;as le ser&aacute;
	entregada su documentaci&oacute;n contractual en el domicilio que tenemos
	registrado en nuestro sistema. &iquest;Correcto? </font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
	respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
	<li><p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
	<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><u>Sr.
	/ Sra. / Srita,</u></font><font color="#000000"><font size="3" style="font-size: 12pt"><b>
	</b></font></font><font color="#000000"><font size="3" style="font-size: 12pt">su
	informaci&oacute;n contractual y p&oacute;liza puede solicitarla en el SAC
	11020000 o Interior de la Rep&uacute;blica 55 11020000, &iquest;Est&aacute; de acuerdo
	con solicitarla por este medio?</font></font><font color="#000000"><font size="3" style="font-size: 12pt"><b>
	</b></font></font><font color="#4472c4"><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>{Esperar
	respuesta o afirmaci&oacute;n del cliente}</b></span></font></font></font></font></p>
</ol>
<p lang="es-MX" class="western" align="justify" style="margin-left: 0.64cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{En
caso de que el cliente desee el env&iacute;o a otro Domicilio de Entrega el
ejecutivo deber&aacute; capturarlo en el sistema}</b></i></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><i><b>{En
cualquier caso es necesario validar el domicilio para la entrega de
Documentaci&oacute;n Contractual}</b></i></font></font></font></font></p>
<p lang="es-ES" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Mientras
tanto su clave de confirmaci&oacute;n ser&aacute; su identificador provisional,
</font><font size="3" style="font-size: 12pt"><b>aplican
restricciones</b></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>
y exclusiones.</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">Para
dudas o aclaraciones </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>consulte
en www.segurosbancomer.com.mx</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
o </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>llame
al SAC 11020000.</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">Para
efectos de la </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>cancelaci&oacute;n
de su p&oacute;liza</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">,
podr&aacute; generarlos por </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>este
mismo medio</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
o por los medios y el proceso que al efecto se determinan en las
condiciones generales de su producto.</span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt"><span lang="es-ES">As&iacute;
mismo, en caso que necesite </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>reportar
alg&uacute;n siniestro</b></span></font><font size="3" style="font-size: 12pt"><span lang="es-ES">
lo puede hacer al </span></font><font size="3" style="font-size: 12pt"><span lang="es-ES"><b>01
800 874 36 83 (01 800 URGENTE).</b></span></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%"><a name="_GoBack"></a>
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font face="Arial, serif"><font size="2" style="font-size: 9pt">Seguros
BBVA Bancomer, S.A. de C.V., Grupo Financiero BBVA Bancomer, </font></font><font face="Arial, serif"><font size="2" style="font-size: 9pt"><b>Avenida
Paseo de la Reforma No.510, Colonia Ju&aacute;rez, Delegaci&oacute;n Cuauht&eacute;moc,
C.P. 06600, Ciudad de M&eacute;xico</b></font></font><font face="Arial, serif"><font size="2" style="font-size: 9pt">,
recaba sus datos para verificar su identidad. El Aviso de Privacidad
Integral actualizado est&aacute; en cualquiera de nuestras Oficinas y
en&nbsp;<a href="http://www.segurosbancomer.com.mx/">www.segurosbancomer.com.mx</a></font></font><br><br>Quedo
en espera de tu confirmaci&oacute;n y aplicaci&oacute;n, por favor que no
tengamos observaciones de ST por este tema.<br><font size="4" style="font-size: 14pt"><b>-----Cierre
de Llamada-----</b></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>Agradecer
al cliente su preferencia y confianza y mencionar las consecuencias
de omitir el pago.</i></span></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Le
reitero la importancia de contar con saldo disponible en su cuenta de
manera mensual, para el cobro de su cobertura y que usted cuente con
una protecci&oacute;n continua.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Muchas
gracias por su tiempo. Le atendi&oacute;: </font><font color="#1f497d"><font size="3" style="font-size: 12pt"><b>{nombre
y apellido}</b></font></font><font size="3" style="font-size: 12pt">.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font size="3" style="font-size: 12pt">Para
Bancomer usted es lo m&aacute;s importante y le desea un excelente d&iacute;a.</font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<font face="Calibri, serif"><font size="2" style="font-size: 11pt"><font color="#0000ff"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>INFORMATIVO:</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
Las instituciones de seguros </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>deber&aacute;n
abstenerse</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
de </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>realizar</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
cualquier tipo de </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>comunicaci&oacute;n</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
de car&aacute;cter </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>promocional</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
a los </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>Usuarios</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
que se encuentren </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>inscritos</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
en el Registro de Usuarios que no deseen que su informaci&oacute;n sea
utilizada para fines mercadot&eacute;cnicos o publicitarios </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>(REUS)</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>,
as&iacute; como de aquellos que </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>en
sus</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
respectivos </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>contratos
</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>hayan
</i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>manifestado</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
su </i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i><b>negativa</b></i></span></font></font><font color="#7030a0"><font size="3" style="font-size: 12pt"><span lang="es-ES"><i>
a recibir informaci&oacute;n o propaganda diversa.</i></span></font></font></font></font></p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
<p lang="es-MX" class="western" align="justify" style="margin-left: 1.27cm; margin-right: 0.5cm; margin-bottom: 0.21cm; line-height: 100%">
<br><br>
</p>
</body>
</html>