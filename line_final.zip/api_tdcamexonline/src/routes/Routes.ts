import { Router } from "express";
import {
  validateSurvey,
  ValSurvey,
  ValSurveyNoSale,
  validate,
  ValUpdateSurvey,
  ValCustomerInformation,
} from "../validation/validators";
import { SurveyController } from "../controllers/SurveyController";
import authenticateJWT from "../validation/authMiddleware";
const router = Router();

const surveyController = new SurveyController();

const ENVIRONMENT = process.env.NODE_ENV || "development";


if (ENVIRONMENT == "development") {
  router.use((req, res, next) => {
    let horaEjecucion = new Date().toLocaleString();
    console.log(
      "-----------------------------------------------------------------------"
    );
    console.log(
      `DEV => Tipo: ${req.method} Ruta: ${req.url} IP: ${req.ip} Hora: ${horaEjecucion}`
    );
    console.log("Body--->", req.body);
    console.log(
      "-----------------------------------------------------------------------"
    );
    console.log("Params--->", req.params);
    console.log(
      "-----------------------------------------------------------------------"
    );
    next();
  });

  router.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function (body) {
      console.log("Respuesta enviada:", body);
      return originalJson.call(this, body);
    };
    next();
  });
}

router.post("/dataInsert/:user_id",authenticateJWT,validateSurvey(ValSurvey),surveyController.createSurvey);
router.post("/dataInsert_noSale/:user_id",authenticateJWT,validateSurvey(ValSurveyNoSale),surveyController.createSurveyNoSale);
router.get("/customerInformation/:user_id",authenticateJWT,validateSurvey(ValCustomerInformation),surveyController.customerInformation);

/**Estas ligas son para impulse, no son publicas */
router.get("/getInfoSales", surveyController.getAllSurveys); //Ventas
router.get("/getInfoNoSales", surveyController.getAllSurveysNoSales); //No ventas
router.get("/getData", surveyController.getAllSurveys);
router.post("/updateSurvey",validate(ValUpdateSurvey),authenticateJWT,surveyController.updateSurveys);
router.post("/updateMassSurveys",surveyController.updateMassSurveys);


export default router;
