require('dotenv').config();
const express = require('express');
const app = express();
const cors = require('cors');
const path = require("path");

const UseRoutes = require('./src/routes/routes');


const port = process.env.PORT;

const corsOptions = {
  origin: '*',
  methods: 'GET, POST, OPTIONS, PUT, DELETE',
  allowedHeaders: 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method',
  credentials: true
};

app.use(cors(corsOptions));
app.use(express.json());
app.use('/apiV1', UseRoutes);


app.use("/v1",express.static(path.join(__dirname, "src/public/v1")));

app.listen(port, () => {
  console.log(`Servidor corriendo en el puerto ${port}`);
});

module.exports = app;
