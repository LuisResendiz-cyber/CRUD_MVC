const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {

const baseQuery = `BEGIN XSP_VERIFYPASSWORD_CAD_B(:uid_, :pwd, :resultado, :userid); END;`;

   console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.u_user || !context.v_password){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  }else{
    //console.log("Parametros correctos");
    //Se asignan los valores respecto a los parametros del SP
    binds.uid_ = context.u_user;
    binds.pwd = context.v_password;
    binds.resultado = {val:context.resultado,dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
    binds.userid = {val:context.userid,dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
//  binds.pwd = {val:context.password,dir: oracledb.BIND_IN, type: oracledb.DB_TYPE_VARCHAR};
    //binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecute(query, binds);
      console.log("\n", result, "\n");
    return result;
  }


}

module.exports.find = find;
