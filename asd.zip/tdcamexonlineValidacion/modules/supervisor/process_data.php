<?php

# @uthor Mark
# Process_data File en NOMINA

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize_nolayout("supervisor", "");

$action = $_REQUEST['act'];
$header = "modules.php?mod=nomina&op=activacion";
$usr_id = get_session_varname("s_usr_id");
$s_usr_nomina = get_session_varname("s_usr_nomina");

if (isset($action) && $action == 1) { # MUESTA EL REPORTE DE PRODUCTIVIDAD
    $tipo_reporte = $_REQUEST['tipo_rep'];
    $tipo_reporte1 = $_REQUEST['tipo_reporte'];
    $fecha_del = $_REQUEST['fecha_del'];
    $fecha_al = $_REQUEST['fecha_al'];
    $turno = $_REQUEST['turno'];

    if ($tipo_reporte1 == 1) { //Productividad
        echo "<table border='0'>
                <tr style='font-weight:bold;'>";

        echo "<th>Supervisor</th>
                    <th>&nbsp;</th>";
        if ($tipo_reporte != 1) {
            echo "<th>Agente</th>
                    <th>&nbsp;</th>";
        }
        echo "<th>Asistencia</th>
                    <th>&nbsp;</th>
                    <th>Horas Trabajadas</th>
                    <th>&nbsp;</th>
                    <th>Ventas</th>
                    <th>&nbsp;</th>
                    <th> Autenticadas</th>
                    <th>&nbsp;</th>
                    <th>No Autenticadas</th>
                    <th>&nbsp;</th>
                    <th>Seguro Desempleo</th>
                    <th>&nbsp;</th>
                    <th>Aprobadas</th>
                    <th>&nbsp;</th>
                    <th>Recuperadas AP</th>
                    <th>&nbsp;</th>
                    <th>Recuperadas AU</th>
                    <th>&nbsp;</th>
                    <th>Reg. Tocados</th>
                    <th>&nbsp;</th>
                    <th>Cont. Efectivos</th>
                    <th>&nbsp;</th>
                    <th>SPH</th>
            </tr>";

        $rs_reporte = get_reporte_productividad($tipo_reporte, $fecha_del, $fecha_al, "", $s_usr_nomina, $db);
        $i = 1;
        while (!$rs_reporte->EOF) {
            if ($i % 2 == 1)
                $color = "silver"; else
                $color = "white";
            echo '<tr bgcolor=' . $color . '>';

            echo '<td>' . $rs_reporte->fields["SUPERVISOR"] . '</td>
                    <td>&nbsp;</td>';
            if ($tipo_reporte != 1) {
                echo '<td>' . $rs_reporte->fields["AGENTE"] . '</td>
                    <td>&nbsp;</td>';
            }
            $autenticadas = $rs_reporte->fields["AUTTIT"] + $rs_reporte->fields["AUTTITPROCESOS"];
            $recuperadas_au = $rs_reporte->fields["RECTITAU"] + $rs_reporte->fields["RECTITAUPROCESOS"];
            echo '<td align="center">' . $rs_reporte->fields["ASISTENCIAS"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["HORAS_TRAB"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["VENTIT"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $autenticadas . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["NOAUTTIT"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["SEG_DESEMPLEO"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["CANTAP"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["RECTITAP"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $recuperadas_au . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["LLAMADAS"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . $rs_reporte->fields["CEFECTIVOS"] . '</td>
                    <td>&nbsp;</td>
                    <td align="center">' . number_format(($rs_reporte->fields["AUTTIT"] > 0 ? ($rs_reporte->fields["AUTTIT"] + $rs_reporte->fields["RECTIT"]) : 0.1 ) / ($rs_reporte->fields["HORAS_TRAB"] > 0 ? $rs_reporte->fields["HORAS_TRAB"] : 0.1 ), 2) . '</td>
                    <td>&nbsp;</td>
            </tr>';
            $rs_reporte->MoveNext();
            $i++;
        }
    } else { //Canceladas
        echo "<table border='0'>
                <tr style='font-weight:bold'>
                    <td>Fecha</td>
                    <td>&nbsp;</td>
                    <td>Nota de Validaci&oacute;n</td>
                    <td>&nbsp;</td>
                    <td>Supervisor AVS</td>
                    <td>&nbsp;</td>
                    <td>Nombre AVS</td>
                    <td>&nbsp;</td>
                    <td>Validador</td>
                    <td>&nbsp;</td>
                    <td>Solicitud</td>
                    <td>&nbsp;</td>
                    <td>Producto</td>
                </tr>";
        $rs_reporte = get_reporte_canceladas($tipo_reporte, $fecha_del, $fecha_al, "", $usr_id, $db);
        $i = 1;
        while (!$rs_reporte->EOF) {
            if ($i % 2 == 1) {
                $color = "silver";
            } else {
                $color = "white";
            }
            echo '<tr bgcolor=' . $color . '>
                    <td>' . $rs_reporte->fields["FECHA"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["RAZON"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["NOTAS"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["NAM_SUP"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["NAM_AGENTE"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["NAM_VALIDA"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["CUSTOMERID"] . '</td>
                    <td>&nbsp;</td>
                    <td>' . $rs_reporte->fields["SURVEYID"] . '</td>
                    <td>&nbsp;</td>
                  </tr>';
            $rs_reporte->MoveNext();
            $i++;
        }
    }

    echo "</table>";
    die();
} else if (isset($action) && $action == 2) {

    $usr_id = get_session_varname("s_usr_id");
    $id_solicitud = $_REQUEST['id_solicitud'];
    $n_agente_ant = $_REQUEST['nomina_ant'];
    $n_agente_nvo = $_REQUEST['nuevo_agente'];
    ECHO 'Sol: ' . $id_solicitud . '<br>Otro--' . $n_agente_ant . '<br>Nomina--' . $n_agente_nvo . '***';

    $asigna_venta = set_asigna_venta_nvoagente($id_solicitud, $n_agente_ant, $n_agente_nvo, $db);
    echo 'Asigna: ' . $asigna_venta;

    if ($asigna_venta == 1) {
        set_traking(get_session_varname("s_usr_id"), 'ASIGNO SOLICITUD', get_session_varname("s_usr_maquina"), $id_solicitud, $n_agente_ant . ',' . $n_agente_nvo, $db);
        echo '<font color="blue">Se libero correctamente la sesion del usuario </font>';
        $header = "modules.php?mod=supervisor&op=resultado_venta&sol=" . $id_solicitud . "&asigno=" . $asigna_venta;
    } else if ($asigna_venta == 2) {
        $header = "modules.php?mod=supervisor&op=resultado_venta&sol=" . $id_solicitud . "&asigno=" . $asigna_venta;
        echo '<font color="red">No se pudo liberar la sesion del usuario </font>';
    } else {
        $header = "modules.php?mod=supervisor&op=resultado_venta&sol=" . $id_solicitud . "&asigno=" . $asigna_venta;
        echo '<font color="red">No se pudo liberar la sesion del usuario </font>';
    }
    die();
} else if (isset($action) && $action == 3) { # Muestra seguimiento de agentes
    $nomina = $_POST['nomina'];
    $tipo = $_POST['tipo_rep'];
    $fecha_del = $_POST['fecha_del'];
    $fecha_al = $_POST['fecha_al'];

    $rs = get_seguimiento_agente($nomina, $fecha_del, $fecha_al, $tipo, $db);

    if (!$rs->EOF) {
        $fieldCount = $rs->FieldCount() - 1;
        echo "<table border=\"1\">\r\n";
        echo "<tr>\r\n";
        for ($i = 0; $i <= $fieldCount; $i++) {
            $f = $rs->FetchField($i);
            echo "<th>{$f->name}</th>\r\n";
        }
        echo "</tr>\r\n";
        $row = 0;
        while (!$rs->EOF) {
            $color = '';
            if ($row++ % 2 == 1) {
                $color = ' bgcolor="silver"';
            }
            echo "<tr $color>\r\n";
            for ($i = 0; $i <= $fieldCount; $i++) {
                echo "<td";
                $f = $rs->FetchField($i);
                if (in_array($f->type, array('CHAR', 'VARCHAR2'))) {
                    echo " align=\"left\"";
                } elseif (in_array($f->type, array('NUMBER', 'INT'))) {
                    echo " align=\"right\"";
                } elseif (in_array($f->type, array('DATE'))) {
                    echo " align=\"center\"";
                }
                echo ">{$rs->fields[$i]}</td>\r\n";
            }
            echo "</tr>\r\n";
            $rs->MoveNext();
        }
        echo "</table>\r\n";
    } else {
        echo "<p class=\"label\">No hay registros con ese criterio.</p>\r\n";
    }
    die();
} else if (isset($action) && $action == 4) { # Muestra seguimiento de agentes
    $solicitud = $_POST['solicitud'];

    /* $tipo:
     * 1 = Resultado de búsqueda,
     * 2 = Teléfonos
     * 3 = Historia
     */
    for ($tipo = 1; $tipo <= 3; $tipo++) {

        $rs = get_seguimiento_solicitud($solicitud, $tipo, $db);

        if (!$rs->EOF) {
            $fieldCount = $rs->FieldCount() - 1;
            echo "<table border=\"1\">\r\n";
            echo "<tr>\r\n";
            for ($i = 0; $i <= $fieldCount; $i++) {
                $f = $rs->FetchField($i);
                echo "<th>{$f->name}</th>\r\n";
            }
            echo "</tr>\r\n";
            $row = 0;
            while (!$rs->EOF) {
                $color = '';
                if ($row++ % 2 == 1) {
                    $color = ' bgcolor="silver"';
                }
                echo "<tr $color>\r\n";
                for ($i = 0; $i <= $fieldCount; $i++) {
                    echo "<td";
                    $f = $rs->FetchField($i);
                    if (in_array($f->type, array('CHAR', 'VARCHAR2'))) {
                        echo " align=\"left\"";
                    } elseif (in_array($f->type, array('NUMBER', 'INT'))) {
                        echo " align=\"right\"";
                    } elseif (in_array($f->type, array('DATE'))) {
                        echo " align=\"center\"";
                    }
                    echo ">{$rs->fields[$i]}</td>\r\n";
                }
                echo "</tr>\r\n";
                $rs->MoveNext();
            }
            echo "</table>\r\n";

            $rs->Close();
        } else {
            echo "<p class=\"label\">No hay registros con ese criterio.</p>\r\n";
        }
    }
    die();
} else if (isset($action) && $action == 5) { # Muestra seguimiento de agentes
    $solicitud = $_POST['solicitud'];

    $mensaje = set_revivir_solicitud($solicitud, $db);
	echo $mensaje->fields['SOLICITUD'];
    $mensaje->Close();
	die();
}else if(isset ($action) && $action == 6) {
    /*echo "<pre>";
    print_r($_REQUEST);
    echo "</pre>";*/
    $fecha = $_REQUEST['fecha'];
    $layout = $_REQUEST['t_layout'];
        
    if(isset($layout) && $layout == 1){
        $datos = get_layoutIq($fecha,$layout,$_SESSION['s_usr_nomina'],$db);
        if($datos){
            while ($arr = $datos->FetchRow()){
                echo "<tr><td><pre>".$datos->fields['IQ']."</pre></td></tr>"; //Aqu� va lo del caracter especial
                //echo "\r\n";
                $datos->MoveNext();
            }
        }
    }
    die();
    exit();
}

header("location: " . $header);
