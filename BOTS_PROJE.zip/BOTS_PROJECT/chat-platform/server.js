require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require("path");
const http = require("http");

const { initWebSocket } = require("./src/ws/socket");

//ROUTES
const UseRoutes = require('./src/routes/routes');
const initRoutes = require("./src/routes/init");
const botRoutes = require("./src/routes/bots");


const app = express();
const port = process.env.PORT;

const corsOptions = {
  origin: '*',
  methods: 'GET, POST, OPTIONS, PUT, DELETE',
  allowedHeaders: 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method',
  credentials: true
};

app.use(cors(corsOptions));
app.use(express.json());

// Rutas API
app.use('/apiV1', UseRoutes);
app.use('/Users', initRoutes);
app.use('/bots', botRoutes);

// Archivos estáticos
app.use("/v1", express.static(path.join(__dirname, "src/public/v1")));

// 🔑 CREAR SERVIDOR HTTP
const server = http.createServer(app);

// 🔌 INICIALIZAR WEBSOCKET
initWebSocket(server);

// 🚀 LEVANTAR TODO (HTTP + WS)
server.listen(port,'0.0.0.0', () => {
  console.log(`🚀 Server HTTP + WebSocket corriendo en puerto ${port}`);
});

module.exports = app;
