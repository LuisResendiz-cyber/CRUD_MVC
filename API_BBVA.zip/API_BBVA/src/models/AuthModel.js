const oracledb = require('oracledb');
const { getOraclePool } = require("../config/configOracleSql");

const UsersModel = {
async getAcces(user) {
    const { username } = user;
    let connection;

    try {
        const pool = getOraclePool();
        connection = await pool.getConnection();

        const result = await connection.execute(
            `BEGIN BVASEG868.SPS_AUTENTICAR_USUARIO(:username, :result); END;`,
            {
                username: username,
                result: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR }
            }
        );

        const resultSet = result.outBinds.result;
        const metaData = resultSet.metaData; // nombres de las columnas
        const row = await resultSet.getRow(); // obtener solo una fila

        await resultSet.close();
        await connection.close();

        if (!row) return null;

        // Combinar los nombres de columna con los valores
        const obj = {};
        metaData.forEach((col, idx) => {
            obj[col.name] = row[idx];
        });

        return obj;

    } catch (error) {
        console.error('Error calling stored procedure:', error);
        if (connection) await connection.close(); // cerrar en caso de error
        throw error;
    }
}

};

module.exports = UsersModel;
