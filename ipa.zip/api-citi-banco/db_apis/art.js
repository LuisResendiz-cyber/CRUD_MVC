const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  // console.log('**funcion para articulo 22*****');
  console.log(context);
  // var longitud = Object.keys(context.keyrig).length;
  // console.log(longitud);
  // var key1 = context.keyrig.pop();
  // var key2 = context.keyrig.pop(-1);

  // const baseQuery = "BEGIN CITI.ART22(:v_fecha1, :v_fecha2, :v_key1, :v_key2, :v_fecha_key1, :v_fecha_key2, :rc); END;";
  const baseQuery = "BEGIN CITI.ART22(:v_fecha1, :v_fecha2, :rc); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(context.schema==''){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
  	binds.v_fecha1 = context.fecha1;
    binds.v_fecha2 = context.fecha2;
    // if (longitud == 1) {
    //   console.log('long if ' , longitud);
    //   binds.v_key1 = key1[0].toString();
    //   binds.v_key2 = key1[0].toString();
    //   binds.v_fecha_key1 = key1[2].toString();
    //   binds.v_fecha_key2 = key1[2].toString();
    // } else {
    //   console.log('long else ' , longitud);
    //   binds.v_key1 = key1[0].toString();
    //   binds.v_key2 = key2[0].toString();
    //   binds.v_fecha_key1 = key1[2].toString();
    //   binds.v_fecha_key2 = key2[2].toString();
    // }
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;
