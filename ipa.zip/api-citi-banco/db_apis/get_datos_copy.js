const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".XSP_GET_DATOS_COPY(:solicitud,:producto,:rc); END;";

  //console.log("get_datos_copy",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if( !context.id_solicitud || !context.id_producto ){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  }else{
    //console.log("Parametros correctos");
    //Se asignan los valores respecto a los parametros del SP
    binds.solicitud = context.id_solicitud;
    binds.producto  = context.id_producto;
    binds.rc        = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
//     console.log(result);
    return result;
  }


}

module.exports.find = find;
