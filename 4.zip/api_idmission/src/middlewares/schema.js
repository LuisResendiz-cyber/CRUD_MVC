const Joi = require('joi');

const token = Joi.object({
  userId: Joi.string().required(),
  password: Joi.string().required().min(10).max(30),
});


const createUser = Joi.object({
  // userId: Joi.string().min(10).max(30).required(),

  userId: Joi.string()
  .alphanum()
  .min(10)
  .max(30)
  .required(),
  password: Joi.string().required().min(10).max(30),
  // .min(10)
  // .max(30)
  // .required(),
});

const webhook = Joi.object({
  userId: Joi.string().required(),
  urlWebhook: Joi.string().required().max(100),
});



const data = Joi.object({
  PCN: Joi.string().max(200).required(),
  AGENCY: Joi.string().max(200).optional().allow(""),
  CHANNEL: Joi.string().max(200).optional().allow(""),
  SUB_CHANNEL: Joi.string().max(200).optional().allow(""),
  PRODUCT: Joi.string().max(200).optional().allow(""),
  DATE_ASIGNED: Joi.string().max(200).optional().allow(""),
  DATE_LINK_SENT: Joi.string().max(200).optional().allow(""),
  NUMBER_LINK_REVENUES: Joi.number().optional().allow(""),
  DATE_LAST_REPORT: Joi.string().max(200).optional().allow(""),
  DATE_LAST_IDMISSION_DECISION: Joi.string().max(200).optional().allow(""),
  DATE_LAST_AGENCY_DECISION: Joi.string().max(200).optional().allow(""),
  DATE_LAST_AMEX_DECISION: Joi.string().max(200).optional().allow(""),
  DOCUMENTATION_STATUS: Joi.string().max(200).optional().allow(""),
  INSURANCE: Joi.string().max(200).optional().allow(""),
  CHECKBOX_PUBLICITY: Joi.string().max(200).optional().allow(""),
  NATIONALITY: Joi.string().max(200).optional().allow(""),
  DEVICE: Joi.string().max(200).optional().allow(""),
  BROWSER: Joi.string().max(200).optional().allow(""),
  DECISION_DATE: Joi.string().max(200).optional().allow(""),
  DEC: Joi.string().max(200).optional().allow("").allow(""),
  COD_DEC: Joi.string().max(200).optional().allow(""),
  RESPONSE_CODE: Joi.string().max(200).optional().allow(""),
  CUSTOMER_TYPE: Joi.string().max(200).optional().allow(""),
  NUMBER_REJECTIONS: Joi.string().optional().allow(""),
});



const getDataImpulse = Joi.object({
  userId: Joi.string().required(),
  password: Joi.string().required().min(10).max(30),
});

const updateDataImpulse = Joi.object({
  userId: Joi.string().required(),
  password: Joi.string().required().min(10).max(30),
  status_data: Joi.number().required(),
  data: Joi.array().items(Joi.number().integer()).required()
});


const schema = {
  createUser,
  token,
  data,
  webhook,
  getDataImpulse,
  updateDataImpulse
};


module.exports = schema;
