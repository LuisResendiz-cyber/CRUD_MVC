import os
from datetime import datetime

BASE_PATH = "/storage/audio"

def save_audio(file_bytes: bytes, call_id: str) -> str:
    today = datetime.utcnow().strftime("%Y/%m/%d")
    dir_path = os.path.join(BASE_PATH, today)
    os.makedirs(dir_path, exist_ok=True)

    file_path = os.path.join(dir_path, f"{call_id}.mp3")

    with open(file_path, "wb") as f:
        f.write(file_bytes)

    return file_path
