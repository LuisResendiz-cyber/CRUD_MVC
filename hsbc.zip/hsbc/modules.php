<?php
# @uthor Mark 
# Modules Fille 

$module = (isset($_REQUEST['mod'])?$_REQUEST['mod']:"");
$op = (isset($_REQUEST['op'])?$_REQUEST['op']:"");
if(strlen($module) > 0 || strlen($op) > 0){
		include("modules/".$module."/".$op.'.php');
}
?>