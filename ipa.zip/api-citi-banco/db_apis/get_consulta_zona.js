const oracledb = require('oracledb');
const database = require('../services/database.js');
 

 
async function find(context) {

  const baseQuery = "BEGIN "+ context.schema +".xsp_consulta_zona(:u_persona, :zona); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};
  if(!context.u_persona){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{
    binds.u_persona     = context.u_persona;
    binds.zona     = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
	
  const result = await database.simpleExecute(query, binds);
  // console.log(result); 
  return result;
}
}
 
module.exports.find = find;