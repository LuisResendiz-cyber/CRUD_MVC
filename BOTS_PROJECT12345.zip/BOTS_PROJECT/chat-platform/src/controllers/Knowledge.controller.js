const KnowledgeModel = require("../models/Knowledge.models");
const LLMService = require("../services/LLM.service");
const { classifyIntent } = require("../services/Intent.service");

const ChatResolver = {
  async resolve({ session, message }) {
    if (session.status !== "bot") return null;

    const BOT_ID = 2;

    // 1️⃣ Clasificar intención con IA

    console.log(message);

    const intent = await classifyIntent(message);

    console.log("INTENT:", intent);

    // 2️⃣ Routing por intención
    switch (intent) {

      case "question": {
        const knowledgeList = await KnowledgeModel.getByBot(BOT_ID);
        const systemPrompt = await KnowledgeModel.getActiveByBot(BOT_ID);

        const aiResponse = await LLMService.generate({
          systemPrompt,
          userMessage: message,
          knowledge: knowledgeList
        });

        return { type: "BOT", message: aiResponse };
      }

      case "greeting":
        const greeting = await LLMService.generateGreeting({ userMessage: message });
        return { type: "BOT", message: greeting };
      case "opinion":
        const reply = await LLMService.generateOpinion({
          userMessage: message
        });

        return { type: "BOT", message: reply };
      case "complaint": {
        const chatResponse = await LLMService.generateChat({
          userMessage: message
        });
        return { type: "BOT", message: chatResponse };
      }
      case "farewell": 
      const chatResponse = await LLMService.generateFarewell({
        userMessage: message
      });
      
      return { type: "BOT", message: chatResponse };

      case "farewell_soft":
        const farewell_soft = await LLMService.generateFarewellSoft({
          userMessage: message
        });
        
        return { type: "BOT", message: farewell_soft };
        
      default: {
        return {
          type: "BOT",
          message: "Estoy aquí para ayudarte 😊 ¿Qué información necesitas?"
        };
      }
    }
  }
};

module.exports = ChatResolver;
