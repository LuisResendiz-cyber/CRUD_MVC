export const acsel = {
  headers: ["Acsel", "Valor"],
  rows: [
    ["PrimaRiesgo", 0],
    ["Prima Neta",  0],
    ["RecargoFraccionamiento",0],
    ["Derecho Emision",0],
    ["Impuesto",0],
    ["PrimaTotalSinDescuentos",0],
    ["Descuento",0],
    ["Prima Total",0],
    ["Primera Cuota",0],
    ["Suma Asegurada HEA",0],
    ["Suma Asegurada AGFU",0]
  ]
};




export const hea = {
  headers: ["HEA", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Neta Total",    1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",              0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Derecho Póliza",      0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["IVA",                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Total",         0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima 1er Recibo",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Pagos subsecuentes",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};

export const agfu = {
  headers: ["AGFU", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Cobertura",     0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",              0, 0, 0, 0, 0, 0, 0, 0, 0, 0],    
    ["Prima Total",         0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima 1er Recibo",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Pagos subsecuentes",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};

export const asim = {
  headers: ["ASIM", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Asistencia",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Descuento Especial",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",              0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["IVA",                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Total",         0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima 1er Recibo",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Pagos subsecuentes",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};




export const noDiscount = {
  headers: ["Monto_Prima_Anual", "Titular", "OA1", "OA2", "OA3", "OA4", "OA5", "OA6", "OA7", "OA8", "Total"],
  rows: [
    ["Prima Neta Total",      0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Apoyo por G.F.",  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Asistencia",      0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["R.P.F.",                0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Derecho Póliza",        0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["IVA",                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima Total",           0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Prima 1er Recibo",      0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ["Pagos subsecuentes",    0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  ]
};

export const tariff = {
  y4: 10,
  z4: 50000
}
export const funeralExpenses = {  
  0: { Hombres: 1.6341, Mujeres: 1.6341 },
  1: { Hombres: 1.6341, Mujeres: 1.6341 },
  2: { Hombres: 1.6341, Mujeres: 1.6341 },
  3: { Hombres: 1.6341, Mujeres: 1.6341 },
  4: { Hombres: 1.6341, Mujeres: 1.6341 },
  5: { Hombres: 1.6341, Mujeres: 1.6341 },
  6: { Hombres: 1.6341, Mujeres: 1.6341 },
  7: { Hombres: 1.6341, Mujeres: 1.6341 },
  8: { Hombres: 1.6341, Mujeres: 1.6341 },
  9: { Hombres: 1.6341, Mujeres: 1.6341 },
  10: { Hombres: 1.6341, Mujeres: 1.6341 },
  11: { Hombres: 1.6341, Mujeres: 1.6341 },
  12: { Hombres: 1.6341, Mujeres: 1.6341 },
  13: { Hombres: 1.6341, Mujeres: 1.6341 },
  14: { Hombres: 1.6341, Mujeres: 1.6341 },
  15: { Hombres: 1.6341, Mujeres: 1.6341 },
  16: { Hombres: 1.6341, Mujeres: 1.6341 },
  17: { Hombres: 1.6341, Mujeres: 1.6341 },
  18: { Hombres: 1.6341, Mujeres: 1.6341 },
  19: { Hombres: 1.6341, Mujeres: 1.6341 },
  20: { Hombres: 0.7593, Mujeres: 0.7593 },
  21: { Hombres: 0.7593, Mujeres: 0.7593 },
  22: { Hombres: 0.7593, Mujeres: 0.7593 },
  23: { Hombres: 0.7593, Mujeres: 0.7593 },
  24: { Hombres: 0.7593, Mujeres: 0.7593 },
  25: { Hombres: 0.7593, Mujeres: 0.7593 },
  26: { Hombres: 0.7593, Mujeres: 0.7593 },
  27: { Hombres: 0.7593, Mujeres: 0.7593 },
  28: { Hombres: 0.7593, Mujeres: 0.7593 },
  29: { Hombres: 0.7593, Mujeres: 0.7593 },
  30: { Hombres: 1.3904, Mujeres: 1.3904 },
  31: { Hombres: 1.3904, Mujeres: 1.3904 },
  32: { Hombres: 1.3904, Mujeres: 1.3904 },
  33: { Hombres: 1.3904, Mujeres: 1.3904 },
  34: { Hombres: 1.3904, Mujeres: 1.3904 },
  35: { Hombres: 1.3904, Mujeres: 1.3904 },
  36: { Hombres: 1.3904, Mujeres: 1.3904 },
  37: { Hombres: 1.3904, Mujeres: 1.3904 },
  38: { Hombres: 1.3904, Mujeres: 1.3904 },
  39: { Hombres: 1.3904, Mujeres: 1.3904 },
  40: { Hombres: 2.8371, Mujeres: 2.8371 },
  41: { Hombres: 2.8371, Mujeres: 2.8371 },
  42: { Hombres: 2.8371, Mujeres: 2.8371 },
  43: { Hombres: 2.8371, Mujeres: 2.8371 },
  44: { Hombres: 2.8371, Mujeres: 2.8371 },
  45: { Hombres: 2.8371, Mujeres: 2.8371 },
  46: { Hombres: 2.8371, Mujeres: 2.8371 },
  47: { Hombres: 2.8371, Mujeres: 2.8371 },
  48: { Hombres: 2.8371, Mujeres: 2.8371 },
  49: { Hombres: 2.8371, Mujeres: 2.8371 },
  50: { Hombres: 6.0147, Mujeres: 6.0147 },
  51: { Hombres: 6.0147, Mujeres: 6.0147 },
  52: { Hombres: 6.0147, Mujeres: 6.0147 },
  53: { Hombres: 6.0147, Mujeres: 6.0147 },
  54: { Hombres: 6.0147, Mujeres: 6.0147 },
  55: { Hombres: 6.0147, Mujeres: 6.0147 },
  56: { Hombres: 6.0147, Mujeres: 6.0147 },
  57: { Hombres: 6.0147, Mujeres: 6.0147 },
  58: { Hombres: 6.0147, Mujeres: 6.0147 },
  59: { Hombres: 6.0147, Mujeres: 6.0147 },
  60: { Hombres: 10.5828, Mujeres: 10.5828 },
  61: { Hombres: 10.5828, Mujeres: 10.5828 },
  62: { Hombres: 10.5828, Mujeres: 10.5828 },
  63: { Hombres: 10.5828, Mujeres: 10.5828 },
  64: { Hombres: 10.5828, Mujeres: 10.5828 },
  65: { Hombres: 10.5828, Mujeres: 10.5828 },
  66: { Hombres: 10.5828, Mujeres: 10.5828 },
  67: { Hombres: 10.5828, Mujeres: 10.5828 },
  68: { Hombres: 10.5828, Mujeres: 10.5828 },
  69: { Hombres: 10.5828, Mujeres: 10.5828 }
}


export const rate = { 

  0: { Hombres: 949.6805, Mujeres: 1011.5273 },
  1: { Hombres: 743.3025, Mujeres: 827.0273 },
  2: { Hombres: 542.3987, Mujeres: 620.868 },
  3: { Hombres: 305.7785, Mujeres: 393.3933 },
  4: { Hombres: 258.2232, Mujeres: 324.6006 },
  5: { Hombres: 228.9058, Mujeres: 279.4731 },
  6: { Hombres: 213.4988, Mujeres: 257.9701 },
  7: { Hombres: 202.0099, Mujeres: 241.6851 },
  8: { Hombres: 184.7844, Mujeres: 230.5462 },
  9: { Hombres: 172.6456, Mujeres: 217.8481 },
  10: { Hombres: 170.321, Mujeres: 212.3271 },
  11: { Hombres: 170.4491, Mujeres: 212.8239 },
  12: { Hombres: 176.7481, Mujeres: 215.3516 },
  13: { Hombres: 165.403, Mujeres: 194.2673 },
  14: { Hombres: 167.5433, Mujeres: 206.6373 },
  15: { Hombres: 167.3808, Mujeres: 224.6408 },
  16: { Hombres: 160.0194, Mujeres: 245.1783 },
  17: { Hombres: 153.7828, Mujeres: 277.7858 },
  18: { Hombres: 163.5439, Mujeres: 324.6568 },
  19: { Hombres: 161.4973, Mujeres: 348.8907 },
  20: { Hombres: 160.3037, Mujeres: 363.1541 },
  21: { Hombres: 166.2934, Mujeres: 376.3427 },
  22: { Hombres: 168.9555, Mujeres: 381.117 },
  23: { Hombres: 180.2851, Mujeres: 398.2644 },
  24: { Hombres: 191.3303, Mujeres: 411.1749 },
  25: { Hombres: 201.4725, Mujeres: 427.1912 },
  26: { Hombres: 208.1183, Mujeres: 432.0999 },
  27: { Hombres: 213.7456, Mujeres: 433.5996 },
  28: { Hombres: 223.6222, Mujeres: 438.7801 },
  29: { Hombres: 229.412, Mujeres: 443.8668 },
  30: { Hombres: 237.0733, Mujeres: 442.6358 },
  31: { Hombres: 246.0001, Mujeres: 445.2197 },
  32: { Hombres: 254.8362, Mujeres: 446.2196 },
  33: { Hombres: 257.5139, Mujeres: 442.2983 },
  34: { Hombres: 274.1083, Mujeres: 441.1485 },
  35: { Hombres: 280.4229, Mujeres: 445.9665 },
  36: { Hombres: 286.9063, Mujeres: 448.3568 },
  37: { Hombres: 299.2888, Mujeres: 454.7339 },
  38: { Hombres: 312.2681, Mujeres: 458.3771 },
  39: { Hombres: 312.1837, Mujeres: 502.0361 },
  40: { Hombres: 326.0473, Mujeres: 511.9502 },
  41: { Hombres: 341.6793, Mujeres: 536.8995 },
  42: { Hombres: 355.9927, Mujeres: 567.6199 },
  43: { Hombres: 371.1779, Mujeres: 610.4321 },
  44: { Hombres: 391.9747, Mujeres: 608.5886 },
  45: { Hombres: 411.728, Mujeres: 641.9429 },
  46: { Hombres: 435.565, Mujeres: 657.175 },
  47: { Hombres: 452.3624, Mujeres: 670.248 },
  48: { Hombres: 485.2262, Mujeres: 703.3617 },
  49: { Hombres: 513.2563, Mujeres: 718.9406 },
  50: { Hombres: 538.6524, Mujeres: 740.806 },
  51: { Hombres: 562.1238, Mujeres: 777.916 },
  52: { Hombres: 591.2256, Mujeres: 792.1919 },
  53: { Hombres: 629.473, Mujeres: 792.3169 },
  54: { Hombres: 667.1172, Mujeres: 814.5385 },
  55: { Hombres: 698.0313, Mujeres: 842.5062 },
  56: { Hombres: 724.9241, Mujeres: 849.1801 },
  57: { Hombres: 755.935, Mujeres: 876.1323 },
  58: { Hombres: 764.1493, Mujeres: 906.8182 },
  59: { Hombres: 763.3463, Mujeres: 916.7417 },
  60: { Hombres: 779.472, Mujeres: 931.4801 },
  61: { Hombres: 788.2488, Mujeres: 954.0361 },
  62: { Hombres: 795.1884, Mujeres: 970.2617 },
  63: { Hombres: 827.1616, Mujeres: 1006.1469 },
  64: { Hombres: 852.3922, Mujeres: 1046.4939 },
  65: { Hombres: 857.5726, Mujeres: 1087.9782 },
  66: { Hombres: 876.7884, Mujeres: 1107.4971 },
  67: { Hombres: 885.2528, Mujeres: 1130.6436 },
  68: { Hombres: 854.6949, Mujeres: 1120.5701 },
  69: { Hombres: 860.8877, Mujeres: 1075.4551 }


} 

export const segmentos = [
  { segmento: "Advance", porcentaje: 0 },
  { segmento: "Premier", porcentaje: 0 },
  { segmento: "Personal Banking", porcentaje: 0 },
  { segmento: "Privada", porcentaje: 0 }
];



export const descuentos = [
  { tipo: "Especial", porcentaje: 0 },
  { tipo: "Segmento", porcentaje: 0 },
  { tipo: "Empleado", porcentaje: 0 },
  { tipo: "Ninguno", porcentaje: 0 }
];

export const derechoPoliza = 150
export const asistenciaMedica = 66

export const iva = 0.16

// export const recargosPorPago = {
//   Anual: { porcentaje: 0.00, frecuencia: 1 },
//   Mensual: { porcentaje: 12.68, frecuencia: 12 },
//   Trimestral: { porcentaje: 11.42, frecuencia: 4 },
//   Semestral: { porcentaje: 9.57, frecuencia: 2 },
//   Aplicable: { porcentaje: 0.00, frecuencia: null }
// };

export const recargosPorPago = {
  Anual: { porcentaje: 0.00, frecuencia: 1 },
  Mensual: { porcentaje: 0.1268, frecuencia: 12 },
  Trimestral: { porcentaje: 0.1142, frecuencia: 4 },
  Semestral: { porcentaje: 0.0957, frecuencia: 2 },
  Aplicable: { porcentaje: 0.00, frecuencia: null }
};


export const dataForms = {
  sumInsured:0, //D5
  saAgfu:0, //D6  
  paymentMethod: 0, //D7 o H7
  segment: 0,//D8
  discounts: 0, //D9
  porDesc: 0, //E9
  customer: {},
  hea: {},

}




// =IF(D9="Segmento",VLOOKUP(D8,$Tarifas.$E$4:$F$7,2,FALSE()),VLOOKUP(D9,$Tarifas.$E$11:$F$14,2,FALSE()))
