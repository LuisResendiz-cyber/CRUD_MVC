<?php
ini_set("session.gc_maxlifetime", 60 * 60); // 60 minutos
ini_set("session.gc_probability", 1);
ini_set("session.gc_divisor", 1);
ini_set("display_errors", true);

  $dbserver = '(DESCRIPTION =
      (LOAD_BALANCE = ON)
      (ADDRESS_LIST =
      (ADDRESS =
      (PROTOCOL = TCP)
      (HOST = 192.168.1.14)
      (PORT = 1521))
      (ADDRESS =
      (PROTOCOL = TCP)
      (HOST = 192.168.1.13)
      (PORT = 1521)
      ))
      (CONNECT_DATA =
      (SERVICE_NAME = xccmtaf)
      ))'; 


/*   $dbserver = "(DESCRIPTION = (ADDRESS_LIST =
         (ADDRESS =
           (PROTOCOL = TCP)
           (HOST = 172.20.1.116)
           (PORT = 1521)
         )
         )(CONNECT_DATA =
         (SERVICE_NAME = xe)
         ))"; */
       
$dbuser = "tdcamexonlineapp";
$dbpassword = "t32358d86f7";
$dbschema = "";

$sessiontimeout = 3000;
$pagetitle = "Impulse Telecom";
$pagefooter = "Impulse Telecom";


$path = explode('/', $_SERVER['SCRIPT_NAME']);
$linkpath = "";
for ($i = 1; $i < count($path) - 1; $i++) {
    $linkpath .= "/{$path[$i]}";
}
unset($path);

session_save_path("/var/lib/php" . $linkpath);
$linkpath .= "/";
setcookie('linkpath', $linkpath);

$header_title = "TDC AMEX ONLINE";
$serveraddress = "https://{$_SERVER["SERVER_ADDR"]}:{$_SERVER["SERVER_PORT"]}";

require_once("openConnection.php");
require_once("session.inc.php");
require_once("db.inc.php");
require_once("menu.inc.php");
require_once("layout.inc.php");
require_once("functions.inc.php");
require_once("utils.inc.php");
require_once("section.inc.php");

error_reporting(E_ALL ^ E_NOTICE);
