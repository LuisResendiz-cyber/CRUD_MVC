from fastapi import APIRouter, UploadFile, File, Form

router = APIRouter(
    prefix="/calls",
    tags=["Calls"]
)

@router.post("/upload")
async def upload_call(
    audio: UploadFile = File(...),
    call_id: str = Form(...),
    agent_id: str = Form(...),
    sale_id: str = Form(...),
    duration_sec: int = Form(...),
    channel: str = Form(...),
    language: str = Form(...)
):
    return {
        "filename": audio.filename,
        "call_id": call_id,
        "agent_id": agent_id,
        "duration_sec": duration_sec,
        "language": language
    }
