const LLMService = require("./LLMService");

class IntentService {
  static async classify(message) {
    return LLMService.generate({
      systemPrompt: `
        Clasifica la intención del usuario en una sola palabra:
        greeting, question, complaint, opinion, farewell, farewell_soft.
        Responde SOLO la palabra.
      `,
      userMessage: message
    });
  }
}

module.exports = IntentService;
