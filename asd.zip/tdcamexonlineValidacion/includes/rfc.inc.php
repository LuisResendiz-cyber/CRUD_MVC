<?php
# RFC
# @uthor Mark 

//require_once("includes.inc.php");

$sino;
$malas;
$PATERNO;
$MATERNO;
$NOMBRE;
$wpaterno;
$wmaterno;
$wnombre;
$wbase;

$arre8[11];
$arre6[4];
$arre2[10];
$arre9[0];
$anex11[0];
$anex12[0];
$anex21[0];
$anex22[0];

$anex31[0];
$anex32[0];
$wrfc;
$wnumer6;


function GENERA_RFC($E_PATERNO, $E_MATERNO, $E_NOMBRE, $E_FECNACIMIENTO){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    
    ###Se instancian los objetos que interactuan con iis
    $CL_PAT;
    $CL_MAT;
    $CL_NOM;
    $DL_FECNAC;
    $FS;
    $TS;

    $DL_FECNAC = $E_FECNACIMIENTO;
    $CL_PAT = Q_spacios($E_PATERNO);
    $CL_MAT = Q_spacios($E_MATERNO);
    $CL_NOM = Q_spacios($E_NOMBRE);

    ### Se llena el $arreglo con la distinciones que hay de las personas, para que solo queden los nombre

    $arre8[0] = "DE ";
    $arre8[1] = "DEL ";
    $arre8[2] = "LA ";
    $arre8[3] = "LOS ";
    $arre8[4] = "LAS ";
    $arre8[5] = "Y ";
    $arre8[6] = "MC ";
    $arre8[7] = "MAC ";
    $arre8[8] = "VON ";
    $arre8[9] = "VAN ";

    ###$arre8[11) = "A "
    ### Para la generación del rfc no se toma en cuenta las cadenas de caracteres que contiene el $arreglo $arre6

    $arre6[0] = "JOSE ";
    $arre6[1] = "MARIA ";
    ###$arre6[3) = "J "
    ###$arre6[4) = "MA "
    ###Se llena el $arrego $arre2 con las vocales

    $arre2[0] = "A";
    $arre2[1] = "E";
    $arre2[2] = "I";
    $arre2[3] = "O";
    $arre2[4] = "U";
    $arre2[5] = "a";
    $arre2[6] = "e";
    $arre2[7] = "i";
    $arre2[8] = "o";
    $arre2[9] = "u";

    $arre9[0];
    $arre9[0] = "";
    $sino = "S";

    ### Se identifica en una sola cadena las palabras altisonantes.

    $malas = "BUEIBUEYCACACACOCAGACAGOCAKACAKOCOGECOJAKOGEKOJOKAKAKULOMAMEMAMO";
    $malas .= "MEARMEASMEONMIONCOJECOJICOJOCULOFETOGUEYJOTOKACAKACOKAGA";
    $malas .= "KAGOMOCOMULAPEDAPEDOPENEPUTAPUTOQULORATARUINCOLAPITOGATAGATO";


    ######Ademas de la cadena de palabras altisonantes que almacena la variable malas
    ###### es posible que existan mas palabras altisonantes, por lo que se toman del
    ###### archivo altisonantes que se encuentra en la misma ruta fisica del componente
    ###
    ###If Dir$(App.Path."\Altisonantes.txt") = "Altisonantes.txt" ) {
    ###
    ###     Open App.Path."\Altisonantes.txt" For Input As #1
    ###
    ###            Do Until EOF(1)    ###Lee el Archivo de Texto
    ###            contador = contador + 1
    ###                Line Input #1, vartexto
    ###                malasExtra = malasExtra.vartexto
    ###            Loop
    ###            Close #1
    ###
    ###malas = malas.malasExtra
    ###
    ###Else
    ###
    ######MsgBox "NO EXISTE EL ARCHIVO: ALTISONANTES.TXT"
    ###
    ###End If ###if existe archivo


    //---for($x = 1; $x <= strlen($malas); $x++){
    for($x = 0; $x <= strlen($malas); $x++){
        //$RePreserve;
        //$arre9[$x];
        $arre9[$x] = substr($malas, $x, 4);
    }

    //--$anex11[1];
    //--$anex12[1];
    //---$anex11[0] = "";
    //---$anex12[0] = "";
    $taba11 = "*0123456789&\ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $taba12 = "000001020304050607080910101112131415161718192122232425262728293233343536373839";

    //---for ($x = 1; $x < strlen($taba11); $x++){
    for ($x = 0; $x < strlen($taba11); $x++){
        //$RePreserve;
        //--$anex11[$x];
        //--$anex12[$x];
        $anex11[$x] = substr($taba11, $x, 1);
        //$two = ($x==0?1:$x) * 2 - 1;
        $two = ($x + 1) * 2 - 1;
        $anex12[$x] = substr($taba12, $two, 2);
    }

    $malas = "";
    $taba11 = "";
    $taba12 = "";
    $taba21 = "00010203040506070809101112131415161718192021222324252627282930313233";
    $taba22 = "123456789ABCDEFGHIJKLMNPQRSTUVWXYZ";

    //---for ($x = 1; $x < strlen($taba21); $x++){
    for ($x = 0; $x < strlen($taba21); $x++){
        //$RePreserve;
        $anex21[$x];
        $anex22[$x];
        $anex21[$x] = substr($taba21, $x, 2);
        $two = ($x + 1) / 2;
        $anex22[$x] = substr($taba22, $two, 1);
    }


    $taba21 = "";
    $taba22 = "";
    $taba11 = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ*";
    $taba12 = "0001020304050607080910111213141516171819202122232425262728293031323334353637";
    //---$anex31[1];
    //---$anex32[1];
    $anex31[0] = "";
    $anex32[0] = "";

    //---for ($x = 1; $x < strlen($taba11); $x++) {
    for ($x = 0; $x < strlen($taba11); $x++) {
        //$RePreserve;
        //---$anex31[$x];
        //---$anex32[$x];
        $anex31[$x] = substr($taba11, $x, 1);
        $two = ($x * 2) - 1;
        $anex32[$x] = substr($taba12, $two, 2);
    }

    $wanual = substr($DL_FECNAC, 6, 4).substr($DL_FECNAC, 3, 2).substr($DL_FECNAC,0, 2);

    $wpaterno = $CL_PAT;
    $wmaterno = $CL_MAT;
    $wnombre = $CL_NOM;

    If(!NACIO($wanual)) { ###revisa si la fecha es correcta y forma la que se pondrá en el rfc
        ###MsgBox "La Fecha de Nacimiento es Incorrecta"
        //$GENERA_RFC = "E-FECHA";
        return "E-FECHA";
    }

    If (!LOS3($wpaterno, $wmaterno, $wnombre)) {   ###Concatena el nombre y los apellidos con un espacio intermedio
        ###MsgBox ("El Nombre es Incorrecto")                 ###y que la longitud de estos sea mayor de 6 caracteres
        //$GENERA_RFC = "E-NOMBRE";
        return "E-NOMBRE";
    }

    $finice = FALSE;

    OCTAVA();      ###Quita del nombre y apellidos las distinciones que hay de las personas, para que solo queden los nombre
    SEXTA();       ###Quita de los nombres compuestos, los nombres que no se aceptan
    ###TERCERA    ###Obtienes las iniciales del nombre y los apellidos
    $wbase = Trim(Trim($PATERNO)." ".Trim($MATERNO)." ".Trim($NOMBRE));

    If(strlen($PATERNO) == 0 || strlen($MATERNO) == 0 ) {
        SEPTIMA();       ###Arma el rfc en caso de que solo haya un apellido.
        $finice = True;
    }

    IF(!$finice) {
        If (strlen($PATERNO) < 3 ) {
            CUARTA();
            $finice = True;
        }
    }

    IF(!$finice) {
        PRIME_SEGU();
    }

    $GENERA_RFC = $wrfc;
    $wrfc = CalcularHomoclave($wbase, $DL_FECNAC, $wrfc);
    return $wrfc;

}

function NACIO($Arg1){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Revisa si la fecha es correcta y forma la fecha que tendrá el rfc.
    ###Recibe como parametro la fecha con el formato: AAAAMMDD.
    ###$Local ll_error
    $Local1[12];
    $Local1[0] = 31;
    $Local1[1] = 28;
    $Local1[2] = 31;
    $Local1[3] = 30;
    $Local1[4] = 31;
    $Local1[5] = 30;
    $Local1[6] = 31;
    $Local1[7] = 31;
    $Local1[8] = 30;
    $Local1[9] = 31;
    $Local1[10] = 30;
    $Local1[11] = 31;

    If (strlen($Arg1) == 0 ) {
        $bb = False;
    }else{
        $todo = substr(($Arg1), 0, 8);
        $bb = True;
        ###uno = Val(substr(todo, 6, 2)) ###Dia
        $uno = substr($todo, 6, 2); ###Dia
        ###dos = Val(substr(todo, 4, 2)) ###Mes
        $dos = substr($todo, 4, 2); ###Mes
        ###tres = Val(substr(todo, 0, 4)) ###Año
        $tres = substr($todo, 0, 4); ###Año

        If ($Arg1 == 0 || $uno == 0 || $dos == 0 ) {
            $bb = False;
        }else{
            ###Checa si el numero del mes esta dentro de los 12 para que sea valido
            If ($dos <= 0 || $dos > 12 ) {
                $bb = False;
            }else{
                $bisies = $Local1[$dos -1];  ###identifica el numero de dias que tiene el mes
                $sanual = substr(($tres), 0, 4);

                ###sanual2 = Val(sanual)
                $sanual2 = $sanual;

                ###Si el mes es Febrero y el año es bisiesto le suma un dia al numero de dias que puede tener el mes
                If ($dos == 2 && (($sanual2 / 4) * 4 == $sanual2 )) {
                    $bisies = $bisies + 1;
                }
            }
        }

        If ($bb) {
            ###Revisa si el numero del dia entra en el rango de dias que puede tener el mes.
            If ($uno <= 0 || $uno > $bisies ) {
                $bb = False;
            }
        }
    }

    IF(!$bb) {
        ###  MsgBox ("ERROR EN FECHA DE NACIMIENTO")
        $wnumer6 = "E-DATE";
    }else{
        $wnumer6 = substr(substr(($tres), 0, 4), 2, 2);
        If ($dos < 10 ) {
            $wnumer6 = $wnumer6.($dos);
        }else{
            $wnumer6 = $wnumer6.substr(($dos), 0, 2);
        }

        If ($uno < 10 ) {
//            $wnumer6 = $wnumer6."0".($uno);
            $wnumer6 = $wnumer6.($uno);
        }else{
            $wnumer6 = $wnumer6.substr(($uno), 0, 2);
        }
    }

    //echo $wnumer6;
    ###La variable: wnumer6 tendra la fecha con formato AAMMDD donde el año son los dos ultimos del año esto si la fecha es valida.
    return $bb;
}

function Q_spacios($Arg1){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Elimina los espacios dobles que haya entre las palabras.
    $aree = explode(" ", strtoupper($Arg1));

    $C = "";
    For ($a = 0; $a <= count($aree); $a++){
        If (strlen(Trim($aree[$a])) > 0 ) {
            $C = $C." ".$aree[$a];
        }
    }

    //$Q_spacios = Trim($C);
    return Trim($C);
}

function LOS3($Arg1, $Arg2, $Arg3){
    ###Revisa que la suma de caracteres del nombre completo sea mayor de 6
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;

    $PATERNO = Trim($Arg1);
    $MATERNO = Trim($Arg2);
    $NOMBRE = Trim($Arg3);
    $wlos3 = Trim(Trim($Arg1)." ".Trim($Arg2)." ".Trim($Arg3));
    //---echo $wlos3 = str_replace($wlos3, " ", " "); ###Reemplaza el espacio del tabulador por un espacio normal.
    
    If (strlen($wlos3) <= 6 ) {
        return False;
    }
    return True;
}

function OCTAVA(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;

    ###Quita del nombre y apellidos las distinciones que hay de las personas, para que solo queden los nombre

    //---for ($xx = 1; $xx <= count($arre8); $xx++){
    for ($xx = 0; $xx <= count($arre8); $xx++){
        $PATERNO = str_replace($arre8[$xx], "", $PATERNO);
        $MATERNO = str_replace($arre8[$xx], "", $MATERNO);
        $NOMBRE = str_replace($arre8[$xx], "", $NOMBRE);
    }

    $arrePaterno = explode(" ", strtoupper($PATERNO));
    $arreMaterno = explode(" ", strtoupper($MATERNO));
    $arreNombre = explode(" ", strtoupper($NOMBRE));

    
    For ($a = 0; $a <= count($arreNombre); $a++){
        If (Trim($arreNombre[$a]) == "A" ) {
            $arreNombre[$a] = "";
        }
        $Elnombre = $Elnombre." ".$arreNombre[$a];
    }

    $NOMBRE = Trim($Elnombre);

    For ($a = 0; $a <= count($arrePaterno); $a++){
        If (Trim($arrePaterno[a]) == "A" ) {
            $arrePaterno[$a] = "";
        }
        $ElPaterno = $ElPaterno." ".$arrePaterno[$a];
    }

    $PATERNO = Trim($ElPaterno);

    For ($a = 0; $a <= count($arreMaterno); $a++){
        If (Trim($arreMaterno[$a]) == "A" ) {
            $arreMaterno[$a] = "";
        }
        $ElMaterno = $ElMaterno." ".$arreMaterno[$a];
    }

    $MATERNO = Trim($ElMaterno);
}

function SEXTA(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Quita del nombre que se calcula los segundos nombre que no se aceptan para la generacion del rfc
    ###esto solo si la persona cuenta con mas de un nombre.
    ###posi = InStr(" ", nombre)
    ###MsgBox nombre
    $posi = count(explode(" ", $NOMBRE));
    If ($posi > 0 ) {
        //---for ($xx = 1; $xx <= count($arre6); $xx++){
        for ($xx = 0; $xx <= count($arre6); $xx++){
            ###MsgBox $arre6[xx)
            $NOMBRE = str_replace($arre6[$xx], "", $NOMBRE);
        }
    }
}

function TERCERA(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;

    ###Obtiene las dos letras iniciales del nombre y los apellidos.

    $IniNombre = substr($NOMBRE, 0, 2);
    $IniPaterno = substr($PATERNO, 0, 2);
    $IniMaterno = substr($MATERNO, 0, 2);

    If ($IniNombre == "CH" ) {
        $IniNombre = "C";
    }else{
        If ($IniNombre == "LL" ) {
            $IniNombre = $L;
        }
    }

    If ($IniPaterno == "CH" ) {
        $IniPaterno = "C";
    }else{
        If ($IniPaterno == "LL" ) {
            $IniPaterno = "L";
        }
    }

    If ($IniMaterno == "CH" ) {
        $IniMaterno = "C";
    }else{
        If ($IniMaterno == "LL" ) {
            $IniMaterno = "L";
        }
    }

}

function SEPTIMA(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Procedimiento que calcula el rfc con solo un apellido
    ###En el caso de que la persona tenga solamente como apellidos el materno
    ###este se toma como el apellido paterno

    If (strlen($PATERNO) == 0 && strlen($MATERNO) > 0 ) {
        $unosolo = $MATERNO;
    } elseIf(strlen($PATERNO) > 0 && strlen($MATERNO) == 0 ) {
        $unosolo = $PATERNO;
    }else{
        $unosolo = $NOMBRE;
    }

    ###si el unico apellido tiene una longitud de 1 caracter se toman 3 caracteres del
    ###nombre para formar el rfc

    If (strlen($unosolo) == 1 ) {
        //$wrfc = $unosolo.substr($NOMBRE, 0, 3).$wnumer6."000";
        $wrfc = $unosolo.substr($NOMBRE, 0, 3).$wnumer6;
    }else{

        ###Si el unico apellido tiene mas de un caracter verifica que el segundo caracter
        ###sea una vocal si no es asi recorre todas las posiciones del apellido hasta que
        ###encuentra una vocal que es el que toma, en caso que apartir de que segundo caracter no
        ###encuentre una vocal pone la consonante que este en el segundo caracter

        $letra = substr($unosolo, 1, 1);
        //---for ($x = 2; $x <= strlen($unosolo); $x++){
        for ($x = 1; $x <= strlen($unosolo); $x++){
            $van = ascan($arre2, substr($unosolo, $x, 1));
            If ($van >= 0 ) {
                $letra = $arre2[$van];
                $x = strlen($unosolo) + 8;
            }
        }

        ###Lo que resulta es la concatenacion de dos caracteres del apellido unico
        ###con dos caracteres del nombre y la fecha

        $wrfc = substr($unosolo, 0, 1).$letra.substr($NOMBRE, 0, 2).$wnumer6;
        //----$wrfc = substr($unosolo, 0, 1).$letra.substr($NOMBRE, 0, 2).$wnumer6."000";
        ###  $wrfc = substr(unosolo, 1, 2).substr(nombre, 1, 2).wnumer6 ###& "000"

    }

    show_it($wrfc); ###Verifica que no se haya formado una palabra altisonante.

}

function show_it($Arg1){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Esta funcion verifica que los cuatros caracteres que forman el rfc no sea
    ###una palabra altisonante, de ser asi, reemplaza el cuarto caracter con una X

    $cuatro = substr($Arg1, 0, 4);
    
    $van = ascan($arre9, $cuatro);
    If ($van > 0 ) {
        ###$wrfc = str_replace($wrfc, substr($wrfc, 4, 1), "X")
        $wrfc = substr($wrfc, 0, 3)."X".substr($wrfc, 4);
    }

    //---HOMONI();      ###genera y pone la homoclave para el rfc
    //---DIGITORFC();      ###Calcula el digito verificador
}

function PRIME_SEGU(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###En caso de que el apellido paterno cuente con una longutid mayor de 3 caracteres
    ###se revisa si el segundo caracter es una vocal de no ser asi recorre los caracteres
    ###del apellido hasta que encuentra una vocal. En caso de no encontrar una vocal a
    ###partir del segundo caracter en el apellido se pone la consonante que este en la
    ###segunda posicion del apellido

    $letra = substr($PATERNO, 1, 1);
    //---for ($x = 2; $x <= strlen($PATERNO); $x++){
    for ($x = 1; $x < strlen($PATERNO); $x++){
        //echo substr($PATERNO, $x, 1).".";
        $van = ascan($arre2, substr($PATERNO, $x, 1));

        If ($van >= 0 ) {
            $letra = $arre2[$van];
            $x = strlen($PATERNO) + 8;
        }
    }

    ###Arma el rfc de acuerdo con las condiciones dichas anteriormente.

    //---$wrfc = substr($PATERNO, 0, 1).$letra.substr($MATERNO, 0, 1).substr($NOMBRE, 0, 1).$wnumer6."000";
    $wrfc = substr($PATERNO, 0, 1).$letra.substr($MATERNO, 0, 1).substr($NOMBRE, 0, 1).$wnumer6;
    

    show_it($wrfc);
    ###Verifica que no se haya formado una palabra altisonante.
}

function ascan($arre, $cadena){
    //echo $cadena."|";
    //global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Funcion que recibe dos parametros de entrada. uno que es un $arreglo y el segundo
    ###es un valor. Se hace la busqueda del valor dentro de los valores que almacena el
    ###$arreglo en caso de que lo encuentre se retorna la posición en la que fue
    ###encontrado el valor
    
    //echo "cantidad: ".count($arre)." -- Cadena: ".$cadena."-->";
    //For($a = 1; $a <= count($arre); $a++){
    For($a = 0; $a <= count($arre); $a++){
        If($arre[$a] == strtoupper($cadena)) {
            $ascan = $a;
            break;
        }else{
            $ascan = -1;
        }
    }
    return $ascan;
}


function HOMONI(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Con todas y cada uno de los caracteres de los apellidos y el nombre se hace el calculo
    ###para obtener la homoclave

    $valores = "0";
    $wbase = Trim(Trim($wpaterno)." ".Trim($wmaterno)." ".Trim($wnombre));

    $wbase = str_replace("Ñ", "&", $wbase);
    ###echo $wbase
    //---for ($x = 1; $x <= strlen($wbase); $x++){
    
    for ($x = 0; $x <= strlen($wbase); $x++){

        $unok = substr($wbase, $x, 1);
        If ($unok == " ") {
            $unok = "*";
        }
        
        $van = ascan($anex11, $unok);
        //---echo "|".$anex12[$van];
        If ($van > 0 ) {
            $valores = $valores.$anex12[$van];
        }else{
            $valores = $valores."00";
        }
    }

    $sumas = 0;
    //---for ($x = 1; $x <= strlen($valores) - 1; $x++){
    for ($x = 0; $x < (strlen($valores) -1) ; $x++){
        ###prod1 = Val(substr(valores, x, 2))
        $prod1 = substr($valores, $x, 2);
        ###prod2 = Val(substr(valores, x + 1, 1))
        $prod2 = substr($valores, $x + 1, 1);
        //echo "/".$prod2."/";
        ###echo "<BR>".prod1."*".prod2
        $prod3 = $prod1 * $prod2;
        ###echo "<BR>".prod3
        ###echo "<BR>".sumas."+".prod3
        $sumas = $sumas + $prod3;
        ###echo "<BR>".sumas
        ###echo "<HR>"
    }
    $sumas;

    $zumass = substr($sumas, 0, strlen($sumas)); ###10
    //die();
    ###zumass = substr((sumas), 1, 10) ###10
    //$zumass = Right($zumass, 3);
    $zumass = substr($zumass, strlen($zumass) - 3);
    $zumas = ($zumass);

    ###echo "<BR>zumas: ".zumas

    $solotres = $zumas;

    ###Print solotres."   solotres"
    ###FormatNumber((solotres / 34),0,,,0)
    ###echo "<BR>cociente: ".((solotres / 34))

    $cociente = ($solotres / 34);
    ###echo "<BR>cociente: ".cociente

    $residuo = $solotres - ($cociente * 34);


    ###echo "<BR>residuo:  ".residuo

    If ($cociente < 10 ) {
        $wrok = "0".substr(($cociente), 0, 1);
    }else{
        $wrok = substr(($cociente), 0, 2);
    }

    ###echo "<BR>1 wrok:  ".wrok
    ###Print wrok."   wrok"
    $van = ascan($anex21, $wrok);

    ###echo "<BR>1 van:  ".van
    ###Print van
    If ($van > 0 ) {
        $homo = $anex22[$van];
    }else{
        $homo = "1";
    }

    ###echo "<BR>1 homo:  ".homo

    If ($residuo < 10 ) {
        $wrok = "0" + substr(($residuo), 0);
    }else{
        ###wrok = substr(Str(residuo), 2)
        $wrok = ($residuo);
    }

    ###echo "<BR>2 wrok: ".wrok

    $van = ascan($anex21, $wrok);

    ###echo "<BR>2 van: ".van

    If ($van > 0 ) {
        $homo = $homo + $anex22[$van];
    }else{
        $homo = $homo + "1";
    }

    ###echo "<BR>2 homo:  ".homo
    ###Le concatena a los 10 caracteres del rfc los digitos de la homoclave
    ###echo "<BR>homo: ".homo

    $wrfc = substr($wrfc, 0, 10).$homo;

}

function CUARTA(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###En caso de que el apellido paterno tenga menos de 3 caracteres y por lo menos tiene uno
    ###se toma el primer caracter del apallido paterno, el primer caracter del apellido
    ###paterno y dos caracteres del nombre
    ###Reponse.write "<BR>DOS D: ".wnumer6

    $wrfc = substr($PATERNO, 0, 1).substr($MATERNO, 0, 1).substr($NOMBRE, 0, 2).$wnumer6."000";

    show_it($wrfc);  ###Verifica que no se haya formado una palabra altisonante.

}

function DIGITORFC(){
    global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    ###Hace el calculo de el digito verificador con los caracteres del rfc

    $valores = "";
    //---for ($x = 1; $x <= strlen($wrfc); $x++){
    for ($x = 0; $x <= strlen($wrfc); $x++){
        $unok = substr($wrfc, $x, 1);

        If ($unok == " " ) {
            $unok = "*";
        }

        $van = ascan($anex31, $unok);

        If ($van > 0 ) {
            $valores = $valores.$anex32[$van];
        }else{
            $valores = $valores."00";
        }
    }

    $sumas = 0;
    $trece = 13;
    //---for ($x = 1; $x <= 12; $x++){
    for ($x = 0; $x <= 12; $x++){
        ###prod1 = Val(substr(valores, x * 2 - 1, 2))
        $prod1 = substr($valores, $x * 2 - 1, 2);
        $prod3 = $prod1 * $trece;
        $sumas = $sumas + $prod3;
        $trece = $trece - 1;
    }
    $cociente = round($sumas / 11);
    $residuo = $sumas - $cociente * 11;

    If ($residuo == 0 ) {
        $dijito = "0";
    }else{
        $valor = 11 - $residuo;
        If ($valor == 10 ) {
            $dijito = "A";
        }else{

            $entrer = substr(($valor), 0, strlen(($valor))); ###10
            ###entrer = substr((valor), 1, 10) ###10
            //$dijito = Right($entrer, 1);
            $dijito = substr($entrer, strlen($entrer) - 1);

        }
    }

    ###Le contanea al rfc con homocle el digito verificador, siendo en total 13 caracteres
    ###echo "<BR> RFC: ".$wrfc
    ###echo "<BR> DIGITORFC: ".dijito
    ###echo "<BR>"
    $wrfc = $wrfc.$dijito;

}



function VERSION(){
    echo "<BR>-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=";
    echo "<BR>&nbsp;&nbsp;&nbsp;Version 4.00";
    echo "<BR>&nbsp;&nbsp;&nbsp;Desarrollado por: Ismael Rojas Arellano";
    echo "<BR>&nbsp;&nbsp;&nbsp;Fecha de Creacion: 31 de Agosto del 2004";
    echo "<BR>&nbsp;&nbsp;&nbsp;&nbsp;IMPULSE TELECOM ";
    echo "<BR>-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=";
}

function VERSION_NUM(){
    return "<BR>V 2.00 <BR>";
}


function CalcularHomoclave($nombreCompleto, $fecha, $rfc) {
    //global $sino, $malas, $PATERNO, $MATERNO, $NOMBRE, $wpaterno, $wmaterno, $wnombre, $wbase, $arre8, $arre6, $arre2, $arre9, $anex11, $anex12, $anex21, $anex22, $anex31, $anex32, $wrfc, $wnumer6;
    //Guardara el nombre en su correspondiente numérico
    //agregamos un cero al inicio de la representación númerica del nombre
    $nombreEnNumero="0";
    //La suma de la secuencia de números de nombreEnNumero
    $valorSuma = 0;

    #region Tablas para calcular la homoclave
    //Estas tablas realmente no se porque son como son
    //solo las copie de lo que encontré en internet

    $tablaRFC1['&']='10';
    $tablaRFC1['Ñ']='10';
    $tablaRFC1['A']='11';
    $tablaRFC1['B']='12';
    $tablaRFC1['C']='13';
    $tablaRFC1['D']='14';
    $tablaRFC1['E']='15';
    $tablaRFC1['F']='16';
    $tablaRFC1['G']='17';
    $tablaRFC1['H']='18';
    $tablaRFC1['I']='19';
    $tablaRFC1['J']='21';
    $tablaRFC1['K']='22';
    $tablaRFC1['L']='23';
    $tablaRFC1['M']='24';
    $tablaRFC1['N']='25';
    $tablaRFC1['O']='26';
    $tablaRFC1['P']='27';
    $tablaRFC1['Q']='28';
    $tablaRFC1['R']='29';
    $tablaRFC1['S']='32';
    $tablaRFC1['T']='33';
    $tablaRFC1['U']='34';
    $tablaRFC1['V']='35';
    $tablaRFC1['W']='36';
    $tablaRFC1['X']='37';
    $tablaRFC1['Y']='38';
    $tablaRFC1['Z']='39';
    $tablaRFC1['0']='00';
    $tablaRFC1['1']='01';
    $tablaRFC1['2']='02';
    $tablaRFC1['3']='03';
    $tablaRFC1['4']='04';
    $tablaRFC1['5']='05';
    $tablaRFC1['6']='06';
    $tablaRFC1['7']='07';
    $tablaRFC1['8']='08';
    $tablaRFC1['9']='09';

    $tablaRFC2[0]="1";
    $tablaRFC2[1]="2";
    $tablaRFC2[2]="3";
    $tablaRFC2[3]="4";
    $tablaRFC2[4]="5";
    $tablaRFC2[5]="6";
    $tablaRFC2[6]="7";
    $tablaRFC2[7]="8";
    $tablaRFC2[8]="9";
    $tablaRFC2[9]="A";
    $tablaRFC2[10]="B";
    $tablaRFC2[11]="C";
    $tablaRFC2[12]="D";
    $tablaRFC2[13]="E";
    $tablaRFC2[14]="F";
    $tablaRFC2[15]="G";
    $tablaRFC2[16]="H";
    $tablaRFC2[17]="I";
    $tablaRFC2[18]="J";
    $tablaRFC2[19]="K";
    $tablaRFC2[20]="L";
    $tablaRFC2[21]="M";
    $tablaRFC2[22]="N";
    $tablaRFC2[23]="P";
    $tablaRFC2[24]="Q";
    $tablaRFC2[25]="R";
    $tablaRFC2[26]="S";
    $tablaRFC2[27]="T";
    $tablaRFC2[28]="U";
    $tablaRFC2[29]="V";
    $tablaRFC2[30]="W";
    $tablaRFC2[31]="X";
    $tablaRFC2[32]="Y";
    $tablaRFC2[33]="Z";

    $tablaRFC3['A']=10;
    $tablaRFC3['B']=11;
    $tablaRFC3['C']=12;
    $tablaRFC3['D']=13;
    $tablaRFC3['E']=14;
    $tablaRFC3['F']=15;
    $tablaRFC3['G']=16;
    $tablaRFC3['H']=17;
    $tablaRFC3['I']=18;
    $tablaRFC3['J']=19;
    $tablaRFC3['K']=20;
    $tablaRFC3['L']=21;
    $tablaRFC3['M']=22;
    $tablaRFC3['N']=23;
    $tablaRFC3['O']=25;
    $tablaRFC3['P']=26;
    $tablaRFC3['Q']=27;
    $tablaRFC3['R']=28;
    $tablaRFC3['S']=29;
    $tablaRFC3['T']=30;
    $tablaRFC3['U']=31;
    $tablaRFC3['V']=32;
    $tablaRFC3['W']=33;
    $tablaRFC3['X']=34;
    $tablaRFC3['Y']=35;
    $tablaRFC3['Z']=36;
    $tablaRFC3['0']=0;
    $tablaRFC3['1']=1;
    $tablaRFC3['2']=2;
    $tablaRFC3['3']=3;
    $tablaRFC3['4']=4;
    $tablaRFC3['5']=5;
    $tablaRFC3['6']=6;
    $tablaRFC3['7']=7;
    $tablaRFC3['8']=8;
    $tablaRFC3['9']=9;
    $tablaRFC3['']=24;
    $tablaRFC3[' ']=37;

    //Recorremos el nombre y vamos convirtiendo las letras en su valor numérico
    $len_nombreCompleto = strlen($nombreCompleto);
    for($x = 0; $x < $len_nombreCompleto; $x++){
        $c = substr($nombreCompleto, $x, 1);
        if (isset($tablaRFC1[$c]))
            $nombreEnNumero .= $tablaRFC1[$c];
        else
            $nombreEnNumero .= "00";
    }
    //Calculamos la suma de la secuencia de números
    //calculados anteriormente
    //la formula es:
    //( (el caracter actual multiplicado por diez)
    //mas el valor del caracter siguiente )
    //(y lo anterior multiplicado por el valor del caracter siguiente)

    $n = strlen($nombreEnNumero) - 1;
    for ($i = 0; $i < $n; $i++) {
        $prod1 = substr($nombreEnNumero, $i, 2);
        $prod2 = substr($nombreEnNumero, $i + 1, 1);
        $valorSuma += $prod1 * $prod2;
    }

    //Lo siguiente no se porque se calcula así, es parte del algoritmo.
    //Los magic numbers que aparecen por ahí deben tener algún origen matemático
    //relacionado con el algoritmo al igual que el proceso mismo de calcular el
    //digito verificador.
    //Por esto no puedo añadir comentarios a lo que sigue, lo hice por acto de fe.
    $div = 0;
    $mod = 0;
    $div = $valorSuma % 1000;
    $mod = floor($div / 34);//cociente
    $div = $div - $mod * 34;//residuo

    $hc = $tablaRFC2[$mod];
    $hc.= $tablaRFC2[$div];

    $rfc .= $hc;

    //Aqui empieza el calculo del digito verificador basado en lo que tenemos del RFC
    //En esta parte tampoco conozco el origen matemático del algoritmo como para dar
    //una explicación del proceso, así que ¡tengamos fe hermanos!.
    $sumaParcial = 0;
    $n = strlen($rfc);
    for ($i = 0; $i < $n; $i++) {
        $c=substr($rfc,$i,1);
        if (isset($tablaRFC3[$c])) {
            $sumaParcial += ($tablaRFC3[$c] * (14 - ($i + 1)));
        }
    }

    $moduloVerificador = $sumaParcial % 11;
    if ($moduloVerificador == 0)
        $rfc .= "0";
    else{
        $sumaParcial = 11 - $moduloVerificador;
        if ($sumaParcial == 10)
            $rfc .= "A";
        else
            $rfc .= $sumaParcial;
        }
        return $rfc;
}
?>
