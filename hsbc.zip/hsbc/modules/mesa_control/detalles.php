<?php 
ini_set('display_errors',1);
require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

load_session();

$id_usuario = $_GET["id"];

$rs_detalle_usuario = $db->Execute("SELECT USR_NOMBRE, TRIM(USR_NIVEL) AS NIVEL FROM TBL_USUARIOS WHERE USR_ID = ".$id_usuario);
$nombre = $rs_detalle_usuario->fields['USR_NOMBRE'];
$tipo = (($rs_detalle_usuario->fields['NIVEL']=='A' || $rs_detalle_usuario->fields['NIVEL']=='AI')?"AGENTE":"SUPERVISOR");

?>	
	
	<form name="detailsForm" action="" target="actionframe" method="post">
		<table align="left">				
			<tr>
				<td>ID Usuario:</td>
				<td><input name="USR_ID" type="text" style="background-color:lightgrey;" size="10" name="usuario" value="<?=$id_usuario?>" readonly><br>
			</tr><tr>						
				<td>Nombre:&nbsp;</td>
				<td><input name="nombre" type="text" style="background-color:lightgrey;" size="50" name="nombre" value="<?=$nombre?>" readonly><br>
			</tr><tr>					
				<td>Tipo Usuario:</td>
				<td><input name="tipo" type="Text" style="background-color:lightgrey;" maxlength="50" name="tipo" value="<?=$tipo?>" readonly><br>
			</tr><tr>
				<td>Zonas:</td>
				<td>
				<?
				$rs_zonas = get_detalle_zonas($id_usuario, 1, $db);
				while(!$rs_zonas->EOF){
					echo '<input type="checkbox" name="zona'.$rs_zonas->fields["IZONA_ID"].'" '.($rs_zonas->fields["ACTIVO"]!=0?" checked":"").' onclick="AsignaZona('.$rs_zonas->fields["IZONA_ID"].','.$id_usuario.',this)">'.$rs_zonas->fields["IZONA_ID"].' -'.strtoupper($rs_zonas->fields["VNOMBRE"]).'<br>';
					$rs_zonas->MoveNext();
				}
				?>
				</td>
			</tr>
		</table>
	</form>