const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN "+ context.schema +".XSP_DUPLICARTELVENTA(:u_telefono, :calificacion); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.u_telefono || !context.calificacion){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
          
      			binds.u_telefono = context.u_telefono;
            binds.calificacion = context.calificacion;


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;