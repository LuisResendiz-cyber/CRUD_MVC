<?php
if ($_SESSION["perfil"] != "Administrador") {
    echo '<script>
        window.location = "?ruta=inicio";
    </script>';
    exit;
}
?>

<div class="content-wrapper">

    <section class="content-header">

        <h1>

            Administrar Campañas

        </h1>

        <ol class="breadcrumb">

            <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>

            <li class="active">Administrar Campañas</li>

        </ol>

    </section>

    <section class="content">

        <div class="box">

            <div class="box-header with-border">

                <button class="btn btn-primary" data-toggle="modal" data-target="#modalAgregarCampana">

                    Agregar Nueva Campaña

                </button>

            </div>

            <div class="box-body">

                <table class="table table-bordered table-striped dt-responsive tablas" width="100%">

                    <thead>

                        <tr>

                            <th style="width:10px">Id</th>
                            <th>Nombre</th>
                            <th>Estado</th>
                            <th>Acciones</th>

                        </tr>

                    </thead>

                    <tbody>


                        <?php

$item = null;
$valor = null;

$enlaces = ControladorCampanas::ctrMostrarCampanas($item, $valor);


foreach ($enlaces as $key => $value){
 
  echo ' <tr>
          <td>'.($key+1).'</td>
          <td>'.$value["NOMBRE_CAMPANA"].'</td>';  
          
          if ($value["estatus"] != 0) {

            echo '<td><button class="btn btn-success btn-xs btnActivar" idUsuario="' . $value["id_campana"] . '" estadoUsuario="0">Activado</button></td>';
          } else {

            echo '<td><button class="btn btn-danger btn-xs btnActivar" idUsuario="' . $value["id_campana"] . '" estadoUsuario="1">Desactivado</button></td>';
          }


          
          echo '
          <td>

            <div class="btn-group">
                
              <button class="btn btn-warning btnEditarCampana" idCampana="'.$value["id_campana"].'" data-toggle="modal" data-target="#modalEditarEnlace"><i class="fa fa-pencil"></i></button>

              <button class="btn btn-danger btnEliminarCampana" idCampana="'.$value["id_campana"].'"><i class="fa fa-times"></i></button>

            </div>  

          </td>

        </tr>';
}


?>

                    </tbody>

                </table>

            </div>

        </div>

    </section>

</div>


<div id="modalAgregarCampana" class="modal fade" role="dialog">

    <div class="modal-dialog">

        <div class="modal-content">

            <form role="form" method="post" enctype="multipart/form-data">


                <div class="modal-header" style="background:#3c8dbc; color:white">

                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <h4 class="modal-title">Administar Campanas</h4>

                </div>

                <div class="modal-body">
                    <div class="box-body">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" name="NuevaCampana"
                                    placeholder="Ingresar el Nombre de la Campaña" required>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>

                    <button type="submit" class="btn btn-primary">Guardar Campaña</button>

                </div>

            </form>

            <?php

                              $crearLiga = new ControladorCampanas();
                              $crearLiga->ctrCrearCampana();

                              ?>

        </div>

    </div>

</div>




<div id="modalEditarEnlace" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form role="form" method="post" enctype="multipart/form-data">
                <div class="modal-header" style="background:#3c8dbc; color:white">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Administar Campanas</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">

                        <div class="form-group">
                            <input type="text" class="form-control input-lg" name="Campana_id" value="" id="id_Campana">
                               <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" id="EditarName" name="EditarName" required>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Salir</button>
                    <button type="submit" class="btn btn-primary">Editar Enlace</button>

                </div>

            </form>

            <?php

                              $EditarCampana = new ControladorCampanas();
                              $EditarCampana->ctrEditarCampana();

                              ?>

        </div>

    </div>

</div>

<?php
$EliminarLiga = new ControladorCampanas();
$EliminarLiga->ctrBorrarCampana();

?>