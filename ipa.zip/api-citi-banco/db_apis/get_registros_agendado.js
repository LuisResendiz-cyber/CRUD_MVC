const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context){
 //console.log(context);
	const baseQuery = "BEGIN " + context.schema + ".XSP_GETLLAMADASAGENDADAS(:s_usr_id, 1, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.s_usr_id = context.s_usr_id;
  binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
	
  const result = await database.simpleExecuteRC(query, binds);
  //console.log(result); 
  return result;
}
 
module.exports.find = find;