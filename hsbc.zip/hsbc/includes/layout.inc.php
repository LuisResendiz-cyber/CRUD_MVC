<?php


function layout_header($subtitle) {
	global $linkpath, $pagetitle;
	$random = rand();
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		  <html>
		  <head>
				<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/css/style.css" type="text/css" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/css/block.css" type="text/css" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/js/calendario/calendar.css" type="text/css" />
		  		<link rel="stylesheet" href="' . $linkpath . 'includes/js/tcal.css" type="text/css" />
		  		<link rel="stylesheet" href="' . $linkpath . 'includes/css/SpryAssets/SpryAccordion.css" type="text/css" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/css/jquery-ui-1.10.3.custom.css" type="text/css" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/css/fontawesome-all.css" type="text/css" />
				<link rel="stylesheet" href="' . $linkpath . 'includes/css/sweetalert2.min.css" type="text/css" />

		  		<script language="JavaScript" src="' . $linkpath . 'includes/css/SpryAssets/SpryAccordion.js" type="text/javascript"></script>
				<script language="JavaScript" src="' . $linkpath . 'includes/js/jquery-1.9.1.js"></script>
		  		<script language="JavaScript" src="' . $linkpath . 'includes/js/jsCode.js?r=' . $random . '"></script>
		  		<script language="JavaScript" src="' . $linkpath . 'includes/js/calendario/SCappearance.js"></script>
		  		<script language="JavaScript" src="' . $linkpath . 'includes/js/calendario/SprigstCalendar.js"></script>
				<script language="JavaScript" src="' . $linkpath . 'includes/js/jquery-ui-1.10.3.custom.js"></script>
				<!--link rel="stylesheet" href="' . $linkpath . '/includes/css/jquery/jquery.ui.all.css" type="text/css" /-->
				<link rel="stylesheet" href="' . $linkpath . 'includes/js/tcal.css" type="text/css" />
				<script language="JavaScript" src="' . $linkpath . 'includes/js/tcal.js"></script>
				<script language="JavaScript" src="' . $linkpath . 'includes/js/fontawesome-all.js"></script>	
				<script language="JavaScript" src="' . $linkpath . 'includes/js/calendario/jquery-ui.min.js"></script>
				<script language="JavaScript" src="' . $linkpath . 'includes/js/sweetalert2.all.min.js"></script>

				<link rel="stylesheet" href="' . $linkpath . 'includes/css/select2.min.css" rel="stylesheet" />
				<script language="JavaScript" src="' . $linkpath . 'includes/js/select2.min.js"></script>

		  		<title>' . $pagetitle . ' - ' . $subtitle . '</title>';
	if ($subtitle === "Script") {
		echo '<link rel="stylesheet" href="' . $linkpath . 'includes/css/script.css" type="text/css" />';
	}
}

# MUESTRA EL MENU

function layout_menu($db, $jsFunction = "") {
	global $linkpath, $header_title, $isPredictivo, $dbuser;
		
	$isPredictivo = get_EsPredictivo($db);
	$empresa = get_session_varname("s_usr_centro");

	if (is_logged()) {
		$name = get_session_varname('s_usr_nombre');
		$es_cumple = get_session_varname('es_cumple');//here
		set_session_varname("es_cumple", 0);
		$festejo = get_session_varname('festejo');//here
		set_session_varname("festejo", 0);
		
		$extension = get_session_varname("extension");
		$marcacion = get_session_varname("s_usr_marcacion");
		$nomina = get_session_varname('s_usr_nomina');
		
		if ($marcacion == 1) {
			$tipo_marcacion = 'Predictivo';
		} elseif ($marcacion == 2) {
			$tipo_marcacion = 'Asistido';
		}else{
			$tipo_marcacion = 'Vicidial';
		}
		
		$occ = number_format(get_occ_agente($nomina, str_replace('app', '', $dbuser), $db),2);
		$tiempo = get_tiempo_llamada($nomina, str_replace('app', '', $dbuser), $db);

		if ($empresa == 'ITS'){
			if($occ<70) {$color1 = "FF0000";} //hasta 69.999 --rojo
			else if($occ<75) {$color1 = "FFFF7F";} //desde 74.999 hasta 72.999  -- amarillo
			else {$color1 = "00FF00";}	//desde 75.0 en adelante -- verde

			$occ = number_format($occ, 0);

		} else {
			if($occ<68) {$color1 = "FF0000";} //hasta 67.999
			else if($occ<73) {$color1 = "FFFF7F";} //desde 68.0 hasta 72.999
			else {$color1 = "00FF00";}	//desde 73.0 en adelante

			$occ = number_format($occ, 0);
		}

		?>
		<div id="info_sicall" title="Indicadores">
			<table align="center">
				<!--tr>
					<td><?php echo "<img src=\"https://172.20.1.79/fotos/Fotos/".$nomina.".jpg\" alt=\"Foto\" align=\"center\"/ WIDTH=100% HEIGHT=100%  style='border-radius:25px;'"; ?>
					</td>
				</tr-->
				<tr>
					<td>agente: <br/><b class='label'> <?php echo $name; ?></b><br/><br/></td>
					<td><b>Extension: </b><br/><b class='label'> <?php echo $extension; ?></b><br/><br/></td>
					<td><b>Centro: </b><br/><b class='label'> <?php echo $empresa; ?></b><br/><br/></td>
					<td><b>Marcaci&oacute;n: </b><br/><b class='label'> <?php echo $tipo_marcacion; ?></b><br/><br/></td>
				</tr>
				
			</table>
			<table>
				<tr>
					<td style='border-radius:25px; text-align: center' bgcolor='#<?=$color1?>'><font style='font-size:300%;'>OCUPACI&Oacute;N  <?=$occ?>%</font></td>
				</tr>
				<tr>
					<td style='border-radius:25px; text-align: center' bgcolor='#0044FF'><font style='font-size:300%;'>TIEMPO <?=$tiempo?></font></td>
				</tr>
			</table>
		</div>
		<?php		
	}
	
	echo '</head><body id="idBody" class="bottom_image" onload="boton_der_deshabilitado();';
	
	if (strlen($jsFunction) > 0) {
		echo $jsFunction;
	}

	echo'">
		  <table class="width100" border="0">
			<tr background="' . $linkpath . 'includes/imgs/logo2.jpeg">
				
				<td align="left">';
				if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'ACB' || get_session_varname('s_usr_nivel') == 'ASB')) {
					$detalle = get_agente_info(get_session_varname("s_usr_id"), $db);
					echo '<table class="cuestionario">
						<tr>
							<td colspan="3">&nbsp;</td>
						</tr>
						<tr>
							<td><b>Solicitudes Canceladas:</b></td><td class="label">' . $detalle->_array[0]['CANCELADAS'] . '</td>
						</tr>
						<tr>
							<td><b>Solicitudes Aceptadas:</b></td><td class="label">' . $detalle->_array[0]['ACEPTADAS'] . '</td>
						</tr>
						<tr>
							<td><b>Ultima Solicitud:</b></td><td class="label">' . $detalle->_array[0]['ULTIMASOLICITUD'] . '</td>
						</tr>
						<tr>
							<td><b>Nota de Validaci&oacute;n:</b></td><td class="label">' . $detalle->_array[0]['V_NOTA'] . '</td>
						</tr>
						<tr>
							<td colspan="3">&nbsp;</td>
						</tr>';
					  //  if($base_especial == 1 && $empresa == 'ITS')
					  /*      echo '<tr>
						   <td colspan="3"><input class= "custionario_boton" type="button" value="Base Especial" onclick="dialogo(\''.$linkpath.'modules.php?mod=agentes&op=base_especial\',\'Escoger Base Especial\');"/></td>
						</tr> ';*/
				echo '</table>';
				} else {
					echo '&nbsp;';
				}

		$rutaaviso= (($empresa=='ITQ')?'':(($empresa=='ITS')?'sjr/':'itt/'));
		
		echo '</td>
			<td id="td_aviso">
				<p><img src="' . $linkpath . 'includes/imgs/logo_campana.png" class="valignmiddle"/></p>
				<!--img id="img_aviso"  align="left" style="width:155px;" src="https://172.20.1.79/ImagenesAntiestres/'.$rutaaviso.'avisos.jpg" class="valignmiddle"/-->
			</td>
				</tr>
				<tr class="bar">
					<td align="left" width="50%">
						<b class="label_td">' . $header_title . '</b>
					</td>
					<td align="right">&nbsp;</td>
			</tr><tr>
				<td  colspan="2">
					<table class="width100" border="0">
						<tr>
							<td class="menu">';
	echo menu($db);
	echo '</td>
							  <td class="vspacer">&nbsp;</td>
							  <td class="text">';
}

# MUESTRA LA PARTE SI MENU

function layout_no_menu() {
	global $linkpath, $header_title;
	echo '</head><body id="idBody" class="bottom_image" onLoad="boton_der_deshabilitado()">
			  <table class="width100">
					<tr>
						<td>
							<p class="title"><img src="' . $linkpath . 'includes/imgs/banner_impulse.jpg" class="valignmiddle" />&nbsp;' . $header_title . '</p>
						</td>
					</tr><tr class="bar">
						<td class="bar">&nbsp;</td>
					</tr><tr>
							<td>
								<table class="width100">
									<tr>';
}

# MUESTRA EL PIE DE PAGINA

function layout_footer() {
	global $pagefooter, $linkpath;
	?>	</td></tr>
	</table>
	</td></tr>
	<tr class="spacer">
		<td colspan="2" class="spacer">&nbsp;</td>
	</tr><tr class="bar">
		<td colspan="3">&nbsp;</td>
	</tr>

	<?php if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'AI' || get_session_varname('s_usr_nivel') == 'AA' || get_session_varname('s_usr_nivel') == 'ACB')) { ?>
		<div id="dialog-proceso" title="Obteniendo Registro">
			<div id="progressbar"></div>
		</div>
		<div valign="bottom" id="dial-layer" style="display:none">
			<script>
////                var td = $('#td_aviso').width();
//                $('#img_aviso').width(td-100);
				document.write("<iframe src='<?php echo $linkpath; ?>modules.php?mod=agentes&op=act27' id='asistido' name='asistido' align='right' scrolling='no' frameborder='0' width='10%' height='10%'>");
				document.write("</iframe>");
				//document.frm1.submit();
			</script>
			<!--iframe src='<?php echo $linkpath; ?>modules.php?mod=agentes&op=act27' id='asistido' name='asistido' align='right' scrolling='no' frameborder='0' width='10%' height='10%'>
			</iframe-->
		</div>
	<?PHP } ?>                

	<tr>
		<td  colspan="2"><p id="text"><b><?php echo $pagefooter; ?></b></p></td>
	</tr>
	<tr>
		<td colspan="2" align="right">
			<strong>Servidor:</strong><?php echo $_SERVER['SERVER_ADDR'] ?><br />
			<strong>Cliente: </strong><?php echo $_SERVER['REMOTE_ADDR'] ?><br />
		</td>
	</tr>
	</table>

<?php includesScoreJS();?>
	</body>
	</html>
	<?php        
}

# MUESTRA LOS CAMPOS MARCADS COMO OBLIGATORIOS

function form_oblmsg() {
	return '<table class="text">
				<tr>
					<td colspan="2" class="messagebox">&nbsp;&nbsp;Los campos marcados con * son obligatorios.&nbsp;&nbsp;</td>
				</tr>
		</table>';
}

# INCLUYE ARCHIVOS JS PARA EL PUNTAJE DEL VALIDADOR
function includesScoreCSS() {
	$ip = explode('.', $_SERVER['SERVER_ADDR']);
	echo '<link rel="stylesheet" href="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/awesomplete.css">
		  <link rel="stylesheet" href="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/styleBpopup.css">
		  <link rel="stylesheet" href="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/starwars.css">';
}

# INCLUYE ARCHIVOS JS PARA EL PUNTAJE DEL VALIDADOR
function includesScoreJS() {
	$ip = explode('.', $_SERVER['SERVER_ADDR']);
	echo '<script language="JavaScript" src="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/awesomplete.js" type="text/javascript"></script>
			<script language="JavaScript" src="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/inc.score.js" type="text/javascript"></script>
				<script language="JavaScript" src="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/jquery.bpopup.js"></script>
					<script language="JavaScript" src="https://'.$_SERVER['SERVER_ADDR'].':9080/biblioteca/lib/score/starwars.js"></script>'
			
			;
}

# MUESTRA EL FOMULARIO PARA INICIAR SESSION
function layout_loggin($message) {
	global $linkpath, $isPredictivo, $marcacion;
	
	$ip = $_SERVER['REMOTE_ADDR'];
	
	if (substr($ip, 0, 6) == '172.20' || substr($ip, 0, 6) == '172.21' || substr($ip, 0, 7) == '192.168') {
		$tipo_centro = "local";
	} else {
		$tipo_centro = "remoto";
	}
	
	setcookie('tipo_centro', $tipo_centro);

	//echo '<form id="login" name="frm1" action="modules.php?mod=admin&op=process_data&act=1&empresa_inicia='.$empresa_inicia.'" method="POST">
	echo '<form id="login" name="frm1" action="modules.php?mod=admin&op=process_data&act=1" method="POST">
				<h4>Iniciar Sesion</h4>
				<p>Centro: '.$tipo_centro.'</p>
				<p id="text">Para ingresar al sistema debes, capturar tu nomina y contrase&ntilde;a<br></p>
				<table border="0" id="t1">
					<tr>
						<td colspan="2"><font color="red">' . (isset($message) ? $message : "") . '</font></td>
					</tr>
					<tr>
						<td>Id Usuario:</td><td><input type="text" maxlenght="10" size="10" name="user" id="user"></td>
					</tr>
					<tr>
						<td>Contrase&ntilde;a:</td><td><input type="password" maxlenght="10" size="10"  name="password" id="password"></td>
					</tr>
					';
					//if ($empresa_inicia == 11) {
					if ($tipo_centro == "remoto") {
					echo 
					'<tr>
						<td>Extensi&oacute;n:</td><td><input type="text" maxlenght="10" size="10"  name="extension" id="extension"></td>
					</tr>
					';
					}
					echo 
					'<tr>';
	

	if ($isPredictivo == 1) {
		echo '<td>Marcaci&oacute;n:</td><td>
									<select name="marcacion" style="width:100px">
									<option value="0">Selecciona</option>
									<option value="1">Predictivo</option>
									<option value="2">Asistido</option>
									<option value="3">Predictivo NUXIBA </option>
								</select>
								</td>
							</tr>';
	}else{
		
		echo '<td>Marcaci&oacute;n:</td><td>
									<input type="text" size="10" name="marcacio2n" id="marcacion2" value="Asistido" disabled>
									<input type="hidden" size="10" name="marcacion" id="marcacion" value="2">                                    
								</select-->
								</td>
							</tr>';
	}

	echo '<tr><td colspan="2"><input type="button" value="Ingresar" onclick="ValidaLogin()"></td>
					</tr>
				</table>
			</form>';
}
?>
