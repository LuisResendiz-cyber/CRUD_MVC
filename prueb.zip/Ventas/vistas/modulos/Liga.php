<?php
$url = "https://app.powerbi.com/view?r=eyJrIjoiNGRlNzY2NWItYjA3NC00Y2JhLWJhMjEtYjkyYmMzMjRmMWE0IiwidCI6IjdlMTI5ZjVjLWYxNjItNDhlYi05NTQ1LTEwYTNkODRkNDQwNSJ9";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Desactivar la verificación del certificado SSL

$result = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error al recuperar la URL: ' . curl_error($ch);
} else {
    echo $result;
}

curl_close($ch);
?>
