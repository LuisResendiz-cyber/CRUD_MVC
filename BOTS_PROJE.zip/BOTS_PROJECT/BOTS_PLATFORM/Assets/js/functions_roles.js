
var divLoading = document.querySelector("#divLoading");
document.addEventListener("DOMContentLoaded", function () {
  
  initDataTable({
    tableId: "#tableRoles",
    url: base_url + "/Roles/getRoles",

    //const Url = `${base_url}/Roles/getRoles`;

    dataSrc: "roles",
    module: "Roles",
    request: ["getRol", "delRol", "editRol"],
    columnRenderers: {
      status: function (data) {
        return data == 1
          ? '<span class="badge badge-success">Activo</span>'
          : '<span class="badge badge-danger">Inactivo</span>';
      },
    },
  });

  const formRol = document.querySelector("#formRol");

  formRol.addEventListener("submit", async function (e) {
    e.preventDefault();

    const strNombre = document.querySelector("#txtNombre").value;
    const strDescripcion = document.querySelector("#txtDescripcion").value;
    const intStatus = document.querySelector("#listStatus").value;

    if (strNombre === "" || strDescripcion === "" || intStatus === "") {
      swal("Atención", "Todos los campos son obligatorios.", "error");
      return;
    }

    divLoading.style.display = "flex";

    const ajaxUrl = `${base_url}/Roles/setRol`;
    const formData = new FormData(formRol);

    try {
      const response = await fetch(ajaxUrl, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Error en la petición");
      }

      const objData = await response.json();

      if (objData.status) {
        $("#modalFormRol").modal("hide");
        formRol.reset();
        swal("Roles de usuario", objData.msg, "success");
      setTimeout(() => {
      initDataTable({
        tableId: "#tableRoles",
        url: base_url + "/Roles/getRoles",
        dataSrc: "roles",
        module: "Roles",
        request: ["getRol", "delRol", "editRol"],
        columnRenderers: {
          status: function (data) {
            return data == 1
              ? '<span class="badge badge-success">Activo</span>'
              : '<span class="badge badge-danger">Inactivo</span>';
          },
        },
      });
    }, 500);
   } else {
        swal("Error", objData.data, "error");
      }
    } catch (error) {
      console.error(error);
      swal("Error", "No se pudo procesar la solicitud", "error");
    } finally {
      divLoading.style.display = "none";
    }
  });
});


function openModal(){
  document.querySelector('#idRol').value ="";
  document.querySelector('.modal-header').classList.replace("headerUpdate", "headerRegister");
  document.querySelector('#btnActionForm').classList.replace("btn-info", "btn-primary");
  document.querySelector('#btnText').innerHTML ="Guardar";
  document.querySelector('#titleModal').innerHTML = "Nuevo Rol";
  document.querySelector("#formRol").reset();
$('#modalFormRol').modal('show');
}


function fntEditRol(module, request, idrol) {
  document.querySelector("#titleModal").innerHTML = "Actualizar Rol";
  document.querySelector(".modal-header").classList.replace("headerRegister", "headerUpdate");
  document.querySelector("#btnActionForm").classList.replace("btn-primary", "btn-info");
  document.querySelector("#btnText").innerHTML = "Actualizar";

  const Url = base_url + "/Roles/getRol/" + idrol;

  fetch(Url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(response => response.json())
    .then(objData => {
      if (objData.status) {
        document.querySelector("#idRol").value = objData.data.ID;
        document.querySelector("#txtNombre").value = objData.data.NOMBRE;
        document.querySelector("#txtDescripcion").value = objData.data.DESCRIPCION;

        let optionSelect;
        if (objData.data.status == 1) {
          optionSelect = '<option value="1" selected class="notBlock">Activo</option>';
        } else {
          optionSelect = '<option value="2" selected class="notBlock">Inactivo</option>';
        }

        const htmlSelect = `
          ${optionSelect}
          <option value="1">Activo</option>
          <option value="2">Inactivo</option>
        `;

        document.querySelector("#listStatus").innerHTML = htmlSelect;
        $("#modalFormRol").modal("show");
      } else {
        swal("Error", objData.msg, "error");
      }
    })
    .catch(error => {
      console.error("Error en la petición:", error);
      swal("Error", "Ocurrió un error al obtener el rol", "error");
    });
}


function fntPermisos(idrol) {
  var idrol = idrol;
  var request = window.XMLHttpRequest
    ? new XMLHttpRequest()
    : new ActiveXObject("Microsoft.XMLHTTP");
  var ajaxUrl = base_url + "/Permisos/getPermisosRol/" + idrol;
  request.open("GET", ajaxUrl, true);
  request.send();

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      document.querySelector("#contentAjax").innerHTML = request.responseText;
      $(".modalPermisos").modal("show");
      document
        .querySelector("#formPermisos")
        .addEventListener("submit", fntSavePermisos, false);
    }
  };
}

function fntSavePermisos(evnet) {
  evnet.preventDefault();
  var request = window.XMLHttpRequest
    ? new XMLHttpRequest()
    : new ActiveXObject("Microsoft.XMLHTTP");
  var ajaxUrl = base_url + "/Permisos/setPermisos";
  var formElement = document.querySelector("#formPermisos");
  var formData = new FormData(formElement);
  request.open("POST", ajaxUrl, true);
  request.send(formData);

  request.onreadystatechange = function () {
    if (request.readyState == 4 && request.status == 200) {
      var objData = JSON.parse(request.responseText);
      if (objData.status) {
        swal("Permisos de usuario", objData.msg, "success");
      } else {
        swal("Error", objData.msg, "error");
      }
    }
  };
}
