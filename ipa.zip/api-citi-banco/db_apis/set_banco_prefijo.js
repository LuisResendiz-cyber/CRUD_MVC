const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".sps_bancos_afiliacion(:p_prefijo, :v_banco, :v_tipo_tarjeta); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.p_prefijo){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
          
			binds.p_prefijo = context.p_prefijo;
			binds.v_banco = {val:parseInt(context.v_banco), dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
      binds.v_tipo_tarjeta = {val:parseInt(context.v_tipo_tarjeta), dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;