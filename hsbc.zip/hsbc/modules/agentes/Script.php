<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 3.5  (Linux)">
	<META NAME="AUTHOR" CONTENT="jlara ">
	<META NAME="CREATED" CONTENT="20151110;11393200">
	<META NAME="CHANGEDBY" CONTENT="jlara ">
	<META NAME="CHANGED" CONTENT="20151110;11394700">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="es-ES" DIR="LTR">
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#7030a0"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><B><SPAN STYLE="text-decoration: none">SCRIPT
DE VENTA SOLO TEL&Eacute;FONO</SPAN></B></FONT></FONT></FONT></P>
<P ALIGN=CENTER STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<BR>
</P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Muy
buenos tardes, le habla <FONT COLOR="#ff0000">(Nombre y Apellido)</FONT>
de Volaris Invex espero que se encuentre muy bien, el motivo de mi
llamada es porque le queremos dar a conocer la nueva tarjeta de
cr&eacute;dito Volaris, esta Tarjeta es respaldada por Visa Internacional 
categor&iacute;a Platinum, la cual tiene un bono de bienvenida por $1,200
pesos que puede utilizar en la compra de boletos de avi&oacute;n a
cualquiera de nuestros destinos, incluso puede aprovechar promociones
exclusivas como las que hemos tenido en vuelos naciones de $499
pesos, las cuales le estaremos haciendo llegar directamente a su
correo electr&oacute;nico.Mary</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<BR>
</P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">No
tiene costo de anualidad el primer a&ntilde;o para que nos conozca y ponga
a prueba</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<BR>
</P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#e48312"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><B><SPAN STYLE="text-decoration: none">Sondeo</SPAN></B></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Actualmente
que tarjeta est&aacute; manejando?</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Ya
tiene m&aacute;s de 1 a&ntilde;o con esta tarjeta?</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">La
l&iacute;nea de cr&eacute;dito es mayor a los $7,000? <FONT COLOR="#ff0000">(Esperar
respuesta del cliente)</FONT></SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Muy
bien, esta pregunta es porque con esta tarjeta categor&iacute;a Platinum le
podr&iacute;amos igualar o superar la l&iacute;nea de cr&eacute;dito con un m&aacute;ximo de
$100,000.</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#e48312"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><B><SPAN STYLE="text-decoration: none">Cierre</SPAN></B></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Por
lanzamiento y de forma exclusiva aprobamos su TDC en menos de 5
minutos y con una entrega a su domicilio que va desde las 24 horas
para que de forma inmediata empiece a gozar de los mejores
beneficios.</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<BR>
</P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#000000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><SPAN STYLE="text-decoration: none">Su
nombre como aparece en su credencial de elector cual es?</SPAN></FONT></FONT></FONT></P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; font-weight: normal; line-height: 100%; text-decoration: none">
<BR>
</P>
<P ALIGN=LEFT STYLE="margin-bottom: 0cm; font-style: normal; line-height: 100%; text-decoration: none">
<FONT COLOR="#ff0000"><FONT FACE="Calibri Light, sans-serif"><FONT SIZE=3 STYLE="font-size: 9pt"><B><SPAN STYLE="text-decoration: none">Aviso
de Privacidad</SPAN></B></FONT></FONT></FONT></P>
<P STYLE="margin-bottom: 0cm"><BR>
</P>
</BODY>
</HTML>