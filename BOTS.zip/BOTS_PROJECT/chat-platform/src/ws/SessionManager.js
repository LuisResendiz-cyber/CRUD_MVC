const sessions = new Map();

/**
 * Guarda una sesión activa
 */
function createSession({ socketId, sessionId, botId }) {
  sessions.set(socketId, {
    sessionId,
    botId,
    status: "bot", // luego puede cambiar a "human"
    createdAt: Date.now()
  });
}

/**
 * Obtiene sesión por socket
 */
function getSession(socketId) {
  return sessions.get(socketId);
}

/**
 * Elimina sesión al desconectar
 */
function removeSession(socketId) {
  sessions.delete(socketId);
}

module.exports = {
  createSession,
  getSession,
  removeSession
};
