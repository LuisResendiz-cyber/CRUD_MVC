const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".spu_set_cal_hotEspecial(:activa_trj,:tiene_trj,:opc,:cal_trns,:persona); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.activa_trj || !context.tiene_trj || !context.opc || !context.cal_trns || !context.persona){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
			
			binds.activa_trj = context.activa_trj;
			binds.tiene_trj = context.tiene_trj;
			binds.opc = context.opc;
			binds.cal_trns = context.cal_trns;
			binds.persona = context.persona;


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;