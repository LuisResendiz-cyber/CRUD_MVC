<?php
# @uthor Mark
# Menu File
// ARMA EL MENU DINAMICO PARA LOS USUARIOS

function menu($db) {
    global $linkpath;

//    echo "Nivel: " . get_session_varname("s_usr_nivel") . "<br />\r\n";
    $tu_base = true;
    if (isset($_REQUEST['mod']) || isset($_REQUEST['op'])) {
        $tu_base = false;
    }

    if (get_session_varname('s_puede_referido') == 0) {
        $tu_base = false;
    }

    $id_solicitud = get_session_varname('id_solicitud'); 

    $tipo_standby = get_session_varname("tipo_standby");
	
    if (is_logged()) {
        


        if(isset($_SESSION['log_registro'])){
            $log_registro = get_session_varname('log_registro');
        }else{
            $log_registro = 0;
        }
        

        
        if($log_registro > 0 || $id_solicitud > 0){
            $bloqueo = 1;
        }else{
            $bloqueo = 0;
        }

                
        if (get_session_varname("s_usr_marcacion") == 1) {
            echo '<b class="text-uppercase">Firmado en Predictivo</b><br/><br/>' . "\r\n";
        } elseif (get_session_varname("s_usr_marcacion") == 2) {
            echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
            <strong>Firmado en Asistido</strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }
        
        if (get_session_varname("s_usr_marcacion") != 1) {
            echo '<input class="btn btn-danger btn-nuevo_diseno" type="button" id="terminar_ss"  onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=admin&op=process_data&act=2\'" value="Terminar sesi&oacute;n"><br /><br />' . "\r\n";
        } else {
            echo '<input type="button" id="terminar_ss" class="btn btn-danger btn-nuevo_diseno" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=admin&op=process_data&act=2\'" value="Terminar sesi&oacute;n"><br /><br />' . "\r\n";
        }

        if (get_session_varname("s_usr_nivel") != 'S') {		
            //Botones para tiempo de OCC
            
            if ($tipo_standby == 0) {
            //Boton inicio
            if (get_session_varname("s_usr_marcacion") == 1) {
                echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="" onclick="AbandonarV2(this,document.frm1.cont.value, \'MTg=\') /*this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=Mzc=\'*/" value="Inicio"></p>' . "\r\n";
            }else{
                echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="inicio" onclick="AbandonarV2(this,document.frm1.cont.value, \'MTg=\') /*this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=Mzc=\'*/" value="Inicio"></p>' . "\r\n";
            }
            
            //Verifica perfil de usuario
            if (in_array(get_session_varname("s_usr_nivel"), array('A', 'ACB'))) {
                //Boton buscar registro
                if ($id_solicitud == 0) {
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="bsregistro" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('2') . '\'" value="Buscar Registro"></p>' . "\r\n";
                } else {
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="bsregistro" onclick="guarda_click(69)" value="Buscar Registro"></p>' . "\r\n";
		}
                
                //Obtener registro

                //echo $bloqueo;
                if ($bloqueo == 0) {

                    //echo get_session_varname("s_usr_marcacion");
                    if (get_session_varname("s_usr_marcacion") == 1) {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="obRegistroPred" onclick="this.disabled=true;marcarpredictivo(\'' . encripta('27') . '\')" value="Obtener Registro"></p>' . "\r\n";
                    } else {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="obRegistroAsis" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('1') . '\'" value="Obtener Registro"></p>' . "\r\n";
                    }

                } else {
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="obRegistroAsis" value="Obtener Registro" disabled></p>' . "\r\n";
                }

                //Nuevo Registro
                } elseif (get_session_varname("s_usr_nivel") == 'ASB') {
                    echo '<p>&nbsp;<input type="button" class="menulink" onclick="window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=nuevoregistro\'" value="Nuevo Registro"></p>' . "\r\n";
                }

            ?> 
            <hi id="nota_agenda">Script / Notas</hi>
            <div id="panel_notaagneda">
                <div  class="accordion-resizer" style="height: 400px;">
                    <div id="accordion">
                        <h3>Agenda</h3>
                        <div>
                            <form method="post" name="frm3" id="frm3">
                                <input type="hidden" name="u_persona" id ="u_persona">
                                <input type="hidden" name="u_registro" id ="u_registro">
                                <input type="text" name="fecha_agenda" id="fecha_agenda" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
                                <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true;
                                                    verAgenda(this, document.getElementById('fecha_agenda').value, 'agenda2', 1);" />

                                <div id="agenda2" align="center" class="script"></div>

                            </form>
                        </div>
                        <h3>Script</h3>
                        <div>
                            <div id="script" class="script"></div>
                        </div>
                        <?php if (is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'AI' || get_session_varname('s_usr_nivel') == 'AA' || get_session_varname('s_usr_nivel') == 'ACB')) { ?>
                            <h3>Notas Personales</h3>
                            <div>
                                <iframe src="<?php echo $linkpath; ?>modules.php?mod=agentes&op=notas" width="100%" height="320" frameborder="0">
                                <p>El navegador no soporta IFrames.</p>
                                </iframe>
                            </div>
                            <?php
                        }
                        ?>
                        <h3>Aviso De Privacidad</h3>
                            <div>                                
                                Los datos personales que nos proporcione ser�n tratados por American Express Company (M�xico), S.A. de C.V., con domicilio en Patriotismo 635 Col. Ciudad de los Deportes, Alcald�a Benito Ju�rez, 03710 Ciudad de M�xico, M�xico, con la finalidad primaria y necesaria de contactarle con el prop�sito de ofrecerle nuestros servicios, as� como para dar seguimiento a sus solicitudes de las Tarjetas American Express. Para conocer nuestro Aviso de Privacidad Integral visite: www.americanexpress.com.mx.
                                <h2 style="color:#59879D;">QUE CONTESTAR AL CLIENTE:</h2>
                                <p style="color:red;">Si el cliente menciona que est&aacute; inscrito en REUS (Registro P&uacute;blico de Usuarios Personas F&iacute;sicas), CONDUSEF (Comisi&oacute;n Nacional para la Protecci&oacute;n y Defensa de los Usuarios de los Servicios Financieros) o ya requiri&oacute; derecho de ARCO:</p>
                                <br>
                                <p>De parte de (campa&ntilde;a) le ofrezco una disculpa, no ten&iacute;a conocimiento de esta situaci&oacute;n. Le agradezco que haya atendido mi llamada, muchas gracias.</p>
                                <br>
                                <p style="color:red;">Que responder ante la pregunta �C&oacute;mo obtuviste mis datos?</p>
                                <br>
                                <P>Se&ntilde;or (a)no se preocupe, el &uacute;nico dato con el que contamos es este tel&eacute;fono al que nos estamos comunicando.</P>
                                <br>
                                <p style="color:red;">Con insistencia, de d&oacute;nde los obtuvieron: </p>
                                <br>
                                <p>Se&ntilde;or (a), nuestra informaci&oacute;n fuente es p&uacute;blica, y es obtenida de correr las series de marcaci&oacute;n que aparecen en la p&aacute;gina web del Instituto Federal de Telecomunicaciones.</p>
                                <br>
                                <p style="color:red;">Tercera insistencia:</p>
                                <br>
                                <p>Se&ntilde;or (a), de parte de (campa&ntilde;a) le ofrezco una disculpa, definitivamente no es nuestro objetivo generarle desconfianza alguna, sin embargo entiendo su preocupaci&oacute;n. En estos momentos procedo al bloqueo de este tel&eacute;fono para que no lo volvamos a contactar. Le agradezco que haya atendido mi llamada, muchas gracias.</p>
                                <br>
                                <p>No darle a entender al cliente que alguna empresa externa nos proporcion&oacute; sus datos lo cual es incorrecto.</p> 
                                <br>
                                <p>Ejemplo:</p>
                                <ul>
                                    <li>Es referido por Visa / Master Card</li>
                                    <li>Por sus buenas referencias crediticias.</li>
                                    <li>Por su buen historial en bur&oacute; de cr&eacute;dito</li>
                                </ul>
                                <br>
                            </div>
                    </div>
                </div>
            </div>
            

            <?php
				if ($bloqueo == 0) {   
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbreak" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('58') . '\'" value="Break"></p>' . "\r\n";
					echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbano" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('59') . '\'" value="Ba&ntilde;o"></p>' . "\r\n";
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btncapa" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('60') . '\'" value="Capacitaci&oacute;n"></p>' . "\r\n";

                } else {
					echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbreak" onclick="guarda_click(58)" value="Break"></p>' . "\r\n";
					echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbano" onclick="guarda_click(59)" value="Ba&ntilde;o"></p>' . "\r\n";
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btncapa" onclick="guarda_click(60)" value="Capacitaci&oacute;n"></p>' . "\r\n";
                                                
				}
				} else {
                    if(get_session_varname("s_usr_marcacion") == 1){
                                        if ($tipo_standby == 1) {
						echo '<p>&nbsp;<input  type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbreak_pred" onclick="this.disabled=true;RegresoPredictivo(event, \'' . encripta('57') . '\')" value="Regreso Break"></p>' . "\r\n";
					} elseif ($tipo_standby == 2) {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btncapa_pred" onclick="this.disabled=true;RegresoPredictivo(event, \'' . encripta('57') . '\')" value="Regreso Ba&ntilde;o"></p>' . "\r\n";
					} elseif ($tipo_standby == 3) {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btncapa_pred" onclick="this.disabled=true;RegresoPredictivo(event, \'' . encripta('57') . '\')" value="Regreso Capacitaci&oacute;n"></p>' . "\r\n";
					} elseif ($tipo_standby == 4) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnretro_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Retroalmentaci&oacute;n"></p>' . "\r\n";
					} elseif ($tipo_standby == 5) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnrep_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Reporter&iacute;a"></p>' . "\r\n";
					} elseif ($tipo_standby == 6) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btndes_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Descanso Forzado"></p>' . "\r\n";
					} elseif ($tipo_standby == 7) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnjunta_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Junta de Arranque"></p>' . "\r\n";
					} elseif ($tipo_standby == 8) {
						echo '<p>&nbsp;<input type="button" id="btnagenda_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Agenda"></p>' . "\r\n";
					} elseif ($tipo_standby == 9) {
						echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbusqueda_pred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso de Busqueda"></p>' . "\r\n";
					} elseif ($tipo_standby == 10) {
                        unset_session_varname("datos_persona");
                        unset_session_varname("id_solicitud");
                        unset_session_varname("id_registro");
                        unset_session_varname("id_producto");
                        unset_session_varname("agenda");
                        unset_session_varname("tipo_standby");
                        unset_session_varname("log_registro");
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="obRegistroPred" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('27') . '\'" value="Obtener Registro"></p>' . "\r\n";
					}
                }else{
                    if ($tipo_standby == 1) {
						echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbreak" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Break"></p>' . "\r\n";
					} elseif ($tipo_standby == 2) {
						echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbano" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Ba&ntilde;o"></p>' . "\r\n";
					} elseif ($tipo_standby == 3) {
						echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btncapa" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Capacitaci&oacute;n"></p>' . "\r\n";
					} elseif ($tipo_standby == 4) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnretro" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Retroalmentaci&oacute;n"></p>' . "\r\n";
					} elseif ($tipo_standby == 5) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnrep" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Reporter&iacute;a"></p>' . "\r\n";
					} elseif ($tipo_standby == 6) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btndes" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Descanso Forzado"></p>' . "\r\n";
					} elseif ($tipo_standby == 7) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnjunta" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Junta de Arranque"></p>' . "\r\n";
					} elseif ($tipo_standby == 8) {
						echo '<p>&nbsp;<input type="button" class="menulink" id="btnagenda" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso Agenda"></p>' . "\r\n";
					} elseif ($tipo_standby == 9) {
						echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="btnbusqueda" onclick="this.disabled=true;window.location=\'' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('57') . '\'" value="Regreso de Busqueda"></p>' . "\r\n";
					}
                }					
			}

                //Consultar ventas
 /*                if ($bloqueo == 0) { */
                    if (get_session_varname("s_usr_marcacion") == 1) {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="consultarVentasPred" value="Consultar ventas" data-state="0"></p>' . "\r\n";
                    } else {
                        echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="consultarVentasAsis"  value="Consultar ventas" data-state="0"></p>' . "\r\n";
                    }

/*                 } else {
                    echo '<p>&nbsp;<input type="button" class="btn btn-primary btn-nuevo_diseno" id="consultarVentas" value="Consultar ventas" disabled></p>' . "\r\n";
                } */
                ?>
                
                <div id="containerConsultaVenta">
                    <div id="dataConsultaVenta">
                    </div>
                </div>

                
                <?php
        } else {
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=reporte_prod">Reportes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=nomina&op=activacion">Activacion</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('30') . '">Buscar Cliente</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=01800">01800</a></p>' . "\r\n";
            //echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=datos_solicitud">Datos de Solicitud</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('32') . '">Buscar Empresa</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=process_data&act=' . encripta('33') . '">Buscar CP</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=agentes&op=procesos_detenidos">Procs. detenidos</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=seguimiento_agentes">Seg. Agentes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=seguimiento_solicitudes">Seg. Solicitudes</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=revivir_solicitud">Revivir Solicitud</a></p>' . "\r\n";
            echo '<p>&nbsp;&nbsp;&nbsp;<a class="menulink" href="' . $linkpath . 'modules.php?mod=supervisor&op=layouts">Layouts</a></p>' . "\r\n";
        }
    } else {
        echo '&nbsp;';
    }
}





// OBTIENE LOS NIVELES DEL MENU
function get_profilemenu($action, $s_usr_nivel, $menuchild_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN SPS_PROFILEMENU('" . $s_usr_nivel . "'," . $menuchild_id . "," . $action . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}
