<?php 
    headerAdmin($data); 
    getModal('modalClientes',$data);
?>
  <main class="app-content">    
      <div class="app-title">
        <div>
            <h1><i class="fas fa-user-tag"></i> <?= $data['page_title'] ?>
                <?php if($_SESSION['permisosMod']['w']){ ?>
                <button class="btn btn-primary" type="button" onclick="openModal();" ><i class="fas fa-plus-circle"></i> Nuevo</button>
              <?php } ?>
            </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?= base_url(); ?>/bots"><?= $data['page_title'] ?></a></li>
        </ul>
      </div>

      <div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">

                <div class="cards-grid">

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-robot"></i>
                            </div>
                            <h5>Bot Travel</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>


                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>


                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <div class="chatbot-card">
                        <span class="badge badge-ai">IA</span>
                        <span class="badge badge-active">Activo</span>

                        <div class="card-body text-center">
                            <div class="icon mb-3">
                                <i class="fa fa-globe"></i>
                            </div>
                            <h5>Amex Viajes</h5>
                            <button class="btn btn-primary btn-sm mt-3">
                                Iniciar
                            </button>
                        </div>
                    </div>

                    <!-- más cards -->

                </div>

            </div>
        </div>
    </div>
</div>

    </main>

    <style>
     .cards-grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr); /* 👈 12 columnas */
    gap: 20px;
}

/* Cada card ocupa 3 columnas (4 por fila) */
.chatbot-card {
    grid-column: span 3; /* 12 / 3 = 4 cards por fila */
    min-height: 230px;                /* 👈 más largas */
    padding: 12px 10px;                /* 👈 respira más */
    position: relative;
    border-radius: 14px;
    border: 1px solid #e5e7eb;        /* gris muy claro pero visible */
    box-shadow: 0 1px 3px rgba(0,0,0,0.05); /* 👈 separación visual */
    border: 1px solid #eee;
    background: #fff;
    transition: 
        transform 0.3s ease,
        box-shadow 0.3s ease;
}

.chatbot-card:hover {
    transform: translateY(-4px);
    border-color: #d1d5db;
    box-shadow: 0 12px 28px rgba(0,0,0,0.12);
}

/* ICONO */
.chatbot-card .icon i {
    font-size: 36px;
    color: #6f42c1;
}

/* BADGES */
.chatbot-card .badge {
    position: absolute;
    top: 12px;
    padding: 4px 10px;
    font-size: 11px;
    border-radius: 12px;
    color: #fff;
}

.badge-ai {
    right: 12px;
    background: linear-gradient(135deg, #6f42c1, #9b6bff);
}


.chatbot-card h5 {
    margin-top: 12px;
    font-weight: 600;
}

.chatbot-card .btn {
    margin-top: 12px;
    padding: 6px 22px;
    border-radius: 18px;
}


.badge-active {
    left: 12px;
    background: #28a745;
}

    </style>
<?php footerAdmin($data); ?>
    