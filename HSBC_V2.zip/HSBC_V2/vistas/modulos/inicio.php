<div class="content-wrapper">
    <section class="content-header">
        <h1>Tablero<small>Panel de Control</small></h1>
        <ol class="breadcrumb">
            <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Tablero</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-success">
                    <div class="container">
                        <div class="box-header"
                            style="position: relative; padding-top: 56.25%; /* 16:9 Aspect Ratio */">
                            <iframe id="myIframe" src=""
                                style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>



<script>    
    document.addEventListener("DOMContentLoaded", function() {

    var enlaces = document.querySelectorAll('.cargarIframe');

    // Agregar un listener para cada enlace
    enlaces.forEach(function(enlace) {
        enlace.addEventListener('click', function(event) {
            event.preventDefault();
            
            // Obtener la URL del iframe desde el atributo data-url
            var urlIframe = this.getAttribute('data-url');

            const test = 'vistas/modulos/header.php?url=' + urlIframe; // Codificar en Base64
            document.getElementById('myIframe').src = test;

            /* var intervalId = setInterval(function() {
            var elemento = document.querySelector('.pbi-glyph-open-in-new-window');
            
            if(elemento) {            
            elemento.style.display = 'none';
            clearInterval(intervalId);
            }

            }, 1000); */


        });
    });
});
</script>