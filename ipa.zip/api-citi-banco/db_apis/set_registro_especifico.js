const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context){


	//console.log('+++', context.keyrig[0], '+++');
	//console.log('\n');
	//console.log('***', context, '***');

  //const baseQuery = "BEGIN "+ context.schema +".XSP_INSERTAREGISTROTELEFONICO3(:camp, :user_, :nombre_, :aPaterno_, :aMaterno_, :RFC_, :fnacimiento, :Pais_, :lada_, :telefono_, :localizacion_, :u_per, :u_tel, :u_reg, :tipoBase, :keys_, :v_mensaje_error); END;";
  // const baseQuery = "BEGIN "+ context.schema +".XSP_INSERTAREGISTROTELEFONICO3(:v_camp, :v_user, :v_nombre, :v_paterno, :v_materno, :v_rfc, :v_fec_nacimiento, :v_pais, :v_lada, :v_telefono, :v_localizacion, :v_tipo_base, :keys_, :rc1); END;";
  const baseQuery = "BEGIN "+ context.schema +".XSP_INSERTAREGISTROTELEFONICO3(:v_camp, :v_user, :v_nombre, :v_paterno, :v_materno, :v_rfc, :v_fec_nacimiento, :v_pais, :v_lada, :v_telefono, :v_localizacion, :v_tipo_base, :rc1); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};
  if(!context.v_campana || !context.v_user || !context.v_nombre || !context.v_paterno || !context.v_lada || !context.v_telefono){
    // if(!context.v_campana || !context.v_user || !context.v_nombre || !context.v_paterno || !context.v_lada || !context.v_telefono || context.keys==''){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.v_camp = context.v_campana;
    binds.v_user = context.v_user;
    binds.v_nombre = context.v_nombre;
    binds.v_paterno = context.v_paterno;
    binds.v_materno = context.v_materno;
    binds.v_rfc = context.v_rfc;
    binds.v_fec_nacimiento =  context.v_fec_nacimiento;
    binds.v_pais = context.v_pais;
    binds.v_lada = context.v_lada;
    binds.v_telefono = context.v_telefono;
    binds.v_localizacion = context.v_localizacion;
		binds.v_tipo_base = context.v_tipo_base;
		// binds.keys_ = context.keyrig;
		binds.rc1  = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_VARCHAR};
	
		//console.log('...', binds, '...');
    const result = await database.simpleExecute(query, binds);
    //console.log('*****', result, '*****'); 
    return result;
    //return 'lñksdnglkf';
  }
}
 
module.exports.find = find;