<?php
require_once("includes/includes.inc.php");
load_session();
layout_header("Seguridad");


if(is_logged()){        
    $name = get_session_varname('s_usr_nombre');
}
    
echo '</head><body id="idBody" class="bottom_image" onload="boton_der_deshabilitado();';

/* if(strlen($jsFunction) > 0)
    echo $jsFunction; */

echo'">
      <table class="width100" border="0">
        <tr background="' . $linkpath . 'includes/imgs/images.jpeg">
            <td>
                <p><img style="width: 23%; height: 23%;" src="' . $linkpath . 'includes/imgs/logo_campana.jpeg" class="valignmiddle"/><a class="title2">&nbsp;' . $header_title . '</a></p>
            </td><td>';
            
        if(is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'ACB' || get_session_varname('s_usr_nivel') == 'ASB')){
            $detalle = get_agente_info(get_session_varname("s_usr_id"), $db);

            echo '<table align="center">
                    <tr>
                        <td><b>Solicitudes Canceladas:</b></td><td>'.$detalle->_array[0]['CANCELADAS'].'</td>
                    </tr>
                    <tr>
                        <td><b>Solicitudes Aceptadas:</b></td><td>'.$detalle->_array[0]['ACEPTADAS'].'</td>
                    </tr>
                    <tr>
                        <td><b>Ultima Solicitud:</b></td><td>'.$detalle->_array[0]['ULTIMASOLICITUD'].'</td>
                    </tr>
                    <tr>
                        <td><b>Nota de Validaci&oacute;n:</b></td><td>'.$detalle->_array[0]['V_NOTA'].'</td>
                    </tr>
            </table>';
        }else{
            echo '&nbsp;';
        }
        echo '</td>
            </tr><tr class="bar">
                <td align="left" width="50%">';
                    if(is_logged())
                        echo '<b>Usuario: '.$name.'</b>';
                    else
                        echo '&nbsp;';
          echo '</td></td><td align="right">&nbsp;<b>'.get_now().'</b></td>
                    </tr><tr>
                            <td  colspan="2">
                                    <table class="width100" border="0">
                                            <tr>
                                                    <td class="menu">';
                                                            //echo menu($db);
                                            echo '</td>
                                                      <td class="vspacer">&nbsp;</td>
                                                      <td class="text">';
?>
<br>

<script language="JavaScript" src="<?= $linkpath ?>includes/js/jquery_validate.js" type="text/javascript"></script>

<script>
    $().ready(function(){
        $("#form").validate({
            rules: {
                password: {
                    required:true,
                    maxlength2: 8
                },
                password_again: {
                    required:true,
                    equalTo: "#password",
                    maxlength2: 8
                }
            },
            errorClass: "error-message",
            submitHandler: function() {
                update_password();
            }
        });
    });

    function update_password(){
v_password = document.getElementById("password").value;
v_passwrod1 = document.getElementById("password_again").value;
usr_id = document.getElementById("usr_id").value;

var xmlhttp;
if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}

xmlhttp.onreadystatechange=function(){
    if (xmlhttp.readyState==4 && xmlhttp.status==200){
        document.getElementById("result_").innerHTML = xmlhttp.responseText.substr(1);
        if(xmlhttp.responseText.substr(0,1) == 5){
            alert("Se ha cambiado el password Exitosamente.");
            window.location = "modules.php?mod=seguridad&op=process_data&act=2";
        }
    }
}
xmlhttp.open("POST","modules.php?mod=seguridad&op=process_data",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("act=1&v_pwd="+v_password+"&v_pwd2="+v_passwrod1+"&usr_id="+usr_id); //+"&num_agente="+num_agente);
}

</script>

    <div class="card text-center">
  <div class="card-header">
    <h2>Cambio de contrase&ntilde;a</h2>
  </div>
  <div class="card-body">
      <br>
<h5 align="center">
            Por motivos de la Norma ISO 27001 se Obliga a Cambiar el Password Cada Inicio de Mes<br/>    
        </h5>
      <ol style="text-transform: uppercase; font-size: 10px; text-align: center;">
            <li>El password debe tener almenos un car&aacute;cter especial !"#$%()*+,-./:;<=>?@�������[\]^_`{|}~�߱�</li>
            <li>La longitud debe ser 8 caracteres</li>
            <li>El password debe ser diferente a los 12 passwords anteriores</li>
            <li>Al finalizar, dar clic en continuar para entrar al sicall</li>
        </ol>      
Contraseña actual:<strong><?php echo isset($_SESSION['s_pwd']) ? $_SESSION['s_pwd'] : ''; ?></strong>
  <form id="form" name="form" method="post" >
  <div id="result_"></div>
  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Nueva Contraseña</label>
      <input type="password" id="password" name="password" class="form-control" required>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault03">Repite la contraseña:</label>
      <input type="password" id="password_again" name="password_again" class="form-control" required>
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-6 mb-3">
      <input type="hidden" name="usr_id" id="usr_id" class="form-control" value="<?php echo isset($_SESSION['s_usr_id2']) ? $_SESSION['s_usr_id2'] : ''; ?>" required>
    </div>
    <div class="col-md-6 mb-3">
      <input type="hidden" name="usr_campaign_id" id="usr_campaign_id" value="291" class="form-control" id="validationDefault03" required>
    </div>
  </div>
  <input class="btn btn-primary" type="submit" value="Cambiar Contraseña" name="cmdChange">
</form>
  </div>
</div>


<style>
    .error-message {
    color: red;
    font-size: 14px;
    margin-top: 5px;
}

</style>

<?php
layout_footer();
