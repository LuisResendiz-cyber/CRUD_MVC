const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

 const baseQuery = "BEGIN " + context.schema + ".PSI_TIPIFICACIONES(:p_numero,:p_id_cliente,:p_nombre_ejecutivo,:p_codigo_estatus,:p_codigo_producto,:p_solicitud, :p_hora, :p_respuesta_contacto_22, :p_resultado_peticion); END;";
  console.log(context);
  
   let query = baseQuery;
   const binds = {}; //Define un objeto para la variable SP

   try { 
    binds.p_numero = context.numero;
    binds.p_id_cliente = context.idCliente;
    binds.p_nombre_ejecutivo = context.nombreEjecutivo;
    binds.p_codigo_estatus = context.codigoStatus;
    binds.p_codigo_producto = context.codigoProducto;
    binds.p_solicitud = context.solicitud;
    binds.p_hora = context.time;
    binds.p_respuesta_contacto_22 = context.contacto22;
    binds.p_resultado_peticion = context.respuesta;

    const result = await database.simpleExecute(query, binds);
    console.log(result);
    return result;  
  } catch (error) {
    console.log(error);
   
  }
}

module.exports.find = find;
