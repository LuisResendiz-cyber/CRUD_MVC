const customerModel = require('../models/customerModel');

const CustomerController = {
    async getCustomers(req, res){
        try {
          const pcn = await customerModel.getCustomers();
          const phones = await customerModel.getPhones(pcn);
          
          res.json(phones);

        } catch (error) {
            
        }
    }
}

module.exports = CustomerController;