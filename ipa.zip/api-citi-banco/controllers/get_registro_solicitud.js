const get_registro_solicitud = require('../db_apis/get_registro_solicitud.js');
//const get_registro_solicitud_decrypt = require('../db_apis/get_registro_solicitud_decrypt.js');
const fetch = require('node-fetch');
const jwt = require('./token_manager');
const config  = require('../config/web-server');
async function post(req, res, next) {
  try {
    const context = req.body;//{};

    // const rows = await get_registro_solicitud.find(context);
    //  console.log(rows[0]);
    // let flag = false;
    //
    // if (rows[0].REGTOCADOS !== 'N') {
    //
    //   const params = {
    //     fecha_carga: rows[0].FECHA_CARGA,
    //     schema: context.schema
    //   };
    //
    //   console.log(params);
    //   if(rows[0].FECHA_CARGA){
    //     console.log('si');
    //   }
    //
    //   let data = await fetch(config.keyRingHost, {
    //     method: 'POST',
    //     headers: {
    //       'Content-Type': 'application/json',
    //       'access_token': jwt.get(),
    //       'Accept': 'application/json'
    //     },
    //     body: JSON.stringify(params)
    //   })
    //   .then(res=>res.json())
    //   .then(data=>{
    //     jwt.set(data.idtoken)
    //     context.keyrig = data.dataKey;
    //     context.error_kr = data.error;
    //     context.msg_kr = data.msg;
    //     context.v_registro = rows[0].REGISTRO;
    //     if(data.error === false){
    //       flag = true;
    //     } else{
    //       res.status(500);
    //       throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );
    //     }
    //   })
    //   .catch(err=>{
    //     res.status(500);
    //     return err;
    //   })
    // }else {
    //   flag === false;
    // }

    console.log(context);
    // try{
    //   if(flag == true){
    //     let rspta = await get_registro_solicitud.give(context);
    //     // console.log(rspta);
    //     res.status(200).json(rspta);
    //   }else{
    //     res.status(200).json(rows);
    //   }
    // } catch(err){
    //   next(err);
    // }

    let rows = await get_registro_solicitud.give(context);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }


  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
