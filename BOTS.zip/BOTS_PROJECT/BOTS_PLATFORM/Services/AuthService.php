<?php

class AuthService extends ApiClient
{



    //USERS
    public function login(string $email, string $password)
    {
        return $this->request('POST', 'Users/Login', [
            'email_user' => $email,
            'passwordHash'   => $password
        ]);
    }

    public function getAccesModules(int $idUser = 0)
    {

        return $this->request('GET', 'Users/getModules?id_user='. $idUser);
    }

    //ROLES
    public function getRoles(int $method = 0)
    {
        return $this->request('GET', 'Users/getRoles');
    }

    public function getRol(int $intIdrol = 0)
    {
        return $this->request('GET', 'Users/getRol?id=' . $intIdrol);
    }

    public function createRol(string $name = NULL, string $description = NULL, int $status = 1)
    {
        return $this->request('POST', 'Users/createRol', [
            'name' => $name, 
            'description' => $description,
            'status' =>  $status
        ]);
    }

    public function deleteRol(int $intIdrol = 0)
    {
        return $this->request('DELETE', 'Users/deleteRol/' . $intIdrol);
    }

    public function UpdatRol(int $intIdrol = 0)
    {
        return $this->request('PUT', 'Users/updateRol/' . $intIdrol);
    }

}
