document.addEventListener("DOMContentLoaded", () => {
  const chatBody = document.querySelector(".chat-body");
  const input = document.querySelector(".chat-footer input");
  const sendBtn = document.querySelector(".chat-footer button");

  if (!localStorage.getItem("chat_session_id")) {
    localStorage.setItem("chat_session_id", crypto.randomUUID());
  }
  window.__CHAT_SESSION_ID__ = localStorage.getItem("chat_session_id");

  // Activar input
  input.disabled = false;
  sendBtn.disabled = false;

  /* =========================
       UTIL: AGREGAR MENSAJE
    ========================== */
  function addMessage(text, type = "bot") {
    const message = document.createElement("div");
    message.className = `message ${type}`;

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    message.appendChild(bubble);
    chatBody.appendChild(message);

    chatBody.scrollTop = chatBody.scrollHeight;
  }

  /* =========================
       MOCK RESPUESTA BOT
    ========================== */
    async function sendMessageToBackend(text) {
        const response = await fetch("http://localhost:4001/apiV1/webchat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            session_id: window.__CHAT_SESSION_ID__,
            message: text
          })
        });
      
        const data = await response.json();
        return data.reply;
      }
      

  /* =========================
       ENVIAR MENSAJE
    ========================== */
    async function sendMessage() {
        const text = input.value.trim();
        if (!text) return;
      
        input.value = "";
      
        // 1️⃣ mostrar mensaje del usuario
        addMessage(text, "user");
      
        try {
          // 2️⃣ enviar al backend
          const reply = await sendMessageToBackend(text);
      
          // 3️⃣ mostrar respuesta del bot
          addMessage(reply, "bot");
        } catch (err) {
          console.error(err);
          addMessage("Ocurrió un error, intenta más tarde.", "bot");
        }
      }
      
  /* =========================
       EVENTOS
    ========================== */
  sendBtn.addEventListener("click", sendMessage);

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  });

  // Cerrar chat (enviar mensaje al padre)
  const closeBtn = document.querySelector(".chat-close");

  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      window.parent.postMessage({ type: "CHAT_WIDGET_CLOSE" }, "*");
    });
  }
});
