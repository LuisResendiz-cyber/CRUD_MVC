<?php
/*require_once("includes/includes.inc.php");
require_once("agentes.inc.php");*/

function darSaludo() {
    $iHora = date('H');

    if ($iHora >= 0 && $iHora < 12) {
        $sSaludo = "Buenos d&iacute;as";
    } else if ($iHora >= 12 && $iHora <= 19) {
        $sSaludo = "Buenas tardes";
    } else {
        $sSaludo = "Buenas noches";
    }

    return $sSaludo;
}

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agentes", "Script");

$u_persona = $_SESSION['datos_persona'][0]['U_PERSONA'];
//$rfc = $_SESSION['datos_persona'][0]['RFC'];
$nombre = $_SESSION['s_usr_nombre'];
//$apaterno = $_SESSION['datos_persona'][0]['APATERNO'];        
echo "<pre>";
 $productos_ = get_productos_campana($u_persona, $db);
 //print_r($productos_);
echo "</pre>";
$datos = get_datos_query2('XSP_GETDATOSCLIENTEINICIO_1('.$u_persona.',:rc)',$db);

echo "<pre>";
//print_r($datos);
echo "</pre>";
?>

<body>
    <table width="360" cellpadding="0" cellspacing="0">
        <tr>
            <td width="354" height="165" colspan="2" bgcolor="#FFFFF9" align="center">
                <div class=Section1>

                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=576
                           style='width:432.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes;
                            height:123.75pt'>
                            <td width=576 style='width:432.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                height:123.75pt'>
                                <p align=center style='text-align:center'><span style='font-size:9.0pt;
                                                                                font-family:Arial'>Logo <span class=SpellE>Amex</span><o:p></o:p></span></p>
                                <p class=style13 align=center style='text-align:center'><span class=SpellE><span
                                            style='font-size:9.0pt'>Script</span></span><span style='font-size:9.0pt'>
                                        <span class=SpellE>Venta Platinum</span><o:p></o:p></span></p>
                                <p class=MsoNormal align=center style='text-align:center'><strong><span
                                            style='font-size:9.0pt;font-family:Arial;color:blue'>No. de Solicitud: <?php echo $u_persona; ?> <br>Producto Origen: <?php echo$productos_->_array[$t]['NOMBRE'];?></span></strong><span
                                        style='font-size:9.0pt;font-family:Arial;color:blue'> <br style='mso-special-character:
                                                                                              line-break'>
                                        <![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
                                        <![endif]><o:p></o:p></span></p>
                                <div align=center>
                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=504
                                           style='width:378.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>SALUDO<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:1;height:14.25pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:14.25pt'>
                                                <p><span style='font-size:9.0pt;font-family:Arial'>Buen d&iacute;a Sr.(a)<!--span
                                                            class=style151><%=NombreCompleto%--> 
                                                        </span><span class=style151><b
                                                                style='mso-bidi-font-weight:normal'><span style='color:windowtext'></span></b></span>
                                                        habla <b style='mso-bidi-font-weight:normal'><?php echo $nombre; ?></b>
                                                        de American Express, es una llamada de servicio para hacerle saber los nuevos beneficios de la tarjeta Platinum de Servicios, es una de nuestras membres&iacute;as m&aacute;s exclusivas que tenemos para usted, perm&iacute;tame comentarle que:
                                                        <br></br>
                                                        Vamos a eliminar la anualidad de por vida de la tarjeta de Cr&eacute;dito (<strong><span
                                                                style='font-size:9.0pt;font-family:Arial;color:blue'><%=TipoTarjeta%></span></strong>) con la que usted cuenta actualmente, adem&aacute;s de esto vamos a eliminar el costo del programa Membership Rewards que actualmente tiene un costo de 40 USD + IVA anuales, le confirmo este costo ya no lo pagar&aacute; m&aacute;s de por vida mientras mantenga su nueva membres&iacute;a de servicios activa.
                                                        <br></br>
                                                        a)	Usted podr&aacute; recibir tarifas especiales en boletos de avi&oacute;n para su acompa&ntilde;ante, descuentos que van del 10% al 20% de descuento en categor&iacute;as Turista, Business y Primera Clase en diferentes aerol&iacute;neas como Air Canada, LAN, Japan Airles, British Airways, Aeromexico entre otras.
                                                        <br></br>
                                                        b)	Para completar la experiencia en viajes, hemos incluido a su membres&iacute;a <span style='font-size:9.0pt;font-family:Arial;color:white'>Priority Pass </span>nivel Prestige con la cual usted tendr&aacute; acceso ilimitado a m&aacute;s de 600 salas de espera en diferentes aeropuertos alrededor del mundo, adem&aacute;s de tener acceso ilimitado a nuestras exclusivas salas Centurion & Platinum en el aeropuerto de la Cd. De M&eacute;xico, Toluca, Guadalajara y Monterrey, el costo de la membres&iacute;a Priority Pass es de validez internacional y sin costo para usted de por vida.
                                                        <br></br>
                                                        c)	Sr. <span class=style151><%=NombreCompleto%> </span> usted contar&aacute; con el servicio de la unidad exclusiva Platinum/Centurion que estar&aacute; disponible para usted las 24/7 de la semana para atenderlo de inmediato cuando usted m&aacute;s lo requiera.  
                                                        <br></br>
                                                        d)	Unos de los grandes beneficios es que forma parte de &ldquo;Cava Club Selecci&oacute;n&rdquo; en la Europea, en d&oacute;nde al momento de inscribirse con su membres&iacute;a Platinum de Servicios recibir&aacute; una tarjeta de socio y un regalo de bienvenida correspondiente a una caja de vino de 12 botellas para usted, el costo de la inscripci&oacute;n es de 3 pagos de $1667MN
                                                        <br></br>
                                                        e)	Como Tarjetahabiente Platinum de Servicios recibir&aacute; invitaciones a exclusivos eventos de entretenimiento alrededor del mundo como:  galas privadas, noches de coctel o conciertos especiales que se realizan a lo largo del a&ntilde;o, as&iacute; como eventos deportivos de talla internacional e incluso ventas exclusivas de joyer&iacute;a y pasarelas, entre muchos otros. 
                                                        <br></br>
                                                        La membres&iacute;a Platinum de servicios tiene un costo de $800 usd m&aacute;s IVA, el cual se divide en 3 parcialidades de $266.66usd. m&aacute;s IVA c/u. Esta membres&iacute;a le incluye a usted su tarjeta como titular de la cuenta y 5 membres&iacute;as adicionales sin costo adicional de por vida
                                                        <br></br>
                                                        Solamente perm&iacute;tame corroborar algunos datos con usted en este momento y en un plazo no mayor a 10 d&iacute;as h&aacute;biles, recibir&aacute; en su domicilio la tarjeta Platinum. 
                                                        <br></br>
                                                        <br><b>
                                                            Me permito informarle  que en AMERICAN EXPRESS SUS DATOS PERSONALES ESTAN PROTEGIDOS.
                                                            Para mayor informacion podra consultar nuestro aviso de privacidad en:

                                                            <br></br>
                                                            www.americanexpress.com.mx
                                                        </b>
                                                        <br></br>
                                                        <!--span class=SpellE>reagendar</span> la llamada y
                                                    actualiza el status de la llamada ) <span class=SpellE>American</span>
                                                    Express le agradece el tiempo que nos otorgo, le recuerdo mi nombre es <b
                                                    style='mso-bidi-font-weight:normal'><%=NombreAgente%></b> asesor ejecutivo de <span
                                                    class=SpellE>American</span> Express<span style='color:red'><o:p></o:p></span></span></p>
                                                    <p><span class=style151><span style='font-size:9.0pt;font-family:Arial'>No </span></span><span
                                                    style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>
                                                    <p><span style='font-size:9.0pt;font-family:Arial'>Buenas tardes, le habla <b
                                                    style='mso-bidi-font-weight:normal'><%=NombreAgente%></b> asesor ejecutivo de <span
                                                    class=SpellE>American</span> Express, El motivo de mi llamada era para
                                                    invitar al Sr. (a) <b style='mso-bidi-font-weight:normal'><%= APaterno %></b> a
                                                    formar parte de nuestro selecto grupo de miembros, y en este momento me
                                                    gustar&iacute;a hacerle extensiva la invitaci&oacute;n a usted ¿con quien tengo el gusto?<o:p></o:p></span></p>
                                                    <p><span class=style71><span style='font-size:9.0pt;font-family:Arial'>Pasar
                                                    a oferta</span></span><span style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>
                                                    <p><span style='font-size:9.0pt;font-family:Arial;color:red'>No le interesa<o:p></o:p></span></p>
                                                    <p><span style='font-size:9.0pt;font-family:Arial'>Gracias muy amable, <span
                                                    class=SpellE>American</span> Express le agradece el tiempo que nos otorgo,
                                                    le recuerdo mi nombre es <b style='mso-bidi-font-weight:normal'><%=NombreAgente%></b><br
                                                    style='mso-special-character:line-break'>
                                                    <![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
                                                    <![endif]><o:p></o:p></span></p>
                                                    <p><span class=style71><span style='font-size:9.0pt;font-family:Arial'>S&iacute;
                                                    se encuentra el cliente, pasar a oferta</span></span><b><span
                                                    style='font-size:9.0pt;font-family:Arial;color:blue'><o:p></o:p></span></b></p>
                                                    </td>
                                                   </tr>
                                                   <tr style='mso-yfti-irow:2;height:12.75pt'>
                                                    <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                    height:12.75pt'>
                                                    <p class=MsoNormal align=center style='text-align:center'><b><span
                                                    style='font-size:9.0pt;font-family:Arial;color:white'>OFERTA<o:p></o:p></span></b></p>
                                                    </td>
                                                   </tr>
                                                   <tr style='mso-yfti-irow:3;height:15.0pt'>
                                                    <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                    height:15.0pt'>
                                                    <p><b><span style='font-size:9.0pt;font-family:Arial'>Buenos d&iacute;as <span
                                                    class=style151>Sr. /<span class=SpellE>Srita</span>. </span><span
                                                    class=GramE><span class=style151><span style='color:windowtext'><%= APaterno %></span>
                                                    </span><span style='font-weight:normal'>,</span></span></span></b><span
                                                    style='font-size:9.0pt;font-family:Arial'> <span class=style31><b><span
                                                    style='mso-ansi-font-size:9.0pt;mso-bidi-font-size:9.0pt'>mi nombre es <span
                                                    style='mso-spacerun:yes'> </span></span></b></span><span class=style151><b><span
                                                    style='color:windowtext'><%=NombreAgente%></span></b></span><span class=style31><b><span
                                                    style='mso-ansi-font-size:9.0pt;mso-bidi-font-size:9.0pt'> </span></b></span>asesor
                                                    ejecutivo de <span class=SpellE>American</span> Express, para invitarlo a
                                                    ser parte de nuestro selecto grupo de miembros a trav&eacute;s de las tarjetas <span
                                                    class=SpellE><b style='mso-bidi-font-weight:normal'>gold</b></span><b
                                                    style='mso-bidi-font-weight:normal'> elite</b> y <span class=SpellE><b
                                                    style='mso-bidi-font-weight:normal'>platinum</b></span><b style='mso-bidi-font-weight:
                                                    normal'> <span class=SpellE>credit</span> <span class=SpellE>card</span>,</b>
                                                    donde usted contar&aacute; con una diversa gama de beneficios.<o:p></o:p></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Actualmente cuenta con
                                                    tarjeta de cr&eacute;dito ¿verdad? <o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Bien con <span
                                                    class=SpellE>American</span> Express cada vez que usted realice sus compras
                                                    contar&aacute; con puntos que podr&aacute; cambiar por exclusivos art&iacute;culos del cat&aacute;logo
                                                    de <span class=SpellE>American</span> Express.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Sus ingresos mensuales
                                                    son arriba de 15,000 mil pesos ¿verdad?<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>¿Son comprobables?
                                                    Esto es para determinar que producto le conviene <span class=GramE>mas</span>.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>En <span class=SpellE>American</span>
                                                    Express contar&aacute; con un respaldo contra cargos no reconocidos. Si en su
                                                    estado de cuenta aparece un cargo que no realiz&oacute;, no tendr&aacute; que pagarlo, se
                                                    le restituye inmediatamente su cr&eacute;dito mientras se realiza la investigaci&oacute;n.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>¿Usted viaja <span
                                                    class=SpellE>Sr</span>?<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Si usted llega a
                                                    viajar podr&aacute; tener la seguridad de hacerlo tranquilamente al adquirir sus
                                                    boletos con nuestras tarjetas, ya que contar&aacute; con asistencia m&eacute;dica de
                                                    emergencia as&iacute; como traslado m&eacute;dico, protecci&oacute;n contra perdida de equipaje
                                                    y hospedaje por convalecencia.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Adem&aacute;s, contar&aacute; con un
                                                    seguro de accidentes por $ 250,000 <span class=SpellE>usd</span> para usted,
                                                    su esposa y sus hijos.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Si le parece bien le
                                                    corroboro sus datos:<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Su nombre completo es…<o:p></o:p></span></span></p>
                                                    <p><st1:PersonName ProductID="La Tarjeta" w:st="on"><span class=style31><span
                                                     style='font-size:9.0pt'>La Tarjeta</span></span></st1:PersonName><span
                                                    class=style31><span style='font-size:9.0pt'> que le estamos otorgando es: <b
                                                    style='mso-bidi-font-weight:normal'>GOLD ELITE / PLATINUM CREDIT CARD, </b>la
                                                    cual no tiene costo en la primera Anualidad, y le otorga hasta 3
                                                    adicionales sin costo de por vida. <o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Adem&aacute;s, por sus
                                                    compras que realice en los primeros 18 meses, le otorgamos un <b
                                                    style='mso-bidi-font-weight:normal'>30 / 60</b> de puntos en Gasolina, <b
                                                    style='mso-bidi-font-weight:normal'>20 / 40</b> en restaurantes y <b
                                                    style='mso-bidi-font-weight:normal'>10 / 20</b> en supermercados, con la
                                                    finalidad de que lo antes posible pueda estarlos cambiando por boletos de
                                                    avi&oacute;n, noches de hospedaje y dem&aacute;s art&iacute;culos exclusivos.<o:p></o:p></span></span></p>
                                                    <p><span class=style31><span style='font-size:9.0pt'>Se&ntilde;or, le pido me
                                                    proporcione los 4 últimos d&iacute;gitos de su tarjeta de cr&eacute;dito para poder
                                                    autenticar ante Bur&oacute; de Cr&eacute;dito su tr&aacute;mite.<o:p></o:p></span></span></p>
                                                    <p style='margin-bottom:12.0pt'><span class=style31><span style='font-size:
                                                    9.0pt;color:blue'>A continuaci&oacute;n lo transfiero al departamento de
                                                    validaci&oacute;n solo para confirmar los datos que me proporcion&oacute;, realizar su
                                                    firma electr&oacute;nica y finalizar el tr&aacute;mite.</span></span><span class=style31><span
                                                    style='font-size:9.0pt'><o:p></o:p></span></span></p-->
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:4;height:12.75pt'>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:12.75pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>CIERRE<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p><span class=style31><b><span style='font-size:9.0pt'><br>Manejo de objeciones y beneficios adicionales: </span></b></span><span
                                                        style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>

                                                <p><span class=style31><b><span style='font-size:9.0pt'><br>Objeci&oacute;n: &ldquo;La cuota es muy elevada y no veo atractivos los beneficios para m&iacute;&rdquo;</span></b></span><span
                                                        style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p><span
                                                    class=style31><span style='font-size:9.0pt'><span class=SpellE>Entiendo su preocupaci&oacute;n Sr.<span
                                                                class=style151><%=NombreCompleto%> </span><span class=style151><b style='mso-bidi-font-weight:normal'><span style='color:windowtext'></span></b></span></span>,
                                                        sin embargo, perm&iacute;tame resaltarle que usted estar&iacute;a obteniendo importantes ahorros en viajes. Por ejemplo, los descuentos en la compra de boletos de avi&oacute;n para usted y sus acompa&ntilde;antes, el boleto beneficio que tenemos con British Airways y Aeromexico en Business y Primera Clase. Con utilizar tan solo este beneficio una vez al a&ntilde;o, usted obtendr&iacute;a ahorros superiores a $8,000.
                                                        <br></br>
                                                        Otro ahorro son los $399 usd. de la membres&iacute;a Priority Pass que le dar&aacute; acceso a las m&aacute;s de 600 exclusivas salas de espera alrededor del mundo.
                                                        <br></br>
                                                        Adicionalmente, usted podr&aacute; compartir todos estos beneficios con sus seres queridos sin costo adicional, pues estamos incluyendo 5 tarjetas adicionales por una sola cuota anual.
                                                        <br></br>
                                                        Tan pronto reciba la tarjeta Platinum en su domicilio, le pido se comunique con nosotros para activarla y comience a gozar de todos los exclusivos beneficios que tiene la tarjeta Platinum de American Express.</span></span><span
                                                    style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>
                                                    <!--p><span class=SpellE><span class=style31><span style='font-size:9.0pt'>Sr</span></span></span><span
                                                    class=style31><span style='font-size:9.0pt'>/<span class=SpellE>Srita</span>,
                                                    no le pedir&eacute; datos confidenciales y yo le proporcionar&eacute; los datos de usted
                                                    con los que ya contamos para su simple corroboraci&oacute;n.</span></span><span
                                                    style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>
                                                    <p><span class=style31><b><span style='font-size:9.0pt'>YA CUENTO CON TDC</span></b></span><span
                                                    style='font-size:9.0pt;font-family:Arial'><o:p></o:p></span></p>
                                                    <p><span class=SpellE><span class=style31><span style='font-size:9.0pt'>Sr</span></span></span><span
                                                    class=style31><span style='font-size:9.0pt'>/<span class=SpellE>Srita</span>,
                                                    le sugiero no deje pasar la oportunidad de haber sido seleccionado por <span
                                                    class=SpellE>American</span> Express para gozar de estos beneficios
                                                    exclusivos que no le otorgan ninguna otra TDC, adem&aacute;s esta TDC es
                                                    independiente a la que maneja, y le recuerdo que no tiene costo de
                                                    anualidad el primer a&ntilde;o.<o:p></o:p></span></span></p>
                                                    <p><span style='font-size:9.0pt;font-family:Arial'><o:p>&nbsp;</o:p></span></p--><br>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:6;height:12.75pt'>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:12.75pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>PUNTOS IMPORTANTES QUE NO DEBES OLVIDAR:<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:7;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <ul type=disc>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                        auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'><b><span
                                                                style='font-size:9.0pt;font-family:Arial'>No utilizar como argumento de venta el CANCELAR la tarjeta anterior. </span>
                                                            <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'><b><span
                                                                        style='font-size:9.0pt;font-family:Arial'>No mencionar que se har&aacute; ajuste de cuota proporcional en la tarjeta actual como  	&ldquo;argumento de venta 	&rdquo;. </span></b><!--span
                                                                        style='font-size:9.0pt;font-family:Arial'> Todas las compras generan
                                                                        puntos, son acumulables, no tiene vigencia, cuenta con diferentes
                                                                        promociones y aceleradores para canjearlos. <o:p></o:p></span></li>
                                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                        auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'><b><span
                                                                        style='font-size:9.0pt;font-family:Arial'>PROMOCIONES EXCLUSIVAS:</span></b><span
                                                                        style='font-size:9.0pt;font-family:Arial'> Meses sin Intereses en
                                                                        diversas tiendas, adem&aacute;s, promociones exclusivas para nuestros <span
                                                                        class=SpellE>tarjetahabientes</span> y planes de financiamiento que se
                                                                        ajustan a las necesidades del cada cliente. <o:p></o:p></span></li>
                                                                   </ul-->
                                                                </td>
                                                                </tr>
                                                                <!--tr style='mso-yfti-irow:8;height:12.75pt'>
                                                                 <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                                 height:12.75pt'>
                                                                 <p class=MsoNormal align=center style='text-align:center'><b><span
                                                                 style='font-size:9.0pt;font-family:Arial;color:white'>REQUISITOS<o:p></o:p></span></b></p>
                                                                 </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:9;mso-yfti-lastrow:yes;height:15.0pt'>
                                                                 <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                                 height:15.0pt'>
                                                                 <ul type=disc>
                                                                  <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                      auto;mso-list:l0 level1 lfo3;tab-stops:list 36.0pt'><span
                                                                      style='font-size:9.0pt;font-family:Arial'>Edad entre 18 y 75 a&ntilde;os. <o:p></o:p></span></li>
                                                                  <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                      auto;mso-list:l0 level1 lfo3;tab-stops:list 36.0pt'><span
                                                                      style='font-size:9.0pt;font-family:Arial'>Ingresos m&iacute;nimos de $15,000
                                                                      mensuales comprobables. <o:p></o:p></span></li>
                                                                  <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                      auto;mso-list:l0 level1 lfo3;tab-stops:list 36.0pt'><span
                                                                      style='font-size:9.0pt;font-family:Arial'>Antigüedad en domicilio y
                                                                      empleo m&iacute;nima de 3 meses. <o:p></o:p></span></li>
                                                                  <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                      auto;mso-list:l0 level1 lfo3;tab-stops:list 36.0pt'><span
                                                                      style='font-size:9.0pt;font-family:Arial'>Nacionalidad mexicana (IFE o
                                                                      Pasaporte), y en caso de ser extranjero (FM2). <o:p></o:p></span></li>
                                                                  <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                                                                      auto;mso-list:l0 level1 lfo3;tab-stops:list 36.0pt'><span
                                                                      style='font-size:9.0pt;font-family:Arial'>Ser titular m&iacute;nimo de una
                                                                      tarjeta de CR&eacute;DITO bancaria o departamental, <span class=GramE>m&iacute;nimo</span>
                                                                      con 1 a&ntilde;o de <span class=SpellE>antiguedad</span>. <o:p></o:p></span></li>
                                                                 </ul>
                                                                 </td>
                                                                </tr-->
                                                                </table>
                                                                </div>
                                                                <p align=center style='text-align:center'>&nbsp;</p>
                                                                </td>
                                                                </tr>
                                                                </table>
                                                                </body>

