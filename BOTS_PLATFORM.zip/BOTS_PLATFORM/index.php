<?php 
	require_once("Config/Config.php");
	require_once("Helpers/Helpers.php");
	require_once("Helpers/api_helper.php"); // <-- AÑADE ESTA LÍNEA


	// En tu index.php, después de cargar los helpers, puedes agregar esto temporalmente:

    require_once("Controllers/TestApi.php");
    $testController = new TestApi();
    if ($method == 'test') {
        $testController->test();
    } elseif ($method == 'usuarios') {
        $testController->testUsuario();
    }
    exit();



	
	$url = !empty($_GET['url']) ? $_GET['url'] : 'home/home';
	$arrUrl = explode("/", $url);
	$controller = $arrUrl[0];
	$method = $arrUrl[0];
	$params = "";

	if(!empty($arrUrl[1]))
	{
		if($arrUrl[1] != "")
		{
			$method = $arrUrl[1];	
		}
	}

	if(!empty($arrUrl[2]))
	{
		if($arrUrl[2] != "")
		{
			for ($i=2; $i < count($arrUrl); $i++) {
				$params .=  $arrUrl[$i].',';
				# code...
			}
			$params = trim($params,',');
		}
	}
	require_once("Libraries/Core/Autoload.php");
	require_once("Libraries/Core/Load.php");

 ?>