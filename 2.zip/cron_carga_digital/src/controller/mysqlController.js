import myslqAccions from "../model/mysqlModel.js";

export const checkConn = async () => {
  const rspta = await myslqAccions.checkConn()
  return rspta
}


export const saveLog = async(paso,estatus,commentarios = 'NA') => {
  await myslqAccions.insertLog(paso,estatus,commentarios)  
}