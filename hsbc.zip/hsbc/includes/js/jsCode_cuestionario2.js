//var arrayTitular = ['nombrepila', 'nombreseg', 'appaterno', 'apmaterno', 'FECHA_NAC', 'RFC'];
var arrayCamps = [
  ['nombrepila', 'nombreseg', 'appaterno', 'apmaterno', 'FECHA_NAC', 'RFC'],
  ['nombre_bene1', 'nombre_bene1', 'appaterno_bene1', 'apmaterno_bene1', 'fechanacimiento_bene1', 'rfc_bene1'],
  ['nombre_bene2', 'nombre_bene2', 'appaterno_bene2', 'apmaterno_bene2', 'fechanacimiento_bene2', 'rfc_bene2'],
  ['nombre_bene3', 'nombre_bene3', 'appaterno_bene3', 'apmaterno_bene3', 'fechanacimiento_bene3', 'rfc_bene3']
];

$(function() {
  /*$(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno, #fechanacimiento', function(event) {
  event.preventDefault();
  verifica_RFC();
});*/

var parar = 4;
for(var i=0; i<parar; i++){
  //console.log(arrayCamps[i]);
  for(var j=0; j<(arrayCamps[i].length-1); j++){
    if(i>0){
      var param_extra = 1;
    } else{
      var param_extra = null;
    }

    //$(document).on('change', '#'+arrayCamps[i][j], function(event){
    //if($('#'+arrayCamps[i][j]).length > 0){
    $('#'+arrayCamps[i][j]).attr('onchange', 'verifica_RFC(['+arrayCamps[i]+'], '+parar+', '+param_extra+');');
    //}

    //event.preventDefault();

    //});
  }
}

// $(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno, #fechanacimiento', function(event) {
//     event.preventDefault();
//     verifica_RFC();
// });

$(document).on('change', '#nombrepila, #nombreseg, #appaterno, #apmaterno', function(event) {
  event.preventDefault();
  var str = $(this).val();


  if (str.match(/(\d+)/)[1]) {
    alert("No se permiten nÃºmeros");
    $(this).val("");
  }
});

// // arreglo de inputs CPs
// const array_botones_cp = ["CP1", "CP_A1", "CP_A2", "CP_A3"];
// // const array_selects = [
// //     /*['COLONIA1', 'MUNICIPIO1', 'ESTADO1', 'CIUDAD1'],*/
// //     ['COLONIA_A1', 'MUNICIPIO_A1', 'ESTADO_A1', 'CIUDAD_A1'],
// //     ['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'],
// //     ['COLONIA_A3', 'MUNICIPIO_A3', 'ESTADO_A3', 'CIUDAD_A3']
// // ]
// // const array_valores = [
// //     /*['MANA_2_5', 'MANA_2_6', 'MANA_2_7', 'MANA_2_8'], // titular*/
// //     ['MANA_6_16', 'MANA_6_17', 'MANA_6_18', 'MANA_6_19'], // beneficiario 1
// //     ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'], // beneficiario 2
// //     ['MANA_62_16', 'MANA_62_17', 'MANA_62_18', 'MANA_62_19'] // beneficiario 3
// // ];

// // obtener el total de beneficiarios
// var num_beneficiarios = parseInt($('#num_beneficiarios').val());
// var total_recorrer = 1 + num_beneficiarios; // titular + nÃºmero de beneficiarios
// /*for(var i=0; i<total_recorrer; i++){
//     clickea_boton(array_botones_cp[i]);
// }*/


// setTimeout(function(){clickea_boton('CP1')},1000);
// setTimeout(function(){selecciona_valores(['COLONIA1', 'MUNICIPIO1', 'ESTADO1', 'CIUDAD1'], ['MANA_2_5', 'MANA_2_6', 'MANA_2_7', 'MANA_2_9'])},1500);

// setTimeout(function(){clickea_boton('CP_A1')},2000);
// setTimeout(function(){selecciona_valores(['COLONIA_A1', 'MUNICIPIO_A1', 'ESTADO_A1', 'CIUDAD_A1'], ['MANA_6_16', 'MANA_6_17', 'MANA_6_18', 'MANA_6_19'])},2500);

// if(total_recorrer == 3){
//     setTimeout(function(){clickea_boton('CP_A2')},3000);
//     setTimeout(function(){selecciona_valores(['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'], ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'])},3500);
// }

// if(total_recorrer == 4){
//     setTimeout(function(){clickea_boton('CP_A2')},3000);
//     setTimeout(function(){selecciona_valores(['COLONIA_A2', 'MUNICIPIO_A2', 'ESTADO_A2', 'CIUDAD_A2'], ['MANA_61_16', 'MANA_61_17', 'MANA_61_18', 'MANA_61_19'])},3500);
//     setTimeout(function(){clickea_boton('CP_A3')},4000);
//     setTimeout(function(){selecciona_valores(['COLONIA_A3', 'MUNICIPIO_A3', 'ESTADO_A3', 'CIUDAD_A3'], ['MANA_62_16', 'MANA_62_17', 'MANA_62_18', 'MANA_62_19'])},4500);
// }
//for(var i=0; i<total_recorrer; i++){
/*for(var i=0; i<num_beneficiarios; i++){
var id_cp = array_botones_cp[i];
//setTimeout(function(){
obtener_demograficos(id_cp, array_valores[i], array_selects[i]);
//},100);
}*/
// fin del ready
//$('#email').attr('onblur', 'validarEmail(event, this.value);');
$('#email').attr('onblur', 'validarDato(this.value, this.id);');
$('#fecha_cobro').attr('onblur', 'validarDato(this.value, this.id);');
});

$(document).ready(function(){


  convierteDatepicker('FECHA_NAC');
  convierteDatepicker('fechanacimientoA1');
  convierteDatepicker('fechanacimientoA2');
  convierteDatepicker('fechanacimientoA3');
  convierteDatepicker('fechanacimientoA4');
  convierteDatepicker('fechanacimientoA5');
  convierteDatepicker('fechanacimiento_bene1');
  convierteDatepicker('fechanacimiento_bene2');
  convierteDatepicker('fechanacimiento_bene3');
  addValidaTipoDato([
    ['#nombrepila', regExpTexto],
    ['#nombreseg', regExpTexto],
    ['#appaterno', regExpTexto],
    ['#apmaterno', regExpTexto],
    ['#FECHA_NAC', regExpFecha1],
    ['#nombre_bene1', regExpTexto],
    ['#appaterno_bene1', regExpTexto],
    ['#apmaterno_bene1', regExpTexto],
    ['#fechanacimiento_bene1', regExpFecha1],
    ['#nombre_bene2', regExpTexto],
    ['#appaterno_bene2', regExpTexto],
    ['#apmaterno_bene2', regExpTexto],
    ['#fechanacimiento_bene2', regExpFecha1],
    ['#nombre_bene3', regExpTexto],
    ['#appaterno_bene3', regExpTexto],
    ['#apmaterno_bene3', regExpTexto],
    ['#fechanacimiento_bene3', regExpFecha1]
]);


const precioHC9 = document.getElementById("precio");

precioHC9.addEventListener("input", updateValue);

function updateValue(e) {
  const valor = event.target.value;
  const patron = /^[0-9]*\.?[0-9]*$/;

  if (!patron.test(valor)) {
    // event.target.value = ''
      precioHC9.style.borderColor = "red";
      precioHC9.placeholder = "Solo numeros";
      precioHC9.value="";
  }
}


});

function clickea_boton(id_boton){
  $("#"+id_boton).click();
}

function selecciona_valores(array_selects, array_valores){
  for(var i=0; i<array_valores.length; i++){
    var valor = $('#'+array_valores[i]).val();
    recorreSelect(array_selects[i], valor);
  }
}

/*function obtener_demograficos(id_boton, array_valores, array_selects){
setTimeout(function(){
$("#"+id_boton).click();
},500);

setTimeout(function(){
for(var i=0; i<array_valores.length; i++){
var valor = $('#'+array_valores[i]).val();
recorreSelect(array_selects[i], valor);
}
},2000);
}*/

function recorreSelect(id_select, valor){
  $('#'+id_select+' option').each(function(){
    if($(this).val() == valor){
      $(this).attr('selected', true);
    }
  });
}


function SubmitForm(){

    //alert($('[name=txtQId11CId7]').val().length);
///MODIFICACION PARA LONGITUD DE RFC
     /* if($('[name=txtQId21CId7]').val().length != 13 || $('[name=txtQId21CId7]').val().length != '13' ){
            alert('longitud no valida RFC');
            return false;

            txtQId26CId11
            txtQId261CId11
            txtQId262CId11

        }*/
        let numeroAsegurados = $('[name=txtQId220CId1]')?.val().trim();
        let coberturaAsistencia = $('[name=txtQId21CId23]')
        let coberturaApoyoGastosFunerarios = $('[name=txtQId21CId24]')?.val();
        
        coberturaAsistencia.html('');
        coberturaAsistencia.append('<option value="1" selected>SI</option>');

        // 
        if (numeroAsegurados >= 1 && coberturaApoyoGastosFunerarios == 1) {
          alert('No puedes tener asegurados y seleccionar cobertura de apoyo gastos funerarios')
          return false
        }
        // else{
        //   console.log('no---')
        //   console.log(coberturaApoyoGastosFunerarios)
        // }



      //   if(RFC_AUXILIAR.length != 13 || RFC_AUXILIAR.length != '13' ){
      //     alert('Longitud RFC no valida');
      //     return false;
      // }


        var RFC_AUXILIAR = $('[name=txtQId21CId7]').val().trim();
        var numero_beneficiarios = $("select[name=txtQId210CId1]").val();

        // console.log(RFC_AUXILIAR);
        console.log(RFC_AUXILIAR.length + ' RFC TITULAR');

        if(RFC_AUXILIAR.length != 13 || RFC_AUXILIAR.length != '13' ){
            alert('Longitud RFC no valida');
            return false;
        }

        let nameBeneficiarios = ['txtQId26CId11', 'txtQId261CId11', 'txtQId262CId11'];

        if (numero_beneficiarios > 0 ) {
            for (let i = 0; i < numero_beneficiarios; i++) {
                console.log(nameBeneficiarios[i]);
                var rfc_beneficiario = $('[name='+nameBeneficiarios[i]+']').val().trim();
                console.log(rfc_beneficiario);
                console.log(RFC_AUXILIAR.length + ' RFC BEN ' + parseInt(i+1));
                if(rfc_beneficiario.length != 13 || rfc_beneficiario.length != '13' ){
                    alert('Longitud RFC beneficiario ' + parseInt(i+1) + ' no valida');
                    return false;
                }
            }
        }


  var array1 = [5,9,13,23,28,29,31,35,37,38,44,57,59,64,65,68,78,81,83,110,134,139,140,150,155,171,172,175,176,177,181,190,202,212,216,218,230];

var valorOcupacion = $('[name=txtQId21CId17]').val();

    // if(array1.includes(parseInt(valorOcupacion)) == true){
    //
    //     alert('Ocupacion no valida');
    //     return false;
    //
    // }

  //Asegurados
  var numro_aseg = $("select[name=txtQId220CId1]").val();//numero de asegurados
  //if(numro_aseg == ""){alert("Numero de asegurados no puede ir vacio"); return false;}

  if (numro_aseg >= 1){

    //Asegurado 1
    var resultadolefechaA1 = false;
    var fecha_lenA1 = $("input[name=txtQId211CId8]").val();
    // var total = fecha_lenA1.length;
    // if(total == 10){
      // var fecha_splitA1 = fecha_lenA1.split('/');
      // if (fecha_splitA1[0].length == 2 && fecha_splitA1[1].length == 2 && fecha_splitA1[2].length == 4){
      //   resultadolefechaA1 =  true;
      //        // alert("fecha1 "+fecha_splitA1[0].length+" - "+fecha_splitA1[1].length+" - "+fecha_splitA1[2].length);
      //    // alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del asegurado 1 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del asegurado 1 incorecta");
    //   return false;
    // }

    var nombreA1 = $("input[name=txtQId211CId1]").val();
    var apellidopA1 = $("input[name=txtQId211CId3]").val();
    var apellidoAm1 = $("input[name=txtQId211CId4]").val();
    var sexoA1 = $("select[name=txtQId211CId15]").val();
    var naciolidadA1 = $("select[name=txtQId211CId14]").val();
    var ocupacionA1 = $("select[name=txtQId211CId16]").val();
    var parentescoA1 = $("select[name=txtQId211CId17]").val();
    var civilA1 = $("select[name=txtQId211CId10]").val();
    var cargoA1 = $("select[name=txtQId211CId22]").val();
    var nacimientoA1 = $("select[name=txtQId211CId12]").val();
    var actividadA1 = $("select[name=txtQId211CId23]").val();

    var camposA1 = new Array();

    if(sexoA1 == ''){camposA1.push('Genero A1')}
    if(nombreA1 == ''){camposA1.push('nombre A1')}
    if(apellidopA1 == ''){camposA1.push('apellidoP A1')}
    if(apellidoAm1 == ''){camposA1.push('apellidoM A1')}
    if(naciolidadA1 == ''){camposA1.push('Nacionalidad A1')}
    if(ocupacionA1 == ''){camposA1.push('Ocupacion A1')}
    if(parentescoA1 == ''){camposA1.push('Parentesco A1')}
    if(civilA1 == ''){camposA1.push('Edo. Civil A1')}
    if(cargoA1 == ''){camposA1.push('Cargo A1')}
    if(nacimientoA1 == ''){camposA1.push('Nacimiento A1')}
    if(actividadA1 == ''){camposA1.push('Actividad A1')}

      if (sexoA1 == "" || nombreA1 == "" || apellidopA1 == "" || apellidoAm1 == ""|| naciolidadA1 == ""|| ocupacionA1 == ""|| parentescoA1 == ""||civilA1 == "" || nacimientoA1 == "" || cargoA1 == "" || actividadA1 == ""){
        //alert("debe llenar todos los campos que son obligatorios: "+campos);
        var campos_A1 = '';
        for(var j=0; j<camposA1.length; j++){
          campos_A1 = campos_A1 + camposA1[j] + '\r\n';
        }
        alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_A1);
        return false;
      }
}

if (numro_aseg >= 2 ){

    //con asegurado 2

    var resultadolefechaA2 = false;
    var fecha_lenA2 = $("input[name=txtQId212CId8]").val();

    // var total = fecha_lenA2.length;
    // if(total == 10){
      // var fecha_splitA2 = fecha_lenA2.split('/');
      // if (fecha_splitA2[0].length == 2 && fecha_splitA2[1].length == 2 && fecha_splitA2[2].length == 4){
      //   resultadolefechaA2 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del asegurado 2 incorecta");
      //   return false;
      // }
    // }else{
    //     alert("fecha formato del asegurado 2 incorecta");
    //     return false;
    // }


    //VALIDACION DE VACIOS ASEGURADO (2)A
    var nombreA2 = $("input[name=txtQId212CId1]").val();
    var apellidopA2 = $("input[name=txtQId212CId3]").val();
    var apellidoAm2 = $("input[name=txtQId212CId4]").val();
    var sexoA2 = $("select[name=txtQId212CId15]").val();
    var naciolidadA2 = $("select[name=txtQId212CId14]").val();
    var ocupacionA2 = $("select[name=txtQId212CId16]").val();
    var parentescoA2 = $("select[name=txtQId212CId17]").val();
    var civilA2 = $("select[name=txtQId212CId10]").val();
    var cargoA2 = $("select[name=txtQId212CId22]").val();
    var nacimientoA2 = $("select[name=txtQId212CId12]").val();
    var actividadA2 = $("select[name=txtQId212CId23]").val();

    var camposA2 = new Array();

    if(sexoA2 == ''){camposA2.push('Genero A2')}
    if(nombreA2 == ''){camposA2.push('nombre A2')}
    if(apellidopA2 == ''){camposA2.push('apellidoP A2')}
    if(apellidoAm2 == ''){camposA2.push('apellidoM A2')}
    if(naciolidadA2 == ''){camposA2.push('Nacionalidad A2')}
    if(ocupacionA2 == ''){camposA2.push('Ocupacion A2')}
    if(parentescoA2 == ''){camposA2.push('Parentesco A2')}
    if(civilA2 == ''){camposA2.push('Edo. Civil A2')}
    if(cargoA2 == ''){camposA2.push('Cargo A2')}
    if(nacimientoA2 == ''){camposA2.push('Lugar de Nacimiento A2')}
    if(actividadA2 == ''){camposA2.push('Actividad A2')}

    if (sexoA2 == "" || nombreA2 == "" || apellidopA2 == "" || apellidoAm2 == ""|| naciolidadA2 == ""|| ocupacionA2 == ""|| parentescoA2 == ""||civilA2 == ""  || nacimientoA2 == "" || cargoA2 == "" || actividadA2 == ""){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_A2 = '';
      for(var z=0; z<camposA2.length; z++){
        campos_A2 = campos_A2 + camposA2[z] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_A2);
      return false;
    }
  }

  if (numro_aseg >= 3){
    //con asegurado 3

    var resultadolefechaA3 = false;
    var fecha_lenA3 = $("input[name=txtQId213CId8]").val();

    // var total = fecha_lenA3.length;
    //   if(total == 10){
      // var fecha_splitA3 = fecha_lenA3.split('/');
      // if (fecha_splitA3[0].length == 2 && fecha_splitA3[1].length == 2 && fecha_splitA3[2].length == 4){
      //   resultadolefechaA3 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del asegurado 3 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del asegurado 3 incorecta");
    //   return false;
    // }

    //VALIDACION DE VACIOS ASEGURADO (3)
    var nombreA3 = $("input[name=txtQId213CId1]").val();
    var apellidopA3 = $("input[name=txtQId213CId3]").val();
    var apellidomA3 = $("input[name=txtQId213CId4]").val();
    var sexoA3 = $("select[name=txtQId213CId15]").val();
    var naciolidadA3 = $("select[name=txtQId213CId14]").val();
    var ocupacionA3 = $("select[name=txtQId213CId16]").val();
    var parentescoA3 = $("select[name=txtQId213CId17]").val();
    var civilA3 = $("select[name=txtQId213CId10]").val();
    var cargoA3 = $("select[name=txtQId213CId22]").val();
    var nacimientoA3 = $("select[name=txtQId213CId12]").val();
    var actividadA3 = $("select[name=txtQId213CId23]").val();

    var camposA3 = new Array();

    if(sexoA3 == ''){camposA3.push('Genero A3')}
    if(nombreA3 == ''){camposA3.push('nombre A3')}
    if(apellidopA3== ''){camposA3.push('apellidoP A3')}
    if(apellidomA3 == ''){camposA3.push('apellidoM A3')}
    if(naciolidadA3 == ''){camposA3.push('Nacionalidad A3')}
    if(ocupacionA3 == ''){camposA3.push('Ocupacion A3')}
    if(parentescoA3 == ''){camposA3.push('Parentesco A3')}
    if(civilA3 == ''){camposA3.push('Edo. Civil A3')}
    if(cargoA3 == ''){camposA3.push('Cargo A3')}
    if(nacimientoA3 == ''){camposA3.push('Lugar Nacimiento A3')}
    if(actividadA3 == ''){camposA3.push('Actividad A3')}

    if (sexoA3 == "" || nombreA3 == "" || apellidopA3 == "" || apellidomA3 == ""|| naciolidadA3 == ""|| ocupacionA3 == ""|| parentescoA3 == ""|| nacimientoA3 == "" || cargoA3 == "" || actividadA3 == ""){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_A3 = '';
      for(var zz=0; zz<camposA3.length; zz++){
        campos_A3 = campos_A3 + camposA3[zz] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_A3);
      return false;
    }
  }

if (numro_aseg >= 4){
    //con asegurado 3

    var resultadolefechaA4 = false;
    var fecha_lenA4 = $("input[name=txtQId214CId8]").val();

    // var total = fecha_lenA3.length;
    //   if(total == 10){
      // var fecha_splitA3 = fecha_lenA3.split('/');
      // if (fecha_splitA3[0].length == 2 && fecha_splitA3[1].length == 2 && fecha_splitA3[2].length == 4){
      //   resultadolefechaA3 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del asegurado 3 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del asegurado 3 incorecta");
    //   return false;
    // }

    //VALIDACION DE VACIOS ASEGURADO (3)
    var nombreA4 = $("input[name=txtQId214CId1]").val();
    var apellidopA4 = $("input[name=txtQId214CId3]").val();
    var apellidomA4 = $("input[name=txtQId214CId4]").val();
    var sexoA4 = $("select[name=txtQId214CId15]").val();
    var naciolidadA4 = $("select[name=txtQId214CId14]").val();
    var ocupacionA4 = $("select[name=txtQId214CId16]").val();
    var parentescoA4 = $("select[name=txtQId214CId17]").val();
    var civilA4 = $("select[name=txtQId214CId10]").val();
    var cargoA4 = $("select[name=txtQId214CId22]").val();
    var nacimientoA4 = $("select[name=txtQId214CId12]").val();
    var actividadA4 = $("select[name=txtQId214CId23]").val();

    var camposA4 = new Array();

    if(sexoA4 == ''){camposA4.push('Genero A4')}
    if(nombreA4 == ''){camposA4.push('nombre A4')}
    if(apellidopA4== ''){camposA4.push('apellidoP A4')}
    if(apellidomA4 == ''){camposA4.push('apellidoM A4')}
    if(naciolidadA4 == ''){camposA4.push('Nacionalidad A4')}
    if(ocupacionA4 == ''){camposA4.push('Ocupacion A4')}
    if(parentescoA4 == ''){camposA4.push('Parentesco A4')}
    if(civilA4 == ''){camposA4.push('Edo. Civil A4')}
    if(cargoA4 == ''){camposA4.push('Cargo A4')}
    if(nacimientoA4 == ''){camposA4.push('Lugar Nacimiento A4')}
    if(actividadA4 == ''){camposA4.push('Actividad A4')}

    if (sexoA4 == "" || nombreA4 == "" || apellidopA4 == "" || apellidomA4 == ""|| naciolidadA4 == ""|| ocupacionA4 == ""|| parentescoA4 == ""|| nacimientoA4 == "" || cargoA4 == "" || actividadA4 == ""){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_A4 = '';
      for(var zz=0; zz<camposA4.length; zz++){
        campos_A4 = campos_A4 + camposA4[zz] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_A4);
      return false;
    }
  }

if (numro_aseg >= 5){
    //con asegurado 3

    var resultadolefechaA5 = false;
    var fecha_lenA5 = $("input[name=txtQId215CId8]").val();

    // var total = fecha_lenA3.length;
    //   if(total == 10){
      // var fecha_splitA3 = fecha_lenA3.split('/');
      // if (fecha_splitA3[0].length == 2 && fecha_splitA3[1].length == 2 && fecha_splitA3[2].length == 4){
      //   resultadolefechaA3 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del asegurado 3 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del asegurado 3 incorecta");
    //   return false;
    // }

    //VALIDACION DE VACIOS ASEGURADO (3)
    var nombreA5 = $("input[name=txtQId215CId1]").val();
    var apellidopA5 = $("input[name=txtQId215CId3]").val();
    var apellidomA5 = $("input[name=txtQId215CId4]").val();
    var sexoA5 = $("select[name=txtQId215CId15]").val();
    var naciolidadA5 = $("select[name=txtQId215CId14]").val();
    var ocupacionA5 = $("select[name=txtQId215CId16]").val();
    var parentescoA5 = $("select[name=txtQId215CId17]").val();
    var civilA5 = $("select[name=txtQId215CId10]").val();
    var cargoA5 = $("select[name=txtQId215CId22]").val();
    var nacimientoA5 = $("select[name=txtQId215CId12]").val();
    var actividadA5 = $("select[name=txtQId215CId23]").val();

    var camposA5 = new Array();

    if(sexoA5 == ''){camposA5.push('Genero A5')}
    if(nombreA5 == ''){camposA5.push('nombre A5')}
    if(apellidopA5== ''){camposA5.push('apellidoP A5')}
    if(apellidomA5 == ''){camposA5.push('apellidoM A5')}
    if(naciolidadA5 == ''){camposA5.push('Nacionalidad A5')}
    if(ocupacionA5 == ''){camposA5.push('Ocupacion A5')}
    if(parentescoA5 == ''){camposA5.push('Parentesco A5')}
    if(civilA5 == ''){camposA5.push('Edo. Civil A5')}
    if(cargoA5 == ''){camposA5.push('Cargo A5')}
    if(nacimientoA5 == ''){camposA5.push('Lugar Nacimiento A5')}
    if(actividadA5 == ''){camposA5.push('Actividad A5')}

    if (sexoA5 == "" || nombreA5 == "" || apellidopA5 == "" || apellidomA5 == ""|| naciolidadA5 == ""|| ocupacionA5 == ""|| parentescoA5 == ""|| nacimientoA5 == "" || cargoA5 == "" || actividadA5 == ""){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_A5 = '';
      for(var zz=0; zz<camposA5.length; zz++){
        campos_A5 = campos_A5 + camposA5[zz] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_A5);
      return false;
    }
  }


//
//Beneficiarios
//

//Valida si combo beneficiarios tenga mÃ¡s de uno
var numro_adic = $("select[name=txtQId210CId1]").val();//numero de beneficiarios
if(numro_adic == ""){alert("Numero de beneficiarios no puede ir vacio"); return false;}


  if (numro_adic >= 1){
    //Beneficiario 1
    var resultadolefechab1 = false;
    var fecha_lenb1 = $("input[name=txtQId26CId4]").val();

    // var total = fecha_lenb1.length;
    // if(total == 10){
      // var fecha_splitb1 = fecha_lenb1.split('/');
      // if (fecha_splitb1[0].length == 2 && fecha_splitb1[1].length == 2 && fecha_splitb1[2].length == 4){
      //   resultadolefechab1 =  true;
      //        // alert("fecha2 "+fecha_splitb1[0].length+" - "+fecha_splitb1[1].length+" - "+fecha_splitb1[2].length);
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del beneficiario 1 incorecta");
      //   return false;
      // }
    // }else{
    //     alert("fecha formato del beneficiario 1 incorecta");
    //     return false;
    // }

    var nombreb1 = $("input[name=txtQId26CId1]").val();
    var apellidopb1 = $("input[name=txtQId26CId2]").val();
    var apellidopm1 = $("input[name=txtQId26CId3]").val();
    var sexob1 = $("select[name=txtQId26CId9]").val();
    var naciolidadb1 = $("select[name=txtQId26CId6]").val();
    var ocupacionb1 = $("select[name=txtQId26CId7]").val();
    var parentescob1 = $("select[name=txtQId26CId8]").val();
    var civilb1 = $("select[name=txtQId26CId10]").val();
    var rfcb1 = $("input[name=txtQId26CId11]").val();
    var residenciab1 = $("select[name=txtQId26CId21]").val();
    var cargob1 = $("select[name=txtQId26CId22]").val();
    var actividadb1 = $("select[name=txtQId26CId23]").val();

    var camposb1 = new Array();

    if(sexob1 == ''){camposb1.push('Genero B1')}
    if(nombreb1 == ''){camposb1.push('nombre B1')}
    if(apellidopb1 == ''){camposb1.push('apellidoP B1')}
    if(apellidopm1 == ''){camposb1.push('apellidoM B1')}
    if(naciolidadb1 == ''){camposb1.push('Nacionalidad B1')}
    if(ocupacionb1 == ''){camposb1.push('Ocupacion B1')}
    if(parentescob1 == ''){camposb1.push('Parentesco B1')}
    if(civilb1 == ''){camposb1.push('edo. Civil B1')}
    if(rfcb1 == ''){camposb1.push('rfc B1')}
    if(residenciab1 == ''){camposb1.push('Residencia B1')}
    if(cargob1 == ''){camposb1.push('Cargo B1')}
    if(actividadb1 == ''){camposb1.push('Actividad B1')}

    if (sexob1 == "" || nombreb1 == "" || apellidopb1 == "" || apellidopm1 == ""|| naciolidadb1 == ""|| ocupacionb1 == ""|| parentescob1 == ""||civilb1 == "" || rfcb1 == "" || residenciab1 == "" || cargob1 == '' || actividadb1 == ''){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_b1 = '';
      for(var j=0; j<camposb1.length; j++){
        campos_b1 = campos_b1 + camposb1[j] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b1);
      return false;
    }
  }

  if (numro_adic >= 2 ){
    //con beneficiario 2

    var resultadolefechab2 = false;
    var fecha_lenb2 = $("input[name=txtQId261CId4]").val();

    // var total = fecha_lenb2.length;
    // if(total == 10){
      // var fecha_splitb2 = fecha_lenb2.split('/');
      // if (fecha_splitb2[0].length == 2 && fecha_splitb2[1].length == 2 && fecha_splitb2[2].length == 4){
      //   resultadolefechab2 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del beneficiario 2 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del beneficiario 2 incorecta");
    //   return false;
    // }


    //VALIDACION DE VACIOS BENEFICIARIO (2)
    var nombreb2 = $("input[name=txtQId261CId1]").val();
    var apellidopb2 = $("input[name=txtQId261CId2]").val();
    var apellidopm2 = $("input[name=txtQId261CId3]").val();
    var sexob2 = $("select[name=txtQId261CId9]").val();
    var naciolidadb2 = $("select[name=txtQId261CId6]").val();
    var ocupacionb2 = $("select[name=txtQId261CId7]").val();
    var parentescob2 = $("select[name=txtQId261CId8]").val();
    var civilb2 = $("select[name=txtQId261CId10]").val();
    var rfcb2 = $("input[name=txtQId261CId11]").val();
    var residenciab2 = $("select[name=txtQId261CId21]").val();
    var cargob2 = $("select[name=txtQId261CId22]").val();
    var actividadb2 = $("select[name=txtQId261CId23]").val();

    var camposb2 = new Array();

    if(sexob2 == ''){camposb2.push('Genero B2')}
    if(nombreb2 == ''){camposb2.push('nombre B2')}
    if(apellidopb2 == ''){camposb2.push('apellidoP B2')}
    if(apellidopm2 == ''){camposb2.push('apellidoM B2')}
    if(naciolidadb2 == ''){camposb2.push('Nacionalidad B2')}
    if(ocupacionb2 == ''){camposb2.push('Ocupacion B2')}
    if(parentescob2 == ''){camposb2.push('Parentesco B2')}
    if(civilb2 == ''){camposb2.push('edo. Civil B2')}
    if(rfcb2 == ''){camposb2.push('RFC B2')}
    if(residenciab2 == ''){camposb2.push('Residencia B2')}
    if(cargob2 == ''){camposb2.push('Cargo B2')}
    if(actividadb2 == ''){camposb2.push('Actividad B2')}

    if (sexob2 == "" || nombreb2 == "" || apellidopb2 == "" || apellidopm2 == ""|| naciolidadb2 == ""|| ocupacionb2 == ""|| parentescob2 == ""||civilb2 == "" || rfcb2 == "" || residenciab2 == "" || cargob2 == '' || actividadb2 == ''){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_b2 = '';
      for(var z=0; z<camposb2.length; z++){
        campos_b2 = campos_b2 + camposb2[z] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b2);
      return false;
    }
  }

  if (numro_adic >= 3){
    //con beneficiario 3

    var resultadolefechab3 = false;
    var fecha_lenb3 = $("input[name=txtQId262CId4]").val();

    // var total = fecha_lenb3.length;
    // if(total == 10){
      // var fecha_splitb3 = fecha_lenb3.split('/');
      // if (fecha_splitb3[0].length == 2 && fecha_splitb3[1].length == 2 && fecha_splitb3[2].length == 4){
      //   resultadolefechab3 =  true;
      //   //  alert("fecha "+resultadolefecha);
      // }else{
      //   alert("fecha formato del beneficiario 3 incorecta");
      //   return false;
      // }
    // }else{
    //   alert("fecha formato del beneficiario 3 incorecta");
    //   return false;
    // }

    //VALIDACION DE VACIOS BENEFICIARIO (2)
    var nombreb3 = $("input[name=txtQId262CId1]").val();
    var apellidopb3 = $("input[name=txtQId262CId2]").val();
    var apellidopm3 = $("input[name=txtQId262CId3]").val();
    var sexob3 = $("select[name=txtQId262CId9]").val();
    var naciolidadb3 = $("select[name=txtQId262CId6]").val();
    var ocupacionb3 = $("select[name=txtQId262CId7]").val();
    var parentescob3 = $("select[name=txtQId262CId8]").val();
    var civilb3 = $("select[name=txtQId262CId10]").val();
    var rfcb3 = $("input[name=txtQId262CId11]").val();
    var residenciab3 = $("select[name=txtQId262CId21]").val();
    var cargob3 = $("select[name=txtQId262CId22]").val();
    var actividadb3 = $("select[name=txtQId262CId23]").val();

    var camposb3 = new Array();

    if(sexob3 == ''){camposb3.push('Genero B3')}
    if(nombreb3 == ''){camposb3.push('nombre B3')}
    if(apellidopb3== ''){camposb3.push('apellidoP B3')}
    if(apellidopm3 == ''){camposb3.push('apellidoM B3')}
    if(naciolidadb3 == ''){camposb3.push('Nacionalidad B3')}
    if(ocupacionb3 == ''){camposb3.push('Ocupacion B3')}
    if(parentescob3 == ''){camposb3.push('Parentesco B3')}
    if(civilb3 == ''){camposb3.push('edo. Civil B3')}
    if(rfcb3 == ''){camposb3.push('RFC B3')}
    if(residenciab3 == ''){camposb3.push('Residencia B3')}
    if(cargob3 == ''){camposb3.push('Cargo B3')}
    if(actividadb3 == ''){camposb3.push('Actividad B3')}

    if (sexob3 == "" || nombreb3 == "" || apellidopb3 == "" || apellidopm3 == ""|| naciolidadb3 == ""|| ocupacionb3 == ""|| parentescob3 == ""||civilb3 == "" || rfcb3 == "" || residenciab3 == "" || cargob3 == '' || actividadb3 == ''){
      //alert("debe llenar todos los campos que son obligatorios: "+campos);
      var campos_b3 = '';
      for(var zz=0; zz<camposb3.length; zz++){
        campos_b3 = campos_b3 + camposb3[zz] + '\r\n';
      }
      alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_b3);
      return false;
    }
  }

//ADICIONALES
var adicionala1 = $("input[name=txtQId210CId1]").val();
var nombre_a1 = $("input[name=txtQId26CId1]").val();


//Fecha nacimiento valida
var nombre_a1 = $("input[name=fechanacimiento_bene1]").val();

if(nombre == ''){
  campos.push(' Fecha beneficiario 1')

}

//si existe adicional
//DATOS ADICIONAL
var porcetaje_a1 = $("select[name=txtQId26CId5]").val(); //porcentaje a1
var porcetaje_a2 = $("select[name=txtQId261CId5]").val(); // porcentaje a2
var porcetaje_a3 = $("select[name=txtQId262CId5]").val(); // porcentaje a2

if (numro_adic == 1 && porcetaje_a1 != 100){

  alert("El porcentaje debe sumar 100");
  return false;
}else if (numro_adic == 2 && (parseInt(porcetaje_a1)+parseInt(porcetaje_a2) != 100)){
  alert("La suma del porcentaje de los beneficiarios 1 y 2 deben ser 100");
  return false;

}else if (numro_adic == 3 && (parseInt(porcetaje_a1)+parseInt(porcetaje_a2)+parseInt(porcetaje_a3)) != 100){
  alert("La suma del porcentaje de los beneficiarios 1, 2 y 3 deben ser 100");
  return false;

}


// $("input[name=txtQId21CId13]").get(0).type = 'email';
var resultadolefecha = false;
var fecha_len = $("input[name=txtQId21CId8]").val();
var fecha_split = fecha_len.split('/');
if (fecha_split[0].length == 2 && fecha_split[1].length == 2 && fecha_split[2].length == 4){
  resultadolefecha =  true;
  //  alert("fecha "+resultadolefecha);
} else{
  alert("fecha format");
  return false;
}

checameElRFC(numro_adic);

//alert('lkdangflksdngoskid');
//VALIDAR VACIOS DATOS DE TITULAR -------------------------------------------------------------
var nombre = $("input[name=txtQId21CId1]").val();//NOMBRE txtQId21CId1
var ap = $("input[name=txtQId21CId3]").val();//Apellido paterno
var am = $("input[name=txtQId21CId4]").val();//Apellido paterno
var rfc = $("input[name=txtQId21CId7]").val();//RFC
var f_nac = $("input[name=txtQId21CId8]").val();//Fecha nacimiento
var r_mex = $("select[name=txtQId21CId9]").val();//reside en mexico
var est_civil = $("select[name=txtQId21CId10]").val();//estado civil verify
//var est = $("select[name=txtQId21CId11]").val();//estado origen  verify
var pais_ori = $("select[name=txtQId21CId12]").val();//lugar nacimiento  verify
var email_ver = $("input[name=txtQId21CId13]").val(); //email
var nacionalidad = $("select[name=txtQId21CId14]").val(); //nacionalidad
var sexo = $("select[name=txtQId21CId15]").val(); //sexo
var titular = $("select[name=txtQId21CId16]").val(); //titular
//var ingreso = $("input[name=txtQId21CId18]").val(); //ingreso
var residencia = $("select[name=txtQId21CId19]").val(); //residencia
var ocupacion = $("select[name=txtQId21CId17]").val(); //ocupacion
var actividad = $("select[name=txtQId21CId20]").val(); //actividad
var cargo = $("select[name=txtQId21CId22]").val(); //cargo


//DATOS DE DOMICILIO
//En formulario 2 no llevan datos de domicilio
// var dom_vac = $("input[name=txtQId22CId1]").val();
// var dom_ext = $("input[name=txtQId22CId2]").val();
// var cp = $("input[name=txtQId22CId4]").val();
// var munici_ti = $("input[name=txtQId22CId6]").val();
// var estado_dom  = $("select[name=txtQId22CId7]").val();



//ACTIVIDAD LABORAL

// var activ_lab = $("select[name=txtQId23CId1]").val();
// var ocup_lab = $("select[name=txtQId23CId2]").val();
// var desc_lab = $("input[name=txtQId23CId3]").val();

//DATOS BANCARIOS

var tdd_tdc_ban = $("select[name=txtQId24CId1]").val();
var nombre_td_ban = $("input[name=txtQId24CId2]").val();
var dig_ban = $("input[name=txtQId24CId3]").val();

//MENSAJERIA
var llego_sms = $("select[name=txtQId27CId1]").val();
var nip_sms = $("select[name=txtQId27CId2]").val();
//DATOS DE PRODCTO
var tipo_plan = $("select[name=txtQId28CId2]").val();
var suma_aseg = $("select[name=txtQId28CId8]").val();
var precio_ind = $("input[name=txtQId28CId9]").val();
//var cargo_aseg = $("input[name=txtQId28CId10]").val();

//AUTENTICACION
var corr_aut = $("select[name=txtQId29CId1]").val();
var tipo_iden = $("select[name=txtQId29CId2]").val();

//BENEFICIARIO


//var lada = $("input[name=txtQId21CId7]").val();
//var cel = $("input[name=txtQId21CId8]").val();
var col = $("select[name=txtQId21CId15]").val();
var otra_col = $("input[name=txtQId21CId18]").val();
//var cd = $("select[name=txtQId21CId16]").val();

var banco_ref1 = $("input[name=txtQId22CId1]").val();
var dig_ref1 = $("input[name=txtQId22CId2]").val();
// var anti_ref1 = $("input[name=txtQId22CId3]").val();
var usr_correo = $("input[name=txtQId21CId10]").val();
var dominio = $("select[name=txtQId21CId9] option:selected").text();
var correo = usr_correo+dominio;
var campos = new Array();


//-----------------------------------------------------------------------------------------------------------

//var campos = '';


//if(fecha_lenb == ''){campos.push(' Beneficiario fecha1')}
//TITULAR
if(nombre == ''){campos.push(' Nombre')}
if(ap == '' || ap == ' '){campos.push(' Apellido Paterno')}
if(am == '' || am == ' '){campos.push(' Apellido Materno')}
if(f_nac == ''){campos.push(' Fecha De Nacimiento')}
if(r_mex == ''){campos.push(' Reside en mexico')}
if(est_civil == ''){campos.push(' Edo Civil')}
//if(est == ''){campos.push(' Estado')}
if(pais_ori == ''){campos.push(' pais origen')}
if(email_ver == ''){campos.push(' Email')}
if(nacionalidad == ''){campos.push(' Nacionalidad')}
if(sexo == ''){campos.push(' Sexo ')}
// if(titular == ''){campos.push(' ')}
//if(ingreso == ''){campos.push(' Ingreso Mensual')}
if(residencia == ''){campos.push(' Lugar de Residencia')}
if(ocupacion == ''){campos.push(' Ocupacion Actividad Asegurado ')}
if(actividad == ''){campos.push(' Actividad de Empresa ')}
if(corr_aut == ''){campos.push(' Fue correcta la autenticacion ')}
if(tipo_iden == ''){campos.push(' Tipo de identificacion ')}
if(cargo == ''){campos.push(' Cargo ')}

//DOMICILIO
// if(dom_vac == ''){campos.push(' Calle')}
// if(dom_ext == ''){campos.push(' Numero Ext')}
// if(cp == ''){campos.push(' CÃ³digo Postal')}
// if(munici_ti == ''){campos.push(' Municipio del titular')}
// if(estado_dom == ''){campos.push(' Estado del titular')}
//ACTIVIDAD LABORAL
// if(activ_lab == ''){campos.push(' Actividad laboral')}
// if(ocup_lab == ''){campos.push(' Ocupacion')}
// if(desc_lab == ''){campos.push(' Descripcion de la Ocupacion')}
//DATOS BANCARIOS
if(tdd_tdc_ban == ''){campos.push(' Tarjeta de credito debito')}
if(nombre_td_ban == ''){campos.push(' Nombre adicional')}
//if(dig_ban == ''){campos.push(' Ultimos 4 digitos')}
//MENSAJERIA
if(llego_sms == ''){campos.push(' Llego SMS')}
if(nip_sms == ''){campos.push(' Es correcto el NIP')}
//DATOS DE PRODCTO
if(tipo_plan == ''){campos.push('Tipo Plan')}
if(suma_aseg == ''){campos.push('Suma Asegurada')}
if(precio_ind == ''){campos.push('Precio indicado al cliente')}
//if(cargo_aseg == ''){campos.push('Cargo asegurado 1')}




//fecha beneficiario

if(numro_adic == ''){campos.push(' numeros de beneficiario ')}




if(rfc == ''){campos.push(' RFC')}
//if(lada == ''){campos.push(' Lada')}
//if(cel == ''){campos.push(' Celular')}

//

//if(rfc == ''){campos.push(' num adicional')}

//if(banco_ref1 == ''){campos.push(' Banco de Referencia Bancaria 1')}
//if(dig_ref1 == ''){campos.push(' Digitos de TDC Referencia Bancaria 1')}
//if(anti_ref1 == ''){campos.push(' Antiguedad TDC 1 (YYMM)')}
//if(cd == ''){campos.push(' Ciudad o Municipio')}

//---------------------------------------------------------------------------------------------------------------------------------------------
/*if(nombre == ''){campos = campos + 'Nombre\r\n'}
// if(ap == ''){campos = campos + 'Apellido Paterno\r\n'}*/
//
if (/*Titular*/nombre == "" || (ap == "" || ap == " " ) || (am == "" || am == " ") || f_nac == "" || r_mex == "" || est_civil == "" || pais_ori == "" || email_ver == "" || nacionalidad == "" || sexo == "" || residencia == "" || ocupacion == "" || actividad == "" || cargo == "" ||
/*Datos bancarios*/ tdd_tdc_ban == "" || nombre_td_ban == "" || rfc == "" ||
/*Mensajeria*/ llego_sms =="" || nip_sms == "" ||
/*Datos producto*/ suma_aseg == "" || precio_ind == "" || tipo_plan == ""
/*beneficiarios numro_adic == "" || fecha_lenb == "" */){
  //alert("debe llenar todos los campos que son obligatorios: "+campos);
  var campos_ = '';
  for(var i=0; i<campos.length; i++){
   campos_ = campos_ + campos[i] + '\r\n';
  }
  alert("Debe llenar todos los campos que son obligatorios: \r\n\r\n"+campos_);
  return false;
}

//----------------------------------------------------------------------------------------------------------VALIDACION DE 4 NUMEROS


if (dig_ban.length != 4){
  alert("longitud de los digitos tarjeta incorrecta ");
  return false ;
}


/* if(!isDate2(f_nac, "DDMMAAAA")) {
alert("[ERROR!] Fecha de Nacimiento Incorrecta");
return false;
}*/
/*
if(lada.length+cel.length < 9 || lada.length+cel.length > 10){
alert("[ERROR!] Lada Celular + TelÃ©fono Celular debe ser de 9 o 10 dÃ­gitos");
return false;
}

if (usr_correo.length > 0 || dominio.length > 0) {
if (dominio == 'Otro') {
if(!validarEmail(usr_correo)){
alert("[ERROR!] Correo electronico invalido");
return false;
}
}else{
if(!validarEmail(correo)){
alert("[ERROR!] Correo electronico invalido");
return false;
}
}
}
*/
/*
if (otra_col.length > 0 && col.length > 0) {
alert("[ERROR!] Si seleccionas una colonia, el campo de otra colonia debe estar vacio");
return false;
}
if (otra_col == "" && col == "") {
alert("[ERROR!] debe llenar todos los campos que son obligatorios: colonia");
return false;
}
if (dig_ref1.length != 4) {
alert("[ERROR!] Los Digitos de TDC Referencia Bancaria 1 deben ser 4");
return false;
}
if (!isDate2(anti_ref1, "MMYY")) {
alert("[ERROR!] Antiguedad TDC 1 en formato YYMM");
return false;
}*/

  if($('.errorValidacion').length > 0){
        alert('Por favor revisa el formulario, ya que hay campos con datos invalidos.');
        return false;
  }

  //Candados 12630
  var validaCandados = validaCandadoAsegurados();

  if(validaCandados === false){
    return validaCandados;
  }

//if (v_conteo_chec == v_conteo) {
//alert('La solicitud que estas procesando es: ' + customer_id + '\n Base de Registro: '+$('#nombre_base').val()+'\n Marca la extension ' + extension);
  alert('La solicitud que estas procesando es: ' + customer_id);

//  return false;
 // //
 document.SurveyResponse.submit();//cris

/*} else {
alert("Te falta completar tu check list");
return false;
}*/

};

function verifica_RFC(arrayCampos, parar, tipo=null){
  var len = arrayCampos.length;

  if(tipo!=null){ // titular
    var ini = 1;
  } else{
    var ini = 0;
  }

  var arrayDatos = [];
  var dato = '';
  var contador = 0;

  for(var i=ini; i<len; i++){
    if($('#'+arrayCampos[i].id).length > 0){
      if ($('#'+arrayCampos[i].id).val() != ""){
        contador += 1;

        if(i<2 && tipo==null){
          dato += $('#'+arrayCampos[i].id).val() + ' ';
          arrayDatos.push(dato.replace(/^\s+|\s+$/gm,''));
        } else{
          arrayDatos.push($('#'+arrayCampos[i].id).val());
        }
        //nombre = eval("document.getElementById('nombrepila').value");

      }
    }
  }

    //console.log(ini, tipo, contador, arrayCampos);
    if(contador>3){
        let len_array = arrayDatos.length - 1;

            //document.getElementById('rfc').innerHTML = "";
        $('#'+arrayCampos[len_array].id).html('');

        if(len_array == 3 || len_array == 4){
            request = "action=5&nombre=" + arrayDatos[0] + "&paterno=" + arrayDatos[1] + "&materno=" + arrayDatos[2] + "&fecha_nac=" + arrayDatos[3] + "&num_reconocedor=";
        } else if(len_array == 5){
            request = "action=5&nombre=" + arrayDatos[1] + "&paterno=" + arrayDatos[2] + "&materno=" + arrayDatos[3] + "&fecha_nac=" + arrayDatos[4] + "&num_reconocedor=";
        }

        send_post_page_rfc(request, arrayCampos[5].id, "modules.php?mod=agentes&op=process_data&act=MjM=", "");
    }





  // var nombre, paterno, materno, fecha_nac, contador = 0;

  // for(var i=0; i<parar; i++){
  //     var arrayDatos = [];
  //     var dato = '';

  //     for(var j=0; j<(arrayCampos[i].length - 1); j++){
  //         console.log($('#'+arrayCampos[i][j]), $('#'+arrayCampos[i][j]).length);
  //         if($('#'+arrayCampos[i][j]).length > 0){
  //             if ($('#'+arrayCampos[i][j]).val() != ""){
  //                 contador += 1;

  //                 // if(i==0 && j<2){
  //                 //     dato += $('#'+arrayCampos[i][j]).val() + ' ';
  //                 //     arrayDatos.push(dato.replace(/^\s+|\s+$/gm,''));
  //                 // } else{
  //                     arrayDatos.push($('#'+arrayCampos[i][j]).val());
  //                 // }
  //                 //nombre = eval("document.getElementById('nombrepila').value");

  //             }
  //         }
  //     }

  //     if(contador==3){
  //         //document.getElementById('rfc').innerHTML = "";
  //         $('#'+arrayCampos[i][5]).html('');
  //         request = "action=5&nombre=" + arrayDatos[0] + "&paterno=" + arrayDatos[1] + "&materno=" + arrayDatos[2] + "&fecha_nac=" + arrayDatos[3] + "&num_reconocedor=";
  //         send_post_page_rfc(request, arrayCampos[i][5], "modules.php?mod=agentes&op=process_data&act=MjM=", "");
  //     }

  // }



  // var nombre, paterno, materno, fecha_nac, contador = 0;
  // if (eval("document.getElementById('nombrepila')") != null) {
  //     if (eval("document.getElementById('nombrepila').value") != "") {
  //         contador += 1;
  //         nombre = eval("document.getElementById('nombrepila').value");
  //     }
  // }

  // //Segundo nombre
  // if (eval("document.getElementById('nombreseg')") != null) {
  //     if (eval("document.getElementById('nombreseg').value") != "") {
  //         nombre += ' ' + eval("document.getElementById('nombreseg').value");
  //     }
  // }

  // //Apellido paterno
  // if (eval("document.getElementById('appaterno')") != null) {
  //     if (eval("document.getElementById('appaterno').value") != "") {
  //         contador += 1;
  //         paterno = eval("document.getElementById('appaterno').value");
  //     }
  // }

  // //Apellido materno
  // if (eval("document.getElementById('apmaterno')") != null) {
  //     if (eval("document.getElementById('apmaterno').value") != "") {
  //         materno = eval("document.getElementById('apmaterno').value");
  //     }
  // }

  // //Fecha de nacimiento
  // if (eval("document.getElementById('fechanacimiento')") != null) {
  //     if (eval("document.getElementById('fechanacimiento').value") != "") {
  //         contador += 1;
  //         fecha_nac = eval("document.getElementById('fechanacimiento').value");

  //         if (!isDate2(fecha_nac, "DDMMAAAA")) {
  //             alert("[ERROR!] Fecha Incorrecta");
  //             contador -= 1;
  //         }
  //         fecha_nac = fecha_nac.substring(0, 2)+'/'+fecha_nac.substring(2, 4)+'/'+fecha_nac.substring(4, 8);
  //     }
  // }

  // if (contador == 3) {
  //     document.getElementById('rfc').innerHTML = "";
  //     request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac + "&num_reconocedor=";
  //     send_post_page_rfc(request, "rfc", "modules.php?mod=agentes&op=process_data&act=MjM=", "");
  // }
}

var dato_valido = 0;



/*function validarDato(valor, id){
    console.log('desde el jscode PRINCIPAL');
    //e.preventDefault();
    $('#errorDato').remove();

    var dato_ = 1;
    if(id == 'email'){
        var regExp_dato = /(([^<>()[\]\.\s@\"]+(\.[^<>()[\]\.\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.\s@\"]+\.)+[^<>()[\]\.\s@\"]{2,})/i;
        var dato = 'Correo Invalido.';

    } else if(id == 'fecha_cobro'){
        var regExp_dato = /^(?:(?:(?:0?[1-9]|1\d|2[0-8])[/-](?:0?[1-9]|1[0-2])|(?:29|30)[/-](?:0?[13-9]|1[0-2])|31[/](?:0?[13578]|1[02]))[/-](?:0{2,3}[1-9]|0{1,2}[1-9]\d|0?[1-9]\d{2}|[1-9]\d{3})|29[/-]0?2[/-](?:\d{1,2}(?:0[48]|[2468][048]|[13579][26])|(?:0?[48]|[13579][26]|[2468][048])00))$/;
        var dato = 'Fecha Invalida.';

        if(valor.split('/')[2].length != 4){
            dato_ = 0;
        }
    }

    if (!regExp_dato.test(valor) || dato_==0){
       $('#'+id).parent().append('<span style="color:red;" id="errorDato">'+dato+'</span>');
       return false;
    } else{
       dato_valido = 1;
       return true;
    }
}*/




// function oculta_beneficiarios(){
//   // agregar clase a los bloques de beneficiario
//   $('.bloque_beneficiarios2').hide();
// }


$( document ).ready(function() {//display ASEGURADOS----------------------------------------------------------------

  // var array_leyendas2 = [21]; revisar bine que pedo

  //    for(var i=0; i<array_leyendas2.length; i++){
  //        $('#cuestionario tbody tr:eq('+array_leyendas2[i]+')').attr('class', 'bloque_beneficiarios2');
  //       // $('#cuestionario tbody tr:eq('+array_cuerpo[i]+')').attr('class', 'bloque_beneficiarios2');
  //    }
  //const array_leyendas = [28,42,56];
  //var array_leyendas2 = [21];
  //var array_cuerpo = [29,43,57];
  //
  // $('#cuestionario tbody tr:eq(23)').attr('class','oculta_adicionales1');//Asegurado 1 titulo
  // $('#cuestionario tbody tr:eq(24)').attr('class','oculta_adicionales1');//Asegurado 1 cuerpo
  // $('#cuestionario tbody tr:eq(38)').attr('class','oculta_adicionales2');//Asegurado 2 titulo
  // $('#cuestionario tbody tr:eq(39)').attr('class','oculta_adicionales2');//Asegurado 2 cuerpo
  // $('#cuestionario tbody tr:eq(53)').attr('class','oculta_adicionales3');//Asegurado 3 titulo
  // $('#cuestionario tbody tr:eq(54)').attr('class','oculta_adicionales3');//Asegurado 3 cuerpo
  // $('#cuestionario tbody tr:eq(77)').attr('class','oculta_adicionales4');//Beneficiario 1 titulo
  // $('#cuestionario tbody tr:eq(78)').attr('class','oculta_adicionales4');//Beneficiario 1 cuerpo
  // $('#cuestionario tbody tr:eq(93)').attr('class','oculta_adicionales5');//Beneficiario 2 titulo
  // $('#cuestionario tbody tr:eq(94)').attr('class','oculta_adicionales5');//Beneficiario 2 cuerpo
  // $('#cuestionario tbody tr:eq(109)').attr('class','oculta_adicionales6');//Beneficiario 3 titulo
  // $('#cuestionario tbody tr:eq(110)').attr('class','oculta_adicionales6');//Beneficiario 3 cuerpo

  // $('.oculta_adicionales1').hide();
  // $('.oculta_adicionales2').hide();
  // $('.oculta_adicionales3').hide();
  // $('.oculta_adicionales4').hide();
  // $('.oculta_adicionales5').hide();
  // $('.oculta_adicionales6').hide();

  //$('#num_asegurados').attr("onchange", "mostar_aseg()");
  //$('#num_beneficiarios').attr("onchange", "mostar_bene()");
});

function mostar_aseg(){
  var num_aseg = $('#num_asegurados').val();

  if(num_aseg == 1){
    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').hide();
    $('.oculta_adicionales3').hide();
    $('.oculta_adicionales4').hide();
    $('.oculta_adicionales5').hide();

  } else if(num_aseg == 2){
    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').show();
    $('.oculta_adicionales3').hide();
    $('.oculta_adicionales4').hide();
    $('.oculta_adicionales5').hide();

  } else if(num_aseg == 3){
    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').show();
    $('.oculta_adicionales3').show();
    $('.oculta_adicionales4').hide();
    $('.oculta_adicionales5').hide();

  } else if(num_aseg == 4){
    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').show();
    $('.oculta_adicionales3').show();
    $('.oculta_adicionales4').show();
    $('.oculta_adicionales5').hide();

  } else if(num_aseg == 5){
    $('.oculta_adicionales1').show();
    $('.oculta_adicionales2').show();
    $('.oculta_adicionales3').show();
    $('.oculta_adicionales4').show();
    $('.oculta_adicionales5').show();

  } else{
    $('.oculta_adicionales1').hide();
    $('.oculta_adicionales2').hide();
    $('.oculta_adicionales3').hide();
    $('.oculta_adicionales4').hide();
    $('.oculta_adicionales5').hide();
  }

  limpiarDatosAdicionalesBeneficiarios(num_aseg, 'A');
}

function mostar_bene(){
  var num_bene = $('#num_beneficiarios').val();

  if(num_bene == 1){
    $('.oculta_adicionales4').show();
    $('.oculta_adicionales5').hide();
    $('.oculta_adicionales6').hide();

  } else if(num_bene == 2){
    $('.oculta_adicionales4').show();
    $('.oculta_adicionales5').show();
    $('.oculta_adicionales6').hide();

  } else if(num_bene == 3){
    $('.oculta_adicionales4').show();
    $('.oculta_adicionales5').show();
    $('.oculta_adicionales6').show();

  } else{
    $('.oculta_adicionales4').hide();
    $('.oculta_adicionales5').hide();
    $('.oculta_adicionales6').hide();
  }

  limpiarDatosAdicionalesBeneficiarios(num_bene, 'B');
}

function limpiarDatosAdicionalesBeneficiarios(numero, tipo){
  if(numero == 1){
    var inicio = 2;
  } else if(numero == 2){
    var inicio = 3;
  }

  if(tipo == 'A'){  // 1, 2, 3
    var fin = 3;
  } else if(tipo == 'B'){ // 4, 5, 6
    inicio = (inicio + 3);
    var fin = 6;
  }

  for(var l=inicio; l<=fin; l++){
    $('.oculta_adicionales'+inicio+':last .errorValidacion').remove();

    $('.oculta_adicionales'+inicio+':last').find('table tbody td input').each(function(index){
      var id = $(this).attr('id');
      $('#'+id).val('').removeClass('conError');
    });
    $('.oculta_adicionales'+inicio+':last').find('table tbody td select').each(function(index){
      var id = $(this).attr('id');
      if($(this).hasClass('select2-hidden-accessible')){
        $('#'+id).val(null).trigger('change');
      } else{
        $('#'+id).val('');
      }
    });
  }
}

function validaCandadoAsegurados(){
  //#12630 - Candados Asegurados HSBC

  var cantidadAseg = parseInt($('#num_asegurados').val());

  var arregloAseg = ['A1','A2','A3','A4','A5'];

  for (var i = 0; i < cantidadAseg; i++) {
    // Fecha de nacimiento
    var fechaElegida = $('#fechanacimiento' + arregloAseg[i]).val().split('/');
    var fechaNacimiento = new Date(fechaElegida[2], fechaElegida[1] - 1, fechaElegida[0]);

    // Fecha actual
    var fechaActual = new Date();

    // Calcular la diferencia de aÃ±os
    var diferenciaAnios = fechaActual.getFullYear() - fechaNacimiento.getFullYear();

    var diferenciaEnMilisegundos = fechaActual.getTime() - fechaNacimiento.getTime();
    var diferenciaEnDias = diferenciaEnMilisegundos / (1000 * 60 * 60 * 24);

    // Comprobar si aÃºn no ha pasado el cumpleaÃ±os este aÃ±o
    if (fechaActual.getMonth() < fechaNacimiento.getMonth() || (fechaActual.getMonth() === fechaNacimiento.getMonth() && fechaActual.getDate() < fechaNacimiento.getDate())) {
      diferenciaAnios--;
    }

    // console.log("La fecha nacimiento es: " + fechaNacimiento + " aÃ±os");
    // console.log("La fecha actual es: " + fechaActual + " aÃ±os");
    // console.log("La edad es: " + diferenciaAnios + " aÃ±os");
    // console.log(diferenciaEnDias);

    var valorParentesco = $('#parentesco'+arregloAseg[i]).val();
    if(valorParentesco === "1"){
      if($('#est_civil' + arregloAseg[i]).val() != "2"){
        alert("Debes seleccionar CASADO en Edo Civil en el Asegurado "+arregloAseg[i]);
        return false;
      }
      if(diferenciaAnios<18 || diferenciaAnios > 60){
        alert("El asegurado " + arregloAseg[i] + " debe tener entre 18 y 60 aÃ±os de edad");
        return false;
      }
    }else if(valorParentesco === "3"){
      if($('#est_civil'+arregloAseg[i]).val() != "1"){
        alert("Debes seleccionar SOLTERO, en Edo Civil en el Asegurado "+arregloAseg[i]);
        return false;
      }
      if($("#ocupacion"+arregloAseg[i]).val() === "3"){
        alert("Debes seleccionar Dependiente Economico o Estudiante, en OcupaciÃ³n Familiar en el Asegurado "+arregloAseg[i]);
        return false;
      }
      if($("#actividad"+arregloAseg[i]).val() != "21"){
        alert("Debes seleccionar 'ESTUDIANTE O MENOR DE EDAD SIN OCUPACION', en Actividad Asegurado "+arregloAseg[i]);
        return false;
      }
      if(diferenciaEnDias < 90 || diferenciaAnios > 25){
        alert("El asegurado " + arregloAseg[i] + " debe tener entre 3 meses y 25 aÃ±os de edad");
        return false;
      }
    }
  }

}

//Candados del requerimiento #12630
$(function(){
  $('#contratante').val("1");
  $("#est_civilA1 option[value='5']").prop('disabled', true);
  $("#est_civilA2 option[value='5']").prop('disabled', true);
  $("#est_civilA3 option[value='5']").prop('disabled', true);
  $("#est_civilA4 option[value='5']").prop('disabled', true);
  $("#est_civilA5 option[value='5']").prop('disabled', true);
  $("#est_civil option[value='5']").prop('disabled', true);

  $('#parentescoA1').on("change",function(){
    var valorParentescoA1 = $('#parentescoA1').val();
    if(valorParentescoA1 === "1"){
      $('#est_civilA1').val("2");
      $("#ocupacionA1").val("").trigger("change");
      $("#actividadA1").val("").trigger("change");
    }else if(valorParentescoA1 === "3"){
      $('#est_civilA1').val("1");
      $("#ocupacionA1").val("1").trigger("change");
      $("#actividadA1").val("21").trigger("change");
    }else{
      $('#est_civilA1').val("");
      $("#ocupacionA1").val("").trigger("change");
      $("#actividadA1").val("").trigger("change");
    }
  })

  $('#parentescoA2').on("change",function(){
    var valorParentescoA2 = $('#parentescoA2').val();
    if(valorParentescoA2 === "1"){
      $('#est_civilA2').val("2");
      $("#ocupacionA2").val("").trigger("change");
      $("#actividadA2").val("").trigger("change");
    }else if(valorParentescoA2 === "3"){
      $('#est_civilA2').val("1");
      $("#ocupacionA2").val("1").trigger("change");
      $("#actividadA2").val("21").trigger("change");
    }else{
      $('#est_civilA2').val("");
      $("#ocupacionA2").val("").trigger("change");
      $("#actividadA2").val("").trigger("change");
    }
  })

  $('#parentescoA3').on("change",function(){
    var valorParentescoA3 = $('#parentescoA3').val();
    if(valorParentescoA3 === "1"){
      $('#est_civilA3').val("2");
      $("#ocupacionA3").val("").trigger("change");
      $("#actividadA3").val("").trigger("change");
    }else if(valorParentescoA3 === "3"){
      $('#est_civilA3').val("1");
      $("#ocupacionA3").val("1").trigger("change");
      $("#actividadA3").val("21").trigger("change");
    }else{
      $('#est_civilA3').val("");
      $("#ocupacionA3").val("").trigger("change");
      $("#actividadA3").val("").trigger("change");
    }
  })

  $('#parentescoA4').on("change",function(){
    var valorParentescoA4 = $('#parentescoA4').val();
    if(valorParentescoA4 === "1"){
      $('#est_civilA4').val("2");
      $("#ocupacionA4").val("").trigger("change");
      $("#actividadA4").val("").trigger("change");
    }else if(valorParentescoA4 === "3"){
      $('#est_civilA4').val("1");
      $("#ocupacionA4").val("1").trigger("change");
      $("#actividadA4").val("21").trigger("change");
    }else{
      $('#est_civilA4').val("");
      $("#ocupacionA4").val("").trigger("change");
      $("#actividadA4").val("").trigger("change");
    }
  })

  $('#parentescoA5').on("change",function(){
    var valorParentescoA5 = $('#parentescoA5').val();
    if(valorParentescoA5 === "1"){
      $('#est_civilA5').val("2");
      $("#ocupacionA5").val("").trigger("change");
      $("#actividadA5").val("").trigger("change");
    }else if(valorParentescoA5 === "3"){
      $('#est_civilA5').val("1");
      $("#ocupacionA5").val("1").trigger("change");
      $("#actividadA5").val("21").trigger("change");
    }else{
      $('#est_civilA5').val("");
      $("#ocupacionA5").val("").trigger("change");
      $("#actividadA5").val("").trigger("change");
    }
  })




});

//Oculta los campos si el origen no es L4
// $(function(){
//   // var origenBase = $('#iniciativasL4').val();
//   // if(origenBase !== 'L4'){
//       //Oculta el titulo de iniciativas
//       $('.bloquel4').hide();
// //  }
// });
// //--------------------------------------------------------------------------------------------------------------------



// console.log('Ivan Placas----',precioHC9.target)
//   precioHC9.addEventListener("input", () => { console.log('ssssss');  } );
