<?php
class Conexion{
	static public function conectar(){
		//desarrollo

						$link = new PDO("mysql:host=172.20.1.149;dbname=VentasAuto",
			            "lresendiz",
			            "R3s3nd1z*");

        //produccion
		// $link = new PDO("mysql:host=67.20.76.217;dbname=tocimpul_VentasAuto",
		// "tocimpul_ventasdigital",
		// "fg82k6fyyU");
		$link->exec("set names utf8");
		return $link;
	}
}