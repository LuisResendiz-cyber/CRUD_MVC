<?php
header('Content-Type: text/html; charset=UTF-8');
echo '<link rel="stylesheet" type="text/css" href="includes/style.css">';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "includes/openConnection.php"; 
include "includes/functions.php"; 
include "includes/read_data.php"; 
require 'includes/autoload.php';

$databaseConnection = new DatabaseConnection('development', false);  
$db = $databaseConnection->getConnection();

$logger = new Logger($db);
$logger->log('INICIA CARGA AUTOMATICA',0,1);


use phpseclib\Net\SFTP;

$ftp_user_name = 'amex'; 
$ftp_user_pass = 'Tyn$t&/(q98Flv7#';
$ftp_server = '189.211.174.149';
$port='9144';

$sftp = new SFTP($ftp_server,$port);
	if (!$sftp->login($ftp_user_name, $ftp_user_pass)) {
		exit('Login Failed');
	}else{
		echo 'Conectado con exito <br>'; 		
    
    $sftp->chdir('amex');
    $archivos = array_diff( $sftp->nlist(), array('.', '..'));
    foreach ($archivos as $key => $value) {
      if ($sftp->is_file($value)) {
        // echo '<hr>Es archivo '.$value;                
        $sftp->get($value, 'leads_Temporal/'.$value); 		 
        // $sftp->rename($value, 'PROCESADOS/'.$value);	
        die();
      }            
    }
    start($db); 
    
    die();

    	
				
		foreach ($archivos as $key => $value) {
			if ($sftp->is_file($value)) {
				echo '<hr>Es archivo '.$value;					
				$df=str_replace( array('.txt','completo'), array(''),$value);
				$arc= explode('_',$df);
					if ($arc[0] !='.' && $arc[0] !='..' ) {
						echo ' <br> valido'.$arc[0];
						$chose= substr($arc[4],-1);
						var_dump($chose);
						$chose= substr($arc[4],-1);
						if ($chose==1) {
							echo '    Archivo invalido';
							$sftp->get($value, 'folderTemporal/'.$value); 				   
						 }else {
						   echo '     Archivo valido';		 				  
							$sftp->get($value, 'folderTemporal/'.$value); 
		 
							$sftp->rename($value, 'PROCESADOS/'.$value);		 
						 }
					}else {
						echo ' <br> No valido'.$arc[0];
					}

			}else {
				echo '<hr> No es archivo '.$value;
			}			
		}
		echo '<hr>';

		readtxt($db);

}