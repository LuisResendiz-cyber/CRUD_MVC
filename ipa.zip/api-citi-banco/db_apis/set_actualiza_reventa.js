const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".XSP_ACTUALIZAREVENTA(:id_solicitud, :id_respuesta); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.id_solicitud || !context.id_respuesta){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    binds.id_solicitud     = context.id_solicitud;
    binds.id_respuesta     = context.id_respuesta;

    const result = await database.simpleExecute(query, binds);
    // console.log(result); 
    return result;

  }
}
 
module.exports.find = find;