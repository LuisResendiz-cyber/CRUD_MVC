const getPri_rh = require('../db_apis/get_prima_values_rh.js');

async function post(req, res, next) {
  try {        
    // console.log("autenticar",req.body)

    const rows = await getPri_rh.find(req.body);

    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;