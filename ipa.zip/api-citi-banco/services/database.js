const oracledb = require('oracledb');
const dbConfig = require('../config/database.js');
const logger = require('../utils/logger.js');

async function initialize() {
  const pool = await oracledb.createPool(dbConfig.hrPool);
}
module.exports.initialize = initialize;

async function close() {
  await oracledb.getPool().close();
}

module.exports.close = close;

function simpleExecute(statement, binds = [], opts = {}) {
  // console.log(statement, binds);
  return new Promise(async (resolve, reject) => {
    let conn;
    try {
      conn = await oracledb.getConnection();
      let resultReturn = [];


      const response = await conn.execute(statement, binds,{ resultSet: true,outFormat: oracledb.OUT_FORMAT_OBJECT, autoCommit:true })
      .then((r) =>{
        if(typeof(r.outBinds) == 'undefined'){
          return {outBinds:{msg:"success"}};
        }else{
          return r;
        }
      })
      .catch((e) =>{
        logger.error(`${e} [ Query ]:${statement}`);
        return {error :true, e};
      });

      if (!response.error){
          resolve(response.outBinds);
      } else {
        reject(response);
      }
    } catch (err) {
      logger.error(`${err} [ Query ]:${statement}`);
      reject(err);
    } finally {
      if (conn) { // conn assignment worked, need to close
        try {
          await conn.close();
        } catch (err) {
          console.log(err);
        }
      }
    }
  });
}

function simpleExecuteRC(statement, binds = [], opts = {}) {
  return new Promise(async (resolve, reject) => {
    let conn;
    try {
      conn = await oracledb.getConnection();
      let resultReturn = [];
      const response = await conn.execute(statement, binds,{ resultSet:true, outFormat:oracledb.OUT_FORMAT_OBJECT, autoCommit:true })
      .catch((e) =>{
        logger.error(`${e} [ Query ]:${statement}`);
        return {error :true, msg:{e}};
      });

      //console.log('--------------------------', response.error, '--------------------------');
      if (!response.error){
          const resultSet_ = response.outBinds.rc;
          //console.log('---', response.outBinds.rc, '---');
          let row;
          let fila = 0;
          while ((row = await resultSet_.getRow())) {
            let temp_ = {};
            for(c in row){
              // console.log(c,row[c]);
              temp_[c] = row[c];
            }
            resultReturn.push(temp_);
            fila++;
          }

          if(fila == 0){
            resolve({resultSet:false});
          }else{
            resolve(resultReturn);
          }
      }else{
          resolve(response);

      }

    } catch (err) {
      logger.error(`${err} [ Query ]:${statement}`);
      reject(err);
    } finally {
      if (conn) { // conn assignment worked, need to close
        try {
          await conn.close();
        } catch (err) {
          console.log(err);
        }
      }
    }
  });
}

module.exports.simpleExecute = simpleExecute;
module.exports.simpleExecuteRC = simpleExecuteRC;
