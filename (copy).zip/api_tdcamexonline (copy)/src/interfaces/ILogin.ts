export interface ILogin {
  ID_USER:string,
  NAME: string
  STATUS: string
  PASS: string
  ROLE?: string;
}