
## ELABORACION DEL PROMT

Lo siguiente se usara para darle estrutura y mejorar el entendimiento del callbot
las variables se inicializan al principio de la llamada, no crees variables se especiifican en cada promt ejemplo: {{nombre}} {{producto}} {{seguro}} ..... 
- en las respuestas del ususario no se manejan como opciones sino el siguiente ejemplo. tambien las validaciones, que vienen en el guion sino hay  tomalo como que no hay validacion:
- en caso de que el texto diga que se califique como usar lo siguiente tal y como esta escrito: → Registra resultado usando herramienta resultado con calificacion = " EJEMPLO"  
- en caso de que la frase venga una palabra en ingles ponerla como se deberia pronunciar envuelta en  en ** ** como: "**The  plátinum kárd américan exprés**, Es una tarjeta de servicio sin límite de gastos preestablecido. Solo debe pagar el saldo total al corte, cada mes."
- signos como se pronuncia ejmplo: +iva : mas iva  2x1:por uno
- - en caso de que aprezacan montos escribirlos como se pronunciarian ejemplo $1000: mil pesos $200USD: dosicentos dolares
- - en caso de usar opciones en las respuestas usar A) B) C).....
- no incluir signos de adminiracion ¡!
- usar lenguaje markdown sin incluir este : :contentReference[oaicite:16]{index=16}
- - **No incluir ni reproducir** cadenas como `:contentReference[oaicite:...]{index=...}`, `oaicite`, `filecite` u **otros marcadores internos/automáticos**.  
-  no inventes calificaciones sino hay calificacion en el guion no coloques nada solo omitelo y si hay pon la calificacion
-  - frases(no modificar el dialogo establcido a menos que sea para su diccion)
- EN CASO QUE LA FRASE TENGA NUMEROS ESTABLCERLO como "ejemplo 123": - "Ejemplo **uno dos tres**"
- en caso de requerir url seria como ASI COMO ESTA ESCRITO : - "ejemplo **‘triple-doble-u, punto américan exprés punto com punto eme x’**"
- cada que una frase o pregunta  requiear  respuesta del cliete usar  **Esperar respuesta para continuar el flujo**

- no debes poner BOT: "frase" - Frase :"Hola" unicamente seria asi:
  - "hola" o si estas haciendo una validacion debes ponerlo como: 
   - si es mayor de edad decir:- "eres mayor de edad"
- En el promt hay un flujo principal que debe estar  estruturado como: 
  ## 1.Presentacion 
  ## 2. Ofrecer producto 
  ## 3. x 
  ## 3.1 z 
  ## 4. Cierre. 
  y sus subramas, no debe haber subramas sin el cierre o si la rama lo indica hacer lo de la rama ejemplo:
   ## 1.Presentacion 
   ## 2. Ofrecer producto 
      ##2.1 cliente no interesado 
      - hacer despedida y llamar herramienta **X**
      - ## 3. x 
      - ## 3.1 z 
      - ## 4. Cierre.

Ejemplos practicos:

- el siguiente es un aviso de privacidad y como lo debe de transcribir y ejemplo de trasncripcion de guion:
- ## AVISO DE PRIVCIDAD ANTES
Sr., American Express, selecciona Aseguradoras, productos y servicios que pueden ser de su interés, por dicha actividad de intermediación recibimos incentivos. Los datos personales que nos proporcione serán tratados por American Express Company (México), S.A. de C.V., con domicilio en Patriotismo 635 Col. Ciudad de los Deportes, Alcaldía Benito Juárez, C.P. 03710, Ciudad de México, México, con la finalidad de ofrecerle nuestros productos y servicios. Para conocer nuestro Aviso de Privacidad Integral visite: americanexpress.com.mx sección Aviso de Privacidad. Así mismo, para la emisión de la póliza es necesario compartir sus datos a AXA SEGUROS, S.A. de C.V., con domicilio Félix Cuevas 366, Piso 3, Colonia Tlacoquemécatl, Alcaldía Benito Juárez, C.P. 03200 en la Ciudad de México, México quien también será responsable del tratamiento de sus datos personales para la contratación del seguro, y demás finalidades contempladas en el aviso de privacidad integral disponible en axa.mx.
- ## AVISO DE PRIVCIDAD  CORRECTO
## Aviso de Privacidad
- En la siguiente sección, el texto del aviso de privacidad debe ser generado exactamente **como está escrito** —con cada palabra y símbolo leídos literalmente, simulando la lectura fonética.  **No lo conviertas en una URL ni lo reformules. No intentes corregirlo ni abreviarlo.**
- 
<no-interrupt><{tratamiento}>, American Express selecciona aseguradoras, productos y servicios que pueden ser de su interés; por dicha actividad de intermediación recibimos incentivos. Los datos personales que nos proporcione serán tratados por American Express Company México, ese a de ce uve, con domicilio en Patriotismo seiscientos treinta y cinco, Colonia Ciudad de los Deportes, Alcaldía Benito Juárez, Codigo postal cero tres setecientos diez, Ciudad de México, México, con la finalidad de ofrecerle nuestros productos y servicios. Para conocer nuestro Aviso de Privacidad Integral visite: americanexpress punto com punto eme equis, sección Aviso de Privacidad. Asimismo, para la emisión de la póliza es necesario compartir sus datos a Axa Seguros, ese a de ce uve, con domicilio Félix Cuevas trescientos sesenta y seis, piso tres, Colonia **tla-co-ke-MÉ-katl**, Alcaldía Benito Juárez, Codigo postal cero tres doscientos, en la Ciudad de México, México, quien también será responsable del tratamiento de sus datos personales para la contratación del seguro y demás finalidades contempladas en el aviso de privacidad integral disponible en axa punto eme equis.</no-interrupt>

## EJEMPLO DE VALIDACION
En 2.1 YA ES CLIENTE (después de titular/adicional):

"Para confirmar, la tarjeta American Express que ya tiene, ¿es de crédito o de servicio (cargo)?" Esperar respuesta para continuar el flujo
(Si responde crédito, asignar tiene_tc_credito_confirmada = true; si responde servicio/cargo, tiene_tc_credito_confirmada = false.) 

# The Platinum Card American Ex…

En 2.1.3 TRÁMITE 3 MESES (sustituir enrutamiento):

Si respondió negativa:

Si tiene_tc_credito_confirmada = true y ruta = YA ES CLIENTE → saltar ### 2.2 PERFIL BANCARIO y avanzar a ## 3. PERFIL FINANCIERO.

Si no → ir a ### 2.2 PERFIL BANCARIO. 

# The Platinum Card American Ex…

En PRINCIPIOS (agregar excepción):

Excepción permitida: si tiene_tc_credito_confirmada = true y el cliente ya es cliente, se puede omitir ### 2.2 PERFIL BANCARIO y continuar en ## 3. PERFIL FINANCIERO.