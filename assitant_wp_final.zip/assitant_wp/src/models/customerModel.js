const db = require("../config/configmysql");

const CustomersModel = {
  async getCustomers() {
    const [result] = await db.query(
      "SELECT id, nombre, lada, numero FROM WHATSAAP_ASSISTANT.DATA_NUMEROS WHERE activo = 1"
    );
    return result;
  },

  // Ahora acepta un array de IDs para desactivar
  async setTryBatch(ids) {
    if (!ids || ids.length === 0) return;
    const placeholders = ids.map(() => "?").join(",");
    await db.query(
      `UPDATE WHATSAAP_ASSISTANT.DATA_NUMEROS SET ACTIVO = 0 WHERE ID IN (${placeholders})`,
      ids
    );
  },

  // Batch Logs Insert
  async saveLogsBatch(logs) {
    if (logs.length === 0) return;

    const values = logs.map(() => "(?, ?, ?)").join(",");
    const flat = logs.flatMap((l) => [l.id_envio, l.status_id, l.errorApi]);

    console.log(values);

    await db.query(
      `INSERT INTO WHATSAAP_ASSISTANT.LOG_ENVIO 
       (id_envio, status_id, errorApi) VALUES ${values}`,
      flat
    );
  },
};

module.exports = CustomersModel;
