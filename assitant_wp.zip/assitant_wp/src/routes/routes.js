const express = require('express');
const router = express.Router();
const CustomerController = require("../controllers/customerController");

router.get('/', (req, res) => {
    res.json({1: "ok"});
});
router.get('/sendMessages',CustomerController.sendMessages);
router.get("/webhook", CustomerController.verifyWebhook);
router.post("/webhook", CustomerController.receiveWebhook);

module.exports = router;
