<?php
ini_set('display_errors', true);
require_once("includes/includes.inc.php");

load_session();

$action = isset($_REQUEST['act']) ? $_REQUEST['act'] : '';


/*  echo $action;
die();  */  

$pwd = isset($_POST['v_pwd']) ? $_POST['v_pwd'] : '';
$usr_id = isset($_POST['usr_id']) ? $_POST['usr_id'] : '';
$resultado = null;

switch ($action) {
  case 1:
  

  try {
    $query = "BEGIN dbo.spu_cambiapassword_cat(:u_user, :v_password, :v_resultado); END;";
    $stmt = $db->PrepareSP($query);

    $db->InParameter($stmt, $usr_id, 'u_user');
    $db->InParameter($stmt, $pwd, 'v_password');
    $db->OutParameter($stmt, $resultado, 'v_resultado');
    $db->Execute($stmt);
    
    }catch (Exception $e) {
        echo $e->getMessage();
        echo $e->getTraceAsString();
    }

$mns = "";
$mns .= $resultado;

switch ($resultado) {

    case 0:
            $mns .= " <a style='font-size: 14px; color: red; text-transform: uppercase;'>error</a>";
        break;
    case 1:
            $mns .= "<a style='font-size: 14px; color: red; text-transform: uppercase;'>La longitud del password debe ser de 8 caracteres</a>";
        break;
    case 2:
            $mns .= "<a style='font-size: 14px; color: red; text-transform: uppercase;'>EL password debe tener almenos un caracter especial $ % &</a>";
        break;
    case 3:
            $mns .= "<a style='font-size: 14px; color: red; text-transform: uppercase;'>Ha revazado el n&uacute;mero de cambios en menos de 24 hrs.</a>";
        break;
    case 4:
            $mns .= "<a style='font-size: 14px; color: red; text-transform: uppercase;'>El password debe ser diferente a sus 12 passwords anteriores</a>";
        break;
    case 5:
    
            set_session_varname("v_pwd",$pwd);
            set_session_varname("usr_id",$usr_id);
            $mns .= "<a style='font-size: 14px; color: green; text-transform: uppercase;'>Se ha cambiado el password Exitosamente.</a>";

        break;
    case 6:
            $mns .= "<a style='font-size: 14px; color: red; text-transform: uppercase;'>EL password no tiene almenos un numero</a>";
        break;
    default:
      echo "No hay caso2";           
  }

  echo $mns;
 


break;

   case 2:

        $usr_id = $_SESSION['usr_id'];
        $pwd = $_SESSION['v_pwd'];

        unset_session_varname("s_usr_id2");            
        unset_session_varname("s_usr_nombre");
        unset_session_varname("s_usr_nomina");            
        unset_session_varname("s_usr_id");
        unset_session_varname('s_pwd');
        unset_session_varname("time");
        unset_session_varname("logged");

        $stmt = $db->PrepareSP("BEGIN XSP_VERIFYPASSWORD_CAD_B(:uid_, :pwd, :resultado, :userid); END;");//,:ext
        $db->InParameter($stmt, $usr_id, 'uid_');
        $db->InParameter($stmt, $pwd, 'pwd');
        $db->OutParameter($stmt, $resultado, 'resultado');
        $db->OutParameter($stmt, $userid, 'userid');
        $db->Execute($stmt);

        $s_usr_sesion = 0;

        if ($resultado == 5 || $resultado == 6 || $resultado == 0) {
            $s_usr_sesion = 1;
        }                    
  
        $datos_agente = get_agente_info_ini($userid, $db);           
        
        if ($s_usr_sesion == 1 && is_object($datos_agente)) {
            
      /*var_dump($datos_agente);
        die();  */

            set_session_varname("s_usr_id", $userid);
            set_session_varname("s_usr_nombre", $datos_agente->_array[0]['NAME']);
            set_session_varname("s_usr_nomina", $datos_agente->_array[0]['EMAIL']);

            if (get_profile_user($datos_agente->_array[0]['EMAIL'], $db) >= 1) {
                set_session_varname("s_usr_nivel", 'S');
            } else {
                $profile_ = get_user_base($userid, $db);
                if (substr($profile_, 0, 1) == '1') {
                    set_session_varname("s_usr_nivel", 'A'); //AGENTE
                } else if (substr($profile_, 1, 1) == '1') {
                    set_session_varname("s_usr_nivel", 'ACB'); //AGENTE CON BASE
                } else if (substr($profile_, 2, 1) == '1') {
                    set_session_varname("s_usr_nivel", 'ASB'); //AGENTE SIN BASE
                }
            }

            set_session_varname("time", time());
            set_session_varname("logged", true);
            set_session_varname("s_usr_maquina", $_SERVER['REMOTE_ADDR']);
            set_traking(get_session_varname("s_usr_id"), 'INICIO SESION', get_session_varname("s_usr_maquina"), 0, '', $db);
        
    }
        header("location: " . "index3.php");
        die();
    break;
  default:
    echo "No hay caso1";
} 
?>
