<?php

class AuthService extends ApiClient
{
    //USERS
    public function login(string $email, string $password)
    {
        return $this->request('POST', 'Users/Login', [
            'email_user' => $email,
            'passwordHash'   => $password
        ]);
    }

    public function getAccesModules(int $idUser = 0)
    {

        return $this->request('GET', 'Users/getModules?id_user='. $idUser);
    }

    //ROLES
    public function getRoles(int $method = 0)
    {
        return $this->request('GET', 'Users/getRoles');
    }

    public function getRol(int $intIdrol = 0)
    {
        return $this->request('GET', 'Users/getRol?id=' . $intIdrol);
    }

    public function createRol(string $name = NULL, string $description = NULL, int $status = 1)
    {
        return $this->request('POST', 'Users/createRol', [
            'name' => $name, 
            'description' => $description,
            'status' =>  $status
        ]);
    }

    public function deleteRol(int $intIdrol = 0)
    {
        return $this->request('DELETE', 'Users/deleteRol/' . $intIdrol);
    }

    public function updateRol(int $intIdrol = 0, string $strRol = NULL, string $strDescipcion= NULL, string $intStatus= NULL)
    {
        return $this->request('PUT', 'Users/updateRol/' . $intIdrol,
        [
            'name' => $strRol,
            'description'   => $strDescipcion,
            'status'   => $intStatus
        ]);
    }

    // Obtener todos los usuarios
    public function getAllUsers()
    {
        return $this->request('GET', 'users');
    }


    // Crear nuevo usuario
    public function createUser(array $data)
    {

        return $this->request('POST', 'users/createUser', $data);
    }

    // Obtener usuario por ID
    public function getUserById(int $id)
    {
        return $this->request('GET', 'users/getUser/' . $id);
    }

    // Actualizar usuario existente
    public function updateUser(int $id, array $data)
    {
        return $this->request('PUT', 'users/updateUser/' . $id, $data);
    }

    // Eliminar/desactivar usuario
    public function deleteUser(int $id)
    {

        //echo dep($id);
        return $this->request('DELETE', 'users/deleteUser/' . $id);
    }    
    
    //BOTS
    //getAllBots
    public function getAllBots()
    {
        return $this->request('GET', 'bots/getAllBots');
    }

}
