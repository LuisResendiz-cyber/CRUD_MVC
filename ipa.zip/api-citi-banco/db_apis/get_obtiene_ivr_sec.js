const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".sps_registrar_ivr(:solicitud, :producto, :resultado); END;";

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(!context.id_solicitud || !context.id_producto){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.solicitud = context.id_solicitud;
    binds.producto = context.id_producto;
    binds.resultado = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
    // binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecute(query, binds);
    // console.log(result);
    return result;
  }


}

module.exports.find = find;

