<?php
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize_nolayout("agente,supervisor", "");
$action = desencripta($_REQUEST['act']);
//$isPredictivo = get_EsPredictivo($db);
$isPredictivo = get_session_varname("s_usr_marcacion");
$empresa = get_session_varname("s_usr_centro");
$usr_id = get_session_varname("s_usr_id");
$name = get_session_varname('s_usr_nombre');
$nomina = get_session_varname('s_usr_nomina');

$header = "index2.php";

if (isset($action) && $action == 1) { ##### OBTIENE UN REGISTRO Y RECUPERA EL NUMERO DE SOLICITUD ##

    unset_session_varname("calificados");

    if ($isPredictivo == 2) {

        if (get_session_varname("agenda") == 1) {
            unset_session_varname("agenda");
            unset_session_varname("id_solicitud");
        }

        $data = get_registros_agendado($usr_id, $db);
        $agendas = array();


    if (isset($data->_array) && is_array($data->_array)) {

        for ($s = 0; $s < count($data->_array); $s++) {
            $agenda = array();
            $agenda['REGISTRO'] = $data->_array[$s]['REGISTRO'];
            $agenda['PERSONA'] = $data->_array[$s]['PERSONA'];
            $agenda['HORA'] = $data->_array[$s]['HORA'];
            $agenda['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $agenda['DATE_'] = $data->_array[$s]['DATE_'];
            $agenda['FECHA'] = $data->_array[$s]['FECHA'];
            $agenda['COMENTARIO'] = $data->_array[$s]['COMENTARIO'];
            $agendas[$s] = $agenda;
        }

        set_session_varname("agenda", $agendas);

        $datos_cliente = get_session_varname("agenda");

        $agendados = strlen($datos_cliente[0]['U_PERSONA']);

        if ($agendados != 0)

        $header = "modules.php?mod=agentes&op=error&e=7&customerid=" . $datos_cliente[0]['U_PERSONA'] . "&hora=" . $datos_cliente[0]['HORA'] . "&fecha=" . $datos_cliente[0]['FECHA'] . "&u_registro=" . $datos_cliente[0]['REGISTRO'] . "&com=" . urlencode($datos_cliente[0]['COMENTARIO']);

    } else if (strlen(get_session_varname("id_solicitud")) == 0) {

        $rnd = rand(1, 100) + 1;

        $data = get_registro_solicitud($db, $usr_id, 1, 1, 0, 10, $rnd, 0, 0);

        if (is_object($data) && !empty($data->_array)) {

            $id_solicitud = $data->fields['U_PERSONA'];
            $id_registro = $data->fields['U_REGISTRO_CAMP'];
            $telefonos_disponibles = count($data->_array);
            $customers = array();

            for ($s = 0; $s < count($data->_array); $s++) {
                $customer = array();
                $customer['U_PERSONA'] = isset($data->_array[$s]['U_PERSONA']) ? $data->_array[$s]['U_PERSONA'] : '';
                $customer['NOMBRE'] = isset($data->_array[$s]['NOMBRE']) ? $data->_array[$s]['NOMBRE'] : '';
                $customer['APATERNO'] = isset($data->_array[$s]['APATERNO']) ? $data->_array[$s]['APATERNO'] : '';
                $customer['AMATERNO'] = isset($data->_array[$s]['AMATERNO']) ? $data->_array[$s]['AMATERNO'] : '';
                $customer['RFC'] = isset($data->_array[$s]['RFC']) ? $data->_array[$s]['RFC'] : '';
                $customer['FNACIMIENTO'] = isset($data->_array[$s]['FNACIMIENTO']) ? $data->_array[$s]['FNACIMIENTO'] : '';
                $customer['U_TELEFONO'] = isset($data->_array[$s]['U_TELEFONO']) ? $data->_array[$s]['U_TELEFONO'] : '';
                $customer['PAIS'] = isset($data->_array[$s]['PAIS']) ? $data->_array[$s]['PAIS'] : '';
                $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
                $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
                $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'];
                $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
                $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
                $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
                $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
                $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
                $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
                $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
                $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
                $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'];
                $customer['REFERIDO_POR'] = $data->_array[$s]['REFERIDO_POR'];
                $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
                $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
                $customer['REFERENCIA'] = isset($data->_array[$s]['REFERENCIA']) ? $data->_array[$s]['REFERENCIA']:'';
                $customer['TERMINACION_TDC'] = isset($data->_array[$s]['TERMINACION_TDC']) ? $data->_array[$s]['TERMINACION_TDC'] : '';
                $customer['PRODUCTO'] = isset($data->_array[$s]['PRODUCTO']) ? $data->_array[$s]['PRODUCTO'] : '';
                $customer['CLAVE_PROD_A_VENDER'] = isset($data->_array[$s]['CLAVE_PROD_A_VENDER']) ? $data->_array[$s]['CLAVE_PROD_A_VENDER'] : '';
                $customer['TIPO_CUENTA'] = isset($data->_array[$s]['TIPO_CUENTA']) ? $data->_array[$s]['TIPO_CUENTA'] : '';
                $customer['NO_POLIZAS'] = isset($data->_array[$s]['NO_POLIZAS']) ? $data->_array[$s]['NO_POLIZAS'] : '';
                $customer['TIPO_ASEGURADO'] = isset($data->_array[$s]['TIPO_ASEGURADO']) ? $data->_array[$s]['TIPO_ASEGURADO'] : '';
                $customer['EDAD'] = isset($data->_array[$s]['EDAD']) ? $data->_array[$s]['EDAD'] : '';
                $customer['SC'] = $data->_array[$s]['SC'];
                $customer['EMAIL'] = isset($data->_array[$s]['EMAIL']) ? $data->_array[$s]['EMAIL'] : '';
                $customer['CELULAR'] = $data->_array[$s]['CELULAR'] ?? '';
                $customer['CANAL'] = $data->_array[$s]['CANAL'] ?? '';
                $customer['MEDIO'] = $data->_array[$s]['MEDIO'] ?? '';
                $customer['SCORE_BURO'] = $data->_array[$s]['SCORE_BURO'] ?? '';
                $customer['BLACKLIST'] = $data->_array[$s]['BLACKLIST'] ?? '';
                $customer['CPID'] = $data->_array[$s]['CPID'] ?? '';
                $customer['COMENTARIOS_7'] = $data->_array[$s]['COMENTARIOS_7'] ?? '';
                $customer['DESC_PRODUCTO'] = $data->_array[$s]['DESC_PRODUCTO'] ?? '';
                $customer['BDT'] = $data->_array[$s]['BDT'] ?? '';
                $customer['U_ZONA'] = $data->_array[$s]['U_ZONA'] ?? '';
                $customer['CAMPANA'] = $data->_array[$s]['CAMPANA'] ?? '';
                $customer['OFERTA'] = $data->_array[$s]['OFERTA'] ?? '';
                $customer['CAMP'] = $data->_array[$s]['CAMP'] ?? '';
                $customer['PCN'] = $data->_array[$s]['PCN'] ?? '';
                $customer['ESTATUSDOC'] = $data->_array[$s]['ESTATUSDOC'] ?? '';
                $customer['ESTATUSONBOARDING'] = $data->_array[$s]['ESTATUSONBOARDING'] ?? '';
                $customer['AMEXURL'] = $data->_array[$s]['AMEXURL'] ?? '';
                $customer['DIGITOS'] = $data->_array[$s]['DIGITOS'] ?? '';
                $customer['TARJETA_SOLICITADA'] = $data->_array[$s]['TARJETA_SOLICITADA'] ?? '';
                $customer['TNKPAGE_ATERRIZAJE'] = $data->_array[$s]['TNKPAGE_ATERRIZAJE'] ?? '';////aqui
                $customer['NACIONALIDAD'] = $data->_array[$s]['NACIONALIDAD'] ?? '';
                $customer['SEGURO'] = isset($data->_array[$s]['SEGURO']) ? $data->_array[$s]['SEGURO'] : '';
                $customer['Z3033'] = $data->_array[$s]['ZONA'] ?? '';
                $customer['FCARGA'] = $data->_array[$s]['FCARGA'];
                $customer['ID_UNICO'] = $data->_array[$s]['ID_UNICO'];
                $customers[$s] = $customer;
            }


            set_session_varname("datos_persona", $customers);

            set_session_varname("id_solicitud", $id_solicitud);
            set_session_varname("id_registro", $id_registro);


           if (isset($id_solicitud) && $id_solicitud > 0) {

                set_traking($usr_id, 'OBTUVO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
                set_evento_registro($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
                set_session_varname("inicio",1);
                $header = "modules.php?mod=agentes&op=index";
            }

        }else{

            $header = "modules.php?mod=agentes&op=error&e=1&bnd=3"; //.$id_bnd; # ERROR CUANDO NO TIENE MAS REGISTROS LIBRES
        }

        } else {
            set_traking($usr_id, 'OBTUVO REGISTRO ELSE', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
            set_evento_registro($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO',$db);

            set_session_varname("inicio",1);

            $header = "modules.php?mod=agentes&op=index"; # AUN NO SE ABANDONA ESTE REGISTRO
        }

        unset_session_varname("CE");
        unset_session_varname("caltelefono0");
        unset_session_varname("caltelefono1");
        unset_session_varname("caltelefono2");
        unset_session_varname("caltelefono3");
        unset_session_varname("caltelefono4");
        unset_session_varname("caltelefono5");

    } else {

        $u_registro = 0;
        $u_registro = get_preavail($usr_id, $db);

        if($u_registro > 0){
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(61);
        }else{
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
        }
    }

    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
} elseif (isset($action) && $action == 2) { ##### VALIDA EL ACCESO A LA BUSQUEDA DE REGISTROS
    $header = "modules.php?mod=agentes&op=busqueda_cliente";
} elseif (isset($action) && $action == 3) { ##### MUESTRA EN PANTALLA EL REGISTRO SELECCIONADO DE LA BUSQUEDA

    
    if(isset($_SESSION['log_registro'])){
        switch (get_session_varname('log_registro')){
            case 1:
                update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'ENTRO A SOLCITUD', $db);
                break;
                case 2:
                    update_evento_registro2($usr_id,-1,'CONSULTA AGENDA', $db);
                    break;
                    case 3:
                        update_evento_registro2($usr_id,-1,'CONSULTA BUSQUEDA', $db);
            break;
            default :
            break;
        }
    }
    
    
    if (get_session_varname('id_solicitud') != null) {
        
        if (!isset($_REQUEST['tipo'])) {
            set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
            
            set_traking($usr_id, 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        } else {
            //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
            set_traking($usr_id, 'ABANDONO REGISTRO POR REFERIDO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        }
        //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
        if($isPredictivo == 1){
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }else{
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }
        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");
    }
    
    if($isPredictivo == 1){
        if(isset($_REQUEST['tipo']) && $_REQUEST['tipo'] == 2){
            $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
            //Limpia al agente de predictivo
            $handler_clear = curl_init($url_clear_pred);
            $clear_pred = curl_exec($handler_clear);
            curl_close($handler_clear);
            
            set_preavail($usr_id, "-1", $db);
            
            $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
            //Limpia al agente de predictivo
            $handler_logout = curl_init($url_logout_pred);
            $logout_pred = curl_exec($handler_logout);
            curl_close($handler_logout);
        }
    }
    
    $u_persona = isset($_REQUEST['u_persona']) ? $_REQUEST['u_persona'] : '';
    $u_registro = isset($_REQUEST['u_registro']) ? $_REQUEST['u_registro'] : '';
    $trabajado = isset($_REQUEST['trabajado']) ? $_REQUEST['trabajado'] : '';
    $agendado = isset($_REQUEST['agendado']) ? $_REQUEST['agendado'] : '';
    $comentario = isset($_REQUEST['com']) ? $_REQUEST['com'] : '';
    $hora = isset($_REQUEST['hora']) ? $_REQUEST['hora'] : '';
    
    set_session_varname("trabajado", $trabajado);
    
    set_libera_agendado($u_registro, $usr_id, $db);
    unset_session_varname("agenda");

    $data = get_registro_especifico($u_registro, $usr_id, 'O', $db);


    if ($data && !$data->EOF) {
        $id_solicitud = $data->fields['U_PERSONA'];
        $id_registro = $u_registro;
    $telefonos_disponibles = count($data->fields);
    $customers = array();
    while (!$data->EOF) {
        $customer = array();
        $customer['U_PERSONA'] = $data->fields['U_PERSONA'];
        $customer['NOMBRE'] = $data->fields['NOMBRE'];
        $customer['APATERNO'] = $data->fields['APATERNO'];
        $customer['AMATERNO'] = $data->fields['AMATERNO'];
        $customer['RFC'] = $data->fields['RFC'];
        $customer['FNACIMIENTO'] = $data->fields['FNACIMIENTO'];
        $customer['U_TELEFONO'] = $data->fields['U_TELEFONO'];
        $customer['PAIS'] = $data->fields['PAIS'];
        $customer['CLAVELADA'] = $data->fields['CLAVELADA'];
        $customer['TELEFONO'] = $data->fields['TELEFONO'];
        $customer['LOCALIZACION'] = isset($data->fields['LOCALIZACION']) ? $data->fields['LOCALIZACION'] : '';
        $customer['ULTIMOESTATUSTELEFONO'] = $data->fields['ULTIMOESTATUSTELEFONO'];
        $customer['PRIORIDAD'] = $data->fields['PRIORIDAD'];
        $customer['INTENTOS'] = $data->fields['INTENTOS'];
        $customer['TIEMPOACUMULADO'] = $data->fields['TIEMPOACUMULADO'];
        $customer['U_RESULTADOLLAMADA'] = $data->fields['U_RESULTADOLLAMADA'];
        $customer['U_ESTATUSLLAMADA'] = $data->fields['U_ESTATUSLLAMADA'];
        $customer['FECHAULTIMOESTATUS'] = $data->fields['FECHAULTIMOESTATUS'];
        $customer['NOMBREDERESPETO'] = $data->fields['NOMBREDERESPETO'];
        $customer['U_REGISTRO_CAMP'] = isset($data->fields['U_REGISTRO_CAMP']) ? $data->fields['U_REGISTRO_CAMP'] : '';
        $customer['REFERIDO_POR'] = $data->fields['REFERIDO_POR'];
        $customer['TIPO_ZONA'] = $data->fields['TIPO_ZONA'];
        $customer['MUNICIPIO_COBERTURA'] = $data->fields['MUNICIPIO_COBERTURA'];
        $customer['REFERENCIA'] = isset($data->fields['REFERENCIA']) ? $data->fields['REFERENCIA'] : '';
        $customer['TERMINACION_TDC'] = isset($data->fields['TERMINACION_TDC']) ? $data->fields['TERMINACION_TDC'] : '';
        $customer['PRODUCTO'] = isset($data->fields['PRODUCTO']) ? $data->fields['PRODUCTO'] : '';
        $customer['CLAVE_PROD_A_VENDER'] = isset($data->fields['CLAVE_PROD_A_VENDER']) ? $data->fields['CLAVE_PROD_A_VENDER'] : '';
        $customer['TIPO_CUENTA'] = isset($data->fields['TIPO_CUENTA']) ? $data->fields['TIPO_CUENTA'] : '';
        $customer['NO_POLIZAS'] = isset($data->fields['NO_POLIZAS']) ? $data->fields['NO_POLIZAS'] : '';
        $customer['TIPO_ASEGURADO'] = isset($data->fields['TIPO_ASEGURADO']) ? $data->fields['TIPO_ASEGURADO'] : '';
        $customer['AGENDADO'] = isset($data->fields['AGENDADO']) ? $data->fields['AGENDADO'] : '';
        $customer['HORA'] = isset($data->fields['HORA']) ? $data->fields['HORA'] : '';
        $customer['COMENTARIO'] = isset($data->fields['COMENTARIO']) ? $data->fields['COMENTARIO'] : '';
        $customer['EDAD'] = $data->fields['EDAD'];
        $customer['SC'] = $data->fields['SC'];
        $customer['EMAIL'] = isset($data->fields['EMAIL']) ? $data->fields['EMAIL'] : '';
        $customer['CELULAR'] = isset($data->fields['CELULAR']) ? $data->fields['CELULAR'] : '';
        $customer['CANAL'] = $data->fields['CANAL'];
        $customer['MEDIO'] = $data->fields['MEDIO'];
        $customer['SCORE_BURO'] = $data->fields['SCORE_BURO'];
        $customer['BLACKLIST'] = $data->fields['BLACKLIST'];
        $customer['CPID'] = $data->fields['CPID'];
        $customer['COMENTARIOS_7'] = $data->fields['COMENTARIOS_7'];
        $customer['DESC_PRODUCTO'] = $data->fields['DESC_PRODUCTO'];
        $customer['BDT'] = isset($data->fields['BDT']) ? $data->fields['BDT'] : '';
        $customer['U_ZONA'] = $data->fields['U_ZONA'];
        $customer['CAMPANA'] = $data->fields['CAMPANA'];
        $customer['OFERTA'] = $data->fields['OFERTA'];
        $customer['CAMP'] = $data->fields['CAMP'];
        $customer['PCN'] = $data->fields['PCN'];
        $customer['ESTATUSDOC'] = $data->fields['ESTATUSDOC'];
        $customer['ESTATUSONBOARDING'] = $data->fields['ESTATUSONBOARDING'];
        $customer['AMEXURL'] = $data->fields['AMEXURL'];
        $customer['DIGITOS'] = $data->fields['DIGITOS'];
        $customer['TARJETA_SOLICITADA'] = $data->fields['TARJETA_SOLICITADA'];
        $customer['TNKPAGE_ATERRIZAJE'] = $data->fields['TNKPAGE_ATERRIZAJE'];
        $customer['NACIONALIDAD'] = $data->fields['NACIONALIDAD'];
        $customer['SEGURO'] = isset($data->fields['SEGURO']) ? $data->fields['SEGURO'] : '';
        $customer['Z3033'] = isset($data->fields['Z3033']) ? $data->fields['Z3033'] : '';
        $customer['FCARGA'] = $data->fields['FCARGA'];
        $customer['ID_UNICO'] = $data->fields['ID_UNICO'];
        
        $customers[] = $customer;
        
        $data->MoveNext();
    }

    
    $data->MoveFirst();
    
    set_session_varname("datos_persona", $customers);
    
    if (isset($id_solicitud) && $id_solicitud > 0) {
        $tipo = $_REQUEST['tipo'] ?? '';
        
        set_session_varname("id_solicitud", $id_solicitud);
        set_session_varname("id_registro", $id_registro);
        
        set_session_varname("inicio",1);
        
        $header = "modules.php?mod=agentes&op=index&t_reg=".$tipo;
        set_evento_registro($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO',$db);
    } else {
        $data = get_mensaje_registro($id_registro, $db);

        for ($s = 0; $s < count($data->_array); $s++) {
            $mensaje = array();
            $mensaje['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $mensaje['ACTIVO_TZ'] = $data->_array[$s]['ACTIVO_TZ'];
            $mensaje['U_ZONA'] = $data->_array[$s]['U_ZONA'];
            $mensaje['ESTATUS'] = $data->_array[$s]['ESTATUS'];
            $mensaje['AGENDAS'] = $data->_array[$s]['AGENDAS'];
            $mensaje['TEXTO'] = $data->_array[$s]['TEXTO'];
        }
        $header = "modules.php?mod=agentes&op=error&e=1&bnd=4&customerid=" . $mensaje['U_PERSONA'] . "&activo_tz=" . $mensaje['ACTIVO_TZ'] . "&u_zona=" . $mensaje['U_ZONA'] . "&estatus=" . $mensaje['ESTATUS'] . "&agendas=" . $mensaje['AGENDAS'] . "&texto=" . $mensaje['TEXTO']; # ERROR GENERICO
    }
}
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    unset_session_varname("tipo_standby");
    unset_session_varname("tipo_standby2");
} elseif (isset($action) && $action == 4) { ##### LIBERA EL REGISTRO SELECCIONADO Y OBTIENE EL SIGUIENTE DISPONIBLE
    unset_session_varname("calificados");
    unset_session_varname("url_contacto");

    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_tipo_standby = get_session_varname('tipo_standby2');
    $contador = $_REQUEST['cont'];
    $contacto_efectivo = 0;

    set_session_varname('sb', $_REQUEST['sb']);
    set_session_varname('tkn', $_REQUEST['tkn']);

    
    if ($contador == 1) {
        $telefono = $_REQUEST['tel_1'];
        $cal_tel = $_REQUEST['tel_01'];
        $u_telefono = $datos_persona[0]['U_TELEFONO'];
        if ($_REQUEST['tel_01'] == 1010) {
            $contacto_efectivo += 1;
            set_session_varname("s_telefono", $datos_persona[0]['CLAVELADA'] . $datos_persona[0]['TELEFONO']);
            set_session_varname("s_tel_contacto", $datos_persona[0]['U_TELEFONO']);
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
        } else {
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
            set_estatus_registro($id_registro, $usr_id, $u_telefono, $cal_tel, 1, '', 1, 0, 'O', $db);
        }
    } else {

/*         for ($s = 1, $t = 0; $s <= $contador; $s++, $t++) {
            if ($_REQUEST['tel_0' . $s] == 1010) {
                $_REQUEST['tel_0' . $s] . " if";
                $contacto_efectivo += 1;
                set_session_varname('CE', $t);
                set_session_varname("s_telefono", $datos_persona[$t]['CLAVELADA'] . $datos_persona[$t]['TELEFONO']);
                set_session_varname("s_tel_contacto", $datos_persona[$t]['U_TELEFONO']);
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
            } else if ($_REQUEST['tel_0' . $s] > 0) {
                $cal_tel = $_REQUEST['tel_0' . $s];
                echo $_REQUEST['tel_0' . $s] . " else if";
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
                set_estatus_registro($id_registro, $usr_id, $datos_persona[$t]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);
            }
        } */

        for ($s = 1, $t = 0; $s <= $contador; $s++, $t++) {
            $tel_key = 'tel_0' . $s;
            
            if (isset($_REQUEST[$tel_key])) {
                if ($_REQUEST[$tel_key] == 1010) {
                    echo $_REQUEST[$tel_key] . " if"; // Asegúrate de que esta línea no esté presente si vas a modificar cabeceras
                    $contacto_efectivo += 1;
                    set_session_varname('CE', $t);
                    set_session_varname("s_telefono", $datos_persona[$t]['CLAVELADA'] . $datos_persona[$t]['TELEFONO']);
                    set_session_varname("s_tel_contacto", $datos_persona[$t]['U_TELEFONO']);
                    set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST[$tel_key], $s, $db);
                } else if ($_REQUEST[$tel_key] > 0) {
                    $cal_tel = $_REQUEST[$tel_key];
                    echo $_REQUEST[$tel_key] . " else if"; // Asegúrate de que esta línea no esté presente si vas a modificar cabeceras
                    set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST[$tel_key], $s, $db);
                    set_estatus_registro($id_registro, $usr_id, $datos_persona[$t]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);
                }
            }
        }

    }
    if ($contacto_efectivo >= 1) {
        set_session_varname("id_producto", $_REQUEST['producto_']);
        set_evento_registro($usr_id,get_session_varname("id_solicitud"),'ENTRO A SOLCITUD',$db);
        if($isPredictivo == 1){
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }else{
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }        
        $header = "modules.php?mod=agentes&op=cuestionario";        
    } else {
    
        set_traking($usr_id, 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);

        if($isPredictivo == 1){
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }else{
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }

        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");
        unset_session_varname("log_registro");
        unset_session_varname("tipo_standby");

        if ($isPredictivo == 1) {

            $u_registro = 0;
            $u_registro = get_preavail($usr_id, $db);

            if($s_tipo_standby > 0){
                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta($s_tipo_standby);
            } else {
                if($u_registro > 0){
                    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(61);
                }else{
                    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
                }

            }
        } else {
            
            if($s_tipo_standby > 0){
                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta($s_tipo_standby);
            } else {

                $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
            }
            //unset_session_varname("tipo_standby2");
        }
        unset_session_varname("tipo_standby2");
    }
} elseif (isset($action) && $action == 5) { ##### REENVIA A LA AGENDA
    $id_solicitud = get_session_varname('id_solicitud');
    $id_sol_req = (isset($_REQUEST['id']) && $_REQUEST['id'] != 0 ? $_REQUEST['id'] : $id_solicitud);

    if ($id_solicitud > 0) {
        if ($id_sol_req != $id_solicitud) {
            set_session_varname("agenda", 1);
            set_session_varname("id_solicitud", $id_sol_req);
        } else {
            //set_session_varname("id_solicitud",$id_solicitud);
        }
    } else {
        set_session_varname("agenda", 1);
        set_session_varname("id_solicitud", $id_sol_req);
    }

    $header = "modules.php?mod=agentes&op=agenda";
} elseif (isset($action) && $action == 6) { ##### AGENDA EL REGISTRO SELECCIONADO

    $datos_cliente = get_session_varname("datos_persona");
    $nombre = $datos_cliente[0]['NOMBRE'] . ' ' . $datos_cliente[0]['APATERNO'] . ' ' . $datos_cliente[0]['AMATERNO'];
    $id_registro = get_session_varname('id_registro');
    $fecha_agendado = $_REQUEST['fecha_agenda'];
    $comentarios = $_REQUEST['comentarios'];
    $hora = $_REQUEST['hora'];
    $id_telefono = get_session_varname('s_u_telefono');
    $array_fecha = explode("/", $fecha_agendado);
    $anio = $array_fecha[2];
    $mes = $array_fecha[1];
    $day = $array_fecha[0];

    $agenda_registro = set_agenda_registro($usr_id, $id_registro, $anio, $mes, $day, $hora, $nombre, $comentarios, 1, $db);
    set_estatus_registro_normal($id_registro, 406, 'AGENDADO', 1, $usr_id, 1, $id_telefono, 1, 0, '1', $db);

    set_traking($usr_id, 'AGENDO REGISTRO', get_session_varname("s_usr_maquina"), $id_registro, '', $db);

    update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'AGENDA REGISTRO', $db);
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    unset_session_varname("log_registro");
    if ($isPredictivo == 1) {
          $u_registro = 0;
          $u_registro = get_preavail($usr_id, $db);

          if($u_registro > 0){
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(61);
        }else{
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
        }
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
    //$header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
} elseif (isset($action) && $action == 7) { # CANCELA LA ACCION DE AGENDADO
    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $calificacion = $_REQUEST['si_contacto'];

    $rs = get_listElegible_face($calificacion,$db);

    if($rs->_array[0]['NUM'] > 0){
        $params = array('solicitud'=>$id_solicitud,"event" => 2);
        $defaults = array(
            CURLOPT_URL => 'http://172.20.1.95/api_fueralinea/main3.php',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true
        );

        $ch = curl_init();
        curl_setopt_array($ch, $defaults);
        $r = curl_exec($ch);
    }

    set_califica_telefono($datos_persona[get_session_varname('CE')]['U_TELEFONO'], $calificacion, 0, $db);
    set_estatus_registro($id_registro, $usr_id, $datos_persona[get_session_varname('CE')]['U_TELEFONO'], $calificacion, 1, '', 1, 0, 'O', $db);
    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'ENTRO A SOLCITUD', $db);
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");

    if ($isPredictivo == 1) {
        $u_registro = 0;
        $u_registro = get_preavail($usr_id, $db);

        if($u_registro > 0){
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(61);
        }else{
            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
        }
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
} elseif (isset($action) && $action == 8) { ##### ACCION PARA ABANDONAR UN REGISTRO
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');

    set_session_varname("solicitud_previa", $id_solicitud);

    set_libera_solicitud($id_registro, 1, 1, $db);
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'ABANDONO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);
    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("agenda");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
    if ($isPredictivo == 1) {
        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;

        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION
} elseif (isset($action) && $action == 9) { ##### CREA UN NUEVO REGISTRO
    $campana = 1;
    $nombre = quitarCaracteresEspeciales(strtoupper($_REQUEST['nombre']));
    $paterno = quitarCaracteresEspeciales(strtoupper($_REQUEST['paterno']));
    $materno = quitarCaracteresEspeciales(strtoupper($_REQUEST['materno']));
    $lada = $_REQUEST['lada'];
    $telefono = $_REQUEST['telefono'];
    $calificacion = $_REQUEST['calificacion'];

    if (empty($_REQUEST['tipo'])) {
        $tipo = 3; // Base blanca por default
        //$referente = 0;
        $referente = get_session_varname('solicitud_previa');
    } else {
        $tipo = $_REQUEST['tipo'];
        if ($tipo == 3){
            $referente = get_session_varname('solicitud_previa');
        }else{
            $referente = $_REQUEST['referente'];
        }
    }
    $result = set_registro_especifico($campana, $usr_id, $nombre, $paterno, $materno, "", "- -", 1, $lada, $telefono, "", $tipo, $db);
    $datos_registro = explode("-", $result);

    $u_persona = $datos_registro[0];
    $u_registro = $datos_registro[2];
    $mensaje_error = $datos_registro[6];

    if ($mensaje_error != null) {
        $header = "modules.php?mod=agentes&op=nuevoregistro&tipo=".$_REQUEST['tipo']."&referente=".$referente."&calificacion=".$calificacion."&telefono=".$lada.$telefono."&error=1"; # Redirige a ingresar nuevo registro por existencia
    } else {
        set_traking($usr_id, 'CREO UN REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), $u_persona, '', $db);

        if ($referente != 0) {
            set_relacion_registro($referente, $u_persona, $tipo, $db);
        }

        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_persona=" . $u_persona . "&u_registro=" . $u_registro . "&tipo=" . $tipo;
    }
} elseif (isset($action) && $action == 10) { # ACCION PARA MOSTRAR EL REGISTRO AGENDADO
    $id_solicitud = $_REQUEST['id'];
    unset_session_varname("id_solicitud");
    set_session_varname("id_solicitud", $id_solicitud);
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'TOMO REGISTRO AGENDADO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    $header = "modules.php?mod=agentes&op=index&sol=" . base64_encode($id_solicitud);

} elseif (isset($action) && $action == 11) { ##### CREA UN NUEVO TELEFONO
    $u_persona = get_session_varname('id_solicitud');
    $u_registro = get_session_varname('id_registro');
    $telefono = $_POST['telefono'];
    $lada = $_POST['lada'];
    $tipo_tel = $_POST['tipo_telefonico'];

    $result = set_nuevo_telefono($u_persona, $lada, $telefono, $tipo_tel, $usr_id, $db);
    set_session_varname('resul_reus',$result);
        if (get_session_varname('id_solicitud') != null) {
            set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
            //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
            set_traking($usr_id, 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
            //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
            if($isPredictivo == 1){
                update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
            }else{
                update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
            }
            unset_session_varname("datos_persona");
            unset_session_varname("id_solicitud");
            unset_session_varname("id_registro");
        }
        $data = get_registro_especifico($u_registro, $usr_id, '2', $db);

        $id_solicitud = $data->fields['U_PERSONA'] ?? '';
        $id_registro = $u_registro;

        if (is_object($data) && property_exists($data, '_array') && is_array($data->_array)) {
            $telefonos_disponibles = count($data->_array);
        } else {
            $telefonos_disponibles = '';
        }
        

        $customers = array();
        for ($s = 0; $s < count($data->_array); $s++) {
            $customer = array();
            $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
            $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
            $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
            $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
            $customer['RFC'] = $data->_array[$s]['RFC'];
            $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
            $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO']?? '';
            $customer['PAIS'] = $data->_array[$s]['PAIS']?? '';
            $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA']?? '';
            $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'] ?? '';
            $customer['LOCALIZACION'] = $data->_array[$s]['LOCALIZACION'] ?? '';
            $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
            $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'] ?? '';
            $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'] ?? '';
            $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'] ?? '';
            $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'] ?? '';
            $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'] ?? '';
            $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'] ?? '';
            $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
            $customer['REFERIDO_POR'] = $data->_array[$s]['REFERIDO_POR'] ?? '';
            $customer['U_REGISTRO_CAMP'] = $data->_array[$s]['U_REGISTRO_CAMP'] ?? '';
            $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
            $customer['REFERENCIA'] = $data->_array[$s]['REFERENCIA'] ?? '';
            $customer['TERMINACION_TDC'] = $data->_array[$s]['TERMINACION_TDC'] ?? '';
            $customer['PRODUCTO'] = $data->_array[$s]['PRODUCTO'] ?? '';
            $customer['CLAVE_PROD_A_VENDER'] = $data->_array[$s]['CLAVE_PROD_A_VENDER'] ?? '';
            $customer['CANAL'] = $data->_array[$s]['CANAL'] ?? '';
            $customer['MEDIO'] = $data->_array[$s]['MEDIO'] ?? '';
            $customer['SCORE_BURO'] = $data->_array[$s]['SCORE_BURO'] ?? '';
            $customer['BLACKLIST'] = $data->_array[$s]['BLACKLIST'] ?? '';
            $customer['CPID'] = $data->_array[$s]['CPID'] ?? '';
            $customer['COMENTARIOS_7'] = $data->_array[$s]['COMENTARIOS_7'] ?? '';
            $customer['DESC_PRODUCTO'] = $data->_array[$s]['DESC_PRODUCTO'] ?? '';
            $customer['BDT'] = $data->_array[$s]['BDT'] ?? '';
            $customer['U_ZONA'] = $data->_array[$s]['U_ZONA'] ?? '';
            $customer['CAMPANA'] = $data->_array[$s]['CAMPANA'] ?? '';
            $customer['OFERTA'] = $data->_array[$s]['OFERTA'] ?? '';
            $customer['CAMP'] = $data->_array[$s]['CAMP'] ?? '';
            $customer['PCN'] = $data->_array[$s]['PCN'] ?? '';
            $customer['ESTATUSDOC'] = $data->_array[$s]['ESTATUSDOC'] ?? '';
            $customer['ESTATUSONBOARDING'] = $data->_array[$s]['ESTATUSONBOARDING'] ?? '';
            $customer['AMEXURL'] = $data->_array[$s]['AMEXURL'] ?? '';
            $customer['DIGITOS'] = $data->_array[$s]['DIGITOS'] ?? '';
            $customer['TARJETA_SOLICITADA'] = $data->_array[$s]['TARJETA_SOLICITADA'] ?? '';
            $customer['TNKPAGE_ATERRIZAJE'] = $data->_array[$s]['TNKPAGE_ATERRIZAJE'] ?? '';//aqui3
            $customer['NACIONALIDAD'] = $data->_array[$s]['NACIONALIDAD'] ?? '';
            $customer['SEGURO'] = $data->_array[$s]['SEGURO'] ?? '';
            $customer['Z3033'] = $data->_array[$s]['ZONA'] ?? '';
            $customer['FCARGA'] = $data->_array[$s]['FCARGA'] ?? '';
            $customer['ID_UNICO'] = $data->_array[$s]['ID_UNICO'] ?? '';

            $customers[$s] = $customer;
        }

        set_session_varname("datos_persona", $customers);

        if (isset($id_solicitud) && $id_solicitud > 0) {
            set_session_varname("id_solicitud", $id_solicitud);
            set_session_varname("id_registro", $id_registro);
            set_evento_registro($usr_id,get_session_varname("id_solicitud"),'BUSQUEDA ESPECIFICA',$db);
            set_session_varname("inicio",1);
            $header = "modules.php?mod=agentes&op=index";
        } else {
            $data = get_mensaje_registro($id_registro, $db);

            for ($s = 0; $s < count($data->_array); $s++) {
                $mensaje = array();
                $mensaje['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
                $mensaje['ACTIVO_TZ'] = $data->_array[$s]['ACTIVO_TZ'];
                $mensaje['U_ZONA'] = $data->_array[$s]['U_ZONA'];
                $mensaje['ESTATUS'] = $data->_array[$s]['ESTATUS'];
                $mensaje['AGENDAS'] = $data->_array[$s]['AGENDAS'];
                $mensaje['TEXTO'] = $data->_array[$s]['TEXTO'];
            }
            $header = "modules.php?mod=agentes&op=error&e=1&bnd=4&customerid=" . $mensaje['U_PERSONA'] . "&activo_tz=" . $mensaje['ACTIVO_TZ'] . "&u_zona=" . $mensaje['U_ZONA'] . "&estatus=" . $mensaje['ESTATUS'] . "&agendas=" . $mensaje['AGENDAS'] . "&texto=" . $mensaje['TEXTO']; # ERROR GENERICO
            
        }
} elseif (isset($action) && $action == 12) { # ACCION DEL CALIFICAR REGISTRO INBOUNT
    $id_solicitud = get_session_varname("id_registro");
    if (isset($id_solicitud)) {
        $id_solicitud = get_session_varname("id_registro");
    } else {
        $id_solicitud = $_REQUEST['id_registro'];
    }

    $calificacion = $_REQUEST['calificacion'];
    $califica = set_califica_llamada($usr_id, $id_solicitud, $calificacion, $db);

    if ($califica >= 1) { //SE CALIFICO EL REGISTRO QUE SE ACABA DE DAR DE ALTA
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, $calificacion, $db);
        $header = "modules.php?mod=agentes&op=nueva_llamada";
    } else {
        unset_session_varname("calificar");
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'ERROR CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, $calificacion, $db);
        $header = "modules.php?mod=agentes&op=error&e=6"; # NO SE CALIFICO EL REGISTRO NUEVO
    }
    die();
} elseif (isset($action) && $action == 13) { # ACCION DE ABANDONO REGISTRO IN  CUANDO ESTABA EN LA SOLICITUD ##
    $id_solicitud = get_session_varname('id_solicitud');
    $etapa = $_REQUEST['etapa'];

    if ($id_solicitud != 0) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'ABANDONO REGISTRO IN SOLICITUD', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);
        $header = "modules.php?mod=agentes&op=index";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=7"; # NO SE CALIFICO EL NUMERO DE TELEFONO
    }
} elseif (isset($action) && $action == 14 && $_REQUEST["modo"] == "procesar") { ##### PROCESA LA INFORMACION CAPTURADA EN LA SOLICITUD  ##

    $s_usr_id = get_session_varname('s_usr_id');
    $id_producto = get_session_varname('id_producto');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_tipo_standby = get_session_varname('tipo_standby2');

    set_delete_survey($id_solicitud, $id_producto, 1, $db);
    
    $preguntas_ = get_preguntas($id_producto, $id_solicitud, 1, 0, $db); 
    
    if (count($preguntas_->_array) > 0) {
        for ($indice_ = 0; $indice_ < count($preguntas_->_array); $indice_++) {
            $respuestas_ = get_respuestas($id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], 1, $id_solicitud, 1, 0, $db);
            // Verifica si $respuestas_ es un objeto y tiene una propiedad _array
            if (is_object($respuestas_) && property_exists($respuestas_, '_array') && count($respuestas_->_array) > 0) {
                for ($indice_resp_ = 0; $indice_resp_ < count($respuestas_->_array); $indice_resp_++) {
                    if ($respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 5 || 
                        $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 6 || 
                        $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 8 || 
                        $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 9) {
                        
                        $respuesta_solicitud = $_REQUEST["txtQId" . $id_producto . $preguntas_->_array[$indice_]['QUESTIONID'] . "CId" . $respuestas_->_array[$indice_resp_]['CHOICEID']] ?? '' ;
                        
                        if (strlen($respuesta_solicitud) > 0) {
                            set_insert_survey($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], date("Y/n/j"), 1, 1, $db);
                            set_update_results($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], 1, $respuesta_solicitud, $db);
                        }
                    }
                }
            }
        }
    }

        //set_datos_solicitud_exitosa_s($id_registro, $id_producto, $id_solicitud, $db);
        
        set_datos_solicitud_exitosa($id_registro, $id_producto, $id_solicitud,get_session_varname("s_tel_contacto"),get_session_varname("grabacion"), $s_usr_id,  $db);

        $idproducto = set_estatus_registro($id_registro, $s_usr_id,get_session_varname("s_tel_contacto"), 1003, 1, 'TELEFONO VENTA', 1, 0, 'O', $db);
        
        set_traking(get_session_varname("s_usr_id"), 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);

        //!Este curl es para el proceso de capi GROSSSALES
        if ($id_producto == 100) {       
        $params1 = array( 'solicitud'=>get_session_varname('id_solicitud'), "event" => 20);  //nuevo gross sales
        $defaults1 = array(
            // CURLOPT_URL => '172.20.1.72/sftpAmex/leads_Amex_Home/pruebas.php',
            CURLOPT_URL => '172.20.1.95/api_fueralinea/main78.php',
            // CURLOPT_URL => '172.20.1.72/api_fueralinea/main78.php',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params1,
            CURLOPT_RETURNTRANSFER => true
        );
        $ch1 = curl_init();
        curl_setopt_array($ch1, $defaults1);        
        $r1 = curl_exec($ch1);

        $params2 = array( 'solicitud'=>get_session_varname('id_solicitud'), "event" => 22);  //nuevo gross sales
        $defaults1 = array(
            // CURLOPT_URL => '172.20.1.72/sftpAmex/leads_Amex_Home/pruebas.php',
            CURLOPT_URL => '172.20.1.95/api_fueralinea/main78.php',
            // CURLOPT_URL => '172.20.1.72/api_fueralinea/main78.php',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params2,
            CURLOPT_RETURNTRANSFER => true
        );
        $ch1 = curl_init();
        curl_setopt_array($ch1, $defaults1);        
        $r1 = curl_exec($ch1);

        }
        
    //Si esta en predictivo manda al menu principal, evitando el corte de llamada.
    if ($isPredictivo == 1) {

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $s_usr_id;

        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);

        $header = "modules.php?mod=agentes&op=index&aprocesado=1";

    } else {
      $header = "modules.php?mod=agentes&op=index&aprocesado=1";
    }
  
  unset_session_varname("tipo_standby2");
} elseif (isset($action) && $action == 14 && $_REQUEST["modo"] == "guardar") { ##### GUARDA LA INFORMACION CAPTURADA EN LA SOLICITUD  ##
    $s_usr_id = get_session_varname('s_usr_id');
    $id_producto = get_session_varname('id_producto');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');


    set_delete_survey($id_solicitud, $id_producto, 1, $db);

    $preguntas_ = get_preguntas($id_producto, $id_solicitud, 1, 0, $db);


        if (count($preguntas_->_array) > 0) {
            for ($indice_ = 0; $indice_ < count($preguntas_->_array); $indice_++) {

                $respuestas_ = get_respuestas($id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], 1, $id_solicitud, 1, 0, $db);


                if (count($respuestas_->_array) > 0) {
                    for ($indice_resp_ = 0; $indice_resp_ < count($respuestas_->_array); $indice_resp_++) {

                        if ($respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 5 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 6 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 8 || $respuestas_->_array[$indice_resp_]['CHOICETYPE'] == 9) {
                            $respuesta_solicitud = $_REQUEST["txtQId" . $id_producto . $preguntas_->_array[$indice_]['QUESTIONID'] . "CId" . $respuestas_->_array[$indice_resp_]['CHOICEID']] ?? '';


                            if (strlen($respuesta_solicitud) > 0) {
                                set_insert_survey($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], date("Y/n/j"), 1, 1, $db);
                                set_update_results($id_solicitud, $id_producto, $preguntas_->_array[$indice_]['QUESTIONID'], $respuestas_->_array[$indice_resp_]['CHOICEID'], 1, $respuesta_solicitud, $db);
                            }
                        }
                    }
                }
            }
        }

        set_datos_solicitud_exitosa_s($id_registro, $id_producto, $id_solicitud, $db);

        set_traking(get_session_varname("s_usr_id"), 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);


  $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(5);

} elseif (isset($action) && $action == 15) { # ACCION DE ABANDONO REGISTRO OUT CUANDO ESTABA EN LA SOLICITUD
    if (isset($id_solicitud) && $id_solicitud != 0) {
        $id_solicitud = get_session_varname('id_solicitud');
    } else {
        $id_solicitud = $_REQUEST['solicitud'];
    }
    $etapa = $_REQUEST['etapa'];

    if ($id_solicitud != 0) {
        $cal_reg = 1001;

        $rs = set_califica_registros($id_solicitud, $cal_reg, $etapa, $db);
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'ABANDONO REGISTRO OUT SOLICITUD', get_session_varname("s_usr_maquina"), $id_solicitud, $cal_reg, $db);
        $header = "modules.php?mod=agentes&op=index&sol=" . base64_encode($id_solicitud);
    } else {
        $header = "modules.php?mod=agentes&op=error&e=8"; # NO SE CALIFICO EL NUMERO DE TELEFONO
    }
} elseif (isset($action) && $action == 16) { ### Califica una llamada  del cliente.
    $id_solicitud = get_session_varname("id_registro");
    $calificacion = $_REQUEST["motivo_llamada"];
    $califica = set_califica_llamada($usr_id, $id_solicitud, $calificacion, $db);

    if ($califica == 1) {
        unset_session_varname("id_registro");
        $header = "modules.php?mod=agentes&op=nueva_llamada";
    } else {
        $header = "modules.php?mod=agentes&op=calificar_llamada";
    }
} elseif (isset($action) && $action == 17) { ### BUSCA LA SUBCALIFICACION PARA LA CALIFICACION SELECCIONADA
    $calif_ = $_REQUEST['calif'];
    $id_solicitud = $_REQUEST['id_solicitud'];
    $id_etapa = $_REQUEST['id_etapa'];

    $sub_calif = get_subcalifiacion($calif_, $id_etapa, $id_solicitud, 'TEL_CALIFICACION_IN', $db);

    if ($sub_calif == 1) {
        echo '<b>2. Sub. Calificaci&oacute;n del Registro:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
        <select name="subcalificacion" style="width:160px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <option value="0">Respuesta:</option>';
          $sub_catalogos_in = get_subcalificacion_m('TEL_SUBCALIFICACION_IN', $calif_, $id_etapa, $id_solicitud, $db);
          while (!$sub_catalogos_in->EOF) {
            echo '<option value="' . $sub_catalogos_in->fields["VALOR"] . '" ' . ($sub_catalogos_in->fields["VALOR"] == 0 ? " selected" : "") . '>' . $sub_catalogos_in->fields["ETIQUETA"] . '</option>';
            $sub_catalogos_in->MoveNext();
        }
        echo '</select>';
    }
    die();
} elseif (isset($action) && $action == 18) { ##### ACCION PARA ABANDONAR (V2)
	//PASO 1: a partir de aqu� califica
    unset_session_varname("calificados");
    unset_session_varname("url_contacto");

    $datos_persona = get_session_varname('datos_persona');
    $id_solicitud = get_session_varname('id_solicitud');
    $id_registro = get_session_varname('id_registro');
    $s_usr_id = get_session_varname('s_usr_id');
    $contador = $_REQUEST['cont'];
    $contacto_efectivo = 0;

    if ($contador == 1) {
        $telefono = $_REQUEST['tel_1'];
        $cal_tel = $_REQUEST['tel_01'];
        $u_telefono = $datos_persona[0]['U_TELEFONO'];
        if ($_REQUEST['tel_01'] == 1010) {
            $contacto_efectivo += 1;
            set_session_varname("s_telefono", $datos_persona[0]['CLAVELADA'] . $datos_persona[0]['TELEFONO']);
            set_session_varname("s_tel_contacto", $datos_persona[0]['U_TELEFONO']);
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
        } else {
            set_califica_telefono($u_telefono, $cal_tel, 1, $db);
            set_estatus_registro($id_registro, $s_usr_id, $u_telefono, $cal_tel, 1, '', 1, 0, 'O', $db);
        }
    }else{
        for ($s = 1, $t = 0; $s <= $contador; $s++, $t++) {
            if ($_REQUEST['tel_0' . $s] == 1010) {
                $_REQUEST['tel_0' . $s] . " if";
                $contacto_efectivo += 1;
                set_session_varname('CE', $t);
                set_session_varname("s_telefono", $datos_persona[$t]['CLAVELADA'] . $datos_persona[$t]['TELEFONO']);
                set_session_varname("s_tel_contacto", $datos_persona[$t]['U_TELEFONO']);
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
            } else if ($_REQUEST['tel_0' . $s] > 0) {
                $cal_tel = $_REQUEST['tel_0' . $s];
                echo $_REQUEST['tel_0' . $s] . " else if";
                set_califica_telefono($datos_persona[$t]['U_TELEFONO'], $_REQUEST['tel_0' . $s], $s, $db);
                set_estatus_registro($id_registro, $s_usr_id, $datos_persona[$t]['U_TELEFONO'], $cal_tel, 1, '', 1, 0, 'O', $db);
            }
        }
    }

    if ($contacto_efectivo >= 1) {
        set_session_varname("id_producto", $_REQUEST['producto_']);
        $header = "modules.php?mod=agentes&op=cuestionario";
    } else {
        set_traking(get_session_varname("s_usr_id"), 'CALIFICO REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    }

    set_session_varname("solicitud_previa", $id_solicitud);

    set_traking(get_session_varname("s_usr_id"), 'ABANDONO REGISTRO', get_session_varname("s_usr_maquina"), $id_solicitud, 0, $db);

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("agenda");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");

    if ($isPredictivo == 1) { 

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $s_usr_id;

        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION

} else if (isset($action) && $action == 19) { ### CREA UN REGISTRO EN BASE A PARTIR DE LA LLAMADA

        $id_solicitud = $_REQUEST['id_solicitud'];
        set_session_varname("id_solicitud", $id_solicitud);

    ##Guarda la solicitud en la tabla de td_registros
        $id_registro = get_session_varname("id_registro");
        set_guardasolicitud_registros($id_registro, $id_solicitud, $db);

    ##Reserva la solicitud al agente que tenemos
        $id_usr_super = get_session_varname("s_usr_super");
        $u_registro = set_reservasolicitud($id_solicitud, $usr_id, $id_usr_super, $db);
        set_session_varname("u_registro", $u_registro);

        $header = "modules.php?mod=agentes&op=cuestionarioinbound";

} elseif (isset($action) && $action == 20) { ##### REALIZA EL BLOQUEO DE SOLICITUD PARA VALIDACION
    $id_solicitud = get_session_varname('id_solicitud');
    set_valida_solicitud($id_solicitud, 1, 2, 0, 1, $db);
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'PASO REGISTRO A VALIDACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");

    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
} elseif (isset($action) && $action == 21) { ##### VALIDA QUE LA SOLICITUD ESTE CAPTURADA
    $id_registro = get_session_varname('id_registro');
    $count_valida = set_valida_solicitud_capturada($id_registro, $db);

  die($count_valida);
} elseif (isset($action) && $action == 22) { ### VALIDA QUE LA SOLICITUD ESTE CAPTURADA
    $id_solicitud = $_REQUEST["u_persona"];
    set_validando_estado($id_solicitud, $db);
    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    unset_session_varname("id_solicitud");
    unset_session_varname("u_registro");
    unset_session_varname("id_registro");
    $header = "modules.php?mod=agentes&op=nueva_llamada";
} elseif (isset($action) && $action == 23) { ### GENERA EL CAMPO DE RFC

    require_once("includes/calc_rfc.php");

    $id_solicitud = get_session_varname('id_solicitud');
    $id_producto = get_session_varname('id_producto');
    $num_reconocedor = (($id_producto != 1 && $id_producto != 3) ? $_REQUEST['num_reconocedor'] : '');
    $apellidoPaterno = $_REQUEST['paterno'];
    $apellidoMaterno = $_REQUEST['materno'];
    $nombre = $_REQUEST['nombre'];
    $fechaNacimiento = $_REQUEST['fecha_nac'];

    $rfc = CalcularRFC($nombre, $apellidoPaterno, $apellidoMaterno, $fechaNacimiento);
    echo $rfc;
    $rfc_valido = get_valida_rfc($id_solicitud, $id_producto, $num_reconocedor, 1, $rfc, 0, $db);

    die();
} elseif (isset($action) && $action == 24) { ### GENERA EL CAMPO DE ESTADO
    $cp = isset($_REQUEST['cp']) ? $_REQUEST['cp'] : '';
    $id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';

    $valor_ = "";


    $datos_ = get_datos_query_CP("xsp_getdelEstado3_ws", $cp, $id, $db);


    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }

    if (count($datos_->_array) > 0) {

        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $valor_;
    die();
} elseif (isset($action) && $action == 25) { ### GENERA EL CAMPO DE MUNICIPIO
    $cp = isset($_REQUEST['cp']) ? $_REQUEST['cp'] : '';
    $id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';

    $valor_ = "";

    $datos_ = get_datos_query_CP("XSP_GETDELMUNICIPIOCLIENTE3_WS", $cp, $id, $db);

    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }

    if (count($datos_->_array) > 0) {
        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $valor_;
    die();
} elseif (isset($action) && $action == 26) { ### GENERA EL CAMPO DE COLONIA
    $cp = isset($_REQUEST['cp']) ? $_REQUEST['cp'] : '';
    $id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';
    $valor_ = "";

    $datos_ = get_datos_query_CP("xsp_getColonia3_ws", $cp, $id, $db);

    if ($datos_->fields['VALOR'] != '-1') {
        $valor_ .= '<option value=""></option>';
    }
    if (count($datos_->_array) > 0) {
        for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos_->_array); $indice_datos_query_++) {
            $valor_ .= '<option value=' . $datos_->_array[$indice_datos_query_]['VALOR'] . '>';
            $valor_ .= special_chars($datos_->_array[$indice_datos_query_]['TEXTO']);
            $valor_ .= '</option>';
        }
    }
    echo $valor_;
    die();

} elseif (isset($action) && $action == 27) {

    $id_solicitud_ant = get_session_varname("id_solicitud_pred");
    unset_session_varname("id_solicitud_pred");
    set_traking($usr_id, 'INICIA PETICION OBTENCION REG. PRED', get_session_varname("s_usr_maquina"), 0, 0, $db);

    unset_session_varname("calificados");


    $blnContinuarPredictivo = true;

    //Variable para saber a que predictivo se dirije para tomar registro.
    $tipo_base = get_session_varname('s_usr_tipo_base');

    $ip = $_SERVER['REMOTE_ADDR'];


    switch (substr($ip, 0, 7)) {
        case '172.20.':
        $ip_number = str_replace("172.20.", "", $ip);
        break;
        case '172.21.':
        $ip_number = str_replace("172.21.", "", $ip);
        break;
        case '172.30.':
            $ip_number = str_replace("172.30.", "", $ip);
        break;
        case '172.23.':
        if (intval(substr($ip, strlen($ip)-3,strlen($ip))) > 100)  {
            $ip_number = str_replace("172.23.62", "64.", $ip);
        }else{
            $ip_number = str_replace("172.23.", "", $ip);
        }
        break;
        case '192.168':
        $ip_number = str_replace("192.168.", "", $ip);
        break;
    }

    if (strlen($ip_number) <= 4) {
        $ini_ext_ip = substr($ip_number, 1, 1);
        $fin_ext_ip = substr($ip_number, 3, 5);

        if ($ini_ext_ip == '.') {
            $ip_number = str_pad($ip_number, 5, "0", STR_PAD_LEFT);
        } else {
            if ($fin_ext_ip != '.') {
                $ip_number = substr($ip_number, 0, 2) . str_pad($fin_ext_ip, 2, "0", STR_PAD_LEFT);
            }
        }
    }elseif (strlen($ip_number) == 6){
        $ini_ext_ip = substr($ip_number, 0, 2);
        $fin_ext_ip = substr($ip_number, 3, 6);

        switch ($fin_ext_ip){
            case "100":
            $fin_ext_ip = str_replace("1","",$fin_ext_ip);
            $ip_number = $ini_ext_ip.$fin_ext_ip;
            break;
            case "101":case "102":case "103":case "104":case "105":case "106":case "107":case "108":case "109":
            case "110":case "111":case "113":case "114":case "115":case "116":case "117":case "118":case "119":
            $fin_ext_ip = str_replace("2","",$fin_ext_ip);
            $ip_number = $ini_ext_ip.$fin_ext_ip;
            $ip_number = $ip_number + 2000;
            break;
            case "200":case "201":case "203":case "204":case "205":case "206":case "207":case "208":case "209":
            case "210":case "211":case "213":case "214":case "215":case "216":case "217":case "218":case "219":
            case "220":case "221":case "223":case "224":case "225":case "226":case "227":case "228":case "229":
            $fin_ext_ip = str_replace("2","",$fin_ext_ip);
            $ip_number = $ini_ext_ip.$fin_ext_ip;
            $ip_number = $ip_number + 100;
            break;
            case "202":case "212":case "222":
            $fin_ext_ip = substr($fin_ext_ip,1,2);
            $ip_number = $ini_ext_ip.$fin_ext_ip;
            $ip_number = $ip_number + 100;
            break;
        }
    }


    $extension = str_replace(".", "", $ip_number);


    //ajuste para cuando la �ltima parte de la IP es de 3 cifras
    if ($extension >= 10000) {
        $extension = 100 * floor($extension / 1000) + $extension % 100;
    }

    switch ($extension) {
        case "0027":
        $extension = "1076";
        break;
        case "0251":
        $extension = "1065";
        break;
        case "0224":
        $extension = "1063";
        break;
        case "0214":
        $extension = "1069";
        break;
        case "0213":
        $extension = "1089";
        break;
        case "0216":
        $extension = "1064";
        break;
        case "0233":
        $extension = "1165";
        break;
        case "0022":
        $extension = "1070";
        break;
        case "0256":
        $extension = "1089";
        break;
    }

    unset_session_varname("agenda");


    $data = get_registros_agendado($usr_id, $db);
    $agendas = array();

    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");


    if($data->_array && count($data->_array) > 0){
   
        for ($s = 0; $s < count($data->_array); $s++) {
        $agenda = array();
        $agenda['REGISTRO'] = $data->_array[$s]['REGISTRO'];
        $agenda['PERSONA'] = $data->_array[$s]['PERSONA'];
        $agenda['HORA'] = $data->_array[$s]['HORA'];
        $agenda['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
        $agenda['DATE_'] = $data->_array[$s]['DATE_'];
        $agenda['FECHA'] = $data->_array[$s]['FECHA'];
        $agenda['COMENTARIO'] = $data->_array[$s]['COMENTARIO'];
        $agendas[$s] = $agenda;
    }

    //5721542

    set_session_varname("agenda", $agendas);

    $datos_cliente = get_session_varname("agenda");

    $agendados = strlen($datos_cliente[0]['U_PERSONA']);

    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_registro=" . $datos_cliente[0]['REGISTRO']."&agendado=1&tipo=0&hora=" . $datos_cliente[0]['HORA'] ."&com=" . urlencode($datos_cliente[0]['COMENTARIO']);

}else{
        //No tiene llamadas agendadas obtiene un registro de predictivo
        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;

        $url_startsession_pred = "http://172.20.1.10/click2dial/tdcamexonline/startsession.php?r1=11&employeeid=" . $usr_id . "&extension=" . $extension . "&employeename=" . urlencode($name) . "&nomina=" . $nomina."&base_tipo=".$tipo_base;

        // var_dump($url_startsession_pred);
        // die(); 
 
        while ($blnContinuarPredictivo) {

            $handler_status = curl_init();
            curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
            curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

            $status_pred = curl_exec($handler_status);

            //Verifica que el usuario este activo en predictivo
            if ($status_pred == 1) {
                //Sesion de predictivo iniciada
                //Limpia al agente de predictivo
                $handler_clear = curl_init($url_clear_pred);
                $clear_pred = curl_exec($handler_clear);
                curl_close($handler_clear);
                //set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
                set_traking($usr_id, 'INICIA ESPERA OBTENCION REG. PRED', get_session_varname("s_usr_maquina"), 0, 0, $db);

                //Se inicializa la tabla de pre_avail...

                //Ciclo para obtener registro
                //Verifica que obtenga un registro precargado...


                //Se manda liga para tener tiempo en espera real.
                $handler_clear = curl_init($url_tiempo_espera);
                $clear_pred = curl_exec($handler_clear);
                curl_close($handler_clear);

                $u_registro = 0;
                set_preavail($usr_id, "0", $db);

                $u_registro = get_preavail($usr_id, $db);

                while ($u_registro == 0) {
                    usleep(250000);
                    $u_registro = get_preavail($usr_id, $db);

                    //$status_pred = file_get_contents($url_status_pred);
                    $status_pred = curl_exec($handler_status);

                    //echo $u_registro;
                    //die();

                    if ($status_pred === false) {
                        $status_pred = 1;
                    }

                    if ($status_pred == 0 && $u_registro == 0) {
                        $header = "modules.php?mod=agentes&op=error&e=8"; # ERROR GENERICO
                        set_preavail($usr_id, "-1", $db);
                        $blnContinuarPredictivo = false;
                        break;
                    }
                }

                if ($status_pred != 0 || $u_registro != 0) {
                    if ($u_registro != 0 || $u_registro != -1) {
                        $telefono = get_PreAvail_Telefono($usr_id, $db);
                        //echo "Telefono: ".$telefono; die();
                        $telefono = substr($telefono, 2, 10);

                        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(29) . "&u_registro=" . $u_registro . "&tel=" . $telefono;
                    }
                }

                $blnContinuarPredictivo = false;

            } else {
                usleep(250000);

                //Sesion de predictivo desocupada
                //Inicia sesion de predictivo
                $handler_start = curl_init($url_startsession_pred);

                curl_exec($handler_start);
                curl_close($handler_start);

                //Verifica si se logueo en predictivo
                $status_pred = curl_exec($handler_status);

                if ($status_pred == 0) {
                    //Inicia preavail con -1
                    if ($empresa == 1){
                        set_preavail($usr_id, "-1", $db);
                    }
                    $blnContinuarPredictivo = false;
                } else {
                    $blnContinuarPredictivo = true;
                }
            }
            curl_close($handler_status);
        }
    }
    //Salio de obtener registro predictivo
} elseif (isset($action) && $action == 28) { ##### MUESTRA EN PANTALLA EL REGISTRO SELECCIONADO DE LA BUSQUEDA
    if (get_session_varname('id_solicitud') != null) {
        set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'ABANDONO REGISTRO POR REGISTRO ESPECIFICO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
        //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
        if($isPredictivo == 1){
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }else{
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
        }
        unset_session_varname("datos_persona");
        unset_session_varname("id_solicitud");
        unset_session_varname("id_registro");
    }

    $u_persona = isset($_REQUEST['u_persona']) ? $_REQUEST['u_persona'] : '';
    $u_registro = isset($_REQUEST['u_registro']) ? $_REQUEST['u_registro'] : '';
    $telefono = isset($_REQUEST['telefono']) ? $_REQUEST['telefono'] : '';
    $grabacion = isset($_REQUEST['grabacion']) ? $_REQUEST['grabacion'] : '';

    $db->debug = true;
    $data = get_registro_especifico_pred($u_registro, $telefono, $usr_id, '0', '0', $grabacion, $db);
    $id_solicitud = $data->fields['U_PERSONA'];
    $id_registro = $u_registro;

    $telefonos_disponibles = count($data->_array);
    $customers = array();

    for ($s = 0; $s < count($data->_array); $s++) {
        $customer = array();
        $customer['U_PERSONA'] = $data->_array[$s]['U_PERSONA'];
        $customer['NOMBRE'] = $data->_array[$s]['NOMBRE'];
        $customer['APATERNO'] = $data->_array[$s]['APATERNO'];
        $customer['AMATERNO'] = $data->_array[$s]['AMATERNO'];
        $customer['RFC'] = $data->_array[$s]['RFC'];
        $customer['FNACIMIENTO'] = $data->_array[$s]['FNACIMIENTO'];
        $customer['U_TELEFONO'] = $data->_array[$s]['U_TELEFONO'];
        $customer['PAIS'] = $data->_array[$s]['PAIS'];
        $customer['CLAVELADA'] = $data->_array[$s]['CLAVELADA'];
        $customer['TELEFONO'] = $data->_array[$s]['TELEFONO'];
        $customer['LOCALIZACION'] = isset($data->_array[$s]['LOCALIZACION']) ? $data->_array[$s]['LOCALIZACION'] : '';
        $customer['ULTIMOESTATUSTELEFONO'] = $data->_array[$s]['ULTIMOESTATUSTELEFONO'];
        $customer['PRIORIDAD'] = $data->_array[$s]['PRIORIDAD'];
        $customer['INTENTOS'] = $data->_array[$s]['INTENTOS'];
        $customer['TIEMPOACUMULADO'] = $data->_array[$s]['TIEMPOACUMULADO'];
        $customer['U_RESULTADOLLAMADA'] = $data->_array[$s]['U_RESULTADOLLAMADA'];
        $customer['U_ESTATUSLLAMADA'] = $data->_array[$s]['U_ESTATUSLLAMADA'];
        $customer['FECHAULTIMOESTATUS'] = $data->_array[$s]['FECHAULTIMOESTATUS'];
        $customer['NOMBREDERESPETO'] = $data->_array[$s]['NOMBREDERESPETO'];
        $customer['U_REGISTRO_CAMP'] = isset($data->_array[$s]['U_REGISTRO_CAMP']) ?  $data->_array[$s]['U_REGISTRO_CAMP'] : '';
        $customer['TIPO_ZONA'] = $data->_array[$s]['TIPO_ZONA'];
        $customer['MUNICIPIO_COBERTURA'] = $data->_array[$s]['MUNICIPIO_COBERTURA'];
        $customer['REFERENCIA'] = isset($data->_array[$s]['REFERENCIA']) ? $data->_array[$s]['REFERENCIA'] : '';
        $customer['TERMINACION_TDC'] = isset($data->_array[$s]['TERMINACION_TDC']) ? $data->_array[$s]['TERMINACION_TDC']: '';
        $customer['PRODUCTO'] = isset($data->_array[$s]['PRODUCTO']) ? $data->_array[$s]['PRODUCTO']: '';
        $customer['CLAVE_PROD_A_VENDER'] = isset($data->_array[$s]['CLAVE_PROD_A_VENDER']) ? $data->_array[$s]['CLAVE_PROD_A_VENDER']: '';
        $customer['TIPO_CUENTA'] = isset($data->_array[$s]['TIPO_CUENTA']) ? $data->_array[$s]['TIPO_CUENTA']: '';
        $customer['EDAD'] = $data->_array[$s]['EDAD'];
        $customer['EMAIL'] = isset($data->_array[$s]['EMAIL']) ? $data->_array[$s]['EMAIL']: '';
        $customer['CELULAR'] = isset($data->_array[$s]['CELULAR']) ? $data->_array[$s]['CELULAR']: '';
        $customer['CANAL'] = $data->_array[$s]['CANAL'];
        $customer['MEDIO'] = isset($data->_array[$s]['MEDIO']) ? $data->_array[$s]['MEDIO']: '';
        $customer['SCORE_BURO'] = $data->_array[$s]['SCORE_BURO'];
        $customer['BLACKLIST'] = $data->_array[$s]['BLACKLIST'];
        $customer['CPID'] = $data->_array[$s]['CPID'];
        $customer['COMENTARIOS_7'] = $data->_array[$s]['COMENTARIOS_7'];
        $customer['DESC_PRODUCTO'] = $data->_array[$s]['DESC_PRODUCTO'];
        $customer['BDT'] = isset($data->_array[$s]['BDT']) ? $data->_array[$s]['BDT']: '';
        $customer['U_ZONA'] = $data->_array[$s]['U_ZONA'];
        $customer['CAMPANA'] = $data->_array[$s]['CAMPANA'];
        $customer['OFERTA'] = $data->_array[$s]['OFERTA'];
        $customer['CAMP'] = $data->_array[$s]['CAMP'];
        $customer['PCN'] = isset($data->_array[$s]['PCN']) ? $data->_array[$s]['PCN']: '';
        $customer['ESTATUSDOC'] = isset($data->_array[$s]['ESTATUSDOC']) ? $data->_array[$s]['ESTATUSDOC'] : '';
        $customer['ESTATUSONBOARDING'] = isset($data->_array[$s]['ESTATUSONBOARDING']) ? $data->_array[$s]['ESTATUSONBOARDING'] : '';
        $customer['AMEXURL'] = $data->_array[$s]['AMEXURL'];
        $customer['DIGITOS'] = isset($data->_array[$s]['DIGITOS']) ? $data->_array[$s]['DIGITOS'] : '';
        $customer['TARJETA_SOLICITADA'] = $data->_array[$s]['TARJETA_SOLICITADA'];
        $customer['TNKPAGE_ATERRIZAJE'] = $data->_array[$s]['TNKPAGE_ATERRIZAJE'];
        $customer['NACIONALIDAD'] = $data->_array[$s]['NACIONALIDAD'];
        $customer['SEGURO'] = isset($data->_array[$s]['SEGURO']) ? $data->_array[$s]['SEGURO'] : '';
        $customer['ID_UNICO'] = $data->_array[$s]['ID_UNICO'];
        $customers[$s] = $customer;
    }

    set_session_varname("datos_persona", $customers);
    if (isset($id_solicitud) && $id_solicitud > 0) {
        set_session_varname("id_solicitud", $id_solicitud);
        set_session_varname("id_solicitud_pred", $id_solicitud);
        set_session_varname("id_registro", $id_registro);
        set_evento_registro($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO',$db);
        $header = "modules.php?mod=agentes&op=index&t_reg=1";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=62"; # ERROR GENERICO
    }
} elseif (isset($action) && $action == 29) { ##### OBTIENE EL REGISTRO DE PREAVAIL
    $u_registro = $_REQUEST['u_registro'];
    $telefono_pred = $_REQUEST['tel'];
    $grabacion = get_PreAvail_Grabacion($usr_id, $db);
    set_session_varname("grabacion", $grabacion);

    if ($u_registro != 0 && $u_registro != "-1") {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(28) . "&u_registro=" . $u_registro . "&telefono=" . $telefono_pred."&grabacion=".$grabacion;
    } else {
        $header = "modules.php?mod=agentes&op=error&e=61"; # ERROR GENERICO
    }
} elseif (isset($action) && $action == 30) { ##### VALIDA EL ACCESO A LA BUSQUEDA DE DATOS
    $function = 15000;
    $languaje = 1;

    $rs = get_valida_acceso($usr_id, $function, $languaje, $db);
    $acceso = count($rs->fields);

    if ($acceso != 0) {
        $header = "modules.php?mod=agentes&op=busqueda_datos";
    } else {
        $header = "modules.php?mod=agentes&op=error&e=3"; # ERROR CUANDO NO TIENE PERMITIDO REALIZAR BUSQUEDAS
    }
} elseif (isset($action) && $action == 31) { ##### Busqueda de solicitudes (Mantenimiento)
    $customerid = $_REQUEST['txt_solicitud'];
    $surveyid = $_REQUEST['txt_producto'];
    $header = "modules.php?mod=agentes&op=mtto_solicitud&customerid=$customerid&surveyid=$surveyid";
} elseif (isset($action) && $action == 32) { ##### Busqueda de empresas
    $header = "modules.php?mod=agentes&op=busqueda_empresas";
} elseif (isset($action) && $action == 33) { ##### Busqueda por CP
    $act2 = $_REQUEST['act2'];
    if (isset($act2) && $act2 == 1) {//se utiliza en busqueda de empresas
        $cp = $_POST['cp'];
        $edo = $_POST['edo'];
        $mun = $_POST['mun'];
        $cdd = trim(strtoupper($_POST['cdd']));
        $col = strtoupper($_POST['col']);

        try {
            $query = "BEGIN SPS_GETBUSQUEDA_CP(:cp,:col,:edo,:mun,:cdd,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $cp, 'cp');
            $db->InParameter($stmt, $col, 'col');
            $db->InParameter($stmt, $edo, 'edo');
            $db->InParameter($stmt, $mun, 'mun');
            $db->InParameter($stmt, $cdd, 'cdd');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }
        if (!$rs->EOF) {
            ?>
            <table class="cp">
                <tr class="cp">
                    <th class="cp">
                        <label for="edo">Estado</label>
                    </th>
                    <th class="cp">
                        <label for="cdd">Ciudad</label>
                    </th>
                    <th class="cp">
                        <label for="mun">Municipio</label>
                    </th>
                    <th class="cp">
                        <label for="col">Colonia</label>
                    </th>
                    <th class="cp">
                        <label for="cp">CP</label>
                    </th>
                </tr>
                <?php while (!$rs->EOF) { ?>
                <tr> <?php
                    $ie = $rs->fieldCount() - 1;
                    for ($i = 0; $i <= $ie; $i++) {
                        ?>

                        <td class="cp">
                            <?php echo $reg = $rs->fields[$i]; ?>
                        </td>

                        <?php
                    }
                    $rs->MoveNext();
                    ?></tr> <?php
                }
                ?>
            </table><?php
        } else {
            echo "<label for='cp'>CP no encontrado</label> ";
        }
    } elseif (isset($act2) && $act2 == 2) {// se utuliza en busqueda de CP
        echo $_POST['edo'];
        try {
            $query = "BEGIN SPS_GETMUNICIPIO(:edo,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $_POST['edo'], 'edo');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }
        //echo '<select id="mun2">';
        echo "<option value=''>Seccione uno..</option>";
        while (!$rs->EOF) {
            $ie = $rs->fieldCount() - 1;
            //$ii=0;
            for ($i = 0; $i <= $ie; $i++) {
                echo "<option value='" . $rs->fields[$i] . "'>" . $rs->fields[$i] . "</option>";
                //$ii++;
            }
            $rs->MoveNext();
        }
    } elseif (isset($act2) && $act2 == 3) {// se utuliza en busqueda de CP
        //echo $_POST['edo'];
        //echo $_POST['mun'];
        try {
            $query = "BEGIN SPS_GETCIUDAD(:edo,:mun,:rc); END;";
            $stmt = $db->PrepareSP($query);
            $db->InParameter($stmt, $_POST['edo'], 'edo');
            $db->InParameter($stmt, $_POST['mun'], 'mun');
            $rs = $db->ExecuteCursor($stmt, 'rc');
        } catch (Exception $e) {
            pa($e->getMessage());
            pa($e->getTraceAsString());
            die();
            exit();
        }

        while (!$rs->EOF) {
            $ie = $rs->fieldCount() - 1;
            for ($i = 0; $i <= $ie; $i++) {
                echo $cdd = $rs->fields[$i];
            }
            $rs->MoveNext();
        }
    }
    die();
    exit();
    //$header = "modules.php?mod=agentes&op=busqueda_cp";
} elseif (isset($action) && $action == 34) { ##### Liberaci�n de registros
    $id_solicitud = $_REQUEST['solicitud'];
    $elapsed = -1;
    $camp = 1;
    try {
        $id_registro = get_registro_campaña($id_solicitud, $db);
        set_libera_solicitud($id_registro, $elapsed, $camp, $db);
        echo "Registro $id_solicitud ($id_registro) liberado.";
    } catch (Exception $e) {
        echo "<pre>{$e->getTrace()}</pre>";
    }
    die();
    exit();
} elseif (isset($action) && $action == 35) { ##### Actualiza los datos
    $nombre_completo = $_GET['nombre'] . ' ' . $_GET['nombre2'];
    $apaterno = $_GET['apaterno'];
    $amaterno = $_GET['amaterno'];
    $customerid = $_GET['solicitud'];
    set_actualizarnombre($customerid, $nombre_completo, $apaterno, $amaterno, $db);
    $registros = set_busca_cliente($customerid, $nombre, $paterno, $materno, $usr_id, $db);

    $header = "modules.php?mod=agentes&op=process_data&act=Mw==&u_persona=" . $customerid . "&u_registro=" . $registros->fields["REGISTRO"];
} elseif (isset($action) && $action == 37) { ### BOTON DE INCIO
    if(get_session_varname('id_registro') == ''){
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'PRESIONO BOTON INICIO - SIN REGISTRO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    }else {
        set_libera_solicitud(get_session_varname('id_registro'), 1, 1, $db);
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'PRESIONO BOTON INICIO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    }
    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }


    if(isset($_SESSION['log_registro'])){
        switch (get_session_varname('log_registro')){
            case 1:
            update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'ENTRO A SOLCITUD', $db);
            break;
            case 2:
            update_evento_registro2($usr_id,-1,'CONSULTA AGENDA', $db);
            break;
            case 3:
            update_evento_registro2($usr_id,-1,'CONSULTA BUSQUEDA', $db);
            break;
            default :
            break;
        }
    }

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");
    unset_session_varname("log_registro");

    //$header = "index2.php";
    if ($isPredictivo == 1) {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
} elseif (isset($action) && $action == 38) { ###
    $nomina = $_REQUEST['nomina'];
    $u_user = $_REQUEST['u_user'];

    //$indicadores = getindicadores(554472,4431,$db);
    $indicadores = getindicadores($nomina, $u_user, $db);
    ?>
    <tr class="indicadores">
        <th colspan="12" class="indicadores">Indicadores</th>
    </tr>
    <tr class="indicadores">
        <th colspan="2" class="indicadores">Hoy</th>
        <th colspan="8" class="indicadores">Acumulado 1 - 15 / 16 - 31 Ultima Act. del ScoreCard : <?php echo $indicadores->_array[0]['FECHA']; ?></th>
    </tr>
    <tr class="indicadores" style="background: #006666;">
        <td class="indicadores">Au</td>
        <td class="indicadores">Ap</td>
        <!--td class="indicadores">Ocupaci&oacute;n</td-->

        <td class="indicadores">Cumplimiento</td>
        <td class="indicadores">Comisiones</td>
        <td class="indicadores">Ocupaci&oacute;n</td>

        <td class="indicadores">Calidad</td>
        <td class="indicadores">Ap (vta en fr&iacute;o)</td>
        <td class="indicadores">Ap (vta en fr&iacute;1o) Auditadas exitosamente</td>
        <td class="indicadores">Au</td>
        <td class="indicadores">Ap</td>
    </tr>
    <tr>
        <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['AU_COLOR']; ?>;" >
            <?php echo $indicadores->_array[0]['AU']; ?>
        </td>
        <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['AP_COLOR']; ?>;" >
            <?php echo $indicadores->_array[0]['AP']; ?>
        </td>
            <!--td class="indicadores">
        </td-->

        <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['CUM_COLOR']; ?>;" >
            <?php echo substr($indicadores->_array[0]['CUMPLIMIENTO'] * 100, 0, 5) . " %"; ?>
        </td>
        <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['COM_COLOR']; ?>;" >
            <?php echo $indicadores->_array[0]['COMICIONES']; ?>
        </td>
        <td class="indicadores" style="background: <?php echo $indicadores->_array[0]['OCU_COLOR']; ?>;" >
            <?php echo substr(($indicadores->_array[0]['OCUPACION']) * 100, 0, 5) . " %"; ?>
        </td>

        <td class="indicadores"><?php echo $indicadores->_array[0]['CALIDAD']; ?></td>
        <td class="indicadores"><?php echo $indicadores->_array[0]['AP_FRIO']; ?></td>
        <td class="indicadores"><?php echo $indicadores->_array[0]['VNTS_EXITOSAMENTE']; ?></td>
        <td class="indicadores"><?php echo $indicadores->_array[0]['AU_Q']; ?></td>
        <td class="indicadores"><?php echo $indicadores->_array[0]['AP_Q']; ?></td>
    </tr>
    <?php
    die();
    exit();
} elseif (isset($action) && $action == 40) { //Obtener lista de llamadas al 01800 del usuario

    $u_user = $_REQUEST['u_user'];
    $rs800 = get_800($u_user, $db);


    if (!$rs800->EOF) {
        ?>
        <table class="indicadores">
            <tr class="indicadores">
                <th colspan="8" class="indicadores">Llamadas 800</th>
            </tr>
            <tr class="indicadores" style="background: #006666;">
                <td>Reporte</td>
                <td>Registro</td>
                <td>Cliente</td>
                <td>Tel&eacute;fono</td>
                <td>Comentario</td>
                <td>Motivo Llamada</td>
                <td>Fecha</td>
                <td>Reportado a</td>
            </tr>
            <?php
            while (!$rs800->EOF) {
                ?>
                <tr class="indicadores">
                    <td><?php echo $rs800->fields['Reporte'] ?></td>
                    <td><?php echo $rs800->fields['Registro'] ?></td>
                    <td><?php echo $rs800->fields['Cliente'] ?></td>
                    <td><?php echo $rs800->fields['Tel�fono'] ?></td>
                    <td><?php echo $rs800->fields['Comentario'] ?></td>
                    <td><?php echo $rs800->fields['Motivo Llamada'] ?></td>
                    <td><?php echo $rs800->fields['Fecha'] ?></td>
                    <td><?php echo $rs800->fields['Reportado a'] ?></td>
                </tr>
                <?php
                $rs800->MoveNext();
            }
            ?>
        </table>
        <?php
    } else {
        echo "No existen llamadas";
    }
    die();
    exit();
}elseif (isset($action) && $action == 41) { //Obtener lista de llamadas al 01800 del usuario
    $dd = set_verifica_tel($_REQUEST['numero'],$db);
    echo $dd;
    die();
}elseif (isset($action) && $action == 42) { //Enviar la subcalificaci�n
	if($_REQUEST['origen'] == 1)
	set_subcalificacion_registro($_REQUEST['referente'],$_REQUEST['calificacion'],$_REQUEST['telefono'],$db);
	set_session_varname("calificados", get_session_varname("calificados") . $_REQUEST['calificado']);
    die();
} elseif (isset($action) && $action == 43) { ### Finaliza la Venta

    set_valida_solicitud(get_session_varname("id_solicitud"), get_session_varname("id_producto"), 2, 0, 1, $db);
    update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'ENTRO A SOLCITUD', $db);
    set_datos_solicitud_exitosa_validacion_local(get_session_varname("id_solicitud"), get_session_varname("id_producto") , $usr_id, $db);    

    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("aprocesado");
    unset_session_varname("CE");
    unset_session_varname("log_registro");

    if ($isPredictivo == 1) {
        $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION
    } else {
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    }
    
} elseif (isset($action) && $action == 406) { ### Obtener lista de agendados para el usuario
    $tipo_agenda = $_POST['tipo_agenda'];

    $id_solicitud = get_session_varname("id_solicitud");
    $datos_cliente = get_session_varname("datos_persona");
    /*  if($datos_cliente && !is_array($datos_cliente)) {
          echo "NO existen solicitudes Agendadas"
      }else{ */

        if (is_array($datos_cliente) && isset($datos_cliente[0])) {
            $cliente = $datos_cliente[0]['NOMBRE'] . '&nbsp;' . $datos_cliente[0]['APATERNO'] . '&nbsp;' . $datos_cliente[0]['AMATERNO'];
        } else {
            // Maneja el caso en el que $datos_cliente no es un array o no tiene elementos
            $cliente = 'Información no disponible';
        }





    $fecha = $_POST['fecha'];
    $rs = get_agenda_usuario_dia($usr_id, $fecha, $db);

    if ($tipo_agenda == 0) {

        if (!$rs->EOF) {
            echo "<table border='1' width='98%' class='agenda'>\r\n";
            echo "<caption>$fecha</caption>\r\n";
            echo "<tr class='agenda'>\r\n";
            echo "<th width='16%' class='agenda'>Hora</th>";
            echo "<th width='45%' class='agenda'>Nombre</th>";
            echo "<th width='45%' class='agenda'>Comentario</th>";
            echo "</tr>\r\n";
            while (!$rs->EOF) {
                echo "<tr class='agenda'>\r\n";
                if ($rs->fields['MEDIAHORA'] != -1) {
                    echo "<td class='agenda'><a href=\"#\" onclick=\"guardaAgenda({$rs->fields['MEDIAHORA']}, '{$rs->fields['HORAREAL']}', '$cliente', $id_solicitud,$isPredictivo);\">{$rs->fields['HORAREAL2']}</a></td>\r\n";
                } else {
                    echo "<td class='agenda'>{$rs->fields['HORAREAL2']}</td>\r\n";
                }
                echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                echo "<td class='agenda'>{$rs->fields['COMENTARIO']}</td>\r\n";
                echo "</tr>\r\n";
                $rs->MoveNext();
            }
            echo "</table>";
        }
    } elseif ($tipo_agenda == 1) {
        if (!$rs->EOF) {
            echo "<table border='1' width='98%' class='agenda'>\r\n";
            echo "<caption>$fecha</caption>\r\n";
            echo "<tr class='agenda'>\r\n";
            echo "<th width='12%' class='agenda'>Hora</th>";
            echo "<th width='45%' class='agenda'>Nombre</th>";
            echo "<th width='45%' class='agenda'>Comentario</th>";
            echo "<th width='45%' class='agenda'>Accion</th>";
            echo "</tr>\r\n";
            while (!$rs->EOF) {
                echo "<tr class='agenda'>\r\n";
                if ($rs->fields['MEDIAHORA'] != -1) {
                    echo "<td class='agenda'><!--a href=\"#\" onclick=\"guardaAgenda({$rs->fields['MEDIAHORA']}, '{$rs->fields['HORAREAL']}', '$cliente', $id_solicitud,$isPredictivo);\"-->{$rs->fields['HORAREAL2']}</a></td>\r\n";
                    echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                    echo '<td class=\'agenda\'>' . $rs->fields['COMENTARIO'] . '</td>
                    <td></td>';
                } else {
                    echo "<td class='agenda'>{$rs->fields['HORAREAL2']}</td>\r\n";
                    echo "<td class='agenda'>{$rs->fields['NOMBRE']}</td>\r\n";
                    echo '<td class=\'agenda\'>' . $rs->fields['COMENTARIO'] . '</td>';
                    echo '<td><a href="#" onclick="Mostrar_agendado3(0, ' . $rs->fields['U_REGISTRO'] . ', ' . $rs->fields['U_REGISTRO'] . ', \'' . encripta(3) . '\')"><img src="' . $linkpath . 'includes/imgs/Comenzar.gif"></td>';
                }
                echo "</tr>\r\n";
                $rs->MoveNext();
            }
            echo "</table>";
        }
    } else {
        echo "No hay agenda para este d�a.";
    }

    $rs->Close();
    die();
}elseif (isset($action) && $action == 600) { //Bloqueo de clientes molestos
    set_bloquea_cliente_molesto(get_session_varname('id_registro'), $action, 'CONSUMIDO', $db);
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'BLOQUEO REGISTRO CLIENTE MUY MOLESTO', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);

    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");

    $header = "index2.php";
}elseif (isset($action) && $action == 44) { //Actualiza nombre base sin nombre (SN)
    $nombre = quitarCaracteresEspeciales(strtoupper($_REQUEST['nombre']));
    $paterno = quitarCaracteresEspeciales(strtoupper($_REQUEST['paterno']));
    $materno = quitarCaracteresEspeciales(strtoupper($_REQUEST['materno']));
    $u_persona = get_session_varname("id_solicitud");
    $u_registro = get_session_varname("id_registro");
    $tipo = 1;

    set_actualizarnombre($u_persona, $nombre, $paterno, $materno, $db);
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'ACTUALIZO NOMBRE DE CLIENTE, BASE SIN NOMBRE', get_session_varname("s_usr_maquina"), get_session_varname('id_solicitud'), 0, $db);
    set_traking_aviso($usr_id, 'ACTUALIZO NOMBRE DE CLIENTE, BASE SIN NOMBRE', get_session_varname("s_usr_maquina"), $u_registro, get_session_varname('tel_predictivo'), $db);
    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(3) . "&u_persona=" . $u_persona . "&u_registro=" . $u_registro . "&tipo=" . $tipo;

}elseif (isset($action) && $action == 47) { //Actulizar forma de pago
    if($_REQUEST['producto'] == 1){
        $datos = get_prima($_REQUEST['producto'],$_REQUEST['prod_value'],$db);
    }else{
        $datos = get_forma_pago($_REQUEST['producto'],$_REQUEST['prod_value'],$db);
    }

    echo $datos->fields['COMBO'];
    die();
}elseif (isset($action) && $action == 48) { //Prescrining

}elseif (isset($action) && $action == 49) { //Enviar el SMS

    $numero = $_REQUEST['numero'];
    $id_solicitud = get_session_varname('id_solicitud');
    $id_producto = get_session_varname('id_producto');
    //print_r($_REQUEST);

    $codigo_ivr_sms = get_obtiene_ivr_sec($id_solicitud,$id_producto,$db);
    $proveedor_sms = get_proveedor_sms($db);
    //echo $codigo_ivr_sms;

    $url_envio_sms = "http://172.20.1.95/sms_bancomer_prueba/index3.php?codigo=".$codigo_ivr_sms."&numero=" . $numero."&proveedor=" . $proveedor_sms;

    $handler_envio = curl_init();
    curl_setopt($handler_envio, CURLOPT_URL, $url_envio_sms);
    curl_setopt($handler_envio, CURLOPT_RETURNTRANSFER, 1);

    curl_setopt($handler_envio, CURLOPT_TIMEOUT, 10); //timeout in seconds

    $uid = curl_exec($handler_envio);

    if($proveedor_sms == 1){
        set_UID_sms_ivr($id_solicitud,$id_producto,$uid,$codigo_ivr_sms,$db);

        $url_status_sms = "http://172.20.1.95/sms_bancomer_prueba/status.php?uid=" . $uid;

        usleep(500000);
        $handler_status_sms = curl_init();
        curl_setopt($handler_status_sms, CURLOPT_URL, $url_status_sms);
        curl_setopt($handler_status_sms, CURLOPT_RETURNTRANSFER, 1);

        curl_setopt($handler_status_sms, CURLOPT_TIMEOUT, 10); //timeout in seconds

        $status_sms = curl_exec($handler_status_sms);

        //ohernandez@20190117
        if ($error_number = curl_errno($handler_status_sms)) {
            if (in_array($error_number, array(CURLE_OPERATION_TIMEDOUT, CURLE_OPERATION_TIMEOUTED))) {
                echo "Tiempo de espera excedido";
                die();
                exit();
            }
        }
        //

        $resp_status_sms = json_decode($status_sms);
        if ($resp_status_sms->resp == "200") {
            $status_sms = $resp_status_sms->status;

            if($status_sms != ''){
                echo $status_sms;
            }else{
                echo 'SMS ENVIADO!!!';
            }

        } elseif ($resp_status_sms->resp == "400") {
            echo $resp_status_sms->description;
        } else {
            echo "<pre>";
            print_r($resp_status_sms);
            echo "</pre>";
        }
    }else{
        echo 'SMS ENVIADO!!!';
    }


//    echo "envi de sms...";
    die();
}elseif (isset($action) && $action == 51) { ### GUARDAR LA RESPUESTA DE AUTENTICACION
    /*echo "<pre>";
    print_r($_REQUEST);
    echo "</pre>";*/
    $id_solicitud = get_session_varname('id_solicitud');

    set_result_cajero($id_solicitud,$_REQUEST['r_valor'],$_REQUEST['act2'],$db);

    die();
}elseif (isset($action) && $action == 55) { //Guarda nombre de grabaci�n

    $solicitud = $_REQUEST['u_persona'];
    $nomina = $_REQUEST['nomina'];
    $telefono = $_REQUEST['telefono'];

    //set_session_varname("tel_predictivo", $telefono);

    $grabacion = set_insert_nombre_grabacion($solicitud,$nomina,$telefono, $empresa, $db);
    set_session_varname("grabacion", $grabacion);

    $t_registro = 0;
    set_session_varname("t_registro", $t_registro);

    die();
}elseif (isset($action) && $action == 56) { //verifica cuantos tel ha ingresado el agente

    //print_r($_REQUEST);
    $u_persona = get_session_varname("id_solicitud");

    $dd = set_count_tel($u_persona,$db);

    echo trim($dd);
    die();
    exit();
}elseif (isset($action) && $action == 57) { ### Regreso de Break u otros status
    $tipo_standby = get_session_varname("tipo_standby");
 
    // barra($isPredictivo);

    if ($tipo_standby == 1) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO BREAK', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO BREAK', $db);
    } elseif ($tipo_standby == 2) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO BANIO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO BANIO', $db);
    } elseif ($tipo_standby == 3) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO CAPACITACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO CAPACITACION', $db);
    } elseif ($tipo_standby == 4) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO RETROALIMENTACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO RETROALIMENTACION', $db);
    } elseif ($tipo_standby == 5) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO REPORTERIA', $db);
    } elseif ($tipo_standby == 6) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO DESCANSO FORZADO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO DESCANSO FORZADO', $db);
    } elseif ($tipo_standby == 7) {
        //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
        set_traking($usr_id, 'REGRESO JUNTA DE ARRANQUE', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
        update_evento_registro2($usr_id,"-1",'INICIO JUNTA DE ARRANQUE', $db);
    } elseif ($tipo_standby == 8) {
        update_evento_registro2($usr_id,-1,'CONSULTA AGENDA', $db);
    } elseif ($tipo_standby == 9) {
        update_evento_registro2($usr_id,-1,'CONSULTA BUSQUEDA', $db);
    }

    //update_evento_registro2($usr_id,-1,'CONSULTA BUSQUEDA', $db);

    //update_evento_registro($usr_id,get_session_varname("id_solicitud"), $db);
    if($isPredictivo == 1){
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }else{
        update_evento_registro2($usr_id,get_session_varname("id_solicitud"),'OBTUBO REGISTRO', $db);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("agenda");
    unset_session_varname("tipo_standby");
    unset_session_varname("log_registro");


    if ($isPredictivo == 1) {

        $u_registro = 0;

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        if ($status_pred == 1) {
            $header = "modules.php?mod=agentes&op=error&e=12"; # ERROR GENERICO
        }else{
            $header = "modules.php?mod=agentes&op=process_data&act=". encripta('27');
        }
    }else{
     $header = "modules.php?mod=agentes&op=process_data&act=". encripta('1');
 }
} elseif (isset($action) && $action == 58) { ### Break
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO BREAK', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO BREAK', $db);

    if ($isPredictivo == 1) {

        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=1";
} elseif (isset($action) && $action == 59) { ### Ba�o
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO BANIO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO BANIO', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=2";
}elseif (isset($action) && $action == 60) { ### Capacitacion
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO CAPACITACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO CAPACITACION', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=3";
}elseif (isset($action) && $action == 61){
    $u_registro = 0;

    $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

    $handler_status = curl_init();

    curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
    curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

    $status_pred = curl_exec($handler_status);

    $u_registro = get_preavail($usr_id, $db);

    if ($status_pred != 0 || $u_registro != 0) {
        if ($u_registro != 0 || $u_registro != -1) {
            $telefono = get_PreAvail_Telefono($usr_id, $db);
            $telefono = substr($telefono, 2, 10);

            $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(29) . "&u_registro=" . $u_registro . "&tel=" . $telefono;
        }
    }
}elseif (isset($action) && $action == 63) { ### Capacitacion
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO RETROALIMENTACION', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO RETROALIMENTACION', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=4";
}elseif (isset($action) && $action == 64) { ### VER REPORTERIA
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO REPORTERIA', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=web_sicall&e=5";
}elseif (isset($action) && $action == 65) { ### DESCANSO FORZADO
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO DESCANSO FORZADO', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO DESCANSO FORZADO', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=6";
} elseif (isset($action) && $action == 66) { ### JUNTA DE ARRANQUE
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO JUNTA DE ARRANQUE', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO JUNTA DE ARRANQUE', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=standby&e=7";
} elseif (isset($action) && $action == 67) {

    $tipo_standby = $_REQUEST['id'];
    set_preavail($usr_id, "-1", $db);
    set_session_varname('tipo_standby2', $tipo_standby );
    die();


} elseif (isset($action) && $action == 68) { ###

    if ($isPredictivo == 1) {

        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=registros_agenda&e=8";
} elseif (isset($action) && $action == 69) { ###

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=process_data&act=Mg==";
}elseif (isset($action) && $action == 70) {
    $header = "modules.php?mod=admin&op=process_data&act=2";
    header("Location:" . $header);
    die();
}elseif (isset($action) && $action == 71) { //Refresh prima
    $datos = get_prima_values($_REQUEST['plan'],$_REQUEST['formapago'],get_session_varname('id_producto'),$db);
    echo $datos->fields['COMBO'];
    die();
}elseif (isset($action) && $action == 72) { //Refresh prima 7
    $datos = get_prima_values_7($_REQUEST['plan'],$_REQUEST['formapago'],get_session_varname('id_solicitud'),$_REQUEST['edad'],$db);

    echo $datos->fields['COMBO'];
    die();
}elseif (isset($action) && $action == 73) {

   echo $resul = set_autorizacion(get_session_varname('s_usr_nomina'),2, $db);
   if($resul == '1'){
       set_autorizacion(get_session_varname('s_usr_nomina'),0, $db);
   }
   die();
}
elseif (isset($action) && $action == 74) { //Refresh prima 7 _A1
    $datos = get_prima_values_A($_REQUEST['plan'],$_REQUEST['sexo'],$_REQUEST['formapago'],get_session_varname('id_solicitud'),$_REQUEST['edad'],$db);
    echo $datos->fields['COMBO'];
    die();
}elseif (isset($action) && $action == 75) { //Refresh prima
    $datos = get_prima_values_rh($_REQUEST['plan'],$_REQUEST['aseg'],$_REQUEST['formapago'],get_session_varname('id_producto'),$db);
    echo $datos->fields['COMBO'];
    die();
}   elseif (isset($action) && $action == 76) {
    $header = "modules.php?mod=agentes&op=process_data&act=NjE=";
} elseif (isset($action) && $action == 77) { ### VER REPORTERIA CANCELADAS
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO REPORTERIA', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=solicitudes_canceladas&e=5";
}elseif (isset($action) && $action == 78) { ### VER REPORTERIA VALIDADAS
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO REPORTERIA', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=solicitudes_aprobadas&rep=1&e=5";
}elseif (isset($action) && $action == 79) { ### VER REPORTERIA PENDIENTES
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO REPORTERIA', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=solicitudes_aprobadas&rep=2&e=5";
}elseif (isset($action) && $action == 80) { ### VER REPORTERIA PROCESADAS
    //                set_traking_($usr_id, 'id de catalogo', get_session_varname("id_solicitud"), get_session_varname("s_usr_maquina"),$db);
    set_traking($usr_id, 'INICIO REPORTERIA', get_session_varname("s_usr_maquina"), get_session_varname("tipo_standby"), '', $db);
    set_evento_registro($usr_id,"-1",'INICIO REPORTERIA', $db);

    if ($isPredictivo == 1) {
        $url_clear_pred = "http://172.20.1.10/click2dial/tdcamexonline/clearmeetme.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_clear = curl_init($url_clear_pred);
        $clear_pred = curl_exec($handler_clear);
        curl_close($handler_clear);

        set_preavail($usr_id, "-1", $db);

        $url_status_pred = "http://172.20.1.10/click2dial/tdcamexonline/getemployeestatus.php?employeeid=" . $usr_id;

        $handler_status = curl_init();
        curl_setopt($handler_status, CURLOPT_URL, $url_status_pred);
        curl_setopt($handler_status, CURLOPT_RETURNTRANSFER, 1);

        $status_pred = curl_exec($handler_status);

        while ($status_pred == 1) {
            usleep(500000);
            $status_pred = curl_exec($handler_status);
        }

        $url_logout_pred = "http://172.20.1.10/click2dial/tdcamexonline/softemployeelogout.php?employeeid=" . $usr_id;
        //Limpia al agente de predictivo
        $handler_logout = curl_init($url_logout_pred);
        $logout_pred = curl_exec($handler_logout);
        curl_close($handler_logout);
    }

    $header = "modules.php?mod=agentes&op=solicitudes_procesadas&e=5";
} elseif (isset($action) && $action == 81) {

    $url_asistido = $_REQUEST['url_asistido'];

    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_FOLLOWLOCATION => true,     // follow redirects
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
        CURLOPT_TIMEOUT        => 120,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        CURLOPT_SSL_VERIFYPEER => false     // Disabled SSL Cert checks
        );

    $handler_marcacion = curl_init($url_asistido);
    curl_setopt_array( $handler_marcacion, $options );

    curl_exec($handler_marcacion);

    curl_errno( $handler_marcacion );
    curl_error( $handler_marcacion );
    curl_getinfo( $handler_marcacion );

    curl_close($handler_marcacion);


} elseif (isset($action) && $action == 82) {

    $solicitud = $_REQUEST['u_persona'];
    $surveyid = $_REQUEST['surveyid'];

    set_recuperada($solicitud, $surveyid, $db);

    $header = "modules.php?mod=agentes&op=solicitudes_canceladas&e=5";
} elseif (isset($action) && $action == 84) {

    $v_numero = $_REQUEST['tel'];


    echo verifcar_numero($v_numero, $db);
    exit();
    // $header = "modules.php?mod=agentes&op=solicitudes_canceladas&e=5";
} elseif (isset($action) && $action == 85) { //Prescrining
    $u_persona = get_session_varname("id_solicitud");
    $u_user = get_session_varname("s_usr_id");
    $rs800 = get_datos_prescrining($u_persona, $db);
    if (!$rs800->EOF) {
        ?>
        <table class="indicadores">
            <tr class="indicadores">
                <th colspan="8" class="indicadores">Prescreening</th>
            </tr>
            <tr class="indicadores" style="background: #006666;">
                <td>Score</td>
                <td>Permisos Operacion</td>
                <td>Número de Consulta</td>
            </tr>
            <?php
            while (!$rs800->EOF) {
                ?>
                <tr class="indicadores">
                    <td><?php echo $rs800->fields['SCORE'] ?></td>
                    <td><?php echo $rs800->fields['PERMISO_OPERACION'] ?></td>
                    <td><?php echo $rs800->fields['NUM_CONSULTA'] == '' ? 1 : $rs800->fields['NUM_CONSULTA']; ?></td>
                </tr>
                <?php
                $rs800->MoveNext();
            }
            ?>
        </table>
        <?php
    } else {
        echo "No se ha actualizado";
    }
    die();
    exit();
}elseif (isset($action) && $action == 87) {
    $nombre = $_POST['nombre'];
    $apaterno = $_POST['ap_panterno'];
    $amaterno = $_POST['ap_materno'];
    $rfc = $_POST['rfc'];

    if($_POST['num_proceso'] == ''){
        $cp = NULL;
        $direccion = NULL;
        $ciudad = NULL;
    } else{
        $cp = $_POST['cp'];
        $direccion = $_POST['direccion']." ".$_POST['num_int'];
        $ciudad = $_POST['ciudad'];
    }

    $rfc = $_POST['rfc'];
    $u_user = get_session_varname("s_usr_id");

    echo set_prescrining(get_session_varname("id_solicitud"),$nombre,$apaterno,$amaterno,$rfc,$u_user,$cp,$direccion,$ciudad,$db);

    die();
} elseif (isset($action) && $action == 88) { ### Finaliza la Venta en caso de Converse, NYLIFE o Santander
    set_valida_solicitud(get_session_varname("id_solicitud"), get_session_varname("id_producto"), 2, 0, 1, $db);

    set_traking(get_session_varname("s_usr_id"), 'FINALIZAR VENTA', get_session_varname("s_usr_maquina"), '', '', $db);

    if (get_session_varname("id_producto") == 1) {
        $score = array(1, get_session_varname("id_solicitud"));
        set_session_varname("sc", $score);
    }
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("id_producto");
    unset_session_varname("CE");
    if ($isPredictivo == 2)
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    elseif ($isPredictivo == 1)
        $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(27);
}

elseif (isset($action) && $action == 89) {
    $nombre = $_POST['nombre'];
    $apaterno = $_POST['ap_panterno'];
    $amaterno = $_POST['ap_materno'];
    $rfc = $_POST['rfc'];

    if($_POST['num_proceso'] == ''){
        $cp = NULL;
        $direccion = NULL;
        $ciudad = NULL;
    } else{
        $cp = $_POST['cp'];
        $direccion = $_POST['direccion']." ".$_POST['num_int'];
        $ciudad = $_POST['ciudad'];
    }

    $rfc = $_POST['rfc'];
    $u_user = get_session_varname("s_usr_id");


    echo set_prescrining_(get_session_varname("id_solicitud"),$nombre,$apaterno,$amaterno,$rfc,$u_user,$cp,$direccion,$ciudad,$db);

    die();

} elseif(isset($action) && $action == 90){
    echo json_encode(get_actualizaciones(3, $nomina, $db));
    die();

} elseif(isset($action) && $action == 91){
    $id = $_POST['id'];
    echo marcar_leido($id, $nomina, $db);
    die();

} elseif(isset($action) && $action == 92){ //
    $calificacion = $_POST['respuestaSelect'];
    $solicitud = get_session_varname("id_solicitud");
        sms_calf_($nomina, $solicitud, $calificacion, $_POST['respuestaRazon'],$_POST['estado'], $db);
    echo json_encode(1);
    die();

} elseif(isset($action) && $action == 93){
    $u_user = get_session_varname("s_usr_id");
    $customerid = get_session_varname("id_solicitud");
    $folio = $_POST['folio'];
    $score = $_POST['score'];
    $intentos = $_POST['intentos'];

    $v_leyenda1 = isset($_POST['v_leyenda1'])? $_POST['v_leyenda1'] : 0;
    $v_leyenda2 = isset($_POST['v_leyenda2'])? $_POST['v_leyenda2'] : 0;
    $v_leyenda3 = isset($_POST['v_leyenda3'])? $_POST['v_leyenda3'] : 0;

    $rspta = guardarDatosAutenticacion($customerid, $u_user, $folio, $score, $intentos, $v_leyenda1, $v_leyenda2, $v_leyenda3,$db);

    echo json_encode($rspta);
    die();
}elseif(isset($action) && $action == 94){ //
    $calificacion= $_POST['calificacionCAPI'];
    $customerid = get_session_varname("id_solicitud");
    // echo $datoDani= $calificacion.'----'.$customerid;
    $rs = get_listElegible_face($calificacion,$db);

    if($rs->_array[0]['NUM'] > 0){
        // $ch = curl_init('172.20.1.95/sftpAmex/leads_Amex_Home/pruebas.php');
        $params = array(
            'solicitud'=>$customerid,
            "event" => 2);  //Eligible Lead
        $defaults = array(
            // CURLOPT_URL => '172.20.1.72/sftpAmex/leads_Amex_Home/pruebas.php',
            CURLOPT_URL => '172.20.1.95/api_fueralinea/main7.php',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true
        );
        $ch = curl_init();
        curl_setopt_array($ch, $defaults);
        $r = curl_exec($ch);
        var_dump($r);

    }else{
        echo 'no elegible';
    }
    die();
}elseif(isset($action) && $action == 95){ //Descripcion de las tarjetas del modal
    $tarjeta = get_descripcion_tarjeta($_REQUEST['tarjeta'],$db);
    echo json_encode($tarjeta->_array);
    die();
}elseif(isset($action) && $action == 96){ //MUESTRA PLANES SEGUN LAS POLIZAS

    $datos = get_tipo_seguro($_REQUEST['prod_value'],$db);   

    if (count($datos->_array) > 0) {
    for ($indice_datos_query_ = 0; $indice_datos_query_ < count($datos->_array); $indice_datos_query_++) {
        echo '<option value=' . $datos->_array[$indice_datos_query_]['VALOR'] . '>';
        echo special_chars($datos->_array[$indice_datos_query_]['TEXTO']);
        echo '</option>';    
        }
    }

    die();
}elseif(isset($action) && $action == 97){ //AGREGAR NOTA DE CANCELACION
    $solicitud = $_REQUEST['customer_id'] ?? '';
    $producto = $_REQUEST['survey_id'] ?? '';
    $valor = $_REQUEST['valor'] ?? '';
    $nota = $_REQUEST['nota'] ?? '';
    $pcn = $_REQUEST['pcn'] ?? '';

    $set_razonCalencacion = set_razon_cancelacion(intval($solicitud), intval($producto), intval($usr_id), intval($valor),$nota, $pcn, $db);
    die();
}elseif(isset($action) && $action == 98){ //NOTA DE CANCELACION
    $solicitud = $_REQUEST['customer_id'] ?? '';
    $get_razonCalencacion = get_razoncancelacionid(intval($solicitud), 1,  $db);
    echo $get_razonCalencacion;
    die();
}elseif(isset($action) && $action == 99){ //DUPLICIDAD DE PCN
    $datos = get_pcn_duplicado($_POST['pcn'],$_POST['customerid'],1 ,$db);
    echo $datos;
    die();
}elseif(isset($action) && $action == 100){
    //set_traking($usr_id, 'NOTA CANCELACION', get_session_varname("s_usr_maquina"), get_session_varname("id_solicitud"), '', $db);
    unset_session_varname("calificados");
	unset_session_varname("url_contacto");
	unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_producto");
    unset_session_varname("id_registro");
    unset_session_varname("log_registro");
    unset_session_varname("tipo_standby");

    $header = "modules.php?mod=agentes&op=process_data&act=" . encripta(1);
    
}elseif(isset($action) && $action == 101){
    set_XSP_SETAUTENTICO_local(get_session_varname("id_solicitud"),$_POST['PCN'],$_POST['rs'],$db);
    die();
}elseif(isset($action) && $action == 102){ //TRAER RESPUESTAS DE SURVEYREPONSE
    $solicitud = get_session_varname("id_solicitud");
    $id_producto = $_POST['surveyId'];

    $data = buscar_respuestas($solicitud, $id_producto, $db);
    echo $data;
    die();
}elseif(isset($action) && $action == 103){ //VALIDA PRODUCTOS PROCESADOS
    $get_procesada = get_procesada($_POST['id_solicitud'], 1, $db);
    echo $get_procesada;
    die();
}elseif(isset($action) && $action == 104){ //OBTENER RESULTADO DE SOLICITUD PARA MOSTRAR/OCULTAR BOTONES
    $solicitud = get_session_varname("id_solicitud");

    $get_resultado= get_procesada($solicitud, 2, $db);
    echo $get_resultado;
    die();
}elseif(isset($action) && $action == 105){ //ABANDONAR REGISTRO SIN CAQLIFICAR
    $header = "index2.php"; # REEENVIA AL INDEX DE LA APLICACION

    unset_session_varname('log_registro');
    unset_session_varname("datos_persona");
    unset_session_varname("id_solicitud");
    unset_session_varname("id_registro");
    unset_session_varname("agenda");
    unset_session_varname("CE");
    unset_session_varname("caltelefono0");
    unset_session_varname("caltelefono1");
    unset_session_varname("caltelefono2");
    unset_session_varname("caltelefono3");
    unset_session_varname("caltelefono4");
    unset_session_varname("caltelefono5");
}elseif(isset($action) && $action == 106){ // Consulta de ventas por agente 
    $ventasAgentes = getventas($usr_id, $db);
    echo json_encode($ventasAgentes);
    die();
}

header("Location:" . $header);




