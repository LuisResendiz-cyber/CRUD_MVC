<?php
/*
function darSaludo() {
    $iHora = date('H');

    if ($iHora >= 0 && $iHora < 12) {
        $sSaludo = "Buenos d&iacute;as";
    } else if ($iHora >= 12 && $iHora <= 19) {
        $sSaludo = "Buenas tardes";
    } else {
        $sSaludo = "Buenas noches";
    }

    return $sSaludo;
}
*/
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agentes", "Script");
ini_set("session.gc_maxlifetime", (60 * 60) * 8); // 60 minutos
/*
$u_persona = $_SESSION['datos_persona'][0]['U_PERSONA'];
$nombre = $_SESSION['s_usr_nombre'];
echo "<pre>";
 $productos_ = get_productos_campana($u_persona, $db);
echo "</pre>";
$datos = get_datos_query2('XSP_GETDATOSCLIENTE('.$u_persona.',:rc)',$db);

if (isset($_POST['cmdCalcular'])) {
    if ($_POST['compras'] != null){
        $rs = get_simulador($_POST['compras'], $_POST['tasa'], $_POST['periodo'], get_session_varname("s_usr_id"), $db);
    }else{
        $mensaje = "debes ingresar el monto de compra";
    }
}
*/
/*echo "<pre>";
print_r($rs);
echo "</pre>";*/

$conceptos = Array(
    "Prima Neta Total",
    "Prima Asistencia",
    "Descuento Especial",
    "R.P.F.",
    "Derecho Poliza",
    "IVA",
    "Prima Total",
    "Prima 1er Recibo",
    "Pagos subsecuentes",
    "R.F.P.",
    "I.V.A."
);

?>
<!-- <script language="JavaScript" src="includes/js/jquery-1.9.1.js"></script> -->

<form name="frmSimulador" id="frmSimulador" method="post" action="modules.php?mod=agentes&op=Script_simulador">
<div style="display:flex">    
    <img src="/sicall/hsbc/includes/imgs/logo_campana.png" class="valignmiddle" STYLE="padding: 32px;">
    
<table>
<tr>
	<td>Fecha de la cotizaci&oacute;n</td>
     <td><?=date("d/m/Y")?></td>
	<td>Tarifa A.M.</td>
     <td><input type="text" name="G6" id="G6" value="66" readonly /></td>     
</tr>
<tr>
	<td>Forma de Pago</td>
     <td>
         <select name="D7" id="D7">
             <option value="12">Mensual</option>
             <option value="4">Trimestral</option>
             <option value="2">Semestral</option>
             <option value="1">Anual</option>
         </select>
     </td>
	<td>A.M. X F.P.</td>
     <td><input type="text" name="G7" id="G7" value="5.5" readonly /></td>     
</tr>
<tr>
	<td>Descuentos</td>
     <td>
         <select name="D8" id="D8">
             <option value="0">Ninguno</option>
             <option value="10">Advance</option>
             <option value="20">Empleado</option>
             <option value="20">Premier</option>
         </select>
     </td>
	<td>Aplicable</td>
     <td><input type="text" name="G8" id="G8" value="0" readonly />%</td>     
</tr>
</table>
    <H1 style="padding: 32px;">SIMULADOR HOSPITAL CASH</h1>
</div>
<div style="display:flex">    
<table cellspacing="0" border="0" style="width:35%;">
	<colgroup span="7" width="85"></colgroup>
	<tr>
		<td colspan=3 height="17" align="right" sdval="1" sdnum="2058;">Fecha Nac.</td>
		<td align="right" sdval="2" sdnum="2058;">Sexo</td>
		<td align="right" sdval="3" sdnum="2058;">Edad</td>
		<td colspan=2 align="right" sdval="4" sdnum="2058;">Tarifas</td>
		</tr>
	<tr>
        <td></td>
		<td height="17" align="right" sdval="5" sdnum="2058;">Titular</td>
        <td align="right" sdval="6" sdnum="2058;"><input type="text" name="D14" id="D14" /></td>
        <td align="right" sdval="7" sdnum="2058;">
            <select name="E14" id="E14">
                <option value="0">M</option>
                <option value="1">F</option>
            </select>              
        </td>
		<td align="right" sdval="8" sdnum="2058;"><input type="text" name="F14" id="F14" value="" readonly /></td>
		<td align="right" sdval="9" sdnum="2058;">$<input type="text" name="G14" id="G14" value="0" readonly /></td>
          <td align="right" sdval="9" sdnum="2058;">$<input type="text" name="H14" id="H14" value="0" readonly /></td>
	</tr>
	<tr>
		<td rowspan=8 height="137" align="right" sdval="10" sdnum="2058;">Dependientes</td>
		<td align="right">1</td>
		<td align="right" sdval="6" sdnum="2058;"><input type="text" name="D15" id="D15" /></td>
          <td align="right">
            <select name="E15" id="E15">
                <option value="0">M</option>
                <option value="1">F</option>
            </select>                            
          </td>
		<td align="right" sdval="8" sdnum="2058;"><input type="text" name="F15" id="F15" value="" readonly /></td>
		<td align="right" sdval="9" sdnum="2058;">$<input type="text" name="G15" id="G15" value="0" readonly /></td>
          <td align="right" sdval="9" sdnum="2058;">$<input type="text" name="H15" id="H15" value="0" readonly /></td>
	</tr>
<?php
    for($i = 2; $i <= 8; $i++) {
?>
	<tr>
		<td align="right"><?=$i?></td>
		<td align="right" sdval="6" sdnum="2058;"><input type="text" name="D<?=$i+14?>" id="D<?=$i+14?>" /></td>
          <td align="right">
            <select name="E<?=$i+14?>" id="E<?=$i+14?>">
                <option value="0">M</option>
                <option value="1">F</option>
            </select>                            
          </td>
		<td align="right" sdval="8" sdnum="2058;"><input type="text" name="F<?=$i+14?>" id="F<?=$i+14?>" value="" readonly /></td>
		<td align="right" sdval="9" sdnum="2058;">$<input type="text" name="G<?=$i+14?>" id="G<?=$i+14?>" value="0" readonly /></td>
          <td align="right" sdval="9" sdnum="2058;">$<input type="text" name="H<?=$i+14?>" id="H<?=$i+14?>" value="0" readonly /></td>
	</tr>
<?php
    }
?>     
</table>

<?php
    for($k = 0; $k <= 13; $k+=13) {
?>

<table cellspacing="0" border="0" id="tabla<?=$k?>" style="width:30%">
    <tr>
        <td><?=($k == 0) ? "Monto Prima por Forma de Pago" : "Monto Prima Anual"?></td>
        <td>$<input type="text" name="L12" id="L12" value="1000" readonly /></td>
        <td>$<input type="text" name="N12" id="N12" value="2000" readonly /></td>
        <td>$<input type="text" name="P12" id="P12" value="3000" readonly /></td>
    </tr>
<?php
    foreach($conceptos as $name => $value) {
?>
    <tr>
        <td><?=$value?></td>
        <td><?=($name < 9) ? "$" : ""?><input type="text" name="L<?=($name+$k+14)?>" id="L<?=($name+$k+14)?>" value="0" readonly /><?=($name >= 9) ? "%" : ""?></td>
        <td><?=($name < 9) ? "$" : ""?><input type="text" name="N<?=($name+$k+14)?>" id="N<?=($name+$k+14)?>" value="0" readonly /><?=($name >= 9) ? "%" : ""?></td>
        <td><?=($name < 9) ? "$" : ""?><input type="text" name="P<?=($name+$k+14)?>" id="P<?=($name+$k+14)?>" value="0" readonly /><?=($name >= 9) ? "%" : ""?></td>
    </tr>
<?php
    }
?>
</table>

<?php
    }
?>
    </div>
</form>
<script>
function reinicializacion() {
    $("#L18, #N18, #P18").val(parseFloat(derecho_poliza / $("#D7").val())/*.toFixed(2)*/);

    var suma_primas = parseFloat($("#H14").val())+parseFloat($("#H15").val())+parseFloat($("#H16").val())+parseFloat($("#H17").val())+parseFloat($("#H18").val())+parseFloat($("#H19").val())+parseFloat($("#H20").val())+parseFloat($("#H21").val())+parseFloat($("#H22").val());
    $("#L14").val(($("#L12").val() / 1000 * suma_primas)/*.toFixed(2)*/);
    $("#N14").val(($("#N12").val() / 1000 * suma_primas)/*.toFixed(2)*/);
    $("#P14").val(($("#P12").val() / 1000 * suma_primas)/*.toFixed(2)*/);

    var suma_asistencias = parseFloat($("#G14").val())+parseFloat($("#G15").val())+parseFloat($("#G16").val())+parseFloat($("#G17").val())+parseFloat($("#G18").val())+parseFloat($("#G19").val())+parseFloat($("#G20").val())+parseFloat($("#G21").val())+parseFloat($("#G22").val());
    $("#L15, #N15, #P15").val(suma_asistencias);
    
    $("#L16").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#L14").val()) + parseFloat($("#L15").val())))/*.toFixed(2)*/);
    $("#N16").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#N14").val()) + parseFloat($("#N15").val())))/*.toFixed(2)*/);
    $("#P16").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#P14").val()) + parseFloat($("#P15").val())))/*.toFixed(2)*/);

    var factor = 0;    
    if($("#D7").val() == "1") {
        factor = 0;
    } else if($("#D7").val() == "2") {
        factor = 9.57;
    } else if($("#D7").val() == "4") {
        factor = 11.42;
    } else if($("#D7").val() == "12") {
        factor = 12.68;
    }
    $("#L23, #N23, #P23").val(factor);

    $("#L17").val((parseFloat($("#L23").val()) / 100 * (parseFloat($("#L14").val()) + parseFloat($("#L15").val()) - parseFloat($("#L16").val())))/*.toFixed(2)*/);
    $("#N17").val((parseFloat($("#N23").val()) / 100 * (parseFloat($("#N14").val()) + parseFloat($("#N15").val()) - parseFloat($("#N16").val())))/*.toFixed(2)*/);
    $("#P17").val((parseFloat($("#P23").val()) / 100 * (parseFloat($("#P14").val()) + parseFloat($("#P15").val()) - parseFloat($("#P16").val())))/*.toFixed(2)*/);        

    if($("#D7").val() == "1") {
        $("#L17, #N17, #P17").val(0);
    } else {
        $("#L17").val((parseFloat($("#L23").val()) / 100 * (parseFloat($("#L14").val()) + parseFloat($("#L15").val()) - parseFloat($("#L16").val())))/*.toFixed(2)*/);
        $("#N17").val((parseFloat($("#N23").val()) / 100 * (parseFloat($("#N14").val()) + parseFloat($("#N15").val()) - parseFloat($("#N16").val())))/*.toFixed(2)*/);
        $("#P17").val((parseFloat($("#P23").val()) / 100 * (parseFloat($("#P14").val()) + parseFloat($("#P15").val()) - parseFloat($("#P16").val())))/*.toFixed(2)*/);        
    }
    
    $("#L19").val(parseFloat($("#L24").val() / 100 * (parseFloat($("#L14").val())+parseFloat($("#L15").val())+parseFloat($("#L17").val())+parseFloat($("#L18").val())-parseFloat($("#L16").val())))/*.toFixed(2)*/);
    $("#N19").val(parseFloat($("#N24").val() / 100 * (parseFloat($("#N14").val())+parseFloat($("#N15").val())+parseFloat($("#N17").val())+parseFloat($("#N18").val())-parseFloat($("#N16").val())))/*.toFixed(2)*/);
    $("#P19").val(parseFloat($("#P24").val() / 100 * (parseFloat($("#P14").val())+parseFloat($("#P15").val())+parseFloat($("#P17").val())+parseFloat($("#P18").val())-parseFloat($("#P16").val())))/*.toFixed(2)*/);    
    $("#L20, #L21, #L22").val((parseFloat($("#L14").val()) + parseFloat($("#L15").val()) + parseFloat($("#L17").val()) + parseFloat($("#L18").val()) + parseFloat($("#L19").val()) - parseFloat($("#L16").val()))/*.toFixed(2)*/);
    $("#N20, #N21, #N22").val((parseFloat($("#N14").val()) + parseFloat($("#N15").val()) + parseFloat($("#N17").val()) + parseFloat($("#N18").val()) + parseFloat($("#N19").val()) - parseFloat($("#N16").val()))/*.toFixed(2)*/);
    $("#P20, #P21, #P22").val((parseFloat($("#P14").val()) + parseFloat($("#P15").val()) + parseFloat($("#P17").val()) + parseFloat($("#P18").val()) + parseFloat($("#P19").val()) - parseFloat($("#P16").val()))/*.toFixed(2)*/);

/*    
    for(j=14; j<=24; j++){
        $("#L"+(j+13)).val($("#L"+(j+0)).val());
        $("#N"+(j+13)).val($("#N"+(j+0)).val());
        $("#P"+(j+13)).val($("#P"+(j+0)).val());
    }
*/
    
//    $( "input[type=text]" ).each(function(){
//       $(this).val( (Math.round(   $( this ).val() * 100) / 100).toFixed(2)      );
//    });

    calcular_anual();

    $('input[type="text"]').each(function(){
        if(this.name != "D14" && this.name != "D15" && this.name != "D16" && this.name != "D17" && this.name != "D18" && this.name != "D19" && this.name != "D20" && this.name != "D21" && this.name != "D22") {
            let val = $(this).val();
            $(this).val(Math.round(val * 100) / 100);
        }
    });
    ceros_derecha();
}
function calcular_anual(){
    $("#L31, #N31, #P31").val(parseFloat(derecho_poliza / 1/**/)/*.toFixed(2)*/);

   var suma_primas = ($("#D7").val()) * (parseFloat($("#H14").val())+parseFloat($("#H15").val())+parseFloat($("#H16").val())+parseFloat($("#H17").val())+parseFloat($("#H18").val())+parseFloat($("#H19").val())+parseFloat($("#H20").val())+parseFloat($("#H21").val())+parseFloat($("#H22").val()));
    $("#L27").val(($("#L12").val() / 1000 * suma_primas)/*.toFixed(2)*/);
    $("#N27").val(($("#N12").val() / 1000 * suma_primas)/*.toFixed(2)*/);
    $("#P27").val(($("#P12").val() / 1000 * suma_primas)/*.toFixed(2)*/);

   var suma_asistencias = ($("#D7").val()) * (parseFloat($("#G14").val())+parseFloat($("#G15").val())+parseFloat($("#G16").val())+parseFloat($("#G17").val())+parseFloat($("#G18").val())+parseFloat($("#G19").val())+parseFloat($("#G20").val())+parseFloat($("#G21").val())+parseFloat($("#G22").val()));
    $("#L28, #N28, #P28").val(suma_asistencias);
    
    $("#L29").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#L27").val()) + parseFloat($("#L28").val())))/*.toFixed(2)*/);
    $("#N29").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#N27").val()) + parseFloat($("#N28").val())))/*.toFixed(2)*/);
    $("#P29").val((parseFloat($("#G8").val()) / 100 * (parseFloat($("#P27").val()) + parseFloat($("#P28").val())))/*.toFixed(2)*/);

    var factor = 0;    
    if($("#D7").val() == "1") {
        factor = 0;
    } else if($("#D7").val() == "2") {
        factor = 9.57;
    } else if($("#D7").val() == "4") {
        factor = 11.42;
    } else if($("#D7").val() == "12") {
        factor = 12.68;
    }
    $("#L36, #N36, #P36").val(factor);

    $("#L30").val((parseFloat($("#L36").val()) / 100 * (parseFloat($("#L27").val()) + parseFloat($("#L28").val()) - parseFloat($("#L29").val())))/*.toFixed(2)*/);
    $("#N30").val((parseFloat($("#N36").val()) / 100 * (parseFloat($("#N27").val()) + parseFloat($("#N28").val()) - parseFloat($("#N29").val())))/*.toFixed(2)*/);
    $("#P30").val((parseFloat($("#P36").val()) / 100 * (parseFloat($("#P27").val()) + parseFloat($("#P28").val()) - parseFloat($("#P29").val())))/*.toFixed(2)*/);        

    if($("#D7").val() == "1") {
        $("#L30, #N30, #P30").val(0);
    } else {
        $("#L30").val((parseFloat($("#L36").val()) / 100 * (parseFloat($("#L27").val()) + parseFloat($("#L28").val()) - parseFloat($("#L29").val())))/*.toFixed(2)*/);
        $("#N30").val((parseFloat($("#N36").val()) / 100 * (parseFloat($("#N27").val()) + parseFloat($("#N28").val()) - parseFloat($("#N29").val())))/*.toFixed(2)*/);
        $("#P30").val((parseFloat($("#P36").val()) / 100 * (parseFloat($("#P27").val()) + parseFloat($("#P28").val()) - parseFloat($("#P29").val())))/*.toFixed(2)*/);        
    }
    
    $("#L32").val(parseFloat($("#D7").val() * $("#L37").val() / 100 * (parseFloat($("#L14").val())+parseFloat($("#L15").val())+parseFloat($("#L17").val())+parseFloat($("#L18").val())-parseFloat($("#L16").val())))/*.toFixed(2)*/);
    $("#N32").val(parseFloat($("#D7").val() * $("#N37").val() / 100 * (parseFloat($("#N14").val())+parseFloat($("#N15").val())+parseFloat($("#N17").val())+parseFloat($("#N18").val())-parseFloat($("#N16").val())))/*.toFixed(2)*/);
    $("#P32").val(parseFloat($("#D7").val() * $("#P37").val() / 100 * (parseFloat($("#P14").val())+parseFloat($("#P15").val())+parseFloat($("#P17").val())+parseFloat($("#P18").val())-parseFloat($("#P16").val())))/*.toFixed(2)*/);    
    $("#L33").val((parseFloat($("#L27").val()) + parseFloat($("#L28").val()) + parseFloat($("#L30").val()) + parseFloat($("#L31").val()) + parseFloat($("#L32").val()) - parseFloat($("#L29").val()))/*.toFixed(2)*/);
    $("#N33").val((parseFloat($("#N27").val()) + parseFloat($("#N28").val()) + parseFloat($("#N30").val()) + parseFloat($("#N31").val()) + parseFloat($("#N32").val()) - parseFloat($("#N29").val()))/*.toFixed(2)*/);
    $("#P33").val((parseFloat($("#P27").val()) + parseFloat($("#P28").val()) + parseFloat($("#P30").val()) + parseFloat($("#P31").val()) + parseFloat($("#P32").val()) - parseFloat($("#P29").val()))/*.toFixed(2)*/);

    $("#L34").val($("#L21").val());
    $("#N34").val($("#N21").val());
    $("#P34").val($("#P21").val());

    $("#L35").val($("#L22").val());
    $("#N35").val($("#N22").val());
    $("#P35").val($("#P22").val());
        
}
    
//$("#tabla13").hide();

var derecho_poliza = 77;
var factor = 12.68;
var iva = 16;
$("#L23, #N23, #P23", "#L36, #N36, #P36").val(factor);
$("#L24, #N24, #P24, #L37, #N37, #P37").val(iva);
//$("#L36, #N36, #P36").val(0);

reinicializacion();

var items = [
    [381.95, 358.52],
    [381.34, 357.95],
    [387.62, 363.84],
    [384.42, 360.84],
    [290.37, 272.56],
    [291.12, 273.27],
    [291.26, 273.4],
    [290.94, 273.1],
    [286.77, 269.18],
    [292.5, 274.56],
    [289.06, 271.33],
    [291.68, 273.79],
    [292.3, 274.37],
    [294.06, 276.03],
    [163.94, 153.88],
    [165.56, 155.41],
    [167.93, 157.63],
    [166.63, 156.41],
    [162.69, 152.71],
    [242.79, 227.9],
    [247.3, 232.13],
    [249.97, 234.64],
    [249.09, 233.82],
    [250.99, 235.59],
    [253.71, 238.15],
    [257.41, 241.62],
    [306.93, 288.11],
    [298.44, 280.13],
    [297.92, 279.65],
    [300.18, 281.77],
    [303.99, 285.35],
    [339.53, 318.71],
    [346.47, 325.22],
    [333.35, 312.91],
    [336.76, 316.11],
    [342.72, 321.7],
    [347.08, 325.8],
    [339.56, 318.74],
    [336.48, 315.85],
    [342.32, 321.33],
    [351.93, 330.35],
    [851.17, 798.97],
    [839.31, 787.83],
    [876.44, 822.68],
    [887.31, 832.89],
    [891.89, 837.18],
    [931.71, 874.56],
    [908.7, 852.97],
    [930.88, 873.78],
    [923.29, 866.66],
    [957.68, 898.94],
    [1052.2, 987.67],
    [1054.52, 989.84],
    [1053.92, 989.28],
    [1081.92, 1015.57],
    [1099.25, 1031.83],
    [1074.15, 1008.27],
    [1093.65, 1026.58],
    [1115.79, 1047.35],
    [1066.97, 1001.54],
    [1098.43, 1031.06],
    [1034.06, 970.64],
    [1030.79, 967.57],
    [1026.31, 963.36],
    [1023.93, 961.13],
    [1023.93, 961.13]    
];

//ESTILOS
$( "input[type=text]" ).attr('size', '4');
$( "#D14, #D15, #D16, #D17, #D18, #D19, #D20, #D21, #D22" ).attr('size', '10');
$( "table" ).css('border', 'red solid 1px');
$( "tr:first-child" ).css('background-color', '#9f9f9f');


$('table').each(function(){
    $(this).find('tbody tr:first').css({'background-color':'#c2c2c2'});
    $(this).find('tbody tr td').css({'vertical-align':'middle', 'padding':'.3rem'});
});

var tablas = [0,13];
for(var i=0; i<tablas.length; i++){
    $('#tabla'+tablas[i]+' tbody tr').each(function(index){
            if(index == 8 || index == 9){
                $(this).find('td').css('background-color','rgba(222,0,0,0.5)');
            }
    });
}

$( "#D14, #D15, #D16, #D17, #D18, #D19, #D20, #D21, #D22" ).change( function (){
    calcular_edad(this);
});

$( "#D7, #D8, #D14, #D15, #D16, #D17, #D18, #D19, #D20, #D21, #D22, #E14, #E15, #E16, #E17, #E18, #E19, #E20, #E21, #E22" ).change( function (){
    calcular();
});

$('table').each(function(indexT){
    if(indexT == 1){
        $(this).find('tbody tr').each(function(indexTr){
            var indexTd;
            // convertir en datepicker
            if(indexTr>0 && indexTr<3){
                indexTd = 2;
            } else{
                indexTd = 1;
            }

            $(this).find('td:eq('+indexTd+')').find('input').datepicker({
                dateFormat:'dd/mm/yy' 
            });
            
            // delinear titular y dependientes
            if(indexTr == 1){
                $(this).find('td:eq(0)').css({'border-top':'1px solid #de0000', 'border-bottom':'1px solid #de0000'});
                $(this).find('td:eq(1)').css({'border-top':'1px solid #de0000', 'border-bottom':'1px solid #de0000', 'border-right':'1px solid #de0000'});
            }
            if(indexTr == 2){
                $(this).find('td:eq(0)').css({'border':'1px solid #de0000'});
                $(this).find('td:eq(1)').css({'width':'1%', 'border-right':'1px solid #de0000'});
            }
            if(indexTr > 2){
                $(this).find('td:eq(0)').css({'width':'1%', 'border-right':'1px solid #de0000'});
            }
        });
    }
});


$('#tabla13 input[type="text"]').css('width','62px');
$('#tabla0 input[type="text"]').css('width','62px');



function calcular() {
//    alert("calculando....");
    $("#G7").val($("#G6").val() / $("#D7").val());
    for(i = 14; i <= 22; i++) if($("#G"+i).val() != "0") $("#G"+i).val($("#G6").val() / $("#D7").val());
    $("#G8").val($("#D8").val());
    for(i = 14; i <= 22; i++) if($("#G"+i).val() != "0") $("#H"+i).val(parseFloat(items[$("#F"+i).val()][$("#E"+i).val()] / $("#D7").val())/*.toFixed(2)*/);
    
    reinicializacion();
    
}

function calcular_edad(campo) {
    var posicion = campo.name.substring(1);
//    var fn = campo.value.split("-").join(""); //CON DATE
    var fn = campo.value.split("/").reverse().join("");   //CON TEXT
    //console.log(fn);
    var today  = new Date();
    var hoy = today.getFullYear() + "" + (today.getMonth() + 1).toString().padStart(2, "0") + "" + today.getDate().toString().padStart(2, "0");
    //console.log(hoy);
    var edad = parseInt((parseInt(hoy) - parseInt(fn)) / 10000);
    if(campo.value == "") {
        $("#F"+posicion).val("");
        $("#G"+posicion).val("0");
        $("#H"+posicion).val("0");
    } else {
        $("#F"+posicion).val(edad);
        $("#G"+posicion).val($("#G7").val());
//        $("#H"+posicion).val($("#G7").val());
    }
    
    reinicializacion();
}

function ceros_derecha(){
    let inputs = document.querySelectorAll('input[type=text]');
    let valor = '';

    for(let input in inputs){
        valor = inputs[input].value;

        if(valor !== undefined && valor.indexOf('.') > -1){
            let separar = valor.split('.');
            
            if(separar[1].length == 1){
                let nuevo_valor = separar[0] + '.' + separar[1] + '0';
                inputs[input].value = nuevo_valor;  
            }
        }
    }
}

</script>