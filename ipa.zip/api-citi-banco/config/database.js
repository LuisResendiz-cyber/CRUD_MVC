
//desarrollo
// var HR_USER = 'CITIBANCOAPP';
// var HR_PASSWORD = 'HeR_7o36Uj15';
// var HR_CONNECTIONSTRING = '172.20.1.116'; 

//PRODUCCION
var HR_USER = 'CITIBANCOAPP';
var HR_PASSWORD = 'HeR_7o36Uj15';
var HR_CONNECTIONSTRING = '192.168.1.14/XCCMTAF';

 

// var HR_CONNECTIONSTRING = `(DESCRIPTION =
//                     (LOAD_BALANCE = ON)
//                         (ADDRESS_LIST =
//                         (ADDRESS =
//                         (PROTOCOL = TCP)
//                         (HOST = 192.168.1.14)
//                         (PORT = 1521))
//                     (ADDRESS =
//                         (PROTOCOL = TCP)
//                         (HOST = 192.168.1.13)
//                         (PORT = 1521)
//                     ))
//                     (CONNECT_DATA =
//                         (SERVICE_NAME = xccmtaf)
//                     ))`;

// var HR_CONNECTIONSTRING = `
//                     (DESCRIPTION=
//                     	(LOAD_BALANCE=ON)
//                     	(
//                     		ADDRESS=(PROTOCOL=TCP)
//                     		(HOST=192.168.1.14)
//                     		(PORT=1521)
//                     	)
//                     	(CONNECT_DATA=
//                     		(SERVICE_NAME=xccmtaf)
//                     		(CID=
//                     			(PROGRAM=httpd)
//                     			(HOST=greko)
//                     			(USER=apache)
//                     		)
//                     	)
//                     )`;

module.exports = {
  hrPool: {
    user: HR_USER,// process.env.HR_USER,
    password: HR_PASSWORD,// process.env.HR_PASSWORD,
    connectString: HR_CONNECTIONSTRING,// process.env.HR_CONNECTIONSTRING,
    poolMin: 10,
    poolMax: 10,
    poolIncrement: 0
  }
};
