const { createLogger, format, transports, config } = require("winston");

const loggerError =  createLogger({
        levels: config.syslog.levels,
        format: format.combine(
            format.align(),
            format.timestamp({
                format: "YYYY-MM-DD HH:mm:ss"
            })
        ),
        transports: [
            new transports.File({
                name: 'error',
                maxsize: 5120000,
                maxFiles: 5,
                filename: './logs/error.log',
                format: format.combine(
                    format.printf(info => `${info.timestamp} ${info.level}: ${[info.message]}`)
                )
            })
        ]
    })
    module.exports = loggerError
