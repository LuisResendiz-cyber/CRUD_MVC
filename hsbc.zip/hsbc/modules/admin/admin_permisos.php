<?php
//ini_set("display_errors",1);
# @uthor Mark 
# admin_usuarios File

require_once("includes/includes.inc.php");
require_once("admin.inc.php");

initialize("administrador","ABC Usuarios",$db);
get_menu($db, "");

$nombre = ($_REQUEST['nombre']!=""?$_REQUEST['nombre']:"");
$paterno = ($_REQUEST['paterno']!=""?" ".$_REQUEST['paterno']:"");
$materno = ($_REQUEST['materno']!=""?" ".$_REQUEST['materno']:"");
$id_usuario = ($_REQUEST['id_usuario']!=""?$_REQUEST['id_usuario']:-1);
?>	
<h4>Usuarios Activos</h4>
<p id="text">D&eacute; click sobre el nombre de un usuario para mostrar las campa&ntilde;as activas</p>
<br>
<form method="post" action="modules.php?mod=admin&op=edita_usuario" name="frm2">
    <input type="hidden" name="idSelected" id="idSelected">
    <table border="0">
        <tr bgcolor="gray" style="font-weight:bold;">
            <td align="center">Reg. #</td>
            <td>&nbsp;</td>
            <td>Nombre</td>
            <td>&nbsp;</td>
            <td align="center">Id usuario&nbsp;&nbsp;&nbsp;</td>
        </tr>
        <?
        $d = 1;
        $usuarios = get_busqueda_usuarios($nombre.$paterno.$materno, $id_usuario,$db);

        while(!$usuarios->EOF) {
            echo '<tr>
                    <td>'.$d.'</td>
                    <td>&nbsp;</td>
                    <td><a href="#" onclick="select_campanas_user(this,'.$usuarios->fields["IUSR_ID"].')" class="textlink">'.$usuarios->fields["VNOMBRE"].'</a>&nbsp;&nbsp;&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>'.$usuarios->fields["IUSR_ID"].'</td>
                </tr>';
            $usuarios->MoveNext();
            $d++;
        }
        ?>
        <tr>
            <td colspan="5">&nbsp;</td>
        </tr><tr>
            <td colspan="5"><div id="resp_act" style="display:none"></div></td>
        </tr>
    </table>
    <br>
    </form>
<?
get_footer();
?>