// const conexion = require('../services/database_mysql.js');
module.exports = {
    obtenerToken(usuario_id){
     return new Promise((resolve, reject) => {
      conexion.query(`select token from usuarios_tokens where usuario_id = ?`,
        [usuario_id],
        (err, resultados,rows) => {
          if (err) {            
            reject(err);
          }else {
            // console.log(resultados.length);
            if(resultados.length > 0){
              resolve(resultados[0].token);
            }else{
              //console.log("entro 1")
              reject();
            }            
          }
        }
      );
    });
  },
  insertarUsuario(usuario_id,token){
    return new Promise((resolve, reject) => {
      conexion.query(`insert into usuarios_tokens values (?,?)`,
        [usuario_id,token],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados, "\n");
            resolve(resultados[0]);
          }
        }
      );
    });
  },
  updateUsuario(usuario_id,token){
    return new Promise((resolve, reject) => {
      conexion.query(`update usuarios_tokens set token= ? where usuario_id = ?`,
        [token,usuario_id],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados, "\n");
            resolve(resultados[0]);
          }
        }
      );
    });
  }
}