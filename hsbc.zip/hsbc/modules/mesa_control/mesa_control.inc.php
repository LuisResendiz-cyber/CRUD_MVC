<?php
# DEVULEVE EL REPORTE DE PRODUCTIVIDAD
function get_layout_clientes($fecha_del, $fecha_al, $etapa_layout, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_LAYOUT('".$fecha_del."','".$fecha_al."', ".$etapa_layout.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA
function get_catalogo($v_id_campo, $db){
	$rs = $db->ExecuteCursor("BEGIN spS_Catalogo('".$v_id_campo."',:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

#MUESTRA LAS ZONAS POR USUARIO
function get_detalle_zonas($id_usuario, $action, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_DETALLEZONAS(".$id_usuario.",".$action.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

function set_asigna_zona($izona, $iusr_id, $calificacion, $db){
	$stmt = $db->PrepareSP("BEGIN SPS_ASIGNAZONAS(:p_izona, :p_iusr_id, :p_calificacion, :v_actualizado); END;");
	$db->InParameter($stmt, $izona, 'p_izona');
	$db->InParameter($stmt, $iusr_id, 'p_iusr_id');	
	$db->InParameter($stmt, $calificacion, 'p_calificacion');
	$db->OutParameter($stmt, $v_capturado, 'v_actualizado');
	$db->Execute($stmt);
	
	return $v_capturado;
}

function set_activa_zona($izona, $calificacion, $db){
	
	$stmt = $db->PrepareSP("BEGIN SPU_ACTIVAZONAS(:p_izona, :p_calificacion, :v_actualizado); END;");
	$db->InParameter($stmt, $izona, 'p_izona');
	$db->InParameter($stmt, $calificacion, 'p_calificacion');
	$db->OutParameter($stmt, $v_capturado, 'v_actualizado');
	$db->Execute($stmt);
	
	return $v_capturado;
}

## ELIMINA LOS REGISTROS QUE SE ENCUENTRAN EN LA TABLA DE FOLIOS_CAMPANA
function delete_from_folios_campana($db){
	$sql = "DELETE FROM TD_FOLIO_CAMPANAS";
	if ($db->Execute($sql) === false)
		return false;
	else
		return true;
}

## CARGA EL CONTENIDO DEL ARCHIVO EN BASE DE DATOS
function set_data_folios_camapana(){
	$arhivo = realpath(set_ctl_file('_lx'));
	$path = realpath('modules/mesa_control/carga_datos_ccupdate.sh');
	//echo shell_exec('ls -l');
	$comando = 'sh '.$path;
	$salida = shell_exec($comando);
	//echo "<pre>$salida</pre>";
	//die();
}

## ARMA EL ARCHIVO CTL
function set_ctl_file($sys){
	$ctl_file = 'modules/mesa_control/load_data_ccupdate'.$sys.'.ctl';
	$path_file =  realpath('modules/mesa_control');
	$content = "LOAD DATA\nINFILE '".$path_file."/archivo_carga_full_ccupdate.txt'\nINTO TABLE td_folio_campanas\nAPPEND\nFIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED '\"'\n(FOLIO_CAMPANA,STATUS)";
	$file_handle = fopen($ctl_file, 'w') or die("No se pudo abrir el archivo");
	fwrite($file_handle, $content);
	fclose($file_handle);

	return $ctl_file;
}

## TRAE LOS DATOS DE ACUERDO AL ARCHIVO CARGADO
function get_data_by_file($db){
	$rs = $db->ExecuteCursor("BEGIN CSP_GETDATOSPORARCHIVO(1,:rc); END;", "rc");
	$db->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

## CLASIFICA LOS REGISTROS QUE SE CARGARON AL SISTEMA
function set_data_clasification($key, $db){

	$cantidad = 0;
	$rs = $db->ExecuteCursor("BEGIN CSP_SETDATACLASIFICATION(".$key.",:rc); END;", "rc");
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	$cantidad = $rs->fields["REMESA"];

	return $cantidad;
}

## DEVUELVE EL REPORTE DE LA CARGA
function get_rerporte_carga($ky, $db){
	$rs = $db->ExecuteCursor("BEGIN CSP_GETREPORTE_CARGA_BANCO(".$ky.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);

	return $rs;
}

?>
