// $(document).ready(function(){
//   $(document).on('click', '.btn', function(e){
//     $(this).toggleClass("active");
//     console.log("click js/funcions.js");
//   });
// });