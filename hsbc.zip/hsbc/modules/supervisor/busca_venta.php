<?php
# Activacion File 
# @uthor Mark
require_once("includes/includes.inc.php");

initialize("supervisor","Reporte de productividad");

layout_menu($db, "");
?>
	<h4>Asignaci&oacute;n de Ventas</h4>
	<form name="frm11" method="post" action="modules.php?mod=supervisor&op=resultado_venta">
	<p id="text">Busca la solicitud y verifica a que agente esta asignado.<br>
	<p id="text">Si no es el correcto asignale la solcitud al agente correcto.<br>	
	<table width="30%" id="t1" border="1">
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr><tr>
            <td colspan="2"><?=form_oblmsg();?></td>
		</tr><tr>
			<td><b>* Solicitud:</b></td>
			<td><input type="text" name="id_solicitud" id="id_solicitud" value="" maxlength="10" size="10"></td>
		</tr><tr>
			<td colspan="2">
                <input type="button" value="Cancelar" onclick="LimpiaDatos()">
                <input type="button" value="Buscar" onclick="Busca_Venta()">
            </td>
        </tr>
	</table>
    </form>
<?
layout_footer();
?>