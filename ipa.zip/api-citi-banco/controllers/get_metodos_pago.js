const nregistro = require('../db_apis/get_metodos_pago.js');
const fetch = require('node-fetch');
const jwt = require('./token_manager');
const config  = require('../config/web-server');

async function post(req, res, next) {
  try {
    // console.log("autenticar",req.body)
    const context = req.body;//{};
    // console.log(req.params);
    // const rows = await nregistro.find(req.body);
    //
    // console.log(rows);
    // const params = {
    //   fecha_carga: rows[0].FECHA_CARGA,
    //   schema: context.schema
    // };

    // let data = await fetch(config.keyRingHost, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'access_token': jwt.get(),
    //     'Accept': 'application/json'
    //   },
    //   body: JSON.stringify(params)
    // })
    // .then(res=>res.json())
    // .then(data=>{
    //   if(!data.error){
    //     jwt.set(data.idtoken)
    //     context.keyrig = data.dataKey;
    //     context.error_kr = data.error;
    //     context.msg_kr = data.msg;
    //   }
    //   else{
    //     res.status(500);
    //     throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );
    //   }
    // })
    // .catch(err=>{
    //   res.status(500);
    //   return err;
    // })




    const respuesta = await nregistro.give(context);

    if (req.params.id) {
      if (respuesta.length === 1) {
        res.status(200).json(respuesta[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(respuesta);
    }

  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
