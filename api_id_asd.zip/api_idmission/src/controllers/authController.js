const bcrypt = require('bcrypt');
const myslqAccions = require('../models/dbModel')
const webhookImp = require("../controllers/webhookController");


const SALT_ROUNDS = 10;
const userId= 'danieldaniel'


const encrypt = async (pass) => {
  try {
    const hash = await bcrypt.hash(pass, SALT_ROUNDS);
    return hash;

  } catch (error) {
    console.log(error);
    throw error;
  }
}
 

async function desencrypt(pass, hash) {
  try {
      const isValid = await bcrypt.compare(pass, hash);
      return isValid;
  } catch (error) {
      console.error('Error al verificar la contraseña:', error.message);
      throw error;
  }
}

async function getKey() {
  try {
    const rspt = await myslqAccions.checkConn();

    if (rspt.length > 0) {
      console.log('Successfully connected to the base')
      webhookImp.send(userId,{ status: "Success", details: `Successfully connected to the base` })      
      
    }else{
      console.log('Error connected to the base')
      webhookImp.send(userId,{ status: "Error", details: rspt })
    }
  } catch (err) {
    console.error('Error al conectar con la base de datos:', err);
    webhookImp.send(userId,{ status: "Error", details: err })
  }
}



module.exports = {   
  encrypt,desencrypt,getKey
};
