const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN xsp_setNuevoTelefono2(:v_u_persona, :v_lada, :v_telefono, :v_tipo, :v_u_user, :v_bl_reus); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.v_u_persona || !context.v_lada || !context.v_telefono || !context.v_tipo || !context.v_u_user || !context.v_bl_reus){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.v_u_persona = context.v_u_persona;
            binds.v_lada = context.v_lada;
            binds.v_telefono = context.v_telefono;
            binds.v_tipo = context.v_tipo;
            binds.v_u_user = context.v_u_user;
            binds.v_bl_reus ={val:parseInt(context.v_bl_reus), dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;




/*
function set_nuevo_telefono($id_solicitud, $lada, $telefono, $tipo, $db) {
    $stmt = $db->PrepareSP("BEGIN xsp_setNuevoTelefono(:v_u_persona, :v_lada, :v_telefono, :v_tipo); END;");
    $db->InParameter($stmt, $id_solicitud, 'v_u_persona');
    $db->InParameter($stmt, $lada, 'v_lada');
    $db->InParameter($stmt, $telefono, 'v_telefono');
    $db->InParameter($stmt, $tipo, 'v_tipo');
    $db->Execute($stmt);
}
*/