const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {

const baseQuery = "BEGIN ASISTENCIA.TL_SPI_CAPA_HO(:nombre_curso, :fecha1, :fecha2, :duracion, :duracion_id, :tipo_facilitador, :facilitador_int, :facilitador_ext, :STPS, :inversion, :mes, :anio, :registro, :id_curso, :ip); END;";
	let query = baseQuery;
	const binds = {};

	let result2 = {};

        if(!context.duracion){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.nombre_curso = context.nombre_curso;
            binds.fecha1 = context.fecha1;
            binds.fecha2 = context.fecha2;
            binds.duracion = context.duracion;
            binds.duracion_id = context.duracion_id;
            binds.tipo_facilitador = context.tipo_facilitador;
            binds.facilitador_int = context.facilitador_int;
            binds.facilitador_ext = context.facilitador_ext;
            binds.STPS = context.STPS;
            binds.inversion = context.inversion;
            binds.mes = context.mes;
            binds.anio = context.anio;
            binds.registro = context.registro;
            binds.id_curso = context.id_curso;
            binds.ip = context.ip;

            const result = await database.simpleExecute(query, binds);

            // console.log(result); 

            return result;
        }            
}
  
module.exports.find = find;
