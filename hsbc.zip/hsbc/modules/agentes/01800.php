<?php
# @uthor Mark
# 01800 File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Registros 01800");

$s_usr_id = get_session_varname("s_usr_id");
$id_registro = get_session_varname("id_registro");
$existesolicitud = ($id_registro != 0?$id_registro:0);
$fecha_busqueda = (strlen($_REQUEST['fecha_busqueda']) > 1?$_REQUEST['fecha_busqueda']:"");
$today = get_today();
layout_menu($db,"");
?>
<p class="textbold">Agentes &gt; Registros 01800</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=01800" name="frm1">
<table class="text" border="0">
    <tr>
        <td colspan="3" class="label">
            &nbsp;Seleccione Fecha:
            <script type=""  language="JavaScript">
                    var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_busqueda','dateFormat' : 'd/m/Y'}
                    var fecha = '<?=(strlen($fecha_busqueda)!=0?$fecha_busqueda:$today)?>';
                    new sCalendar(SC_SET_1,fecha);
            </script>
        </td>
    </tr><tr>
        <td colspan="3">
            <input type="button" value="Buscar 01800" onclick="Continuar_01800()"/>&nbsp;&nbsp;
        </td>
<?php
if($fecha_busqueda != ""){

    
    $dia = substr($fecha_busqueda, 0, 2);
    $mes = substr($fecha_busqueda, 3, 2);
    $anio = substr($fecha_busqueda, 6, 4);

    $registros_01800 = get_detalle_01800_usuario($s_usr_id, $anio, $mes, $dia, $db);
    
   
?>
    </tr><tr>
        <td colspan="3"><hr></td>
    </tr><tr>
        <td colspan="3"><b>Registros 01800.</b></td>
    </tr><tr>
        <td colspan="3">
            <input type="hidden" name="u_persona" id ="u_persona">
            <input type="hidden" name="u_registro" id ="u_registro">
            <table>
                <tr style="font-weight:bold;" align="center">
                    <td>Agente</td>
                    <td>&nbsp;</td>
                    <td>Supervisor</td>
                    <td>&nbsp;</td>
                    <td>Cliente</td>
                    <td>&nbsp;</td>
                    <td>Telefono</td>
                    <td>&nbsp;</td>
                    <td>Comentario</td>
                    <td>&nbsp;</td>
                    <td>Motivo llamada</td>
                </tr>
                <?
                
                if(!$registros_01800->EOF){
                        
                    while(!$registros_01800->EOF) {
                        echo '<tr>
                            <td align="center">'.$registros_01800->fields["AGENTE"].'</td>
                            <td>&nbsp;</td>
                            <td class="textleft">'.$registros_01800->fields["SUPERVISOR"].'</td>
                            <td>&nbsp;</td>
                            <td class="textleft">'.$registros_01800->fields["CLIENTE"].'</td>
                            <td>&nbsp;</td>
                            <td class="textleft">'.$registros_01800->fields["TELEFONO"].'</td>
                            <td>&nbsp;</td>
                            <td class="textleft">'.$registros_01800->fields["COMENTARIO"].'</td>
                            <td>&nbsp;</td>
                            <td class="textleft">'.$registros_01800->fields["MOTIVO"].'</td>
                            <td>&nbsp;</td>'
                            ;
                        $registros_01800->MoveNext();
                    }
                }else{
                    echo '<tr>
                             <td colspan="7"><font color="blue">No se encontraron resultados</font></td>
                          </tr>';
                          
                }
                ?>
            </table>
        </td>
    </tr><tr>
            <td colspan="3">&nbsp;</td>
    </tr>
<?
}else
    echo '</tr>';
?>
</table>
</form>
<?
layout_footer();
?>
