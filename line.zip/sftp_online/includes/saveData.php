<?php

require 'PHPMailer/PHPMailerAutoload.php';


function guardar_Log_SFTP($db,$estatus,$base){   
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN SPI_LOG_SFTP_TU_CARGABASE_2(:v_Estatus,:v_Base,:rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt,$estatus,'v_Estatus');
        $db->InParameter($stmt,$base,'v_Base');    
        $rs = $db->ExecuteCursor($stmt,'rc');
        return $rs;

    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";
    }     
} 
function truncar_tbl_TU_CARGABASE_2($db){ 
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN XSP_TRUNC_TU_CARGABASE_2(:rc); END;";
        $stmt = $db->PrepareSP($query);
        // $db->InParameter($stmt,$estatus,'v_Estatus');
        // $db->InParameter($stmt,$base,'v_Base');    
        $rs = $db->ExecuteCursor($stmt,'rc');
        return $rs; 
    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";
    }  
}   
function insertarRegistro($data,$db){  
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN SPI_SAVE_DATA_SFTP(:v_base,:v_etiqueta_reg,:v_id,:v_Nombre,:v_Telefono,:v_Fecha_c,:v_Hora_c,:v_Categoria,:v_Fecha_nac,:v_Bounce_Funnel,:v_Source,:v_Campaign,:v_Gclid,:v_Medium,:v_Email,:v_Auto_year,:v_Model_brand_version,:rc); END;";
        $stmt = $db->PrepareSP($query);
        $db->InParameter($stmt, $data["base"],'v_base');
        $db->InParameter($stmt, $data["etiqueta_reg"],'v_etiqueta_reg');
        $db->InParameter($stmt, $data["ID"],'v_id');
        $db->InParameter($stmt, $data["Nombre"],'v_Nombre');
        $db->InParameter($stmt, $data["Telefono"],'v_Telefono');
        $db->InParameter($stmt, $data["Fecha_c"],'v_Fecha_c');
        $db->InParameter($stmt, $data["Hora_c"],'v_Hora_c');
        $db->InParameter($stmt, $data["Categoria"],'v_Categoria');
        $db->InParameter($stmt, $data["Fecha_nac"],'v_Fecha_nac');
        $db->InParameter($stmt, $data["Bounce_Funnel"],'v_Bounce_Funnel');
        $db->InParameter($stmt, $data["Source"],'v_Source');
        $db->InParameter($stmt, $data["Campaign"],'v_Campaign');
        $db->InParameter($stmt, $data["Gclid"],'v_Gclid');    
        $db->InParameter($stmt, $data["Medium"],'v_Medium');    
        $db->InParameter($stmt, $data["Email"],'v_Email');    
        $db->InParameter($stmt, $data["Auto_year"],'v_Auto_year');    
        $db->InParameter($stmt, $data["Model_brand_version"],'v_Model_brand_version');    
        $rs = $db->ExecuteCursor($stmt,'rc');
        return $rs;   
    } catch (Exception $e) {
        // Manejo de la excepción
        // echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        return "ERROR";
    }
} 
function optimiza_TU_CARGABASE_2($db){  
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN XSP_OPTIMIZA_TU_CARGABASE_2(:rc); END;";
        $stmt = $db->PrepareSP($query);
        // $db->InParameter($stmt,$estatus,'v_Estatus');
        // $db->InParameter($stmt,$base,'v_Base');    
        $rs = $db->ExecuteCursor($stmt,'rc');
        return $rs; 
    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";
    }  
}  


function higiene($db){
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query= "BEGIN XSP_SANITIZACION_1; END;";
        $stmt = $db->PrepareSP($query);
        $db->Execute($stmt);
    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";
    }

 }  
 function valida_paso_1($db){  
    try {
        $db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN XSP_higienizacion_paso_1(:rc); END;";
        $stmt = $db->PrepareSP($query); 
        $rs = $db->ExecuteCursor($stmt,'rc');
        return $rs;
    } catch (Exception $e) {
        // Manejo de la excepción
        echo "ERROR" . $e->getMessage();
        // echo "ERROR" . $e->getMessage();
        // return "ERROR";
    }    
}

//  -----------------------------------------------------------------------------------------------
function notifica($data){
    echo '<br> Enviando correo...  '.$data;
    // // MENSAJE SMS
    $campana=1008;    
    $cadena = 'Fallo la carga automatica. Campana: DIGITAL. ARCHIVO => '.$data;   
    $proveedor=6;     
    $telefonos = array("DANIEL" => 4428450036,"VICKY" => 9717185016,"JORGE" => 4426797176);
    foreach ($telefonos as $tel => $value) {        
        $ch = curl_init('172.20.1.95/sms_hsbc/index2.php');               
        curl_setopt($ch, CURLOPT_POST, 1);   
        curl_setopt($ch, CURLOPT_POSTFIELDS, array(
           'numero' => $value ,
           'proveedor' => $proveedor,
           'campana' => $campana,
           'mensaje' => $cadena
         )); 
        //le decimos que queremos recoger una respuesta (si no esperas respuesta, ponlo a false)
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);   
        //recogemos la respuesta
        $respuesta_api = curl_exec($ch);   
        //o el error, por si falla
        $error_api = curl_error($ch);   
        //y finalmente cerramos curl
        curl_close($ch);
    } 
    ////CORREO  
    $rs3 = array(
        "DESARROLLO" => 'dsa@impulse-telecom.com',
     //   "ULISES" => 'ujuarez@impulse-telecom.com',
     //   "BLANCA" => 'balegria@impulse-telecom.com',
      //   "DANIEL2" => 'danieluaeh@gmail.com',
      ); 
    $mensaje = '
      <div style="background: #d8fdf8;">
      <p> <b style="color: red;"> Error </b> en la carga automatica de archivos CSV para Insurance Digital</p>
      <p> El archivo con errores es => <b style="color: red;"> '.$data.' </b></p>
  
      </div>
      '; 

     foreach ($rs3 as $key => $value) {
        // echo '<hr>'.$key.' -> '.$value;    
        $asunto = "ERROR EN CARGA AUTOMATICA DIGITAL";
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        $mail->Host = "mail.impulse-telecom.com.mx";
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = "reportes@impulse-telecom.com";
        $mail->Password = "R3p0rt32016";
        $mail->setFrom('reportes@impulse-telecom.com', 'impulse telecom');
        $mail->addAddress($value, '');
        $mail->Subject = $asunto;  
        //echo $mensaje; 
        //die(); exit(); 
        $mail->msgHTML($mensaje);
        if (!$mail->send()) {
        //   echo "Mailer Error: ".$mail->ErrorInfo;    
          echo "Correo no enviado ";    
        } else {
          echo '<hr> Correo Enviado';
            // echo "Mailer sent!->".$rs3->fields['CORREO']."->".$contador;
        }
    }


}




function notifica_exito(){ 
    print_r($total_archivos);
    die();
    ////CORREO  
    $rs3 = array(
        "DESARROLLO" => 'dsa@impulse-telecom.com',
     //   "ULISES" => 'ujuarez@impulse-telecom.com',
     //   "BLANCA" => 'balegria@impulse-telecom.com',
      //   "DANIEL2" => 'danieluaeh@gmail.com',
      ); 
    $mensaje = '
      <div style="background: #d8fdf8;">
      <p> <b style="color: red;"> Error </b> en la carga automatica de archivos CSV para Insurance Digital</p>
      <p> El archivo con errores es => <b style="color: red;"> '.$data.' </b></p>
  
      </div>
      '; 

     foreach ($rs3 as $key => $value) {
        // echo '<hr>'.$key.' -> '.$value;    
        $asunto = "ERROR EN CARGA AUTOMATICA DIGITAL";
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        $mail->Host = "mail.impulse-telecom.com.mx";
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = "reportes@impulse-telecom.com";
        $mail->Password = "R3p0rt32016";
        $mail->setFrom('reportes@impulse-telecom.com', 'impulse telecom');
        $mail->addAddress($value, '');
        $mail->Subject = $asunto;  
        //echo $mensaje; 
        //die(); exit(); 
        $mail->msgHTML($mensaje);
        if (!$mail->send()) {
        //   echo "Mailer Error: ".$mail->ErrorInfo;    
          echo "Correo no enviado ";    
        } else {
          echo '<hr> Correo Enviado';
            // echo "Mailer sent!->".$rs3->fields['CORREO']."->".$contador;
        }
    }


}