<?php
ini_set('display_errors', 1);
# @uthor Mark 
# Cuestionario File 

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
require_once("includes/surveyClass.php");

initialize("agente","Solicitud");

//$id_solicitud = get_session_varname('id_solicitud');
//$id_producto = get_session_varname('id_producto');
$id_solicitud = 5000;
$id_producto = 1;

//--$id_registro = get_session_varname('id_registro');
//--$datos_cliente = get_session_varname("datos_persona");
layout_menu($db, "displayResult()");

$objsurveyClass = new surveyClass($id_solicitud, $id_producto, $db);
echo $objsurveyClass->GetXML();
?>
<script>
    var survey_id = <?=$id_solicitud?>;
    var customer_id = <?=$id_producto?>;
</script>
<script LANGUAGE="JavaScript" src="/hsbc/includes/js/jsCode_cuestionario.js"></script>

<p class="textbold">Agentes &gt; Solicitud</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=process_data&act=<?=encripta(14)?>" name="SurveyResponse">
<table border="0" width="100%">
    <tr>
        <td colspan="2">
            <div id="cuestionario"/>
        </td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr>
</table>
</form>
<? layout_footer(); ?>
