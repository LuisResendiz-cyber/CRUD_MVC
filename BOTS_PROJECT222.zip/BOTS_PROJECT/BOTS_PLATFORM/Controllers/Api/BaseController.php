<?php
namespace Controllers\Api;

use Core\Api;
use Core\Conexion;

class BaseController extends Api {
    protected $db;
    
    public function __construct() {
        parent::__construct();
        $this->db = Conexion::getInstance(); // Asumiendo que ya tienes esta clase
    }
    
    // Métodos comunes para todos los controladores API
    protected function validateRequired($fields, $data) {
        $missing = [];
        foreach ($fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $missing[] = $field;
            }
        }
        
        if (!empty($missing)) {
            $this->response(400, [
                'error' => 'Campos requeridos faltantes',
                'fields' => $missing
            ]);
        }
        
        return true;
    }
    
    protected function sanitizeInput($input) {
        if (is_array($input)) {
            foreach ($input as $key => $value) {
                $input[$key] = $this->sanitizeInput($value);
            }
        } else {
            $input = htmlspecialchars(strip_tags(trim($input)));
        }
        return $input;
    }
}