const Users = require("../models/Users.models");
const MenuService = require("../services/User.service");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const secretKey = process.env.JWT_SECRET;

const UsersController = {
  async setUser(req, res) {
    const {
      customer_id,
      name,
      last_name,
      phone_number,
      email_user,
      passwordHash,
      rolid,
    } = req.body;
    const validaUser = await Users.getAcces({ email_user });

    if (validaUser) {
      return res.json({
        message:
          "El email ya existe en registrado, favor de validar la informacion",
      });
    }

    const salt = await bcrypt.genSalt(10);
    const password = await bcrypt.hash(passwordHash, salt);

    try {
      const resp = await Users.CreateUser({
        customer_id,
        name,
        last_name,
        phone_number,
        email_user,
        password,
        rolid,
      });

      if (resp.affectedRows > 0) {
        console.log("Usuario registrado con éxito");
        res.json({
          message: "Usuario registrado con éxito",
          userId: resp.insertId,
        });
      } else {
        res.status(400).json({ message: " No se pudo insertar el usuario" });
      }
    } catch (error) {
      console.log(error.message);
      return res
        .status(500)
        .json({ message: " Error en el servidor, intenta más tarde" });
    }
  },
   async createUser(req, res) {
    try {
      const { name, last_name, phone_number, email_user, passwordHash, rolid, status = 1 } = req.body;
      
      const salt = await bcrypt.genSalt(10);
      const password = await bcrypt.hash(passwordHash, salt);
      
      const result = await Users.User(3, { 
        name, last_name, phone_number, email_user, password, rolid, status
      });
      
      res.status(201).json(
        {data: result}
      );
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al crear el usuario',
        error: error.message
      });
    }
  },
  async updateUser(req, res) {
    try {
      const { id } = req.params;
      const { name,last_name, phone_number, email_user, passwordHash, rolid, status } = req.body;
      
      // Verificar si existe el usuario
      const existingUser = await Users.User('2', { id });

      if (existingUser.length === 0) {
        return res.status(404).json({
          message: 'Usuario no encontrado'
        });
      }

      const result = await Users.User(4, {
        id,
        name: name || existingUser.NOMBRE,
        last_name: last_name || existingUser.APELLIDO,
        phone_number: phone_number || existingUser.phone_number,
        email_user: email_user || existingUser.EMAIL,
        passwordHash: passwordHash || existingUser.passwordHash,
        rolid: rolid !== undefined ? rolid : existingUser.rolid,
        status: status !== undefined ? status : existingUser.status
      });
      
      res.json({
        data: result,
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al actualizar el usuario',
        error: error.message
      });
    }
  },
  async deleteUser(req, res) {
    try {
      const { id } = req.params;
      
      // Verificar si existe el usuario
      const existingUser = await Users.User(2, { id });
      if (existingUser.length === 0) {
        return res.status(404).json({
          message: 'Usuario no encontrado'
        });
      }
      
      const result = await Users.User(5, { id });
      res.json({
        data: result
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al eliminar el usuario',
        error: error.message
      });
    }
  },
  async getAllUsers(req, res) {
    try {
      const users = await Users.User(1);
      res.json({
        status: true,
        usuarios: users
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al obtener usuarios',
        error: error.message
      });
    }
  },
  async getUserById(req, res) {
    try {
      const { id } = req.params;
      const users = await Users.User(2, { id });
      
      if (users.length === 0) {
        return res.status(404).json({
          status: false,
          message: 'Usuario no encontrado'
        });
      }
      

      res.json({
        status: true,
        data: users
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al obtener el usuario',
        error: error.message
      });
    }
  },
  async login(req, res) {
    const { email_user, passwordHash } = req.body;
    const user = await Users.getAcces({ email_user });

    console.log(user);

    if (!user) {
      return res.json({
        message: `El usuario ${email_user} no existe, favor de revisar`,
      });
    }
    const isMatch = await bcrypt.compare(passwordHash, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Contraseña incorrecta" });

    // Crear token JWT
    const token = jwt.sign(
      { userId: user.idUser, email_user: user.email_user },
      secretKey,
      { expiresIn: "90d" }
    );

    // Adjuntar token al usuario
    user.token = token;

    res.json({
      status: "success",
      user,
    });
  },
  async changePassword(req, res) {
    const { email_user, passwordHash } = req.body;
    const user = await Users.getAcces({ email_user });
  },
  async getModules(req, res) {
    try {

      const { id_user } = req.query;
      
      console.log(id_user);
      const menu = await MenuService.getUserMenu(parseInt(id_user));

  
      return res.json(menu);
  
    } catch (error) {
      return res.status(500).json({
        status: false,
        msg: error.message
      });
    }
  },
  async getRoles(req, res) {
    try {
      const roles = await Users.Roles(1);
      res.json({roles});
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al obtener roles',
        error: error.message
      });
    }
  },
  async getRoleById(req, res) {
    try {
      const { id } = req.query;
      const roles = await Users.Roles(2, { id });
      
      if (roles.length === 0) {
        return res.status(404).json({
          status: false,
          message: 'Rol no encontrado'
        });
      }
      
      res.json({
        status: true,
        data: roles[0]
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al obtener el rol',
        error: error.message
      });
    }
  },
  async updateRol(req, res){
    try {
      const { id } = req.params;
      const { name, description, status } = req.body;
      
      // Verificar si existe el rol
      const existingRole = await Users.Roles(1, { id });
      if (existingRole.length === 0) {
        return res.status(404).json({
          status: false,
          message: 'Rol no encontrado'
        });
      }
      
      const result = await Users.Roles(4, {
        id,
        name: name || existingRole[0].name,
        description: description || existingRole[0].description,
        status: status !== undefined ? status : existingRole[0].status
      });
      
      res.json({
        status: true,
        data: result
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al actualizar el rol',
        error: error.message
      });
    }
  },
  async deleteRol(req, res){
    try {
      const { id } = req.params;

      // Verificar si existe el rol
      const existingRole = await Users.Roles(2, { id });

      if (existingRole.length === 0) {
        return res.status(404).json({
          status: false,
          message: 'Rol no encontrado'
        });
      }
      
      const result = await Users.Roles(6, { id });
      

      // if (result && result.length > 0) {
      //   if (dataa.status === 1 || dataa.status === true) {
          res.json({
            data: result
          });        
      //}}
      //if (result.data.status === false) {        
      
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al eliminar el rol',
        error: error.message
      });
    }

  },
  async createRole(req, res) {
    try {
      const { name, description, status = 1 } = req.body;
      
      // Validaciones
      if (!name) {
        return res.status(400).json({
          status: false,
          message: 'El nombre es requerido'
        });
      }
      
      const result = await Users.Roles(3, { 
        name, 
        description, 
        status 
      });
      
      res.status(201).json({
        status: true,
        data: result
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al crear el rol',
        error: error.message
      });
    }
  },
  async updateRole(req, res) {
    try {
      const { id } = req.params;
      const { name, description, status } = req.body;
      
      // Verificar si existe el rol
      const existingRole = await Users.Roles('GET_BY_ID', { id });
      if (existingRole.length === 0) {
        return res.status(404).json({
          status: false,
          message: 'Rol no encontrado'
        });
      }
      
      const result = await Users.Roles('UPDATE', {
        id,
        name: name || existingRole[0].name,
        description: description || existingRole[0].description,
        status: status !== undefined ? status : existingRole[0].status
      });
      
      res.json({
        status: true,
        data: result,
        message: 'Rol actualizado exitosamente'
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        message: 'Error al actualizar el rol',
        error: error.message
      });
    }
  },
}

module.exports = UsersController;
