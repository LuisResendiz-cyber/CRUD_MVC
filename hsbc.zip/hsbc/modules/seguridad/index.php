<?php
require_once("includes/includes.inc.php");
load_session();
layout_header("Seguridad");

//print_r($_SESSION);
if(is_logged()){        
    $name = get_session_varname('s_usr_nombre');
}
    
echo '</head><body id="idBody" class="bottom_image" onload="boton_der_deshabilitado();';
if(strlen($jsFunction) > 0)
    echo $jsFunction;

echo'">
      <table class="width100" border="0">
        <tr background="' . $linkpath . 'includes/imgs/logo2.png">
            <td>
                <p><img style="width: 23%; height: 23%;" src="' . $linkpath . 'includes/imgs/logo_campana.png" class="valignmiddle"/><a class="title2">&nbsp;' . $header_title . '</a></p>
            </td><td>';
        if(is_logged() && (get_session_varname('s_usr_nivel') == 'A' || get_session_varname('s_usr_nivel') == 'ACB' || get_session_varname('s_usr_nivel') == 'ASB')){
            $detalle = get_agente_info(get_session_varname("s_usr_id"), $db);
            echo '<table align="center">
                    <tr>
                        <td><b>Solicitudes Canceladas:</b></td><td>'.$detalle->_array[0]['CANCELADAS'].'</td>
                    </tr>
                    <tr>
                        <td><b>Solicitudes Aceptadas:</b></td><td>'.$detalle->_array[0]['ACEPTADAS'].'</td>
                    </tr>
                    <tr>
                        <td><b>Ultima Solicitud:</b></td><td>'.$detalle->_array[0]['ULTIMASOLICITUD'].'</td>
                    </tr>
                    <tr>
                        <td><b>Nota de Validaci&oacute;n:</b></td><td>'.$detalle->_array[0]['V_NOTA'].'</td>
                    </tr>
            </table>';
        }else{
            echo '&nbsp;';
        }
        echo '</td>
            </tr><tr class="bar">
                <td align="left" width="50%">';
                    if(is_logged())
                        echo '<b>Usuario: '.$name.'</b>';
                    else
                        echo '&nbsp;';
          echo '</td></td><td align="right">&nbsp;<b>'.get_now().'</b></td>
                    </tr><tr>
                            <td  colspan="2">
                                    <table class="width100" border="0">
                                            <tr>
                                                    <td class="menu">';
                                                            //echo menu($db);
                                            echo '</td>
                                                      <td class="vspacer">&nbsp;</td>
                                                      <td class="text">';
?>
<br>
<script language="JavaScript" src="<?= $linkpath ?>includes/js/jquery_validate.js" type="text/javascript"></script>
<script>
    $().ready(function(){
        //debug: true,
        $("#form").validate({
            rules: {
                password: {
                    required:true,
                    maxlength2: 8
                },
                password_again: {
                    required:true,
                    equalTo: "#password",
                    maxlength2: 8
                }
            },
            submitHandler: function() {
                update_password();
            }
        });
        //$('#password').puipassword();
    });

    function update_password(){

        v_password = document.getElementById("password").value;
        v_passwrod1 = document.getElementById("password_again").value;
        usr_id = document.getElementById("usr_id").value;
        //usr_campaign_id = document.getElementById("usr_campaign_id").value;
        //alert(usr_id +" "+ usr_campaign_id);

        var xmlhttp;
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
            if (xmlhttp.readyState==4 && xmlhttp.status==200){
                document.getElementById("result_").innerHTML=xmlhttp.responseText.substr(1);
                if(xmlhttp.responseText.substr(0,1) == 5){
                    alert("Se ha cambiado el password Exitosamente.");
                    window.location = "modules.php?mod=seguridad&op=process_data&act=2";
                }
            }
        }
        xmlhttp.open("POST","modules.php?mod=seguridad&op=process_data",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.send("act=1&v_pwd="+v_password+"&v_pwd2="+v_passwrod1+"&usr_id="+usr_id); //+"&num_agente="+num_agente);
    }
</script>
<!--div id="content"-->
    <form id="form" name="form" method="post" ><!--onsubmit="return submitForm(this);"-->
        <h2 align="center">Cambio de contrase&ntilde;a</h2>
        <h3 align="center">
            Por motivos de la Norma ISO 27001 <font color="Red">se obliga a cambiar el password cada inicio de mes</font><br />    
        </h3>
        <ul style="text-transform: uppercase; font-size: 10px; color: red; text-align: center;">
            <li>El password debe tener almenos un car&aacute;cter especial !"#$%()*+,-./:;<=>?@�������[\]^_`{|}~�߱�</li>
            <li>La longitud debe ser 8 caracteres</li>
            <li>El password debe ser diferente a los 12 passwords anteriores</li>
            <li>Al finalizar, dar clic en continuar para entrar al sicall</li>
        </ul>
        <table align="center" style="position: absolute; left: 43%">
            <TR>
                <TD colspan="2">
                    <div id="result_"></div>
                </TD>
            </TR>
            <tr>
                <th>Contrase�a actual:</th>
                <td><strong><?php echo $_SESSION['s_pwd'] ?></strong></td>
            </tr>
            <tr>
                <th>Contrase�a nueva:</th>
                <td>
                    <input type="password" id="password" name="password"><!--size="20" maxlength="20" id="usr_pwd"-->
                </td>                        
            </tr>
            <tr>
                <th>Repite la contrase�a:</th>
                <td>
                    <input type="password" id="password_again" name="password_again"><!-- size="20" maxlength="20" id="usr_pwd1"-->
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" value="Continuar" name="cmdChange" >
                </td>
            </tr>
        </table>
        <input type="hidden" name="usr_id" id="usr_id" value="<?php echo $_SESSION['s_usr_id2'] ?>">
        <input type="hidden" name="usr_campaign_id" id="usr_campaign_id" value="291">
    </form>
<!--/div-->
<?php

layout_footer();
