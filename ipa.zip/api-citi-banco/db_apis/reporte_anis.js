const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  const baseQuery =
    "BEGIN CITI.SPS_REPORTE_ANIS(:mes, :anio, :rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  let result = {};

  if (context.mes == "" || context.anio == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
  } else {
    binds.mes = context.mes;
    binds.anio = context.anio;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
    console.log(result);
      
    return result; 
  }
}

module.exports.find = find;
