const actMailer = require("../model/model-mailer");
const ExcelJS = require("exceljs");
const path = require("path");
const fs = require("fs");
const { actionsMysql } = require("../model/model-mysql");

let ruta_file = "";
let envio_correcto = 0;

const { createConnObj, oraExcProc2 } = require("../model/model-oracle");
const { func } = require("joi");

const reporteKpis = {
  reporteKpisCitiBanco: async (req, res) => {
    const datos = [
      { opcion: 4, nombre: "ITS", producto: 1, empresa: 5, valor: "CNC" },
      { opcion: 4, nombre: "ITS", producto: 2, empresa: 5, valor: "CNB" },
      { opcion: 4, nombre: "ITS", producto: 3, empresa: 5, valor: "CNT" },
      { opcion: 4, nombre: "ITS", producto: 4, empresa: 5, valor: "CPC" },
      { opcion: 4, nombre: "ITS", producto: 5, empresa: 5, valor: "CPB" },
      { opcion: 4, nombre: "ITS", producto: 6, empresa: 5, valor: "CPT" },
      { opcion: 4, nombre: "ITS", producto: 7, empresa: 5, valor: "CLI" },
      { opcion: 4, nombre: "ITR", producto: 1, empresa: 411, valor: "CNC" },
      { opcion: 4, nombre: "ITR", producto: 2, empresa: 411, valor: "CNB" },
      { opcion: 4, nombre: "ITR", producto: 3, empresa: 411, valor: "CNT" },
      { opcion: 4, nombre: "ITR", producto: 4, empresa: 411, valor: "CPC" },
      { opcion: 4, nombre: "ITR", producto: 5, empresa: 411, valor: "CPB" },
      { opcion: 4, nombre: "ITR", producto: 6, empresa: 411, valor: "CPT" },
      { opcion: 4, nombre: "ITR", producto: 7, empresa: 411, valor: "CLI" },
      { opcion: 2, nombre: "GENERAL", producto: 1, empresa: 411, valor: "CNC" },
      { opcion: 2, nombre: "GENERAL", producto: 2, empresa: 411, valor: "CNB" },
      { opcion: 2, nombre: "GENERAL", producto: 3, empresa: 411, valor: "CNT" },
      { opcion: 2, nombre: "GENERAL", producto: 4, empresa: 411, valor: "CPC" },
      { opcion: 2, nombre: "GENERAL", producto: 5, empresa: 411, valor: "CPB" },
      { opcion: 2, nombre: "GENERAL", producto: 6, empresa: 411, valor: "CPT" },
      { opcion: 2, nombre: "GENERAL", producto: 7, empresa: 411, valor: "CLI" },
    ];

    respuesta_promesa = 0;
    let index = 0;
    const workbook = new ExcelJS.Workbook();

    // Función para llenar la hoja
    async function fillSheet(worksheet, nombre, workbook) {
      // Encabezados
      worksheet.addRow(["ACUMULADO", "DIAS_DE_MARCACION", "LEADS_RECIBIDOS", "TOTAL_REG_TOC", "WS", "HORAS", "LLAMADAS", "CE_LLAMADAS", "CONTACTOS", "E.E./BDD", "VENTAS", "%CLOSE", "SPH", "CONVERSION", "CE", "CNE", "NC"]);
      
      // Filtrar datos por nombre
      const filteredData = datos.filter(item => item.nombre === nombre);
      
      // Llenar cada fila
      // filteredData.forEach(item => {
      index = 0;
      for (const item of filteredData) {
          const campaign = 1013;
          const nameProcedure = "SPS_REPORTE_KPIS_2";
          let parameters = { v_producto: item.producto, v_opcion: item.opcion, v_empresa: item.empresa };
          // // console.log(parameters);
          let oraRspta = 10;
          if (item.nombre == 'ITS') {
            if (item.producto == 1 || item.producto == 2 || item.producto == 3 || item.producto == 5 || item.producto == 7) {
              oraRspta = 20;
            } else {
              objConnOracle = await createConnObj(campaign, nameProcedure, parameters);

              if (objConnOracle == null || objConnOracle == undefined) {
                console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
                res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
              } else {
                // console.log(objConnOracle);
                try {
                  const oraRspta_1 = await oraExcProc2(objConnOracle);
                  // console.log(oraRspta_1);

                  console.log("DATA IN ORACLE");
                  worksheet.addRow([item.valor, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);

                  for (let i = 1; i <= 5; i++) {
                      worksheet.addRow(["GRUPO_" + i, oraRspta_1[i-1]["DIAS_DE_MARCACION"], oraRspta_1[i-1]["LEADS_RECIBIDOS"], oraRspta_1[i-1]["LEADS_UTILIZADOS"], oraRspta_1[i-1]["WS"], oraRspta_1[i-1]["HORAS"], oraRspta_1[i-1]["LEADS_OCUPADAS"], oraRspta_1[i-1]["CE_LLAMADAS"], oraRspta_1[i-1]["CONTACTOS"], oraRspta_1[i-1]["BDD"], oraRspta_1[i-1]["VENTAS"], oraRspta_1[i-1]["CLOSE"], oraRspta_1[i-1]["SPH"], oraRspta_1[i-1]["CONVERSION"], oraRspta_1[i-1]["CONTACTO_EFECTIVO"], oraRspta_1[i-1]["CONTACTO_NO_EFECTIVO"], oraRspta_1[i-1]["NO_CONTACTO"]]);
                  }
                } catch (error) {
                  res.status(500).send({ error: error.message });
                }
              }
            }
          } else if (item.nombre == 'ITR') {
            if (item.producto == 1 || item.producto == 5) {
              oraRspta = 20;
            } else {
              objConnOracle = await createConnObj(campaign, nameProcedure, parameters);

              if (objConnOracle == null || objConnOracle == undefined) {
                console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
                res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
              } else {
                // console.log(objConnOracle);
                try {
                  const oraRspta_1 = await oraExcProc2(objConnOracle);

                  // console.log(oraRspta_1);
                  console.log("DATA IN ORACLE");
                  worksheet.addRow([item.valor, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);

                  for (let i = 1; i <= 5; i++) {
                      worksheet.addRow(["GRUPO_" + i, oraRspta_1[i-1]["DIAS_DE_MARCACION"], oraRspta_1[i-1]["LEADS_RECIBIDOS"], oraRspta_1[i-1]["LEADS_UTILIZADOS"], oraRspta_1[i-1]["WS"], oraRspta_1[i-1]["HORAS"], oraRspta_1[i-1]["LEADS_OCUPADAS"], oraRspta_1[i-1]["CE_LLAMADAS"], oraRspta_1[i-1]["CONTACTOS"], oraRspta_1[i-1]["BDD"], oraRspta_1[i-1]["VENTAS"], oraRspta_1[i-1]["CLOSE"], oraRspta_1[i-1]["SPH"], oraRspta_1[i-1]["CONVERSION"], oraRspta_1[i-1]["CONTACTO_EFECTIVO"], oraRspta_1[i-1]["CONTACTO_NO_EFECTIVO"], oraRspta_1[i-1]["NO_CONTACTO"]]);
                  }
                
                } catch (error) {
                  res.status(500).send({ error: error.message });
                }
              }
            }
          } else {
            if (item.producto == 1 || item.producto == 5) {
              oraRspta = 20;
            } else {
              objConnOracle = await createConnObj(campaign, nameProcedure, parameters);

              if (objConnOracle == null || objConnOracle == undefined) {
                console.log("NO CREDENTIALS FOR THIS CAMPAIGN");
                res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
              } else {
                // console.log(objConnOracle);
                try {
                  const oraRspta_1 = await oraExcProc2(objConnOracle);

                  // console.log(oraRspta_1);
                  console.log("DATA IN ORACLE");
                  worksheet.addRow([item.valor, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);

                  for (let i = 1; i <= 5; i++) {
                      worksheet.addRow(["GRUPO_" + i, oraRspta_1[i-1]["DIAS_DE_MARCACION"], oraRspta_1[i-1]["LEADS_RECIBIDOS"], oraRspta_1[i-1]["LEADS_UTILIZADOS"], oraRspta_1[i-1]["WS"], oraRspta_1[i-1]["HORAS"], oraRspta_1[i-1]["LEADS_OCUPADAS"], oraRspta_1[i-1]["CE_LLAMADAS"], oraRspta_1[i-1]["CONTACTOS"], oraRspta_1[i-1]["BDD"], oraRspta_1[i-1]["VENTAS"], oraRspta_1[i-1]["CLOSE"], oraRspta_1[i-1]["SPH"], oraRspta_1[i-1]["CONVERSION"], oraRspta_1[i-1]["CONTACTO_EFECTIVO"], oraRspta_1[i-1]["CONTACTO_NO_EFECTIVO"], oraRspta_1[i-1]["NO_CONTACTO"]]);
                  }
                
                } catch (error) {
                  res.status(500).send({ error: error.message });
                }
              }
            }
          }

          if (oraRspta == 0) {
            console.log("NO DATA IN ORACLE");
            worksheet.addRow([item.valor, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);

            for (let i = 1; i <= 5; i++) {
                worksheet.addRow(["GRUPO_" + i, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);
            }
          } else if (oraRspta == 20) {
            worksheet.addRow([item.valor, "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]);

            for (let i = 1; i <= 5; i++) {
                worksheet.addRow(["GRUPO_" + i, 0, 0, 0, 0, 0, 0, "0%", 0, "0%", 0, "0%", 0, "0%", 0, 0, 0]);
            }
          } 

          console.log('index '+ item.nombre +' ' + item.producto);
          // console.log(index + ' valor de index.');
          index++; // Incrementar el contador
          if (item.producto == 7 && item.nombre == 'ITS') {
            console.log(index + ` es el último elemento de its`);
            // guardarArchivo(workbook, res);
            aplicarEstilos(worksheet, workbook, res, item.nombre);
	          index = 0;
          } else if (item.producto == 7 && item.nombre == 'ITR') { 
            console.log(index + ` es el último elemento de itr`);
            // guardarArchivo(workbook, res);
            aplicarEstilos(worksheet, workbook, res, item.nombre);
            index = 0;
          } else if (item.producto == 7 && item.nombre == 'GENERAL') { 
            console.log(index + ` es el último elemento de itr`);
            // guardarArchivo(workbook, res);
            aplicarEstilos(worksheet, workbook, res, item.nombre);
          }
      };
    }

    // Crear las hojas
    const names = ["ITS", "ITR", "GENERAL"];
    // const names = ["ITR"];
    names.forEach(nombre => {
        const worksheet = workbook.addWorksheet(nombre);
        fillSheet(worksheet, nombre, workbook);        
    });
  },
};

async function enviarCorreo(res) {
  const filePath = path.join(
    __dirname,
    "..",
    "assets/docs",
    "Reporte_KPIS.xlsx"
  );
  const mails = await actionsMysql.mailsAsistencia(4);
  if (mails.length == 0) {
    console.log("Reporte no enviado, sin remitentes para este correo");
    res.json({
      status: 200,
      rspta: "Reporte no enviado, sin remitentes para este correo",
    });
  } else {
    // console.log(mails);
    const emailAddresses = mails.map((emailObj) => emailObj.MAILS);
    const emailString = emailAddresses.join(",");

    const mailOptions = {
      to: emailString,
      subject: "Reporte KPIS",
      html: "Reporte KPIS ITS, ITR",
      attachments: [
        {
          filename: "Reporte_KPIS.xlsx",
          path: filePath,
        },
      ],
    };
    let nObjMailer = await actMailer.createObjMailer(mailOptions);

    if (nObjMailer == 200) {
      console.log("Reporte enviado: ", nObjMailer);
      await actionsMysql.saveLogCron("REPORTE CORTO", 1);
      res.json({ status: 200, rspta: "MAILS SENT" });
    } else {
      await actionsMysql.saveLogCron("REPORTE CORTO", 0);
      console.log("Error al enviar reporte : ", nObjMailer);
      res.send("Error al enviar reporte");
    }
  }
}

function esPar(numero) {
    return numero % 2 === 0; // Devuelve true si el número es par
}

function guardarArchivo(workbook, res) {
  // Guardar el archivo
  const outputPath = path.join(__dirname, "..", 'assets/docs', 'Reporte_KPIS.xlsx');
  workbook.xlsx.writeFile(outputPath)
    .then(() => {
        console.log('Archivo guardado como datos.xlsx');
    })
    .catch(err => {
        console.error('Error al guardar el archivo:', err);
    });
  enviarCorreo(res);
}

function aplicarEstilos(worksheet, workbook, res, nombre) {
   //**** Aplicar estilos ****
   const celdas = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q"];

   // Recorrer el arreglo para aplicar estilos
   for (let i = 1; i <= 43; i++) {
       if (esPar(i)) {
           celdas.forEach((celda, index) => {
               // console.log(`Celda ${celda}${i}`);
               worksheet.getCell(`${celda}${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: '000000' } };
               worksheet.getCell(`${celda}${i}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'd6eaf8' } };

               if (i == 1 || i == 2 || i == 8 || i == 14 || i == 20 || i == 26 || i == 32 || i == 38) {
                   worksheet.getCell(`A${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: '000000' } };
               } else {
                   worksheet.getCell(`A${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: 'b2babb' } };
               }
           });
       } else {
           celdas.forEach((celda, index) => {
               worksheet.getCell(`${celda}${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: '000000' } };
               worksheet.getCell(`${celda}${i}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'ffffff' } };

               if (i == 1 || i == 2 || i == 8 || i == 14 || i == 20 || i == 26 || i == 32 || i == 38) {
                   worksheet.getCell(`A${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: '000000' } };
               } else {
                   worksheet.getCell(`A${i}`).font = { name: 'Calibri', size: 12, bold: true, color: { argb: 'b2babb' } };
               }
           });
       }
   }

   // Definir bordes
   const borderStyle = {
       top: { style: 'thin', color: { argb: '2e86c1' } },
       left: { style: 'thin', color: { argb: '2e86c1' } },
       bottom: { style: 'thin', color: { argb: '2e86c1' } },
       right: { style: 'thin', color: { argb: '2e86c1' } }
   };

   // Aplicar bordes a un rango de celdas (A1 a Q43)
   for (let i = 1; i <= 43; i++) {
       for (let j = 1; j <= 17; j++) {
           const cell = worksheet.getCell(i, j); // Obtener la celda por fila y columna
           cell.border = borderStyle; // Aplicar bordes
       }
   }

  if (nombre == 'GENERAL') {
    guardarArchivo(workbook, res);
  }
}

module.exports = { reporteKpis };

