<?php
# @uthor Mark
# Index File on Validacion module

require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize("validacion","Buscar Solicitud");

$id_solicitud = base64_decode($_REQUEST['sol']);

layout_menu($db, "");
?>
<p class="textbold">Validaci&oacute;n &gt; Buscar Solicitud</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=validacion&op=process_data&act=1" name="frm1">
<table border="0">
    <tr>
        <td colspan="2"><b>Captura el numero de solicitud que se va a validar.</b></td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr><tr>
        <td colspan="2"><?=form_oblmsg()?></td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr><tr>
        <td><b>* N&uacute;mero de Solicitud </b></td>
        <td><input type="text" size="10" name="idsolicitud" id="idsolicitud" maxlength="10"></td>
    </tr><tr>
        <td colspan="2">&nbsp;</td>
    </tr><tr>
        <td><input type="button" value="Limpiar" onclick="LimpiaDatosV()"/></td>
        <td><input type="button" value="Buscar Solicitud" onclick="BuscarSolicitud()"/></td>
    </tr>
</table>
</form>
<?
layout_footer();
?>