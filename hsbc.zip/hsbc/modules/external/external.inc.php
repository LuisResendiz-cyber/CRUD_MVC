<?php

/*
##### OBTIENE EL NUMERO DE SOLICITUD DE PREDICTIVO

function get_preavail($s_usr_id, $db) {
    $rs = $db->ExecuteCursor("BEGIN xsp_getPreAvail_ws(" . $s_usr_id . ",:rc); END;", 'rc');
    $db->SetFetchMode(ADODB_FETCH_BOTH);
    return $rs;
}

##### OBTIENE UN NUEVO REGISTRO Y DEVUELVE EL NUMERO DE SOLICITUD

function get_registro_solicitud($s_usr_id, $camp, $prioridad, $estatus, $intentos, $rand_, $reg, $tipoCampana, $db) {
    $db->SetFetchMode(ADODB_FETCH_BOTH);

    $stmt = $db->PrepareSP("BEGIN XSP_GETNUEVOREGISTRO(:camp ,:prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :rc); END;");
    $db->InParameter($stmt, $camp, 'camp');
    $db->InParameter($stmt, $prioridad, 'prioridad');
    $db->InParameter($stmt, $estatus, 'estatus');
    $db->InParameter($stmt, $intentos, 'intentos');
    $db->InParameter($stmt, $s_usr_id, 'user_');
    $db->InParameter($stmt, $rand_, 'rand_');
    $db->OutParameter($stmt, $reg, 'reg', 32); # return varchar(32)
    $db->InParameter($stmt, $tipoCampana, 'tipoCampana');
    $rs = $db->ExecuteCursor($stmt, 'rc');

//    echo "<pre>";
//    print_r($rs);
//    echo "</pre>";
//    die();
//    exit();

    return $rs;
}

function set_califica_telefono($telefono, $cal_tel, $num_tel, $db) {
    //echo $cal_tel;
    //die();
    set_session_varname("caltelefono" . $num_tel, $cal_tel);

    $stmt = $db->PrepareSP("BEGIN spU_setRegistroTelefonico(:iRegTelefono, :iStatusLlamada); END;");
    $db->InParameter($stmt, $telefono, 'iRegTelefono');
    $db->InParameter($stmt, $cal_tel, 'iStatusLlamada');
    $db->Execute($stmt);
}

#####  INSERT UN NUEVO REGISTRO EN BASE

function set_registro_especifico($campana, $usr_id, $nombre, $paterno, $materno, $rfc, $fec_nacimiento, $pais, $lada, $telefono, $localizacion, $tipobase, $db) {
//    $stmt = $db->PrepareSP("BEGIN xsp_insertaRegistroTelefonico(:campana, :usr_id, :nombre, :paterno, :materno, :rfc, :fec_nacimiento, :pais, :lada, :telefono, :localizacion, :u_persona, :u_telefono, :u_registro); END;");
    $stmt = $db->PrepareSP("BEGIN xsp_insertaRegistroTelefonico2(:campana, :usr_id, :nombre, :paterno, :materno, :rfc, :fec_nacimiento, :pais, :lada, :telefono, :localizacion, :u_persona, :u_telefono, :u_registro, :tipobase,:mensaje_error); END;");
    $db->InParameter($stmt, $campana, 'campana');
    $db->InParameter($stmt, $usr_id, 'usr_id');
    $db->InParameter($stmt, $nombre, 'nombre');
    $db->InParameter($stmt, $paterno, 'paterno');
    $db->InParameter($stmt, $materno, 'materno');
    $db->InParameter($stmt, $rfc, 'rfc');
    $db->InParameter($stmt, $fec_nacimiento, 'fec_nacimiento');
    $db->InParameter($stmt, $pais, 'pais');
    $db->InParameter($stmt, $lada, 'lada');
    $db->InParameter($stmt, $telefono, 'telefono');
    $db->InParameter($stmt, $localizacion, 'localizacion');
    $db->OutParameter($stmt, $u_persona, 'u_persona');
    $db->OutParameter($stmt, $u_telefono, 'u_telefono');
    $db->OutParameter($stmt, $u_registro, 'u_registro');
    $db->InParameter($stmt, $tipobase, 'tipobase');
    $db->OutParameter($stmt, $mensaje_error, 'mensaje_error');
    $db->Execute($stmt);

    return $u_persona . '-' . $u_telefono . '-' . $u_registro . '-' . $mensaje_error;
}


function set_valida_solicitud_capturada($id_registro, $db) {
    $stmt = $db->PrepareSP("BEGIN xsp_isSolicitudOK(:id_solicitud, :res); END;");
    $db->InParameter($stmt, $id_registro, 'id_solicitud');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}
*/

function libera_extension($extension, $db) {
    $stmt = $db->PrepareSP("BEGIN spU_LiberarExtensiones(:extension, :res); END;");
    $db->InParameter($stmt, $extension, 'extension');
    $db->OutParameter($stmt, $res, 'res');
    $db->Execute($stmt);
    return $res;
}