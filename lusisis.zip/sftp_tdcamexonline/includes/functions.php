<?php
require 'PHPMailer/PHPMailerAutoload.php';

class Logger {
  private $db;

  public function __construct($db) {
    $this->db = $db;
  }

  public function log($texto, $estatus, $opcion) {
    echo "<hr> PASO: {$texto} ESTATUS: {$estatus}";
    $rspta = $this->guardarLogSFTP($texto, $estatus, $opcion);
    $this->valida($rspta);    
  }
  private function guardarLogSFTP($texto, $estatus, $opcion) {
    $tipo = 'CARGA_AUT';
    try {
        $this->db->SetFetchMode(ADODB_FETCH_BOTH);
        $query = "BEGIN TDCAMEXONLINE.SPI_CARGA_AUT_LEADS(:v_estatus, :v_comentarios, :v_tipo, :v_opcion, :rc); END;";
        $stmt = $this->db->PrepareSP($query);
        $this->db->InParameter($stmt, $texto, 'v_comentarios');
        $this->db->InParameter($stmt, $estatus, 'v_estatus');
        $this->db->InParameter($stmt, $tipo, 'v_tipo');
        $this->db->InParameter($stmt, $opcion, 'v_opcion');
        $rs = $this->db->ExecuteCursor($stmt, 'rc');
        
        if (empty($rs->_array)) {
            return "SIN_DATOS";
        } else {
            return $rs->_array[0]['RESPONSE'];
        }
    } catch (Exception $e) {
        // return "ERROR" . $e->getMessage();
        return "ERROR";
    }
  }
  private function valida($rspta) {
    if ($rspta == 1) { // Cambiado $data a $rspta
        echo 'EXITO<br>';
    } else {
        echo 'ERROR<br>';
        //notificar error        
    }
  }
}

class DataInserter {
  private $db;
  public function __construct($db) {
    $this->db = $db;
  }
  
  public function insertData($data) {
    try {
          $this->db->SetFetchMode(ADODB_FETCH_BOTH);
          $query = "BEGIN tdcamexonline.SPI_SAVE_DATA_SFTP(:v_id,:v_fecha_leads,:v_nombres,:v_a_Paterno,:v_a_Materno,:v_rfc,:v_telefono,:v_email,:v_tarjeta_Solicitada,:v_score_Buro,:v_tnkPage_Aterrizaje,:v_cpid,:v_campana,:v_id_Unico,:v_origen,:v_comentarios1,:v_comentarios2,:v_comentarios3,:v_comentarios4,:v_comentarios5,:v_comentarios6,:v_comentarios7,:v_comentarios8,:v_comentarios9,:v_comentarios10,:v_suscripcion,:v_user_Agent,:v_fbc,:v_fbp,:v_ingresos,:v_sexo,:v_pais_Nacimiento,:v_estado_Nacimiento,:v_nacionalidad,:v_calle,:v_num_Int,:v_colonia,:v_codigo_Postal,:v_municipio,:v_estado_Residencia,:v_ciudad,:v_tiempo_Residencia,:v_tipo_Vivienda,:v_estatus_Laboral,:v_compania,:v_tipo_Industria,:v_tipo_C_Empresa,:v_puesto,:v_puntos_Rewards,:v_tarjetas_Credito,:v_digitos_Tarjeta,:v_credito_Auto,:v_hipoteca,:v_autorizacion,:v_492_via_email,:v_wild_Card1,:v_wild_Card2,:v_wild_Card3,:v_arch,:v_id_Origen_Archivo, :v_f_Hig,  :v_operable,:v_desc_No_Op,:v_if_Arch,:v_h_Arch,:rc); END;";
          $stmt = $this->db->PrepareSP($query);          
          $this->db->InParameter($stmt,$data['dato_0'], 'v_id');
          $this->db->InParameter($stmt,$data['dato_1'], 'v_fecha_leads');
          $this->db->InParameter($stmt,$data['dato_2'], 'v_nombres');   
          $this->db->InParameter($stmt,$data['dato_3'], 'v_a_Paterno');   
          $this->db->InParameter($stmt,$data['dato_4'], 'v_a_Materno');  
          $this->db->InParameter($stmt,$data['dato_5'], 'v_rfc');   
          $this->db->InParameter($stmt,$data['dato_6'], 'v_telefono');   
          $this->db->InParameter($stmt,$data['dato_7'], 'v_email');   
          $this->db->InParameter($stmt,$data['dato_8'], 'v_tarjeta_Solicitada');   
          $this->db->InParameter($stmt,$data['dato_9'], 'v_score_Buro');   
          $this->db->InParameter($stmt,$data['dato_10'], 'v_tnkPage_Aterrizaje');  
          $this->db->InParameter($stmt,$data['dato_12'], 'v_cpid');   
          $this->db->InParameter($stmt,$data['dato_13'], 'v_campana');   
          $this->db->InParameter($stmt,$data['dato_14'], 'v_id_Unico');   
          $this->db->InParameter($stmt,$data['dato_15'], 'v_origen');  
          $this->db->InParameter($stmt,$data['dato_16'], 'v_comentarios1');   
          $this->db->InParameter($stmt,$data['dato_17'], 'v_comentarios2');   
          $this->db->InParameter($stmt,$data['dato_18'], 'v_comentarios3');   
          $this->db->InParameter($stmt,$data['dato_19'], 'v_comentarios4');   
          $this->db->InParameter($stmt,$data['dato_20'], 'v_comentarios5');   
          $this->db->InParameter($stmt,$data['dato_21'], 'v_comentarios6');   
          $this->db->InParameter($stmt,$data['dato_22'], 'v_comentarios7');   
          $this->db->InParameter($stmt,$data['dato_23'], 'v_comentarios8');   
          $this->db->InParameter($stmt,$data['dato_24'], 'v_comentarios9');   
          $this->db->InParameter($stmt,$data['dato_25'], 'v_comentarios10');   
          $this->db->InParameter($stmt,$data['dato_26'], 'v_suscripcion');
          $this->db->InParameter($stmt,$data['dato_27'], 'v_user_Agent');   
          $this->db->InParameter($stmt,$data['dato_28'], 'v_fbc');   
          $this->db->InParameter($stmt,$data['dato_29'], 'v_fbp');
          $this->db->InParameter($stmt,$data['dato_30'], 'v_ingresos');
          $this->db->InParameter($stmt,$data['dato_31'], 'v_sexo');        
          $this->db->InParameter($stmt,$data['dato_32'], 'v_pais_Nacimiento');   
          $this->db->InParameter($stmt,$data['dato_33'], 'v_estado_Nacimiento');   
          $this->db->InParameter($stmt,$data['dato_34'], 'v_nacionalidad');   
          $this->db->InParameter($stmt,$data['dato_35'], 'v_calle');    
          $this->db->InParameter($stmt,$data['dato_36'], 'v_num_Int');   
          $this->db->InParameter($stmt,$data['dato_37'], 'v_colonia');   
          $this->db->InParameter($stmt,$data['dato_38'], 'v_codigo_Postal');   
          $this->db->InParameter($stmt,$data['dato_39'], 'v_municipio');
          $this->db->InParameter($stmt,$data['dato_40'], 'v_estado_Residencia');
          $this->db->InParameter($stmt,$data['dato_41'], 'v_ciudad');
          $this->db->InParameter($stmt,$data['dato_42'], 'v_tiempo_Residencia');
          $this->db->InParameter($stmt,$data['dato_43'], 'v_tipo_Vivienda');
          $this->db->InParameter($stmt,$data['dato_44'], 'v_estatus_Laboral');   
          $this->db->InParameter($stmt,$data['dato_45'], 'v_compania');   
          $this->db->InParameter($stmt,$data['dato_46'], 'v_tipo_Industria');   
          $this->db->InParameter($stmt,$data['dato_47'], 'v_tipo_C_Empresa');   
          $this->db->InParameter($stmt,$data['dato_48'], 'v_puesto');
          $this->db->InParameter($stmt,$data['dato_49'], 'v_puntos_Rewards');
          $this->db->InParameter($stmt,$data['dato_50'], 'v_tarjetas_Credito');   
          $this->db->InParameter($stmt,$data['dato_51'], 'v_digitos_Tarjeta');   
          $this->db->InParameter($stmt,$data['dato_52'], 'v_credito_Auto');   
          $this->db->InParameter($stmt,$data['dato_53'], 'v_hipoteca');
          $this->db->InParameter($stmt,$data['dato_54'], 'v_autorizacion');
          $this->db->InParameter($stmt,$data['dato_55'], 'v_492_via_email');
          $this->db->InParameter($stmt,$data['dato_56'], 'v_wild_Card1');   
          $this->db->InParameter($stmt,$data['dato_57'], 'v_wild_Card2');   
          $this->db->InParameter($stmt,$data['dato_58'], 'v_wild_Card3');   
          $this->db->InParameter($stmt,$data['dato_59'], 'v_arch');   //nombre del archivo
          $this->db->InParameter($stmt,$data['dato_60'], 'v_id_Origen_Archivo'); //origen archivo
          $this->db->InParameter($stmt,$data['dato_61'], 'v_f_Hig');  
          $this->db->InParameter($stmt,$data['dato_62'], 'v_operable');   
          $this->db->InParameter($stmt,$data['dato_63'], 'v_desc_No_Op');   
          $this->db->InParameter($stmt,$data['dato_64'], 'v_if_Arch');   
          $this->db->InParameter($stmt,$data['dato_65'], 'v_h_Arch');          
          
          $rs = $this->db->ExecuteCursor($stmt, 'rc');
          return $rs->_array[0]['RESPONSE'];
      } catch (Exception $e) {        
          return "ERROR";
          // return $e;
      }
  }
  public function valida($rspta) {
    if ($rspta == 1) { // Cambiado $data a $rspta
        echo 'EXITO<br>';
    } else {
        echo 'ERROR<br>';
        //notificar error        
    }
  }

}




class Capi {
  private $apiUrl;

    public function __construct() {
        $this->apiUrl = 'http://172.20.1.95/api_fueralinea/main6.php'; // URL fija
    }

    public function enviarRegistroMain6($data) {
        $params = array(
          'datos14' => $data["dato_14"],
          'datos7'  =>  $data["dato_7"],
          'datos6'  => $data["dato_6"],
          'datos26' => $data["dato_26"],
          'datos27' => $data["dato_27"],
          'datos28' => $data["dato_28"],
          'datos10' => $data["dato_10"],
          'datos8'  => $data["dato_8"],
          'datos17' => $data["dato_17"],
          "event"   => 7 // CompleteRegistration
        );        

        $defaults = array(
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_RETURNTRANSFER => true
        );

        $ch = curl_init();
        curl_setopt_array($ch, $defaults);
        $r = curl_exec($ch);
        curl_close($ch);

        return $r;
    }
}



class FileMover {
  public function moveFile($value,$opcion){
    $folder='leads_Temporal/';
    $folder_destino = $opcion ==1 ? 'leads_Respaldo/':'leads_Errores/';     
    if (file_exists($folder.$value)) {
        echo '<br> ARCHIVO TRANSFERIDO A LA CARPETA: '.$folder_destino.$value; 
        copy($folder.$value,$folder_destino.$value);
        unlink('leads_Temporal/'.$value);         
        // rename($folder.$value,$folder_destino.$value);
    }else {
        echo 'NO EXISTE EL ARCHIVO => '.$value;
    } 
  }
}

function notify($option,$data){
  $asunto = "PRUEBA ERROR EN CARGA LEADS ONLINE";
  switch ($option) {
    case 1:
    //sms             
      $telefonos = array("DANIEL" => 4428450036,"VICKY" => 9717185016,"Luis dsa" => 4411003234);
      foreach ($telefonos as $tel => $value) {        
        $ch = curl_init('172.20.1.95/sms_hsbc/index2.php');               
        curl_setopt($ch, CURLOPT_POST, 1);   
        curl_setopt($ch, CURLOPT_POSTFIELDS, array(
           'numero' => $value ,
           'proveedor' => 6,
           'campana' => 1008,
           'mensaje' => $asunto
         ));         
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);           
        $respuesta_api = curl_exec($ch);           
        $error_api = curl_error($ch);           
        curl_close($ch);
      } 

    break;
    case 2:
    //mail
      $rs3 = array(
        "DESARROLLO" => 'dsa@impulse-telecom.com',        
        "IM FER" => 'lolvera@impulse-telecom.com'        
      );
      $mensaje = "
                  <div style='background: #d8fdf8;'>
                  <p> <b style='color: red;'> Error </b> en la carga de leads de ONLINE</p>
                  <p> Archivo: $data</p>
                  </div>
                 ";
      $emailSender = new EmailSender("mail.impulse-telecom.com.mx", 587, "reportes@impulse-telecom.com", "R3p0rt32016");

      foreach ($rs3 as $key => $value) {
        $correoEnviado = $emailSender->sendEmail($value, $asunto, $mensaje);
        if ($correoEnviado) {
          echo '<hr>Correo Enviado';
        } else {
          echo 'Correo no enviado';
        }
      }


    break;
    default:
      echo 'prueba';
    break;
  }
}

class EmailSender {
  private $smtpHost;
  private $smtpPort;
  private $smtpUsername;
  private $smtpPassword;

  public function __construct($smtpHost, $smtpPort, $smtpUsername, $smtpPassword) {
      $this->smtpHost = $smtpHost;
      $this->smtpPort = $smtpPort;
      $this->smtpUsername = $smtpUsername;
      $this->smtpPassword = $smtpPassword;
  }

  public function sendEmail($recipient, $subject, $message) {    
    // require 'PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    $mail->Debugoutput = 'html';
    $mail->Host = $this->smtpHost;
    $mail->Port = $this->smtpPort;
    $mail->SMTPAuth = true;
    $mail->Username = $this->smtpUsername;
    $mail->Password = $this->smtpPassword;
    $mail->setFrom($this->smtpUsername, 'impulse telecom');
    $mail->addAddress($recipient, '');
    $mail->Subject = $subject;
    $mail->msgHTML($message);

    if (!$mail->send()) {
        return false; // Error al enviar el correo
    } else {
        return true; // Correo enviado exitosamente
    }
  }
}

class RemoveAccents {
  public function quitarAcentos($texto) {
      $acentos = array('á', 'é', 'í', 'ó', 'ú', 'ü', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ü', 'ñ', 'Ñ');
      $sinAcentos = array('a', 'e', 'i', 'o', 'u', 'u', 'A', 'E', 'I', 'O', 'U', 'U', 'n', 'N');      
      $textoSinAcentos = str_replace($acentos, $sinAcentos, $texto);
      $textoLimpio = trim($textoSinAcentos);
      $textoRecortado = substr($textoLimpio, 0, 254);
      return $textoRecortado;
  }
}
 