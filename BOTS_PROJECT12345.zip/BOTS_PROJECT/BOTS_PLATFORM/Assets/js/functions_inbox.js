let activeSessionId = null;

const socket = io("http://localhost:4001", {
  auth: {
    type: "crm",
  },
});

socket.on("connect", () => {
  console.log("✅ Inbox conectado:", socket.id);
});

socket.emit("inbox:init");

socket.on("inbox:conversations", (conversations) => {
  renderConversationList(conversations);
});

function renderConversationList(conversations) {
  const container = document.getElementById("conversation-list");
  container.innerHTML = "";

  console.log(conversations);

  conversations.forEach((c) => {
    const statusLabel =
      c.status === "bot"
        ? `<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Bot</span>`
        : c.status === "human"
        ? `<span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Agente</span>`
        : `<span class="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">Cerrado</span>`;

    const item = document.createElement("div");
    item.className = "p-4 bg-white hover:bg-gray-50 cursor-pointer";
    item.dataset.session = c.session_uuid;

    item.innerHTML = `
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">
            ${c.name}
          </span>
          ${statusLabel}
        </div>
        <p class="text-sm text-gray-500 truncate">
          ${c.last_message || "Sin mensajes"}
        </p>
      `;

    item.addEventListener("click", () => {
      openConversation(c);
    });

    container.appendChild(item);
  });
}

function openConversation(chat) {
  activeSessionId = chat.session_uuid;

  // Header
  document.getElementById("chat-user-name").textContent =
    chat.name || "Anónimo";

  document.getElementById(
    "chat-bot-status"
  ).textContent = `🤖 ${chat.bot_name} · IA activa`;

  document.getElementById("chat-status-badge").textContent = "Abierto";

  // Limpiar mensajes
  document.getElementById("chat-messages").innerHTML = "";

  // pedir historial al backend
  socket.emit("inbox:load_messages", {
    session_uuid: activeSessionId,
  });

  console.log("📤 Evento inbox:load_messages emitido");
}

socket.on("inbox:messages", (messages) => {
    console.log(messages);
    messages.forEach(msg => {
      renderMessage(msg);
    });
  });

function renderMessage({ role, message_text }) {
  const container = document.getElementById("chat-messages");

  const wrapper = document.createElement("div");

  if (role === "user") {
    wrapper.className = "flex justify-start";
    wrapper.innerHTML = `
        <div class="bg-gray-200 px-4 py-2 rounded-lg max-w-md">
          ${message_text}
        </div>
      `;
  }

  if (role === "assistant") {
    wrapper.className = "flex justify-end";
    wrapper.innerHTML = `
        <div class="bg-indigo-600 text-white px-4 py-2 rounded-lg max-w-md">
          ${message_text}
        </div>
      `;
  }

  if (role === "agent") {
    wrapper.className = "flex justify-end";
    wrapper.innerHTML = `
        <div class="bg-green-600 text-white px-4 py-2 rounded-lg max-w-md">
          ${message_text}
        </div>
      `;
  }

  if (role === "system") {
    wrapper.className = "flex justify-center";
    wrapper.innerHTML = `
        <div class="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
          ${message_text}
        </div>
      `;
  }

  container.appendChild(wrapper);
  container.scrollTop = container.scrollHeight;
}