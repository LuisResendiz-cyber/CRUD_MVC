<?php
# @uthor Mark 
# Process_data File en NOMINA

require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize_nolayout("mesa_control","");

$action = $_REQUEST['act'];
$header = "index.php";

if (isset($action) && $action == 4){ ## ACCION PARA ASIGNAR O DESASIGNAR LA ZONA A UN USUARIO #

	$izona = $_REQUEST['izona'];
	$iusr_id = $_REQUEST['iusr_id'];
	$calificacion = $_REQUEST['calificacion'];
	set_asigna_zona($izona, $iusr_id, $calificacion, $db);
	die();

} elseif (isset($action) && $action == 5){ ## ACCION PARA ASIGNAR O DESASIGNAR LA ZONA A UN USUARIO #

	$izona = $_REQUEST['izona'];
	$calificacion = $_REQUEST['calificacion'];
	set_activa_zona($izona, $calificacion, $db);
	die();

} elseif (isset($action) && $action == 6){ ## CARGA EL ARCHIVO Y ACTUALIZA DATOS #
    
    delete_from_folios_campana($db);

    if ($_POST["action_val"] == "upload") {
        $tamano = $_FILES["fichero"]['size'];
        $tipo = $_FILES["fichero"]['type'];
        $archivo = $_FILES["fichero"]['name'];
        $prefijo = rand();

        if ($archivo != "") {
            $destino = "modules/mesa_control/archivo_carga_full_ccupdate.txt";
            if (copy($_FILES['fichero']['tmp_name'], $destino)) {
                set_data_folios_camapana();
                $header = "modules.php?mod=mesa_control&op=subeArchivo";
            } else {
                $header = "modules.php?mod=mesa_control&op=subeArchivo&e=1";
            }
        } else {
            $header = "modules.php?mod=mesa_control&op=subeArchivo&e=2";
        }
    }	

} elseif (isset($action) && $action == 7){ ## CLASIFICA LA INFORMACION QUE SE CARGO EN EL ARCHIVO

		$key = time();

		$clasifica_datos = set_data_clasification($key, $db);

		if ($clasifica_datos <= 50000){
			$header = "modules.php?mod=mesa_control&op=subeArchivo&e=3&c=".$clasifica_datos."&ky=".$key;
		}else{
			 $header = "modules.php?mod=mesa_control&op=subeArchivo&e=4";
		}
} elseif (isset($action) && $action == 8) { ## GENERA EL REPORTE DE CARGA

		$ky = $_REQUEST['ky'];
		$header = "modules.php?mod=mesa_control&op=reporteCarga&ky=".$ky;
		header("location: ".$header);
}

header("location: ".$header);
?>