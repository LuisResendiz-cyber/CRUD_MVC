document.addEventListener("DOMContentLoaded", () => {

  const chatBody = document.querySelector(".chat-body");
  const input = document.querySelector(".chat-footer input");
  const sendBtn = document.querySelector(".chat-footer button");
  const wasClosed = localStorage.getItem("chatClosed") === "true";

  if (!localStorage.getItem("chat_session_id")) {
    localStorage.setItem("chat_session_id", crypto.randomUUID());
  }

  const sessionId = localStorage.getItem("chat_session_id");

  let isTyping = false;
  let chatClosed = false;


  const socket = io("http://localhost:4001", {
    transports: ["websocket"],
    auth: {
      session_id: sessionId,
      bot_id: 2
    }
  });

  input.disabled = false;
  sendBtn.disabled = false;

  function addMessage(text, type) {
    console.log(type);
    const msg = document.createElement("div");
    msg.className = `message ${type}`;
    msg.innerHTML = `<div class="bubble">${text}</div>`;
    chatBody.appendChild(msg);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  let typing = null;

  function showTyping() {
    if (typing) return;
  
    typing = document.createElement("div");
    typing.className = "message bot typing";
    typing.innerHTML = `
      <div class="bubble typing-indicator">
        <span></span><span></span><span></span>
      </div>
    `;
  
    chatBody.appendChild(typing);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
  
  
  

  function hideTyping() {
    isTyping = false;
    typing?.remove();
    typing = null;
  }

  sendBtn.onclick = sendMessage;
  //input.onkeydown = e => e.key === "Enter" && sendMessage();

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendMessage();
    }
  });
  

  function sendMessage() {
    if (chatClosed) return; 

    const text = input.value.trim();
    if (!text) return;
  
    input.value = "";
    addMessage(text, "user");
  
    botThinking = true;          // 🔴 CLAVE
    showTyping();
    resetInactivityTimers();
  
    socket.emit("user_message", text);
  }

  socket.on("new_message", (data) => {
    hideTyping();
    botThinking = false;
    addMessage(data.message_text, data.role);
    resetInactivityTimers();
  });

  socket.on("new_message", (data) => resetInactivityTimers());


  async function loadChatHistory() {
    try {
      const response = await fetch(
        `http://localhost:4001/apiV1/history/${sessionId}`
      );
      const data = await response.json();
  
      if (data.messages) {
        data.messages.forEach((msg) => {
          addMessage(
            msg.message_text,
            msg.role === "user" ? "user" : "bot"
          );
  
          lastMessageId = msg.id_webhook;
        });
      }
    } catch (err) {
      console.error("Error cargando historial", err);
    }
  }
  
  loadChatHistory();

  let inactivityTimer = null;
let warningTimer = null;

function resetInactivityTimers() {
  clearTimeout(inactivityTimer);
  clearTimeout(warningTimer);

  // ⛔ Si el bot está pensando, NO iniciar timers
  if (botThinking) return;

  inactivityTimer = setTimeout(showInactivityWarning, 0.5 * 60 * 1000);
}


function showInactivityWarning() {
  // ⛔ Si el bot sigue pensando, NO avisar
  if (botThinking) return;

  console.log(localStorage.getItem("chatClosed"));

  let chatClosed = localStorage.getItem("chatClosed");

  if (!chatClosed) {    
    addMessage(
      "¿Sigues ahí? El chat se cerrará en 1 minuto por inactividad ⏳",
      "bot"
      );
    }

  warningTimer = setTimeout(() => {
    if (!botThinking) closeChatAutomatically();
  }, 60 * 1000);
}

function disableChatInput() {
  input.disabled = true;
  sendBtn.disabled = true;
}

socket.on("chat_closed", () => {

  if (chatClosed) return; // ⛔ evita duplicados

  chatClosed = true;
  localStorage.setItem("chatClosed", "true");

  hideTyping();

  addMessage(
    "El chat se cerró por inactividad.",
    "bot"
  );

  showReactivateButton();
  disableChatInput();
});


function closeChatAutomatically() {
  hideTyping();
  socket.emit("chat_idle");
}


function showReactivateButton() {
  if (document.querySelector(".reactivate-link")) return;

  const wrapper = document.createElement("div");
  wrapper.className = "system-action";

  const link = document.createElement("span");
  link.className = "reactivate-link";
  link.textContent = "Reactivar chat";

  link.onclick = () => {
    reactivateChat();
    wrapper.remove();
  };

  wrapper.appendChild(link);
  chatBody.appendChild(wrapper);
  chatBody.scrollTop = chatBody.scrollHeight;
}

function reactivateChat() {
  chatClosed = false;
  localStorage.removeItem("chatClosed");

  document.getElementById("chat-status").innerHTML = "";

  botThinking = false;

  input.disabled = false;
  sendBtn.disabled = false;
  resetInactivityTimers();
  socket.emit("chat_reactivate");
  addMessage("El chat ha sido reactivado 😊", "bot");
}

if (wasClosed) {
  chatClosed = true;
  showChatClosedState();
}

function showChatClosedState() {
  const status = document.getElementById("chat-status");

  status.innerHTML = `
    <div class="chat-closed-banner">
      <span>El chat se cerró por inactividad.</span>
      <a href="#" class="reactivate-link">Reactivar chat</a>
    </div>
  `;

  status.querySelector(".reactivate-link").onclick = (e) => {
    e.preventDefault();
    reactivateChat();
  };

  disableChatInput();
}
});

