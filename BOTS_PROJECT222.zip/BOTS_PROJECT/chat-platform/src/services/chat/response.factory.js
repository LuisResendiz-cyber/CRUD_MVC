// services/chat/response.factory.js

module.exports = {
    bot(text) {
      return {
        type: "BOT",
        message: text
      };
    },
  
    human() {
      return {
        type: "HUMAN",
        message: "Un asesor continuará la conversación contigo."
      };
    }
  };
  