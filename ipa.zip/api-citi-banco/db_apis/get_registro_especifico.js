const oracledb = require('oracledb');
const database = require('../services/database.js');

// async function find(context){
//   console.log(context);
//   const baseQuery = "BEGIN " + context.schema + ".XSP_GETREGISTROESPECIFICO(:registro, :u_user, :tipo_campana, :u_persona, :keys, :rc ); END;";
// 	let query = baseQuery;
// 	const binds = {};
//   let result2 = {};
//
//   if(!context.registro || !context.u_user || !context.tipo_campana || !context.u_persona){
//     //console.log("Parametros incorrectos")
//     result2.error_ = true;
//     result2.mensaje = "Parametros Erroneos";
//     return result2;
//
//   } else{
//     binds.registro = context.registro;
//     binds.u_user = context.u_user;
//     binds.tipo_campana = context.tipo_campana;
//     binds.u_persona = context.u_persona;
//     binds.keys = '1';
//     binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
//     console.log(binds);
//     const result = await database.simpleExecuteRC(query, binds);
//     console.log(result);
//     return result;
//   }
// }


async function give(context){
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".XSP_GETREGISTROESPECIFICO(:registro, :u_user, :tipo_campana, :u_persona, :rc ); END;";
  let query = baseQuery;

  const binds = {};
  let result2 = {};

  if(!context.registro || !context.u_user || !context.tipo_campana || !context.u_persona ){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    console.log(result2);
    return result2;

  } else{
    binds.registro = context.registro;
    binds.u_user = context.u_user;
    binds.tipo_campana = context.tipo_campana;
    binds.u_persona = context.u_persona;
    // binds.keys      = context.keyrig;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    console.log(binds);
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;

  }
}

// module.exports.find = find;
module.exports.give = give;
