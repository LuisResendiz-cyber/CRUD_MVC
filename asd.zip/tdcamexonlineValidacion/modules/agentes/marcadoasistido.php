
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$nomina = $_REQUEST['nomina'];

echo 'Llamando';
echo telefono;
echo $nomina;
echo 'Solicitud';

//172.21.0.1/click2dial/marcadoasistido.php?employeeid=546555&exten=01555555555&sicallVarSolicitud=233443

print ('<br/><img src="includes/imgs/loading.gif"/>');

?>
