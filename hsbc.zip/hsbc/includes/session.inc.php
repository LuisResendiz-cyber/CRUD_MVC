<?php

# @uthor Mark
# Session File

//require_once("includes.inc.php");

# LOAD THE SESSION AND VERIFY IT IS LOGGED_IN

function load_session() {
	session_start();
	return is_logged();
}

#  UNSET ALL SESSION VARS

function unload_session($db) {
	if (strlen(get_session_varname("s_usr_id")) > 0 && get_session_varname("logged")) {
		set_session_usuario('0', get_session_varname("s_usr_id"));
	}
	session_unset();
}

# SET A SESSION VARNAME

function set_session_varname($varname, $value_varname) {
	$_SESSION[$varname] = $value_varname;
}

# GET A SESSION VARNAME

function get_session_varname($varname) {
	if (isset($_SESSION[$varname]))
		return $_SESSION[$varname];
	else
		return false;
}

# VERIFY IF USER IS LOGGED IN

function is_logged() {
	global $db;
	global $sessiontimeout;
	if (get_session_varname("logged") && time() - get_session_varname("time") < $sessiontimeout) {
		set_session_varname("time", time());
		return true;
	} else {
		unload_session($db);
		return false;
	}
}

# UNSET A SINGLE VARNAME SESSION

function unset_session_varname($varname) {
	unset($_SESSION[$varname]);
}

# GET SESSION ID

function session_get_id() {
	return session_id();
}

# REALIZA EL TERMINO DE SESSION DEL USUARIO Y CAMBIA EL ESTADO EN BASE DE DATOS

function set_session_usuario($status, $s_usr_id) {
	global $db;
	$stmt = $db->PrepareSP("BEGIN hsbc.xsp_userDesOcupado(:p_id_user); END;");
	$db->InParameter($stmt, $s_usr_id, 'p_id_user');
	$db->Execute($stmt);
}

function set_traking_($id_usr, $evento, $maquina, $id_solicitud, $url, $db) {
	$stmt = $db->PrepareSP("BEGIN XSP_SETEVENTO_LOG(:p_id_user, :p_evento, :p_maquina, :p_id_solicitud, :p_url); END;");
	$db->InParameter($stmt, $id_usr, 'p_id_user');
	$db->InParameter($stmt, $evento, 'p_evento');
	$db->InParameter($stmt, $maquina, 'p_maquina');
	$db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
	$db->InParameter($stmt, $url, 'p_url');
	$db->Execute($stmt);
}

function set_traking($id_usr, $evento, $maquina, $id_solicitud, $url, $db) {
	$stmt = $db->PrepareSP("BEGIN XSP_SETEVENTO(:p_id_user, :p_evento, :p_maquina, :p_id_solicitud, :p_url); END;");
	$db->InParameter($stmt, $id_usr, 'p_id_user');
	$db->InParameter($stmt, $evento, 'p_evento');
	$db->InParameter($stmt, $maquina, 'p_maquina');
	$db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
	$db->InParameter($stmt, $url, 'p_url');
	$db->Execute($stmt);
}

function set_traking_aviso($id_usr, $evento, $maquina, $id_solicitud, $tel_pred, $db) {
	$stmt = $db->PrepareSP("BEGIN XSP_SETEVENTO_AVISO(:p_id_user, :p_evento, :p_maquina, :p_id_solicitud, :p_tel); END;");
	$db->InParameter($stmt, $id_usr, 'p_id_user');
	$db->InParameter($stmt, $evento, 'p_evento');
	$db->InParameter($stmt, $maquina, 'p_maquina');
	$db->InParameter($stmt, $id_solicitud, 'p_id_solicitud');
	$db->InParameter($stmt, $tel_pred, 'p_tel');
	$db->Execute($stmt);
}

##### DEVUELVE INFORMACION DETALLADA DE LOS AGENTES

function get_agente_info_ini($s_usr_id, $db) {
	$rs = $db->ExecuteCursor("BEGIN hsbc.xsp_getUserData(" . $s_usr_id . ", :rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

##### DEVUELVE INFORMACION DETALLADA DE LOS AGENTES

function get_agente_info($s_usr_id, $db) {
	$rs = $db->ExecuteCursor("BEGIN hsbc.xsp_getVentasDetallado2(" . $s_usr_id . ", :rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

### DEVUELVE LOS INDICADORES DETALLADO DE LOS AGENTES

function getindicadores($nomina,$u_user,$db) {
	$stmt = $db->PrepareSP("BEGIN hsbc.SPS_GETINDICADORES(:nomina,:u_user,:rc); END;");
	$db->InParameter($stmt, $nomina, 'nomina');
	$db->InParameter($stmt, $u_user, 'u_user');
	//$db->OutParameter($stmt, $v_predictivo, 'v_predictivo');
	$rc = $db->ExecuteCursor($stmt,'rc');
	return $rc;
}

##### DEVUELVE SI LA CAMPAÃ‘A ESTA EN PREDICTIVO

function get_EsPredictivo($db) {
	$stmt = $db->PrepareSP("BEGIN DBO.SPS_PREDICTIVO(:v_predictivo); END;");
	$db->OutParameter($stmt, $v_predictivo, 'v_predictivo');
	$db->Execute($stmt);
	return $v_predictivo;
}

// DEVULEVE EL PERFIL DEL USUARIO TIPO SICALL
function get_profile_user($nomina, $db) {
	$rs = $db->ExecuteCursor("BEGIN hsbc.SPS_VALIDASUPER (" . $nomina . ",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return ($rs->fields["EXISTE"] != NULL ? $rs->fields["EXISTE"] : 0);
}

// DEVULEVE EL PERFIL DEL USUARIO TIPO AGENTE, AGENTE CON BASE, AGENTE SIN BASE
function get_user_base($s_usr_id, $db) {
	$rs = $db->ExecuteCursor("BEGIN hsbc.CSP_VERIFYUSER_BASE (" . $s_usr_id . ",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return ($rs->fields["TIPO_1"] . $rs->fields["TIPO_2"] . $rs->fields["TIPO_3"]);
}

# REALIZA EL LOGGEO DE USUARIOS

function login($usr_id, $pwd,$ext,$marcacion, $db) {
	if($ext == ''){
		//sacamos extension de ip
		$ip = $_SERVER['REMOTE_ADDR'];
		
		/*if (substr($ip, 0, 6) == '172.20') {
			$ip_number = str_replace("172.20.", "", $ip);
		} else {
			$ip_number = str_replace("172.21.", "", $ip);
		}*/
		
		switch (substr($ip, 0, 7)) {
			case '172.20.': 
				$ip_number = str_replace("172.20.", "", $ip);
				break;
			case '172.21.': 
				$ip_number = str_replace("172.21.", "", $ip);
				break;
			case '192.168': 
				$ip_number = str_replace("192.168.", "", $ip);
				break;
		}    
					
		
		if (strlen($ip_number) <= 4) {
			$ini_ext_ip = substr($ip_number, 1, 1);
			$fin_ext_ip = substr($ip_number, 3, 5);

			if ($ini_ext_ip == '.') {
				$ip_number = str_pad($ip_number, 5, "0", STR_PAD_LEFT);
			} else {
				if ($fin_ext_ip != '.') {
					$ip_number = substr($ip_number, 0, 2) . str_pad($fin_ext_ip, 2, "0", STR_PAD_LEFT);
				}
			}
		} elseif (strlen($ip_number) == 6){
			$ini_ext_ip = substr($ip_number, 0, 2);
			$fin_ext_ip = substr($ip_number, 3, 6);
			
			switch ($fin_ext_ip){
				case "100":
					$fin_ext_ip = str_replace("1","",$fin_ext_ip);
					$ip_number = $ini_ext_ip.$fin_ext_ip;
					break;
				case "200":case "201":case "203":case "204":case "205":case "206":case "207":case "208":case "209":
				case "210":case "211":case "213":case "214":case "215":case "216":case "217":case "218":case "219":
				case "220":case "221":case "223":case "224":case "225":case "226":case "227":case "228":case "229":
					$fin_ext_ip = str_replace("2","",$fin_ext_ip);
					$ip_number = $ini_ext_ip.$fin_ext_ip;
					$ip_number = $ip_number + 100;
					break;
				case "202":case "212":case "222":
					$fin_ext_ip = substr($fin_ext_ip,1,2);
					$ip_number = $ini_ext_ip.$fin_ext_ip;
					$ip_number = $ip_number + 100;
					break;
			}
		}
		
		$extension = str_replace(".", "", $ip_number);
	}else{
		$extension = $ext;
	}
	
	switch ($extension) {
		case "0027":
			$extension = "1076";
			break;
		case "0232":
			$extension = "1065";
			break;
		case "0224":
			$extension = "1063";
			break;
		case "0214":
			$extension = "1069";
			break;
		case "0216":
			$extension = "1064";
			break;
		case "0022":
			$extension = "1070";
			break;
		case "0211":
			$extension = "1106";
			break;
		case "0251":
			$extension = "1068";
			break;
	}
	
	try {
		try{
			$stmt = $db->PrepareSP("BEGIN xsp_AuthCredencial_sicall(:uid_, :pwd,:rc); END;");//,:ext
			$db->InParameter($stmt, $usr_id, 'uid_');
			$db->InParameter($stmt, $pwd, 'pwd');            
			$rs = $db->ExecuteCursor($stmt,'rc');
				
		}catch (Exception $e) {
			echo $e;
			echo '<pre>';var_dump(5);echo '</pre>';die();exit();
			return 17.1;
			die();
			exit();
		}

		if(isset($rs->fields['VALOR']) && $rs->fields['VALOR'] == -1){
			return $rs->fields['V_RESULTADO'];
			die();
			exit();
		}
		
		if(!$rs->EOF){
			$resultado = $rs->fields['V_RESULTADO'];
			$usuario_id = $rs->fields['USUARIO_ID'];
			$s_usr_sesion = 0;
			set_session_varname('s_usr_id',$usuario_id);
			
			if ($resultado == 5 || $resultado == 6 || $resultado == 0) {
				$s_usr_sesion = 1;
			} elseif($resultado == 2){
				// echo 'entro addAttempts' ;
				try {
					$stmt = $db->PrepareSP("BEGIN CSP_ADDATTEMPT(:usr_id); END;");
					$db->InParameter($stmt, $usuario_id, 'usr_id');
					$ok = $db->Execute($stmt);
				   // addAttempts($usuario_id);
				} catch (Exception $e) {
					pa($e->getMessage());
					pa($e->getTrace());
					die();
					exit();
				}

			} elseif($resultado == 12){
				set_session_varname("sch", "HSBC");
				$datos_agente = get_agente_info_ini($rs->fields['USUARIO_ID'], $db);

				set_session_varname("s_usr_marcacion", $marcacion);

				set_session_varname("s_usr_id2", $datos_agente->fields['EMAIL']);
				set_session_varname("s_usr_nombre", $datos_agente->fields['NAME']);
				set_session_varname("s_usr_empresa", $datos_agente->fields['ID_EMPRESA']);
				set_session_varname("s_usr_nomina", $datos_agente->fields['EMAIL']);
				set_session_varname("s_usr_cc", $datos_agente->fields['CC']);
				set_session_varname("es_cumple", $datos_agente->fields['ES_CUMPLE']);//here
				set_session_varname("s_usr_id", $usuario_id);
				set_session_varname("s_usr_pbx", $datos_agente->fields['PBX']);
				set_session_varname('s_pwd', $pwd);
				set_session_varname("time", time());
				set_session_varname("logged", true);            
				set_session_varname("extension", $extension);
				set_session_varname("s_usr_tipo_base", $datos_agente->fields['TIPO']);
				set_session_varname('s_puede_referido', get_PuedeReferido($db));
				set_session_varname("s_usr_centro", $datos_agente->fields['EMPRESA']);
				header("location: " . "modules.php?mod=seguridad&op=index");//&s_usr_id=".$userid."&campaign_id=".$id_campaign
				die();
			}

			if ($s_usr_sesion == 1) {
				set_session_varname("sch", "HSBC");
				$datos_agente = get_agente_info_ini($rs->fields['USUARIO_ID'], $db);
                // var_dump($datos_agente);
                // die();


				// echo "<prev>"; var_dump( $datos_agente); echo "</prev>"; die();exit();
				// if($datos_agente[0]->TIPO == '' && $marcacion == 1){
				//     return 16;
				// }

				// set_session_varname("s_usr_id", $usuario_id);
				// set_session_varname("s_usr_marcacion", $marcacion);
				// set_session_varname("s_usr_nombre", $datos_agente[0]->NAME);
				// set_session_varname("s_usr_nomina", $datos_agente[0]->EMAIL);
				// set_session_varname("festejo", 1);
				// set_session_varname('s_puede_referido', get_PuedeReferido());
				// set_session_varname("s_usr_tipo_base", $datos_agente[0]->TIPO);
				// set_session_varname("s_usr_cc", $datos_agente[0]->CC);
				// set_session_varname("local", $local);
				// set_session_varname("es_cumple", $datos_agente[0]->ES_CUMPLE);
				// set_session_varname("s_usr_centro", $datos_agente[0]->EMPRESA);
				// set_session_varname("s_usr_empresa", $datos_agente[0]->ID_EMPRESA);
				 set_session_varname("s_usr_pbx", $datos_agente->fields['PBX']);
				// set_session_varname("usr_puesto_id", $datos_agente[0]->PUESTO_ID);
				// setcookie('s_usr_centro', $datos_agente[0]->EMPRESA);
				// setcookie('s_usr_empresa', $datos_agente[0]->ID_EMPRESA);
				// setcookie('s_usr_pbx', $datos_agente[0]->PBX);
				// set_session_varname("s_usr_id", $rs[0]->USUARIO_ID);
				set_session_varname("s_usr_id", $usuario_id);
				set_session_varname("s_usr_marcacion", $marcacion);
				set_session_varname("s_usr_nombre", $datos_agente->fields['NAME']);
				set_session_varname("s_usr_nomina", $datos_agente->fields['EMAIL']);
				set_session_varname("festejo", 1);
				set_session_varname('s_puede_referido', get_PuedeReferido($db));
				set_session_varname("s_usr_tipo_base", $datos_agente->fields['TIPO']);
				set_session_varname("s_usr_empresa", $datos_agente->fields['ID_EMPRESA']);
				set_session_varname("s_usr_cc", $datos_agente->fields['CC']);
				set_session_varname("es_cumple", $datos_agente->fields['ES_CUMPLE']);
				set_session_varname("s_usr_centro", $datos_agente->fields['EMPRESA']);
				setcookie('s_usr_centro', $datos_agente->fields['EMPRESA']);
				set_session_varname("s_usr_id", $rs->fields['USUARIO_ID']);

				// if (get_profile_user($rs[0]->ID_USUARIO) >= 1) {
				//     set_session_varname("s_usr_nivel", 'S');
				// } else {
				//     $profile_ = get_user_base($usuario_id);
				//     if (substr($profile_, 0, 1) == '1') {
				//         set_session_varname("s_usr_nivel", 'A'); //AGENTE
				//     } else if (substr($profile_, 1, 1) == '1') {
				//         set_session_varname("s_usr_nivel", 'ACB'); //AGENTE CON BASE
				//     } else if (substr($profile_, 2, 1) == '1') {
				//         set_session_varname("s_usr_nivel", 'ASB'); //AGENTE SIN BASE
				//     } else if (substr($profile_, 3, 1) == '1') {
				//         set_session_varname("s_usr_nivel", 'V'); //VALIDADOR
				//     } else if (substr($profile_, 4, 1) == '1') {
				//         set_session_varname("s_usr_nivel", 'J'); //VALIDADOR
				//     } else{
				//         return 17.2;
				//     }
				// }

				if (get_profile_user($rs->fields['ID_USUARIO'], $db) >= 1) {
					set_session_varname("s_usr_nivel", 'S');
				} else {
					$profile_ = get_user_base($usuario_id, $db);                    
					if (substr($profile_, 0, 1) == '1') {
						set_session_varname("s_usr_nivel", 'A'); //AGENTE
					} else if (substr($profile_, 1, 1) == '1') {
						set_session_varname("s_usr_nivel", 'ACB'); //AGENTE CON BASE    
					} else if (substr($profile_, 2, 1) == '1') {
						set_session_varname("s_usr_nivel", 'ASB'); //AGENTE SIN BASE
					}else{
						return 17.2;
					}
				}


				set_session_varname("extension", $extension);
				set_session_varname("time", time());
				set_session_varname("logged", true);
				set_session_varname("s_usr_maquina", $_SERVER['REMOTE_ADDR']);
				//set_traking(get_session_varname("s_usr_id"), 'INICIO SESION',  0, get_session_varname("s_usr_maquina"), '0');
				set_traking(get_session_varname("s_usr_id"), 'INICIO SESION', get_session_varname("s_usr_maquina"), 0, '', $db);

				if($resul == '2'){
					// set_traking(get_session_varname("s_usr_id"), 'REGRESO PERMISO', 0,  get_session_varname("s_usr_maquina"), '0');
					// $resul = set_autorizacion($usr_id,4);
					set_traking(get_session_varname("s_usr_id"), 'REGRESO PERMISO', get_session_varname("s_usr_maquina"), '', '', $db);
					$resul = set_autorizacion($usr_id,4,$db); 
				}
			}

			// echo "<prev>asasasas"; var_dump($resultado); echo "</prev>"; die();exit();
			return $resultado;
			require_once('closeConnection.php');
		}else{

			return 17.3;
		}

	} catch (Exception $e) {
		die($e->getMessage());
	}
}


##### DEVUELVE SI LA CAMPAÑA PUEDE INGRESAR REFERIDOS
function get_PuedeReferido($db) {
	$v_referido = 0;
	$stmt = $db->PrepareSP("BEGIN DBO.SPS_PUEDE_REFERIDO(:v_referido); END;");
	$db->OutParameter($stmt, $v_referido, 'v_referido');
	$db->Execute($stmt);
	return $v_referido;
}

##### DEVUELVE LA OCC POR AGENTE

function get_occ_agente($nomina, $dbuser, $db) {
	$v_occ = 0;
	$stmt = $db->PrepareSP("BEGIN DBO.xsp_getOccUser(:v_nomina, :v_schema, :v_occ); END;");
	$db->InParameter($stmt, $nomina, 'v_nomina');
	$db->InParameter($stmt, $dbuser, 'v_schema');
	$db->OutParameter($stmt, $v_occ, 'v_occ');
	$db->Execute($stmt);
	return $v_occ;
}

function get_tiempo_llamada($nomina, $dbuser, $db) {
	$tiempo = 0;
	$stmt = $db->PrepareSP("BEGIN DBO.XSP_GETTIMELLAMADAUSER(:v_nomina, :v_schema, :v_tiempo); END;");
	$db->InParameter($stmt, $nomina, 'v_nomina');
	$db->InParameter($stmt, $dbuser, 'v_schema');
	$db->OutParameter($stmt, $tiempo, 'v_tiempo');
	$db->Execute($stmt);
	return $tiempo;
}

/*function get_base_especial($act,$valor1,$valor2,$db){
	$query = "BEGIN hsbc.xsp_editar_bases_especiales(:act,:valor1,:valor2,:result); END;";
	$db->SetFetchMode(ADODB_FETCH_ASSOC);
	$stmt = $db->PrepareSP($query);
	$db->InParameter($stmt, $act, 'act');
	$db->InParameter($stmt, $valor1, 'valor1');
	$db->InParameter($stmt, $valor2, 'valor2');
	$db->OutParameter($stmt, $result, 'result');
	$db->Execute($stmt);    
	return $result;
}*/

function enviar_aviso_privacidad($usr_id, $nomina, $t_registro, $isPredictivo, $u_persona){
	
	if($isPredictivo == 1 && $t_registro == 1){        
		if($empresa == 'ITQ' || $empresa == 'ITS'){
			$url_aviso_privacidad = "http://172.20.1.10/click2dial/hsbc/clearmeetme-aviso.php?employeeid=" . $usr_id;
		}else {
			$url_aviso_privacidad = "http://172.20.19.11/click2dial/hsbc/clearmeetme-aviso.php?employeeid=" . $usr_id;
		}
	}else{
		if($empresa == 'ITQ' || $empresa == 'ITS'){
			$url_aviso_privacidad = "http://172.20.1.10/marcadoasistido/click2dial/hsbc/transfiere-aviso-privacidad.php?agentenomina=".$nomina."&solicitud=".$u_persona;
		}else {
			$url_aviso_privacidad = "http://172.20.19.11/click2dial/hsbc/transfiere-aviso-privacidad.php?agentenomina=".$nomina."&solicitud=".$u_persona;
		}
	}
}

?>
