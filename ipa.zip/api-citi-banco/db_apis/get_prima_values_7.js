const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".xsp_get_prima_values_7_jl(:plan,:formapago,:solicitud,:edad,:rc); END;";

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if( !context.plan || !context.formapago || !context.id_solicitud || !context.edad ){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.plan = context.plan;
    binds.formapago = context.formapago;
    binds.solicitud = context.id_solicitud;
    binds.edad = context.edad;
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);

    return result;
  }


}

module.exports.find = find;
