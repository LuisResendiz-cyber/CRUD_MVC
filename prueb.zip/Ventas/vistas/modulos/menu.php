<aside class="main-sidebar">

	 <section class="sidebar">

		<ul class="sidebar-menu">

		<li class="active">

				<a href="?ruta=inicio">

					<i class="fa fa-home"></i>
					<span>Inicio</span>
				</a>
		</li>

		<?php
		if($_SESSION["perfil"] == "Administrador"){

		echo '<li>
				<a href="?ruta=usuarios">
					<i class="fa fa-user"></i>
					<span>Usuarios</span>
				</a>
			</li>';

		}

		?>
		</ul>
	 </section>
</aside>