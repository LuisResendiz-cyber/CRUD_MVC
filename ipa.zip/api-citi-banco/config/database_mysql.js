// const HR_USER = 'bancomerseg';
// const HR_DATABASE = 'bancomerseg';
// const HR_PASSWORD = 'S6WndSUpjbxu';

// const HR_USER = 'amexinsurance';
// const HR_DATABASE = 'amexinsurance';
// const HR_PASSWORD = 'LNn0YO9EFzizTAbu';

// const HR_USER = 'scotiabank';
// const HR_DATABASE = 'scotiabank';
// const HR_PASSWORD = 'H4kged9jWqiTUY5B';

//const HR_USER = 'invex';
//const HR_DATABASE = 'invex';
//const HR_PASSWORD = 'QEUTYyNG6Sag46Nq';

const HR_USER = 'tdcamexonline';
const HR_DATABASE = 'tdcamexonline';
const HR_PASSWORD = 'tiokVFHyv0qecf5h';

const HR_CONNECTIONSTRING = '127.0.0.1';
module.exports = {
  	objConfiguracion: {
  		connectionLimit:100,
	    host: HR_CONNECTIONSTRING,
	    user: HR_USER,
	    password: HR_PASSWORD,
	    database:HR_DATABASE
	}
};
