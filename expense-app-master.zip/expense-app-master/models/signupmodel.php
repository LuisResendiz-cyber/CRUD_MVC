<?php

class SignupModel extends Model{

    public function __construct(){
        parent::__construct();
    }
}

?>