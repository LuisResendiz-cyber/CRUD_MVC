<?php
namespace Models\Api;

class AuthModel {
    
    public function login($email, $password) {
        $data = [
            'email_user' => $email,
            'passwordHash' => $password // Ya viene hasheado del controlador
        ];
        
        $response = api_post('Users/Login', $data);
        
        if ($response['success']) {
            // Guardar token si la API lo retorna
            if (isset($response['data']['token'])) {
                $_SESSION['api_token'] = $response['data']['token'];
                api_set_token($response['data']['token']);
            }
            
            // Mapear respuesta a formato esperado por tu sistema
            $userData = $response['data']['user'] ?? $response['data'];
            
            return [
                'idpersona' => $userData['idpersona'] ?? $userData['id'] ?? 0,
                'status' => $userData['status'] ?? 1,
                'email_user' => $userData['email_user'] ?? $email,
                'nombres' => $userData['nombres'] ?? $userData['name'] ?? '',
                'apellidos' => $userData['apellidos'] ?? $userData['last_name'] ?? '',
                'rolid' => $userData['rolid'] ?? $userData['role_id'] ?? 2
            ];
        }
        
        // log_api_error('Login failed', [
        //     'email' => $email,
        //     'response' => $response
        // ]);
        
        return false;
    }
    
    public function getUserProfile($userId) {
        $response = api_get("Users/GetUser/{$userId}");
        
        if ($response['success']) {
            $userData = $response['data'];
            
            return [
                'idpersona' => $userData['idpersona'] ?? $userData['id'] ?? $userId,
                'nombres' => $userData['nombres'] ?? $userData['name'] ?? '',
                'apellidos' => $userData['apellidos'] ?? $userData['last_name'] ?? '',
                'email_user' => $userData['email_user'] ?? '',
                'telefono' => $userData['telefono'] ?? $userData['phone_number'] ?? '',
                'rolid' => $userData['rolid'] ?? $userData['role_id'] ?? 2,
                'nombrerol' => $userData['nombrerol'] ?? $userData['role_name'] ?? 'Usuario',
                'status' => $userData['status'] ?? 1
            ];
        }
        
        return false;
    }
    
    public function logout() {
        // Si tu API tiene endpoint para logout
        $response = api_post('Users/Logout');
        
        // Limpiar token de sesión
        unset($_SESSION['api_token']);
        api_set_token(null);
        
        return $response['success'] ?? true;
    }
}
?>