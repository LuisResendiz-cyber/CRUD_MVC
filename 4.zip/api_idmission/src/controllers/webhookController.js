const axios = require("axios");
const https = require("https");
const myslqAccions = require("../models/dbModel");

const agent = new https.Agent({
  rejectUnauthorized: false, // Ignora los certificados autofirmados
});

const webhookImp = {
  send: async (userId, objData) => {
    try {
      const rspt = await myslqAccions.getWebhook(userId);

      if (rspt.length === 0) {
        return false
      }     

      const webhookPromises = rspt.map(async (variable) => {
        return await sendWebhook(variable.LINK, objData);
      });
      const results = await Promise.all(webhookPromises);  
      // console.log('Results from webhooks:', results);

    } catch (error) {
      console.log("Error getting webhooks:", error);
    }
  },
};

const sendWebhook = async (url, objData) => {
  try {
    const { data } = await axios.post(url, objData, {
      headers: {
        "Content-Type": "application/json",
      },
      httpsAgent: agent,
    });

    // console.log("Webhook response data:", data);
    return true;
  } catch (error) {
    console.error(`Error sending webhook to ${url}:`, error.response ? error.response.data : error.message);
    return false;
  }
};


module.exports = webhookImp;
