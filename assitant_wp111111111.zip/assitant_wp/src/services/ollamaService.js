import axios from "axios";

export async function askOllama(systemPrompt, messages) {
  try {
    const response = await axios.post("http://localhost:11434/api/chat", {
      model: "phi3",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages
      ],
      stream: false
    });

    return response.data.message.content;
  } catch (error) {
    console.error("❌ Error llamando a Ollama:", error.message);
    return "Lo siento, hubo un error procesando tu solicitud.";
  }
}
