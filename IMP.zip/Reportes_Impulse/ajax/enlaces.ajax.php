<?php

require_once "../controladores/enlaces.controlador.php";

require_once "../modelos/enlaces.modelo.php";

class AjaxUsuarios{
	/*=============================================
	EDITAR ENLACES
	=============================================*/	
	public $idEnlace;

	public function ajaxEditarEnlace(){
		$item = "id";
		$valor = $this->idEnlace;
		$respuesta = ControladorLigas::ctrMostrarEnlaces($item, $valor);
		echo json_encode($respuesta);
	}
}

/*=============================================
EDITAR ENLACES
=============================================*/
if(isset($_POST["idEnlace"])){
	$editar = new AjaxUsuarios();
	$editar -> idEnlace = $_POST["idEnlace"];
	$editar -> ajaxEditarEnlace();
}