const { Pool } = require('pg');


const ENVIRONMENT = process.env.NODE_ENV;

const pool = new Pool({
  host: ENVIRONMENT === "development" ? '172.20.1.89': '172.20.1.9',
  database: ENVIRONMENT === "development" ? 'cms':'reportes',
  user: ENVIRONMENT === "development" ? 'dtrejo':'usrreportes',
  password: ENVIRONMENT === "development" ? 'dtr3j0':'xmA3cOWa87',
  port: 5432,
});

module.exports = pool;