<?php 
    headerAdmin($data); 
    getModal('modalClientes',$data);
?>
  <main class="app-content">    
      <div class="app-title">
        <div>
            <h1><i class="fas fa-user-tag"></i> <?= $data['page_title'] ?></h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?= base_url(); ?>/clientes"><?= $data['page_title'] ?></a></li>
        </ul>
      </div>
        <div class="row">
            <div class="col-md-12">
              <div class="tile p-0">

              <div class="p-4 border-b bg-white">

<!-- BARRA SUPERIOR -->
<div class="flex items-center justify-between mb-1 gap-4">

  <!-- FILTROS RÁPIDOS (IZQUIERDA) -->
  <div class="flex items-center gap-3 flex-wrap">

    <!-- Buscar conversación -->
    <div class="relative">
      <input
        type="text"
        placeholder="Buscar conversación"
        class="pl-10 pr-4 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
      >
      <span class="absolute left-3 top-2.5 text-gray-400">🔍</span>
    </div>

    <!-- Bot -->
    <select class="px-3 py-2 border rounded-lg text-sm">
      <option>Todos los bots</option>
      <option>Bot Ventas</option>
      <option>Bot Soporte</option>
    </select>

    <!-- Status -->
    <select class="px-3 py-2 border rounded-lg text-sm">
      <option>Todos los status</option>
      <option>Abierto</option>
      <option>Pendiente</option>
      <option>Cerrado</option>
    </select>

  </div>

  <!-- ACCIONES (DERECHA) -->
  <div class="flex items-center gap-3">

    <button class="px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-700">
      + Crear contacto
    </button>

    <button class="px-4 py-2 rounded-lg bg-emerald-500 text-white text-sm hover:bg-emerald-600">
      Exportar
    </button>

    <!-- BOTÓN FILTROS -->
    <button class="px-4 py-2 rounded-lg border border-indigo-600 text-indigo-600 text-sm hover:bg-indigo-50">
      Filtros
    </button>

  </div>
</div>

</div>
              <div class="flex h-[80vh] bg-white rounded-xl border overflow-hidden">

  <!-- INBOX -->
  <aside class="w-80 border-r flex flex-col">

    <!-- Lista de chats -->
    <div class="flex-1 overflow-y-auto divide-y">

      <div class="p-4 bg-gray-100 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">Anonimo</span>
          <span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
            Abierto
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          Hola, necesito información...
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>


      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

      <div class="p-4 hover:bg-gray-50 cursor-pointer">
        <div class="flex justify-between items-center">
          <span class="font-medium text-gray-800">María López</span>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            Pendiente
          </span>
        </div>
        <p class="text-sm text-gray-500 truncate">
          ¿Me pueden ayudar?
        </p>
      </div>

    </div>
  </aside>

  <!-- CHAT -->
  <section class="flex-1 flex flex-col">

    <!-- Header chat -->
    <div class="p-4 border-b flex justify-between items-center bg-white">
      <div>
        <h3 class="font-semibold text-gray-800">Anonimo</h3>
        <p class="text-sm text-indigo-600">
          🤖 Bot Ventas · IA activa
        </p>
      </div>

      <span class="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full">
        Abierto
      </span>
    </div>
    

    <!-- MENSAJES -->
    <div class="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">

      <div class="flex">
        <div class="bg-gray-200 px-4 py-2 rounded-lg max-w-md">
          Hola, quiero información del servicio
        </div>
      </div>

      <div class="flex justify-end">
        <div class="bg-indigo-600 text-white px-4 py-2 rounded-lg max-w-md">
          Claro 😊 ¿en qué puedo ayudarte?
        </div>
      </div>

      <div class="flex">
        <div class="bg-gray-200 px-4 py-2 rounded-lg max-w-md">
          Me interesa saber precios
        </div>
      </div>

    </div>

    <!-- INPUT (PEGADO ABAJO) -->
    <div class="p-4 border-t bg-white">
      <div class="flex gap-2">
        <input
          type="text"
          placeholder="Escribe un mensaje..."
          class="flex-1 border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">
          Enviar
        </button>
      </div>
    </div>

  </section>
</div>

            </div>
        </div>

        
    </main>
<?php footerAdmin($data); ?>
    