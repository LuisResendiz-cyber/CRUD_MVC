<?php
ini_set('memory_limit', '512M');
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
ini_set("session.gc_maxlifetime", 40 * 60); // 40 minutos

ini_set('max_execution_time', 900);
set_time_limit(900);


include "includes/read_leads.php";
include "includes/openConnection.php"; // produccion
// include "includes/openConnection_dsa.php"; // desarrollo

require 'vendor/autoload.php';
use phpseclib\Net\SFTP; /**Libreria para conectarse por SFTP */
  
// CREDENCIALES PRODUCCION
$ftp_user_name = 'amex'; 
$ftp_user_pass = 'Tyn$t&/(q98Flv7#';
// $ftp_user_pass = 'Tyn$t&/(q98Flv7#-';
$ftp_server = '189.211.174.149';
$port='9144';

$sftp = new SFTP($ftp_server,$port);

 if (!$sftp->login($ftp_user_name, $ftp_user_pass)) {
    exit('Login Failed');
}else{
	echo 'Conectado con exito <br>';    
	echo '<hr>';
}   

$sftp->chdir('amex'); /*Aceder a carpetas */

$data= $sftp->nlist();

var_dump($data);
// echo '<hr>';
// start($db);
//   die();
if (sizeof($data) > 0 ) {
	echo '<hr> SERVIDOR CON DATOS';
	foreach ($archivos as $key => $value) {
		if ($sftp->is_file($value)) {
			echo '<hr>Es arch			$df=str_replace( array('.txt','completo'), array(''),$value);
			$arc= explode('_',$df);
				if ($arc[0] !='.' && $arc[0] !='..' ) {
					echo ' <hr> valido'.$arc[0];
					$chose= substr($arc[4],-1);
					var_dump($chose);
					$chose= substr($arc[4],-1);
					if ($chose==1) {
						echo 'Archivo invalido';
						$sftp->get($value, 'folderTemporal/'.$value); 				   
					 }else {
					   echo 'Archivo valido';		 				  
						$sftp->get($value, 'folderTemporal/'.$value); 
	 
						$sftp->rename($value, 'PROCESADOS/'.$value);		 
					 }
				}else {
					echo ' <hr> No valido'.$arc[0];
				}

		}else {
			echo '<hr> No es archivo '.$value;
		}			
	}
	start($db); //funcion leer leads y guardar en base
} else {
	echo '<hr> SIN DATOS';
	log_('SERVIDOR DE ONLINE SIN DATOS',0,$db);
	die();
} 