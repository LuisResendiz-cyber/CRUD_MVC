const axios = require("axios");

const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = process.env.PHONE_NUMBER_ID; 
const WA_API_URL = `https://graph.facebook.com/v19.0/${PHONE_NUMBER_ID}/messages`;

async function sendWhatsAppMessage(to, message) {
  try {
    const payload = {
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body: message }
    };

    console.log(payload);

    const response = await axios.post(WA_API_URL, payload, {
      headers: {
        Authorization: `Bearer ${WHATSAPP_TOKEN}`,
        "Content-Type": "application/json"
      }
    });

    console.log("Mensaje enviado:", response.data);
    return response.data;
  } catch (error) {
    console.log(error);
    console.error("Error enviando mensaje:", error.response?.data || error.message);    
    throw error;
  }
}

module.exports = { sendWhatsAppMessage };