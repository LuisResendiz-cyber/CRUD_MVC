export interface ISurvey {
    CUSTOMER_ID?: number;                // ID de la encuesta, opcional
    NOMBRE?: string;
    AP_PATERNO?: string;
    AP_MATERNO?: string;
    FECHA_NACIMIENTO?: string;
    RFC?: string;
    INGRESOS_FIJOS_COMPROBABLES?: string;
    NACIONALIDAD?: string;
    PAIS_ORIGEN?: string;
    SEXO?: string;
    ESTADO_NACIMIENTO?: string;
    ESTADO_ALTERNO_NACIMIENTO?: string;
    TIPO_ID?: string;
    NUMERO_ID?: string;
    ANTIGUEDAD_VIVIENDA_ANIOS?: string;
    ANTIGUEDAD_VIVIENDA_MESES?: string;
    CALLE?: string;
    NUMERO_EXTERIOR?: string;
    NUMERO_INTERIOR?: string;
    CP?: string;
    COLONIA?: string;
    MUNICIPIO?: string;
    ESTADO?: string;
    LADA?: string;
    TELEFONO?: string;
    TELEFONO_CELULAR?: string;
    CORREO_ELECTRONICO?: string;
    TIPO_VIVIENDA?: string;
    TRABAJADOR_INDEPENDIENTE?: string;
    STATUS_LABORAL?: string;
    TIPO_INDUSTRIA?: string;
    OCUPACION?: string;
    ANTIGUEDAD_EMPRESA_ANIOS?: string;
    ANTIGUEDAD_EMPRESA_MESES?: string;
    NOMBRE_EMPRESA?: string;
    LADA_OFICINA?: string;
    TELEFONO_OFICINA?: string;
    BANCO_REF_1?: string;
    DIGITOS_TDC?: string;
    CREDITO_HIPOTECARIO?: string;
    CREDITO_AUTO?: string;
    TITULAR_TDC?: string;
    ID_PHONE?: string;
    TYPIFICATIONID?: string;
}



export interface IinfoCustomer {
    ID_USER?: string;
    CUSTOMERID?: string;
    NAME?: string;
    LAST_NAME_P?: string;
    LAST_NAME_M?: string;
    PRODUCT_TYPE?: string;
    PRODUCT_1?: string;
    PRODUCT_2?: string;
  }

