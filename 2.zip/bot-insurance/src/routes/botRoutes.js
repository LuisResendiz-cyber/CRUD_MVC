import { Router } from "express";
import { procesarPregunta1, chatStream } from "../controllers/botController.js";

const router = Router();

//router.post("/preguntar", procesarPregunta);
router.post("/chat", chatStream);

export default router;
