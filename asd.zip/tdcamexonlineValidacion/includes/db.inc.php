<?php
# DB Fille		        
# @uthor Mark	        

require_once('includes.inc.php');

//Create a new conection to DB

function getConn(){
	global $dbserver,$dbuser,$dbpassword;
	
	$conn = oci_connect($dbuser, $dbpassword, $dbserver);
	if(!$conn){
		$m = oci_error();
		die("Error al conectarse a la base de datos.<br>Error: ".$m['message']);
	}
	return $conn;
}

//Get the resulset
function get_row($statement){
	return oci_fetch_array ($statement, OCI_NUM);
}

//Execute the query
function execute($query){
	$statement = oci_parse(getConn(), $query);
	$exe = oci_execute($statement);	
	return $statement;
}

//Get num rows
function num_rows($statement){
	return oci_num_rows($statement);
}

//Commit
function commit($conn) {
	return oci_commit($conn);
} 

//Rollback
function rollback($conn) {
	return oci_rollback($conn);
}

// Close the Oracle connection
function closeBD($conn){
	oci_close($conn);
}

?>