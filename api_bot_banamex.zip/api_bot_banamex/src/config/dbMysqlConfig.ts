import dotenv from "dotenv";

import mysql from 'mysql2/promise';
dotenv.config();


const dbName = process.env.DB_MYSQL_NAME;

const dbUser = process.env.DB_MYSQL_USER;

const dbPass = process.env.DB_MYSQL_PASS;

const dbHost = process.env.DB_MYSQL_HOST;

if (!dbName || !dbUser || !dbPass || !dbHost) {
  throw new Error(
    "Not found environment variables"
  );
}


const pool = mysql.createPool({
  host: dbHost,
  user: dbUser,
  password: dbPass,
  database: dbName,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // port:3307
});

export default pool;

 