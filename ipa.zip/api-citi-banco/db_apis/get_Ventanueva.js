const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN "+ context.schema +".xsp_VentaNueva(:v_usuario, :v_solicitud, :v_action, :rc); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};
    
        if(!context.v_usuario || !context.v_solicitud || !context.v_action){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.v_usuario = context.v_usuario;
            binds.v_solicitud = context.v_solicitud;
            binds.v_action = context.v_action;
   			    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;  
                }
}
 
module.exports.find = find;