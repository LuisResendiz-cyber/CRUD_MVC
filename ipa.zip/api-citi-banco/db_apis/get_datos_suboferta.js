const oracledb = require('oracledb');
const database = require('../services/database.js');
 

 
async function find(context) {
    try {        
        const baseQuery = "BEGIN " + context.schema + ".SPS_GET_RESPUESTAS(:customer_id, :choiceId, :rc); END;";//` + context.schema + `
        let query = baseQuery;
	const binds = {};
        let result2 = {};
        binds.customer_id      = context.customer_id;
        binds.choiceId      = context.choiceId;
        binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
        const result = await database.simpleExecuteRC(query, binds); 
        return result;           
    } catch (error) {
        console.log(error);    
    }
}
 
module.exports.find = find;