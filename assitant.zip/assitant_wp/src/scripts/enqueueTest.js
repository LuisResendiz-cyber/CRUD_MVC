const { jobsQueue } = require("../config/queue");

(async () => {
  const job = await jobsQueue.add("test", { message: "Hola desde test" });
  console.log("Job enqueued:", job.id);
})();
