const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

 const baseQuery = "BEGIN " + context.schema + ".SPI_RESPUESTA_CLIENTE_IVR(:v_nomina_agente,:v_u_telefono,:v_solicitud,:v_codigo,:v_respuesta,:v_resultado); END;";
  console.log(context);
   let query = baseQuery;
   const binds = {}; //Define un objeto para la variable SP
   let result2 = {};

   if(!context.nomina || !context.u_telefono || !context.customerid || !context.codigo || !context.respuesta || !context.resultado){
     //console.log("Parametros incorrectos")
     result2.error_ = true;
     result2.mensaje = "Parametros Erroneos";
     return result2;

   }else{

    binds.v_nomina_agente = context.nomina;
    binds.v_u_telefono = context.u_telefono;
    binds.v_solicitud = context.customerid;
    binds.v_codigo = context.codigo;
    binds.v_respuesta = context.respuesta;
    binds.v_resultado = context.resultado;

    const result = await database.simpleExecute(query, binds);
     console.log(result);
    return result;
  }
}

module.exports.find = find;
