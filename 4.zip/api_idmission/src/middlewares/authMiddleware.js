const jwt = require("jsonwebtoken");
const webhookImp = require('../controllers/webhookController')
const JWT_SECRET = process.env.JWT_SECRET;

// Middleware para verificar el token JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  const decoded = jwt.decode(token);

  if (!token)
    return res.status(401).json({ status: "Error", message: "Without token" });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      webhookImp.send(decoded.id,{ status: "Error", details: `Invalid or expired token` })
      return res
        .status(403)
        .json({ status: "Error", message: "Invalid or expired token" });
    }
    req.user = user;
    next();
  });
};


// peticiones solo para el usuario de impulse 
const authenticateImpulse = (req, res, next) => {
  const { userId} = req.body;
  if (userId == 'danieldaniel') {
    return next();
  }else {
    return res.status(400).json({ status: "Error", details: 'User not allowed' });
  }

 
};


module.exports = {authenticateToken,authenticateImpulse};


