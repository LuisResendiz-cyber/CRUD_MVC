const { Server } = require("socket.io");
const {
  processIncomingMessage,
  closeChatByInactivity,
  reopenSession, sendHumanMessage
} = require("../services/MessageFlow.service");

const customerModel = require("../models/webchat.models");

let ioInstance = null;

function initWebSocket(server) {
  const io = new Server(server, {
    cors: { origin: "*" },
  });

  ioInstance = io; // 🔑 CLAVE

  io.on("connection", (socket) => {
    const { session_id, type } = socket.handshake.auth;

     if (type === "crm") {
       socket.join("crm_inbox");
       console.log("🧑‍💼 CRM conectado al inbox");

       socket.on("inbox:init", async () => {
         const conversations = await customerModel.getConversations(1);
         socket.emit("inbox:conversations", conversations);
       });

       socket.on("inbox:load_messages", async ({ session_uuid }) => {
         console.log("📥 Backend recibió inbox:load_messages:", session_uuid);

        const messages = await customerModel.getConversations(2,session_uuid);

         console.log("📤 Mensajes encontrados:", messages.length);

         socket.emit("inbox:messages", messages);
       });
     }

     socket.on("agent_message", async (payload) => {
      try {
        const { session_uuid, agent_id, message } = payload;
    
        const event = await sendHumanMessage(
          session_uuid,
          agent_id,
          message
        );

        await emitConversationUpdate(session_uuid);
    
        // 🔥 Emitir al cliente
        io.to(session_uuid).emit("new_message", event);
    
        // 🔥 Emitir al CRM (otras vistas)
        io.to("crm_inbox").emit("new_message", event);
    
      } catch (error) {
        console.error("❌ Error agent_message:", error.message);
      }
    });


    socket.on("return_to_bot", async ({ session_uuid }) => {
      try {
        console.log("🤖 Devolver sesión al bot:", session_uuid);
    
        await customerModel.setSessionBot(session_uuid);

        await emitConversationUpdate(session_uuid);
    
        const event = {
          session_uuid,
          role: "system",
          message_text: "🤖 La conversación volvió a ser atendida por el bot",
          created_at: new Date(),
        };
    
        // Cliente
        io.to(session_uuid).emit("new_message", event);
    
        // CRM
        io.to("crm_inbox").emit("new_message", event);
    
      } catch (error) {
        console.error("❌ Error return_to_bot:", error.message);
      }
    });
    
    socket.on("quick_replies:load", async ({ id_bot, channel }) => {
      try {
        const replies = await customerModel.getQuickReplies(1, id_bot, channel);
        socket.emit("quick_replies:data", replies);
      } catch (err) {
        console.error("❌ Error cargando quick replies", err);
      }
    });    
    

    if (session_id) {
      socket.join(session_id); // 🔑 CLAVE
    }

    socket.on("user_message", async (text) => {      

      // 👉 PERO sí lo mandamos al CRM
      io.to("crm_inbox").emit("new_message", {
        session_uuid: session_id,
        role: "user",
        message_text: text,
        created_at: new Date(),
      });
    
      // 🧠 Procesar IA
      const result = await processIncomingMessage({
        session_id,
        message: text,
        channel: "web",
      });

      
      await emitConversationUpdate(session_id);

    
      // 🤖 Emitir SOLO respuestas del bot / system
      if (result?.events?.length) {
        result.events.forEach((event) => {
          const payload = {
            session_uuid: session_id,
            role: event.role,
            message_text: event.message_text,
            created_at: event.created_at,
          };
          
          // 👉 bot/system SÍ van al widget
          io.to(session_id).emit("new_message", payload);
    
          // 👉 y también al CRM
          io.to("crm_inbox").emit("new_message", payload);


          
        });
      }
    });
    
    // socket.on("chat_idle", async () => {
    //   console.log("📩 chat_idle recibido en servidor", socket.id, new Date().toISOString());

    //   await closeChatByInactivity(session_id);
    //   io.to(session_id).emit("chat_closed");
    //   socket.emit("chat_closed");
    // });

    // socket.on("chat_idle", async () => {
    //   console.log("📩 chat_idle recibido en servidor", socket.id, new Date().toISOString());
    
    //   await closeChatByInactivity(session_id);
    
    //   const event = {
      //     session_uuid: session_id,
    //     status: "closed",
    //     reason: "inactivity",
    //     updated_at: new Date(),
    //   };
    
    //   // 🔥 Widget
    //   io.to(session_id).emit("chat_closed", event);
    
    //   // 🔥 CRM
    //   io.to("crm_inbox").emit("chat_status_update", event);
    // });

    socket.on("chat_idle", async () => {
      console.log("📩 chat_idle recibido en servidor", socket.id, new Date().toISOString());
    
      await closeChatByInactivity(session_id);
      await emitConversationUpdate(session_id);

    
      const event = {
        session_uuid: session_id,
        status: "closed",
        reason: "inactivity",
        updated_at: new Date(),
      };
    
      // 🔥 Widget
      io.to(session_id).emit("chat_closed", event);
    
      // 🔥 CRM estado
      io.to("crm_inbox").emit("chat_status_update", event);
    
      // 🔥 CRM mensaje visual (coherente con BD)
      io.to("crm_inbox").emit("new_message", {
        session_uuid: session_id,
        role: "system",
        message_text: "Chat cerrado por inactividad del Usuario",
        created_at: new Date(),
      });
    });
    
    
    
    socket.on("chat_reactivate", async () => {
      console.log("⏳ Chat Reactivado:", session_id);
    
      await reopenSession(session_id);
      await emitConversationUpdate(session_id);
      
      const event = {
        session_uuid: session_id,
        status: "open",
        reason: "user_reactivated",
        updated_at: new Date(),
      };
    
      // 🔥 Widget
      io.to(session_id).emit("chat_reopened", event);
    
      // 🔥 CRM - actualiza estado visual
      io.to("crm_inbox").emit("chat_status_update", event);
      
      // 🔥 CRM - muestra mensaje en la conversación
      io.to("crm_inbox").emit("new_message", {
        session_uuid: session_id,
        role: "system",
        message_text: "El chat ha sido reactivado por el Usuario😊",
        created_at: new Date(),
      });
    });

    socket.on("conversation:read", async ({ session_uuid }) => {
      try {
    
        await customerModel.resetUnread(session_uuid);
    
        await emitConversationUpdate(session_uuid);
    
      } catch (error) {
        console.error("Error reset unread:", error);
      }
    });
    
    
  });
}

function emitToSession(sessionId, event, payload) {
  if (!ioInstance) return;
  ioInstance.to(sessionId).emit(event, payload);
}

async function emitConversationUpdate(session_uuid) {
  if (!ioInstance) return;

  const updatedSession = await customerModel.getSessionByUUID(session_uuid);

  ioInstance.to("crm_inbox").emit("conversation_updated", updatedSession);
}


module.exports = { initWebSocket, emitToSession, emitConversationUpdate };
