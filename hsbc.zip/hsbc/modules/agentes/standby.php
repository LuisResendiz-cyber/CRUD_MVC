<?php
# @uthor Mark  
# Error File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","standby");

$tipo_standby = $_REQUEST["e"];

set_session_varname("tipo_standby", $tipo_standby);
layout_menu($db, "");

if($estatus == 1){
    $msg = 'Break';
} else if($estatus == 2) {
    $msg = 'Ba�o';
} else if($estatus == 3) {
    $msg = 'Capacitaci�n';
}

?>
<p class="textbold">Agentes &gt; Standby</p>
<p>&nbsp;</p>
<table border="0">
    <tr>
        <td class="textleft" colspan="2" ><b class="mensaje"><?=$msg?></b></td>
    </tr>
</table>
</form>
<?
layout_footer();
?>
