function cotizarDatos() {
  console.log("Inicia cotizador");
  var solicitud = document.getElementById("customerid").value;
  console.log(solicitud);

  var params = {
    u_persona: solicitud,
  };

  //consulta edad y suma asegurada
  $.ajax({
    url: "modules.php?mod=agentes&op=process_data&act=ODY=",
    data: params,
    type: "POST",
    dataType: "json",
    async: false, // Hacer la solicitud de forma síncrona
    success: function (data) {
      console.log("Solicitud completada: " + data);
      console.log(data);

      data.forEach((element, index) => {
        // console.log(element.OPCION);
        // console.log(element.SUMA_ASEGURADA);
        // console.log(element.FECHA_NACIMIENTO);
        // console.log(element.SEXO);
        // console.log(index);

        let datos_funcion_cotizador = quotationAut(
          element.FECHA_NACIMIENTO,
          element.SEXO,
          element.SUMA_ASEGURADA
        );
        console.log(datos_funcion_cotizador);
        opcion = index + 1;
        // console.log(opcion);
        document.getElementById("suma_asegurada_" + opcion).value = '';
        document.getElementById("valor_precio_" + opcion).value = '';

        document.getElementById("suma_asegurada_" + opcion).value = datos_funcion_cotizador.D6;
        document.getElementById("valor_precio_" + opcion).value = datos_funcion_cotizador.N13;
      });
    },
    error: function (xhr, status, error) {
      console.error("Error en la solicitud: " + error);
    },
  });
}
