<?php

class OracleConexion
{
  private $username;
  private $password;
  private $host;
  private $connection;
  private $state_conn;

  public function __construct()
  {
    $this->username = $_ENV['DB_USER'];
    $this->password =  $_ENV['DB_PASS'];
    $this->host = $_ENV['DB_HOST'] . '/' . $_ENV['DB_SID'];
    $this->connection = null;
    $this->state_conn = false;
  }

  public function connect()
  {
    // Verificar si la extensión OCI8 está cargada
    if (!function_exists('oci_connect')) {
      throw new Exception('La extensión OCI8 no está instalada o habilitada en PHP.');
    }

    // Intentar establecer la conexión
    $this->connection = @oci_connect($this->username, $this->password, $this->host, 'AL32UTF8');

    if (!$this->connection) {
      $error = oci_error();
      throw new Exception('Error al conectar a Oracle: ' . $error['message']);
    }

 

    $this->state_conn = true;
    return true;
  }

  public function disconnect()
  {
    if ($this->connection) {
      oci_close($this->connection);
      $this->connection = null;
      $this->state_conn = false;
    }
    return true;
  }


  public function getState()
  {
    return $this->state_conn;
  }


  public function executeQuery($sql, $params = [])
  {
    if (!$this->state_conn) {
      $this->connect();
    }

    $stid = oci_parse($this->connection, $sql);

    if (!$stid) {
      $error = oci_error($this->connection);
      throw new Exception('Error al preparar la consulta: ' . $error['message']);
    }

    // Bind de parámetros si existen
    foreach ($params as $key => $val) {
      oci_bind_by_name($stid, $key, $params[$key]);
    }

    if (!oci_execute($stid)) {
      $error = oci_error($stid);
      throw new Exception('Error al ejecutar la consulta: ' . $error['message']);
    }

    return $stid;
  }


  public function ejecutarProcedimientoConCursor($nombreProcedimiento, $params = [], $nombreCursorParam = ':rc')
{
    if (!$this->state_conn) {
        $this->connect();
    }

    $sql = "BEGIN $nombreProcedimiento(";
    
    
    $allParams = $params;
    $allParams[$nombreCursorParam] = null;
    
    $paramList = implode(', ', array_keys($allParams));
    $sql .= $paramList;
    
    $sql .= "); END;";

    $stid = oci_parse($this->connection, $sql);
    
    if (!$stid) {
        $error = oci_error($this->connection);
        throw new Exception('Error al preparar el procedimiento: ' . $error['message']);
    }

    // Crear el cursor
    $cursor = oci_new_cursor($this->connection);
    
    // Bind de parámetros de entrada
    foreach ($params as $key => $val) {
        oci_bind_by_name($stid, $key, $params[$key]);
    }
    
    // Bind del parámetro de cursor de salida
    oci_bind_by_name($stid, $nombreCursorParam, $cursor, -1, OCI_B_CURSOR);
    
    if (!oci_execute($stid)) {
        $error = oci_error($stid);
        throw new Exception('Error al ejecutar el procedimiento: ' . $error['message']);
    }
    
    // Ejecutar el cursor para obtener los resultados
    if (!oci_execute($cursor)) {
        $error = oci_error($cursor);
        throw new Exception('Error al ejecutar el cursor: ' . $error['message']);
    }
    
    // Obtener los datos del cursor
    $resultados = [];
    while ($fila = oci_fetch_assoc($cursor)) {
        $resultados[] = $fila;
    }
    
    // Liberar recursos
    oci_free_statement($cursor);
    oci_free_statement($stid);
    
    return $resultados;
}



















  public function execute($accion, $sql, $params = [])
  {
    switch ($accion) {
      case 'select':

        $stid = $this->executeQuery($sql, $params);
        $resultados = [];
        while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {
          $resultados[] = $row;
        }
        oci_free_statement($stid);
        return $resultados;

      case 'insert':
        $stid = $this->executeQuery($sql, $params);
        if (!$stid) {
          throw new Exception("Error en la ejecución de la consulta de inserción.");
        }
        return oci_num_rows($stid);
      default:
        throw new Exception("Accion no valida: $accion");
        break;
    }
  }


  // El destructor cierra la conexión si aún está abierta
  public function __destruct()
  {
    $this->disconnect();
  }
}
