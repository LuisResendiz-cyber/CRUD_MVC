import { Query } from "mysql2/typings/mysql/lib/protocol/sequences/Query";
import pool from "../config/dbMysqlConfig";
import { ISurvey } from "../interfaces/ISurvey";
import { RowDataPacket } from 'mysql2';

export class SurveyModel {
  public async createSurvey(survey: ISurvey, user_id: string) {
    const {
          CUSTOMER_ID,
          NOMBRE,
          AP_PATERNO,
          AP_MATERNO,
          FECHA_NACIMIENTO,
          RFC,
          INGRESOS_FIJOS_COMPROBABLES,
          NACIONALIDAD,
          PAIS_ORIGEN,
          SEXO,
          ESTADO_NACIMIENTO,
          ESTADO_ALTERNO_NACIMIENTO,
          TIPO_ID,
          NUMERO_ID,
          ANTIGUEDAD_VIVIENDA_ANIOS,
          ANTIGUEDAD_VIVIENDA_MESES,
          CALLE,
          NUMERO_EXTERIOR,
          NUMERO_INTERIOR,
          CP,
          COLONIA,
          MUNICIPIO,
          ESTADO,
          LADA,
          TELEFONO,
          TELEFONO_CELULAR,
          CORREO_ELECTRONICO,
          TIPO_VIVIENDA,
          TRABAJADOR_INDEPENDIENTE,
          STATUS_LABORAL,
          TIPO_INDUSTRIA,
          OCUPACION,
          ANTIGUEDAD_EMPRESA_ANIOS,
          ANTIGUEDAD_EMPRESA_MESES,
          NOMBRE_EMPRESA,
          LADA_OFICINA,
          TELEFONO_OFICINA,
          BANCO_REF_1,
          DIGITOS_TDC,
          CREDITO_HIPOTECARIO,
          CREDITO_AUTO,
          TITULAR_TDC,
          TYPIFICATIONID
    } = survey;
    try {
      const [result] = await pool.query(
        `INSERT INTO BOT_TDCAMEXONLINE.SURVEYDATA (
          CUSTOMER_ID,
          NOMBRE,
          AP_PATERNO,
          AP_MATERNO,
          FECHA_NACIMIENTO,
          RFC,
          INGRESOS_FIJOS_COMPROBABLES,
          NACIONALIDAD,
          PAIS_ORIGEN,
          SEXO,
          ESTADO_NACIMIENTO,
          ESTADO_ALTERNO_NACIMIENTO,
          TIPO_ID,
          NUMERO_ID,
          ANTIGUEDAD_VIVIENDA_ANIOS,
          ANTIGUEDAD_VIVIENDA_MESES,
          CALLE,
          NUMERO_EXTERIOR,
          NUMERO_INTERIOR,
          CP,
          COLONIA,
          MUNICIPIO,
          ESTADO,
          LADA,
          TELEFONO,
          TELEFONO_CELULAR,
          CORREO_ELECTRONICO,
          TIPO_VIVIENDA,
          TRABAJADOR_INDEPENDIENTE,
          STATUS_LABORAL,
          TIPO_INDUSTRIA,
          OCUPACION,
          ANTIGUEDAD_EMPRESA_ANIOS,
          ANTIGUEDAD_EMPRESA_MESES,
          NOMBRE_EMPRESA,
          LADA_OFICINA,
          TELEFONO_OFICINA,
          BANCO_REF_1,
          DIGITOS_TDC,
          CREDITO_HIPOTECARIO,
          CREDITO_AUTO,
          TITULAR_TDC,
          user_id,
          TYPIFICATIONID
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          CUSTOMER_ID,
          NOMBRE,
          AP_PATERNO,
          AP_MATERNO,
          FECHA_NACIMIENTO,
          RFC,
          INGRESOS_FIJOS_COMPROBABLES,
          NACIONALIDAD,
          PAIS_ORIGEN,
          SEXO,
          ESTADO_NACIMIENTO,
          ESTADO_ALTERNO_NACIMIENTO,
          TIPO_ID,
          NUMERO_ID,
          ANTIGUEDAD_VIVIENDA_ANIOS,
          ANTIGUEDAD_VIVIENDA_MESES,
          CALLE,
          NUMERO_EXTERIOR,
          NUMERO_INTERIOR,
          CP,
          COLONIA,
          MUNICIPIO,
          ESTADO,
          LADA,
          TELEFONO,
          TELEFONO_CELULAR,
          CORREO_ELECTRONICO,
          TIPO_VIVIENDA,
          TRABAJADOR_INDEPENDIENTE,
          STATUS_LABORAL,
          TIPO_INDUSTRIA,
          OCUPACION,
          ANTIGUEDAD_EMPRESA_ANIOS,
          ANTIGUEDAD_EMPRESA_MESES,
          NOMBRE_EMPRESA,
          LADA_OFICINA,
          TELEFONO_OFICINA,
          BANCO_REF_1,
          DIGITOS_TDC,
          CREDITO_HIPOTECARIO,
          CREDITO_AUTO,
          TITULAR_TDC,
          user_id,
          TYPIFICATIONID
        ]
      );

      return result;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

    public async createSurveyNoSale(survey: ISurvey, user_id: string) {
    try {
      const { CUSTOMER_ID, ID_PHONE, TYPIFICATIONID } = survey;

      const [result] = await pool.query(
        `
        INSERT INTO SURVEYDATANOSALES (
          ID_USER,
          CUSTOMER_ID,
          ID_PHONE,
          TYPIFICATIONID
          ) VALUES (?,?,?,?)`,
        [user_id, CUSTOMER_ID, ID_PHONE, TYPIFICATIONID]
      );
      return result;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  public async getCustomerInfo(CUSTOMERID:string) {

    const query = 'SELECT * FROM BOT_TDCAMEXONLINE.TEM_CUSTOMER_INFO WHERE CUSTOMERID = ?';
    const [rows] = await pool.query<RowDataPacket[]>(query, [CUSTOMERID]);
    return rows ;
  }

  public async getAllSurveys(): Promise<ISurvey[]> {
    const query = `SELECT *
      FROM BOT_TDCAMEXONLINE.SURVEYDATA WHERE STATUS_SURVEY = 0`;
    const [rows] = await pool.query(query);
    return rows as ISurvey[];
  }

  public async getAllSurveysNoSales(): Promise<ISurvey[]> {
    const query = `
      SELECT ID_SURVEYNOSALE,DATE_FORMAT(DATE_INSERT, '%d/%m/%Y %H:%i:%S') DATE_INSERT,STATUS_NOSALE,ID_USER,CUSTOMER_ID,TYPIFICATIONID,ID_PHONE  
      from BOT_TDCAMEXONLINE.SURVEYDATANOSALES
      WHERE STATUS_NOSALE = 0`;
    const [rows] = await pool.query(query);
    return rows as ISurvey[];
  }

  public async updateSurvey(ID_SURVEY: number, STATUS_SURVEY: ISurvey) {
    const query = `UPDATE BOT_TDCAMEXONLINE.SURVEYDATA SET STATUS_SURVEY = ? WHERE ID_SURVEY = ?`;
    const [result] = await pool.query(query, [STATUS_SURVEY, ID_SURVEY]);
    return result;
  }

  public async updateSurveys(ID_SURVEYS: number[], STATUS_SURVEYS: number[]) {
    let query = `UPDATE BOT_TDCAMEXONLINE.SURVEYDATA SET STATUS_SURVEY = CASE ID_SURVEY `;

    const updates: string[] = [];
    const values: (string | number)[] = [];

    ID_SURVEYS.forEach((id, index) => {
      updates.push(`WHEN ? THEN ?`);
      values.push(id, STATUS_SURVEYS[index]);
    });

    query +=
      updates.join(" ") +
      ` END WHERE ID_SURVEY IN (${ID_SURVEYS.map(() => "?").join(",")})`;

    values.push(...ID_SURVEYS);
    const [result] = await pool.query(query, values);
    return result;
  }
}
