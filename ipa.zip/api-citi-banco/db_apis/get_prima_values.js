const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".XSP_PRIMA(:plan,:formapago,:producto,:rc); END;";

   //console.log(context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if( !context.plan || !context.formapago || !context.id_producto ){
    //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.plan = context.plan;
    binds.formapago = context.formapago;
    binds.producto = context.id_producto;
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
     // console.log(result);
    return result;
  }


}

module.exports.find = find;

