import fs from "fs";
import path from "path";
import csv from 'csv-parser';
import { inserLeadsOracle,executeOraProcedure } from "./oracleModel.js";
import { notifySMS } from "../controller/gralController.js";
import { fileURLToPath } from "url";
import { saveLog } from "../controller/mysqlController.js";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const publicFolderPath = path.join( __dirname, "..", "..", "..", "cron_carga_digital/src/public/tempLeads");
const publicFolderBackPath = path.join( __dirname, "..", "..", "..", "cron_carga_digital/src/public/backLeads");

export const checkCsvExist = async () => {
  try {
    if (!fs.existsSync(publicFolderPath)) {
      createDirectory(publicFolderPath)
    }

    const files = fs.readdirSync(publicFolderPath);
    if (files.length === 0) return false;

    const csvToRead = files.filter((file) => isCSV(file));
    return csvToRead.length > 0 ? csvToRead : false;
  } catch (error) {
    console.error(error);
    return [];
  }
};


const createDirectory = (folder) => {
  fs.mkdir(folder, { recursive: true }, (err) => {
      if (err) {
          console.error('Error al crear la carpeta:', err);
      } else {
          console.log('Carpeta creada con exito.');
      }
  });
};

const isCSV = (file) => {
  const filePath = path.join(publicFolderPath, file);
  const stats = fs.statSync(filePath);
  return file.endsWith(".csv") && stats.size > 0;
};
const trimValues = (values) => {
  return values.map(value => value ? value.trim() : '');  
};

export function isArrayEmpty(arr) {
  return (Array.isArray(arr) && arr.length === 0) || arr == false;
}

export const readCSV = async (csvFiles) => {
  const filePath = path.join(publicFolderPath, csvFiles);
  const results = [];
  const stream = fs.createReadStream(filePath);
  return new Promise((resolve, reject) => {
    stream
      .pipe(csv())
      .on("data", (row) => {
        let newFileName = csvFiles.replace(/[\s:]/g, "_");
        newFileName = newFileName.slice(0, -4);
        let fileNameSplit = newFileName.split("_");       

        const values = trimValues(Object.values(row));

        const newRow = {
          BASE: `${fileNameSplit[3]} ${fileNameSplit[4]} ${fileNameSplit[5]} ${fileNameSplit[6]} ${fileNameSplit[7]}_${fileNameSplit[8]}_${fileNameSplit[9]} AUTO`,
          ETIQUETA_REG: `${fileNameSplit[3]} ${fileNameSplit[4]}_${fileNameSplit[5]}_${fileNameSplit[6]} ${fileNameSplit[7]}_${fileNameSplit[8]}_${fileNameSplit[9]}`,
          ID: values[0],
          NOMBRE: `${values[1]} ${values[2]} ${values[3]}`,
          TELEFONO: values[5],
          FECHA_C: `${fileNameSplit[4]}/${fileNameSplit[5]}/${fileNameSplit[6]}`,
          HORA_C: `${fileNameSplit[7]}:${fileNameSplit[8]}:${fileNameSplit[9]}`,
          CATEGORIA: values[6],
          FECHA_DE_NACIMIENTO: values[4],
          BOUNCE_FUNNEL: values[7],
          SOURCE: values[10],
          CAMPAIGN: values[8],
          GCLID: values[9],
          MEDIUM: values[11],
          EMAIL: values[12],
          AUTO_YEAR: values[13],
          MODEL_BRAND_VERSION: values[14],
          POSTCODE: values[15],
          AXA_AMOUNT: values[16],
          CHUBB_AMOUNT: values[17],
          FOLIO: values[18],
          FECHA_SALIDA: values[19],
          FECHA_REGRESO: values[20],
          CLIENTE_AMEX: values[21],
          VIAJA_SEGUIDO: values[22],
          VIAJA_CON_FAMILIA: values[23],
          ID_RELACIONADO: values[24],
          // CSV_NAME: csvFiles
        }
        results.push(newRow); 
      })
      .on("end", () => {
        resolve(results); 
      })
      .on("error", (error) => {
        reject(error); 
      });
  });
};

export const insertCSV = async (data) => {
  try {    
    const result = await inserLeadsOracle(data);
    return result;

  } catch (error) {
    console.log(error);
    await saveLog(`Error al insertar datos en oracle`,2,error);
    await notifySMS(`Error al insertar datos en oracle fun insertCSV: ${error}`);
    return 0;
  }
}

export const moveCsv = async(fileName) => {

  // if (!fs.existsSync(publicFolderBackPath)) {
  //   createDirectory(publicFolderBackPath)
  // }

  const oldfilePath = path.join(publicFolderPath, fileName);
  const newfilePath = path.join(publicFolderBackPath, fileName);
  try {
    if (fs.existsSync(oldfilePath)) {
      fs.renameSync(oldfilePath, newfilePath);
      // console.log(`Archivo movido correctamente -- ${fileName}`);
      return true;
    }
  } catch (err) {
    console.error("Error al mover el archivo:", err);
    await saveLog(`Error al mover archivo: ${fileName}`,2,err);
    return false;
  }
}




export const hygiene = async() => {
  try {    

    const hig1 = await executeOraProcedure({nameProcedure: 'XSP_HIGIENE_PASO_1'})

    if (hig1[0].RESPONSE != '1') {
      console.log(`Error en el paso de higiene 1 XSP_HIGIENE_PASO_1 ${hig1[0].RESPONSE}`)
      await saveLog(`Error en el paso de higiene 1 XSP_HIGIENE_PASO_1`,2,hig1[0].RESPONSE);
      await notifySMS(`Error en el paso de higiene 1 XSP_HIGIENE_PASO_1 ${hig1[0].RESPONSE}`);            
      return false 
    }
    console.log('Paso 1 ejecutado')
    await saveLog(`Paso 1 ejecutado`,1,'XSP_HIGIENE_PASO_1');

//*------------------------------------- FIN PASO 1  ---------------------------------     

    const hig2 = await executeOraProcedure({nameProcedure: 'XSP_HIGIENE_PASO_4'})    
    if (hig2[0].RESPONSE != '1') {
      console.log(`Error en el paso de higiene 2 XSP_HIGIENE_PASO_4 ${hig2[0].RESPONSE}`)
      await saveLog(`Error en el paso de higiene 2 XSP_HIGIENE_PASO_4`,2,hig2[0].RESPONSE);
      await notifySMS(`Error en el paso de higiene 2 XSP_HIGIENE_PASO_4 ${hig2[0].RESPONSE}`);
      return false 
    }
    console.log('Paso 2 ejecutado')
    await saveLog(`Paso 2 ejecutado`,1,'XSP_HIGIENE_PASO_4');

    // const val1 = await executeOraProcedure({nameProcedure: 'XSP_VALIDA_HIGIENE',parameters:{v_opcion: '1'} })
    // if (val1[0].RESPONSE != '1') {
    //   console.log(`Error en la validacion del paso 1 XSP_VALIDA_HIGIENE ${val1[0].RESPONSE}`)

    //   await saveLog(`Error en la validacion del paso 1 XSP_VALIDA_HIGIENE`,2,val1[0].RESPONSE);

    //   await notifySMS(`Error en la validacion del paso 1 XSP_VALIDA_HIGIENE ${val1[0].RESPONSE}`);
    //   return false 
    // }
    // console.log('Validacion paso 1 y 2')

    // await saveLog(`Validacion paso 1 y 2`,1,'XSP_VALIDA_HIGIENE');
//*------------------------------------- FIN PASO 2  ---------------------------------     
    
    const hig3 = await executeOraProcedure({nameProcedure: 'XSP_HIGIENE_PASO_2'})    
    if (hig3[0].RESPONSE != '1') {
      console.log(`Error en el paso de higiene 3 XSP_HIGIENE_PASO_2 ${hig3[0].RESPONSE}`)

      await saveLog(`Error en el paso de higiene 3 XSP_HIGIENE_PASO_2`,2,hig3[0].RESPONSE);

      await notifySMS(`Error en el paso de higiene 3 XSP_HIGIENE_PASO_2 ${hig3[0].RESPONSE}`);
      return false 
    }
    console.log('Paso 3 ejecutado')   
    await saveLog(`Paso 3 ejecutado`,1,'XSP_HIGIENE_PASO_2'); 

    // const val2 = await executeOraProcedure({nameProcedure: 'XSP_VALIDA_HIGIENE',parameters:{v_opcion: '2'} })
    // if (val2[0].RESPONSE != '1') {
    //   console.log(`Error en la validacion del paso 2 ${val2[0].RESPONSE}`)

    //   await saveLog(`Error en la validacion del paso 2`,2,val2[0].RESPONSE);

    //   await notifySMS(`Error en la validacion del paso 2 ${val2[0].RESPONSE}`);
    //   return false 
    // }
    // console.log('Validacion paso 3')  
    // await saveLog(`Validacion paso 3`,1,'XSP_VALIDA_HIGIENE');  
//*------------------------------------- FIN PASO 3  ---------------------------------     
    const hig4 = await executeOraProcedure({nameProcedure: 'XSP_HIGIENE_PASO_3'})    
    if (hig4[0].RESPONSE != '1') {
      console.log(`Error en el paso de higiene 4 XSP_HIGIENE_PASO_3 ${hig4[0].RESPONSE}`)

      await saveLog(`Error en el paso de higiene 4 XSP_HIGIENE_PASO_3`,2,hig4[0].RESPONSE);

      await notifySMS(`Error en el paso de higiene 4 XSP_HIGIENE_PASO_3 ${hig4[0].RESPONSE}`);
      return false 
    }
    console.log('Paso 4 ejecutado')

    await saveLog(`Paso 4 ejecutado`,1,'XSP_HIGIENE_PASO_3');  

    return true
//*------------------------------------- FIN PASO 4  ---------------------------------     
    

    
  } catch (error) {
    console.log(error)
    await notifySMS(`Error en el proceso de higieneRESPONSE ${JSON.stringify(error)}`);
    await saveLog(`Error generico hygiene`,2,error);
  }

}
