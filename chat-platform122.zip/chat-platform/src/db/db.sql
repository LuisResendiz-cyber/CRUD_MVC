CREATE DATABASE `WHATSAAP_ASSISTANT` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;


-- WHATSAAP_ASSISTANT.BOTS definition

CREATE TABLE `BOTS` (
  `id_bot` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo` enum('cobranza','ventas','seguros','tarjetas','soporte','gen') NOT NULL,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bot`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CHAT_SESSIONS definition

CREATE TABLE `CHAT_SESSIONS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT '1',
  `session_uuid` char(36) NOT NULL,
  `channel` enum('web','whatsapp') DEFAULT 'web',
  `status` enum('bot','human','closed') DEFAULT 'bot',
  `assigned_agent_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_uuid` (`session_uuid`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `CHAT_SESSIONS_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `CUSTOMERS` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.CUSTOMERS definition

CREATE TABLE `CUSTOMERS` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_key` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_key` (`client_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.DATA_NUMEROS definition

CREATE TABLE `DATA_NUMEROS` (
  `id_contacto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `lada` char(2) NOT NULL,
  `numero` char(10) NOT NULL,
  `PLATFORM_ID` int DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS definition

CREATE TABLE `ENVIOS` (
  `id_envio` int NOT NULL AUTO_INCREMENT,
  `id_contacto` int NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `mensaje_enviado` text NOT NULL,
  `fecha_envio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio`),
  KEY `id_contacto` (`id_contacto`),
  CONSTRAINT `ENVIOS_ibfk_1` FOREIGN KEY (`id_contacto`) REFERENCES `DATA_NUMEROS` (`id_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.ENVIOS_STATUS definition

CREATE TABLE `ENVIOS_STATUS` (
  `id_envio_status` int NOT NULL AUTO_INCREMENT,
  `id_envio` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_envio_status`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `ENVIOS_STATUS_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.LOG_ENVIO definition

CREATE TABLE `LOG_ENVIO` (
  `id_log_local` int NOT NULL AUTO_INCREMENT,
  `id_envio` int DEFAULT NULL,
  `status_id` int NOT NULL,
  `errorApi` varchar(500) NOT NULL DEFAULT 'NA',
  `fecha_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log_local`),
  KEY `id_envio` (`id_envio`),
  CONSTRAINT `LOG_ENVIO_ibfk_1` FOREIGN KEY (`id_envio`) REFERENCES `ENVIOS` (`id_envio`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.PLATFORMS definition

CREATE TABLE `PLATFORMS` (
  `id_platform` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `activo` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_platform`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.STATUS_ENVIO definition

CREATE TABLE `STATUS_ENVIO` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `message` varchar(30) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- WHATSAAP_ASSISTANT.WHATSAPP_WEBHOOK_LOG definition

CREATE TABLE `WHATSAPP_WEBHOOK_LOG` (
  `id_webhook` int NOT NULL AUTO_INCREMENT,
  `event_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `wamid` varchar(100) DEFAULT NULL,
  `from_number` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `message_text` text,
  `channel` enum('web','whatsapp','voice') NOT NULL DEFAULT 'web',
  `role` enum('user','assistant') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'assistant',
  `conversation_id` varchar(100) DEFAULT NULL,
  `raw_json` json NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_webhook`),
  KEY `idx_from_created` (`from_number`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=923 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;