const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context){
  // console.log('***** llamando al procedimiento SPS_RESULTADOSLLAMADAS *****');
  // console.log(context);
  const baseQuery = "BEGIN "+context.schema+".SPS_RESULTADOSLLAMADAS(:u_telefono, :rc); END;";
  //console.log(context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(context.schema=='' || context.u_telefono==''){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
  	binds.u_telefono = context.u_telefono;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    // console.log(result);
    return result;
  }
}

module.exports.find = find;

