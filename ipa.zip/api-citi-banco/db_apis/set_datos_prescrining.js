const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
  
const baseQuery = "BEGIN "+ context.schema +".SPS_REP_PRESCREENING_OPE(:user,:CUSTOMERID,:rc); END;";

  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   
  
  if(!context.user || !context.CUSTOMERID){
   //console.log("Paramentros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Paramentros Erroneos";
    return result2;

  }else{
    //console.log("Paramentros correctos");    
    //Se asignan los valores respecto a los parametros del SP
    binds.user = context.user;
    binds.CUSTOMERID = context.CUSTOMERID;
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    // console.log(result);
    return result;
  }


}

module.exports.find = find;