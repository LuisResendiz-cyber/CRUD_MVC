<?php

define('URL', 'http://localhost:8080/expense-app/');

define('HOST', 'localhost');
define('DB', 'expenseapp');
define('USER', 'root');
define('PASSWORD', "root");
define('CHARSET', 'utf8mb4');

?>