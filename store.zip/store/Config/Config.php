<?php 
	const BASE_URL = "http://172.20.1.149/store";
	const BASE_API = "http://172.20.2.2:4001/api_bbva/"; //DSA API

	//Zona horaria
	date_default_timezone_set('America/Mexico_City');

	//Datos de conexión a Base de Datos
	const DB_HOST = "172.20.1.149";
	const DB_NAME = "tienda";
	const DB_USER = "lresendiz";
	const DB_PASSWORD = "R3s3nd1z*";
	const DB_CHARSET = "utf8";

	//Deliminadores decimal y millar Ej. 24,1989.00
	const SPD = ".";
	const SPM = ",";

	//Simbolo de moneda
	const SMONEY = "Q";

	//Datos envio de correo
	const NOMBRE_REMITENTE = "Tienda Virtual";
	const EMAIL_REMITENTE = "no-reply@abelosh.com";
	const NOMBRE_EMPESA = "Tienda Virtual";
	const WEB_EMPRESA = "www.abelosh.com";
 ?>