 <aside class="main-sidebar">

	 <section class="sidebar">

		<ul class="sidebar-menu" data-widget="tree">
		<li class="active">

				<a href="?ruta=inicio">

					<i class="fa fa-home"></i>
					<span>Inicio</span>
				</a>
		</li>


		<?php
$enlaces = $_SESSION['enlaces_usuario'];
$enlacesAgrupados = [];

foreach ($enlaces as $enlace) {
    $campana = $enlace['NOMBRE_CAMPANA'];
    if (!isset($enlacesAgrupados[$campana])) {
        $enlacesAgrupados[$campana] = [];
    }
    $enlacesAgrupados[$campana][] = $enlace;
}

foreach ($enlacesAgrupados as $campana => $enlacesCampana) {
    echo '<li class="treeview">
            <a href="#">
                <i class="fa fa-laptop"></i>
                <span>' . $campana . '</span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">';

//     foreach ($enlacesCampana as $enlace) {
//         echo '<li><a href="?ruta=inicio" data-url="' . $enlace['url'] . '"><i class="fa fa-circle-o"></i>' . $enlace['titulo'] . '</a></li>';
//     }
    foreach ($enlacesCampana as $enlace) {
	echo '<li><a href="?ruta=inicio" data-url="' . $enlace['url'] . '" class="cargarIframe"><i class="fa fa-circle-o"></i>' . $enlace['titulo'] . '</a></li>';
      }
    echo '</ul>
        </li>';
}
        ?>

		<?php
		if($_SESSION["perfil"] == "Administrador"){
		echo '<li>
				<a href="?ruta=usuarios">
					<i class="fa fa-user"></i>
					<span>Usuarios</span>
				</a>
			</li>';
			

			echo '<li>
			<a href="?ruta=enlaces">
				<i class="fa fa-user"></i>
				<span>Administrar Ligas</span>
			</a>
		</li>';
		}
		?>
		</ul>
	 </section>
</aside> 