<?php
//ini_set('display_errors',1);
## MUESTRA LAS CAMPA�AS DISPONIBLES
function get_campanas($conn){
    $campanas = get_campanasxusuario($conn);
    $rs = $conn->ExecuteCursor("BEGIN CALIDAD.SPS_CAMPANASSEGSOL('".$campanas."',:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;
}

## MUESTRA LAS CAMPAÑAS ASIGNADAS POR USUARIO
function get_campanasxusuario($conn){
	$rs = $conn->ExecuteCursor("BEGIN SPS_CAMPANASXUSUARIO(".get_session_varname('s_usr_id').",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);

	$campanas = "0";
    while(!$rs->EOF) {
        $campanas .= ",".$rs->fields[1];
        $rs->MoveNext();
    }

    return $campanas;
}

## DEVUELVE DETALLES DE LA CAMPAÑA SELECCIONADA
function get_datos_campana($s_id_campana, $conn){
	$rs = $conn->ExecuteCursor("BEGIN CALIDAD.ASPS_DETALLESCAMPANA (".$s_id_campana.",:rc); END;", 'rc');
	$conn->SetFetchMode(ADODB_FETCH_BOTH);
	
	return $rs;	
}

# OBTIENE UN NUEVO REGISTRO Y DEVUELVE EL NUMERO DE SOLICITUD
function set_activa_usuario($p_usr_id, $db){
	$stmt = $db->PrepareSP("BEGIN SPU_ACTIVACIONUSUARIO(:p_usr_id, :p_usr_id_activado); END;");
	$db->InParameter($stmt, $p_usr_id, 'p_usr_id');
	$db->OutParameter($stmt, $p_usr_id_activado, 'p_usr_id_activado');
	$db->Execute($stmt);
	return $p_usr_id_activado;
}

# REGRESA LA BUSQUEDA DE LOS USUARIOS
function get_busqueda_usuarios($nombre_completo, $id_usuario, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_BUSQUEDAUSUARIOS('".strtoupper($nombre_completo)."',".$id_usuario.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

function get_perfil_usuario($nivel){
	$permission_array = array('A' => 'Agente', 'AI' => 'Agente_in', 'N' => 'Nomina', 'V' => 'Validacion','MC' => 'Mesa Control', 'GO' => 'Gerente Operacion', 'GV' => 'Gerente Validacion', 'S' => 'supervisor', 'X' => 'Administrador');
	return strtoupper($permission_array[trim($nivel)]);
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA
function get_perfiles($v_id_campo, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_CATALOGO('".$v_id_campo."',:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

# DEVUELVE LA INFORMACION DEL USUARIO
function get_informacion_usuario($usr_id, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_INFOUSUARIO(".$usr_id.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

#DEVUELVE LA LISTA DE LOS SUPERVISORES ACTIVOS
function get_supervisores($var,$db){
	$rs = $db->ExecuteCursor("BEGIN SPS_SUPERVISORES(".$var.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}


# GUARDA LOS DATOS DEL USUARIO EDITADO
function set_datos_usuario($usr_id, $nombre, $contrasena, $perfil, $activo, $supervisor, $etapa, $generacion, $db){
	$stmt = $db->PrepareSP("BEGIN SPX_NOMINAUSUARIO(:p_usr_id, :p_nombre, :p_contrasena, :p_perfil, :p_activo, :p_supervisor, :p_etapa, :p_generacion, :p_usr_id_activado); END;");
	$db->InParameter($stmt, $usr_id, 'p_usr_id');
	$db->InParameter($stmt, $nombre, 'p_nombre');
	$db->InParameter($stmt, $contrasena, 'p_contrasena');
	$db->InParameter($stmt, $perfil, 'p_perfil');
	$db->InParameter($stmt, $activo, 'p_activo');
	$db->InParameter($stmt, $supervisor, 'p_supervisor');
	$db->InParameter($stmt, $etapa, 'p_etapa');
	$db->InParameter($stmt, $generacion, 'p_generacion');
	$db->OutParameter($stmt, $p_usr_id_activado, 'p_usr_id_activado');
	$db->Execute($stmt);
	return $p_usr_id_activado;
}

# DEVUELVE LA INFORMACION DE LAS CAMPAÑAS ASIGNADAS POR USUARIO
function get_campanas_activas_usuario($usr_id, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_CAMPANASACTIVAS(".$usr_id.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

# ASIGNA / SESASIGNA CAMPANA
function set_asigna_campana_usuario($p_usr_id, $p_campana_id, $p_action, $db){
	$stmt = $db->PrepareSP("BEGIN SPX_ASIGNACAMPANAS(:p_usr_id, :p_campana_id, :p_action, :p_activado); END;");
	$db->InParameter($stmt, $p_usr_id, 'p_usr_id');
	$db->InParameter($stmt, $p_campana_id, 'p_campana_id');
	$db->InParameter($stmt, $p_action, 'p_action');
	$db->OutParameter($stmt, $p_activado, 'p_activado');
	$db->Execute($stmt);
	return $p_activado;

}

?>