<?php

# Utils Fille 
# @uthor Mark 

require_once("includes.inc.php");

//Get the courrent date in number format
function getDates() {
    $date = date("Ymd");
    return $date;
}

//Get the substring 
function getString($data1) {
    $data = substr($data1, 2);
    return $data;
}

function get_now() {
    $day = date("j");
    $month = date("m");
    $year = date("Y");
    $actualmonth = "";
    switch ($month) {
        case 1:
            $actualmonth = "Enero";
            break;
        case 2:
            $actualmonth = "Febrero";
            break;
        case 3:
            $actualmonth = "Marzo";
            break;
        case 4:
            $actualmonth = "Abril";
            break;
        case 5:
            $actualmonth = "Mayo";
            break;
        case 6:
            $actualmonth = "Junio";
            break;
        case 7:
            $actualmonth = "Julio";
            break;
        case 8:
            $actualmonth = "Agosto";
            break;
        case 9:
            $actualmonth = "Septiembre";
            break;
        case 10:
            $actualmonth = "Octubre";
            break;
        case 11:
            $actualmonth = "Noviembre";
            break;
        case 12:
            $actualmonth = "Diciembre";
            break;
    }
    return $day . ' de ' . $actualmonth . ' de ' . $year;
}

function get_money_format($data, $position) {
    return number_format($data, $position, ".", ",");
}

function convert_to_money($data) {
    return str_replace(',', '', $data);
}

## REGRESE EL COLOR DE LA CELDA

function getColor($i) {
    if ($i % 2 == 0)
        $color = "#afd3d5";
    else
        $color = "#ffffff";

    return $color;
}

function get_today() {
    $day = date("j");
    $month = date("m");
    $year = date("Y");
    return (strlen($day) == 1 ? '0' . $day : $day) . '/' . $month . '/' . $year;
}

function special_chars($string) {
    $source = array('/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/�/', '/&/');
    $dest = array('a', 'e', 'i', 'o', 'u', 'n', 'A', 'E', 'I', 'O', 'U', 'N', '&amp;');
    return preg_replace($source, $dest, $string);
}

function pa($data) {
    echo "<pre>";
    print_r($data);
    echo "</pre>\r\n";
}