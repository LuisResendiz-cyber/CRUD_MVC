const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  console.log('****crear_tickets****');
  console.log(context);
  const baseQuery = "BEGIN CITI.XSP_INSERTAR_UPDATE_TICKET(:v_categoria, :v_usuario, :v_opcion, :v_asignado, :v_nota, :v_realizado, :v_id_editar, :v_fecha_cierre, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if (context.opcion == 1) { // Crear tickets
    if (context.categoria == "" || context.usuario == "") {
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;
    } else {
      binds.v_categoria = context.categoria;
      binds.v_usuario = context.usuario;
      binds.v_opcion = context.opcion;
      binds.v_asignado = null;
      binds.v_nota = null;
      binds.v_realizado = null;
      binds.v_id_editar = null;
      binds.v_fecha_cierre = null;
      binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

      const result = await database.simpleExecuteRC(query, binds);
      console.log(result);
      return result;
    }
  } else { // Editar ticket
    if (context.id == "") {
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;
    } else {
      binds.v_categoria = null;
      binds.v_usuario = null;
      binds.v_opcion = context.opcion;
      binds.v_asignado = context.valorUsuario;
      binds.v_nota = context.valorNota;
      binds.v_realizado = context.valorCheckbox;
      binds.v_id_editar = context.id;
      binds.v_fecha_cierre = context.fechaCierre;
      binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

      const result = await database.simpleExecuteRC(query, binds);
      console.log(result);
      return result;
    }
  }
}

module.exports.find = find;
