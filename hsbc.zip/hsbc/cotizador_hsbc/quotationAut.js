const objData = {
  O3: 1,
  O1: 1,
  O4: 1,
  CUSTOMER: {},
  // HEA: {},
};
const rates = {
  Y4: 10, // $Tarifas.Y4
  Z4: 50000, //  $Tarifas.Z4
};

const paymentSurcharges = {
  Anual: { value: 0.0, colS: 1 },
  Mensual: { value: 0.1268, colS: 12 },
  Trimestral: { value: 0.1142, colS: 4 },
  Semestral: { value: 0.0957, colS: 2 },
  Iva: { value: 0.16 },
};

const segmentos = {
  //! Actualmente todo esta en 0 pero cuando estos valores cambien se deben de agregar pero en formato de porcentaje ejem: 11% = 0.11
  Advance: 0,
  Premier: 0,
  Personal_Banking: 0,
  Privada: 0,
};
const descuentos = {
  //! Actualmente todo esta en 0 pero cuando estos valores cambien se deben de agregar pero en formato de porcentaje ejem: 11% = 0.11
  Especial: 0,
  Segmento: 0,
  Empleado: 0,
  Ninguno: 0,
};

function calculateAge(birthDate, fechaReferencia) {
  const nacimiento = convertDate(birthDate); // Convertimos el string de fecha
  // console.log(nacimiento)
  if (!nacimiento) return "";

  const hoy = convertDate(fechaReferencia);
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const mes = hoy.getMonth() - nacimiento.getMonth();
  if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
    edad--;
  }
  return edad;
}

function convertDate(fechaStr) {
  const [dia, mes, anio] = fechaStr.split("/").map(Number);
  if (!dia || !mes || !anio) return null;
  return new Date(anio, mes - 1, dia);
}

const quotationDate = () => {
  const actDate = new Date();
  const day = String(actDate.getDate()).padStart(2, "0");
  const month = String(actDate.getMonth() + 1).padStart(2, "0");
  const year = actDate.getFullYear();
  const formattedDate = `${day}/${month}/${year}`;
  objData["D5"] = formattedDate; //* Fecha de la cotización
};

const countInRange = (obj, start, end, prefix) => {
  const keysInRange = Array.from(
    { length: end - start + 1 },
    (_, i) => `${prefix}${start + i}`
  );

  const count = keysInRange.filter(
    (key) => key in obj && obj[key] !== 0
  ).length;

  return count;
};

const min = (D6) => Math.min(rates.Z4, rates.Y4 * D6);

function calculateAGFU(gender, age) {
  if (objFuneralExpenses[age]) {
    return gender == "M"
      ? objFuneralExpenses[age].Male
      : objFuneralExpenses[age].Female;
  } else {
    return "N/A";
  }
}

function calculateRate(gender, age) {
  // console.log(gender,'--------',age)
  if (objRate[age]) {
    return gender == "M" ? objRate[age].Male : objRate[age].Female;
  } else {
    return "N/A";
  }
}

const objFuneralExpenses = {
  0: { Male: 1.6341, Female: 1.6341 },
  1: { Male: 1.6341, Female: 1.6341 },
  2: { Male: 1.6341, Female: 1.6341 },
  3: { Male: 1.6341, Female: 1.6341 },
  4: { Male: 1.6341, Female: 1.6341 },
  5: { Male: 1.6341, Female: 1.6341 },
  6: { Male: 1.6341, Female: 1.6341 },
  7: { Male: 1.6341, Female: 1.6341 },
  8: { Male: 1.6341, Female: 1.6341 },
  9: { Male: 1.6341, Female: 1.6341 },
  10: { Male: 1.6341, Female: 1.6341 },
  11: { Male: 1.6341, Female: 1.6341 },
  12: { Male: 1.6341, Female: 1.6341 },
  13: { Male: 1.6341, Female: 1.6341 },
  14: { Male: 1.6341, Female: 1.6341 },
  15: { Male: 1.6341, Female: 1.6341 },
  16: { Male: 1.6341, Female: 1.6341 },
  17: { Male: 1.6341, Female: 1.6341 },
  18: { Male: 1.6341, Female: 1.6341 },
  19: { Male: 1.6341, Female: 1.6341 },
  20: { Male: 0.7593, Female: 0.7593 },
  21: { Male: 0.7593, Female: 0.7593 },
  22: { Male: 0.7593, Female: 0.7593 },
  23: { Male: 0.7593, Female: 0.7593 },
  24: { Male: 0.7593, Female: 0.7593 },
  25: { Male: 0.7593, Female: 0.7593 },
  26: { Male: 0.7593, Female: 0.7593 },
  27: { Male: 0.7593, Female: 0.7593 },
  28: { Male: 0.7593, Female: 0.7593 },
  29: { Male: 0.7593, Female: 0.7593 },
  30: { Male: 1.3904, Female: 1.3904 },
  31: { Male: 1.3904, Female: 1.3904 },
  32: { Male: 1.3904, Female: 1.3904 },
  33: { Male: 1.3904, Female: 1.3904 },
  34: { Male: 1.3904, Female: 1.3904 },
  35: { Male: 1.3904, Female: 1.3904 },
  36: { Male: 1.3904, Female: 1.3904 },
  37: { Male: 1.3904, Female: 1.3904 },
  38: { Male: 1.3904, Female: 1.3904 },
  39: { Male: 1.3904, Female: 1.3904 },
  40: { Male: 2.8371, Female: 2.8371 },
  41: { Male: 2.8371, Female: 2.8371 },
  42: { Male: 2.8371, Female: 2.8371 },
  43: { Male: 2.8371, Female: 2.8371 },
  44: { Male: 2.8371, Female: 2.8371 },
  45: { Male: 2.8371, Female: 2.8371 },
  46: { Male: 2.8371, Female: 2.8371 },
  47: { Male: 2.8371, Female: 2.8371 },
  48: { Male: 2.8371, Female: 2.8371 },
  49: { Male: 2.8371, Female: 2.8371 },
  50: { Male: 6.0147, Female: 6.0147 },
  51: { Male: 6.0147, Female: 6.0147 },
  52: { Male: 6.0147, Female: 6.0147 },
  53: { Male: 6.0147, Female: 6.0147 },
  54: { Male: 6.0147, Female: 6.0147 },
  55: { Male: 6.0147, Female: 6.0147 },
  56: { Male: 6.0147, Female: 6.0147 },
  57: { Male: 6.0147, Female: 6.0147 },
  58: { Male: 6.0147, Female: 6.0147 },
  59: { Male: 6.0147, Female: 6.0147 },
  60: { Male: 10.5828, Female: 10.5828 },
  61: { Male: 10.5828, Female: 10.5828 },
  62: { Male: 10.5828, Female: 10.5828 },
  63: { Male: 10.5828, Female: 10.5828 },
  64: { Male: 10.5828, Female: 10.5828 },
  65: { Male: 10.5828, Female: 10.5828 },
  66: { Male: 10.5828, Female: 10.5828 },
  67: { Male: 10.5828, Female: 10.5828 },
  68: { Male: 10.5828, Female: 10.5828 },
  69: { Male: 10.5828, Female: 10.5828 },
};

const objRate = {
  0: { Male: 949.6805, Female: 1011.5273 },
  1: { Male: 743.3025, Female: 827.0273 },
  2: { Male: 542.3987, Female: 620.868 },
  3: { Male: 305.7785, Female: 393.3933 },
  4: { Male: 258.2232, Female: 324.6006 },
  5: { Male: 228.9058, Female: 279.4731 },
  6: { Male: 213.4988, Female: 257.9701 },
  7: { Male: 202.0099, Female: 241.6851 },
  8: { Male: 184.7844, Female: 230.5462 },
  9: { Male: 172.6456, Female: 217.8481 },
  10: { Male: 170.321, Female: 212.3271 },
  11: { Male: 170.4491, Female: 212.8239 },
  12: { Male: 176.7481, Female: 215.3516 },
  13: { Male: 165.403, Female: 194.2673 },
  14: { Male: 167.5433, Female: 206.6373 },
  15: { Male: 167.3808, Female: 224.6408 },
  16: { Male: 160.0194, Female: 245.1783 },
  17: { Male: 153.7828, Female: 277.7858 },
  18: { Male: 163.5439, Female: 324.6568 },
  19: { Male: 161.4973, Female: 348.8907 },
  20: { Male: 160.3037, Female: 363.1541 },
  21: { Male: 166.2934, Female: 376.3427 },
  22: { Male: 168.9555, Female: 381.117 },
  23: { Male: 180.2851, Female: 398.2644 },
  24: { Male: 191.3303, Female: 411.1749 },
  25: { Male: 201.4725, Female: 427.1912 },
  26: { Male: 208.1183, Female: 432.0999 },
  27: { Male: 213.7456, Female: 433.5996 },
  28: { Male: 223.6222, Female: 438.7801 },
  29: { Male: 229.412, Female: 443.8668 },
  30: { Male: 237.0733, Female: 442.6358 },
  31: { Male: 246.0001, Female: 445.2197 },
  32: { Male: 254.8362, Female: 446.2196 },
  33: { Male: 257.5139, Female: 442.2983 },
  34: { Male: 274.1083, Female: 441.1485 },
  35: { Male: 280.4229, Female: 445.9665 },
  36: { Male: 286.9063, Female: 448.3568 },
  37: { Male: 299.2888, Female: 454.7339 },
  38: { Male: 312.2681, Female: 458.3771 },
  39: { Male: 312.1837, Female: 502.0361 },
  40: { Male: 326.0473, Female: 511.9502 },
  41: { Male: 341.6793, Female: 536.8995 },
  42: { Male: 355.9927, Female: 567.6199 },
  43: { Male: 371.1779, Female: 610.4321 },
  44: { Male: 391.9747, Female: 608.5886 },
  45: { Male: 411.728, Female: 641.9429 },
  46: { Male: 435.565, Female: 657.175 },
  47: { Male: 452.3624, Female: 670.248 },
  48: { Male: 485.2262, Female: 703.3617 },
  49: { Male: 513.2563, Female: 718.9406 },
  50: { Male: 538.6524, Female: 740.806 },
  51: { Male: 562.1238, Female: 777.916 },
  52: { Male: 591.2256, Female: 792.1919 },
  53: { Male: 629.473, Female: 792.3169 },
  54: { Male: 667.1172, Female: 814.5385 },
  55: { Male: 698.0313, Female: 842.5062 },
  56: { Male: 724.9241, Female: 849.1801 },
  57: { Male: 755.935, Female: 876.1323 },
  58: { Male: 764.1493, Female: 906.8182 },
  59: { Male: 763.3463, Female: 916.7417 },
  60: { Male: 779.472, Female: 931.4801 },
  61: { Male: 788.2488, Female: 954.0361 },
  62: { Male: 795.1884, Female: 970.2617 },
  63: { Male: 827.1616, Female: 1006.1469 },
  64: { Male: 852.3922, Female: 1046.4939 },
  65: { Male: 857.5726, Female: 1087.9782 },
  66: { Male: 876.7884, Female: 1107.4971 },
  67: { Male: 885.2528, Female: 1130.6436 },
  68: { Male: 854.6949, Female: 1120.5701 },
  69: { Male: 860.8877, Female: 1075.4551 },
};

const derechoPoliza = 150;
const medicalAssitance = 66;

//*-----------------------------------Hea---------------------------------------------------
const calculateHea = () => {
  objData["E25"] = ((objData.CUSTOMER?.["H14"] ?? 0) / 1000) * objData.D6;
  objData["E26"] = objData["E25"] * objData["E10"];
  objData["E27"] = (objData["E25"] - objData["E26"]) * objData.R5;
  objData["E28"] = derechoPoliza;
  objData["E29"] =
    (objData["E25"] - objData["E26"] + objData["E27"] + objData["E28"]) *
    paymentSurcharges.Iva.value;
  objData["E30"] =
    objData["E25"] -
    objData["E26"] +
    objData["E27"] +
    objData["E28"] +
    objData["E29"];
  objData["E31"] = objData["E30"] / paymentSurcharges[objData.D8]?.colS;

  objData["N25"] = objData["E25"];
  objData["N26"] = objData["E26"];
  objData["N27"] = objData["E27"];
  objData["N28"] = objData["E28"];
  objData["N29"] = objData["E29"];
  objData["N30"] = objData["E30"];
  objData["N31"] = objData["E30"] / paymentSurcharges[objData.D8]?.colS;
};
//*----------------------------------Agfu----------------------------------------------------
const calculateAgfu = () => {
  objData["E34"] = ((objData.CUSTOMER?.["G14"] ?? 0) * objData.D7) / 1000;
  objData["E35"] = objData["E34"] * objData.E10;
  objData["E36"] = (objData["E34"] - objData["E35"]) * objData.R5;
  objData["E37"] = objData["E34"] - objData["E35"] + objData["E36"];
  objData["E38"] = objData["E37"] / paymentSurcharges[objData.D8]?.colS;
  objData["N34"] = objData["E34"];
  objData["N35"] = objData["E35"];
  objData["N36"] = objData["E36"];
  objData["N37"] = objData["E37"];
  objData["N38"] = objData["E37"] / paymentSurcharges[objData.D8]?.colS;
};
//*----------------------------------ASIM----------------------------------------------------
const calculateAsim = () => {
  objData["E41"] = objData.O1 == 1 ? medicalAssitance : 0;
  objData["E42"] = objData.E41 * objData.E10;
  objData["E43"] = (objData.E41 - objData.E42) * objData.R5;
  objData["E44"] =
    (objData.E41 - objData.E42 + objData.E43) * paymentSurcharges.Iva.value;
  objData["E45"] = objData.E41 - objData.E42 + objData.E43 + objData.E44;
  objData["E46"] = objData.E45 / paymentSurcharges[objData.D8]?.colS;
  objData["N41"] = objData["E41"];
  objData["N42"] = objData["E42"];
  objData["N43"] = objData["E43"];
  objData["N44"] = objData["E44"];
  objData["N45"] = objData["E45"];
  objData["N46"] = objData["N45"] / paymentSurcharges[objData.D8]?.colS;
};

//*----------------------------------ASIM----------------------------------------------------
const calQuotation = () => {
  const n25 = objData["N25"] ?? 0;
  const n34 = objData["N34"] ?? 0;
  const n41 = objData["N41"] ?? 0;

  objData["M5"] = parseFloat(n25.toFixed(2));
  let n5F = n25 / paymentSurcharges[objData.D8]?.colS;
  objData["N5"] = parseFloat(n5F.toFixed(2));
  objData["M6"] = objData.O3 == 1 ? objData["N34"] : 0;
  let n6F = n34 / paymentSurcharges[objData.D8]?.colS;
  objData["N6"] = parseFloat(n6F.toFixed(2));
  objData["M7"] = parseFloat(n41.toFixed(2));
  let n7F = n41 / paymentSurcharges[objData.D8]?.colS;
  objData["N7"] = parseFloat(n7F.toFixed(2));
  const m8 = objData["N25"] + objData["N34"] + objData["N41"];
  objData["M8"] = parseFloat(m8.toFixed(2));
  const n8F =
    (objData["N25"] + objData["N34"] + objData["N41"]) /
    paymentSurcharges[objData.D8]?.colS;
  objData["N8"] = parseFloat(n8F.toFixed(2));
  const m9 = objData["N26"] + objData["N35"] + objData["N42"];
  objData["M9"] = parseFloat(m9.toFixed(2));
  const n9 =
    (objData["N26"] + objData["N35"] + objData["N42"]) /
    paymentSurcharges[objData.D8]?.colS;
  objData["N9"] = parseFloat(n9.toFixed(2));
  const m10 = objData["N27"] + objData["N36"] + objData["N43"];
  objData["M10"] = parseFloat(m10.toFixed(2));
  const n10 =
    (objData["N27"] + objData["N36"] + objData["N43"]) /
    paymentSurcharges[objData.D8]?.colS;
  objData["N10"] = parseFloat(n10.toFixed(2));

  objData["M11"] = objData.N28;
  objData["N11"] = objData.N28 / paymentSurcharges[objData.D8]?.colS;
  const m12 = objData["N29"] + objData["N44"];
  objData["M12"] = parseFloat(m12.toFixed(2));
  const n12 =
    (objData["N29"] + objData["N44"]) / paymentSurcharges[objData.D8]?.colS;
  objData["N12"] = parseFloat(n12.toFixed(2));

  const m13 = objData["N30"] + objData["N37"] + objData["N45"];
  objData["M13"] = parseFloat(m13.toFixed(2));

  const n13 =
    (objData["N30"] + objData["N37"] + objData["N45"]) /
    paymentSurcharges[objData.D8]?.colS;
  objData["N13"] = parseFloat(n13.toFixed(2));

  objData["M14"] = objData["N13"];

  const colS = paymentSurcharges[objData.D8]?.colS ?? 0;

  // console.error(colS,objData['M13'])

  const m15 = objData["M13"] - objData["M14"] * (colS - 1);

  objData["M15"] = parseFloat(m15.toFixed(2));

  // console.log(objData.M15);
};

const declareVariables = (fechaNacimiento, gender, sumaAsegurada) => {
  const formaPago = "Mensual";
  const segmento = "Advance";
  const descuento = "Especial";

  objData["D6"] = sumaAsegurada;

  const isCustomerInRange = countInRange(objData.CUSTOMER, 14, 22, "D") > 1;
  objData["D7"] = objData.O3 == 1 && !isCustomerInRange ? min(objData.D6) : 0; // S.A. AGFU
  objData["O4"] = objData.O3 == 1 && !isCustomerInRange ? 1 : 0; // O4

  objData["D8"] = formaPago;
  objData["R5"] = paymentSurcharges[formaPago].value;
  objData["D9"] = segmento;
  objData["D10"] = descuento;
  objData["E10"] =
    descuento === "Segmento" ? segmentos[objData.D9] : descuentos[descuento];
  objData["funeralExpenses"] = 1;

  const age = calculateAge(fechaNacimiento, objData.D5);

  // Validar edad
  if (age < 18 || age > 65) {
    return false;
  }

  // Calcular AGFU y tasa
  const agfu = calculateAGFU(gender, age);
  const rate = calculateRate(gender, age);

  // Asignar datos al cliente
  objData.CUSTOMER["D14"] = fechaNacimiento;
  objData.CUSTOMER["F14"] = age;
  objData.CUSTOMER["G14"] = agfu;
  objData.CUSTOMER["H14"] = rate;
  objData["insuredIncluded"] = countInRange(objData.CUSTOMER, 14, 22, "H");

  return true;
};

//!AQUI SE DEBE DE AGREGAR TODO EL PROCESO PARA GENERAR LA COTIZACION
const quotationAut = (fechaNacimiento, gender, sumaAsegurada) => {
  quotationDate(); //Calcular la fecha actual
  declareVariables(fechaNacimiento, gender, sumaAsegurada); //Declarar las variables a utilisar
  calculateHea();
  calculateAgfu();
  calculateAsim();

  calQuotation();
  return objData;
};

const test = () => {
  const test = quotationAut("01/01/1963", "M", 4000); //fecha de nacimiento sexo suma asegurada
  return test;
  //*SEXO M O F 
  
  // console.log(test);

  // document.getElementById("code").innerHTML= JSON.stringify(test, null, 2)

  
};

document.getElementById("btnAutQuotation").addEventListener("click", test);
