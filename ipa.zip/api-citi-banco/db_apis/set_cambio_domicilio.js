const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
    console.log(context);
    const baseQuery = "BEGIN " + context.schema + ".XSP_CAMBIO_DOMICILIO(:customer_id, :CambioDomicilio); END;";
    try {
        let query = baseQuery;
        const binds = {};
        let result2 = {};
        binds.customer_id = context.customer_id;
        binds.CambioDomicilio = context.CambioDomicilio;

        const result = await database.simpleExecute(query, binds);
        return result;
    } catch (error) {
        console.log(error);
    }
}

module.exports.find = find;
