const load_permissions = require('../db_apis/load_permissions.js');
 
async function post(req, res, next) {
  try {
    const context = req.body; 
    // console.log(context);
 
    const rows = await load_permissions.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;