const db = require("../db/mysql");

const Users = {
    async getUser(clientKey) {
        const rows = await db.query(`
          SELECT
            c.id           AS customerId,
            c.active       AS customerActive,
            b.id_bot       AS botId,
            b.nombre,
            b.tipo,
            b.estado
          FROM CUSTOMERS c
          JOIN BOTS b ON b.id_bot = c.bot_id
          WHERE c.client_key = ?
          LIMIT 1
        `, [clientKey]);

        if (!rows.length ||!rows[0][0].customerActive) {
          return null;
        }
        return rows[0];
      },
      async CreateUser(datosUser) {
        const { customer_id, name, last_name, phone_number, email_user, password, rolid } = datosUser;

        
        const [result] = await db.query("INSERT INTO USERS(customer_id, name,last_name, phone_number, email_user, password, rolid) VALUES(?,?,?,?,?,?,?)", [customer_id, name, last_name, phone_number, email_user, password, rolid]);
        return result;
      },
      async getAcces(user) {  
        const { email_user } = user;
        const [rows] = await db.query('SELECT * FROM USERS where email_user = ?', [email_user]);
        return rows[0];
      }
};

module.exports = Users;


