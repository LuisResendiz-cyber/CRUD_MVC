const express = require('express');

const {checkConn,getToken} = require('../controllers/authController')
const {dataInsert,massiveDataInsert} = require('../controllers/idMissionController')
const validateRequest = require('../middlewares/validateRequest')
const template = require('../middlewares/schema')

const router = express.Router();

const ENVIRONMENT = process.env.NODE_ENV || 'development';

//*Esto es para aplicar debug sobre las peticiones y las repuestas
if (ENVIRONMENT === 'development') {
  console.log('Developer mode');
  router.use((req, res, next) => {
    let horaEjecucion = new Date().toLocaleString(); 
    console.log('-----------------------------------------------------------------------');
    console.log(`DEV => Method -> ${req.method} Endpoint -> ${req.url} Ip -> ${req.ip} Time -> ${horaEjecucion}`);
    console.log('Parameters:',req.body);
    console.log('-----------------------------------------------------------------------');
    next();
  });

  router.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function (body) {
        console.log('Response sent --> ', body);
        return originalJson.call(this, body);
    };
    next();
});
}


// router.get('/checkConn', checkConn ); //Validar si el api responde

// router.post('/createUser',validateRequest(template.createUser),getToken ); //Generar el token

// router.post('/getToken',validateRequest(template.token),getToken ); //Generar el token
// router.post('/dataInsert',dataInsert ); //Generar el token
// router.post('/massiveDataInsert',massiveDataInsert ); //Generar el token











 //* Con esto manejamos las exepciones de los endpoint que no se encuentren o para un error interno
 router.use((req, res, next) => {
  res.status(404).json({ "status": "Route not found" });
});
router.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ "status": "Internal error" });
});




module.exports = router;
