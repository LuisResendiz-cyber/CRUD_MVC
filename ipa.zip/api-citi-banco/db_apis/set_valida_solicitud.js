const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

 console.log(context);
const baseQuery = "BEGIN " + context.schema + ".XSP_BLOQUEOBYVALIDACION(:id_solicitud, :id_producto, :bandera, :segundosllamda, :origen); END;";
  let query = baseQuery;
  const binds = {};
        let result2 = {};

        if(!context.id_solicitud || !context.id_producto || !context.bandera || !context.segundosllamda || !context.origen){
         // console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{
            binds.id_solicitud      = {val:parseInt(context.id_solicitud) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER}
            binds.id_producto      = {val:parseInt(context.id_producto) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER}
            binds.bandera      = {val:parseInt(context.bandera) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER}
            binds.segundosllamda      = {val:parseInt(context.segundosllamda) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER}
            binds.origen      = {val:parseInt(context.origen) ,dir: oracledb.BIND_IN, type: oracledb.NUMBER}

            const result = await database.simpleExecute(query, binds);

             // console.log(result);

            return result;
        }
}

module.exports.find = find;
