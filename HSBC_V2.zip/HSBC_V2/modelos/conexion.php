<?php

class Conexion {
    private static $username = 'hsbcapp';
    private static $password = 'h0d9c476f1b';
    private static $host = '172.20.1.116';
    private static $connection;

    static public function conectar() {
        // Verificar si la extensión OCI8 está cargada
        if (!function_exists('oci_connect')) {
            throw new Exception('La extensión OCI8 no está instalada o habilitada en PHP.');
        }

        // Intentar establecer la conexión
        self::$connection = @oci_connect(self::$username, self::$password, self::$host, 'AL32UTF8');

        if (!self::$connection) {
            $error = oci_error();
            throw new Exception('Error al conectar a Oracle: ' . $error['message']);
        }

        return true;
    }
}

// Invocar la clase para probar la conexión
try {
    Conexion::conectar();
    echo "Conexión exitosa a la base de datos Oracle.";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
