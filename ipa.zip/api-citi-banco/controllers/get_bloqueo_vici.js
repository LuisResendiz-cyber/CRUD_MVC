const get_bloqueo_vici = require('../db_apis/get_bloqueo_vici.js');

async function post(req, res, next) {
  try {
    const context = req.body;//{};

    const respuesta = await get_bloqueo_vici.give(context);

    if (req.params.id) {
      if (respuesta.length === 1) {
        res.status(200).json(respuesta[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(respuesta);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
