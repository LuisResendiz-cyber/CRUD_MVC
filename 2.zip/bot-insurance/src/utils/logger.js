export const log = (...args) => {
    console.log("[BOT LOG]", ...args);
  };