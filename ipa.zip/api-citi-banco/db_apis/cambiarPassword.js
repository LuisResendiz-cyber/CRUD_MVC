const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
  try {
    const baseQuery = "BEGIN CITIBANCO.spu_cambiapassword_cat(:u_user, :v_password,:v_resultado); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.u_user = context.u_user;
  binds.v_password = context.v_password;
  binds.v_resultado = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
  
  const result = await database.simpleExecute(query, binds);
  // console.log(result); 
  return result;
} catch (error) {
console.log(error);  
}
}
 
module.exports.find = find;
