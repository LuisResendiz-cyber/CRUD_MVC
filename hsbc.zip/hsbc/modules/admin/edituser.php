<?php
require_once("../includes/includes.inc.php");
/****************/
/*EditUser File */
/* @uthor Mark */
/***************/

$id_user = $_GET['idSelected'];

$conn = getConn();
$query = "SELECT ID_USER, NAME,LASTNAME, MAIL FROM USERS WHERE ID_USER=".$id_user;
$statement = execute($conn, $query);
$row = oci_fetch_array ($statement, OCI_NUM);

echo layout_header();
echo '<h4>Editar Usuario</h4>';
echo '<p id="text">Capture los datos<br>';
?>
	<FORM name="forma" method="POST" action="./process.php">
	<input type="hidden" name="action" value="2">
	<input type="hidden" name="idSelected" value="<?=$id_user?>">
	<table width="30%" id="t1" border="1">
	   <tr>
	       <td colspan="2">* Campos Requeridos</td>
	   </tr><tr>
	   	   <td >* Nombre:</td>
		   <td><input type="text" name="name" maxlength="19" size="20" value="<?=$row[1]?>"></td>
	   </tr><tr>
		   <td >* Paterno:</td>
		   <td><input type="text" name="lastname"  maxlength="20" size="20" value="<?=$row[2]?>"></td>
	   </tr><tr>
		   <td >* Mail</td>
		   <td><input type="text" name="mail"  maxlength="20" size="20" value="<?=$row[3]?>"></td>
		</tr>
	</table>
	<br>
	<input type="button" value="Cancelar" onclick="window.location='../index.php'">
	<input type="submit" value="Continuar">
	<br>

<?=layout_footer();?>

         
          