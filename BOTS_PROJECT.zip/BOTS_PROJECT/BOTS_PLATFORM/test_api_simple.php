<?php
// test_api_simple.php - PRUEBA RÁPIDA
require_once("Config/Config.php");
require_once("Helpers/Helpers.php");
require_once("Helpers/api_helper.php");

echo "<h1>Prueba de API desde tu aplicación</h1>";
echo "<p>API URL: " . API_NODE_URL . "</p>";
echo "<p>USE_API: " . (defined('USE_API') && USE_API ? 'SÍ' : 'NO') . "</p>";

// Probar creación de usuario
echo "<h3>Test 2: Probar creación de usuario</h3>";
echo '<form method="POST">';
echo '<input type="submit" name="test_crear" value="Crear usuario de prueba" class="btn btn-primary">';
echo '</form>';

if (isset($_POST['test_crear'])) {
    // Datos similares a los que envía tu controlador Usuarios.php
    $datos_prueba = [
        'customer_id' => 1,
        'name' => 'Prueba',
        'last_name' => 'API',
        'phone_number' => '5512345678',
        'email_user' => 'prueba' . rand(100, 999) . '@test.com',
        'passwordHash' => hash("SHA256", 'test123'),
        'rolid' => 1
    ];
    
    echo "<h4>Enviando a API:</h4>";
    echo "<pre>" . json_encode($datos_prueba, JSON_PRETTY_PRINT) . "</pre>";
    
    $resultado = api_post('Users/CreateUser', $datos_prueba);
    
    echo "<h4>Respuesta de API:</h4>";
    echo "Éxito: " . ($resultado['success'] ? 'SÍ' : 'NO') . "<br>";
    echo "Código: " . $resultado['code'] . "<br>";
    
    if ($resultado['success']) {
        echo "✅ Usuario creado exitosamente en API Node.js<br>";
        echo "<pre>" . json_encode($resultado['data'], JSON_PRETTY_PRINT) . "</pre>";
    } else {
        echo "❌ Error al crear usuario<br>";
        echo "Error: " . ($resultado['error'] ?? 'Desconocido') . "<br>";
    }
}
?>