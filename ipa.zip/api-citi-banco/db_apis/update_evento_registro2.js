const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
 console.log(context);
const baseQuery = "BEGIN " + context.schema + ".xsp_update_eventlog_registro2(:s_id_solicitud,:s_id_user,:s_evento); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};


  binds.s_id_solicitud = context.p_id_solicitud;
  binds.s_id_user = context.p_id_user;
  binds.s_evento = { val: context.evento , dir:oracledb.BIND_IN , type: oracledb.DB_TYPE_VARCHAR };
  console.log(binds);
  const result = await database.simpleExecute(query, binds);
   console.log(result);
  return result;
}

module.exports.find = find;
