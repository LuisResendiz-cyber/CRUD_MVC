const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  console.log("context db apis");
  console.log(context);
  const baseQuery = "BEGIN CITI.SPS_CALIFICADA(:v_fechaBase, :v_fechaDe, :v_fechaAl, :rc); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if (
    context.fechaBase == "" ||
    context.fechaDe == "" ||
    context.fechaAl == ""
  ) {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
    //8314871 7
  } else {
    binds.v_fechaBase = context.fechaBase;
    binds.v_fechaDe = context.fechaDe;
    binds.v_fechaAl = context.fechaAl;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;

    // console.log(context);
    // return context;
  }
}

module.exports.find = find;
