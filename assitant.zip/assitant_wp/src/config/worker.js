// src/config/worker.js
const { Worker } = require('bullmq');
const customerModel = require('../models/customerModel');
const { jobsQueue } = require('../config/queue'); // opcional, no usado aquí
const { sendWhatsAppMessage } = require('../services/whatsappService');
const axios = require('axios');

// === CONFIG ===
const REDIS_CONN = { host: process.env.REDIS_HOST || '127.0.0.1', port: process.env.REDIS_PORT ? Number(process.env.REDIS_PORT) : 6379 };
const LLM_TIMEOUT = 60000; // ms
const CONTEXT_LIMIT = 8; // últimos mensajes a enviar al LLM
const SYSTEM_PROMPT = `
Eres un asistente virtual especializado en explicar tarjetas de crédito (demo).
Tono: profesional, amable y conciso.
Ofreces información sobre: Tarjeta Plata, Tarjeta Oro, Tarjeta Premium.
No inventes datos reales; cuando no sepas, di que es demo.
Responde en español neutro.
`.trim();

// === Mock sendWhatsApp: guarda en DB + logea (reemplazar por tu función real) ===
async function sendWhatsAppMock(to, body) {
  console.log(`[MOCK] Enviando WhatsApp a ${to}: ${body}`);
  try {
    await customerModel.insertWebhookLog({
      event_type: 'message',
      wamid: null,
      from_number: to,
      status: null,
      message_text: body,
      role: 'assistant',
      raw_json: { mock: true, timestamp: Date.now() }
    });
  } catch (e) {
    console.error('Error insertWebhookLog(mock):', e);
  }
  return { ok: true };
}

// === callOllama: llama al endpoint de Ollama local (ajusta si tu endpoint es otro) ===
async function callOllama(messages) {
  try {
    const payload = {
      model: 'phi3',
      stream: false,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages
      ]
    };

    const { data } = await axios.post('http://localhost:11434/api/chat', payload, { timeout: LLM_TIMEOUT });
    // respuesta según formato de Ollama
    const content = data?.message?.content ?? data?.choices?.[0]?.message?.content ?? null;
    return content || null;
  } catch (err) {
    console.error('Error callOllama:', err?.message || err);
    throw err;
  }
}

// === Worker ===
const worker = new Worker(
  'jobs',
  async (job) => {
    console.log('=== Nuevo job recibido ===');
    console.log('Tipo:', job.name);
    console.log('ID Job:', job.id);
    console.log('Data:', job.data);

    if (job.name === 'testJob') {
      console.log('Ejecutando testJob');
      return { ok: true };
    }

    if (job.name === 'inboundMessage') {
      const { from, text, wamid, conversation_id } = job.data;

      console.log('📩 Mensaje del usuario:');
      console.log('Número:', from);
      console.log('Texto:', text);
      console.log('WAMID:', wamid);
      console.log('conversation_id:', conversation_id || '(no)');

      // --- 1) Obtener contexto (preferir conversation_id si viene, sino por phone)
      let history = [];
      try {
        if (conversation_id) {
          history = await customerModel.getLastMessagesByConversation(35);
        } else {
          history = await customerModel.getLastMessagesByConversation(35);
        }
      } catch (e) {
        console.error('Error obteniendo historial:', e);
        history = [];
      }

      // --- 2) Formatear mensajes para el LLM (role: user/assistant)
      const messagesForLLM = [];
      for (const h of history) {
        // h.role puede ser 'user' o 'assistant', y texto puede venir en message_text o message
        const content = h.message || h.message_text || '';
        const role = (h.role === 'assistant') ? 'assistant' : 'user';
        messagesForLLM.push({ role, content });
      }

      // Asegurar que el último mensaje (el actual) esté al final
      messagesForLLM.push({ role: 'user', content: text || '' });

      // --- 3) Llamar a Ollama (LLM)
      let aiResponse = null;
      try {
        aiResponse = await callOllama(messagesForLLM);
        if (!aiResponse) {
          throw new Error('Respuesta vacía de LLM');
        }
      } catch (err) {
        console.error('LLM falló, usar fallback. Error:', err?.message || err);
        aiResponse = "Disculpa, en este momento tengo un problema técnico. En breve te respondemos.";
      }

      // --- 4) Guardar respuesta en BD (role assistant)
      try {
        await customerModel.insertWebhookLog({
          event_type: 'message',
          wamid: null,
          from_number: from,
          status: null,
          message_text: aiResponse,
          role: 'assistant',
          raw_json: { generated_by: 'ollama', timestamp: Date.now() }
        });
      } catch (e) {
        console.error('Error guardando respuesta en DB:', e);
      }

      // --- 5) Enviar respuesta por WhatsApp (mock o real)
      try {
        // Reemplaza sendWhatsAppMock por tu función real cuando estés listo:
        await sendWhatsAppMessage(from, 'Luis REsendiz', 3, aiResponse); // envío real
      } catch (e) {
        console.error('Error enviando WhatsApp (mock):', e);
      }

      console.log('✔️ Job procesado y respuesta enviada.');
      return { processed: true };
    }

    console.warn('Job tipo no reconocido:', job.name);
    return { error: 'job-no-reconocido' };
  },
  { connection: REDIS_CONN }
);

worker.on('completed', (job) => {
  console.log(`✔️ Job completado: ${job.id}`);
});

worker.on('failed', (job, err) => {
  console.error(`❌ Job falló: ${job.id}`, err);
});
