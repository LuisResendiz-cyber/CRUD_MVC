<?php
# @uthor M@rk
# Reportede_llamada File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Reporte de la Llamada");
layout_menu($db,"");
?>
	<p class="textbold">Agentes &gt; Reporte de la Llamada</p>
	<p>&nbsp;</p>
	<form name="frm15" method="post" action="modules.php?mod=agentes&op=nuevoregistro">
	<table class="text" border="0">
		<tr>
			<td colspan="14"><b>Detalles del Cliente</b></td>
		</tr><tr>
			<td colspan="14">&nbsp;</td>
		</tr><tr style="font-weight:bold;" align="center">
            <td>Acci&oacute;n</td>
            <td>&nbsp;</td>
            <td>Solicitud</td>
            <td>&nbsp;</td>
            <td>Nombre Completo</td>
            <td>&nbsp;</td>
            <td>Tel&eacute;fono</td>
            <td>&nbsp;</td>
            <td>TDC</td>
            <td>&nbsp;</td>
            <td>Fecha <br>&uacute;ltimo estado</td>
            <td>&nbsp;</td>
            <td>Estado actual</td>
		</tr>
        <?
            $id_registro = get_session_varname("id_registro");
            $s_usr_id = get_session_varname("s_usr_id");
            $detalle_reg_llamada = get_seguimiento_registro($id_registro, $s_usr_id, $db);
            
            while(!$detalle_reg_llamada->EOF) {
                $v_base = $detalle_reg_llamada->fields["BASE"];
                echo '<tr align="center">
                        <td><input type="radio" onclick="habilita_sol('.$v_base.')" name="id_solicitud" id="id_solicitud" value="'.$detalle_reg_llamada->fields["ID_SOLICITUD"].'"></td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["ID_SOLICITUD"].'</td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["MAIN_NOMBRE_COMPLETO"].'</td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["MAIN_TEL_01"].'</td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["MAIN_TDC"].'</td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["FECHA_ULTIMO_STATUS"].'</td>
                        <td>&nbsp;</td>
                        <td class="textleft">'.$detalle_reg_llamada->fields["ESTADO"].'</td>
                    </tr>';
                $detalle_reg_llamada->MoveNext();
            }
        ?>
        <tr>
			<td colspan="14">&nbsp;</td>
         </tr><tr>
			<td colspan="14">
				<input type="button" name="btn_califica_llamada" id="btn_califica_llamada" value="Calificar Llamada" onclick="RegistroIncompleto('1')"/>&nbsp; &nbsp;
				<input type="button" name ="btn_solicitud" id="btn_solicitud" value="Solicitud" onclick="RegistroIncompleto('2')" disabled />&nbsp; &nbsp;
				<!--input type="button" name ="btn_nuevo_registro" id="btn_nuevo_registro" value="Nuevo registro" onclick="RegistroIncompleto('3')" disabled/>&nbsp; &nbsp;-->
				<input type="button" name="btn_regresar" id="btn_regresar" value="Regresar" onclick="RegistroIncompleto('4')" />
			</td>
		</tr><tr>
			<td colspan="14">&nbsp;</td>
		</tr>
	</table>
	</form>
<?
layout_footer();
?>