const oracledb = require("oracledb");
const database = require("../services/database.js");
async function find(context) {
  //let query = baseQuery;
  //const binds = {};
  let result2 = {};

  let arrayd = JSON.parse(context.array_datos);
  console.log(arrayd);
  var longitud = Object.keys(arrayd).length;
  console.log(longitud);

  if (context.array_datos == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else {
    for (let i = 0; i < longitud; i++) {
      var BASE = arrayd[i]["BASE"];
      var ETIQUETA_REG = arrayd[i]["ETIQUETA_REG"];
      var NOMBRE = arrayd[i]["NOMBRE"];
      var CALLE = arrayd[i]["CALLE"];
      var COLONIA = arrayd[i]["COLONIA"];
      var POBLACION = arrayd[i]["POBLACION"];
      var EDO = arrayd[i]["EDO"];
      var CP = arrayd[i]["CP"];
      var RFC = arrayd[i]["RFC"];
      var CELULAR_CERTIFICADO = arrayd[i]["CELULAR_CERTIFICADO"];
      var Ter_TC = arrayd[i]["Ter_TC"];
      var cuatro_digitos = arrayd[i]["cuatro_digitos"];
      var Ter_Ch = arrayd[i]["Ter_Ch"];
      var FECHA_NACIMIENTO = arrayd[i]["FECHA_NACIMIENTO"];
      var SEXO = arrayd[i]["SEXO"];
      var NUMCLIENTE = arrayd[i]["NUMCLIENTE"];
      var CALL_CENTER = arrayd[i]["CALL_CENTER"];
      var EMAIL = arrayd[i]["EMAIL"];
      var OFERTA_PROD = arrayd[i]["OFERTA_PROD"];
      var oferta_doble = arrayd[i]["oferta_doble"];
      var CONSECUTIVO = arrayd[i]["CONSECUTIVO"];

      console.log(values);

      // const baseQuery = "BEGIN CITI.XSP_INSERTTUCARGABASE(:array, :rc); END;";
      let query = baseQuery;
      const binds = {}; //Define un objeto para la variable SP
    }

    binds.BASE = BASE;
    binds.ETIQUETA_REG = ETIQUETA_REG;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;
