<?php
require_once "conexion.php";

class ModeloUsuarios{

	static public function mdlMostrarUsuarios($tabla, $item, $valor){
		if ($item != null) {
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");
			$stmt->bindParam(":" . $item, $valor, PDO::PARAM_STR);
			$stmt->execute();
			return $stmt->fetch();
		} else {
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");
			$stmt->execute();
			return $stmt->fetchAll();
		}
		$stmt->close();
		$stmt = null;
	}

	static public function mdlMostrarCampanasAsignadas($id){
		$stmt = Conexion::conectar()->prepare("select cc.id_campana from usuario_campana uc
		join cat_campanas cc on uc.id_campana = cc.id_campana where id_usuario = :id");		    
		$stmt->bindParam(":id", $id, PDO::PARAM_INT);
		$stmt->execute();
		$result = $stmt->fetchAll(PDO::FETCH_ASSOC);	
		$stmt->closeCursor();
		return $result;
	}

	      static public function mdlMostrarEnlaces($item, $id) {
		if ($item != null) {
		    $stmt = Conexion::conectar()->prepare("SELECT e.id, e.titulo, e.url, cc.NOMBRE_CAMPANA  
				    FROM enlaces e 
				    JOIN usuario_campana uc ON e.id_campana = uc.id_campana
				    JOIN cat_campanas cc ON cc.id_campana = e.id_campana 
				    JOIN usuarios u ON uc.id_usuario = u.id 
				    WHERE u.id = :id");		    
		    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
		    $stmt->execute();
		    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);	
		    $stmt->closeCursor();
		    return $result;
		}
	      }


	      static public function mdlObtenerCampanasId($item, $id) {
		if ($item != null) {
		    $stmt = Conexion::conectar()->prepare("select cc.id_campana from usuario_campana uc
		    join cat_campanas cc on uc.id_campana = cc.id_campana where id_usuario = :id");		    
		    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
		    $stmt->execute();
		    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);	
		    $stmt->closeCursor();
		    return $result;
		}
	      }
	      
	      

	static public function mdlIngresarUsuario($tabla, $datos)
	{
		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(nombre, usuario, password, perfil, estado) VALUES (:nombre, :usuario, :password, :perfil,0 )");
		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datos["password"], PDO::PARAM_STR);
		$stmt->bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);

		if ($stmt->execute()) {



			return "ok";
		} else {



			return "error";
		}



		$stmt->close();



		$stmt = null;
	}

	static public function mdlAsignarCampaña($tabla, $datos)
	{



		try {
			// Preparar el statement una vez para reutilizarlo

			$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (id_usuario, id_campana) VALUES (:id_usuario, :id_campana)");

			// id del usuario
			$idUsuario = $datos["id_Usuario"];

			// Iterar sobre $datos para extraer las campañas
			foreach ($datos as $key => $idCampana) {
				// Filtrar solo las claves que empiezan con 'id_' y evitar `id_Usuario`
				if ($key !== "id_Usuario" && strpos($key, 'id_') === 0) {
					$stmt->bindValue(":id_usuario", $idUsuario, PDO::PARAM_INT);
					$stmt->bindValue(":id_campana", $idCampana, PDO::PARAM_INT);

					// Ejecutar el insert para cada campaña
					if (!$stmt->execute()) {
						// Ver información detallada sobre el error si `execute` falla
						//var_dump($stmt->errorInfo());
						return "error"; // Si alguna inserción falla, devolver "error"
					}
				}
			}

			return "ok"; // Si todas las inserciones fueron exitosas

		} catch (Exception $th) {
			echo $th->getMessage();
			return "error";
		} finally {
			$stmt = null;
		}
	}


	static public function mdlEditarUsuario($tabla, $datos)
	{

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET nombre = :nombre, password = :password, perfil = :perfil WHERE usuario = :usuario");
		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datos["password"], PDO::PARAM_STR);
		$stmt->bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);
		$stmt->bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			return "ok";
		} else {
			return "error";
		}
		$stmt->close();
		$stmt = null;
	}

	static public function mdlActualizarUsuario($tabla, $item1, $valor1, $item2, $valor2)
	{



		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET $item1 = :$item1 WHERE $item2 = :$item2");



		$stmt->bindParam(":" . $item1, $valor1, PDO::PARAM_STR);

		$stmt->bindParam(":" . $item2, $valor2, PDO::PARAM_STR);



		if ($stmt->execute()) {



			return "ok";
		} else {



			return "error";
		}



		$stmt->close();



		$stmt = null;
	}

	static public function mdlBorrarUsuario($tabla, $datos)
	{



		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");



		$stmt->bindParam(":id", $datos, PDO::PARAM_INT);



		if ($stmt->execute()) {



			return "ok";
		} else {



			return "error";
		}



		$stmt->close();



		$stmt = null;
	}
}
