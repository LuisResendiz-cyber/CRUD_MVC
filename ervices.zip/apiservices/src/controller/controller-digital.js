const ExcelJS = require("exceljs");
const fs = require("fs");
const path = require("path");
const actMailer = require("../model/model-mailer");
const {
  createConnObj,
  oraExcQuery,
  oraExcProc2,
} = require("../model/model-oracle");
const { actionsMysql } = require("../model/model-mysql");

const outputPath = path.join(__dirname, "..", "public/csv/");

const digital = {
  conteoLeadsAut: async (req, res) => {
    const campaign = 1008;
    const query = `
    
SELECT
    nvl(SUM(CASE 
        WHEN UPPER(ETIQUETA_REG) LIKE '%AUTOCCP%' THEN 1
        ELSE 0  
    END),0) AS AUTO,
    nvl(SUM(CASE 
        WHEN UPPER(ETIQUETA_REG) NOT LIKE '%AUTOCCP%' THEN 1
        ELSE 0
    END),0) AS DIGITAL
FROM AMEXINSURANCEDIG.TU_CARGABASE_2
WHERE DATE_DSA BETWEEN SYSDATE - INTERVAL '1' HOUR AND SYSDATE

      `;

    const now = new Date();
    let intervalo = `${String(now.getHours() - 1).padStart(
      2,
      "0"
    )}:00:00 - ${String(now.getHours()).padStart(2, "0")}:00:00`;

    try {
      const rspta = await oraExcQuery(campaign, query);
      // console.log(rspta[0]);
      //  return

      const mails = await actionsMysql.mailsAsistencia(6);
      if (mails.length == 0) {
        res.json({
          status: 200,
          rspta:
            "Reporte conteo digital no enviado, sin remitentes para este correo",
        });
        return;
      }
      const emailAddresses = mails.map((emailObj) => emailObj.MAILS);
      const emailString = emailAddresses.join(",");

      const htmlPath = path.join(
        __dirname,
        `../public/html/reporteAsistencia.html`
      );
      // htmlContent = fs.readFileSync(htmlPath, "utf-8");
      let htmlContent = `
        <style>
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }
    
    td, th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }
    
    tr:nth-child(even) {
      background-color: #dddddd;
    }
    </style>
      <table>
  <tr>

    <th>Horario</th>
    <th>Digital</th>
    <th>Auto</th>
  </tr>

    <tr>
      <td>${intervalo}</td>
      <td>${rspta[0].AUTO}</td>
      <td>${rspta[0].DIGITAL}</td>      
    </tr>
</table>
      `;

      const mailOptions = {
        to: emailString,
        subject: "Reporte conteo leads carga aut digital",
        html: htmlContent,
      };
      let nObjMailer = await actMailer.createObjMailer(mailOptions);

      if (nObjMailer != 200) {
        await actionsMysql.saveLogCron(
          "REPORTE CONTEO LEADS DIGITAL NO ENVIADO",
          0
        );
        console.log("Error al enviar CONTEO LEADS DIGITA: ", nObjMailer);
        res.send("Error al enviar CONTEO LEADS DIGITA");
        return;
      }

      console.log("REPORTE CONTEO LEADS DIGITAL ENVIADO: ", nObjMailer);
      await actionsMysql.saveLogCron("REPORTE LEADS DIGITAL", 1);
      res.json({ status: 200, rspta: "MAILS SENT" });
    } catch (error) {
      console.log(error);
      res.json(error);
    }
  },

  asistencia: async (req, res) => {
    const campaign = 1008;
    const nameProcedure = "XSP_ASISTENCIA_AGENTES";
    const parameters = { v_option: 2 };
    const localExcelPath = outputPath + "ReporteAsistenciaDig.xlsx";

    try {
      objConnOracle = await createConnObj(campaign, nameProcedure, parameters);

      if (objConnOracle == null || objConnOracle == undefined) {
        res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
        return;
      }
      const oraRspta = await oraExcProc2(objConnOracle);
      if (oraRspta.length == 0) {
        console.log("NO DATA IN ORACLE");
        res.json({ status: 402, rspta: "NO DATA IN ORACLE" });
        return;
      }

      const reportGenerated = await createReport(oraRspta, localExcelPath);
      if (!reportGenerated.success) {
        console.error("Error al generar el reporte:", reportGenerated.error);
        return res.status(400).json({
          status: 400,
          rspta: "ERROR GENERATING REPORT",
          details: reportGenerated.error,
        });
      }
      const fileExists = await fs.promises
        .access(localExcelPath)
        .then(() => true)
        .catch(() => false);

      if (!fileExists) {
        console.error("El archivo de reporte no existe");
        return res.status(400).json({
          status: 400,
          rspta: "REPORT FILE NOT FOUND",
        });
      }

      const mailSent = await sendMail(campaign, localExcelPath);
      if (!mailSent) {
        console.error("Error al enviar el correo");
        return res.status(400).json({
          status: 400,
          rspta: "ERROR SENDING EMAIL",
        });
      }

      // Éxito
      return res.json({
        status: 200,
        rspta: "Report prepared and sent successfully",
      });
    } catch (error) {
      console.error("Error en el proceso completo:", error);
      return res.status(500).json({
        status: 500,
        rspta: "INTERNAL SERVER ERROR",
        details: error.message,
      });
    }
  },
};

const bau = {
  asistencia: async (req, res) => {
    const campaign = 996;
    const nameProcedure = "XSP_ASISTENCIA_AGENTES";
    const parameters = { v_option: 2 };
    const localExcelPath = outputPath + "ReporteAsistenciaBau.xlsx";
    try {
      objConnOracle = await createConnObj(campaign, nameProcedure, parameters);

      if (objConnOracle == null || objConnOracle == undefined) {
        res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
        return;
      }
      const oraRspta = await oraExcProc2(objConnOracle);
      if (oraRspta.length == 0) {
        console.log("NO DATA IN ORACLE");
        res.json({ status: 402, rspta: "NO DATA IN ORACLE" });
        return;
      }

      const reportGenerated = await createReport(oraRspta, localExcelPath);
      if (!reportGenerated.success) {
        console.error("Error al generar el reporte:", reportGenerated.error);
        return res.status(400).json({
          status: 400,
          rspta: "ERROR GENERATING REPORT",
          details: reportGenerated.error,
        });
      }

      const fileExists = await fs.promises
        .access(localExcelPath)
        .then(() => true)
        .catch(() => false);

      if (!fileExists) {
        console.error("El archivo de reporte no existe");
        return res.status(400).json({
          status: 400,
          rspta: "REPORT FILE NOT FOUND",
        });
      }

      const mailSent = await sendMail(campaign, localExcelPath);
      if (!mailSent) {
        console.error("Error al enviar el correo");
        return res.status(400).json({
          status: 400,
          rspta: "ERROR SENDING EMAIL",
        });
      }

      // Éxito
      return res.json({
        status: 200,
        rspta: "Report prepared and sent successfully",
      });
    } catch (error) {
      console.error("Error en el proceso completo:", error);
      return res.status(500).json({
        status: 500,
        rspta: "INTERNAL SERVER ERROR",
        details: error.message,
      });
    }
  },
};

const createReport = async (datos, localExcelPath) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const date = new Date();
    const nombreMes = date.toLocaleString('es-ES', { month: 'long' });

    const [month, day, year] = [
      date.getMonth() + 1,
      date.getDate(),
      date.getFullYear(),
    ];
    const worksheet = workbook.addWorksheet(`Asistencia- ${nombreMes}`);

    const c_month = month.toString().padStart(2, '0');

    const columnDefinitions = [
      { header: 'NOMINA', key: 'NOMINA', width: 10 },
      { header: 'NOMBRE AGENTE', key: 'NOMBE_AGENTE', width: 30 },
    ];
    const numberDays = [];

    const diasSemana = ['DOM', 'LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB'];
    for (let i = 1; i <= day; i++) {
      const dia = i.toString().padStart(2, '0');
      const fecha = new Date(year, c_month - 1, i);
      const diaSemana = diasSemana[fecha.getDay()];
      columnDefinitions.push({
        header: diaSemana,
        key: `DIA_${dia}`,
        width: 8,
      });

      numberDays.push({
        header: `${dia}/${c_month}/${year}`,
        key: `D_${dia}`,
        width: 12,
      });
    }

    worksheet.columns = columnDefinitions;

    // Aplicar estilo a fila 1 (encabezados)
    const headerRow = worksheet.getRow(1);
    headerRow.eachCell((cell) => {
      cell.font = { bold: false, color: { argb: 'FFFFFFFF' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '002060' },
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    // Fila de fechas
    const diasRow = worksheet.getRow(2);
    numberDays.forEach((day, index) => {
      const cell = diasRow.getCell(index + 3);
      cell.value = day.header;
      cell.font = { color: { argb: 'FFFFFFFF' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '002060' },
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    const grupos = {};
    datos.forEach((empleado) => {
      const supervisor = empleado.NOMBE_SUPER;
      if (!grupos[supervisor]) {
        grupos[supervisor] = [];
      }
      grupos[supervisor].push(empleado);
    });

    // Variables para acumular totales
    let totalAsistenciasGeneral = 0;
    const totalEmpleados = datos.length;
    const totalDiasEvaluados = totalEmpleados * day;

    for (const [supervisor, empleados] of Object.entries(grupos)) {
      empleados.forEach((empleado) => {
        const rowData = {
          NOMINA: empleado.NOMINA,
          NOMBE_AGENTE: empleado.NOMBE_AGENTE,
        };
        
        for (let i = 1; i <= day; i++) {
          const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
          rowData[diaKey] = empleado[diaKey];
        }
        
        const row = worksheet.addRow(rowData);
        
        // Aplicar estilos a las celdas de días
        for (let i = 1; i <= day; i++) {
          const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
          const cell = row.getCell(diaKey);
          const value = empleado[diaKey];
          if (value) {
            const style = getCellStyle(value);
            cell.style = style;
          }
        }
      });

      // Calcular totales por supervisor
      const totalSupervisorRow = worksheet.addRow({
        NOMINA: '',
        NOMBE_AGENTE: `${supervisor}`,
        TIPO: 'TOTAL SUPERVISOR',
      });

      let totalAsistenciasSuper = 0;
      for (let i = 1; i <= day; i++) {
        const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
        let totalAsistencias = 0;

        empleados.forEach((empleado) => {
          if (empleado[diaKey] === 'A') {
            totalAsistencias++;
            totalAsistenciasSuper++;
          }
        });

        totalSupervisorRow.getCell(diaKey).value = totalAsistencias;
      }

      // Acumular para el total general
      totalAsistenciasGeneral += totalAsistenciasSuper;

      // Aplicar estilos a la fila de supervisor
      totalSupervisorRow.eachCell((cell) => {
        cell.font = { bold: false, color: { argb: 'FFFFFFFF' } };
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: '1e2f72' }
        };
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' },
        };
        if (cell.numFmt === undefined && cell.value !== null) {
          cell.alignment = { vertical: 'middle', horizontal: 'center' };
        }
      });
    }

    // Agregar filas de REAL, OBJETIVO y CUMPLIMIENTO
    const estiloFilasFinales = {
      font: { bold: false, color: { argb: 'FFFFFFFF' } },
      fill: {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '1e2f72' }
      },
      border: {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      },
      alignment: { vertical: 'middle', horizontal: 'center' }
    };

    // Fila REAL
    const realRow = worksheet.addRow({
      NOMINA: '',
      NOMBE_AGENTE: 'REAL',
    });

    // Llenar valores para días
    for (let i = 1; i <= day; i++) {
      const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
      let totalAsistencias = 0;
      datos.forEach(empleado => {
        if (empleado[diaKey] === 'A') {
          totalAsistencias++;
        }
      });
      realRow.getCell(diaKey).value = totalAsistencias;
    }

    // Fila OBJETIVO
    const objetivoRow = worksheet.addRow({
      NOMINA: '',
      NOMBE_AGENTE: 'OBJETIVO',
    });

    // Llenar con total de empleados (mismo valor para todos los días)
    for (let i = 1; i <= day; i++) {
      const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
      objetivoRow.getCell(diaKey).value = totalEmpleados;
    }

    // Fila CUMPLIMIENTO
    const cumplimientoRow = worksheet.addRow({
      NOMINA: '',
      NOMBE_AGENTE: 'CUMPLIMIENTO',
    });

    // Calcular porcentaje para cada día
    for (let i = 1; i <= day; i++) {
      const diaKey = `DIA_${i.toString().padStart(2, '0')}`;
      const real = realRow.getCell(diaKey).value;
      const objetivo = objetivoRow.getCell(diaKey).value;
      cumplimientoRow.getCell(diaKey).value = real / objetivo;
      cumplimientoRow.getCell(diaKey).numFmt = '0.00%';
    }

    // Aplicar estilos a las filas
    [realRow, objetivoRow, cumplimientoRow].forEach(row => {
      row.eachCell(cell => {
        Object.assign(cell.style, estiloFilasFinales);
      });
    });

    // Ajustar anchos de columnas
    for (let i = 3; i <= day + 2; i++) {
      worksheet.getColumn(i).width = 8;
    }
    worksheet.getColumn(2).width = 30; // Columna de nombre

    // Aplicar bordes a todas las celdas
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber > 1) {
        row.eachCell((cell) => {
          if (!cell.style) cell.style = {};
          cell.style.border = {
            top: { style: 'thin' },
            left: { style: 'thin' },
            bottom: { style: 'thin' },
            right: { style: 'thin' },
          };
          if (cell.numFmt === undefined && cell.value !== null) {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
          }
        });
      }
    });

    // Guardar el archivo
    await workbook.xlsx.writeFile(localExcelPath);
    console.log('Archivo creado correctamente!');
    return { success: true };
  } catch (error) {
    console.error('Error al crear el reporte:', error);
    return {
      success: false,
      error: error.message,
    };
  }
};




function getCellStyle(value) {
  const style = {
    font: {},
    fill: {},
    alignment: { horizontal: "center" },
  };

  switch (value.toUpperCase()) {
    case "A":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFFFFFFF" }, //Verde
      };
      // style.font = { bold: true };
      break;
    case "F":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "c21d03" }, //rojo
      };
      style.font = { color: { argb: "FFFFFFFF" }, bold: true }; // Texto blanco
      break;
    case "DES":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "1e2f72" },
      }; //AZUL
      style.font = { color: { argb: "FFFFFFFF" } };
      break;
    case "VAC":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "ccff99" },
      }; //ANARANJADO
      // style.font = { color: { argb: 'FFFFFFFF' } }; // Texto blanco
      break;
    case "JM":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "cc99ff" }, //morado
      }; //ANARANJADO
      // style.font = { color: { argb: 'FFFFFFFF' } }; // Texto blanco
      break;
    case "INCAPACIDAD IMSS":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FF7F50" },
      }; //ANARANJADO
      // style.font = { color: { argb: 'FFFFFFFF' } }; // Texto blanco
      break;
    case "ASISTENCIA JUSTIFICADA":
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "cc99ff" },
      }; //ANARANJADO
      // style.font = { color: { argb: 'FFFFFFFF' } }; // Texto blanco
      break;
    default:
      style.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFFFFFFF" },
      };
  }

  return style;
}

const sendMail = async (act, localExcelPath) => {
  const nameReport = act == 1008 ? "DIGITAL" : "BAU";
  const numerMails = act == 1008 ? 7 : 8;

  try {
    // 1. Obtener destinatarios
    const mails = await actionsMysql.mailsAsistencia(numerMails);
    if (!mails || mails.length === 0) {
      console.error("No hay remitentes para este correo");
      await actionsMysql.saveLogCron(
        `REPORTE ASISTENCIA ${nameReport} NO ENVIADO - SIN REMITENTES`,
        0
      );
      return false;
    }

    // 2. Validar existencia del archivo
    try {
      await fs.promises.access(localExcelPath);
    } catch (error) {
      console.error("El archivo adjunto no existe:", localExcelPath);
      await actionsMysql.saveLogCron(
        `REPORTE ASISTENCIA ${nameReport} NO ENVIADO - ARCHIVO NO ENCONTRADO`,
        0
      );
      return false;
    }

    // 3. Preparar contenido del correo
    const emailAddresses = mails.map((emailObj) => emailObj.MAILS);
    const emailString = emailAddresses.join(",");

    const htmlContent = `
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reporte de Asistencia</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
    
            .banner {
                background: linear-gradient(135deg, #006fcf 0%, #004a8f 100%);
                color: white;
                padding: 30px 40px;
                position: relative;
                overflow: hidden;
                min-height: 150px;
                border-radius: 10px;
                box-shadow: 0 10px 30px rgba(0, 111, 207, 0.2);
                margin-bottom: 20px;
            }
    
            .banner-content {
                z-index: 2;
                position: relative;
            }
    
            .banner h1 {
                font-size: 2.5rem;
                font-weight: 700;
                margin-bottom: 10px;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
    
            .banner p {
                font-size: 1.1rem;
                opacity: 0.9;
                max-width: 600px;
            }
    
            .banner-decoration {
                position: absolute;
                width: 200px;
                height: 200px;
                background-color: rgba(255, 255, 255, 0.1);
                border-radius: 50%;
                right: -50px;
                top: -50px;
            }
    
            .banner-decoration:nth-child(2) {
                width: 300px;
                height: 300px;
                right: -100px;
                top: auto;
                bottom: -100px;
                background-color: rgba(255, 255, 255, 0.05);
            }
    
            .stats-container {
                display: flex;
                gap: 20px;
                margin-top: 20px;
            }
    
            .stat-item {
                background-color: rgba(255, 255, 255, 0.15);
                padding: 15px 20px;
                border-radius: 8px;
                min-width: 120px;
                text-align: center;
            }
    
            .stat-value {
                font-size: 1.8rem;
                font-weight: 700;
                margin-bottom: 5px;
            }
    
            .stat-label {
                font-size: 0.9rem;
                opacity: 0.8;
            }
    
            .message {
                font-size: 1rem;
                color: #333;
                margin: 20px 0;
                line-height: 1.5;
            }
        </style>
    </head>
    <body>
        <div class="banner">
            <div class="banner-content">
                <h1>Reporte de asistencia</h1>                

            </div>
            
            <div class="banner-decoration"></div>
            <div class="banner-decoration"></div>
        </div>
    
        <div class="message">
            <p>Este es un mensaje automático, por favor no responder directamente a este correo.</p>
        </div>
    </body>
    </html>`;

    const mailOptions = {
      to: emailString,
      subject: `Reporte de asistencia ${nameReport}`,
      html: htmlContent,
      attachments: [
        {
          filename: `Reporte_Asistencia_${nameReport}.xlsx`,
          path: localExcelPath,
          contentType:
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        },
      ],
    };

    // 4. Enviar correo
    const mailResult = await actMailer.createObjMailer(mailOptions);

    if (mailResult !== 200) {
      console.error(`Error al enviar rep ASISTENCIA ${nameReport}`, mailResult);
      await actionsMysql.saveLogCron(
        `REPORTE ASISTENCIA ${nameReport} NO ENVIADO - ERROR DE ENVÍO`,
        0
      );
      return false;
    }
    await actionsMysql.saveLogCron(
      `REPORTE ASISTENCIA ${nameReport} ENVIADO`,
      1
    );
    return true;
  } catch (error) {
    console.error("Error inesperado en sendMail:", error);
    await actionsMysql.saveLogCron(
      `REPORTE ASISTENCIA ${nameReport} NO ENVIADO - ERROR INESPERADO`,
      0
    );
    return false;
  }
};

module.exports = { digital, bau };
