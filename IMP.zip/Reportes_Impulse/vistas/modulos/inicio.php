<div class="content-wrapper">
  <section class="content-header">
    <h1>Tablero<small>Panel de Control</small></h1>
    <ol class="breadcrumb">
      <li><a href="?ruta=inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      <li class="active">Tablero</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
    </div>
    <div class="row">
        <div class="col-lg-12">
        </div>
        <div class="col-lg-6">
        </div>
         <div class="col-lg-6">
        </div>
        <div class="col-lg-12">
         <div class="box box-success">
                  <div class="box-header">
                    <!-- Iframe con un src por defecto (vacío o un URL predeterminado) -->
                    <iframe id="myIframe" src="" height="700" width="1380"></iframe> 
                  </div>
        </div>
        </div>
     </div>
  </section>
</div>



<script>
document.addEventListener("DOMContentLoaded", function() {
    // Obtener todos los enlaces con la clase .cargarIframe
    var enlaces = document.querySelectorAll('.cargarIframe');

    // Agregar un listener para cada enlace
    enlaces.forEach(function(enlace) {
        enlace.addEventListener('click', function(event) {
            event.preventDefault(); // Evitamos que el enlace cargue la página

            // Obtener la URL del iframe desde el atributo data-url
            var urlIframe = this.getAttribute('data-url');
        

            const test = 'vistas/modulos/header.php?url=' + urlIframe; // Codificar en Base64
            document.getElementById('myIframe').src = test;
        });
    });
});
</script>
