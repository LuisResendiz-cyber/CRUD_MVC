const bloqueo_reus = require("../db_apis/bloqueo_reus.js");
const fetch = require("node-fetch");

async function post(req, res, next) {
  try {
    const context = req.body; //{};
    var sin_valor = 0;

    const respuesta = await bloqueo_reus.give(context);
    console.log("respuesta.length= " + respuesta.length);
    var tipo_bloqueo = context.tipo;
    if (respuesta.length > 0) {
      respuesta.forEach(function (element) {
        //  console.log(element["SIN_VALOR"]);
        if ("SIN_VALOR" in element) {
          if (element["SIN_VALOR"] === 0) {
            res.status(200).json("Sin registros a bloquear");
            sin_valor = 1;
          }
        } else {
          console.log(element["U_TELEFONO"]);

           var ligaPeticion = "http://172.33.62.183:3000/api-predictivo/bloqueoReus/" + element["U_TELEFONO"] + "/" + tipo_bloqueo;
          // var ligaPeticion = "http://172.20.2.66:3000/api-predictivo/bloqueoReus/" + element["U_TELEFONO"] + "/" + tipo_bloqueo;
          // console.log(ligaPeticion);
          fetch(ligaPeticion)
            .then((response) => response.json())
            .then((data) => {
              // Aquí puedes procesar los datos obtenidos de la API externa
              context["respuesta"] = element["TELEFONO"] + ": " + JSON.stringify(data["bloqueo"]);
              context["u_persona"] = element["U_PERSONA"];
              // console.log(element);
              // console.log(context.respuesta);
              const respuesta2 = bloqueo_reus.insert(context);
            })
            .catch((error) => {
              console.error("Error:", error);
            });
        }
      });
      if (sin_valor === 0) {
        // res.status(200).json(respuesta);
        const resultado_bloqueo = { VALOR: 0, BLOQUEOS: respuesta.length, };
        res.status(200).json(resultado_bloqueo);
      }
    } else {
      res.status(404).end();
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
