<?php
set_time_limit(300);
//ini_set("display_errors", 1);
# Download File 
# @uthor Mark     

require_once("includes/includes.inc.php");
require_once("modules/layoutFile.inc.php");

$file_name = desencrypt($_GET["file_name"]);
$file_data_path = desencrypt($_GET["file_data"]);
$Datos = array();

header("Content-Type: text/plain");
header("content-disposition: attachment;filename=".$file_name."");

	//echo "<pre>";
	$f = fopen($file_data_path, "r");
	while ($lines = fgets($f, 1000) ) {
		$line = explode(",",$lines);
		
		if($_REQUEST["surveyid"] == 6){
			$rs = get_data_file_to_download($line[0], $_REQUEST["surveyid"], $conn);
			$fecha = $rs->fields["RESPONSEDATE"];
			echo "|0014"; 
			echo "|" . $rs->fields["CONTRATO"] . "|" . $rs->fields["SUCURSAL"];
			echo  "|" . $rs->fields["DIGITOS"]. "|" . $rs->fields["NOMBRE"] ." " . $rs->fields["PATERNO"] . " " . $rs->fields["MATERNO"];
			echo  "|BASICO|COBRO";
			
				$rs1 = get_datosBD($rs->fields["U_PERSONA"],$conn);
				
				echo  "|" . $rs1->fields["COBRO"] . "|" . $fecha;
				echo  "|" . $rs1->fields["DESC_PRODUCTO"] . "|" . $rs->fields["RFC"];
				echo  "|" . $rs1->fields["FOLIO_CAMP"] . "|";
			
				if(strlen(trim($rs->fields["CALLE"])) > 0){
					echo $rs->fields["CALLE"] . " No ". $rs->fields["EXT"];
					if (strlen(trim($rs->fields["INT"])) > 0 ){
						echo " Int " . $rs->fields["INT"];
					}
					$rs2 = get_domiciliocompleto($rs->fields["CODIGO"],$rs->fields["MUNICIPIO"],$rs->fields["ESTADO"],$conn);
					echo "|" .$rs->fields["COLONIA"]. "|" . $rs->fields["CODIGO"];
					echo "|".$rs2->fields["MUNICIPIO"] . "|"; 				
					echo $rs2->fields["ESTADO"] . "|";
				}
			echo chr(13).chr(10);
			//--echo  "<br>";
		} else {
			if($line[1] != 7 && $line[1] != 8 && $line[1] != 9 && $line[1] != 10){
				$rs = get_data_file_to_download($line[0], $line[1], $conn);
				echo  completa (26,$rs->fields["CODIGO_BARRAS"]) . "|";  #Codigo de Barras
				echo  ceros(2,$rs->fields["DIGITOS"]) . "|";  #Ultimos 2 digitos				
					
				if($rs->fields["SURVEYID"] == 1 || $rs->fields["SURVEYID"] == 11 || $rs->fields["SURVEYID"] == 12 || $rs->fields["SURVEYID"] == 7 || $rs->fields["SURVEYID"] == 8 || $rs->fields["SURVEYID"] == 9 || $rs->fields["SURVEYID"] == 10 || $rs->fields["SURVEYID"] == 22){
					$con_cobro = 6;
				}else if($rs->fields["SURVEYID"] == 2 || $rs->fields["SURVEYID"] == 21){
					$con_cobro = 5;
				}else if($rs->fields["SURVEYID"] == 3 || $rs->fields["SURVEYID"] == 4 || $rs->fields["SURVEYID"] == 5 || $rs->fields["SURVEYID"] == 13 || $rs->fields["SURVEYID"] == 21 || $rs->fields["SURVEYID"] == 22){
					$con_cobro = $rs->fields["COBRO"];
				}
				
				echo  $con_cobro . "|";  # Su pago es con TC o Cheques
				if($con_cobro == 6 ){
					echo $rs->fields["DESC_PRODUCTO"] . "|"; #tipo de tdc
				} else {
					echo "|" ;
				}

				if($rs->fields["SURVEYID"] == 1 || $rs->fields["SURVEYID"] == 11 || $rs->fields["SURVEYID"] == 12){
					echo "0074|"; #ramo
				}else if($rs->fields["SURVEYID"] == 2){
					echo "0026|"; #ramo
				}else if($rs->fields["SURVEYID"] == 3){
					echo "0092|"; #ramo
				}else if($rs->fields["SURVEYID"] == 4){
					echo "0091|"; #ramo
				}else if($rs->fields["SURVEYID"] == 5){
					echo "0090|"; #ramo
				}else if($rs->fields["SURVEYID"] == 13){
					echo "0003|"; #ramo
				}else if($rs->fields["SURVEYID"] == 21){
					echo "0080|"; #ramo
				}else if($rs->fields["SURVEYID"] == 22){
					echo "0081|"; #ramo
				}
					
							
				$cuenta = 0;
				if(strlen(trim($rs->fields["CALLE"])) > 1){ $cuenta += 1; }
				if(strlen(trim($rs->fields["EXT"])) > 1){ $cuenta += 1; }			
				if(strlen(trim($rs->fields["INT"])) > 1){ $cuenta += 1; }
				if(strlen(trim($rs->fields["CODIGO"])) > 1){ $cuenta += 1; }
				if(strlen(trim($rs->fields["COLONIA"])) > 1){ $cuenta += 1; }
				if(strlen(trim($rs->fields["MUNICIPIO"])) > 1){ $cuenta += 1; }
										
				if($cuenta >= 4){
					$rs1 = get_domiciliocompleto($rs->fields["CODIGO"],$rs->fields["MUNICIPIO"],$rs->fields["ESTADO"],$conn);

					if(strlen(trim($rs->fields["INT"])) > 0  && trim($rs->fields["INT"]) != ""){
						echo  $rs->fields["CALLE"] . " " . $rs->fields["EXT"] . " INT " . $rs->fields["INT"] . "|";	#Calle , NoExt y NoInt (Domicilio)
					}else if (strlen(trim($rs->fields["INT"])) == 0 && trim($rs->fields["INT"]) == "" ){					
						echo  $rs->fields["CALLE"] .' '.$rs->fields["EXT"] . "|";	#Calle , NoExt y NoInt (Domicilio)
					}	
					echo $rs->fields["COLONIA"]  . "|"; 				
					echo $rs1->fields["MUNICIPIO"] . "|"; 				
					echo $rs1->fields["DESCESTADO"] . "|";
					echo $rs->fields["CODIGO"];
				} else {
					echo "|" . "|" . "|" . "|" ;
				}
					
				echo chr(13).chr(10);
				//--echo  "<br>";
			}
		}

		$rs->MoveNext();
	}
	fclose($f);
		
	if(file_exists($file_data_path)){
		unlink(realpath($file_data_path));
	}
	//echo "</pre>";
?>