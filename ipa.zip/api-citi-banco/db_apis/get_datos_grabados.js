const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {

// const baseQuery = "BEGIN " + context.schema + ".PROC_SURVEY_GETQUESTCHOICESCU3(:id_solicitud, :id_producto, :llave, :rc); END;";
const baseQuery = "BEGIN " + context.schema + ".PROC_SURVEY_GETQUESTCHOICESCU3(:id_solicitud, :id_producto, :rc); END;";
console.log(context);
	let query = baseQuery;
	const binds = {};
  let result2 = {};

  // if(!context.id_solicitud || !context.id_producto || !context.llave){
  if(!context.id_solicitud || !context.id_producto){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.id_solicitud = context.id_solicitud;
    binds.id_producto = context.id_producto;
    // binds.llave = context.llave;
    binds.rc = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;
