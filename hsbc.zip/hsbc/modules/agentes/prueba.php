<?php
# @uthor Mark
# Index File on agente module

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Nuevo registro");

$datos_cliente = get_session_varname("datos_persona");
$id_solicitud = (strlen(get_session_varname('id_solicitud')) > 0 ?get_session_varname('id_solicitud'):desencripta($_REQUEST['sol']));
layout_menu($db, "ShowScript_GeneralIN()");
?>
<p class="textbold">Agentes &gt; Obtener Registro</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes&op=cuestionario" name="frm1">
<table class="text" border="0" height="500px">
    <tr>
        <td width="60%">
            <table border="0">
                <tr>
                    <td colspan="4">Seleccione el estatus de la lista para cada uno de los telefonos, si no logro contactar a la persona.</td>
                </tr><tr>
                    <td colspan="4">&nbsp;</td>
                </tr><tr>
                    <td class="textleft" width="25%" colspan="2"><b>Nombre cliente:&nbsp;</b></td>
                    <td colspan="2" class="label"><?=$datos_cliente[0]['NOMBRE'].'&nbsp;'.$datos_cliente[0]['APATERNO'].'&nbsp;'.$datos_cliente[0]['AMATERNO']?></td>
                </tr><tr>
                    <td colspan="2" ><b># Solicitud:&nbsp;</b></td>
                    <td colspan="2" class="label"><?=$id_solicitud?></td>
                </tr><tr>
                    <td colspan="2" class="textleft"><b>RFC:&nbsp;</b></td>
                    <td colspan="2" class="label"><?=$datos_cliente[0]['RFC']?></td>
                </tr>
                    <?
                        $contador = 1;
                        for($indice = 0; $indice < count($datos_cliente); $indice ++){
                            echo '<tr>
                                    <td colspan="2" class="textleft"><b>Telefono '.$contador.':&nbsp;<a href = "javascript:AbreVentana()"> <img src="includes/imgs/ico_telefono2.gif" alt="Marcar"/></a></b></td>
                                    <td ><input class="label" type="text" size="10" name="tel_'.$contador.'" id="tel_'.$contador.'" value="'.$datos_cliente[$indice]["CLAVELADA"].$datos_cliente[$indice]["TELEFONO"].'" readonly></td>
                                    <td>';
                                if(strlen($datos_cliente[$indice]["TELEFONO"]) > 0 ){
                                    echo '<select name="tel_0'.$contador.'" style="width:250px">
                                            <option value="0">Elige opcion</option>
                                            <option value="1010">C - CONTACTO (1010)</option>';
                                            $cal_NC = get_cal_NC(1, $db); //Calificacion de  NO CONTACTO
                                            for($indice_cal = 0; $indice_cal < count($cal_NC->_array); $indice_cal++){
                                                echo '<option value="'.$cal_NC->_array[$indice_cal]['U_ESTATUSLLAMADA'].'" >NC - '.$cal_NC->_array[$indice_cal]['ESTATUS'].'&nbsp;('.$cal_NC->_array[$indice_cal]['U_ESTATUSLLAMADA'].')</option>';
                                            }
                                    echo '</select>';
                                } else
                                    echo "&nbsp;";
                            echo '</td>
                                </tr>';
                            $contador ++;
                        }
                    ?>
                <tr>
                    <td colspan="4">&nbsp;<input type="hidden" name="cont" value="<?=$contador - 1?>" id="cont"></td>
                </tr><tr>
                    <td colspan="4">&nbsp;</td>
                </tr><tr>
                    <td colspan="2" class="textleft"><b>PRODUCTO:&nbsp;</b></td>
                    <td colspan="2" class="label">
                        <select name="producto_">
                            <option value="">Elige opcion</option>
                        <?php
                            $productos_ = get_productos_campana($db); //PRODUCTOS
                            for($t = 0; $t < count($productos_->_array); $t++){
                                if($productos_->_array[$t]['U_PRODUCTO'] == 1 || $productos_->_array[$t]['U_PRODUCTO'] == 2){
                                    echo '<option value="'.$productos_->_array[$t]['U_PRODUCTO'].'">'.$productos_->_array[$t]['NOMBRE'].'</option>';
                                }
                            }
                        ?>
                        </select>
                    </td>
                </tr><tr>
                    <td colspan="4">&nbsp;</td>
                </tr><tr>
                    <td colspan="4">Seleccione de la lista una opci&oacute;n en cuanto haga contacto con cualquier persona de los distintos telefonos</td>
                </tr><tr>
                    <td colspan="4">&nbsp;</td>
                </tr><tr>
                    <td colspan="4">
                        <input type="button" value="Continuar" onclick="Continuar(<?=$contador-1?>, '<?=encripta(4)?>')"/>&nbsp;&nbsp;
                        <input type="button" value="Abandonar" onclick="Abandonar(<?=$contador-1?>, '<?=encripta(8)?>')"/>&nbsp;&nbsp;
                        <input type="button" value="Nuevo Telefono" onclick="Agregar_Telefono()">
                    </td>
                </tr>
            </table>
        </td>
        <td rowspan="2">
            <?php

            //echo '<iframe name="cuestionarioasp" id="cuestionarioasp" src="'.$linkpath_cuestionario.'/script.asp?surveyid=1&u_persona='.$id_solicitud.'&u_registro='.$id_solicitud.'&u_user='.get_session_varname('s_usr_id').'&inicio=y" frameborder="0" width="100%" height="500" scrolling="auto"></iframe>';
            ?>
            <div id="script" align="center" class="script"></div>
        </td>
    </tr>
</table>
</form>
<?
layout_footer();
?>
