<?php
// phpinfo();


// $host = '192.168.1.13';
// $port = '1521';
// $sid = 'xccmtaf';
// $username = 'tdcamexonlineapp';
// $password = 't32358d86f7';

// try {
//     // Crear la cadena de conexión DSN
//     $dsn = "oci:dbname=//{$host}:{$port}/{$sid}";

//     // Crear una nueva conexión PDO
//     $pdo = new PDO($dsn, $username, $password);

//     // Configurar el modo de error de PDO para que lance excepciones
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//     echo "Conexión exitosa a la base de datos Oracle.";
// } catch (PDOException $e) {
//     // Manejar errores de conexión
//     echo "Error de conexión: " . $e->getMessage();
// }

$username = 'tdcamexonlineapp';       // Cambia por tu usuario Oracle
$password = 't32358d86f7';    // Cambia por tu contraseña Oracle
$connection_string = '192.168.1.13/xccmtaf'; // Cambia por tu host/SID o servicio. Ejemplo: 'localhost/XE'
// Intentar conectar
$conn = oci_connect($username, $password, $connection_string);
if (!$conn) {
    $e = oci_error();
    echo "Error al conectar: " . $e['message'];
} else {
    echo "Conexión exitosa a Oracle!";
    oci_close($conn);
}


?>
