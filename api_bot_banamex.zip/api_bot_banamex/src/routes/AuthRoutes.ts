import {Router  } from "express";
import {validateSurvey,ValSurvey,ValSignIn,validate  } from "../validation/validators";
import AuthController from "../controllers/authController";

const router=Router();

const authController = new AuthController()



router.post("/signUp",validate(ValSignIn), authController.createUser );

router.post("/login",validate(ValSignIn), authController.getToken );

router.post("/signIn",validate(ValSignIn), authController.getToken );


// router.post("/signU-p",validate(ValSignIn), authController.createUser );

// router.post("/sigIn",validate(ValSignIn), authController.sigIn );
// router.post("/sigUp",validate(ValSignIn), surveyController.getAllSurveys );
// router.post("/validateToken",validate(ValSignIn), authController.getAllSurveys );
 



// router.post("/dataInsert/:user_id",validateSurvey(ValSurvey), surveyController.createSurvey );
// router.get("/getData",validate(ValSignIn), surveyController.getAllSurveys );

export default router
