<?php
# genera_layout File 
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize("mesa_control","Layout de clientes");
layout_menu($db, "");
?>
	<h4>Layout de clientes</h4>
	<form name="frm1" method="post" action="modules.php?mod=mesa_control&op=layout">
	<p id="text">Seleccione un rango de fecha para generar el layout.<br>
	<table align="center" border="0">
		<tr>
			<td colspan="2" align="center"><b>Fecha</b></td>
		</tr><tr>
			<td align="center">Del:</td>
			<td align="center">Al:</td>
		</tr><tr>
			<td align="center">
				<script language="JavaScript">
					var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_del','dateFormat' : 'd/m/Y'}
					var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
					new sCalendar(SC_SET_1,fecha);
				</script>
			</td>
			<td>
				<script language="JavaScript">
					var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_al','dateFormat' : 'd/m/Y'}
					var fecha = '<?=$registro->fields["FECHA_AGENDADO"]?>';
					new sCalendar(SC_SET_1,fecha);
				</script>
			</td>
        </tr><tr align="center">
            <td colspan="2" align="center">&nbsp;</td>
		</tr><tr>
           	<td colspan="2">
                <input type="button" value="Cancelar" onclick="Atras()">
                <input type="button" value="Mostrar layout" name="mostrar_layout" onclick="Mostrar_Layout()">
			</td>
		</tr>		
	</table>
	<br>
    </form>
<?
layout_footer();
?>