<?php
class ControladorCampanas{

          static public function ctrCrearCampana(){
		if(isset($_POST["NuevaCampana"])){

                              if ($_POST["NuevaCampana"]) {
                                        $tabla = "cat_campanas";

                                        $datos = array(
                                                  "Nombre_Campana" => $_POST["NuevaCampana"]
                                        );

                                        $respuesta = ModeloCampanas::mdlCrearCampana($tabla, $datos);

                                        if ($respuesta == "ok") {
                                                  echo '<script>
					swal({
						type: "success",
						title: "¡La Campana ha sido guardado correctamente!",
						showConfirmButton: true,
						confirmButtonText: "Cerrar"
					}).then(function(result){
						if(result.value){		
							window.location = "?ruta=campanas";
						}
					});</script>';
                                        }
                              } else {
                                        echo '<script>
					swal({
						type: "error",
						title: "¡La Campana no puede ir vacío o llevar caracteres especiales!",
						showConfirmButton: true,
						confirmButtonText: "Cerrar"
					}).then(function(result){
					if(result.value){
					window.location = "?ruta=campanas";
					}
					});
				</script>';
                              }
		}             
          }

          //MOSTRAR USUARIO
          static public function ctrMostrarCampanas($item, $valor){
		  $tabla = "cat_campanas";
          $respuesta = ModeloCampanas::mdlMostrarCampanas($tabla, $item, $valor);
          return $respuesta;
          }

          //	EDITAR USUARIO
          static public function ctrEditarCampana(){
			if(isset($_POST["EditarName"])){
                                        $tabla = "cat_campanas";
                                        $datos = array("EditarName" => $_POST["EditarName"], "id_campana" => $_POST["Campana_id"]);

                                        $respuesta = ModeloCampanas::mdlEditarCampana($tabla, $datos);
                                        if ($respuesta == "ok") {
                                                  echo '<script>
					swal({
						  type: "success",
						  title: "El Enlace ha sido editado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result) {
									if (result.value) {
									window.location = "?ruta=campanas";
									}
								})
					</script>';
                                        }
                              
									}
          }

          static public function ctrBorrarCampana(){
                    if (isset($_GET["idCampana"])) {
                              $tabla = "cat_campanas";
                              $datos = $_GET["idCampana"];
                              $respuesta = ModeloEnlaces::mdlBorrarEnlace($tabla, $datos);
                              if ($respuesta == "ok") {
                                        echo '<script>
				swal({
					  type: "success",
					  title: "La Campana ha sido borrado correctamente",
					  showConfirmButton: true,
					  confirmButtonText: "Cerrar",
					  closeOnConfirm: false
					  }).then(function(result) {
								if (result.value) {
								window.location = "?ruta=campanas";
								}
							})
				</script>';
                              }
                    }
          }
}