const oracledb = require('oracledb');
const database = require('../services/database.js');

// async function find(context){
//   console.log(context);
//   // const baseQuery = "BEGIN " + context.schema + ".XSP_GETNUEVOREGISTRO(:camp, :prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :rc, :keys, :v_accion, :v_registro); END;";
//   const baseQuery = "BEGIN " + context.schema + ".XSP_GETNUEVOREGISTRO(:camp, :prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :key, :registro, :rc); END;";
//   let query = baseQuery;
//
// 	const binds = {};
//   let result2 = {};
//
//   if(!context.camp || !context.prioridad || !context.estatus || !context.intentos || !context.user_ || !context.rand_ || !context.reg || !context.tipoCampana
//     || !context.key){
//     console.log("Parametros incorrectos")
//     result2.error_ = true;
//     result2.mensaje = "Parametros Erroneos";
//     return result2;
//
//   } else{
//     binds.camp      = context.camp;
//     binds.prioridad   = context.prioridad;
//     binds.estatus     = context.estatus;
//     binds.intentos    = context.intentos;
//     binds.user_     = context.user_;
//     binds.rand_     = context.rand_;
//     binds.registro  = null;
//     //binds.reg = parseInt(context.reg);
//     binds.reg       = {val:parseInt(context.reg), dir: oracledb.BIND_INOUT, type:oracledb.DB_TYPE_NUMBER};
//     binds.tipoCampana   = context.tipoCampana;
//     binds.key = context.key;
//     binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
//     //binds.keys      = context.keyrig;
//     // binds.keys      = '';
//     // binds.v_accion = 1;
//     // binds.v_registro = 0;
//     // console.log(binds);
//     const result = await database.simpleExecuteRC(query, binds);
//     //console.log(result);
//     return result;
//   }
// }

async function give(context){
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".XSP_GETNUEVOREGISTRO(:camp, :prioridad, :estatus, :intentos, :user_, :rand_, :reg, :tipoCampana, :rc); END;";
  let query = baseQuery;

  const binds = {};
  let result2 = {};

  if(!context.camp || !context.prioridad || !context.estatus || !context.intentos || !context.user_ || !context.rand_ || !context.reg || !context.tipoCampana){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.camp      = context.camp;
    binds.prioridad   = context.prioridad;
    binds.estatus     = context.estatus;
    binds.intentos    = context.intentos;
    binds.user_     = context.user_;
    binds.rand_     = context.rand_;
    //binds.reg = parseInt(context.reg);
    binds.reg       = {val:parseInt(context.reg), dir: oracledb.BIND_INOUT, type:oracledb.DB_TYPE_NUMBER};
    binds.tipoCampana   = context.tipoCampana;
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    // binds.registro = context.v_registro;
    // binds.key      = context.keyrig;
    // binds.keys =
    // binds.fecha_inicio = data[1].substring(0,10);
    // binds.fecha_fin = data[2].substring(0,10);

    // binds.keys = context.keyrig;
    // binds.v_accion = 2;
    // binds.v_registro = context.v_registro;


    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  }
}

// module.exports.find = find;
module.exports.give = give;
