const KnowledgeModel = require("../models/Knowledge.models");


function normalize(text) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

const ChatResolver = {
  async resolve({ session, message }) {
    if (session.status !== "bot") {
      return null;
    }

    const BOT_ID = 2; // customer_support

    const knowledgeList = await KnowledgeModel.getByBot(BOT_ID);
    const normalizedUserMessage = normalize(message);

    const matches = [];

    for (const item of knowledgeList) {
      let matchCount = 0;

      for (const keyword of item.tags) {
        const normalizedKeyword = normalize(keyword);

        if (normalizedUserMessage.includes(normalizedKeyword)) {
          matchCount++;
        }
      }

      if (matchCount > 0) {
        const score = matchCount * 10 + item.priority;

        matches.push({
          ...item,
          score
        });

        console.log(
          `KB#${item.id} | matches=${matchCount} | priority=${item.priority} | score=${score}`
        );
      }
    }

    if (matches.length > 0) {
      // ordenar por score
      matches.sort((a, b) => b.score - a.score);

      // eliminar duplicados por contenido
      const uniqueResponses = [];
      const used = new Set();

      for (const m of matches) {
        if (!used.has(m.content)) {
          used.add(m.content);
          uniqueResponses.push(m.content);
        }
      }

      //return uniqueResponses.join("\n\n");

      return {
        type: "BOT",
        message: uniqueResponses.join("\n\n")
      };

    }

    return {
      type: "BOT",
      message: "Gracias por tu mensaje, en breve un asesor te apoyará 😊"
    };
  }
};

module.exports = ChatResolver;
