function LTrim(s) {
    // Devuelve una cadena sin los espacios del principio
    var i = 0;
    var j = 0;
    // Busca el primer caracter <> de un espacio
    for (i = 0; i <= s.length - 1; i++)
        if (s.substring(i, i + 1) != ' ') {
            j = i;
            break;
        }
    return s.substring(j, s.length);
}

function RTrim(s) {
    // Quita los espacios en blanco del final de la cadena
    var j = 0;
    // Busca el ltimo caracter <> de un espacio
    for (var i = s.length - 1; i > - 1; i--)
        if (s.substring(i, i + 1) != ' ') {
            j = i;
            break;
        }
    return s.substring(0, j + 1);
}

function Trim(s) {
    // Quita los espacios del principio y del final
    return LTrim(RTrim(s));
}


function isDate2(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAAA-MM-DD") {
        datePat = /^(\d{4})(-)(\d{1,2})(-)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[5];
        year = matchArray[1];
    }

    if (formato == "MM/AA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[1];
        //day = matchArray[5];
        year = matchArray[4];
    }


    if (formato == "DD/MM/AAAA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[1];
        year = matchArray[5];
    }

    if (formato == "DDMMAAAA") {
        datePat = /^(\d{1,2})(\d{1,2})(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        day = dateStr.substring(0, 2);
        month = dateStr.substring(2, 4);
        year = dateStr.substring(4, 8);
    }

    if (formato == "YYMM") {
        datePat = /^(\d{1,2})(\d{1,2})/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[2];
        year = matchArray[1];
        day = 1;
    }

    //alert(month.length);
    if (formato == "YYMM") {
        if (year.length < 2) { // chequeo de numero de digitos en A?
            return false;
        }
    }else{
        if (year.length < 4) { // chequeo de numero de digitos en A?
            return false;
        }
        if (year >= 2079) { // chequeo del A? para smalldate
            return false;
        }
    }

    if (month < 1 || month > 12 || month.length < 2) { // checa rango mes
        return false;
    }
    if (day < 1 || day > 31 || day.length < 2) {
        return false;
    }
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    }
    if (month == 2) { // check para febrero 29
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}
/*
 *Evalua el telefono de la solicitud y lo asigna de a cuerdo a su valor
 */
function evaluar_telefono() {
    var eval_tel = document.getElementById("ev_tel").value;
    alert(eval_tel);
}
function isDate3(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "MM/AA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[1];
        day = '01';
        year = matchArray[3];
    }

    //alert(month.length);
    if (year.length < 2) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year < 05) { // chequeo del A? para smalldate
        return false;
    }
    if (year >= 79) { // chequeo del A? para smalldate
        return false;
    }
    if (month < 1 || month > 12 || month.length < 2) { // checa rango mes
        return false;
    }

    return true;
}

function isDate4(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAMM") {
        datePat = /^(\d{2})(\d{1,2})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        year = matchArray[1];
        month = matchArray[2];
        day = '01';
    }

    if (year.length < 2) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year > 99) { // chequeo del A? para smalldate
        return false;
    }
    if (month > 11 || month.length < 2) { // checa rango mes
        return false;
    }

    return true;
}


function isDate5(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "AAAA") {
        datePat = /^(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = '01';
        day = '01';
        year = matchArray[1];
    }

    //alert(month.length);
    if (year.length < 4) { // chequeo de numero de digitos en A?
        return false;
    }
    if (year >= 2079) { // chequeo del A? para smalldate
        return false;
    }
    return true;
}


function fechas() {
    var a = 0;
    var ArreFecha = new Array();
    var ArrePegunta = new Array();
    var ArreTipo = new Array();

    var banderaFechas = true;

    if (survey_id == 100) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') == '') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
                                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value');
                                    ArrePegunta[a] = "Fecha de Cita";
                                    ArreTipo[a] = "";
                                    a++;
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6') != null) {
            ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId6.value');
            ArrePegunta[a] = "Fecha de Nacimiento de Titular";
            ArreTipo[a] = "T";
            a++;
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') == 'S') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Alterno";
                    ArreTipo[a] = "T";
                    a++;
                }
            }
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '1') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 1";
                    ArreTipo[a] = "";
                    a++;
                }
            }
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '2') {

                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 1";
                    ArreTipo[a] = "";
                    a++;
                }

                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId11') != null) {
                    ArreFecha[a] = eval('document.SurveyResponse.txtQId' + survey_id + '6CId11.value');
                    ArrePegunta[a] = "Fecha de Nacimiento Adicional 2";
                    ArreTipo[a] = "";
                    a++;
                }
            }
        }
    }


    for (a = 0; a < ArreFecha.length; a++) {
        if (Trim(ArreFecha[a]).length > 0) {
            if (!isDate2(Trim(ArreFecha[a]), "DD/MM/AAAA")) {
                alert("ERROR en la Pregunta \n\n--   " + ArrePegunta[a] + "   --\n\n FORMATO: DD/MM/AAAA ")
                banderaFechas = false;
            } else {
                if (ArreTipo[a] == 'T') {
                    if (!validarAdulto(ArreFecha[a], ArrePegunta[a], ArreTipo[a])) {
                        banderaFechas = false;
                    }
                }
            }
        } else {
            alert("El campo \n\n--   " + ArrePegunta[a] + "   --\n\n no puede ser vacio ")
            banderaFechas = false;
        }
    }

    return banderaFechas;
}
/*
 function increment() {
 if (document.images.bar != null)
 {
 count += 1;
 if (count == 0) {
 document.images.bar.src = image00.src;
 }
 if (count == 1) {
 document.images.bar.src = image01.src;
 }
 if (count == 2) {
 document.images.bar.src = image02.src;
 }
 if (count == 3) {
 document.images.bar.src = image03.src;
 }
 if (count == 4) {
 document.images.bar.src = image04.src;
 }
 if (count == 5) {
 document.images.bar.src = image05.src;
 }
 if (count == 6) {
 document.images.bar.src = image06.src;
 }
 if (count == 7) {
 document.images.bar.src = image07.src;
 }
 if (count == 8) {
 document.images.bar.src = image08.src;
 }
 if (count == 9) {
 document.images.bar.src = image09.src;
 }
 if (count == 10) {
 document.images.bar.src = image10.src;
 count = -1;
 }
 }
 }
 
 function stopclock() {
 if (timerRunning)
 clearInterval(timerID);
 timerRunning = false;
 }
 
 function end() {
 if (finish == true) {
 stopclock();
 }
 else {
 finish = true;
 }
 }
 
 function startclock() {
 stopclock();
 timerID = setInterval("increment()", timeValue);
 timerRunning = true;
 if (document.images.bar != null)
 {
 document.images.bar.src = image00.src;
 }
 }
 */
function GoHome() {
    history.back()
}

function GoBack() {
    history.back();
}

function cerrarVentana() {
//window.close();
}

function SubmitSurvey() {
    document.prueba.submit();
}

function validarQuestion() {
    bandera_telac = true;
    campo = " Datos del Titular";

    //-- Relacion con el Registro de base
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '') {
            alert("Favor de seleccionar la relacion del registro con la base de los " + campo);
            return  false;
        }
    }

    //-- Nombre
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value') == '') {
            alert("Favor de escribir el Nombre de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId2'), "Nombre de los" + campo, 1, 25)) {
                return false;
            }
            if (!/^([a-zA-Z áéíóúÁÉÍÓÚñÑ])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value'))) {
                alert("El nombre de los " + campo + " debe ser solo alfabetico");
                return false;
            }
        }
    }

    //-- Segundo nombre
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != '') {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId3'), "Segundo Nombre de los" + campo, 1, 25)) {
                return false;
            }
            if (!/^([a-zA-Z áéíóúÁÉÍÓÚñÑ])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value'))) {
                alert("El segundo nombre de los " + campo + " debe ser solo alfabetico");
                return false;
            }
        }
    }

    //-- Paterno
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == '') {
            alert("Favor de escribir el Apellido Paterno de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId4'), "Apellido Paterno de los" + campo, 1, 50)) {
                return false;
            }
            if (!/^([a-zA-Z áéíóúÁÉÍÓÚñÑ])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value'))) {
                alert("El apellido paterno de los " + campo + " debe ser solo alfabetico");
                return false;
            }
        }
    }

    //-- Materno
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value') != '') {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId5'), "Apellido materno de los" + campo, 1, 50)) {
                return false;
            }
            if (!/^([a-zA-Z áéíóúÁÉÍÓÚñÑ])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value'))) {
                alert("El apellido materno de los " + campo + " debe ser solo alfabetico");
                return false;
            }
        }
    }

    //-- Fecha de Nacimiento
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6.value') == '') {
            alert("Favor de escribir la fecha de nacimiento de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId6'), "fecha de nacimiento de los " + campo, 1, 10))
                return false;
        }
    }

    //-- RFC
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') == '') {
            alert("Favor de escribir el RFC de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId7'), "RFC de los" + campo, 1, 13))
                return false;
        }
    }

    //-- Edo de nacimiento
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value') == '') {
            alert("Favor de seleccionar el Estado de Nacimiento de los " + campo);
            return  false;
        }
    }

    //-- Edo de cuenta
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') == '') {
            alert("Favor de seleccionar el Nombre de su estado de cuenta es diferente de los " + campo);
            return  false;
        }
    }

    // -- Si el estado de cuenta es SI
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') == 'S') {
            //-- Nombre alterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId9') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId9.value') == '') {
                    alert("Favor de escribir el Nombre alterno de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId9'), "Nombre de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno alterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') == '') {
                    alert("Favor de escribir el Apellido Paterno Alterno de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId11'), "Apellido Paterno de los" + campo, 1, 30))
                        return false;
                }
            }


            //-- Fecha de Nacimiento alterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value') == '') {
                    alert("Favor de escribir la fecha de nacimiento Alterno de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId13'), "fecha de nacimiento de los " + campo, 1, 10))
                        return false;
                }
            }

            //-- RFC alterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') == '') {
                    alert("Favor de escribir el RFC Alterno de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId13'), "RFC de los" + campo, 1, 13))
                        return false;
                }
            }
        }
    }

    //-- Nacionalidad
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value') == '') {
            alert(" Favor de seleccionar la Nacionalidad de los" + campo);
            return  false;
        }
    }

    //-- Pais de Origen
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16.value') == '') {
            alert("Favor de seleccionar el Pais de Origen de los " + campo);
            return  false;
        }
    }

    //-- Sexo
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') == '') {
            alert("Favor de seleccionar el Sexo de los " + campo);
            return  false;
        }
    }

    //-- Estado Civil
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId18') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId18.value') == '') {
            alert(" Favor de seleccionar el Edo Civil de los" + campo);
            return  false;
        }
    }

    //-- Dependientes
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') == '') {
            alert(" Favor de seleccionar el N�mero de Dependientes o 0 si no tiene " + campo);
            return  false;
        }
    }

    //-- Grado de Estudios
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId20') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId20.value') == '') {
            alert(" Favor de seleccionar el Maximo grado de estudios de los " + campo);
            return  false;
        }
    }

    //-- Producto Ofertado
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') == '') {
            alert(" Favor de seleccionar el Producto Ofertado de los " + campo);
            return  false;
        }
    }

    //ohernandez@20160728 REQ. #2130 - Candado de solicitud 2.0 para ITS
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') == '1' && eval('document.SurveyResponse.s_usr_centro.value') == '5' && ((eval('document.SurveyResponse.descbase.value').indexOf("CAN") >= 0) || (eval('document.SurveyResponse.descbase.value').indexOf("SPO") >= 0) || (eval('document.SurveyResponse.descbase.value').indexOf("RECH") >= 0))) {
            alert("NO se permite vender la solicitud Volaris 1, unicamente la solicitud 2.0 debido a que el cliente es de base: " + eval('document.SurveyResponse.descbase.value') + ", en " + campo);
            return  false;
        }
    }
    //

    return bandera_telac;
}


function validarQuestion2() {
    bandera_telac = true;
    campo = "datos de Domicilio";

    /*
     * ABarajas, 20140430
     * Validar longitud de datos de domicilio, hasta 36 caracteres
     * de acuerdo a req. 805 de AGarduno
     */
    var calle = eval('document.SurveyResponse.txtQId' + survey_id + '2CId2.value');
    var num_int = eval('document.SurveyResponse.txtQId' + survey_id + '2CId3.value');
    var num_ext = eval('document.SurveyResponse.txtQId' + survey_id + '2CId4.value');
    if (calle.length + num_int.length + num_ext.length > 36) {
        alert("Los datos de calle y n�mero de los " + campo + " no deben exceder 36 caracteres.\n\nPor favor revisa.");
        return false;
    }

    //-- Antiguedad en vivienda YY
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId1.value') == '') {
            alert("Favor de seleccionar la antiguedad YY en vivienda de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId1'), "antiguedad en vivienda de los " + campo, 1, 4))
            {//return false;
            }
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId1.value'))) {
                alert("La antiguedad en vivienda debe tener solo d�gitos de " + campo);
                return  false;
            }
        }
    }

    //-- Antiguedad en vivienda MM
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId32') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId32.value') == '') {
            alert("Favor de seleccionar la antiguedad MM en vivienda de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId32'), "antiguedad en vivienda de los " + campo, 1, 4))
            {//return false;
            }
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId32.value'))) {
                alert("La antiguedad en vivienda debe tener solo d�gitos de " + campo);
                return  false;
            }
        }
    }

    //-- Calle
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId2') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId2.value') == '') {
            alert("Favor de escribir la Calle de la " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId2'), "Direcci�n de la " + campo, 1, 100))
                return false;
        }
    }

    //-- Numero Exterior
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId3.value') == '') {
            alert("Favor de escribir el N�mero Exterior de los " + campo);
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId3.value'))) {
                alert("El Numero Exterior debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId3'), "N�mero Exterior de la " + campo, 1, 10))
                    return false;
            }
        }
    }


    //-- Entre calle 1
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId5') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId5.value') == '') {
            alert("Favor de escribir el campo Entre calle 1 de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId5'), "Entre calle 1 de " + campo, 1, 80))
                return false;
        }
    }


    //-- Entre calle 1
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId6.value') == '') {
            alert("Favor de escribir el campo Entre calle 2 los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId6'), "Entre calle 2 de " + campo, 1, 80))
                return false;
        }
    }

    //-- CP
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId7.value') == '') {
            alert("Favor de escribir el CP de los " + campo);
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId7.value'))) {
                alert("El CP debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId7'), "CP de " + campo, 5, 5))
                    return false;
            }
        }
    }

    //-- Colonia
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId9') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId9.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8.value') == '') {
                    alert("Favor de seleccionar o escribir la Colonia de " + campo);
                    return false;
                }
            } else {
                alert("Favor de seleccionar o escribir la Colonia de " + campo);
                return false;
            }
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId8.value') != '') {
                    alert("Favor de solo proporcionar una colonia de los " + campo);
                    return false;
                }
            }
        }
    }

    //-- Ciudad
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId10') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId10.value') == '') {
            alert("Favor de seleccionar la Ciudad de " + campo);
            return  false;
        }
    }

    //-- Municipio
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId11') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId11.value') == '') {
            alert("Favor de seleccionar la Municipio de " + campo);
            return  false;
        }
    }


    //-- Estado
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId12') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId12.value') == '') {
            alert("Favor de seleccionar el Estado de " + campo);
            return  false;
        }
    }

    //-- Estados de cuenta otro domicilio

    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId13') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId13.value') == '') {
            alert("Favor de seleccionar si sus estados de cuenta llegan a otro domicilio de " + campo);
            return  false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId13.value') == 'S') {

                //-- Calle Alterna
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId14') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId14.value') == '') {
                        alert("Favor de escribir la Calle Alterna de la " + campo);
                        return  false;
                    } else {
                        if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId14'), "Direcci�n de la " + campo, 1, 30))
                            return false;
                    }
                }

                //-- Numero Exterior Alterno
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId15') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId15.value') == '') {
                        alert("Favor de escribir el N�mero Exterior Alterno de los " + campo);
                        return  false;
                    } else {
                        if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId15.value'))) {
                            alert("El Numero Exterior Alterno debe tener solo d�gitos de los " + campo);
                            return  false;
                        } else {
                            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId15'), "N�mero Exterior Alterno de la " + campo, 1, 5))
                                return false;
                        }
                    }
                }


                //-- CP Alterna
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId17') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId17.value') == '') {
                        alert("Favor de escribir el CP Alterna de los " + campo);
                        return  false;
                    } else {
                        if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId17.value'))) {
                            alert("El CP Alterna debe tener solo d�gitos de los " + campo);
                            return  false;
                        } else {
                            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '2CId17'), "CP de " + campo, 5, 5))
                                return false;
                        }
                    }
                }

                //-- Colonia Alterna
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20.value') == '') {
                        alert("Favor de seleccionar la Colonia Alterna de " + campo);
                        return false;
                    }
                }

                //-- Ciudad Alerta
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId19') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId19.value') == '') {
                        alert("Favor de seleccionar la Ciudad Alterna de " + campo);
                        return  false;
                    }
                }

                //-- Municipio
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId21') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId21.value') == '') {
                        alert("Favor de seleccionar la Municipio Alterna de " + campo);
                        return  false;
                    }
                }


                //-- Estado
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId22') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId22.value') == '') {
                        alert("Favor de seleccionar el Estado Alterno de " + campo);
                        return  false;
                    }
                }
            }
        }
    }


    //-- Lada Casa

    /*if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value') != '') {
     if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value'))) {
     alert("La Lada debe tener solo d�gitos de " + campo);
     return  false;
     } else {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value.length') < 2) {
     alert("La Lada debe ser 2 o 3 d�gitos de " + campo);
     return  false;
     }
     }
     } else {
     alert("Favor de escribir la Lada de " + campo);
     return  false;
     }
     }*/

    //-- Telefono
    /*if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId24') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value') != '') {
     if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value'))) {
     alert("El Tel�fono Casa debe tener solo d�gitos de " + campo);
     return  false;
     } else {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value.length') != 10) {
     alert("Entre el Tel�fono y la Lada de la Casa se deben de conjuntar 10 d�gitos de " + campo);
     return  false;
     }
     }
     } else {
     alert("Favor de escribir el Tel�fono Casa de " + campo);
     return  false;
     }
     }*/

    //-- Ingresar telefono celular
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId27') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId27.value') == '') {
            alert("Debe de seleccionar la Compa�ia Celular de los " + campo);
            return false;
        }
    }

    //-- Ingresar telefono celular
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId27') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId27.value') != 99) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value') == '') {
                    alert("Debe de proporcionar el numero Celular de los " + campo);
                    return false;
                }
            }
        }
    }


    //-- Telefono Celular
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value'))) {
                alert("El Tel�fono Celular debe tener solo d�gitos de " + campo);
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value.length') != 10) {
                    alert("el telefono celular debe ser a 10 d�gitos de " + campo);
                    return  false;
                }
            }
        } else {
            alert("Debe de proporcionar el numero Celular de los " + campo);
            return false;

        }
    }

    //-- Email
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value') != '') {
//            bandera_telac = ChecaEmail();
        } else {
            alert("El email es obligatorio en " + campo);
            return false;
        }
    }

    return bandera_telac;
}


function validarQuestion3() {
    bandera_telac = true;
    campo = "Datos de empresa";

    /*
     * ABarajas, 20140430
     * Validar longitud de datos de domicilio, hasta 36 caracteres
     * de acuerdo a req. 805 de AGarduno
     */
    var calle = eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value');
    var num_int = eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value');
    var num_ext = eval('document.SurveyResponse.txtQId' + survey_id + '3CId8.value');
    if (calle.length + num_int.length + num_ext.length > 36) {
        alert("Los datos de calle y n�mero de los " + campo + " no deben exceder 36 caracteres.\n\nPor favor revisa.");
        return false;
    }

    //-- Actividad Laboral
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == '') {
            alert(" Favor de seleccionar la Actividad Laboral de " + campo);
            return  false;
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == 2) {
            /*if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId22.value') == null) {
             alert(" Favor de escribir detalle de Actividad Laboral de " + campo);
             return  false;
             }*/
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == 4) {
                /*if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId22.value') == null) {
                 alert(" Favor de escribir Tel�fono Oficina" + campo);
                 return  false;
                 }*/
            }
        }
    }

    //-- Tipo de Industria
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId2') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId2.value') == '') {
            alert(" Favor de seleccionar el Tipo de Industria de " + campo);
            return  false;
        }
    }

    //-- Antiguedad en vivienda actual a�os
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId3.value') == '') {
            alert("Favor de seleccionar la antiguedad YY en actual empleo de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId3'), "antiguedad en actual empleo de los " + campo, 1, 4))
            {
            }//return false;
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId3.value'))) {
                alert("La antiguedad en vivienda debe tener solo d�gitos de " + campo);
                return  false;
            }
        }
    }

    //-- Antiguedad en vivienda actual MESES
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId24') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId24.value') == '') {
            alert("Favor de seleccionar la antiguedad MM en actual empleo de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId24'), "antiguedad en actual empleo de los " + campo, 1, 4))
            {
            }//return false;
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId24.value'))) {
                alert("La antiguedad en vivienda debe tener solo d�gitos de " + campo);
                return  false;
            }
        }
    }

    //-- Antiguedad en vivienda actual a�os
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId4.value') == '') {
            alert("Favor de seleccionar la antiguedad en empleo anterior de los " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId4'), "antiguedad en empleo anterior de los " + campo, 1, 4))
                return false;
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '2CId1.value'))) {
                alert("La antiguedad en vivienda debe tener solo d�gitos de " + campo);
                return  false;
            }
        }
    }

    //-- Nombre de la Empresa
    /*if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5.value') == '') {
     alert("Favor de escribir el Nombre de " + campo);
     return  false;
     } else {
     if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId5'), "Nombre de " + campo, 1, 30))
     return false;
     }
     }*/
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == '6' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == '2' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == '8') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId25') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId25.value') == '') {
                    eval('document.SurveyResponse.txtQId' + survey_id + '3CId25.focus()')
                    alert("Favor de seleccionar el combo de persona fisica.");
                    return false;
                } else {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId5.value') == '') {
                            alert("Favor de escribir el Nombre de " + campo);
                            eval('document.SurveyResponse.txtQId' + survey_id + '3CId5.focus()')
                            return  false;
                        } else {
                            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId5'), "Nombre de " + campo, 1, 30))
                                return false;
                        }
                    }
                }
            }
        }
    }

    //-- Calle
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId6.value') == '') {
            alert("Favor de escribir la Calle de la " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId6'), "Direcci�n de la " + campo, 1, 30))
                return false;
        }
    }

    //-- Numero Exterior
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value') == '') {
            alert("Favor de escribir el N�mero Exterior de los " + campo);
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId7.value'))) {
                alert("El Numero Exterior debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId7'), "N�mero Exterior de la " + campo, 1, 5))
                    return false;
            }
        }
    }

    //-- CP
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId9') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId9.value') == '') {
            alert("Favor de escribir el CP de los " + campo);
            return  false;
        } else {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId9.value'))) {
                alert("El CP debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId9'), "CP de " + campo, 5, 5))
                    return false;
            }
        }
    }

    //-- Colonia
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId21') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId21.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId10') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId10.value') == '') {
                    alert("Favor de seleccionar o escribir la Colonia de " + campo);
                    return false;
                }
            } else {
                alert("Favor de seleccionar o escribir la Colonia de " + campo);
                return false;
            }
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId10') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId10.value') != '') {
                    alert("Favor de solo proporcionar una colonia de los " + campo);
                    return false;
                }
            }
        }
    }

    //-- Municipio
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId11') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId11.value') == '') {
            alert("Favor de seleccionar la Municipio de " + campo);
            return  false;
        }
    }

    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '28' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '118' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '92' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '30' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '58' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '59' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '42' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '32' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '62' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '33' ||
                eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '34') 
        {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId13.value') == '') {
                        alert("Favor de seleccionar que solo tiene Tarjeta Departamental el cliente");
                        return false;
                    }

        }
    }
    /*if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId1') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId3') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId5') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId11.4CId1') == ''
     && eval('document.SurveyResponse.txtQId' + survey_id + '3CId11.4CId3') == '' 
     && eval('document.SurveyResponse.txtQId' + survey_id + '3CId11.4CId5') == ''
     && eval('document.SurveyResponse.txtQId' + survey_id + '3CId11.4CId13') == '') {
     alert("Favor de seleccionar que solo tiene Tarjeta Departamental el cliente " + campo);
     return  false;
     }
     }
     }
     }*/


    //-- Estado
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId12') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId12.value') == '') {
            alert("Favor de seleccionar el Estado de " + campo);
            return  false;
        }
    }

    //-- Lada Oficina de la Empresa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value'))) {
                alert("La Lada de Oficina debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value.length') < 2) {
                    alert("La Lada de Oficina debe ser 2 o 3 d�gitos de los " + campo);
                    return  false;
                }
                /*if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId13.value') != eval('document.SurveyResponse.txtQId'+survey_id+'2CId23.value')){
                 alert("La Lada de Oficina debe ser igual que la Casa");
                 return  false;
                 }*/
            }
        } else {
            alert("Favor de escribir la Lada de Oficina de los " + campo);
            return  false;
        }

    }

    //-- Telefono de la Empresa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId14') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value'))) {
                alert("El Tel�fono de Oficina debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value.length') != 10) {
                    alert("Entre el Tel�fono y la Lada de la Oficina se deben de conjuntar 10 d�gitos de los " + campo);
                    return  false;
                }
                /*if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value') == 4) {
                 if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') == eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value')) {
                 if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value') == eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value')) {
                 alert("El telefono de casa es el mismo de oficina, debe capturar el telefono de oficina diferente");
                 return  false;
                 }
                 }
                 }*/
            }
        } else {
            alert("Favor de escribir el Tel�fono de Oficina de los " + campo);
            return  false;
        }
    }


    //-- Extension Oficina
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId15') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId15.value') != "") {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId15.value'))) {
                alert("La Extension de Oficina debe tener solo d�gitos de los " + campo);
            }
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId15'), "Extencion Oficina de los " + campo, 1, 5))
                return false;
        }
    }
    /*
     // Telefono casa != telefono oficina o capturar celular
     if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId13') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId14') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId23') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId24') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId13.value') == eval('document.SurveyResponse.txtQId'+survey_id+'2CId23.value')){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId14.value') == eval('document.SurveyResponse.txtQId'+survey_id+'2CId24.value')){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId25') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId25.value') ==''){	
     alert("El telefono de casa es el mismo de oficina, debe capturar el telefono celular");
     return  false;
     }
     }
     }
     }
     }
     }
     }
     }*/

    //-- Ingresos Fijos de la Empresa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId16') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId16.value') == '') {
            alert("Favor de escribir los Ingresos Fijos comprobables de la " + campo);
            return  false;
        }
        var ingresosFijos = removeFormat(eval('document.SurveyResponse.txtQId' + survey_id + '3CId16.value'));
        if (!/^([0-9.])*$/.test(ingresosFijos)) {
            alert("Los ingresos fijos comprobables deben tener solo digitos");
            return false;
        } /* else {
         if (eval('document.SurveyResponse.txtQId'+survey_id+'3CId16.value') < 5000) {
         alert("Los ingresos fijos comprobables deben ser mayores o iguales a $5000.00");
         return false;
         }
         } */
    }

    //-- Fuente de otros Ingresos Fijos de la Empresa
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '3CId17.value'))) {
                alert("El campo Otros ingresos debe tener solo d�gitos de los " + campo);
                return false;
            }
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '3CId17'), "Otros ingresos de los " + campo, 1, 6))
                return false;

            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId18') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId18.value') == '') {
                    alert("Favor de seleccionar la Fuente de Otros Ingresos de los " + campo);
                    return  false;
                }
            }
        }
    }

    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId18') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId18.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId17.value') == '') {
                    alert("Al seleccionar fuente de otros ingresos debes capturar los otros ingresos de los " + campo);
                    return false;
                }
            }
        }
    }


    //-- TDC Ofrecida
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId19') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId19.value') == '') {
            alert("Favor de seleccionar Tarjeta a Ofrecer de los " + campo);
            return  false;
        } /*else {
         if(eval('document.SurveyResponse.txtQId'+survey_id+'3CId19.value') == '2'){
         //alert(parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'3CId9.value')))
         if(parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'3CId16.value')) < 30000){
         alert("Para Tarjeta platino los ingresos deben ser superiores a 30000");
         return  false;
         }
         }
         }*/
    }

    //-- Envio de Estado de Cuenta
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId20') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId20.value') == '') {
            alert("Favor de seleccionar Envio de Estado de Cuenta de los " + campo);
            return  false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId20.value') == '20') {
                //-- Email
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value') != '') {
//                        bandera_telac = ChecaEmail();
                    } else {
                        alert("Favor de capturar el campo correo");
                        return  false;
                    }
                }
            }
        }
    }
    //-- Dominio de correo
    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId29') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId29.value') == '') {
                    alert("Favor de seleccionar o escribir el Dominio de correo de " + campo);
                    return false;
                }
            } else {
                alert("Favor de seleccionar o escribir el Dominio de correo de " + campo);
                return false;
            }
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId20.value') != '') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId29') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId29.value') != '') {
                            alert("Favor de solo proporcionar un dominio de correo de los " + campo);
                            return false;
                        }
                    }
                }
            }
        }
    }

    //parentesco adicinal 1 producto 3
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId98') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId98.value') == '') {
            alert("Favor de seleccionar el parentesco del adicional 1 de los " + campo);
            return  false;
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId86.value') == '') {
            alert("Favor de seleccionar el Nombre del adicional 1 de los " + campo);
            return  false;
        }
    }
    /*//parentesco adicinal 2 producto 3
     if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId107') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId107.value') == '') {
     alert("Favor de seleccionar el parentesco del adicional 1 de los " + campo);
     return  false;
     }
     if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId91.value') == '') {
     alert("Favor de seleccionar el Nombre del adicional 1 de los " + campo);
     return  false;
     }
     }
     //*/
    return bandera_telac;
}


function validarQuestion4() {
    bandera_telac = true;
    campo = "Referencias Bancarias";

    //-- Referencia Bancaria 1
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId1.value') == '') {
            alert(" Favor de seleccionar " + campo + " 1");
            return  false;
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId2') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId2.value') == '') {
                alert("Favor de escribir Ultimos 4 digitos de TDC de " + campo + " 1");
                return  false;
            } else {
                if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '4CId2'), "Ultimos 4 digitos de TDC de " + campo + " 1", 4, 4))
                    return false;
                if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId2.value'))) {
                    alert("Los ultimos 4 digitos del campo 1 de la TDC debe tener solo d�gitos");
                    return false;
                }
            }
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId7') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId7.value') == '') {
                alert(" Favor de capturar la antiguedad de la TDC en " + campo + " 1");
                return  false;
            }
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId10') != null) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId10.value') == '') {
                alert(" Favor de capturar el limite de credito de la TDC en " + campo + " 1");
                return  false;
            }
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId10.value'))) {
                alert("El limite de credito de la TDC 1 debe tener solo digitos");
                return false;
            } /* else {
             if (eval('document.SurveyResponse.txtQId'+survey_id+'4CId10.value') < 7000) {
             alert("El limite de credito de la TDC 1 debe ser mayor o igual a $7000.00");
             return false;
             }
             } */
        }
    }

    //-- Referencia Bancaria 2

    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId3.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId4.value') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId4.value') == '') {
                    alert("Favor de escribir Ultimos 4 digitos de TDC de " + campo + " 2");
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '4CId4'), "Ultimos 4 digitos de TDC de " + campo + " 2", 4, 4))
                        return false;
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId4.value'))) {
                        alert("los ultimos 4 digitos del campo 2 de la TDC debe tener solo d�gitos");
                        return false;
                    }
                }
            }
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId11.value'))) {
                alert("El limite de credito de la TDC 2 debe tener solo digitos");
                return false;
            } /* else {
             if (eval('document.SurveyResponse.txtQId'+survey_id+'4CId11.value') < 7000) {
             alert("El limite de credito de la TDC 2 debe ser mayor o igual a $7000.00");
             return false;
             }
             } */
        }
    }

    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId4.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId3.value') == '') {
                    alert(" Favor de seleccionar " + campo + " 2");
                    return  false;
                }
            }
        }
    }

    //-- Referencia Bancaria 3
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId5') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId5.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId6.value') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId6.value') == '') {
                    alert("Favor de escribir Ultimos 4 digitos de TDC de " + campo + " 3");
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '4CId6'), "Ultimos 4 digitos de TDC de " + campo + " 3", 4, 4))
                        return false;
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId6.value'))) {
                        alert("los ultimos 4 digitos del campo 3 de la TDC debe tener solo d�gitos");
                        return false;
                    }
                }
            }
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '4CId12.value'))) {
                alert("El limite de credito de la TDC 3 debe tener solo digitos");
                return false;
            } /* else {
             if (eval('document.SurveyResponse.txtQId'+survey_id+'4CId12.value') < 7000) {
             alert("El limite de credito de la TDC 3 debe ser mayor o igual a $7000.00");
             return false;
             }
             } */
        }
    }


    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId6.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId5.value') == '') {
                    alert(" Favor de seleccionar " + campo + " 3");
                    return  false;
                }
            }
        }
    }
    
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId14') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId14.value') == '') {
            alert(" Favor de seleccionar Numero de Objeciones");
            return  false;
        }
    }
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId15') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId15.value') == '') {
            alert(" Favor de seleccionar Objecion predominante del cliente");
            return  false;
        }
    }
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId16') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId16.value') == '') {
            alert(" Favor de seleccionar Comento tener problemas en buro?");
            return  false;
        }
    }
    if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId17') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '4CId17.value') == '') {
            alert(" Favor de seleccionar Numero de tarjetas que tiene el cliente");
            return  false;
        }
    }


    return bandera_telac;
}


function validarQuestion5() {
    bandera_telac = true;
    campo = "campos de Validacion";

    //-- Titular de Tarjeta Vigente
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId1.value') == '') {
            alert(" Favor de seleccionar Titular de una TDC en los " + campo);
            return  false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId1.value') == 'S') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId2.value') == '') {
                    alert("Favor de escribir Ultimos 4 digitos de TDC Vigente de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '5CId2'), "Ultimos 4 digitos de TDC de los " + campo, 4, 4))
                        return false;
                }
            }
        }
    }

    //-- Retrazo de TDC
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId6.value') == '') {
            alert(" Favor de seleccionar si a tenido retrazos en TDC de los " + campo);
            return  false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId6.value') == 'S') {
                //-- Tiempo de retrazo
                if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId7') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId7.value') == '') {
                        alert(" Favor de seleccionar tiempo maximo de retrazo de TDC de los " + campo);
                        return  false;
                    }
                }
            } else {
                //-- Tiempo de retrazo
                if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId7') != null) {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId7.value') != '') {
                        alert(" Favor de NO seleccionar tiempo maximo de retrazo de TDC de los " + campo);
                        return  false;
                    }
                }
            }
        }
    }



    //-- Reestructura TDC
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId8') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId8.value') == '') {
            alert(" Favor de seleccionar si a tenido reestructura de TDC de los " + campo);
            return  false;
        }
    }

    //-- Credito Hipotecario
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId3.value') == '') {
            alert(" Favor de seleccionar Credito Hipotecario de los " + campo);
            return  false;
        }
    }

    //-- Credito Automotriz Bancario
    if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '5CId4.value') == '') {
            alert(" Favor de seleccionar Credito Automotriz Bancario de los " + campo);
            return  false;
        }
    }


    return bandera_telac;
}

function validarQuestion6() {
    bandera_telac = true;
    campo = "Tarjetas Adicionales";

    //-- Tarjetas adicionales	
    if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '') {
            alert("Favor de seleccionar si requiere " + campo);
            return  false;
        }

        if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '1') {

            //-- Nombre Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId2') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId2.value') == '') {
                    alert("Favor de escribir el Nombre Completo de adicional 1 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId2'), "Nombre Completo Adicional 1 de " + campo, 1, 60))
                        return false;
                }
            }

            //-- Apellidos Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId3.value') == '') {
                    alert("Favor de escribir el Apellidos de Adicional 1 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId3'), "Apellidos de Adicional 1 de " + campo, 1, 80))
                        return false;
                }
            }

            //-- Fecha de Nacimiento Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value') == '') {
                    alert("Favor de escribir la fecha de nacimiento de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId5'), "fecha de nacimiento de los " + campo, 1, 10))
                        return false;
                }
            }

            //-- RFC Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId6') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId6.value') == '') {
                    alert("Favor de escribir el RFC de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId6'), "RFC de los" + campo, 1, 13))
                        return false;
                }
            }

            //-- Parentesco Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId7') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId7.value') == '') {
                    alert("Favor de seleccionar el parentesco del adicional 1 de los " + campo);
                    return  false;
                }
            }


        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId1.value') == '2') {

            //-- Nombre Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId2') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId2.value') == '') {
                    alert("Favor de escribir el Nombre Completo de adicional 1 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId2'), "Nombre Completo Adicional 1 de " + campo, 1, 60))
                        return false;
                }
            }

            //-- Apellidos Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId3.value') == '') {
                    alert("Favor de escribir el Apellidos de Adicional 1 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId3'), "Apellidos de Adicional 1 de " + campo, 1, 80))
                        return false;
                }
            }

            //-- Fecha de Nacimiento Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId5.value') == '') {
                    alert("Favor de escribir la fecha de nacimiento de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId5'), "fecha de nacimiento de los " + campo, 1, 10))
                        return false;
                }
            }

            //-- RFC Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId6') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId6.value') == '') {
                    alert("Favor de escribir el RFC de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId6'), "RFC de los" + campo, 1, 13))
                        return false;
                }
            }

            //-- Parentesco Adicioanal 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId7') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId7.value') == '') {
                    alert("Favor de seleccionar el parentesco del adicional 1 de los " + campo);
                    return  false;
                }
            }

            //-- Nombre Adicional 2
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId8.value') == '') {
                    alert("Favor de escribir el Nombre Completo de adicional 2 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId8'), "Nombre Completo Adicional 2 de " + campo, 1, 60))
                        return false;
                }
            }

            //-- Apellidos Adicional 2
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId9') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId9.value') == '') {
                    alert("Favor de escribir el Apellidos de Adicional 2 de " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId9'), "Apellidos de Adicional 2 de " + campo, 1, 80))
                        return false;
                }
            }

            //-- Fecha de Nacimiento Adicional 2
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId11') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId11.value') == '') {
                    alert("Favor de escribir la fecha de nacimiento de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId11'), "fecha de nacimiento de los " + campo, 1, 10))
                        return false;
                }
            }

            //-- RFC Adicional 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId12') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId12.value') == '') {
                    alert("Favor de escribir el RFC de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '6CId12'), "RFC de los" + campo, 1, 13))
                        return false;
                }
            }

            //-- Parentesco Adicioanal 2
            if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId13') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '6CId13.value') == '') {
                    alert("Favor de seleccionar el parentesco del adicional 2 de los " + campo);
                    return  false;
                }
            }


        }

    }

    return bandera_telac;
}


function validarQuestion7() {
    bandera_telac = true;
    campo = "Referencias Personales";

    //-- Nombre Referencia Familiar 1
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId86') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId86.value') == '') {
            alert("Favor de escribir el Nombre Completo de " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '7CId86'), "Nombre Completo de " + campo, 1, 60))
                return false;
        }
    }

    //-- Apellidos Refencia Familiar
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId87') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId87.value') == '') {
            alert("Favor de escribir el Apellidos de " + campo);
            return  false;
        } else {
            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '7CId87'), "Apellidos de " + campo, 1, 80))
                return false;
        }
    }

    //-- Email
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId88') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId88.value') != '') {
//            bandera_telac = ChecaEmail();
        }
    }

    //-- Lada Referencia
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value'))) {
                alert("La Lada debe tener solo dígitos de los " + campo);
                return  false;
            } else {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value.length') < 2) {
                    alert("La Lada debe ser 2 o 3 dígitos de los " + campo);
                    return  false;
                }
                /*
                 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value') != eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value')) {
                 alert("La Lada de Referencia 1 debe ser igual que la Casa");
                 return  false;
                 }
                 */
            }
        } else {
            alert("Favor de escribir la Lada de los " + campo);
            return  false;

        }
    }

    //-- Telefono Referencia
    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId90') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value') != '') {
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value'))) {
                alert("El Tel�fono Referencia 1 debe tener solo d�gitos de los " + campo);
                return  false;
            } else {
                if (/*eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value.length') +*/ eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value.length') != 10) {
                    alert("Entre el Tel�fono y la Lada de la Referencia 1 se deben de conjuntar 10 d�gitos de los " + campo);
                    return  false;
                }
            }
        } else {
            alert("Favor de escribir el Teléfono Referencia 1 de los " + campo);
            return  false;
        }
    }

    /*-- Correo electr�nico
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId28') != null) {
     if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId28.value') == '') {
     alert("Favor de escribir el Correo Electr�nico de " + campo);
     return false;
     } 
     }///*/







    //-- Nombre Referencia Familiar 1
//    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId91') != null) {
//        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId91.value') == '') {
//            alert("Favor de escribir el Nombre Completo de " + campo);
//            return  false;
//        } else {
//            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '7CId91'), "Nombre Completo de " + campo, 1, 60))
//                return false;
//        }
//    }

    //-- Apellidos Refencia Familiar
//    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId92') != null) {
//        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId92.value') == '') {
//            alert("Favor de escribir el Apellidos de " + campo);
//            return  false;
//        } else {
//            if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '7CId92'), "Apellidos de " + campo, 1, 80))
//                return false;
//        }
//    }

    //-- Email
//    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId93') != null) {
//        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId93.value') != '') {
//            bandera_telac = ChecaEmail();
//        }
//    }

    //-- Lada Referencia
//    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94') != null) {
//        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value') != '') {
//            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value'))) {
//                alert("La Lada debe tener solo dígitos de los " + campo);
//                return  false;
//            } else {
//                if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value.length') < 2) {
//                    alert("La Lada debe ser 2 o 3 dígitos de los " + campo);
//                    return  false;
//                }
//                /*
//                if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value') != eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value')) {
//                    alert("La Lada de Referencia 2 debe ser igual que la Casa");
//                    return  false;
//                }
//                */
//            }
//        } else {
//            alert("Favor de escribir la Lada de los " + campo);
//            return  false;
//        }
//    }

    //-- Telefono Referencia
//    if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId95') != null) {
//        if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value') != '') {
//            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value'))) {
//                alert("El Teléfono Casa debe tener solo dígitos de los " + campo);
//                return  false;
//            } else {
//                if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value.length') != 10) {
//                    alert("Entre el Teléfono y la Lada de la Casa se deben de conjuntar 10 dígitos de los " + campo);
//                    return  false;
//                }
//            }
//        } else {
//            alert("Favor de escribir el Tel�fono Casa de los " + campo);
//            return  false;
//        }
//    }

    return bandera_telac;
}

function getDOY(fecha_actual) {
    var onejan = new Date(fecha_actual.getFullYear(), 0, 1);
    return Math.ceil((this - onejan) / 86400000);
}


function validarQuestion100() {
    bandera_telac = true;
    campo = " Datos de Autenticacion";

    //Codigo cliente
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '') {
            alert("Favor de escribir el Codigo de Cliente de los " + campo);
            return  false;
        } else {
            //if(!tamanos(eval('document.SurveyResponse.txtQId'+survey_id+'1CId1'), "Codigo de Cliente de los" + campo, 17,17)) return false;
            if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value'))) {
                alert("El Codigo de Cliente debe tener solo d�gitos de los " + campo);
                return  false;
            }
        }
    }

    /*codigo = eval('document.SurveyResponse.txtQId'+survey_id+'1CId1.value')  
     anio  = codigo.substring(0,4);
     fijo  = codigo.substring(7,9);
     fijo2 = codigo.substring(14,17);	
     
     var fecha_actual = new Date ();
     anio1 = fecha_actual.getFullYear();	
     if(anio == anio1){
     if(fijo == '12'){
     if(fijo2.toUpperCase() != 'MXN'){
     alert("El formato del codigo ingresado no es correcto")
     return false;	
     }
     }else{
     alert("El formato fijo del codigo ingresado no es correcto")
     return false;	
     }
     }else{
     alert("El formato de a�o en el codigo ingresado no es correcto")
     return false;	
     }
     
     //-- Resultado de tramite
     if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2') != null){
     if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2.value') ==''){		
     alert("Favor de seleccionar el resultado del tramite de los " + campo);
     return  false;
     }
     }	*/

    //-- Docuementos Solicitados
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '') {
            alert("Favor de seleccionar los documentos solicitados de los " + campo);
            return  false;
        }
    }

    var antiguedad = 13;

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value') == 'AU') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != 'P' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != 'D' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != 'D1') {
                    alert("Cuando el Resultado es AUTENTICADO, solo se permite seleccionar \nPENDIENTE C/ DOCS\nDECLINADA\n para los documentos solicitados");
                    return  false;
                }
            }
        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value') == 'AP') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != '3D' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') != '2D') {
                    alert("Cuando el Resultado es COND APROBADO, solo se permite seleccionar \r3 DOCUMENTOS\r2 DOCUMENTOS\r para los documentos solicitados de" + campo);
                    return  false;
                }
            }
        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId2.value') == 'NA') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (antiguedad < 12) {
                    alert("Cuando el Resultado es NO AUTENTICADO, solo se permite seleccionar \r3 DOCUMENTOS\r para los documentos solicitados " + campo);
                    return  false;
                } else if (antiguedad >= 12) {
                    alert("Cuando el Resultado es NO AUTENTICADO, solo se permite seleccionar \r2 DOCUMENTOS\r para los documentos solicitados " + campo);
                    return  false;
                }
            }
        }
    }

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == '') {
            alert("Favor de seleccionar si se enviara mensajeria");
            return  false;
        }
    }


    //-- Se enviara mensajeria
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') != 'S') {
                    alert("El campo mensajeria debe seleccionar la opcion SI cuando el campo documentos son 2 o 3");
                    return  false;
                }
            }
        }
    }

    //-- Seguro siempre protegido
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId25') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId25.value') == '') {
            alert("Favor de selecionar si quiere seguro siempre protegido");
            return  false;
        }
    }

    //-- Seguro de desempleo
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId26') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId26.value') == '') {
            alert("Favor de selecionar si quiere seguro de desempleo");
            return  false;
        }
    }

    //-- Verifica que si se escogio seguro de desempleo, se llenen los beneficiarios...
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId26.value') == 'S') {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId27.value') == '') {
            alert('Favor de capturar al menos un beneficiario');
            return false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId28.value') == '') {
                alert("Favor de seleccionar el porcentaje designado 1");
                return false;
            }
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId31.value') == '') {
                alert("Favor de seleccionar el parentesco 1");
                return false;
            }
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId29.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId30.value') == '') {
                alert("Favor de seleccionar el porcentaje designado 2");
                return false;
            }
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId32.value') == '') {
                alert("Favor de seleccionar el parentesco 2");
                return false;
            }
        }









        //ORIGINALMENTE LA OPERACI�N ERA:
        //sumaPct = parseInt(parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value')) + parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'1CId30.value')));
        //sumaPct = ((eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value')) + (eval('document.SurveyResponse.txtQId'+survey_id+'1CId30.value')));
        /*if (sumaPct != 100) {
         alert("La suma de los porcentajes no es 100% (" + sumaPct + ")");
         return false;
         }*/

        /*
         //PERO AHOR� SE INTENTAR� DE LAS 2 FORMAS DE HACER LA OPER... PARA ASEGURAR EL RESULTADO:
         sumaPct1 = parseInt(parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value')) + parseInt(eval('document.SurveyResponse.txtQId'+survey_id+'1CId30.value')));
         sumaPct2 = ((eval('document.SurveyResponse.txtQId'+survey_id+'1CId28.value')) + (eval('document.SurveyResponse.txtQId'+survey_id+'1CId30.value')));
         
         //SE PREGUNTA SI ES MAYOR A CERO, ES DECIR SI EL VALOR TRAE UN N�MERO PARA VERIFICAR QUE SEA IGUAL A 100:
         if(sumaPct1 > 0){
         if (sumaPct1 != 100) {
         alert("1. La suma de los porcentajes no es 100% (" + sumaPct1 + ")");
         return false;
         }
         }
         
         //SI NO ENTR� A LA OPCI�N DE ARRIBA, LA DE ARRIBA SE OMITE AUTOM�TICAMENTE Y ENTONCES SE INTENTA LA DE ABAJO:
         if(sumaPct2 > 0){
         if (sumaPct2 != 100) {
         alert("2. La suma de los porcentajes no es 100% (" + sumaPct2 + ")");
         return false;
         }
         }
         
         //LO INTERESANTE DE ESTE ENJUAGUE ES QUE A FUERZAS ENTRA EN UNA O EN OTRA, PERO NO EN LAS 2
         */

        //EL INTENTO M�S RECIENTE ES...
        x = eval("document.SurveyResponse.txtQId" + survey_id + "1CId28.value");
        y = eval("document.SurveyResponse.txtQId" + survey_id + "1CId30.value");
        if (x == "")
            x = "0";
        if (y == "")
            y = "0";
        sumaPct = eval(eval(x) + "+" + eval(y));
        if (sumaPct != 100) {
            alert("La suma de los porcentajes no es 100% (" + sumaPct + ")");
            return false;
        }










    } else {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId27.value') != '') {
            alert('Favor de quitar el beneficiario 1');
            return false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId28.value') != '') {
                alert("Favor de quitar el porcentaje designado 1");
                return false;
            }
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId31.value') != '') {
                alert("Favor de quitar el parentesco 1");
                return false;
            }
        }
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId29.value') != '') {
            alert('Favor de quitar el beneficiario 2');
            return false;
        } else {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId30.value') != '') {
                alert("Favor de quitar el porcentaje designado 2");
                return false;
            }
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId32.value') != '') {
                alert("Favor de quitar el parentesco 2");
                return false;
            }
        }
    }

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == 'D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == 'D1' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == 'P') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                    alert("El campo mensajeria debe seleccionar la opcion NO cuando el campo documentos es pendiente c/docs, declinada o declinada/ctas nuevas");
                    return  false;
                }
            }
        }
    }

    // Identificacion oficial
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                            alert("Favor de seleccionar la identificacion oficial de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }

    // Comprobante de domicilio
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId6.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                            alert("Favor de seleccionar el comprobante de domicilio de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }

    // FM2
    var nacionalidad = 'MEX';
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S' && nacionalidad != 'MEX') {
                    alert("Favor de seleccionar si entregara FM2 de los " + campo);
                    return  false;
                }
            }
        }
    }

    // Comprobante de Ingreso
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId9') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId9.value') == '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                            alert("Favor de seleccionar el comprobante de ingreso que proporcionara de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }

    // Lugar de la cita

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == '') {
                            alert("Favor de seleccionar el lugar de la cita de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }


    // Fecha de la cita

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') == '') {
                            alert("Favor de Capturar la fecha de la cita de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }


    // Fecha de la cita 2 dias despues y no permite dias anteriores
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') != '') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                            anio = eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value.substring(6,10)');
                            mes = eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value.substring(3,5)');
                            dia = eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value.substring(0,2)');
                            today = mes + '/' + dia + '/' + anio

                            var fecha_cita = new Date(today);
                            var now_date = new Date();

                            if (fecha_cita.getDay() == 0 || fecha_cita.getDay() == 6) {
                                alert("La fecha seleccionada para la cita no es un dia habil\nCambie la fecha!!!");
                                return false;
                            }

                            now_date.setDate(now_date.getDate() + 1);

                            if (fecha_cita < now_date) {
                                alert("La fecha de la cita no puede ser anterior al dia de hoy, Debe ser 2 dias despues a la fecha actual");
                                return false
                            }
                        }
                    }
                }
            }
        }
    }



    // Hora de la cita

    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '2D' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '3D') {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId4.value') == 'S') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12.value') == '') {
                            alert("Favor de seleccionar la hora de la cita de los " + campo);
                            return  false;
                        }
                    }
                }
            }
        }
    }


    // Lugar de cita
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == 2 || eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == 3) {
            //Calle		
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value') == "") {
                    alert("Favor de capturar el campo Domicilio de los " + campo);
                    return  false;
                }
            }

            // Exterior
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') == "") {
                    alert("Favor de capturar el campo Num. Exterior de los " + campo);
                    return  false;
                }
            }

            //Calle 1
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16.value') == "") {
                    alert("Favor de capturar el campo Entre calle 1 de los " + campo);
                    return  false;
                }
            }

            //Calle 2
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') == "") {
                    alert("Favor de capturar el campo Entre calle 2 de los " + campo);
                    return  false;
                }
            }

            //CP
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId16.value') == "") {
                    alert("Favor de capturar el campo CP de los " + campo);
                    return  false;
                }
            }

            //Colonia o Colonia Alterna
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId20') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId20.value') == '') {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') == '') {
                            alert("Favor de seleccionar o escribir la Colonia de " + campo);
                            return false;
                        }
                    } else {
                        alert("Favor de seleccionar o escribir la Colonia de " + campo);
                        return false;
                    }
                } else {
                    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null) {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') != '') {
                            alert("Favor de seleccionar o escribir la Colonia de " + campo);
                            return false;
                        }
                    }
                }
            }




            //Delegacion
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value') == "") {
                    alert("Favor de capturar el campo CP de los " + campo);
                    return  false;
                }
            }

            //Estado
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') == "") {
                    alert("Favor de capturar el campo CP de los " + campo);
                    return  false;
                }
            }



            //-- Lada
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId23') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId23.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId23.value'))) {
                        alert("La Lada debe tener solo d�gitos de " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId23.value.length') > 3 || eval('document.SurveyResponse.txtQId' + survey_id + '1CId23.value.length') < 2) {
                            alert("La Lada debe ser 2 o 3 d�gitos de " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir la Lada de " + campo);
                    return  false;
                }
            }

            //-- Telefono

            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId24') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId24.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId24.value'))) {
                        alert("El Tel�fono debe tener solo d�gitos de " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId23.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId24.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada  se deben de conjuntar 10 d�gitos de " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el Tel�fono de " + campo);
                    return  false;
                }
            }





            /*//Telefono + Lada
             if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId23') != null && eval('document.SurveyResponse.txtQId'+survey_id+'1CId24') != null){
             if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId23.value') != "" || eval('document.SurveyResponse.txtQId'+survey_id+'1CId24.value') != ""){
             if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId23.value.length') +eval('document.SurveyResponse.txtQId'+survey_id+'1CId24.value.length') !=10){
             alert("La laongitud del campo lada y telefono deben ser a 10 posiciones");
             return  false;
             }
             //if(!tamanos(eval('document.SurveyResponse.txtQId'+survey_id+'1CId23')+eval('document.SurveyResponse.txtQId'+survey_id+'1CId24'), "Lada y telefono Cliente de los" + campo, 10,10)) return false;
             
             }
             }*/
        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == 1) {
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId16') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId18') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId20') != null && eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId16.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId16.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId20.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') != "" || eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') != "") {
                    alert("Los campos de domicilio solo se capturan cuando el lugar de la cita no es casa de los " + campo);
                    return  false;
                }
            }
            /*if(survey_id == 100){
             survey_id = 1
             if(eval('document.SurveyResponse.txtQId'+survey_id+'2CId13.value') == 05){
             alert("estado de Coahuila");
             return  false;
             }
             }*/
        } else {
            /*alert("Debes seleccionar el lugar de la cita de los " + campo);
             return  false;*/
        }
    }

    return bandera_telac;
}

function validarQuestion1_survey2() {
    bandera_telac = true;
    campo = " Datos del Referido";

    //-- Numero de referidos
    if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1') != null) {
        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '') {
            alert("Favor de seleccionar el numero de referidos que desea dar de alta de los " + campo);
            return  false;
        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '1') {
            //-- Nombre
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '') {
                    alert("Favor de escribir el Nombre del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId3'), "Nombre del referido 1 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId5'), "Apellido Paterno de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value'))) {
                        alert("La lada del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 1 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value'))) {
                        alert("El Tel�fono del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 1 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 1 de los " + campo);
                    return  false;
                }
            }

            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId11') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId12') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId13') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId15') != '') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId11.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId12.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId13.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value') != '') {
                    alert("Solo se permite llenar los campos del referido 1 de los " + campo);
                    return  false;
                }
            }

            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId18') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId20') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId21') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != '') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId18.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId20.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') != '') {
                    alert("Solo se permite llenar los campos del referido 1 de los " + campo);
                    return  false;
                }
            }

        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '2') {
            //-- Nombre
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '') {
                    alert("Favor de escribir el Nombre del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId3'), "Nombre del referido 1 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId5'), "Apellido Paterno de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value'))) {
                        alert("La lada del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 1 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value'))) {
                        alert("El Tel�fono del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 1 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 1 de los " + campo);
                    return  false;
                }
            }
            //-- Nombre Referido 2
            //-- Nombre
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == '') {
                    alert("Favor de escribir el Nombre del referido 2 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId10'), "Nombre del referido 2 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 2 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId12'), "Apellido Paterno del referido 2 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value'))) {
                        alert("La lada del referido 2 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 2 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value'))) {
                        alert("El Tel�fono del referido 2 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 2 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 2 de los " + campo);
                    return  false;
                }
            }

            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId18') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId20') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId21') != '' && eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != '') {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId18.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId20.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') != '') {
                    alert("Solo se permite llenar los campos del referido 1 y 2 de los " + campo);
                    return  false;
                }
            }

        } else if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId1.value') == '3') {
            //-- Nombre
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId3.value') == '') {
                    alert("Favor de escribir el Nombre del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId3'), "Nombre del referido 1 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId5.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 1 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId5'), "Apellido Paterno de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value'))) {
                        alert("La lada del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 1 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value'))) {
                        alert("El Tel�fono del referido 1 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId7.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId8.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 1 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 1 de los " + campo);
                    return  false;
                }
            }
            //-- Nombre Referido 2
            //-- Nombre
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId10.value') == '') {
                    alert("Favor de escribir el Nombre del referido 2 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId10'), "Nombre del referido 1 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId12.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 2 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId12'), "Apellido Paterno de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value'))) {
                        alert("La lada del referido 2 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 2 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value'))) {
                        alert("El Tel�fono del referido 2 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId14.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId15.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 2 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 2 de los " + campo);
                    return  false;
                }
            }

            //-- Nombre  Referido 3
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId17.value') == '') {
                    alert("Favor de escribir el Nombre del referido 3 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId17'), "Nombre de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Paterno Referido 3
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId19.value') == '') {
                    alert("Favor de escribir el Apellido Paterno del referido 3 de los " + campo);
                    return  false;
                } else {
                    if (!tamanos(eval('document.SurveyResponse.txtQId' + survey_id + '1CId19'), "Apellido Paterno del referido 3 de los" + campo, 1, 30))
                        return false;
                }
            }

            //-- Lada del referido 3
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value'))) {
                        alert("La lada del referido 3 debe tener solo d�gitos de los " + campo);
                        return  false;
                    }
                } else {
                    alert("Favor de escribir la lada del referido 3 de los " + campo);
                    return  false;
                }
            }

            //-- Telefono del referido 3
            if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22') != null) {
                if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value') != '') {
                    if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value'))) {
                        alert("El Tel�fono del referido 3 debe tener solo d�gitos de los " + campo);
                        return  false;
                    } else {
                        if (eval('document.SurveyResponse.txtQId' + survey_id + '1CId21.value.length') + eval('document.SurveyResponse.txtQId' + survey_id + '1CId22.value.length') != 10) {
                            alert("Entre el Tel�fono y la Lada del referido 3 se deben de conjuntar 10 d�gitos de los " + campo);
                            return  false;
                        }
                    }
                } else {
                    alert("Favor de escribir el telefono del referido 3 de los " + campo);
                    return  false;
                }
            }
        }
    }

    return bandera_telac;
}

/*
 function validarQuestion7(){
 bandera_telac = true;
 campo = "Datos Validacion";	
 
 //-- Codigo Cliente	
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId1') != null){
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId1.value') ==''){		
 alert("Favor de seleccionar si captura codigo cliente en " + campo);
 return  false;
 }
 }
 
 //-- Resultado	
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2') != null){
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2.value') ==''){		
 alert("Favor de captur el resultado en " + campo);
 return  false;
 }else{
 if(!tamanos(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2'), "Resultado es a 4 en " + campo+ " 3", 4,4)) return false;
 if (!/^([0-9])*$/.test(eval('document.SurveyResponse.txtQId'+survey_id+'1CId2.value'))){
 alert("El campo resultado debe tener solo d�gitos");
 return false;
 }
 }
 }
 }	
 
 //-- Documentos solicitados
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId3') != null){
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId3.value') ==''){		
 alert("Favor de capturar los documentos solicitados en " + campo);
 return  false;
 }
 }
 
 //-- Mensajeria	
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId4') != null){
 if(eval('document.SurveyResponse.txtQId'+survey_id+'1CId4.value') ==''){		
 alert("Favor de seleccionar si se envia mensajeria en " + campo);
 return  false;
 }
 }
 
 return bandera_telac;
 }
 */
function ChecaEmail() {
    var a = 0;
    var ArreEmail = new Array();
    var ArrePeguntaEmail = new Array();
    var banderaEmail = true;

    if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId26') != null) {
        ArreEmail[a] = eval('document.SurveyResponse.txtQId' + survey_id + '2CId26.value');
        ArrePeguntaEmail[a] = "Email:";
        a++;
    }

    for (a = 0; a < ArreEmail.length; a++) {
        //    alert("VALOR:" + ArreEmail[a] );
        if (ArreEmail[a].length > 0 && !emailCheck(ArreEmail[a])) {
            banderaEmail = false;
        }
    }

    return banderaEmail;
}

function emailCheck(emailStr) {

    var emailPat = /^(.+)@(.+)$/
    var specialChars = "\\(\\)<>@,;:\\\\\\\"\\.\\[\\]"
    var validChars = "\[^\\s" + specialChars + "\]"
    var quotedUser = "(\"[^\"]*\")"
    var ipDomainPat = /^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/
    var atom = validChars + '+'
    var word = "(" + atom + "|" + quotedUser + ")"
    var userPat = new RegExp("^" + word + "(\\." + word + ")*$")
    var domainPat = new RegExp("^" + atom + "(\\." + atom + ")*$")
    var matchArray = emailStr.match(emailPat)
    if (matchArray == null) {
        alert("EMAIL - LA DIRECCION DE CORREO ES INCORRECTA (CHECA QUE TENGAN @ Y .)")
        return false
    }
    var user = matchArray[1]
    var domain = matchArray[2]

    if (user.match(userPat) == null) {
        alert("EMAIL - EL NOMBRE DE USUARIO NO PUEDE SER VALIDO")
        return false
    }

    var IPArray = domain.match(ipDomainPat)
    if (IPArray != null) {
        for (var i = 1; i <= 4; i++) {
            if (IPArray[i] > 255) {
                alert("EMAIL - EL DESTINATARIO IP ES INVALIDO!")
                return false
            }
        }
        return true
    }

    var domainArray = domain.match(domainPat)
    if (domainArray == null) {
        alert("EMAIL - EL DOMINIO NO PUEDE SER VALIDO")
        return false
    }


    var atomPat = new RegExp(atom, "g")
    var domArr = domain.match(atomPat)
    var len = domArr.length
    if (domArr[domArr.length - 1].length < 2 ||
            domArr[domArr.length - 1].length > 3) {
        alert("EMAIL - LA DIRECCION DEL DOMINIO DEBE TERMINAR EN TRES LETRAS O DOS LETRAS PARA EL PAIS")
        return false
    }

    if (len < 2) {
        var errStr = "EMAIL - A la dirección le está faltando un hostname!"
        alert(errStr)
        return false
    }

    return true;
}

//VALIDA LOS TAMA�OS DE LOS DIFERENTES CAMPOS
function tamanos(campo, nombrecampo, log_min, log_max) {
    var a = 0;
    var contDigitos = 0;
    var Arretamano = new Array();
    var ArrePeguntatam = new Array();
    var Arrelongitudmin = new Array();
    var Arrelongitudmax = new Array();
    var arreNumDigitos = new Array();
    var arreNumDigitosTexto = new Array();
    //var banderatamanos=true;

    if (campo != null) {
        Arretamano[a] = campo.value.length;
        ArrePeguntatam[a] = nombrecampo;
        Arrelongitudmin[a] = log_min;
        Arrelongitudmax[a] = log_max;
        a++;
    }

    contDigitos = 0;

    for (a = 0; a < Arretamano.length; a++) {
        if ((Arretamano[a] < Arrelongitudmin[a] && Arretamano[a] > 0) || (Arretamano[a] > Arrelongitudmax[a] && Arretamano[a] > 0)) {
            contDigitos = arreNumDigitos.length;
            if (Arrelongitudmin[a] == Arrelongitudmax[a]) {
                alert(ArrePeguntatam[a] + "  \n\n Longitud debe ser igual a " + Arrelongitudmax[a]);
                campo.select();
            } else {
                alert(ArrePeguntatam[a] + "  \n\n La Longitud debe estar entre " + Arrelongitudmin[a] + " y " + Arrelongitudmax[a]);
                campo.select();
            }
            return false;
            break;
        }
    }
    return true;
}

function validarTelefonosReferencias() {
    telRef1 = /*eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value') +*/ eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value');
    if (telRef1 == "") {
        telRef1 = "telRef1";
    }
    telCel1 = ""/*eval('document.SurveyResponse.txtQId' + survey_id + '7CId96.value')*/;
    if (telCel1 == "") {
        telCel1 = "telCel1";
    }
    /*telRef2 = eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value') + eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value');
     if (telRef2 == "") {
     telRef2 = "telRef2";
     }*/

    /*casa = eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value') + eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value');
     if (casa == "") {
     casa = "casa";
     }*/

    Trabajo = eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') + eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value');
    if (Trabajo == "") {
        Trabajo = "Trabajo";
    }

    telCel2 = ""/*eval('document.SurveyResponse.txtQId' + survey_id + '7CId97.value')*/;
    if (telCel2 == "") {
        telCel2 = "telCel2";
    }
    telRef3 = /*eval('document.SurveyResponse.txtQId' + survey_id + '7CId102.value') +*/ eval('document.SurveyResponse.txtQId' + survey_id + '7CId103.value');
    if (telRef3 == "") {
        telRef3 = "telRef3";
    }

    if (telRef1 == telCel1 ||
            //telRef1 == telRef2 ||
            //telRef1 == telCel2 || 
            telRef1 == telRef3 ||
            //telCel1 == telRef2 || 
            telCel1 == telCel2 ||
            telCel1 == telRef3 ||
            //telRef2 == telCel2 || 
            //telRef2 == telRef3 ||
            telCel2 == telRef3) {
        alert("Los tel�fonos de referencias no pueden repetirse. Favor de revisar.");
        return false;
    } else if (/*casa == telRef1 ||*/ Trabajo == telRef1 /*|| casa == telRef2 || Trabajo== telRef2*/) {
        alert("Los tel�fonos de referencias no pueden repetirse. Favor de revisar telefono de casa o Trabajo");
        return false;
    } else {
        return true;
    }
}

function validarTelefonosEmpleo() {
    if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId1') != null) {
        ocupacion = eval('document.SurveyResponse.txtQId' + survey_id + '3CId1.value');
        //Si la ocupaci�n es "Empleado" validar tel�fonos
        if (ocupacion == "4") {
            /*if(eval('document.SurveyResponse.txtQId' + survey_id + '2CId23') != null && eval('document.SurveyResponse.txtQId' + survey_id + '2CId24') != null){
             telCasa = eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value') + eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value');
             }else{
             telCasa = "telCasa";
             }
             if (telCasa == "") {
             telCasa = "telCasa";
             }*/
            telOficina = eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') + eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value');
            if (telOficina == "") {
                telOficina = "telOficina";
            }
            /*if (telCasa == telOficina) {
             alert("Los tel�fonos de casa (o celular) no pueden ser los mismos que de oficina. Favor de revisar.");
             return false;
             } else {
             return true;
             }*/
        }
    }
    return true;
}

function SaveForm(boton)
{
    //			document.all.item("CAMPOCP").value = "OTRA";
    //			boton.style.visibility = "hidden";
    //			startclock();
    document.getElementById("modo").value = "guardar";
    alert('La solicitud que estas guardando es: ' + customer_id);
    document.SurveyResponse.submit(); //ohernandez@20150702, lo deje comentado temporalmente xq reportaron varias veces que al darle guardar borra todo
}

function cp_cobertura() {
    if (v_cobertura == 1) {
        if (v_cobertura_casa == 0) {
            alert("[SIN COBERTURA]-Domicilio de Casa");
            return false;
        } else {
            return true;
        }
    } else if (v_cobertura == 2) {
        if (v_cobertura_empresa == 0) {
            alert("[SIN COBERTURA]-Domicilio de Empresa");
            return false;
        } else {
            return true;
        }
    } else if (v_cobertura == 3) {
        if (v_cobertura_empresa == 0 && v_cobertura_casa == 0) {
            alert("[SIN COBERTURA]-Ambos Domicilios");
            return false;
        } else if (v_cobertura_empresa > 0 || v_cobertura_casa > 0) {
            return true;
        }
    }
}

/*Inicio de Validaci�n de edad para AP, CV , AP Recuperados y CV Recuperados*/
function validarAdulto(fecha, campo, limite) {
    dateUser = fecha;
    anioUser = dateUser.substr(6, 4)
    mesUser = dateUser.substr(3, 2)
    diaUser = dateUser.substr(0, 2)
    var dinami_edad = 0;

    currentDate = new Date();
    currentDay = currentDate.getDate();
    currentMonth = (currentDate.getMonth() + 1);
    currentYear = currentDate.getFullYear();

    if (currentMonth == 1 || currentMonth == 2 || currentMonth == 5 || currentMonth == 7 || currentMonth == 8 || currentMonth == 10 || currentMonth == 12) {
        daysinmonth = 31
    } else if (currentMonth == 2) {
        if (currentYear % 4 == 0) {
            daysinmonth = 28
        } else {
            daysinmonth = 29
        }
    } else if (currentMonth == 4 || currentMonth == 6 || currentMonth == 9 || currentMonth == 11) {
        daysinmonth = 30
    }

    mod_year = currentYear - anioUser;
    mod_day = currentDay - diaUser;
    mod_month = currentMonth - mesUser;

    if (mod_month < 0) {
        mod_year = mod_year - 1;
        mod_month = 12 + mod_month;
        if (mod_day < 0) {
            mod_month = mod_month - 1;
            mod_day = 30 + mod_day;
        }
    } else {
        if (mod_month == 0) {
            if (mod_day < 0) {
                mod_year = mod_year - 1;
                mod_month = 11;
                mod_day = 30 + mod_day;
            }
        } else {
            if (mod_day < 0) {
                mod_month = mod_month - 1;
                mod_day = 30 + mod_day;
            }
        }
    }
    if (limite == "T") {
        dinami_edad = 70;
        dinami_edadminima = 18;
    }

    if (mod_year < dinami_edadminima) {
        alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
        return false;
    } else {
        if (dinami_edad == mod_year) {
            alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
            return false;
        } else {
            if (dinami_edad > mod_year) {
                return true;
            } else {
                alert("ERROR en la Pregunta \n\n--   " + campo + "--\n\n El usuario no cumple con la edad requerida, Tiene " + mod_year + " a�os, con " + mod_month + " meses. ")
                return false;
            }
        }
    }

}

/*Fin de Validaci�n de edad*/


function CerrarWin() {
//window.close();
}


function VerificaCapturaRFC(objeto, tipoobjeto) {
    // Text Box
    //if ( tipoobjeto = 5 ) {
    alert(objeto.value);
//}
}

function quitaEspaciosDobles(texto) {
    var cadena = texto;
    var aux = '';
    for (i = 0; i < texto.length - 1; i++) {
        if (texto.charAt(i) == ' ') {
            aux = aux + texto.charAt(i);
            if (texto.charAt(i + 1) != ' ') {
                cadena = cadena.replace(aux, ' ');
                aux = '';
            }
        }
    }

    return cadena;
}



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//			Funcion que va ha validar caracteres especiales
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
function checaCaracteresInvalidos(boton) {
    var forma = boton.form
    var a = 0;
    var banderaCaracterEspecial;
    banderaCaracterEspecial = false;
    var matchArray;
    var cadena;

    var strCadena2 = "";
    var strCadena = "";
    for (a = 0; a < forma.elements.length - 1; a++) {
        if (forma.elements[a].type == 'hidden') {
            if (forma.elements[a].name == 'hdntxt') {
                strCadena2 = "";
                strCadena = "";
                cadena = document.all.item(forma.elements[a].value).value;
                while (hayCaracteres(cadena).length > 0) {
                    strCadena2 = hayCaracteres(cadena);

                    // 	    alert("ENTRO WHILE: " + strCadena2);
                    strCadena = cadena;
                    if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'a')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'e')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'i')
                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'o')

                    } else if (strCadena2 == "�") {
                        ExpreRegNew = /\�/;
                        strCadena = strCadena.replace(ExpreRegNew, 'u')
                    } else {
                        arrText = strCadena.split(strCadena2);
                        strCadena = arrText.join("");
                    }
                    cadena = strCadena;
                    document.all.item(forma.elements[a].value).value = strCadena;
                }
            }//if  hdntxt
        }// if hidden
    }//for

    if (banderaCaracterEspecial) {
        window.scroll(1, a * 7.5)
        alert("REVISA QUE EL CAMPO NO TENGA CARACTERES ESPECIALES \n                                    %,$,?,�,(,),{,},[,],*,+,#,&");
        return true;
    } else {
        return false;
    }
}// fin checaCaracteresInvalidos


function hayCaracteres(cadena) {
    ExpreReg = /%|\$|\?|\�|\(|\)|\{|\}|\[|\]|\*|\+|\t|\c13|\#|\&|\�|\||\�|\,|\;|\:|\_|\:|\~|\�|\�|\�|\�|\�|\'|\!|\�|\<|\>|\^/;		  		//'
    matchArray = cadena.match(ExpreReg); // si algun caracter es igual a %,$,?,�,(,),{,},[,],*,+,#,&,�,|,�,,,;,:
    if (matchArray == null) {
        return "";
    } else {
        return matchArray;
    }
}
/*
 function verify_movil2(tel){
 
 if(tel == 1){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23') != null && eval('document.SurveyResponse.txtQId' + survey_id + '2CId24') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '2CId23.value') + eval('document.SurveyResponse.txtQId' + survey_id + '2CId24.value');
 //alert(numero);
 request = "numero=" + numero;        
 send_post_page_verifica_numero2(request,"tel_1", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);                    
 }
 }
 }else if(tel == 2){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '2CId25.value');
 //alert(numero);
 request = "numero=" + numero;
 send_post_page_verifica_numero2(request,"tel_2", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }
 }else if(tel == 3){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89') != null && eval('document.SurveyResponse.txtQId' + survey_id + '7CId90') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '7CId89.value') + eval('document.SurveyResponse.txtQId' + survey_id + '7CId90.value');
 //alert(numero);
 request = "numero=" + numero;
 send_post_page_verifica_numero2(request,"tel_3", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }else if(tel == 4){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94') != null && eval('document.SurveyResponse.txtQId' + survey_id + '7CId95') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '7CId94.value')+eval('document.SurveyResponse.txtQId' + survey_id + '7CId95.value');
 //alert(numero);
 request = "numero=" + numero;
 send_post_page_verifica_numero2(request,"tel_4", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }else if(tel == 5){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId102') != null && eval('document.SurveyResponse.txtQId' + survey_id + '7CId103') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId102.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '7CId103.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '7CId102.value') + eval('document.SurveyResponse.txtQId' + survey_id + '7CId103.value');
 //alert(numero);
 request = "numero=" + numero;        
 send_post_page_verifica_numero2(request,"tel_5", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }else if(tel == 6){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId96') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId96.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '7CId96.value');
 //alert(numero);
 request = "numero=" + numero;        
 send_post_page_verifica_numero2(request,"tel_6", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }else if(tel == 7){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId97') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '7CId97.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '7CId97.value');
 //alert(numero);
 request = "numero=" + numero;        
 send_post_page_verifica_numero2(request,"tel_7", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }else if(tel == 8){
 if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13') != null && eval('document.SurveyResponse.txtQId' + survey_id + '3CId14') != null) {
 if (eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') != '' || eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value') != '') {
 numero = eval('document.SurveyResponse.txtQId' + survey_id + '3CId13.value') + eval('document.SurveyResponse.txtQId' + survey_id + '3CId14.value');
 //alert(numero);
 request = "numero=" + numero;        
 send_post_page_verifica_numero2(request,"tel_8", "modules.php?mod=agentes&op=process_data&act=NDE=",tel);
 }
 }            
 }
 }
 
 function send_post_page_verifica_numero2(request, container, page,tel) {
 
 var contenedor;
 contenedor = document.getElementById(container);
 
 ajax5 = nuevoAjax();
 ajax5.open("POST", page, true);
 ajax5.onreadystatechange = function() {
 if (ajax5.readyState == 4) {
 if(ajax5.responseText == 'No valido'){
 //alert("Telefono no valido, Verificar los telefonos e Ingresar un telefono valido");
 tel_valido = 1;
 }else{                
 tel_valido = 0;
 }
 }
 }
 ajax5.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 ajax5.send(request);
 
 }
 
 
 
 function sleep(milliseconds) {
 var start = new Date().getTime();
 for (var i = 0; i < 1e7; i++) {
 if ((new Date().getTime() - start) > milliseconds){
 break;
 }
 }
 }
 */
