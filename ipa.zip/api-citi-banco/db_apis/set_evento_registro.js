const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
 console.log(context);
const baseQuery = "BEGIN " + context.schema + ".xsp_set_eventlog_registro(:p_id_solicitud,:p_id_user,:evento); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  binds.p_id_solicitud = context.p_id_solicitud;
  binds.p_id_user = context.s_usr_id;
  //binds.evento = context.p_evento;
  binds.evento = { val: context.p_evento , dir:oracledb.BIND_IN , type: oracledb.DB_TYPE_VARCHAR };


  const result = await database.simpleExecute(query, binds);
  // console.log(result);
  return result;
}

module.exports.find = find;
