<body onblur="focus()">
<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
echo 'Llamando';
print ('<br/><img src="includes/imgs/loading.gif"/>');


?>
