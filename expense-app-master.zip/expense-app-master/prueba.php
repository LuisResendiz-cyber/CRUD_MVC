<?php
    echo 2*2;
?>