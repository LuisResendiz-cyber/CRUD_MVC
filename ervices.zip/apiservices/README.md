# API de Servicios Integrados

API diseñada para gestionar servicios de comunicación y reportes automatizados con las siguientes funcionalidades:

- 🔌 **Conexión a servicios de internet**
- 📱 **Envío masivo de SMS** (campañas)
- ✉️ **Envío de correos electrónicos** mediante SFTP (Impulse/Doppler)
- 📊 **Generación automática de reportes**:
  - Reportes cortos para CITI
  - Reportes de asistencia para seguros
  - Mapas de calor

## Tecnologías Clave
- Node.js 20.x
- axios
- crypto-js
- express
- mysql2
- nodemailer
- oracledb
- pg
- axios
- axios
- axios

## Requisitos Previos
- Node.js 20.x ([Descargar](https://nodejs.org/))
- npm 9.x+
- Credenciales para servicios de:
  - SMS
  - SFTP (Impulse/Doppler)
  - Reportería
## Estructura del proyecto
```
└── 📁apiservices
    └── 📁src
        └── 📁assets
            └── 📁docs
                └── Reporte_Corto_CLI.xlsx
                └── Reporte_Corto_CNC.xlsx
                └── Reporte_Corto_CPC.xlsx
                └── Reporte_Corto_Sofom.xlsx
                └── Reporte_Corto.xlsx
                └── Reporte_KPIS.xlsx
                └── ReporteAsistenciaDig.xlsx
        └── 📁cert
            └── certificado.crt
            └── clave-privada.key
        └── 📁config
            └── db-mysql.js
            └── db-oraclePool.js
            └── db-pg.js
            └── dopplerConfig.json
            └── smtpConfig.json
        └── 📁controller
            └── controller_rep_corto_cli.js
            └── controller_rep_corto_cnc.js
            └── controller_rep_corto_cpc.js
            └── controller-aut-process.js
            └── controller-aut-reports.js
            └── controller-aut-rfc.js
            └── controller-check.js
            └── controller-cod31.js
            └── controller-digital.js
            └── controller-doppler.js
            └── controller-gral.js
            └── controller-impulse.js
            └── controller-mailer.js
            └── controller-multer.js
            └── controller-reporte-corto-sofom.js
            └── controller-reporte-corto.js
            └── controller-reporte-kpis-06-11-2024.js
            └── controller-reporte-kpis.js
            └── controller-sms.js
        └── 📁model
            └── model-mailer.js
            └── model-mysql.js
            └── model-mysqlPool.js
            └── model-oracle.js
            └── model-oraclePool.js
            └── model-pg.js
            └── model-sms.js
        └── 📁public
            └── 📁csv
                └── asistencia.csv
                └── ReporteAsistenciaBau.xlsx
                └── ReporteAsistenciaDig.xlsx
            └── 📁html
                └── EMM_Insurance_Days_Junio.html
                └── index.html
                └── index2.html
                └── Insurance_Email Auto_BA_0934.html
                └── layout.html
                └── reporteAsistencia.html
            └── 📁img
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_AUTO_MOB.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_AUTO.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_BANNER.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_GUARD_MOB.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_GUARD.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_LOGO.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_SEGUROS.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_TAG.png
                └── MEX_ICSS_INSMX0518M_NLTravelJulBBX_01_08Jul2024_211241_TRAVEL.png
                └── ping.png
            └── 📁json
                └── correos.json
            └── 📁mapa_calor
                └── MAPA_CALOR_CITIBANCO.csv
                └── MAPA_CALOR_CITIBANCO.zip
                └── MAPA_CALOR_CITISOFOM.csv
                └── MAPA_CALOR_CITISOFOM.zip
                └── MAPA_CALOR_TDCAMEXONLINE.csv
                └── MAPA_CALOR_TDCAMEXONLINE.zip
        └── 📁routes
            └── routes.js
            └── routesAutProcess.js
    └── .env
    └── .gitignore
    └── index.js
    └── notas-txt
    └── package-lock.json
    └── package.json
    └── README.md
```


## Instalación y Configuración

1. **Clonar repositorio**:
```bash
git clone git@172.20.1.236:desarrollo/apiservices.git
cd apiservices

2. **Clonar repositorio**:
npm install
