const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".xsp_getColonia3_ws(:cp, :rc); END;";
//console.log(context);
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.cp){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.cp      = context.cp;
//            binds.id      = context.id;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

//console.log(result);

            return result;
        }
}

module.exports.find = find;
