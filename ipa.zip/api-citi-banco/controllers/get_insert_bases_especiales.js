const get_insert_bases_especiales = require('../db_apis/get_insert_bases_especiales.js');
 
async function post(req, res, next) {
  try {
    // console.log("autenticar",req.body)
    
    const rows = await get_insert_bases_especiales.find(req.body);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;