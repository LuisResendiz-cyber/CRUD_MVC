<?php
# @uthor Mark
# Agenda File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Registros Agendados");

$s_usr_id = get_session_varname("s_usr_id");
$id_registro = get_session_varname("id_registro");
$existesolicitud = ($id_registro != 0?$id_registro:0);
$fecha_busqueda = (strlen($_REQUEST['fecha_busqueda']) > 1?$_REQUEST['fecha_busqueda']:"");
$today = get_today();
$tipo_standby = $_REQUEST["e"];
$estatus = $_REQUEST["e"];

set_session_varname("tipo_standby", 8);

if($estatus == 1){
    $msg = 'Break';
} else if($estatus == 2) {
    $msg = 'Ba�o';
} else if($estatus == 3) {
    $msg = 'Capacitaci�n';
} else if($estatus == 4) {
    $msg = 'Retroalimentaci�n';
} else if($estatus == 5) {
    $msg = 'Ver Reporter�a';
} else if($estatus == 6) {
    $msg = 'Descanso Forzado';
} else if($estatus == 7) {
    $msg = 'Junta de Arranque';
} else if($estatus == 8) {
    $msg = 'Agenda';
} 


if(get_session_varname("log_registro") === 2){
    set_session_varname('log_registro',2);
}else{
    set_session_varname('log_registro',2);
    set_evento_registro(get_session_varname("s_usr_id"),-1,'CONSULTA AGENDA',$db);
}
layout_menu($db,"");
?>
<p class="textbold">Agentes &gt; Registros Agendados</p>
<p>&nbsp;</p>


<form method="post" name="frm3" id="frm3">
    <input type="hidden" name="u_persona" id ="u_persona">
    <input type="hidden" name="u_registro" id ="u_registro">
    <input type="text" name="fecha_agenda" id="fecha_agenda" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
    <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true;
                        verAgenda(this, document.getElementById('fecha_agenda').value, 'agenda2', 1);" />

    <div id="agenda2" align="center" class="script" style="overflow:auto;"></div>

</form>
<!--form method="post" action="modules.php?mod=agentes&op=registros_agenda" name="frm1">
<table class="text" border="0">
    <tr>
        <td colspan="3" class="label">
            &nbsp;Seleccione Fecha:
            <script language="JavaScript">
                    var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_busqueda','dateFormat' : 'd/m/Y'}
                    var fecha = '<?=(strlen($fecha_busqueda)!=0?$fecha_busqueda:$today)?>';
                    new sCalendar(SC_SET_1,fecha);
            </script>
        </td>
    </tr><tr>
        <td colspan="3">
            <input type="button" value="Buscar Agendados" onclick="Continuar_Agenda()"/>&nbsp;&nbsp;
        </td>
        <td colspan="3">
            <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true; verAgenda(this, document.getElementById('fecha_busqueda').value, 'agenda2', 1);" />
            <div id="agenda2" align="center" class="script"></div>
        </td>
        
        <?php
        if($fecha_busqueda != ""){

            $dia = substr($fecha_busqueda, 0, 2);
            $mes = substr($fecha_busqueda, 3, 2);
            $anio = substr($fecha_busqueda, 6, 4);
            $registros_agendados = get_detalle_agendados_usuario($s_usr_id, $anio, $mes, $dia, 1, $db);
        ?>
    </tr><tr>
        <td colspan="3"><hr></td>
    </tr><tr>
        <td colspan="3"><b>Registros agendados.</b></td>
    </tr><tr>
        <td colspan="3">
            <input type="hidden" name="u_persona" id ="u_persona">
            <input type="hidden" name="u_registro" id ="u_registro">
            <table>
                <tr style="font-weight:bold;" align="center">
                    <td># Reg.</td>
                    <td>&nbsp;</td>
                    <td># Solicitud</td>
                    <td>&nbsp;</td>
                    <td>Cliente</td>
                    <td>&nbsp;</td>
                    <td>Comentario</td>
                    <td>&nbsp;</td>
                    <td>Fecha</td>
                    <td>&nbsp;</td>
                    <td>Hora</td>
                    <td>&nbsp;</td>
                    <td>Mostrar</td>
                </tr>
                <?
                if(!$registros_agendados->EOF){
                    $i = 1;
                    $s = 0;
                    while(!$registros_agendados->EOF) {
                        $media_hora = get_medias_horas($registros_agendados->_array[$s]["MEDIAHORA"], $db);
                        echo '<tr>
                                <td align="center">'.$i.'</td>
                                <td>&nbsp;</td>
                                <td align="center">'.$registros_agendados->_array[$s]["U_PERSONA"].'</td>
                                <td>&nbsp;</td>
                                <td class="textleft">'.$registros_agendados->_array[$s]["NOMBRE"].'</td>
                                <td>&nbsp;</td>
                                <td class="textleft">'.$registros_agendados->_array[$s]["COMENTARIO"].'</td>
				<td>&nbsp;</td>
                                <td class="textleft">'.$registros_agendados->_array[$s]["DAY_"].'-'.$registros_agendados->_array[$s]["MONTH_"].'-'.$registros_agendados->_array[$s]["YEAR_"].'</td>
                                <td>&nbsp;</td>
                                <td class="textleft">'.$media_hora->fields['NOMBRE'].'</td>
                                <td>&nbsp;</td>
                                <td align="center"><a href="#" onclick="Mostrar_agendado('.$existesolicitud.', '.$registros_agendados->_array[$s]["U_REGISTRO"].', '.$registros_agendados->_array[$s]["U_PERSONA"].', \''.  encripta(3).'\')"><img src="'.$linkpath.'includes/imgs/Comenzar.gif"></a></td>
                              </tr>';

                        $i++;
                        $s++;
                        $registros_agendados->MoveNext();
                    }
                }else{
                    echo '<tr>
                             <td colspan="7"><font color="blue">No se encontraron resultados</font></td>
                          </tr>';
                }
                ?>
            </table>
        </td>
    </tr><tr>
            <td colspan="3">&nbsp;</td>
    </tr>
<?
}else
    echo '</tr>';
?>
</table>
</form-->
<?
layout_footer();
?>