const db = require('../config/configmysql');

const CustomersModel = {
    async getCustomers(){
        const [result] = await db.query("SELECT * FROM API_IDMISSION.DATA_IDMISSION di WHERE DOCUMENTATION_STATUS <> 'Successful Signature'");
        return result;
    }
}


module.exports = CustomersModel;