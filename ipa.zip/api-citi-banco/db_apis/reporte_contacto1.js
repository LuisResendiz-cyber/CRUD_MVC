const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  console.log(context);
  const baseQuery =
    "BEGIN CITI.XSP_REPORTECITI(:v_fecha_1, :v_fecha_2, :v_fecha_3, :v_fecha_4, :v_base, :rc); END;";
    //"BEGIN CITI.XSP_REPORTECITINVO(:v_fecha_1, :v_fecha_2, :v_fecha_3, :v_fecha_4, :v_base, :rc); END;"; 
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  let result = {};

  if (context.v_fecha_1 == "" || context.v_fecha_2 == "" || context.v_fecha_3 == "" || context.v_fecha_4 == "" || context.v_base == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
  } else {
    binds.v_fecha_1 = context.v_fecha_1;
    binds.v_fecha_2 = context.v_fecha_2;
    binds.v_fecha_3 = context.v_fecha_3;
    binds.v_fecha_4 = context.v_fecha_4;
    binds.v_base = context.v_base;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
    setTimeout(() => {
      console.log(result);
      return result;
    }, 20000);
    

  }
}

module.exports.find = find;
