<?php

class AuthService extends ApiClient
{
    public function login(string $email, string $password)
    {
        return $this->request('POST', 'Users/Login', [
            'email_user' => $email,
            'passwordHash'   => $password
        ]);
    }
}
