import https from "https";
import fs from "fs";
import path from "path";
import app from "./app";
import pool from "./config/dbMysqlConfig";

const PORT: number = Number(process.env.PORT) || 4000;

class Server {
  private server: https.Server;
  
  constructor() {
    const options = {
      key: fs.readFileSync(path.resolve(__dirname, "certs/key.pem")),
      cert: fs.readFileSync(path.resolve(__dirname, "certs/cert.pem")),
    };
    
    this.server = https.createServer(options, app);
    this.setupProcessHandlers();
    this.start();
  }

  private async start(): Promise<void> {
    try {
      // Verificar conexión a la base de datos
      const connection = await pool.getConnection();
      console.log('Connected to MySQL database');
      connection.release();

      // Iniciar servidor HTTPS
      this.server.listen(PORT, () => {
        console.log(`Server running on https://localhost:${PORT}`);
      });
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private setupProcessHandlers(): void {
    process.on("SIGINT", this.gracefulShutdown);
    process.on("SIGTERM", this.gracefulShutdown);
    process.on("unhandledRejection", (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    });
    process.on("uncaughtException", (error) => {
      console.error('Uncaught Exception:', error);
      this.gracefulShutdown();
    });
  }

  private gracefulShutdown = (): void => {
    console.log('\nShutting down gracefully...');
    
    // Cerrar servidor HTTP
    this.server.close(async () => {
      console.log('Server closed');
      
      // Cerrar conexiones de la base de datos
      try {
        await pool.end();
        console.log('Database connections closed');
      } catch (err) {
        console.error('Error closing database connections:', err);
      }
      
      process.exit(0);
    });

    // Forzar cierre después de 5 segundos si algo falla
    setTimeout(() => {
      console.error('Force shutdown after timeout');
      process.exit(1);
    }, 5000);
  }
}

new Server();