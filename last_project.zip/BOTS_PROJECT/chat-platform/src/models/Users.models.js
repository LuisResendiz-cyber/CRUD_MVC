const db = require("../db/mysql");

const Users = {
    async getUser(clientKey) {
        const rows = await db.query(`
        SELECT
        c.id           AS customerId,
        c.active       AS customerActive,
        b.id_bot       AS botId,
        b.name,
        b.type,
        b.estado,
        c.client_key
      FROM CUSTOMERS c
      JOIN USERS u on c.id = u.customer_id
      JOIN BOTS b on c.id = b.customer_id
      WHERE c.client_key = ?
          LIMIT 1
        `, [clientKey]);

        if (!rows.length ||!rows[0][0].customerActive) {
          return null;
        }
        return rows[0];
      },
      async CreateUser(datosUser) {
        const { customer_id, name, last_name, phone_number, email_user, password, rolid } = datosUser;

        const [result] = await db.query("INSERT INTO USERS(customer_id, name,last_name, phone_number, email_user, password, rolid) VALUES(?,?,?,?,?,?,?)", [customer_id, name, last_name, phone_number, email_user, password, rolid]);
        return result;
      },
      async getAcces(user) {  
        const { email_user } = user;
        const [rows] = await db.query('SELECT us.*, r.name as nombrerol FROM USERS us JOIN ROLES r ON us.role_id  = r.idrol  where email = ?', [email_user]);
        return rows[0];
      },
      async getModules(idUser) {
        const [rows] = await db.query(`SELECT DISTINCT m.title, m.icon, s.idsubmodule, s.title as submodulo_titulo, s.route as submodulo_ruta, s.icon as submodulo_icono,
    s.order as submodulo_orden
    FROM USERS u
    JOIN ROLES r ON u.role_id = r.idRol
    JOIN PERMISSIONS p ON r.idRol = p.rolid
    JOIN SUB_MODULES s ON p.submodule_id = s.idsubmodule
    JOIN MODULES m ON s.module_id = m.idmodule
    WHERE u.idUser = ?
      AND m.status = 1
      AND s.status = 1
    ORDER BY s.order;`, [idUser]);
        return rows;
      },
      async Roles(method, params = {}) {

        try {
          // Valores por defecto
          const {
            id = null,
            name = null,
            description = null,
            status = null
          } = params;
      
          // Ejecutar el procedimiento
          const [rows] = await db.query(
            'CALL sp_role_crud(?, ?, ?, ?, ?)', 
            [method, id, name, description, status]
          );

          // Devolver resultado según el método
          if (method === 1 || method === 2) {
            return rows[0]; // Datos de los roles
          } else {
            return rows[0][0]; // Mensajes de confirmación
          }
        } catch (error) {
          console.error('Error en Roles:', error);
          throw error;
        }
      },
      async User(option, params = {}) {
        try {
          const {
            customer_id = null,
            id = null,
            name = null,
            last_name= null,
            phone_number = null,
            email_user = null,
            password = null,
            rolid = null,
            status = null
          } = params;
    
          const [rows] = await db.query('CALL sp_user_crud(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [option, customer_id, id, name, last_name, phone_number, email_user, password, rolid, status]);          

          if (option === 1) {
            return rows[0];
          } else {
            return rows[0][0]; // Mensajes de confirmación
          }
          
        } catch (error) {
          console.error('Error en User CRUD:', error);
          throw error;
        }
      }
      
};

module.exports = Users;


