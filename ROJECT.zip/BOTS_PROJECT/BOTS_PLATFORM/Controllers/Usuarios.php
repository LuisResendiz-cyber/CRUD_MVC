<?php 

	class Usuarios extends Controllers{

		private AuthService $auth;

		public function __construct()
		{
			parent::__construct();
			session_start();
			if(empty($_SESSION['login']))
			{
				header('Location: '.base_url().'/login');
			}
			getPermisos(2);

			$this->auth = new AuthService();
		}

		public function Usuarios()
		{
			if(empty($_SESSION['permisosMod']['r'])){
				header("Location:".base_url().'/dashboard');
			}
			$data['page_tag'] = "Usuarios";
			$data['page_title'] = "USUARIOS <small>Impulse Bots</small>";
			$data['page_name'] = "usuarios";
			$data['page_functions_js'] = "functions_usuarios.js";
			$this->views->getView($this,"usuarios",$data);
		}

		public function setUsuario(){
			if($_POST){
				
				if(empty($_POST['txtNombre']) || empty($_POST['txtApellido']) || empty($_POST['txtTelefono']) || empty($_POST['txtEmail']) || empty($_POST['listRolid']) || empty($_POST['listStatus']) )
				{
					$arrResponse = array("status" => false, "msg" => 'Datos incorrectos.');
				}else{ 
					$idUsuario = intval($_POST['idUsuario']);				
					$strNombre = ucwords(strClean($_POST['txtNombre']));					
					$strApellido = ucwords(strClean($_POST['txtApellido']));					
					$intTelefono = intval(strClean($_POST['txtTelefono']));					
					$strEmail = strtolower(strClean($_POST['txtEmail']));					
					$intTipoId = intval(strClean($_POST['listRolid']));					
					$intStatus = intval(strClean($_POST['listStatus']));

					$authService = new AuthService();

					if($idUsuario == 0)
					{
						$option = 1;
						$strPassword =  empty($_POST['txtPassword']) ? passGenerator() : $_POST['txtPassword'];
						$request_user = $authService->createUser([          																			
																			'name' => $strNombre, 
																			'last_name' => $strApellido, 
																			'phone_number' => $intTelefono, 
																			'email_user' => $strEmail,
																			'passwordHash' => $strPassword, 
																			'rolid' => $intTipoId, 
																			'status' => $intStatus]);

					}else{
						$option = 2;
						$strPassword =  empty($_POST['txtPassword']) ? "" : $_POST['txtPassword'];
						
						$request_user = $authService->updateUser($idUsuario, 
																   ['name' => $strNombre,
																	'last_name' => $strApellido, 
																	'phone_number' => $intTelefono, 
																	'email_user' => $strEmail,
																	'passwordHash' => $strPassword, 
																	'rolid' => $intTipoId, 
																	'status' => $intStatus]);
					}

				}
				
				echo json_encode($request_user,JSON_UNESCAPED_UNICODE);
			}
			die();
		}

		public function getUsuarios()
		{
			$authService = new AuthService();
			$arrData = $authService->getAllUsers();

			echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
			die();
		}
		

		public function getUsuario(int $idpersona){
			
			$idusuario = intval($idpersona);
			if($idusuario > 0)
			{
				$authService = new AuthService();
				$arrData = $authService->getUserById($idusuario);
				
				echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
			}
			die();
		}

		public function delUsuarios(int $id = 0)
		{
				$intIdpersona = intval($id);
				$authService = new AuthService();
				$requestDelete = $authService->deleteUser($intIdpersona);
				echo json_encode($requestDelete,JSON_UNESCAPED_UNICODE);
			die();
		}

		public function perfil(){
			$data['page_tag'] = "Perfil";
			$data['page_title'] = "Perfil de usuario";
			$data['page_name'] = "perfil";
			$data['page_functions_js'] = "functions_usuarios.js";
			$this->views->getView($this,"perfil",$data);
		}

	}
 ?>