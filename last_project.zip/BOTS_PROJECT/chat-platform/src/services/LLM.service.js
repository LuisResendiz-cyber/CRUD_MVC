const { getProvider } = require("../services/provider.factory");

const generate = async (context) => {
  const {
    systemPrompt,
    userMessage,
    temperature,
    max_tokens,
    top_p,
    frequency_penalty,
    presence_penalty,
    model
  } = context;


  const provider = getProvider(model);

  const response = await provider.generate({
    systemPrompt,
    userMessage,
    temperature,
    max_tokens,
    top_p,
    frequency_penalty,
    presence_penalty,
    model
  });

  return response;
};

module.exports = { generate };
