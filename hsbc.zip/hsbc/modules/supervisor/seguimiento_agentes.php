<?php
# @uthor Mark
# Cuestionario File

require_once("includes/includes.inc.php");
require_once("supervisor.inc.php");

initialize("supervisor", "Seguimiento");

$id_solicitud = get_session_varname('id_solicitud');

layout_menu($db, "frm1.nomina.focus();");
?>
<p class="textbold">Supervisor &gt; Seguimiento de Agentes</p>
<p>&nbsp;</p>
<form method="post" name="frm1"><!--action="modules.php?mod=supervisor&op=resultado_agentes"-->
    <table border="0">
        <tr>
            <td colspan="2" class="label_td" bgcolor="grey">Datos</td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td class="textleft"><b>N&oacute;mina:&nbsp;</b></td>
            <td class="label"><input type="text" name="nomina" id="nomina" size="6" maxlength="6" /></td>
        </tr>
        <tr>
            <td class="textleft"><b>Del:&nbsp;</b></td>
            <td class="label">
                <script language="JavaScript">
                    var SC_SET_1 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_del','dateFormat' : 'd/m/Y'}
                    var fecha = '<?php echo date('d/m/Y') ?>';
                    new sCalendar(SC_SET_1, fecha);
                </script>
            </td>
        </tr>
        <tr>
            <td class="textleft"><b>Al:&nbsp;</b></td>
            <td class="label">
                <script language="JavaScript">
                    var SC_SET_2 = {'appearance': SC_APPEARANCE,'dataArea':'fecha_al','dateFormat' : 'd/m/Y'}
                    var fecha = '<?php echo date('d/m/Y') ?>';
                    new sCalendar(SC_SET_2, fecha);
                </script>
            </td>
        </tr>
        <tr>
            <td class="textleft"><b>Registros:&nbsp;</b></td>
            <td class="label">
                <input type="radio" name="tipo_rep" id="tipo_rep1" value="3" checked /><label for="tipo1">Tocados</label>
                <input type="radio" name="tipo_rep" id="tipo_rep2" value="1" /><label for="tipo2">Agendados</label>
                <input type="radio" name="tipo_rep" id="tipo_rep3" value="2" /><label for="tipo3">Con ventas</label>
            </td>
        </tr>
        <tr>
            <td colspan="2">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" value="Cancelar" onclick="window.location='index2.php'"/>&nbsp;&nbsp;
                <input type="button" value="Mostrar Reporte" onclick="seg_agente();">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
                <div id="resp_act" style="display:none"><img src="<?= $linkpath ?>includes/imgs/loading.gif"></div>
            </td>
        </tr>
    </table>
</form>
<?
layout_footer();
?>