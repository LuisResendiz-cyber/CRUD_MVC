const Joi = require('joi');

// Definimos el esquema de validación
const userSchema = Joi.object({
    username: Joi.string().min(3).max(30).required().messages({
        "string.base": "El nombre de usuario debe ser un texto",
        "string.empty": "El nombre de usuario es obligatorio",
        "string.min": "El nombre de usuario debe tener al menos {#limit} caracteres",
        "string.max": "El nombre de usuario no puede tener más de {#limit} caracteres",
        "any.required": "El nombre de usuario es obligatorio"
    }),
    email: Joi.string().email().required(),
    passwordHash: Joi.string().min(6).required()
}).unknown(true);


const UserSchema = Joi.object({
    id: Joi.number().integer().min(1).required().messages({
    "number.base": "El id debe ser un número",
    "number.integer": "El id debe ser un número entero",
    "number.min": "El id debe ser mayor a 0",
    "any.required": "El id es obligatorio"
  })
})


const loginSchema = Joi.object({
    email: Joi.string().required().messages({
        "string.base": "El nombre de usuario debe ser un texto",
        "any.required": "El email de usuario es obligatorio"
    }),
    passwordHash: Joi.string().required().messages({
        "string.base": "El password de usuario debe ser un Alfanumerico",
        "any.required": "El password de usuario es obligatorio"
    }),
})

const checkUser = (req, res, next) => {
    const { error } = userSchema.validate(req.body);
    if (error) {
        return res.status(400).json({ error: error.details[0].message });
    }
    next();
};

 const checkLogin = (req, res, next) => {
     const { error } = loginSchema.validate(req.body);

     if (error) {
         return res.status(400).json({ error: error.details[0].message });
     }
     next();
 }

 const checkGetUser = (req, res, next)=>{
     const { error } = UserSchema.validate(req.params);

     if (error) {
        return res.status(400).json({error: error.details[0].message})
     }
     next();
 }


const check = { checkUser, checkLogin, checkGetUser }

module.exports = check;
