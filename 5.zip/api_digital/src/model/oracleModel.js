import * as db from "../config/dbOracle.js";
import oracledb from 'oracledb';
import { notifySMS } from "../controller/gralController.js";
import { saveLog } from "../controller/mysqlController.js";

async function checkConn() {
  let connection;
  try {
    const pool = db.getPool();
    connection = await pool.getConnection();
    const result = await connection.execute("SELECT 1 AS RSPTA FROM dual");
    // console.log("Resultado de la consulta:", result.rows[0]);
    return true;
  } catch (error) {
    console.error("Error al testear la conexión a Oracle DB:", error);
    return false;
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log("Conexion liberada");
      } catch (err) {
        console.error("Error al cerrar la conexión:", err.message);
      }
    }
  }
}
const inserLeadsOracle = async (data) => {
  let connection;
  try {
    // db.initPool();
    const pool = db.getPool();
    connection = await pool.getConnection();

    const sql = `
    INSERT INTO amexinsurancedig.TU_CARGABASE_2 (base,etiqueta_reg,col_05,nombre,telefono_1,ESRAB_DATE,col_10,OFFER_TYPE,col_02,COL_11,COL_12,COL_13,COL_14,"MEDIUM",EMAIL,AUTO_YEAR,MODEL_BRAND_VERSION,CODIGO_POSTAL,MONTO_AXXA,MONTO_CHUBB,FOLIO,DTDEC,DTDEC_REGRESO,CLIENTE_AMEX,VIAJA_SEGUIDO,VIAJA_CON_FAMILIA,FOLIO_RELACIONADO
      ) 
    VALUES (
      :BASE,
      :ETIQUETA_REG,
      :ID,
      :NOMBRE,
      :TELEFONO,
      TO_DATE(:FECHA_C, 'YYYY/MM/DD'),
      :HORA_C,
      :CATEGORIA,
      :FECHA_DE_NACIMIENTO,
      :BOUNCE_FUNNEL,
      :SOURCE,
      :CAMPAIGN,
      :GCLID,
      :MEDIUM,
      :EMAIL,
      :AUTO_YEAR,
      :MODEL_BRAND_VERSION,
      :POSTCODE,
      :AXA_AMOUNT,
      :CHUBB_AMOUNT,
      :FOLIO,
      :FECHA_SALIDA,
      :FECHA_REGRESO,
      :CLIENTE_AMEX,        
      :VIAJA_SEGUIDO,        
      :VIAJA_CON_FAMILIA,
      :ID_RELACIONADO

    ) `;

    const result = await connection.executeMany(sql, data);

    // console.log(result)
    await connection.commit();

    return result.rowsAffected;
  } catch (error) {
    console.log(error);
    await saveLog(`Error al insertar datos en oracle TU_CARGABASE_2`,2,error);

    await notifySMS(`Error al insertar datos a tu_cargabase_2: ${error}`);
    return 0;
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        throw new Error("Error al cerrar la conexión: " + err.message);
      }
    }
  }
};

const executeOraProcedure = async (data) => {

  let connection, parameters, bindVars;

  if (data.parameters == null || data.parameters == undefined) {
    parameters = ":rc";
    bindVars = {
      rc: { dir: oracledb.BIND_OUT, type: oracledb.CURSOR },
    };
  } else {
    parameters = `:${Object.keys(data.parameters).join(", :")} ,:rc`;
    bindVars = data.parameters;
    bindVars.rc = { dir: oracledb.BIND_OUT, type: oracledb.CURSOR };
  }

  try {
    // db.initPool();
    const pool = db.getPool();
    connection = await pool.getConnection();
   
    let result = await connection.execute(`BEGIN AMEXINSURANCEDIG.${data.nameProcedure}(${parameters}); END;`, bindVars );
    
    const resultSet = result.outBinds.rc;

    let rows = [];
      let row;
      let metaData = resultSet.metaData.map(column => column.name); // Obtener los nombres de las columnas
      while ((row = await resultSet.getRow())) {
        let rowData = {};
        for (let i = 0; i < metaData.length; i++) {
          rowData[metaData[i]] = row[i];
        }
        rows.push(rowData); 
      }
      return rows;


  } catch (error) {
    console.log(error);

    await saveLog(`Error al ejecutar el procedimiento ${data.nameProcedure}`,2,error);

    await notifySMS(`Error al ejecutar el procedimiento ${data.nameProcedure}: ${error}`);

    //!Aqui debo de notificar de los errores en oracle
    return [{RESPONSE:error}];
    
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        throw new Error("Error al cerrar la conexión: " + err.message);
      }
    }
  }
};

export { checkConn, inserLeadsOracle, executeOraProcedure };
