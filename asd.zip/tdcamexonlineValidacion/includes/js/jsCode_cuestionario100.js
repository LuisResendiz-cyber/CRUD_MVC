$(document).ready(function () {
    let inputs = document.querySelectorAll('input[name^="txtQId"]');
    let excludes = ['txtQId1001CId30', 'txtQId1001CId71'];
    let selectsValidacion = Array.from(document.querySelectorAll('select[name^="txtQId1001"]'))
    .filter(select => !excludes.some(exclude => select.name.includes(exclude)));
    let PolizasSencilla = document.getElementsByName('txtQId1001CId49')[0];
    let RazonNoVenta = document.getElementsByName('txtQId1001CId30')[0];
    let CodigoCliente = document.getElementsByName('txtQId1001CId1')[0];
    let ResultadoTramite = document.getElementsByName('txtQId1001CId2')[0];
    let DocumentosSol = document.getElementsByName('txtQId1001CId3')[0];
    let Mensajeria = document.getElementsByName('txtQId1001CId4')[0];
    let OnboardingUno = document.getElementById('onboarding_preg');
    let OnboardingDos = document.getElementById('onboarding_resp');
    let TipoPlan = document.getElementById('TIPO_SEGURO_CROSS');
    let year_actual = new Date().getFullYear();
    
    
/*     //MOSTRAR/OCULTAR PLAN PARA GUARD
    var $selectElement = $('select[name="txtQId1001CId71"]');

    TipoPlan.addEventListener('change', (event) => {
    if(TipoPlan.value == 13 || TipoPlan.value == 15 || TipoPlan.value == 19) {
        $selectElement.show();
        $selectElement.closest('td').prev('td').show(); // Oculta el td anterior
    } else {
        $selectElement.hide();
        $selectElement.closest('td').prev('td').hide(); // Oculta el td anterior
    } 
    }); */

    //OPCIONES DE ONBOARDIONG 2 DEPENDIENDO EL ONBOARDING 1
    OnboardingUno.addEventListener('change', (event) => {
        for (var i = 0; i < OnboardingDos.options.length; i++) {
            OnboardingDos.options[i].style.display = 'none';
        }
        if (OnboardingUno.value == 1) {
            var valuesToHide = ["11", "12", "13", "14", "15"];
        } else if (OnboardingUno.value == 2) {
            var valuesToHide = ["21", "22", "23", "24"];
        } else if (OnboardingUno.value == 3) {
            var valuesToHide = ["31", "32", "33"];
        } else if (OnboardingUno.value == 4) {
            var valuesToHide = ["41", "42", "43", "44"];
        } else if (OnboardingUno.value == 5) {
            var valuesToHide = ["51", "52", "53", "54", "55"];
        } else if (OnboardingUno.value == 6) {
            var valuesToHide = ["61", "62", "63"];
        } else {
            var valuesToHide = ["71", "72"];
        }

        for (var i = 0; i < OnboardingDos.options.length; i++) {
            if (valuesToHide.includes(OnboardingDos.options[i].value)) {
                OnboardingDos.options[i].style.display = 'block';
            }
        }
    });

    function ValidaPlan() {
        let bandera = true;
        if (PolizasSencilla.value == "A" && RazonNoVenta.value == "") {
            swal("Cuidado!", "El campo Razon de no venta seguro es Obligatorio", "warning");
            bandera = false;
        }
        return bandera;
    }

    //OPCIONES DE DOCUMENTOS SOLICITADOS
    ResultadoTramite.addEventListener('change', (event) => {

        for (var i = 0; i < DocumentosSol.options.length; i++) {
            DocumentosSol.options[i].style.display = 'none';
        }

        if (ResultadoTramite.value == 'AU') {
            var valuesToHide = ["D", "D1"];
            Mensajeria.value = 'N';
        } else {
            var valuesToHide = ["2D", "3D"];
            Mensajeria.value = 'S';
        }

        for (var i = 0; i < DocumentosSol.options.length; i++) {
            if (valuesToHide.includes(DocumentosSol.options[i].value)) {
                DocumentosSol.value = "";
                DocumentosSol.options[i].style.display = 'block';
            }
        }
    });

    window.SaveForm = function () {
        document.getElementById("modo").value = "guardar";
        alert('La solicitud que estas guardando es: ' + customer_id);
        document.SurveyResponse.submit();
    };

    //VALIDA SI EXISTE RAZON CANCELACION: 
    $.post("modules.php?mod=agentes&op=process_data&act=OTg=", {
        customer_id,
    }, function (data) {
        let parsedData = JSON.parse(data);
        let rc = document.querySelector('#razon_cancelacion');
        rc.value = parsedData.razon_cancelacion;
    });

    //validaciones SECCION VALIDACION
    function ValidacionCodigoCliente(event) {
        let regex = /^[a-zA-Z0-9]*$/; 
        let anio = CodigoCliente.value.substring(0, 4);
        let Tm = CodigoCliente.value.substring(7, 9);
        let Mxn = CodigoCliente.value.substring(14, 17);

        if (!regex.test(CodigoCliente.value)){
            swal("Cuidado!", "El Código Cliente no puede Contener Caracteres Especiales", "warning");
            return false;
        }else if (CodigoCliente.value.length < 17 || CodigoCliente.value.length > 17) {
            swal("Cuidado!", `El código del cliente debe tener una longitud de 17 caracteres`, "warning");
            return false;
        } else if (anio != year_actual) {
            swal("Cuidado!", "El formato de año en el código ingresado no es correcto", "warning");
            return false;
        } else if (Mxn.toUpperCase() !== 'MXN' || Tm.toUpperCase() !== 'TM') {
            swal("Cuidado!", "El formato del código ingresado no es correcto", "warning");
            return false;
        }
        
        return true;
    }
    

    //PROCESAR SOLICITUD
    window.SubmitForm = function (event) {
        event.preventDefault();
        $.post("modules.php?mod=agentes&op=process_data&act=OTk=", {
            pcn: CodigoCliente.value, customerid: customer_id, id_pruducto: survey_id
        }, function (data) {
            let existePcn = JSON.parse(data);
            if (existePcn[1] == 1) {
                swal("Cuidado!", `El PCN ya existe en base`, "error");
                return false;
            } else {
                swal({
                    title: "Estas Seguro?",
                    text: `La solicitud a validar es: ${customer_id}`,
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Si, PROCESAR!",
                    cancelButtonText: "No, Cancelar!",
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                    function (isConfirm) {
                        if (isConfirm) {
                            if (ResultadoTramite.value == 'AU' && (DocumentosSol.value == 'D' || DocumentosSol.value == 'D1')) {
                                if (ValidaQuestionario(inputs, 'Validacion') && ValidacionCodigoCliente(event) && ValidaPlan()) {

                                    //COLOCAMOS EL PCN Y RESTRAMITE EN SESSIONSTORAGE PARA PODER ENVIARLOS AL FINALIZAR LA VENTA
                                    sessionStorage.setItem("PCN", CodigoCliente.value);
                                    sessionStorage.setItem("rs", ResultadoTramite.value);                                
                                    document.SurveyResponse.submit();
                                }
                            } else if (ValidaQuestionario(inputs, 'Validacion') && ValidaQuestionario(selectsValidacion, 'Validacion') && ValidacionCodigoCliente(event) && ValidaPlan()) {
                                    //COLOCAMOS EL PCN Y RESTRAMITE EN SESSIONSTORAGE PARA PODER ENVIARLOS AL FINALIZAR LA VENTA
                                    sessionStorage.setItem("PCN", CodigoCliente.value);
                                    sessionStorage.setItem("rs", ResultadoTramite.value);
                                    document.SurveyResponse.submit();
                            }
                        } else {
                            Alert("Cancelado", "Revisa Correctamente los datos", "error");
                        }
                    });

            }
        });
    };

    function ValidaQuestionario(elementos, seccion) {
        let allFieldsValid = true;
        elementos.forEach(input => {
            if (input.value.trim() === '') {
                Alert("Cuidado!", `El campo ${input.getAttribute('data-name')} esta vacio en la seccion de ${seccion}`, "warning");
                allFieldsValid = false;
                return;
            }
        });
        return allFieldsValid;
    }

    function Alert(title, msj, type) {
        swal(title, msj, type);
    }
});