<?php
ini_set('display_errors','On');
//Index File
//@uthor Mark

require_once("../includes/includes.inc.php");

echo layout_header();

	echo '<table border="1" id="t1">';
		echo '<tr>';
			echo '<td colspan="2">'.$error.'</td>';
		echo '</tr><tr>';
			echo '<td>Id Usuario:</td><td><input type="text" maxlenght="10" size="10" name="id_user" id="id_user"></td>';
		echo '</tr><tr>';
			echo '<td>Contrase�a:</td><td><input type="password" maxlenght="10" size="10"  name="pass_user" id="pass_user"></td>';
		echo '</tr><tr>';
			echo '<td colspan="2"><input type="button" value="Continuar" onclick="ValidaLogin()"></td>';
		echo '</tr>';
	echo '</table>';
echo layout_footer();

?>

         
          