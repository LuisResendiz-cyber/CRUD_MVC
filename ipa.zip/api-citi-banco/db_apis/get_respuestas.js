const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
//console.log("GET_RESPUESTAS",context);
const baseQuery = "BEGIN " + context.schema + ".PROC_SURVEY_GETQUESTCHOICESCU2(:SurveyId_, :QuestionId_, :Lang, :persona, :mostrar, :Exist, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.SurveyId_ || !context.QuestionId_ || !context.Lang || !context.persona || !context.mostrar || !context.Exist){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.SurveyId_      = context.SurveyId_;
            binds.QuestionId_      = context.QuestionId_;
            binds.Lang      = context.Lang;
            binds.persona      = context.persona;
            binds.mostrar      = context.mostrar;
            binds.Exist      = {val:parseInt(context.Exist), dir:oracledb.BIND_INOUT, type:oracledb.DB_TYPE_NUMBER};
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;