import { Query } from "mysql2/typings/mysql/lib/protocol/sequences/Query";
import pool from "../config/dbMysqlConfig";
import { ILogin } from "../interfaces/ILogin";
import bcrypt from "bcrypt";
import jwt, { SignOptions } from 'jsonwebtoken';
import dotenv from "dotenv";
dotenv.config();

export class AuthModel {
  public async getUser(username: string): Promise<ILogin[]> {
    try {
      const [result] = await pool.query(
        "SELECT ID_USER,NAME,PASS,STATUS FROM BOT_TDCAMEXONLINE.USER_API WHERE STATUS = 1 AND NAME =?",
        [username]
      );
      return result as ILogin[];
    } catch (error) {
      console.log(error);
      return [] as ILogin[];;      
    }
  }


    public async insertUser(username: string,pass:string): Promise<ILogin[]> {
    try {
      const [result] = await pool.query(
        "INSERT INTO BOT_TDCAMEXONLINE.USER_API (NAME, PASS, STATUS) VALUES(?, ?, 1)",
        [username,pass]
      );
      return result as ILogin[];
    } catch (error) {
      console.log(error);
      return [] as ILogin[];;      
    }
  }


}


export class JwtService {
  private readonly secret: string;
  private readonly expiresIn: number;

  constructor() {
    const secret = process.env.JWT_SECRET;
    const expiresIn = process.env.JWT_EXPIRES_IN;

    if (!secret || !expiresIn) {
      throw new Error('JWT_SECRET and JWT_EXPIRES_IN must be defined in the environment variables');
    }

    this.secret = secret;
    // this.expiresIn = expiresIn;
    this.expiresIn = parseInt(expiresIn, 10); // Convertir a número
    if (isNaN(this.expiresIn)) {
      throw new Error('JWT_EXPIRES_IN must be a valid number');
    }
  }
  public generateToken(data: ILogin): string {
    const payload = {
      sub: data.ID_USER,
      username: data.NAME,
      role: data.ROLE || 'user'
    };
    const options: SignOptions = { expiresIn: this.expiresIn };
    return jwt.sign(payload, this.secret, options);
  }
}



export class PasswordService {
  private readonly saltRounds: number;

  constructor(saltRounds: number = 10) {
    this.saltRounds = saltRounds;
  }

  public async hashPassword(password: string): Promise<string> {
    return await bcrypt.hash(password, this.saltRounds);
  }

  public async comparePasswords(
    plainPassword: string,
    hashedPassword: string
  ): Promise<boolean> {
    return await bcrypt.compare(plainPassword, hashedPassword);
  }
}