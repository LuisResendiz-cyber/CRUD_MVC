const customerModel = require("../models/customerModel");
const { sendWhatsAppMessage } = require("../services/whatsappService.js");

const dotenv = require("dotenv");
dotenv.config();

const CustomerController = {
  async sendMessages(req, res) {
    try {
      const users = await customerModel.getCustomers();
      const resultados = [];

      for (const user of users) {
        const numeroCompleto = `${user.lada}${user.numero}`;
        const mensaje = `Hola ${user.nombre}!, en que puedo ayudarte hoy?: 1625`;

        try {
          const response = await sendWhatsAppMessage(numeroCompleto, mensaje);
          resultados.push({
            numero: numeroCompleto,
            status: "enviado",
            response,
          });
        } catch (err) {
          resultados.push({
            numero: numeroCompleto,
            status: "error",
            error: err.response?.data || err.message,
          });
        }
      }

      res.json({
        status: "success",
        message: "Mensajes enviados a todos los usuarios.",
        resultados
      });
    } catch (error) {
      console.error("Error en sendMessages:", error);

      // DEVUELVE EL ERROR AL CLIENTE
      res.status(500).json({
        status: "error",
        message: "Ocurrió un error al enviar los mensajes.",
        error: error.response?.data || error.message,
      });
    }
  },
};

module.exports = CustomerController;
