const customerModel = require("../models/customerModel");
const { sendWhatsAppMessage } = require("../services/whatsappService");

const CONCURRENCY = 15;
const BATCH_SIZE = 100;

async function promisePool(items, handler, concurrency) {
  const executing = new Set();

  for (const item of items) {
    const p = Promise.resolve().then(() => handler(item));
    executing.add(p);

    p.finally(() => executing.delete(p));

    if (executing.size >= concurrency) {
      await Promise.race(executing);
    }
  }

  await Promise.all(executing);
}

const CustomerController = {
  async sendMessages(req, res) {

    res.json({
      status: "processing",
      message: "El envío masivo comenzó en background."
    });

    console.log("=== INICIANDO ENVÍO MASIVO ===");

    setImmediate(async () => {
      try {
        const users = await customerModel.getCustomers();
        console.log(`Usuarios por enviar: ${users.length}`);

        if (!users.length) {
          console.log("No hay registros activos.");
          return;
        }

        const logsBatch = [];
        const idsToDeactivate = [];

        await promisePool(
          users,
          async user => {
            const numero = `${user.lada}${user.numero}`;
            const mensaje = `Hola ${user.nombre}! ¿En qué puedo ayudarte hoy?`;

            try {
              const resp = await sendWhatsAppMessage(numero, mensaje);
              console.log(`[OK] ${numero}`);

              logsBatch.push({
                id_envio: user.id,
                status_id: 1,
                errorApi: JSON.stringify(resp)
              });

            } catch (err) {
              console.log(`[ERR] ${numero} -> ${err.response?.status || err.message}`);

              logsBatch.push({
                id_envio: user.id,
                status_id: 2,
                errorApi: JSON.stringify(err.response?.data || err.message)
              });
            }

            idsToDeactivate.push(user.id);

            if (logsBatch.length >= BATCH_SIZE) {
              console.log("Guardando logs batch... count:", logsBatch.length);
              await customerModel.saveLogsBatch(logsBatch.splice(0));
            }

            if (idsToDeactivate.length >= BATCH_SIZE) {
              console.log("Desactivando IDs batch... count:", idsToDeactivate.length);
              await customerModel.setTryBatch(idsToDeactivate.splice(0));
            }
          },
          CONCURRENCY
        );

        // En este punto promisePool ya esperó a que todas las tareas TERMINARAN
        console.log("promisePool completado. logsBatch remaining:", logsBatch.length, "idsToDeactivate remaining:", idsToDeactivate.length);

        if (logsBatch.length) {
          console.log("Guardando logs restantes... count:", logsBatch.length);
          await customerModel.saveLogsBatch(logsBatch);
        }

        if (idsToDeactivate.length) {
          console.log("Desactivando IDs restantes... count:", idsToDeactivate.length);
          await customerModel.setTryBatch(idsToDeactivate);
        }

        console.log("=== ENVÍO MASIVO FINALIZADO ===");

      } catch (error) {
        console.error("Error en procesamiento background:", error);
      }
    });
  }
};

module.exports = CustomerController;
