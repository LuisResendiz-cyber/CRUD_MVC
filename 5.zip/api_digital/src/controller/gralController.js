import * as oraModel from "../model/oracleModel.js";
import axios from "axios";
import { getLog } from "./mysqlController.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicFolderPath = path.join( __dirname, "..", "..", "..", "cron_carga_digital/src/public/tempLeads");
const publicFolderBackPath = path.join( __dirname, "..", "..", "..", "cron_carga_digital/src/public/backLeads");


export const checkConnOra = async () => {
  const rspta = await oraModel.checkConn();
  return rspta;
};

export const checkConnOra2 = async (req,res) => {
  const rspta = await oraModel.checkConn();
  res.json(rspta);
};

export const hiWord = (req, res) => {
  res.render("index");
};

export const listLocalCsv = (req, res) => {
  res.render("localCsvList");
};

export const executionLog = async (req, res) => {
  const rspta = await getLog();
  console.log(rspta);
  res.render("logProcessDig",{ logs: rspta });
};

export const notifySMS = async (content) => {
  const emails = [
    "lhernandez@impulse-telecom.com",
    "dsa@impulse-telecom.com",
    "dbecerra@impulse-telecom.com"
    // "vovere9293@eluxeer.com",
  ];

  for (const email of emails) {
    try {
      const response = await axios.get(
        "https://172.20.1.97:3009/api-serv/sendMail",
        {
          headers: {
            "Content-Type": "application/json",
          },
          data: {
            subject: "Error en carga automatica digital",
            content: `<h5> ${JSON.stringify(content, null, 2)} </h5>`,
            email: email,
          },
        }
      );
      console.log(response.data);
    } catch (error) {
      console.log("Error en la solicitud:", error);
    }
  }
};


export const getListCsv = async (req, res) => {
  // const {typeFolder} = req
  const typeFolder = 1

  const folder= typeFolder ==1 ? publicFolderPath: publicFolderBackPath
  try {
    const files = fs.readdirSync(folder)

    if (files.length === 0) return res.status(300).json(['SIN DATOS']);  

    // const routefiles = files.map(file=>`${folder}/${file}`)

    res.status(200).json(files)
  } catch (error) {
    console.log(error);
    res.status(500).json('test')
  }

  
};

