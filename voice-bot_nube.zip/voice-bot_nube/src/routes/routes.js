const express = require('express');
const router = express.Router();

const appController = require('../controllers/ServicesController') 

router.get('/stt', appController.stt)

module.exports = router;