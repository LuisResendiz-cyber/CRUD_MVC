const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".CSP_VERIFYUSER_BASE(:s_usr_id, :rc); END;";
//console.log(baseQuery);
//console.log(context.s_usr_id);

	let query = baseQuery;
	const binds = {};
        

            binds.s_usr_id     = context.s_usr_id;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

            //console.log(result);	

            return result;           
}
 
module.exports.find = find;
