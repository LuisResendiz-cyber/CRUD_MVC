import * as Yup from "yup";
import { AnySchema } from "yup";

export const ValSignIn = Yup.object().shape({
  USERNAME: Yup.string()
    .required("username is required")
    .min(6, "username must contain 6 characters"),
  PASSWORD: Yup.string()
    .required("password is required")
    .min(8, "password must contain 8 characters"),
});

export const ValUpdateSurvey = Yup.object().shape({
  ID_SURVEY: Yup.string().required("ID_SURVEY is required"),
  STATUS_SURVEY: Yup.number().required("password is required").integer(),
});

export const ValUpdateDataCustomer = Yup.object().shape({
  page: Yup.number().required("page is required"),
  limit: Yup.number().required("limit is required").integer(),
});

export const validate =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate(req.body, { abortEarly: false });
      next();
    } catch (err: any) {
      res.status(400).json({ errors: err.errors });
    }
  };

export const validateSurvey =
  (schema: AnySchema) => async (req: any, res: any, next: any) => {
    try {
      await schema.validate({
        params: req.params,
        body: req.body,
      });

      next();
    } catch (err: any) {
      return res.status(400).json({ type: err.name, message: err.message });
    }
  };

export const ValSurvey = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .matches(/^[0-9]+$/, "The CUSTOMERID must be a numeric value.")
      .max(100),
    ID_PHONE: Yup.string()
      .required("The ID_PHONE field is required.")
      .matches(/^[0-9]+$/, "The ID_PHONE must be a numeric value.")
      .max(20),

    TYPIFICATIONID: Yup.string()
      .required("The TYPIFICATIONID field is required.")
      .matches(/^[0-9]+$/, "The TYPIFICATIONID must be a numeric value.")
      .max(100),

    CAMPAIGN: Yup.string().required("The CAMPAIGN field is required.").max(100),

    // STATUS_FROM_TMK: Yup.string()
    //   .required("The STATUS_FROM_TMK field is required.")
    //   .min(0)
    //   .max(100),

    // PRODUCT: Yup.string().required("The PRODUCT field is required.").max(100),

    // TDC: Yup.string().required("The TDC field is required.").max(100),
    // LINE_CREDIT: Yup.string()
    //   .required("The LINE_CREDIT field is required.")
    //   .max(100),

    // BASE_FOLIO: Yup.string()
    //   .required("The BASE_FOLIO field is required.")
    //   .max(100),
    // BIRTH_DATE: Yup.string()
    //   .required("The BIRTH_DATE field is required.")
    //   .matches(
    //     /^\d{2}\/\d{2}\/\d{4}$/,
    //     "The BIRTH_DATE format must be DD/MM/YYYY"
    //   ),

    // HOLDER_LAST_NAME_FATHER: Yup.string()
    //   .required("The HOLDER_LAST_NAME_FATHER field is required.")
    //   .max(100),

    // HOLDER_LAST_NAME_MOTHER: Yup.string()
    //   .required("The HOLDER_LAST_NAME_MOTHER field is required.")
    //   .max(100),

    // HOLDER_NAME: Yup.string()
    //   .required("The HOLDER_NAME field is required.")
    //   .max(100),

    // RFC: Yup.string().required("The RFC field is required.").max(100),

    // HOMOCLAVE: Yup.string()
    //   .required("The HOMOCLAVE field is required.")
    //   .length(6, "The HOMOCLAVE must be 6 characters long.")
    //   .max(100),

    // CURP: Yup.string()
    //   .required("The CURP field is required.")
    //   .matches(/^[A-Z]{4}\d{6}[A-Z]{6}\d{2}$/, "The CURP format is invalid."),

    // COMMENTS: Yup.string().optional().max(100),

    STREET: Yup.string().required("The STREET field is required.").max(100),

    EXTERIOR_NUMBER: Yup.string()
      .required("The EXTERIOR_NUMBER field is required.")
      .max(100),
    INTERIOR_NUMBER: Yup.string().optional().max(100),

    POSTAL_CODE: Yup.string()
      .max(100)
      .required("The POSTAL_CODE field is required."),

    COLONY: Yup.string().required("The COLONY field is required.").max(100),

    STATE: Yup.string().required("The STATE field is required.").max(100),

    // REFERENCE_MUNICIPALITY: Yup.string()
    //   .required("The REFERENCE_MUNICIPALITY field is required.")
    //   .max(100),

    MUNICIPALITY: Yup.string()
      .required("The MUNICIPALITY field is required.")
      .max(100),

    // CELL_PHONE: Yup.string()
    //   .required("The CELL_PHONE field is required.")
    //   .length(10, "The CELL_PHONE must be 10 characters long.")
    //   .max(100),

    // PHONE: Yup.string().required("The PHONE field is required.").max(10),

    // CONTACT_PHONE: Yup.string()
    //   .required("The CONTACT_PHONE field is required.")
    //   .max(10),

    // COUNTRY_BIRTH: Yup.string()
    //   .required("The COUNTRY_BIRTH field is required.")
    //   .max(100),

    // FEDERAL_ENTITY: Yup.string()
    //   .required("The FEDERAL_ENTITY field is required.")
    //   .max(100),

    // // EMAIL: Yup.string()
    // //   .required("The EMAIL field is required.")
    // //   .email("The EMAIL format is invalid.")
    // //   .max(100),

    // MONTHLY_INCOME: Yup.string()
    //   .required("The MONTHLY_INCOME field is required.")
    //   .max(100),

    // INCOME_RECEIPT_TYPE: Yup.string()
    //   .required("The INCOME_RECEIPT_TYPE field is required.")
    //   .max(100),

    // IDENTIFICATION_TYPE: Yup.string()
    //   .required("The IDENTIFICATION_TYPE field is required.")
    //   .max(100),

    // ADDRESS_RECEIPT_TYPE: Yup.string().required(
    //   "The ADDRESS_RECEIPT_TYPE field is required."
    // ),
    // NUMBER_REFERENCES: Yup.string().required(
    //   "The NUMBER_REFERENCES field is required."
    // ),
    // CREDIT_REFERENCE_1: Yup.string().required(
    //   "The CREDIT_REFERENCE_1 field is required."
    // ),
    // LAST_4_DIGITS_CARD_1: Yup.string()
    //   .required("The LAST_4_DIGITS_CARD_1 field is required.")
    //   .min(4, "The LAST_4_DIGITS_CARD_1 must be a 4-digit number.")
    //   .max(10, "The LAST_4_DIGITS_CARD_1 must be a 4-digit number."),
    // CREDIT_REFERENCE_2: Yup.string().required(
    //   "The CREDIT_REFERENCE_2 field is required."
    // ),
    // LAST_4_DIGITS_CARD_2: Yup.string()
    //   .required("The LAST_4_DIGITS_CARD_2 field is required.")
    //   .min(4, "The LAST_4_DIGITS_CARD_2 must be a 4-digit number.")
    //   .max(10, "The LAST_4_DIGITS_CARD_2 must be a 4-digit number."),

    // CREDIT_REFERENCE_3: Yup.string().required(
    //   "The CREDIT_REFERENCE_3 field is required."
    // ),
    // LAST_4_DIGITS_CARD_3: Yup.string()
    //   .required("The LAST_4_DIGITS_CARD_3 field is required.")
    //   .min(4, "The LAST_4_DIGITS_CARD_3 must be a 4-digit number.")
    //   .max(10, "The LAST_4_DIGITS_CARD_3 must be a 4-digit number."),

    // PERSONAL_LAST_NAME_FATHER: Yup.string()
    //   .required("The PERSONAL_LAST_NAME_FATHER field is required.")
    //   .max(100),

    // PERSONAL_LAST_NAME_MOTHER: Yup.string()
    //   .required("The PERSONAL_LAST_NAME_MOTHER field is required.")
    //   .max(100),
    // PERSONAL_NAME: Yup.string()
    //   .required("The PERSONAL_NAME field is required.")
    //   .max(100),

    // PERSONAL_RELATIONSHIP: Yup.string().required(
    //   "The PERSONAL_RELATIONSHIP field is required."
    // ),
    // PERSONAL_PHONE: Yup.string().required(
    //   "The PERSONAL_PHONE field is required."
    // ),
    // PERSONAL_EXTENSION: Yup.string().required(
    //   "The PERSONAL_EXTENSION field is required."
    // ),

    // BRANCH_VISIT_DATE: Yup.string()
    //   .required("The BRANCH_VISIT_DATE field is required.")
    //   .matches(
    //     /^\d{2}\/\d{2}\/\d{4}$/,
    //     "The BRANCH_VISIT_DATE format must be DD/MM/YYYY"
    //   ),
  }),
});

export const ValSurveyNoSale = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .matches(/^[0-9]+$/, "The CUSTOMERID must be a numeric value.")
      .max(100),
    ID_PHONE: Yup.string()
      .required("The ID_PHONE field is required.")
      .matches(/^[0-9]+$/, "The ID_PHONE must be a numeric value.")
      .max(20),
    TYPIFICATIONID: Yup.string()
      .required("The TYPIFICATIONID field is required.")
      .matches(/^[0-9]+$/, "The TYPIFICATIONID must be a numeric value.")
      .max(100),
  }),
});

export const ValCustomerInformation = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
  body: Yup.object().shape({
    CUSTOMERID: Yup.string()
      .required("The CUSTOMERID field is required.")
      .matches(/^[0-9]+$/, "The CUSTOMERID must be a numeric value.")
      .max(100),
  }),
});

export const ValCustomerSpecificInformation = Yup.object({
  params: Yup.object({
    user_id: Yup.number().required().typeError("user_id must be a number"),
  }),
});
