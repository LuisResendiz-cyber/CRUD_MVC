const pool = require("../config/dbConfig");

const myslqAccions = {
  checkConn: async () => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query("SELECT 1");

      return rows;
    } catch (error) {
      throw new Error("Database connection error: " + error.message);
    } finally {
      // Liberar la conexión al pool
      if (connection) connection.release();
    }
  },
  getToken: async () => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query("SELECT * FROM TOKEN_KEY WHERE STATUS_KEY = 1");

      return rows;
    } catch (error) {
      throw new Error("Database connection error: " + error.message);
    } finally {
      // Liberar la conexión al pool
      if (connection) connection.release();
    }
  },
  addUser: async (userId, password) => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `SELECT COUNT(*) EXISTE FROM USER_API where NAME = ?`,
        [userId]
      );

      if (rows[0].EXISTE != 0) {
        return false;
      } else {
        const [result] = await connection.query(
          "INSERT INTO USER_API (NAME, PASS) VALUES (?, ?)",
          [userId, password]
        );
        if (result.affectedRows == 0) {
          return false;
        } else {
          return true;
        }
      }
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  getUser: async (userId) => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `SELECT NAME,PASS FROM USER_API where NAME = ?`,
        [userId]
      );

      if (rows.length === 0) {
        return [];
      }
      return rows[0];
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  addWebook: async (userId, link) => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `SELECT COUNT(*) EXISTE FROM WEBHOOK where UPPER(ID_USER) = UPPER(?) AND UPPER(LINK) = UPPER(?)`,
        [userId, link]
      );
      if (rows[0].EXISTE != 0) {
        return false;
      } else {
        const [result] = await connection.query(
          "INSERT INTO WEBHOOK (ID_USER, LINK) VALUES(?, ?);",
          [userId, link]
        );
        if (result.affectedRows == 0) {
          return false;
        } else {
          return true;
        }
      }
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  dataIdmissionInsert: async (data) => {
    let connection;
    try {
      connection = await pool.getConnection();

      const query = `
      INSERT INTO DATA_IDMISSION (
        PCN, AGENCY, CHANNEL, SUB_CHANNEL, PRODUCT, 
        DATE_ASIGNED, DATE_LINK_SENT, NUMBER_LINK_REVENUES, 
        DATE_LAST_REPORT, DATE_LAST_IDMISSION_DECISION, 
        DATE_LAST_AGENCY_DECISION, DATE_LAST_AMEX_DECISION, 
        DOCUMENTATION_STATUS, INSURANCE, CHECKBOX_PUBLICITY, 
        NATIONALITY, DEVICE, BROWSER, DECISION_DATE, DEC_, 
        COD_DEC, RESPONSE_CODE, CUSTOMER_TYPE, NUMBER_REJECTIONS
      ) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

      const values = [
        data.PCN,
        data.AGENCY,
        data.CHANNEL,
        data.SUB_CHANNEL,
        data.PRODUCT,
        data.DATE_ASIGNED,
        data.DATE_LINK_SENT,
        data.NUMBER_LINK_REVENUES,
        data.DATE_LAST_REPORT,
        data.DATE_LAST_IDMISSION_DECISION,
        data.DATE_LAST_AGENCY_DECISION,
        data.DATE_LAST_AMEX_DECISION,
        data.DOCUMENTATION_STATUS,
        data.INSURANCE,
        data.CHECKBOX_PUBLICITY,
        data.NATIONALITY,
        data.DEVICE,
        data.BROWSER,
        data.DECISION_DATE,
        data.DEC,
        data.COD_DEC,
        data.RESPONSE_CODE,
        data.CUSTOMER_TYPE,
        data.NUMBER_REJECTIONS,
      ];

      const [result] = await connection.query(query, values);
      if (result.affectedRows == 0) {
        await connection.rollback();
        return false;
      }
      await connection.commit();
      return true;
    } catch (error) {
      if (connection) await connection.rollback();
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  getWebhook: async (userId) => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `SELECT LINK FROM WEBHOOK WHERE STATUS = 1 AND ID_USER = ?`,
        [userId]
      );

      if (rows.length === 0) {
        return [];
      }
      return rows;
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  getData: async () => {
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `SELECT * 
        FROM DATA_IDMISSION 
        WHERE STATUS_FIELD = 1
        LIMIT 100`
      );

      if (rows.length === 0) {
        return [];
      }
      return rows;
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
  updateData: async (STATUS_FIELD,data) => {
    // console.log('--->',data)
    let connection;
    try {
      connection = await pool.getConnection();

      const [rows] = await connection.query(
        `UPDATE DATA_IDMISSION SET STATUS_FIELD = ? WHERE ID_DATA IN (?)`,[STATUS_FIELD,data]
      );

      if (rows.affectedRows == 0) {
        await connection.rollback();
        return false;
      }
      await connection.commit();
      return true;
    } catch (error) {
      console.log(error);
      return 0;
    } finally {
      if (connection) connection.release();
    }
  },
};

module.exports = myslqAccions;
 