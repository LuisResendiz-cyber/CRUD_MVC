import fs from "fs";
import path from "path";

export function cargarKB() {
  const ruta = path.resolve("seguros.md");
  return fs.readFileSync(ruta, "utf8");
}
