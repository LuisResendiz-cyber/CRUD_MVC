const { GoogleGenerativeAI } = require("@google/generative-ai");
require("dotenv").config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "AIzaSyDzs8ppJlRAUzj_g1bPafcDfKO3O51w_6M");

const generate = async ({
  systemPrompt,
  userMessage,
  temperature = 0.7,
  maxTokens = 1000,
  topP = 1,
  frequencyPenalty = 0,
  presencePenalty = 0,
  
}) => {

    try {

  const geminiModel = genAI.getGenerativeModel({
    model: "gemini-2.5-flash-lite"
  });

  const result = await geminiModel.generateContent({
    contents: [
      {
        role: "user",
        parts: [{ text: userMessage }]
      }
    ],
    systemInstruction: {
      parts: [{ text: systemPrompt }]
    },
    generationConfig: {
      temperature,
      maxOutputTokens: maxTokens,
      topP
    }
  });

  const response = await result.response;

  return response.text();
} catch (error) {

    console.error("❌ Error Gemini:", {
      message: error.message,
      status: error?.response?.status,
      details: error?.response?.data
    });

    
    return "Lo siento, en este momento tengo dificultades técnicas. Por favor intenta nuevamente en unos segundos.";
  }
};

module.exports = { generate };
