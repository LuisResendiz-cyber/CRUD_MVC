const axios = require("axios");
const https = require("https");
const { oraExcQuery, oraExcInsert } = require("../model/model-oracle");

const actions = {
  asistencia: async (req, res) => {
    try {
      const campaign = 1;
      const query = `INSERT INTO ASISTENCIA.REGISTROEXTEMP (CLAVE, HORA, FECHA, EQUIPO) 
                     VALUES(:clave, :hora, TO_DATE(:fecha, 'DD/MM/YYYY'), :equipo)`;

      const assistanceData = await getAssistance();

      // console.log(typeof(assistanceData.data.success))

      if (assistanceData.data.success == false) {
        res.status(200).json({
          status: "Success",
          details: "No se encontraron asistencias para insertar",
        });        
        return
      }     
      // console.log(assistanceData)
      // return

      const insertResults = [];

      for (const element of assistanceData.data) {
        const binds = {
          clave: element.NOMINA,
          hora: element.HORA,
          fecha: element.FECHA,
          equipo: element.EQUIPO,
        };
        await oraExcInsert(campaign, query, binds);
        insertResults.push(element.ID_ASSISTENCIA);
      }
      
      // console.log(insertResults)
      const up = await updateAssistance(insertResults)
      console.log(up)

      res.status(200).json({
        status: "Success",
        details: "Asistencias insertadas correctamente",
        // details_2: up.data.data,
        insertedCount: insertResults.length,        
      });
    } catch (error) {
      console.error("Error en el proceso de asistencia:", error);
      res.status(500).json({
        status: "Error",
        details: "Ocurrio un error al procesar las asistencias",
        error: error.message,
      });
    }
  },
};

const getAssistance = async () => {
  const agent = new https.Agent({
    rejectUnauthorized: false,
    keepAlive: true,
    timeout: 10000,
  });
  const config = {
    httpsAgent: agent,
    timeout: 15000,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  };
  // const url = "https://172.20.1.149:9080/gitDani/checador_web/assistance.php";
  const url = "https://tocimpulse.com/checador_web/assistance.php";
  const data = { key: "1" };
  try {
    const response = await axios.post(url, data, config);
    if (!response.data) {
      throw new Error("La respuesta del servicio no contiene datos");
    }

    return response.data;
  } catch (error) {
    console.error("Error al obtener datos de asistencia:", error);
    throw new Error(`Error en getAssistance: ${error.message}`);
  }
};
const updateAssistance = async (ids) => {  
  const agent = new https.Agent({
    rejectUnauthorized: false,
    keepAlive: true,
    timeout: 10000,
  });
  const config = {
    httpsAgent: agent,
    timeout: 15000,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  };
  // const url = "http://172.20.1.149/gitDani/checador_web/upAssistence.php";
  const url = "https://tocimpulse.com/checador_web/upAssistence.php";
  const data = { key: "1",ids };
  try {
    const response = await axios.post(url, data, config);
    if (!response.data) {
      throw new Error("La respuesta del servicio no contiene datos");
    }

    return response.data;
  } catch (error) {
    console.error("Error al obtener datos de asistencia:", error);
    throw new Error(`Error en getAssistance: ${error.message}`);
  }
};

module.exports = actions;
