const express = require('express');
const router = express.Router();
const webchatController = require("../controllers/webchat.controller");


router.post("/webchat", webchatController.receiveMessage);

module.exports = router;