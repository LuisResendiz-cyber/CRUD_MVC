<?php
date_default_timezone_set('America/Mexico_City');


require_once("adodb.inc.php");
require_once('adodb-exceptions.inc.php');
//require_once('adodb-pager.inc.php');
//require_once("tohtml.inc.php");
//require_once("vars.php");

$db = newADOConnection("oci8");
if (isset($_GET['debug']) && $_GET['debug'] == 1) {
    $db->debug = true;
} else {
    $db->debug = false;
}

    //Desarrollo
     
    // $server = '(DESCRIPTION =
    //            (ADDRESS =
    //              (PROTOCOL = TCP)
    //              (HOST = 172.20.1.116)
    //              (PORT = 1521)
    //             )
    //         (CONNECT_DATA =
    //              (SERVICE_NAME = XE)
    //          )
    //       )';
     
    
    // P-R-O-D-U-C-I-O-N
    $server = '(DESCRIPTION =
    (LOAD_BALANCE = ON)
    (ADDRESS_LIST =
        (ADDRESS =
            (PROTOCOL = TCP)
            (HOST = 192.168.1.13)
            (PORT = 1521)
        )
        (ADDRESS =
            (PROTOCOL = TCP)
            (HOST = 192.168.1.14)
            (PORT = 1521)
        )
    )
    (CONNECT_DATA =
        (SERVICE_NAME = xccmtaf)
    )
    )';

try {
    $db->charSet = 'utf8';
    $db->Connect($server, 'amexinsurancedig', 'af05bedccdc');

    // echo 'conectado';

    
} catch (Exception $e) {
    die($e->getMessage());
}

$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
