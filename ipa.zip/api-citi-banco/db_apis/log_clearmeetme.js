const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN " + context.schema + ".INSERTAR_LOG_CLEARMEETME(:agente, :descripcion, :origen); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.agente || !context.descripcion || !context.origen){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.agente     = context.agente;
            binds.descripcion      = context.descripcion;
            binds.origen      = context.origen;            
            const result = await database.simpleExecute(query, binds);

            console.log(result);

            return result;
        }
}

module.exports.find = find;
