<?php
# @uthor Mark 
# Agenda File 

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Agendar Registro");

set_session_varname("url_contacto", "agenda");

$id_solicitud = get_session_varname("id_solicitud");
$id_usr = get_session_varname("s_usr_id");
$datos_cliente = get_session_varname("datos_persona");
$isPredictivo2 = get_session_varname("s_usr_marcacion");

/*
 * Obtener el u_telefono de acuerdo al registro y al tel?fono contactado
 */
$telefono = get_session_varname("s_telefono");
$id_telefono = get_id_telefono($id_solicitud, $telefono, $db); 
set_session_varname('s_u_telefono', $id_telefono);

layout_menu($db, "verAgenda('cmdAgenda', '" . date('d/m/Y') . "', 'agenda',0);");
?>
<p class="textbold">Agentes &gt; Agendar Registro</p>
<p>&nbsp;</p>
<form method="post" action="modules.php?mod=agentes" name="frm1">
    <input type="hidden" name="estatus_reg" id="estatus_reg" value="<?php echo $agenda ?>">
    <table class="cuestionario" width="1200px">
        <tr>
            <td colspan="3">&nbsp;</td>
        </tr> 
        
        <tr>
            <td colspan="3" class="label_td">Capture la siguiente informaci&oacute;n para el registro seleccionado.</td>
        </tr>
        <tr>
            <td colspan="2"></td>
            <td rowspan="9">
                <div align="center">
                    <label for="fecha_agenda">Fecha:</label>
                    <input type="text" name="fecha_agenda" id="fecha_agenda" size="10" maxlength="10" class="tcal" value="<?php echo date('d/m/Y'); ?>" />
                    <input type="button" value="Ver agenda" name="cmdAgenda" id="cmdAgenda" onclick="this.disabled = true; verAgenda(this, frm1.fecha_agenda.value, 'agenda',0);" />
                </div>
                <div id="agenda" align="center" class="script2"></div>
            </td>
        </tr>
        <tr>
            <td class="textleft"><b>Nombre cliente:&nbsp;</b></td>
            <td class="label"><?= $datos_cliente[0]['NOMBRE'] . '&nbsp;' . $datos_cliente[0]['APATERNO'] . '&nbsp;' . $datos_cliente[0]['AMATERNO'] ?></td>
        </tr>
        <tr>
            <td class="textleft"><b># Solicitud:&nbsp;</b></td>
            <td class="label"><?= $id_solicitud ?></td>
        </tr>
        <tr>
            <td class="textleft" colspan="2"><b>Comentarios:&nbsp;</b></td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea name="comentarios" rows="5" cols="70" onKeyDown="limita_texto(this.form.comentarios, this.form.contador_car, 500);" onKeyUp="limita_texto(this.form.comentarios, this.form.contador_car, 500);"><?= $registro->fields["COMENTARIOS"] ?></textarea>
                <br />
                M�ximo <input readonly type="text" name="contador_car" value="500" class="leftchar"> caracteres.
            </td>
        <tr>
            <td colspan="2" align="center">
                <input type="button" class="custionario_boton" value="Cancelar" onclick="this.disabled = true; Atras()"/>&nbsp;&nbsp;
            </td>
        </tr>
    </table>
    <input type="hidden" name="hora" id="hora">
</form>
<?
//}
layout_footer();
