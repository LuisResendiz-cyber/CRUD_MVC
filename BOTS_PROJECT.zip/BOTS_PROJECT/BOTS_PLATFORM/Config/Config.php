<?php
	define("BASE_URL", "http://localhost:8080/");

	define("API_NODE_URL", "http://bots_api_node:4001/");
	define("USE_API", true);  // Cambiar a false para conectar directo a BD
	define("API_TIMEOUT", 30);
	
	date_default_timezone_set('America/Mexico_City');

	//Datos de conexión a Base de Datos
	const DB_HOST = "172.20.1.149";
	const DB_NAME = "tienda";
	const DB_USER = "lresendiz";
	const DB_PASSWORD = "R3s3nd1z*";
	const DB_CHARSET = "utf8";

	//Deliminadores decimal y millar Ej. 24,1989.00
	const SPD = ".";
	const SPM = ",";

	//Simbolo de moneda
	const SMONEY = "Q";

	//Datos envio de correo
	const NOMBRE_REMITENTE = "Impulse Bots";
	const EMAIL_REMITENTE = "no-reply@abelosh.com";
	const NOMBRE_EMPESA = "Impulse Bots";
	const WEB_EMPRESA = "www.abelosh.com";


	// NUEVO: CORS para desarrollo
	define("ALLOWED_ORIGINS", [
	    "http://localhost:3000",    // React/Vue
	    "http://localhost:8080",    // Tu PHP MVC
	    "http://localhost:4001"     // Tu Node.js API
	]);

 ?>