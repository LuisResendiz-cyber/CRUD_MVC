const regExpTexto = /^([A-Z a-z]){1,}$/g;
const regExpNumeros = /^([0-9])$/g;
const regExpFecha = /^(?:(?:(?:0?[1-9]|1\d|2[0-8])[/-](?:0?[1-9]|1[0-2])|(?:29|30)[/-](?:0?[13-9]|1[0-2])|31[/](?:0?[13578]|1[02]))[/-](?:0{2,3}[1-9]|0{1,2}[1-9]\d|0?[1-9]\d{2}|[1-9]\d{3})|29[/-]0?2[/-](?:\d{1,2}(?:0[48]|[2468][048]|[13579][26])|(?:0?[48]|[13579][26]|[2468][048])00))$/;
const regExpFecha1 = /^([0-2][0-9]|3[0-1])(\/|-)(0[1-9]|1[0-2])\2(\d{4})$/;

var rand_pregunta = 0;
$(document).ready(function (){ 
    f5($(document), true);
    $("#nota_agenda").click(function (){
        $("#panel_notaagneda").slideToggle("slow");
    });
    //deshabilitar el select para validación de mensajeria
    //$('select[name=txtQId17CId2]').attr('disabled', true);
    // cambiar id fel primer botón de consulta CP
    $('input[name=CPBUTTON]:first').attr('id', 'CP1');

    // método para la pregunta aleatoria
    rand_pregunta = $('#input_rand').val();
    $('#td_'+rand_pregunta).show();

    //forzar la tarjeta en solicitud
    let prod = $('#survey_id').val();
    //Cuestionario 1
    var existen_datos_bancarios = $('select[name=txtQId'+prod+'4CId1]').length;
    if(existen_datos_bancarios > 0){
        var tdd = $('#tdd').val();
        var tdc = $('#tdc').val();

        $('select[name=txtQId'+prod+'4CId1]').parent().css({'display':'flex'}).append(`
            <div style="padding-left:7rem;">
                <table>
                    <tbody>
                        <tr>
                            <td style="padding:2px 1.5rem;letter-spacing:.15em;color:#3E4551;">TDC: ${tdc}</td>
                            <td style="padding:2px 1.5rem;letter-spacing:.15em;color:#3E4551;">TDD: ${tdd}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        `);

        $('select[name=txtQId'+prod+'4CId1] option').each(function(){
            let id = $(this).text().toLowerCase();
            let plastico = $('#'+id).val();
            $(this).attr('data-plastico', plastico);
        });
        $('#ultimostarjeta').attr('readonly', true);
    }

    // Beneficiarios
    const array_leyendas = []; //= [29,43,57];
    const array_cuerpo = []; //= [30,44,58];
    // Asegurados
    const array_leyendasAseg = [];
    const array_cuerpoAseg = []; //= [30,44,58];
    var regExpBen = /(BENEFICIARIO)/g;
    var regExpAseg = /(ASEGURADO)/g;
    $('#cuestionario table tr').each(function(index){
        var titulo = $(this).text();

        var tituloBen = titulo.substring(0,12);
        var tituloAseg = titulo.substring(0,9);

        if(regExpBen.test(tituloBen)){
            array_leyendas.push(index);
            array_cuerpo.push((index+1));
        }
        if(regExpAseg.test(tituloAseg)){
            array_leyendasAseg.push(index);
            array_cuerpoAseg.push((index+1));
        }
    });

    //console.log(array_leyendas, array_cuerpo);

    //Cuestionario 2
    // var existen_datos_bancarios_c2 = $('select[name=txtQId24CId1]').length;
    // if(existen_datos_bancarios_c2 > 0){
    //     var tdd = $('#tdd').val();
    //     var tdc = $('#tdc').val();

    //     $('select[name=txtQId24CId1]').parent().css({'display':'flex'}).append(`
    //         <div style="padding-left: 7rem;">
    //             <table>
    //                 <tbody>
    //                     <tr>
    //                         <td style="padding:2px 1.5rem;letter-spacing:.15em;color:#3E4551;">TDC: ${tdc}</td>
    //                         <td style="padding:2px 1.5rem;letter-spacing:.15em;color:#3E4551;">TDD: ${tdd}</td>
    //                     </tr>
    //                 </tbody>
    //             </table>
    //         </div>
    //     `);
    // }

    // agregar clase a los bloques de beneficiarios
    let title_cust = $('#cuestionario .title_cuestionario').text();
    if(title_cust.indexOf('1.') > 0 || title_cust.indexOf('2.') > 0 ){
      for(var i=0; i<array_leyendas.length; i++){
          $('#cuestionario tbody tr:eq('+array_leyendas[i]+')').attr('class', 'bloque_beneficiarios');
          $('#cuestionario tbody tr:eq('+array_cuerpo[i]+')').attr('class', 'bloque_beneficiarios beneficiario'+(i+1));
      }

      for(var i=0; i<array_leyendasAseg.length; i++){
          $('#cuestionario tbody tr:eq('+array_leyendasAseg[i]+')').attr('class', 'bloque_asegurados');
          $('#cuestionario tbody tr:eq('+array_cuerpoAseg[i]+')').attr('class', 'bloque_asegurados asegurado'+(i+1));
      }
    }

    // obtener tipo form
    var tipo_form = parseInt($('#tipo_formulario').val());
    if(tipo_form == 0){
        oculta_beneficiarios();
    } else{
        var num_beneficiarios_seleccionados = parseInt($('#num_beneficiarios').val());
        var num_asegurados_seleccionados = parseInt($('#num_asegurados').val());
        muestra_beneficiarios_seleccionados(num_beneficiarios_seleccionados, array_leyendas, array_cuerpo);
        muestra_asegurados_seleccionados(num_asegurados_seleccionados, array_leyendasAseg, array_cuerpoAseg);

        // var id_cp = 'CP1';
        // obtener_demograficos(id_cp);
    }

    // método para mostrar bloques de beneficiarios
    var array_campos = ['ocupacion', 'cargo', 'actividad'];
    $('#num_beneficiarios').change(function(){
        var num_beneficiarios = $(this).val();

        if(num_beneficiarios != ''){
            $('.bloque_beneficiarios').hide();
            for(var i=0; i<num_beneficiarios; i++){
                $('#cuestionario tbody tr:eq('+array_leyendas[i]+')').show();
                $('#cuestionario tbody tr:eq('+array_cuerpo[i]+')').show();
            }
            limpiarFormBeneficiarios(num_beneficiarios);
        } else{
            $('.bloque_beneficiarios').hide();
        }
    });

    $('#num_asegurados').change(function(){
        var num_asegurados = $(this).val();

        if(num_asegurados != ''){
            $('.bloque_asegurados').hide();
            for(var i=0; i<num_asegurados; i++){
                $('#cuestionario tbody tr:eq('+array_leyendasAseg[i]+')').show();
                $('#cuestionario tbody tr:eq('+array_cuerpoAseg[i]+')').show();
            }
            limpiarFormAsegurados(num_asegurados);
        } else{
            $('.bloque_asegurados').hide();
        }
    });

    $('#frm .cuestionario input').each(function(index){
        // agregar id a los elementos faltantes
        var id_actual = $(this).attr('id');
        if(id_actual == undefined){
            $(this).attr('id', 'input_'+index);
        }

        // obtener onblur actual
        var onblur_actual = $(this).attr('onblur');

        if(onblur_actual != undefined){
            var onblur_p_c = onblur_actual.slice(-1); // punto y como final

            if(onblur_p_c == ';'){
                $(this).attr('onblur', onblur_actual+'removeSpaces(this.id);');

            } else{
                $(this).attr('onblur', onblur_actual+';removeSpaces(this.id);');
            }

        } else{
            $(this).attr('onblur', 'removeSpaces(this.id);');
        }
    });

    armaCamposCorreo();

    $('#info_sicall').css('z-index','9999');
    // convertir select en select2
    // titular AP
    $('select[name="txtQId13CId1"]').select2();
    $('select[name="txtQId13CId2"]').select2();

    // beneficiarios AP
    $('select[name="txtQId16CId7"]').select2();
    $('select[name="txtQId161CId7"]').attr('id', 'ocupacionB2').select2();
    $('select[name="txtQId162CId7"]').attr('id', 'ocupacionB3').select2();

    // titular HC
    $('select[name="txtQId21CId17"]').select2();
    $('select[name="txtQId21CId22"]').select2();
    $('select[name="txtQId21CId20"]').select2();

    // asegurados HC
    for(var a=1; a<=5; a++){ // para 3 asegurados y 3 beneficiarios
        for(var n=0; n<array_campos.length; n++){
            $('#'+array_campos[n]+'A'+a).select2();
            $('#'+array_campos[n]+'B'+a).select2();
        }
    }

    $('.select2-container').css('min-width','20rem');

    // bloquear campos de rfc
    for(var m=0; m<3; m++){
        $('#rfc_bene'+(m+1)).attr('readonly', true);
    }


    let plastico_ = '';
    let creditodebito = '';
    let tarjeta_adicional = '';
    $('#creditodebito').change(function(){
        if($(this).val() == ''){
            plastico_ = '';
            creditodebito = '';
        } else{
            plastico_ = $(this).find('option:selected').attr('data-plastico');
            creditodebito = $(this).val();
        }
        putPlastico(plastico_, creditodebito, tarjeta_adicional);
    });

    $('#tadicional').change(function(){
        if($(this).val() == ''){
            tarjeta_adicional = '';
        } else{
            tarjeta_adicional = $(this).val();
        }
        putPlastico(plastico_, creditodebito, tarjeta_adicional);
    });

    $('#ultimostarjeta').change(function(){
        let modo = $(this).attr('modo');
        if(modo == 'manual'){
            let plastico_avi = $(this).val();
            let coincidencia = '';
            if(plastico_avi == tdc){
                coincidencia = 'TDC';
                $('#ultimostarjeta').val('');

            } else if(plastico_avi == tdd){
                coincidencia = 'TDD';
                $('#ultimostarjeta').val('');
            }
            alert('La tarjeta que ingresaste tiene la misma terminacion que la '+coincidencia+' de base. Por favor selecciona bien los combos para continuar.');
        }
    });
    valida_marcacion();
});

//pintar valor de tarjeta o habilitar input Ultimos 4 Digitos de Tarjeta para AVI
                    // 4 digitos, tdd/tdc (0/1), no/si (0,1)
function putPlastico(num_plastico, tipo_tarjeta, adicional){
    if(num_plastico.length == 4 && parseInt(adicional) == 0){
        $('#ultimostarjeta').val(num_plastico).attr('readonly', true).attr('modo', 'automatico');
    } else{
        $('#ultimostarjeta').val('');
        $('#ultimostarjeta').attr('readonly', false).attr('modo', 'manual');;
    }
}

function limpiarFormBeneficiarios(num_beneficiarios){
    if(num_beneficiarios == 1){
        $('.beneficiario2 input').val('');
        $('.beneficiario2 select').val('');
        $('#ocupacionB2').val(null).trigger('change');
        $('.beneficiario2 .errorValidacion').remove();

        $('.beneficiario3 input').val('');
        $('.beneficiario3 select').val('');
        $('#ocupacionB3').val(null).trigger('change');
        $('.beneficiario3 .errorValidacion').remove();

    } else if(num_beneficiarios == 2){
        $('.beneficiario3 input').val('');
        $('.beneficiario3 select').val('');
        $('#ocupacionB3').val(null).trigger('change');
        $('.beneficiario3 .errorValidacion').remove();
    }
}

function limpiarFormAsegurados(num_asegurados){
    if(num_asegurados == 1){
        $('.asegurado2 input').val('');
        $('.asegurado2 select').val('');
        $('#ocupacionA2').val(null).trigger('change');
        $('#cargoA2').val(null).trigger('change');
        $('#actividadA2').val(null).trigger('change');
        $('.asegurado2 .errorValidacion').remove();

        $('.asegurado3 input').val('');
        $('.asegurado3 select').val('');
        $('#ocupacionA3').val(null).trigger('change');
        $('#cargoA3').val(null).trigger('change');
        $('#actividadA3').val(null).trigger('change');
        $('.asegurado3 .errorValidacion').remove();

        $('.asegurado4 input').val('');
        $('.asegurado4 select').val('');
        $('#ocupacionA4').val(null).trigger('change');
        $('#cargoA4').val(null).trigger('change');
        $('#actividadA4').val(null).trigger('change');
        $('.asegurado4 .errorValidacion').remove();

        $('.asegurado5 input').val('');
        $('.asegurado5 select').val('');
        $('#ocupacionA5').val(null).trigger('change');
        $('#cargoA5').val(null).trigger('change');
        $('#actividadA5').val(null).trigger('change');
        $('.asegurado5 .errorValidacion').remove();

    } else if(num_asegurados == 2){
        $('.asegurado3 input').val('');
        $('.asegurado3 select').val('');
        $('#ocupacionA3').val(null).trigger('change');
        $('#cargoA3').val(null).trigger('change');
        $('#actividadA3').val(null).trigger('change');
        $('.asegurado3 .errorValidacion').remove();

        $('.asegurado4 input').val('');
        $('.asegurado4 select').val('');
        $('#ocupacionA4').val(null).trigger('change');
        $('#cargoA4').val(null).trigger('change');
        $('#actividadA4').val(null).trigger('change');
        $('.asegurado4 .errorValidacion').remove();

        $('.asegurado5 input').val('');
        $('.asegurado5 select').val('');
        $('#ocupacionA5').val(null).trigger('change');
        $('#cargoA5').val(null).trigger('change');
        $('#actividadA5').val(null).trigger('change');
        $('.asegurado5 .errorValidacion').remove();
    
    } else if(num_asegurados == 3){
        $('.asegurado4 input').val('');
        $('.asegurado4 select').val('');
        $('#ocupacionA4').val(null).trigger('change');
        $('#cargoA4').val(null).trigger('change');
        $('#actividadA4').val(null).trigger('change');
        $('.asegurado4 .errorValidacion').remove();

        $('.asegurado5 input').val('');
        $('.asegurado5 select').val('');
        $('#ocupacionA5').val(null).trigger('change');
        $('#cargoA5').val(null).trigger('change');
        $('#actividadA5').val(null).trigger('change');
        $('.asegurado5 .errorValidacion').remove();
    
    } else if(num_asegurados == 4){
        $('.asegurado5 input').val('');
        $('.asegurado5 select').val('');
        $('#ocupacionA5').val(null).trigger('change');
        $('#cargoA5').val(null).trigger('change');
        $('#actividadA5').val(null).trigger('change');
        $('.asegurado5 .errorValidacion').remove();
    } 
}

function muestra_beneficiarios_seleccionados(num_sel, array_leyendas, array_cuerpo){
    if(num_sel != ''){
        $('.bloque_beneficiarios').hide();
        for(var i=0; i<num_sel; i++){
            $('#cuestionario tbody tr:eq('+array_leyendas[i]+')').show();
            $('#cuestionario tbody tr:eq('+array_cuerpo[i]+')').show();
        }
    } else{
        $('.bloque_beneficiarios').hide();
    }
}

function muestra_asegurados_seleccionados(num_sel, array_leyendasAseg, array_cuerpoAseg){
    if(num_sel != ''){
        $('.bloque_asegurados').hide();
        for(var i=0; i<num_sel; i++){
            $('#cuestionario tbody tr:eq('+array_leyendasAseg[i]+')').show();
            $('#cuestionario tbody tr:eq('+array_cuerpoAseg[i]+')').show();
        }
    } else{
        $('.bloque_asegurados').hide();
    }
}


// function obtener_demograficos(id_cp){
//     setTimeout(function(){
//         $('#'+id_cp).click();
//     },500);

//     setTimeout(function(){
//         var valor = $('#MANA_2_5').val();
//         recorreSelect('COLONIA1', valor);
//     },500);
// }

// function recorreSelect(id_select, valor){
//     $('#'+id_select+' option').each(function(){
//         console.log($(this).value);
//         if($(this).value == valor){
//             $(this).attr('selectd', true);
//         }
//     });
// }

function sendSMS(e, id, u_telefono, telefono, nomina){
    e.preventDefault();
    let customerid = $('#customerid').val();
    let surveyid = $('#surveyid').val();
    let cliente = $('#nombrepila').val().split(' ')[0];

    var params = {
        'customerid' : customerid,
        'surveyid' : surveyid,
        'cliente' : cliente,
        'u_telefono' : u_telefono,
        'telefono' : telefono,
        'nomina' : nomina
    };

    $.ajax({
        type: "post",
        url: "modules/agentes/sendSMS.php",
        //url: 'modules.php?mod=agentes&op=process_data&act=NzU=',
        data: params,
        dataType: "json",
        beforeSend: function(){
            $('#btnSendSMS_'+id).css('cursor','not-allowed').attr('disabled',true);
            $('#tdResponseSMS_'+id).html('<img src="includes/imgs/loader.gif" style="width: 30px;border-radius: 50%;">');
            $('#tdSMS_'+id).html('');
        },
        success: function(response){
            console.log(response);
            if(response.error_api == ''){
                var resp = 'Mensaje Enviado. <span style="color:green;font-size:1rem;"><i class="fa-solid fa-check"></i></span>';
                // $('#tdSMS_'+id).html(`
                //     <input id="inputCodigo_${id}">
                //     <button style="background-color:red;color:#fff;padding:0 2rem;" class="btn" onclick="validaCodigo(event, ${id}, ${response.codigo_aleatorio});">
                //         Validar c&oacute;digo
                //     </button>
                // `);

                // $('#tdSMS_'+id).html(`
                //     <input id="inputCodigo_${id}">
                //     <button style="background-color:red;color:#fff;padding:0 2rem;" class="btn" onclick="validaCodigo(event, ${id}, ${response.codigo_aleatorio}, ${customerid});">
                //         Validar c&oacute;digo
                //     </button>
                // `);
                $('#tdSMS_'+id).html(`
                    <input id="inputCodigo_${id}">
                    <input style="background-color:red;color:#fff;padding:0 2rem;width:110px;" class="btn" onclick="validaCodigo(event, ${id}, ${response.codigo_aleatorio}, ${customerid});" value="Validar c&oacute;digo">
                `);

                // $('#tdIVR_'+id).html(`
                //     <button style="background-color:red;color:#fff;padding:0 2rem;" class="btn" id="btnIVR_${id}" onclick="sendIVR(event, ${customerid}, ${surveyid}, ${u_telefono}, ${telefono}, ${nomina},
                //         ${response.codigo_aleatorio},);">
                //         IVR
                //     </button>
                // `);
            } else{
                var resp = response.error_api + '. <span style="color:red;font-size:1rem;"><i class="fa-solid fa-xmark"></i></span>';
            }
            $('#tdResponseSMS_'+id).html(resp);
            $('#btnSendSMS_'+id).css('cursor','pointer').attr('disabled',false);
        }
    });
}

// function validaCodigo(e, id, codigo_aleatorio){
//     e.preventDefault();
//     let codigo_input = $('#inputCodigo_'+id).val();

//     if(codigo_input == ''){
//         alert('Por favor ingresa el código proporcionado por el cliente.');
//     } else{
//         if(codigo_input == codigo_aleatorio){
//             alert('El código ingresado es correcto.');
//             $('select[name=txtQId17CId2]').val(1);

//         } else{
//             alert('El código ingresado no conicide con el enviado al cliente.');
//             $('select[name=txtQId17CId2]').val(0);
//         }
//     }
// }

function validaCodigo(e, id, codigo_aleatorio, customerid){
    e.preventDefault();
    // codigo_aleatorio es el ultimo enviado al cliente.
    let codigo_input = $('#inputCodigo_'+id).val();

    if(codigo_input == ''){
        alert('Por favor ingresa el código proporcionado por el cliente.');
    } else{
        // enviar petición para recuperar todos los codigos aleatorios
        $.ajax({
            type: "post",
            url: 'modules.php?mod=agentes&op=process_data&act=NzQ=',
            data: {'customerid':customerid},
            dataType: "json",
            beforeSend: function(){
                //console.log('mostrar gif de espera retorno IVR');
            },
            success: function(response){
                console.log(response);
                if(response.includes(codigo_input) == true){
                    alert('El código ingresado es correcto.');
                    $('select[name=txtQId17CId2]').val(1);
                } else{
                    alert('El código ingresado no conicide con el enviado al cliente.');
                    $('select[name=txtQId17CId2]').val(0);
                }
            }
        });
    }
}

function enlazarIVR(e, customerid, surveyid, u_telefono, telefono, nomina){
    e.preventDefault();
    var params = {
        'customerid' : customerid,
        'surveyid' : surveyid,
        'u_telefono' : u_telefono,
        'telefono' : telefono,
        'nomina' : nomina
    };

    $.ajax({
        type: "post",
        url: 'modules.php?mod=agentes&op=process_data&act=NzM=',
        data: params,
        dataType: "json",
        beforeSend: function(){
//          console.log("Entrando a IVR");
            $('.loader').show();
            //alert("Ejecutando proceso de IVR, confirma con tu cliente si es correcto.");
            //console.log('mostrar gif de espera retorno IVR');
//            console.log(response.split('|')[1]); // mensaje de BD

        },
        success: function(response){
//            console.log("Exitoso");
            $('.loader').hide();
            //alert(response.split('|')[0]);  // respuesta digitación cliente
            console.log(response.split('|')[1]); // mensaje de BD

            // if(response.split('|')[0] == '0'){
            //     alert('Error. El cliente NO digito correctamente el codigo aleatorio.');

            // } else if(response.split('|')[0] == 'Regresamos con el cliente'){
            //     alert('El cliente no digito el codigo');

            // } else if(response.split('|')[0] == ''){
            //     alert(response.split('|')[2]);

            // } else if(response.split('|')[0] == '1'){
            //     alert('Exito. El cliente digito correctamente el codigo aleatorio.');
            // }


            if(response.split('|')[0] == '0'){
                if(response.split('|')[3] == ''){
                    alert(response.split('|')[2]); // cliente o agente colgo
                } else{
                    alert('Error. El cliente NO digito correctamente el codigo aleatorio.');
                }


            // } else if(response.split('|')[0] == ''){
            //     alert(response.split('|')[2]);

            } else if(response.split('|')[0] == '1'){
                alert('Exito. El cliente digito correctamente el codigo aleatorio.');
            }
        }
    });
}

var selection = null;
var altDown = 0;

/**
 * Formato para moneda
 * @param number c
 * @param char d
 * @param char t
 * @returns {String}
 */
Number.prototype.formatMoney = function (c, d, t) {
    var n = this,
            c = isNaN(c = Math.abs(c)) ? 2 : c,
            d = d == undefined ? "." : d,
            t = t == undefined ? "," : t,
            s = n < 0 ? "-" : "",
            i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
    return '$' + s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};

/**
 * Quita el formato numérico de "$", ",", etc., y solo deja los números.
 * @param string number
 * @returns number
 */
function removeFormat(number) {
    return number.replace(/[^0-9.]/g, '');
}
/*
 * @function createCookie
 * @param string name
 * @param string value
 * @param number/null days
 * @returns {undefined}
 * @author abarajas
 * @date 2014-03-19
 *
 * Establece una cookie con su nombre, valor y duración (en días). Se puede
 * omitir la duración para que nunca expire o colocarla en 0 para que se
 * destruya al cerrar el navegador.
 */


function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    } else
        var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

/*
 * @function readCookie
 * @param string name
 * @returns string
 * @author abarajas
 * @date 2014-03-19
 *
 * Lee las cookies locales para extraer un valor, y así poder pasar datos
 * desde PHP hacia JavaScript
 */
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0)
            return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
    return null;
}

/*
 * @function eraseCookie
 * @param string name
 * @returns {undefined}
 * @author abarajas
 * @date 2014-03-19
 *
 * Elimina una cookie llamado a createCookie con un parámetro negativo,
 * destruyéndola efectivamente en el momento.
 */
function eraseCookie(name) {
    createCookie(name, "", -1);
}

var linkpath = readCookie('linkpath');
//alert("Desde jsCode, " + linkpath);

//VALIDACION PARA NO USAR EL ALT <-
if (typeof window.event != 'undefined') {
    document.onkeydown = function () {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
    }

    document.onkeyup = function () {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
        altDown = 0;
    }

    document.onkeypress = function () {
        window.status = event.keyCode
        if (event.keyCode == 18)
            altDown = 1;
        if (event.keyCode == 37 && altDown == 1)
            return false;
        altDown = 0;
    }
} else {
    document.onkeydown = function (e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
    }
    document.onkeypress = function (e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
        altDown = 0;
    }

    document.onkeyup = function (e) {
        if (e.keyCode == 18)
            altDown = 1;
        if (e.keyCode == 37 && altDown == 1) {
            return false;
        }
        altDown = 0;
    }
}

//EVITA EL BOTON ATRAS
if (typeof window.event != 'undefined') {
    document.onkeydown = function () {
        if (event.srcElement.tagName.toUpperCase() != 'INPUT' && event.srcElement.tagName.toUpperCase() != 'TEXTAREA')
            return (event.keyCode != 8);
    }
} else {
    document.onkeypress = function (e) {
        if (e.target.nodeName.toUpperCase() != 'INPUT' && e.target.nodeName.toUpperCase() != 'TEXTAREA')
            return (e.keyCode != 8);
    }
}

// CREA EL OBJETO AJAX
function nuevoAjax() {
    var xmlhttp = false;
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            xmlhttp = false;
        }
    }

    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
}


function loadXMLDoc(dname) {
    if (window.XMLHttpRequest) {
        xhttp = new XMLHttpRequest();
    } else {
        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xhttp.open("GET", dname, false);
    xhttp.send("");
    return xhttp.responseXML;
}

function displayResult(producto) {

    xml = loadXMLDoc("./modules/agentes/cuestionario_" + producto + ".xml?i=2");
    xsl = loadXMLDoc("./modules/agentes/catalogo.xsl?i=2");

    if (window.ActiveXObject) { // code for IE
        ex = xml.transformNode(xsl);
        document.getElementById("cuestionario").innerHTML = ex;
    } else if (document.implementation && document.implementation.createDocument) { // code for Mozilla, Firefox, Opera, etc.
        xsltProcessor = new XSLTProcessor();
        xsltProcessor.importStylesheet(xsl);
        resultDocument = xsltProcessor.transformToFragment(xml, document);
        document.getElementById("cuestionario").appendChild(resultDocument);
    }
}

// ENVIA DATOS USANDO EL OBJETO AJAX
function send_post_page_n(request, container, page) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            contenedor.innerHTML = ajax.responseText
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// CALIFICA LOS TELEFONOS CON AJAX
function send_post_page_califica_tel(request, page) {
    var contenedor;
    ajax = nuevoAjax();
    ajax.open("POST", page, false);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}


// ENVIA LA SOLICITUD ENCONTRADA A TD_REGISTROS PARA DESPUES CALIFICAR
function send_post_page_sol(request, page) {
    var contenedor;
    //alert('Entra a esta funcion');
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// ENVIA DATOS POR AJAX PARA GUARDAR LA CALIFICACION DEL REGISTRO
function send_post_page(request, page) {
    var contenedor;
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            //alert(ajax.responseText)
            //prompt('as',ajax.responseText)
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// MUESTRA EL SCRIPT DE VENTA
function ShowScript(script, solicitud, etapa) {
    request = "action=1";
    scriptMostrar = script;
    if (scriptMostrar == 1) { //Super Light  No Automï¿½tico
        send_post_page_n(request, "script", "modules.php?mod=agentes&op=Script_IN&sol=" + solicitud);
    } else {
//send_post_page_n(request,"script","modules.php?mod=agentes&op=Script_OUT&sol="+solicitud);
//send_post_page_n(request,"script","http://172.20.1.77/PagosFijos/cuestionarion.asp?surveyid=1&u_persona="+solicitud+"&u_registro="+solicitud+"&u_user=7&inicio=y");
    }


}

function ShowScript_V(script, solicitud, etapa) {
    request = "action=1";
    scriptMostrar = script;
    send_post_page_n(request, "script", "modules.php?mod=validacion&op=ScriptValidacion&sol=" + solicitud);
}

// MUESTRA EL SCRIPT DE VENTA
function ShowScript_GeneralIN(tarjeta) {
    request = "action=1";
    send_post_page_n(request, "script", "modules.php?mod=agentes&op=Script"+tarjeta);
}

// CALIFICA EL NUMERO TELEFONICO
function califica_tel(valor, solicitud, contador, plan) {
    indice = document.getElementById("cont").value; //Cuenta el total de telefonos para el registro
    calificacion = valor.value;
    //etapa = document.frm1.id_etapa.value;
    telefono = document.getElementById('tel_' + contador).value;
    //request = "telefono="+telefono+"&calificacion="+calificacion+"&etapa="+etapa+"&solicitud="+solicitud;
    //send_post_page_califica_tel(request, "modules.php?mod=agentes&op=process_data&act=2");
    alert(calificacion);
}
/*
 *Evalua el telefono de la solicitud y lo asigna de a cuerdo a su valor
 */
function evaluartelefono(op) {
    var eval_tel = document.getElementById("ev_tel").value;
    if (op != null && op != '') {

        if (eval_tel.substr(0, 2) == '55') {
            var lada = eval_tel.substr(0, 2);
            var tel = eval_tel.substr(2);
        } else {
            var lada = eval_tel.substr(0, 3);
            var tel = eval_tel.substr(3);
        }
        if (op == 1) {
            $("#evallt").val(lada);
            $("#evallt").prop("disabled", true);
            $("#evalt").val(tel);
            $("#evalt").prop("disabled", true);
            $("#evac").prop("disabled", false);
            $("#evac").val("");
        } else if (op == 2) {
            $("#evac").val(lada + tel);
            $("#evac").prop("disabled", true);
            $("#evallt").prop("disabled", false);
            $("#evalt").prop("disabled", false);
            $("#evallt").val("");
            $("#evalt").val("");
        }

    }
}
//ABRE VENTANA LLAMADA
function AbreVentana(boton, contador, nomina, tel, id_solicitud, extenagente, cc, u_telefono, u_zona) {
    u_telefono = typeof u_telefono !== 'undefined' ?  u_telefono : '';
    u_zona = typeof u_zona !== 'undefined' ?  u_zona : '';
    /*
     * ABarajas, 2014-03-05
     * Crear variable para id de empresa, así poder saber a qué IP
     * se debe dirigir el marcador asistido (entre otras cosas).
     *
     * Afecta:
     * - session.inc.php
     * - jsCode.js
     *
     * Centros (Revisar ASISTENCIA.EMPRESAS y validar):
     * 1	Impulse Telecom Queretaro
     * 2	TELEMARKETING ESPECIALIZADO SA DE CV
     * 3	AMEX
     * 5	Impulse Telecom San Juan del Rio
     * 8	I Cube
     * 9	Quayllay
     * 10	IQ Call
     */
    //centro = readCookie('s_usr_centro');

        //Si no esta dentro del rango de la hora no desabilita los botones de Marcar
    if(!ValidaHorario()){
        return false     
   }



    centro = 'ITQ';
    //alert("Entro, empresa: "+ centro)

    var URL = "";
    //alert("*" + centro + "*"); chuy url

    if (centro == 'ITQ' || centro == 'ITS')
    {
        URL = "https://172.20.1.10/marcadoasistido/click2dial/hsbc/marcadoasistido.php?employeeid=" + nomina + "&exten=01" + tel + "&sicallVarSolicitud=" + id_solicitud + "&extenagente=" + extenagente + "&centro=" + centro + "&cc=" + cc + "&schm=hsbc&u_telefono="+u_telefono+"&u_zona="+u_zona;
    }else
    {
        if(centro == '') {
            URL = "";
        }else {
            URL = "https://172.20.19.11/click2dial/hsbc/marcadoasistido.php?employeeid=" + nomina + "&exten=01" + tel + "&sicallVarSolicitud=" + id_solicitud + "&extenagente=" + extenagente + "&centro=" + centro + "&cc=" + cc + "&schm=hsbc&u_telefono="+u_telefono+"&u_zona="+u_zona;
        }

    }

    if (URL != "") {
        //Realiza marcacion
        //document.getElementById("asistido").src = URL;

        //alert(URL);

        //Metodo para desbloquear el boton despues 30 seg.
        document.getElementById(boton.id).setAttribute("class", "menulink2");
        setTimeout(function () {
            boton.disabled = false;
            document.getElementById(boton.id).setAttribute("class", "menulink");
        }, 15000);
        alert("Marcando teléfono...\n\nPresiona <Enter> o da clic en \"Aceptar\" al recibir la llamada (o si no te contestan).");

        //sweetAlert("Marcando...", "Se esta realizando la marcación, sino tienes exito revisa tu softphone", "success");

        $.post("modules.php?mod=agentes&op=process_data&act=ODE=",{//81
            url_asistido:URL
        },function(data,status){
            //alert(data+"\n\n\n"+status);
        });


    } else {
        alert("No existe marcación para tu centro/No estás asignado a un centro");
    }
    document.getElementById('tel_0' + contador).focus();

console.log(URL, centro);
    //Registra el nombre de la grabacion == 55
    $.post("modules.php?mod=agentes&op=process_data&act=NTU=", {
        nomina: nomina,
        telefono: tel,
        u_persona: id_solicitud,
        url: URL
    }, function (data, status) {
        //alert(data);
    });
}

function Continuar(boton, telefonos, action, ispredictivo, nomina, solicitud) {
    var suma = 0;
    var contacto = 0;


    for (i = 1; i <= telefonos; i++) {
        var tel = eval('document.frm1.tel_0' + i + '.value');
        if (tel != 0) {
            if (tel == 1010) {
                contacto += 1;
            } else {
                suma += 1;
            }
        }
    }

    if (contacto != 0) {
        if (document.frm1.producto_.value == "") {
            alert('Debes seleccionar un producto para continuar');
            boton.disabled = false;
            return false;
        } else {
            document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
            document.frm1.submit();
        }

    } else {
        if (suma < telefonos) {
            alert('Debes calificar lo(s) Telefono(s) disponibles');
            boton.disabled = false;
            return false;
        }
    }
    


    if (contacto == 0) {
        colgar_asistido(1, action, nomina, solicitud);
    }

    if (contacto == 0) {
        
        if(!ValidaHorario()){
            //Si ya no entra dentro del rango de hora, ya no deja obtener registro y se deslogea automaticamente
            window.location = 'modules.php?mod=admin&op=process_data&act=2';                          
            
        }

    }

    if (ispredictivo == 1 && contacto == 0) {
       
     
        $(function () {
            $("#dialog-proceso").dialog({
                autoOpen: true,
                height: 100,
                width: 350,
                modal: true,
                closeOnEscape: false,
                open: function (event, ui) {
                    jQuery('.ui-dialog-titlebar-close').hide();
                }
            });
        });

     
    }


    
    //setTimeout(function() {
    // document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
    // document.frm1.submit();
    //},2000);



}


function AbandonarV2(boton, telefonos, action, ispredictivo, nomina, solicitud) {
    var suma = 0;
    var contacto = 0;


    for (i = 1; i <= telefonos; i++) {
        var tel = eval('document.frm1.tel_0' + i + '.value');
        if (tel != 0) {
            if (tel == 1010) {
                contacto += 1;
            } else {
                suma += 1;
            }
        }
    }

  

    if (contacto != 0) {
        alert('Si vas a Abandonar el registro no debes calificar Contacto');
        boton.disabled = false;
        return false;
    } else {
        if (suma < telefonos) {
            alert('Debes calificar lo(s) Telefono(s) disponibles para poder Abandonar');
            boton.disabled = false;
            return false;
        }
    }

    if (contacto == 0) {
        colgar_asistido(1, action, nomina, solicitud);
    }

    if (contacto == 0) {
        
        if(!ValidaHorario()){
            //Si ya no entra dentro del rango de hora, ya no deja obtener registro y se deslogea automaticamente
            window.location = 'modules.php?mod=admin&op=process_data&act=2';        
       }

    }

    if (ispredictivo == 1 && contacto == 0) {
        $(function () {
            $("#dialog-proceso").dialog({
                autoOpen: true,
                height: 100,
                width: 350,
                modal: true,
                closeOnEscape: false,
                open: function (event, ui) {
                    jQuery('.ui-dialog-titlebar-close').hide();
                }
            });
        });
    }

    

    //setTimeout(function() {
    // document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
    // document.frm1.submit();
    //},2000);



}

function obtenerRegistroAsistido(){    

    if(!ValidaHorario()){ 
        //Si ya no entra dentro del rango de hora, ya no deja obtener registro y se deslogea automaticamente
        window.location = 'modules.php?mod=admin&op=process_data&act=2';               
    }else{
        //Si está dentro del rango de horario, va al proceso de obtener nuevo registro asistido                     
        window.location =  'modules.php?mod=agentes&op=process_data&act=MQ==';        
    }
    
}

function obtenerRegistroPredictivo(){

    if(!ValidaHorario()){        
        //Si ya no entra dentro del rango de hora, ya no deja obtener registro y se deslogea automaticamente
        window.location = 'modules.php?mod=admin&op=process_data&act=2';               
    }else{
        //Si está dentro del rango de horario, va al proceso de obtener nuevo registro predictivo                     
        window.location =  'modules.php?mod=agentes&op=process_data&act=Mjc=';
    }
  
}

function colgar_asistido(frm, action, nomina, solicitud){

    //Registra el nombre de la grabacion == 55
    $.post("modules.php?mod=agentes&op=process_data&act=ODI=", {
        agentenomina: nomina,
        solicitud: solicitud,
        url: 'https://172.20.1.10/marcadoasistido/click2dial/hsbc/marcado-clear-to-call.php'
    }, function (data, status) {
        //alert(data);
    })
    .done(function() {
        console.log("success");
        if(frm ==1){
            document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
            document.frm1.submit();
        }else{
            var valhora = ValidaHorario();
 
            document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&validahorario=' + valhora ;
            //document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
            document.SurveyResponse.submit();
        }

    });
}


// ABANDONA EL REGISTRO SELECCIONADO
function Abandonar(boton, telefonos, action) {
    if (confirm("¿Esta seguro de que deseas abandonar este registro?\nSolo usar para salir de la aplicacion") == true) {
        document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
        document.frm1.submit();

    } else {
        boton.disabled = false;
        return false;
    }
}

//INFORMA DE QUE LA LINEA ESTA OCUPADA PREDICTIVO.
function linea_ocupada_pred()
{
    alert("linea ocupada");
    return false;
}

// ### ENVIA A LA PANTALLA DONDE CALIFICA LA LLAMADA QUE REALIZO EL CLIENTE,
function CalificarLlamada() {
    if (document.frm15.motivo_llamada.value == 0) {
        alert('Seleccione una calificacion');
        return false;
    }
    document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=16';
    document.frm15.submit();
}

// CALIFICA EL NUEVO REGISTRO DE LA LLAMADA RECIBIDA
function cal_llamada(valor, registro) {
    calificacion = valor.value;
    request = "id_registro=" + registro + "&calificacion=" + calificacion;
    send_post_page_califica_tel(request, "modules.php?mod=agentes&op=process_data&act=12");

}



function ValidaHorario() {
    
    const fechaActual = new Date();
    const hora = fechaActual.getHours();


    //if(id_user == '577242'){ //Usuario para pruebas
        if(hora < 9){
          
            Swal.fire('Solo puedes ingresar al sicall a partir de las 9 AM');           
            return false;

        }else if(hora >= 19){
            
            Swal.fire('El horario de sicall es hasta las 7:00PM');
            return false;
          
        }
      //}
       return true 
  
}


// VALIDA LOS CAMPOS PARA EL INICIO DE SESSION
function ValidaLogin() {
    var id_user = document.getElementById("user").value;
    var pass_user = document.getElementById("password").value;
    var marcacion = document.frm1.marcacion.value;

    //console.log(ValidaHorario());
    
       if(!ValidaHorario()){
            return false        
       }


    //centro = readCookie('s_usr_centro_inicia');
    tipo_centro = readCookie('tipo_centro');

    //if (centro == 11) {
    if (tipo_centro == 'remoto') {
        var ext_user = document.getElementById("extension").value;
    }

    
    if (id_user != "") {
        if (pass_user != "") {
            if (marcacion != "0") {
                if (tipo_centro == 'remoto') {
                    if (ext_user != "") {
                        if (ext_user.length == 4) {
                            document.frm1.submit();
                        } else {
                            alert('El campo Extension debe de ser de 4 numeros')
                            return false;
                        }
                    } else {
                        alert('Debes de capturar el campo Extension')
                        return false;
                    }
                } else {
                    document.frm1.submit();
                }
            } else {
                alert('Debe seleccionar el tipo de marcación')
                return false;
            }
        } else {
            alert('Debes de capturar el campo Contraseña')
            return false;
        }
    } else {
        alert('Debes de capturar el campo Id Usuario')
        return false;
    }


}


//REALIZA LA VALIDACION DE LA BUSQUEDA DE CLIENTES EN UNA NUEVA LLAMADA
function MotivoLlamada(nuevo, bandera) {

    if (nuevo == 1) {

        if (document.frm15.nombre.value == "" || document.frm15.paterno.value == "" || document.frm15.tdc.value == "" || document.frm15.telefono.value == "") {
            alert('Captura los campos obligatorios.');
            document.frm15.nombre.focus();
            return false;
        }

        if (document.frm15.tdc.value != "") {

            if (!validatarjeta(document.frm15.tdc.value, "16 Digitos TC"))
                return false;
            if (!numeros(document.frm15.tdc, "TDC"))
                return false;
            if (!tamanos(document.frm15.tdc, "TDC", 16, 16))
                return false;
            if (document.frm15.tipo_tdc.value == 0) {
                alert('Debes escoger que tipo de TDC es');
                document.frm15.tipo_tdc.focus();
                return false;
            }
        } else {

            if (document.frm15.tipo_tdc.value != 0) {
                alert('Falta capturar una TDC para escoger el tipo al que pertenece');
                document.frm15.tipo_tdc.focus();
                return false;
            }
        }

        if (document.frm15.telefono.value != "") {
            if (!numeros(document.frm15.telefono, "Telefono"))
                return false;
            if (!tamanos(document.frm15.telefono, "Telefono", 10, 10))
                return false;
        } else {
            alert('El campo Telefono es obligatorio');
            document.frm15.tipo_tdc.focus();
            return false;
        }
    }

    document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=11&nuevo=' + nuevo + '&bandera=' + bandera;
    document.frm15.submit();

}



//### CALIFICA LA LLAMADA SOBRE EL REGISTRO QUE INGRESAMOS O ABRE LA SOLICITUD SI NO TIENE VENTA.
function RegistroIncompleto(accion) {
    if (accion == 1) { // Boton califica llamada
        document.frm15.action = 'modules.php?mod=agentes&op=calificar_llamada'
    } else if (accion == 2) { // Boton solicitud
        //document.frm15.action = 'modules.php?mod=agentes&op=cuestionarioinbound'
        document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=19&nvo=0'
    } else if (accion == 3) {// Boton nuevo registro
        document.frm15.action = 'modules.php?mod=agentes&op=process_data&act=19&nvo=1'
    } else if (accion == 4) {// Boton regresar
        document.frm15.action = 'modules.php?mod=agentes&op=nueva_llamada'
    }

    document.frm15.submit();
}


// REGRESAR A BUSQUEDA DE CLIENTE OUT
function NuevaLlamda() {
    document.frm15.action = 'modules.php?mod=agentes&op=nueva_llamada'
    document.frm15.submit();
}

// REALIZA LA ACCION DE BORRAR LO DE UN FORMULARIO
function LimpiaDatos() {
    document.frm11.reset();
}

//VALIDA EL NUMERO VERIFICADOR DE LA TDC
function PrefijoSS(tdc, campo) {
    var banprefijoss = true;
    Banco = 0;
    TDC_Cliente = tdc;
    numeroTarjeta = TDC_Cliente;
    arraytarjeta = new Array();
    numeroprefijos = '212121212121212';
    arrayprefijos = new Array();
    arrayproducto = new Array();
    prefijo = 0;
    dividendo = 0;
    verificador = 0;

    if (Banco == 8) {
        numeroTarjeta = 0 + numeroTarjeta;
        no_verificador = numeroTarjeta.substring(15, 16);
    } else {

        numeroTarjeta
        no_verificador = numeroTarjeta.substring(15, 16);
    }

    arraytarjeta = numeroTarjeta.split("");
    arrayprefijos = numeroprefijos.split("");
    for (i = 0; i < 15; i++) {
        prefijo += parseInt(validalongitudprefijos(parseInt(arraytarjeta[i]), parseInt(arrayprefijos[i])));
    }
    dividendo = prefijo % 10;
    if (dividendo == 0) {
        verificador = 0;
    } else {
        verificador = 10 - dividendo;
    }
    if (verificador == no_verificador) {
        banprefijoss = true;
    } else {
        alert('Verifique los datos de la TDC para el campo " ' + campo + '", es incorrecto el nï¿½mero verificador.');
        banprefijoss = false;
    }
    return banprefijoss;

}


function validalongitudprefijos(numtarjeta, numprefijo) {
    valor = numtarjeta * numprefijo;
    valor = valor + '';
    nuevovalor = 0;
    if (valor >= 10) {
        valor.split("");
        nuevovalor = parseInt(valor[0]) + parseInt(valor[1]);
    } else {
        nuevovalor = valor;
    }
    return nuevovalor;
}

//VALIDA QUE LOS BINES DE LA TDC SEAN CORRECTOS
function validatarjeta(tdc, campo) {
    bandera_telac = true;
    TDC_Cliente = tdc;
    validada = 100;

    if (TDC_Cliente.length == 16) {
        for (i = 0; i < (array_bines.length); i++) {
            Bines2 = eval(TDC_Cliente.substring(0, array_bines[i].toString().length));
            if (array_bines[i].toString() == Bines2) {
                validada = 0;
                break;
            }
        }

        if (validada == 100) {
            alert('El prefijo de la TDC capturada en el campo "' + campo + '" no coincide con el prefijo del Banco.')
            bandera_telac = false;
        } else {
            bandera_telac = PrefijoSS(tdc, campo);
        }
    } else {
        alert("La longitud de la TDC para el " + campo + " debe ser de 16 dï¿½fitos");
        bandera_telac = false;
    }
    return bandera_telac;

}

//### BUSCA LA SOLICITUD QUE SE VA A VALIDAR
function BuscarSolicitud() {
    if (document.frm1.idsolicitud.value == "") {
        alert('Debes capturar una solicitud');
        document.frm1.idsolicitud.focus();
        return false;
    }
    if (!numeros(document.frm1.idsolicitud, "Numero de Solicitud"))
        return false;

    document.frm1.submit();
}

// REALIZA LA ACCION DE BORRAR LO DE UN FORMULARIO
function LimpiaDatosV() {
    document.frm1.reset();
}

// REALIZA LA VALIDACION DE LA SOLICITUD INBOUND
function ValidaSolicitud_Inbound() {

    if (document.frm12.nombre != null) {
        if (document.frm12.nombre.value == "") {
            alert('El campo de "Nombre", no debe ir vacï¿½o');
            document.frm12.nombre.focus();
            return false;
        }
    }

    if (document.frm12.paterno != null) {
        if (document.frm12.paterno.value == "") {
            alert('El campo de "Paterno", no debe ir vacï¿½o');
            document.frm12.paterno.focus();
            return false;
        }
    }

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            alert('Debes selecionar un Telefono de contacto o capturar el campo Otro')
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            alert('Ya tienes seleccionado un numero telefonico del combo')
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            alert("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar != null) {
        if (document.frm12.actualizar.value == 0) {
            alert('Conteste si desea actualizar sus datos.');
            document.frm12.actualizar.focus();
            return false;
        } else {
            if (document.frm12.calificacion != null) {
                if (document.frm12.calificacion.value == 0) {
                    alert('Selecciona una Calificacion');
                    document.frm12.calificacion.focus();
                    return false;
                }
                if (document.frm12.subcalificacion != null) {
                    if (document.frm12.subcalificacion.value == 0) {
                        alert('Selecciona una Sub. Calificacion.');
                        document.frm12.subcalificacion.focus();
                        return false;
                    }
                }
                if (document.frm12.rangopago != null) {
                    if (document.frm12.rangopago.value == 0) {
                        alert('Selecciona el Rango de Pago.');
                        document.frm12.rangopago.focus();
                        return false;
                    }
                }
            }

            if (document.frm12.edocta.value == 0) {
                alert('La pregunta 4 es  obligatoria.');
                document.frm12.edocta.focus();
                return false;
            }
            if (document.frm12.actualizar.value == 1) {
                if (document.frm12.promo.value == 0) {
                    alert('Constesta la pregunta 3')
                    return false;
                }

                if (document.frm12.mastdc.value == 0) {
                    alert('Constesta la pregunta 5')
                    return false;
                }
            }
        }
    } else {
        if (document.frm12.calificacion != null) {
            if (document.frm12.calificacion.value == 0) {
                alert('Selecciona una Calificacion');
                document.frm12.calificacion.focus();
                return false;
            }
            if (document.frm12.subcalificacion != null) {
                if (document.frm12.subcalificacion.value == 0) {
                    alert('Selecciona una Sub. Calificacion.');
                    document.frm12.subcalificacion.focus();
                    return false;
                }
            }
            if (document.frm12.rangopago != null) {
                if (document.frm12.rangopago.value == 0) {
                    alert('Selecciona el Rango de Pago.');
                    document.frm12.rangopago.focus();
                    return false;
                }
            }
        }
    }

    if (document.frm12.ejecutivo_venta != null) {
        if (document.frm12.ejecutivo_venta.value == 0) {
            alert('La pregunta 6 es obligatoria.');
            document.frm12.rangopago.focus();
            return false;
        }

        if (document.frm12.ejecutivo_venta.value == 2) {
            if (document.frm12.calificacion.value == 525) {
                alert('No puedes seleccionar esta calificacion "Firma Solicitud al Ejecutivo" cuando la pregunta 6 es "NO".');
                document.frm12.ejecutivo_venta.focus();
                return false;
            }
        }

        if (document.frm12.folio_carta.value == "") {
            alert('El cliente tiene que proporcionar este folio');
            document.frm12.folio_carta.focus();
            return false;
        }
    }


    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            alert('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            alert('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            alert('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    alert('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        alert('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    alert('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }


    if (document.frm12.tdc != null) {
        if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
            return false;
        if (!numeros(document.frm12.tdc, "16 Dï¿½gitos TdC"))
            return false;
        if (document.frm12.tdc.value != "") {
            if (!validatarjeta(document.frm12.tdc.value, "16 Dï¿½gitos TdC"))
                return false;
        }
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;


    alert('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".')

    document.frm12.submit();


}

// REALIZA LA VALIDACION DE LA SOLICITUD IN
function ValidaSolicitud_In() {

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            alert('Debes selecionar un Telefono de contacto o capturar el campo Otro')
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            alert('Ya tienes seleccionado un numero telefonico del combo')
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            alert("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar != null) {
        if (document.frm12.actualizar.value == 0) {
            alert('Conteste si desea actualizar sus datos.');
            document.frm12.actualizar.focus();
            return false;
        } else {
            if (document.frm12.subcalificacion != null) {
                if (document.frm12.subcalificacion.value == 0) {
                    alert('Selecciona una Sub. Calificacion.');
                    document.frm12.subcalificacion.focus();
                    return false;
                }
            }

            if (document.frm12.edocta.value == 0) {
                alert('La pregunta 3 es  obligatoria.');
                document.frm12.edocta.focus();
                return false;
            }
            if (document.frm12.actualizar.value == 1) {
                if (document.frm12.promo.value == 0) {
                    alert('Constesta la pregunta 2')
                    return false;
                }

                if (document.frm12.mastdc.value == 0) {
                    alert('Constesta la pregunta 4')
                    return false;
                }
            }
        }
    } else {
        if (document.frm12.subcalificacion != null) {
            if (document.frm12.subcalificacion.value == 0) {
                alert('Selecciona una Sub. Calificacion.');
                document.frm12.subcalificacion.focus();
                return false;
            }
        }
    }

    if (document.frm12.nueva_tdc != null) {
        if (document.frm12.nueva_tdc.value == 0) {
            alert('La pregunta " Ya recibiï¿½ su nueva TdC" es Obligatoria');
            document.frm12.nueva_tdc.focus();
            return false;
        }
    }



    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            alert('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            alert('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            alert('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    alert('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        alert('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    alert('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }


    if (document.frm12.tdc != null) {
        if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
            return false;
        if (!numeros(document.frm12.tdc, "16 Dï¿½gitos TdC"))
            return false;
        if (document.frm12.tdc.value != "") {
            if (!validatarjeta(document.frm12.tdc.value, "16 Dï¿½gitos TdC"))
                return false;
        }
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;


    alert('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".')
    document.frm12.submit();


}

function NoProcesar(solicitud) {
    request = "solicitud=" + solicitud;
    send_post_page(request, "modules.php?mod=validacion&op=process_data&act=3");
}

function ProcesarValidacion() {
    if (document.frm2.nombre != null) {
        if (document.frm2.nombre.value == "") {
            alert('El campo de "Nombre", no debe ir vacio');
            document.frm2.nombre.focus();
            return false;
        }
    }

    if (document.frm2.paterno != null) {
        if (document.frm2.paterno.value == "") {
            alert('El campo de "Paterno", no debe ir vacio');
            document.frm2.paterno.focus();
            return false;
        }
    }
    if (document.frm2.tel_contacto.value == 0) {
        if (document.frm2.otro_contacto.value == "") {
            alert('Debes selecionar un telefono de contacto o capturar el campo Otro')
            document.frm2.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm2.otro_contacto.value != "") {
            document.frm2.otro_contacto.select();
            alert('Ya tienes seleccionado un numero telefonico del combo')
            return false;
        }
    }

    if (document.frm2.email.value != "") {
        var s = document.frm2.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            alert("Ingrese una direccion de correo valida");
            document.frm2.email.focus();
            return false;
        }
    }

    if (document.frm2.actualizar.value == 0) {
        alert('Conteste si desea actualizar sus datos.');
        document.frm2.actualizar.focus();
        return false;
    } else {

        if (document.frm2.edocta.value == 0) {
            alert('La pregunta 3 es  obligatoria.');
            document.frm2.edocta.focus();
            return false;
        }
        if (document.frm2.actualizar.value == 1) {

            if (document.frm2.promo.value == 0) {
                alert('Constesta la pregunta 2')
                return false;
            }

            if (document.frm2.mastdc.value == 0) {
                alert('Constesta la pregunta 4')
                return false;
            }

        }
    }

    if (document.frm2.ejecutivo_venta != null) {
        if (document.frm2.ejecutivo_venta.value == 0) {
            alert('La pregunta 6 es obligatoria.');
            document.frm2.rangopago.focus();
            return false;
        }

        if (document.frm2.folio_carta.value == "") {
            alert('El cliente tiene que proporcionar este folio');
            document.frm2.folio_carta.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc1.value == 0) {
            alert('Contesta SI o NO en la TDC 1');
            document.frm2.tdc1.focus();
            return false;
        }
    }

    if (document.frm2.tdc2 != null) {
        if (document.frm2.tdc2.value == 0) {
            alert('Contesta SI o NO en la TDC 2');
            document.frm2.tdc2.focus();
            return false;
        }
    }

    if (document.frm2.tdc3 != null) {
        if (document.frm2.tdc3.value == 0) {
            alert('Contesta SI o NO en la TDC 3');
            document.frm2.tdc3.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc2 != null) {
            if (document.frm2.tdc3 != null) {
                if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2 && document.frm2.tdc3.value == 2) {
                    alert('Al menos una de las tres TDC debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm2.tdc1 != null && document.frm2.tdc2 != null) {
                    if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2) {
                        alert('Al menos una de las dos TDC debe ser inscripta');
                        document.frm2.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm2.tdc1 != null) {
                if (document.frm2.tdc1.value == 2) {
                    alert('La unica TDC que tiene debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm2.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm2.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_celular, "Telefono Celular"))
        return false;

    alert('La solicitud fue procesada con exito!.');
    document.frm2.submit();
}

// REALIZA LA VALIDACION DE LA SOLICITUD
function ValidaSolicitud() {

    if (document.frm2.tel_contacto.value == 0) {
        if (document.frm2.otro_contacto.value == "") {
            alert('Debes selecionar un Telefono de contacto o capturar el campo Otro')
            document.frm2.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm2.otro_contacto.value != "") {
            document.frm2.otro_contacto.select();
            alert('Ya tienes seleccionado un numero telefonico del combo')
            return false;
        }
    }

    if (document.frm2.email.value != "") {
        var s = document.frm2.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            alert("Ingrese una direccion de correo valida");
            document.frm2.email.focus();
            return false;
        }
    }

    if (document.frm2.actualizar.value == 0) {
        alert('Conteste si desea actualizar sus datos.');
        document.frm2.actualizar.focus();
        return false;
    } else {
        if (document.frm2.subcalificacion != null) {
            if (document.frm2.subcalificacion.value == 0) {
                alert('Selecciona una Sub. Calificacion.');
                document.frm2.subcalificacion.focus();
                return false;
            }
        }

        if (document.frm2.edocta.value == 0) {
            alert('La pregunta 3 es  obligatoria.');
            document.frm2.edocta.focus();
            return false;
        }
        if (document.frm2.actualizar.value == 1) {

            if (document.frm2.promo.value == 0) {
                alert('Constesta la pregunta 2')
                return false;
            }

            if (document.frm2.mastdc.value == 0) {
                alert('Constesta la pregunta 4')
                return false;
            }

        }
    }


    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc1.value == 0) {
            alert('Contesta SI o NO en la TDC 1');
            document.frm2.tdc1.focus();
            return false;
        }
    }

    if (document.frm2.tdc2 != null) {
        if (document.frm2.tdc2.value == 0) {
            alert('Contesta SI o NO en la TDC 2');
            document.frm2.tdc2.focus();
            return false;
        }
    }

    if (document.frm2.tdc3 != null) {
        if (document.frm2.tdc3.value == 0) {
            alert('Contesta SI o NO en la TDC 3');
            document.frm2.tdc3.focus();
            return false;
        }
    }

    if (document.frm2.tdc1 != null) {
        if (document.frm2.tdc2 != null) {
            if (document.frm2.tdc3 != null) {
                if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2 && document.frm2.tdc3.value == 2) {
                    alert('Al menos una de las tres TDC debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm2.tdc1 != null && document.frm2.tdc2 != null) {
                    if (document.frm2.tdc1.value == 2 && document.frm2.tdc2.value == 2) {
                        alert('Al menos una de las dos TDC debe ser inscripta');
                        document.frm2.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm2.tdc1 != null) {
                if (document.frm2.tdc1.value == 2) {
                    alert('La unica TDC que tiene debe ser inscripta');
                    document.frm2.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm2.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm2.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm2.tel_celular, "Telefono Celular"))
        return false;

    document.frm2.submit();


}


// REALIZA LA VALIDACION DE LA SOLICITUD IN
function ValidaSolicitud_PP() {

    if (document.frm12.tel_contacto.value == 0) {
        if (document.frm12.otro_contacto.value == "") {
            alert('Debes selecionar un Telefono de contacto o capturar el campo Otro')
            document.frm12.tel_contacto.focus();
            return false;
        }
    } else {
        if (document.frm12.otro_contacto.value != "") {
            document.frm12.otro_contacto.select();
            alert('Ya tienes seleccionado un numero telefonico del combo')
            return false;
        }
    }

    if (document.frm12.email.value != "") {
        var s = document.frm12.email.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_\-]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {

            alert("Ingrese una direccion de correo valida");
            document.frm12.email.focus();
            return false;
        }
    }

    if (document.frm12.actualizar.value == 0) {
        alert('Conteste si desea actualizar sus datos.');
        document.frm12.actualizar.focus();
        return false;
    } else {
        if (document.frm12.subcalificacion != null) {
            if (document.frm12.subcalificacion.value == 0) {
                alert('Selecciona una Sub. Calificacion.');
                document.frm12.subcalificacion.focus();
                return false;
            }

            if (document.frm12.subcalificacion.value == 20 || document.frm12.subcalificacion.value == 29) {
                var a = 0;
                var ArreFecha = new Array();
                var ArrePegunta = new Array();

                if (document.frm12.fec_comp != null) {
                    ArreFecha[a] = document.frm12.fec_comp.value;
                    ArrePegunta[a] = "Fecha Compromiso";
                    a++;
                }

                for (a = 0; a < ArreFecha.length; a++) {
                    if (!isDate2(ArreFecha[a], "DD/MM/AAAA") && ArreFecha[a].length > 0) {
                        alert("ERROR en la Pregunta \n\n--   " + ArrePegunta[a] + "   --\n\n FORMATO: DD/MM/AAAA ")
                        return false;
                        break;
                    }
                }
                if (document.frm12.fec_comp.value == "") {
                    alert('Para esta Sub. Calificacion: "PAGARA DE INMEDIATO", debes capturar la fecha compromiso.');
                    document.frm12.fec_comp.focus();
                    return false;
                }
            }
        }

        if (document.frm12.rangopago != null) {
            if (document.frm12.rangopago.value == 0) {
                alert('Llene la pregunta de "Cuanto va a pagar?" o "Cuanto pago?".');
                document.frm12.rangopago.focus();
                return false;
            }
        }

        if (document.frm12.edocta.value == 0) {
            alert('La pregunta 3 es  obligatoria.');
            document.frm12.edocta.focus();
            return false;
        }

        if (document.frm12.actualizar.value == 1) {

            if (document.frm12.promo.value == 0) {
                alert('Constesta la pregunta 2')
                return false;
            }

            if (document.frm12.mastdc.value == 0) {
                alert('Constesta la pregunta 4')
                return false;
            }
        }
    }


    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc1.value == 0) {
            alert('Contesta SI o NO en la TDC 1');
            document.frm12.tdc1.focus();
            return false;
        }
    }

    if (document.frm12.tdc2 != null) {
        if (document.frm12.tdc2.value == 0) {
            alert('Contesta SI o NO en la TDC 2');
            document.frm12.tdc2.focus();
            return false;
        }
    }

    if (document.frm12.tdc3 != null) {
        if (document.frm12.tdc3.value == 0) {
            alert('Contesta SI o NO en la TDC 3');
            document.frm12.tdc3.focus();
            return false;
        }
    }

    if (document.frm12.tdc1 != null) {
        if (document.frm12.tdc2 != null) {
            if (document.frm12.tdc3 != null) {
                if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2 && document.frm12.tdc3.value == 2) {
                    alert('Al menos una de las tres TDC debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            } else {
                if (document.frm12.tdc1 != null && document.frm12.tdc2 != null) {
                    if (document.frm12.tdc1.value == 2 && document.frm12.tdc2.value == 2) {
                        alert('Al menos una de las dos TDC debe ser inscripta');
                        document.frm12.tdc1.focus();
                        return false;
                    }
                }
            }
        } else {
            if (document.frm12.tdc1 != null) {
                if (document.frm12.tdc1.value == 2) {
                    alert('La unica TDC que tiene debe ser inscripta');
                    document.frm12.tdc1.focus();
                    return false;
                }
            }
        }
    }

    if (!tamanos(document.frm12.tdc, "Son 16 digitos para la TDC", 16, 16))
        return false;
    if (!numeros(document.frm12.tdc, "16 Dï¿½gitos TdC"))
        return false;
    if (document.frm12.tdc.value != "") {
        if (!validatarjeta(document.frm12.tdc.value, "16 Dï¿½gitos TdC"))
            return false;
    }
    if (!tamanos(document.frm12.tel_alterno, "Telefono Alterno", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_alterno, "Telefono Alterno"))
        return false;
    if (!tamanos(document.frm12.tel_celular, "Telefono Celular", 10, 10))
        return false;
    if (!numeros(document.frm12.tel_celular, "Telefono Celular"))
        return false;

    alert('La solicitud que esta procesando es "' + document.getElementById("id_solicitud").value + '".')
    document.frm12.submit();
}

// VALIDA QUE LOS CAMPOS SEAN SOLO DE TIPO NUMERICO
function numeros(campo, nombre) {
    var valor
    var numeros
    if (campo != null) {
        if (campo.value != "") {
            valor = campo.value;
            numeros = "0123456789";
            for (i = 0; i < valor.length; i++) {
                if (numeros.indexOf(valor.substring(i, i + 1)) < 0) {
                    alert("El campo \"" + nombre + "\" debe tener solamente numeros sin espacios");
                    campo.select();
                    return false;
                }
            }
        }
    }
    return true;
}

// VALIDA LA EDAD DE LOS CONDUCTORES
function validarAdulto(edad, campo) {

    dateUser = edad;
    anioUser = dateUser;
    var dinami_edad = 0;

    dinami_edad = 95;

    if (edad < 18) {
        alert('El usuario es menor de edad, tiene ' + edad + ' aï¿½os. En el campo' + campo)
        return false;
    } else {
        if (edad <= dinami_edad) {
            return true;
        } else {
            alert('El usuario NO tiene la edad requerida, tiene ' + anioUser + ' Aï¿½os. En el campo' + campo);
            return false;
        }
    }

}

//VALIDA LOS TAMAï¿½OS DE LOS DIFERENTES CAMPOS
function tamanos(campo, nombrecampo, log_min, log_max) {
    var a = 0;
    var contDigitos = 0;
    var Arretamano = new Array();
    var ArrePeguntatam = new Array();
    var Arrelongitudmin = new Array();
    var Arrelongitudmax = new Array();
    var arreNumDigitos = new Array();
    var arreNumDigitosTexto = new Array();
    //var banderatamanos=true;

    if (campo != null) {
        Arretamano[a] = campo.value.length;
        ArrePeguntatam[a] = nombrecampo;
        Arrelongitudmin[a] = log_min;
        Arrelongitudmax[a] = log_max;
        a++;
    }

    contDigitos = 0;

    for (a = 0; a < Arretamano.length; a++) {
        if ((Arretamano[a] < Arrelongitudmin[a] && Arretamano[a] > 0) || (Arretamano[a] > Arrelongitudmax[a] && Arretamano[a] > 0)) {
            contDigitos = arreNumDigitos.length;
            if (Arrelongitudmin[a] == Arrelongitudmax[a]) {
                alert(ArrePeguntatam[a] + "  --\n\n Longitud debe ser igual a " + Arrelongitudmax[a])
            } else {
                alert(ArrePeguntatam[a] + "  --\n\n Longitud entre " + Arrelongitudmin[a] + " y " + Arrelongitudmax[a])
            }
            return false;
            break;
        }
    }

    return true;
}

//  LIMITA EL NUMERO DE CARACTERES PERMITIDOS EN EL TEXTAREA DE COMENTARIOS
function limita_texto(limitField, limitCount, limitNum) {
    if (limitField.value.length > limitNum) {
        limitField.value = limitField.value.substring(0, limitNum);
    } else {
        limitCount.value = limitNum - limitField.value.length;
    }
}

// REALIZA EL PROCESO DE AGENDAR EL REGISTRO  #####
function Agenda_registro(/*action,ispredictivo*/action, hora, nombre, solicitud, ispredictivo) {
    console.log(action);
    
    if (document.frm1.comentarios.value == "") {
        Swal.fire('Debes capturar los comentarios para este registro');        
        return false;
    } else if (document.frm1.fecha_agenda.value == "") {
        Swal.fire('Debes capturar la fecha en el que se agenda el registro');        
        return false;
    }

    // Fecha de la agenda no permite dias anteriores
    anio = document.frm1.fecha_agenda.value.substring(6, 10);
    mes = document.frm1.fecha_agenda.value.substring(3, 5);
    dia = document.frm1.fecha_agenda.value.substring(0, 2);
    today = mes + '/' + dia + '/' + anio

    var fecha_cita = new Date(today);
    var now_date = new Date();
    var max_date = new Date();

    /*
     * Quitar para agendar domingos.
     */
    /*
     if (fecha_cita.getDay() == 0) {
     alert("La fecha seleccionada para la agenda no es un dia habil");
     return false;
     }
     */
    now_date.setDate(now_date.getDate() - 1);

    if (fecha_cita < now_date) {
        Swal.fire("La fecha de la agenda no puede ser anterior al dia de hoy");
        return false
    }

    max_date.setDate(max_date.getDate() + 15);

    if (fecha_cita > max_date) {
        Swal.fire("La fecha de la agenda no puede mayor a 15 dias");
        return false
    }

    //return false;

    if (confirm("Se agendara el registro " + solicitud + " de " + nombre + " a las " + hora)) {
        if (ispredictivo == 1) {
            $(function () {
                $("#dialog-proceso").dialog({
                    autoOpen: true,
                    height: 100,
                    width: 350,
                    modal: true,
                    closeOnEscape: false,
                    resizable: false,
                    position: {my: "center"},
                    draggable: false,
                    open: function (event, ui) {
                        jQuery('.ui-dialog-titlebar-close').hide();
                    }
                });
            });
        }
        var valhora = ValidaHorario();
        document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&validahorario=' + valhora ;
        document.frm1.submit();
    }

}

// CANCELA LA ACCION DE AGENDAR REGISTRO
function Cancelar() {
    document.frm3.action = 'modules.php?mod=agentes&op=process_data&act=1'
    document.frm3.submit();
}

// REGRESAR A BUSQUEDA DE CLIENTE IN
function RegresarBusqueda(solicitud, etapa) {
    if (solicitud == 0) {
        document.frm12.action = 'modules.php?mod=agentes&op=index'
        document.frm12.submit();
    } else {
        document.frm12.action = 'modules.php?mod=agentes&op=process_data&act=13&etapa=' + etapa
        document.frm12.submit();
    }
}

// ELIMINA EL REGISTRO AGENDADO
function Elimina_agendado() {
    document.frm3.action = 'modules.php?mod=agentes&op=process_data&act=1'
    document.frm3.submit();
}

function Atras() {
    javascript:history.back();
//javascript:history.back(alert("Este usuario ya existe"));
}

// ACTIVAR SESION DEL USUARIO
function Activar() {
    document.getElementById('resp_act').innerHTML = "";
    if (document.frm1.s_usr_id.value == "") {
        alert('Debes capturar el numero de nomina del usuario');
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";
        s_usr_id = document.frm1.s_usr_id.value;
        request = "s_usr_id=" + s_usr_id;
        send_post_page_n(request, "resp_act", "modules.php?mod=nomina&op=process_data&act=1");
    }

}


// ASIGNACION DE VENTAS
function Busca_Venta() {
    if (document.frm11.id_solicitud.value == "") {
        alert('Debes capturar el numero de Solicitud.');
        return false;
    } else {
        id_solicitud = document.frm11.id_solicitud.value;
        document.frm11.action = 'modules.php?mod=supervisor&op=resultado_venta&sol=' + id_solicitud
        document.frm11.submit();
    }

}

// MUSTRA LA LISTA DE LOS USUARIOS DEL SISTEMA
function Buscar_usuarios() {
    if (document.frm1.nombre.value == "" && document.frm1.id_usuario.value == "") {
        alert('Debes capturar por lo menos un campo para realizar la busqueda');
        return false;
    } else {
        document.frm1.submit();
    }
}

// DA UN SALTO A LA PAGINA ANTERIOR
function Atras() {
    history.back();
}

//SELECCIONA EL ELEMENTO DE UNA BUSQUEDA
function select_elem(objlink, id) {
    if (selection)
        selection.style.fontWeight = 'normal';
    document.fmr2.idSelected.value = id;
    selection = objlink;
    selection.style.fontWeight = 'bold';
    document.getElementById("linkeditar").style.display = 'inline';
    document.getElementById("linknuevo").style.display = 'inline';
}

// VALIDACIONES PARA MOSTRAR EL RERPORTE DE PRODUTIVIDAD
function Mostrar_Reporte() {
    //document.getElementById('resp_act').style.display = "none";

    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        alert('Los campos de fecha estan vacios')
        return false;
    } else {

        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }
        document.getElementById('resp_act').style.display = "inline";
        tipo_reporte = document.frm1.tipo_reporte.value;

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;

        turno = 0;
        request = "tipo_rep=" + tipo_rep + "&fecha_del=" + fecha_del + "&fecha_al=" + fecha_al + '&tipo_reporte=' + tipo_reporte;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=1");
    }
}

// VALIDACIONES PARA MOSTRAR EL RERPORTE DE PRODUTIVIDAD X ZONA Y ETAPA
function Mostrar_Reporte_P() {
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        alert('Los campos de fecha estan vacios')
        return false;
    } else {

        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;

        turno = 0;
        document.frm1.action = 'modules.php?mod=supervisor&op=mostrar_rp'
        document.frm1.submit();
    }
}

//VALIDA EL FORMULARIO PARA MOSTRAR EL LAYOUT
function Mostrar_Layout() {
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        alert('Los campos de fecha estan vacios.')
        return false;
        /*}else if(document.frm1.etapa_layout.value == 0){
         alert('Seleccione un "Tipo de LayOut" para mostrarlo.');
         return false;*/
    } else {
        document.frm1.mostrar_layout.style.display = "none";
        document.frm1.submit();
    }
}

//HABILITA LA OPCION EDITAR DEL MODULO DE ABC USUARIOS
function select(object, id) {
    if (selection)
        selection.style.fontWeight = 'normal';
    document.frm2.idSelected.value = id;
    selection = object;
    selection.style.fontWeight = 'bold';
    document.getElementById("linkeditar").style.display = 'inline';
}

// MUESTRA EL FORMULARIO PARA EDITAR EL REGISTRO SELECCIONADO
function edit_data() {
    document.frm2.submit();
}

// VALIDA EL FORMULARIO PARA LA EDICION DEL USUARIO
function valida_edicion_usuario(dinamic_var) {

    if (dinamic_var == 1) {
        if (document.frm1.idSelected.value == "") {
            alert('Debes capturar el campo Id Usuario');
            return false;
        }
    }

    if (document.frm1.nombre.value == "") {
        alert('Debes capturar el nombre del usuario');
        return false;
    } else if (document.frm1.perfil.value == 0) {
        alert('Debes seleccionar el perfil del usuario');
        return false;
    }

    if (dinamic_var == 1) {
        if (document.frm1.contrasena.value.length == 0 || document.frm1.re_contrasena.value.length == 0) {
            alert('Debes capturar los siguientes campos:\n -Contraseï¿½a.\n -Reescribir contraseï¿½a.');
            return false;
        }
    }

    if (document.frm1.contrasena.value.length != 0) {
        if (document.frm1.re_contrasena.value.length == 0) {
            alert('Debes capturar los 2 campos de contraseï¿½a');
            return false;
        }
    } else {
        if (document.frm1.re_contrasena.value.length != 0) {
            alert('Debes capturar los 2 campos de contraseï¿½a');
            return false;
        }
    }

    if (document.frm1.contrasena.value.length != 0 && document.frm1.re_contrasena.value.length != 0) {
        if (document.frm1.contrasena.value != document.frm1.re_contrasena.value) {
            alert('Las contraseï¿½as no coinciden');
            return false;
        }
    }

    document.frm1.submit();
}

// HABILITA LA LISTA DE SUPERVISORES PARA CUANDO EL PERFIL ES DE AGENTE
function muestra_super(obj) {
    if (obj.value == "A" || obj.value == "AI") {
        document.getElementById('super').style.display = 'inline';
    } else {
        document.getElementById('super').style.display = 'none';
    }
}


//ENVIA AL FORMULARIO PARA DAR DE ALTA EL USUARIO
function nuevo_usuario() {
    document.location = 'modules.php?mod=nomina&op=nuevo_usuario';
}


//ASIGAN UN NUEVO AGENTE A UNA SOLICITUD YA PROCESADA
function Nvo_Agente() {

    if (document.frm3.nuevo_agente.value == null || document.frm3.nuevo_agente.value == 0) {
        alert('Captura el numero de Nomina del nuevo agente');
        document.frm3.nuevo_agente.focus();
        return false;
    }

    if (!tamanos(document.frm3.nuevo_agente, "Nomina del Nuevo Agente", 3, 6))
        return false;
    if (!numeros(document.frm3.nuevo_agente, "Nomina del Nuevo Agente"))
        return false;

    document.frm3.action = 'modules.php?mod=supervisor&op=process_data&act=2'
    document.frm3.submit();
}

function AsignaZona(zona, usuario, obj) {
    if (obj.checked) {
        //alert('Agregar al usuario '+ usuario+'de la zona-->'+zona)
        calificacion = 1;
    } else {
        //alert('Quitar al usuario '+ usuario+'de la zona-->'+zona)
        calificacion = 2;
    }

    request = "izona=" + zona + "&iusr_id=" + usuario + "&calificacion=" + calificacion;
    send_post_page_n(request, "showproc", "modules.php?mod=mesa_control&op=process_data&act=4");


}

function Sub_calif(obj, solicitud, etapa) {
    calif = obj.value;

    document.getElementById('sub_calif').innerHTML = "";
    document.getElementById('sub_calif').style.display = "inline";

    request = "calif=" + calif + "&id_solicitud=" + solicitud + "&id_etapa=" + etapa;
    send_post_page_n(request, "sub_calif", "modules.php?mod=agentes&op=process_data&act=17");
}

//SELECCIONA  TODAS LAS ZONAS
function Todas_Z() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s <= long_; s++) {
        //alert(''+eval('form['+s+'].name')); // Para debugear el codigo
        eval('document.frm1.id_zona' + s).checked = true;
    }
}

//QUITA LA SELECCION A   TODAS LAS ZONAS
function Ning_Z() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s < long_; s++) {
        eval('form.id_zona' + s).checked = false;
    }
}

//SELECCIONA  TODAS LAS ETAPA
function Todas_E() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s <= long_; s++) {
        //alert(''+eval('form['+s+'].name'));
        eval('document.frm1.id_etapa' + s).checked = true;
    }
}

//QUITA LA SELECCION A  TODAS LAS ETAPA
function Ning_E() {
    var form = document.frm1;
    var long_ = form.length;
    for (s = 0; s < long_; s++) {
        eval('form.id_etapa' + s).checked = false;
    }
}

//##### REALIZA LA VALIDACION DE LOS CAMPOS OBLIGATORIOS PARA INICIAR LA BUSQUEDA
function BuscarCliente(boton) {

    if (document.frm1.solicitud.value == "" && document.frm1.nombre.value == "" && document.frm1.paterno.value == "" && document.frm1.materno.value == "" && document.frm1.telefono.value == "") {
        alert('Debes capturar por lo menos un campo para iniciar la busqueda.');
        boton.disabled = false;
        return false;
    }

    if (document.frm1.telefono != null) {
        if (!numeros(document.frm1.telefono, "Telefono"))
            return false;
        if (!tamanos(document.frm1.telefono, "Telefono", 10, 10))
            return false;
    }

    if (document.frm1.solicitud != null) {
        if (!numeros(document.frm1.solicitud, "Solicitud"))
            return false;
        if (!tamanos(document.frm1.solicitud, "Solicitud", 1, 10))
            return false;
    }

    document.frm1.submit();
}

//##### REALIZA LA VALIDACION DE LOS CAMPOS OBLIGATORIOS PARA INICIAR LA BUSQUEDA DE DATOS
function BuscarDatos() {

    /*if(document.frm1.solicitud.value == "" && document.frm1.nombre.value == "" && document.frm1.paterno.value == "" && document.frm1.materno.value == ""  && document.frm1.clave.value == "" && document.frm1.telefono.value == "" && document.frm1.rfc.value == ""){
     alert('Debes capturar por lo menos un campo para iniciar la busqueda.');
     return false;
     }*/
    //alert(document.getElementById("seleccionado").value);
    /*
     if(document.getElementById("seleccionado").value=="1")
     if(document.frm1.nombre.value == "" || (document.frm1.paterno.value == "" && document.frm1.materno.value == "")){
     alert('El nombre y un apellido son obligatorios para iniciar la busqueda.');
     document.frm1.nombre.focus()
     return false;
     }
     if(document.getElementById("seleccionado").value=="2")
     if(document.frm1.solicitud.value == ""){
     alert('Debe capturar la solicitud para iniciar la busqueda.');
     document.frm1.solicitud.focus()
     return false;
     }
     if(document.getElementById("seleccionado").value=="3")
     if(document.frm1.clave.value == ""){
     alert('Debe capturar el folio LUCI para iniciar la busqueda.');
     document.frm1.clave.focus()
     return false;
     }
     if(document.getElementById("seleccionado").value=="4")
     if(document.frm1.telefono.value == ""){
     alert('Debe capturar el nÃºmero de telÃ©fono para iniciar la busqueda.');
     document.frm1.telefono.focus()
     return false;
     }
     if(document.getElementById("seleccionado").value=="5")
     if(document.frm1.rfc.value.length < 10){
     alert('Debe capturar por lo menos los primeros 10 dÃ­gitos del RFC para iniciar la busqueda.');
     document.frm1.rfc.focus()
     return false;
     }
     */
    /*if(document.frm1.solicitud != null){
     if (!numeros(document.frm1.solicitud,"Solicitud")) return false;
     if (!tamanos(document.frm1.solicitud,"Solicitud",1,10)) return false;
     }*/

    document.frm1.submit();
}

//##### OBTIENE LOS DATOS DEL REGISTRO BUSCADO Y LO MUESTRA EN PANTALLA
function mostrar_registro(bandera, u_persona, registro, action, trabajado) {

    if (bandera == 1) {
        alert('La calificacion de este registro no permite mostrar mas informacion.');
        return false;
    } else {
        document.frm1.u_persona.value = u_persona;
        document.frm1.u_registro.value = registro;
        document.frm1.trabajado.value = trabajado;
    }

    if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas Continuar?')) {
        document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
        document.frm1.submit();
    } else {
        return false;
    }
}

//##### VALIDA EL FORMULARIO PARA LA CAPTURA DE UN NUEVO CLIENTE
function nuevo_registro(bandera, boton) {

    if (bandera == 1) {
        if (confirm('Se va a dar de alta un nuevo cliente\nDeseas Continuar?')) {
            document.frm1.action = "modules.php?mod=agentes&op=nuevoregistro";
            document.frm1.submit();
        } else {
            return false;
        }
    } else {
        if (document.frm1.nombre.value == "") {
            alert('Debes capturar el campo Nombre (s)')
            document.frm1.nombre.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.paterno.value == "") {
            alert('Debes capturar el campo Paterno')
            document.frm1.paterno.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.telefono.value == "") {
            alert('Debes capturar el campo Telefono')
            document.frm1.telefono.focus();
            boton.disabled = false;
            return false;
        } else if (document.frm1.lada.value == "") {
            alert('Debes capturar el campo Lada')
            document.frm1.lada.focus();
            boton.disabled = false;
            return false;
        }
        //414, 419, 427, 441, 442, 448, 487.
        /*tel = document.frm1.lada.value+document.frm1.telefono.value;
         if(tel.substring(0,3) == '414'||
         tel.substring(0,3) == '419'||
         tel.substring(0,3) == '427'||
         tel.substring(0,3) == '441'||
         tel.substring(0,3) == '442'||
         tel.substring(0,3) == '448'||
         tel.substring(0,3) == '487'){
         alert('La lada no es permitida-');
         document.frm1.lada.focus();
         boton.disabled = false;
         return false;
         }*/

        if (!tamanos(document.frm1.telefono, "Solo se permite de 7 u 8 digitos para el campo Telefono", 7, 8))
            return false;
        if (!tamanos(document.frm1.lada, "Solo se permite 2 o 3 digitos para el campo lada", 2, 3))
            return false;

        if (!numeros(document.frm1.telefono, "Telefono"))
            return false;
        if (!numeros(document.frm1.lada, "Lada"))
            return false;


        if ((document.frm1.telefono.value.length + document.frm1.lada.value.length) != 10) {
            alert('La suma de lada y telefono es a 10 posiciones');
            return false;
        } else {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=OQ==";
            document.frm1.submit();
        }
    }
}

//##### VALIDA EL FORMULARIO PARA LA CAPTURA DE UN NUEVO CLIENTE
function actualiza_nombre() {

    if (document.frm1.nombre.value == "") {
        alert('Debes capturar el campo Nombre (s)')
        document.frm1.nombre.focus();
        return false;
    } else if (document.frm1.paterno.value == "") {
        alert('Debes capturar el campo Paterno')
        document.frm1.paterno.focus();
        return false;
    } else {
        document.frm1.action = "modules.php?mod=agentes&op=process_data&act=NDQ=";
        document.frm1.submit();
    }
}

function datos_solicitud() {
    if (document.frm1.txt_solicitud.value == "") {
        alert('Debes capturar el nÃºmero de solicitud')
        document.frm1.txt_solicitud.focus();
        return false;
    } else if (document.frm1.txt_producto.value == "") {
        alert('Debes capturar el nÃºmero de producto (generalmente 1)')
        document.frm1.txt_producto.focus();
        return false;
    }

    if (!numeros(document.frm1.txt_solicitud, "Solicitud"))
        return false;
    if (!numeros(document.frm1.txt_producto, "Producto"))
        return false;

    document.frm1.action = "modules.php?mod=agentes&op=process_data&act=MzE=";
    document.frm1.submit();
}


function ActivaZonas(zona, obj) {
    libres = eval('document.frm1.libres' + zona + '.value')
    abandonados = eval('document.frm1.abandonados' + zona + '.value')


    if (obj.checked) {
        if (libres == 0 && abandonados == 0) {
            alert('No puedes activar una zona sin registros libres y abandonados')
            obj.checked = false;
            return false;
        }
        calificacion = 1;
    } else {
        calificacion = 2;
    }

    request = "izona=" + zona + "&calificacion=" + calificacion;
    send_post_page_n(request, "showproc", "modules.php?mod=mesa_control&op=process_data&act=5");
}


function boton_der_deshabilitado() {
    /*
     var message = "";

     function clickIE(){
     if (document.all){
     (message);
     return false;
     }
     }

     function clickNS(e){
     if (document.layers || (document.getElementById && !document.all)){
     if (e.which == 2 || e.which == 3){
     (message);
     return false;
     }
     }
     }

     if (document.layers){
     document.captureEvents(Event.MOUSEDOWN);
     document.onmousedown = clickNS;
     }else{
     document.onmouseup = clickNS;
     document.oncontextmenu = clickIE;
     }

     document.oncontextmenu = new Function("return false")
     return true;*/
}

function actualizar() {
    document.onkeydown = function () {
        if (window.event && (window.event.keyCode == 116)) {
            window.event.keyCode = 505;
        }
        if (window.event && window.event.keyCode == 505) {
            return false;
        }
    }
}


//FUNCION PARA HABILITAR LOS DIFERENTES BOTONES DEPENDIENDO DEL REGISTRO
function habilita_sol(base) {
    document.frm15.btn_solicitud.disabled = true;
    if (base == 1) {
        document.frm15.btn_solicitud.disabled = false;
    }
}


function isDate2_(dateStr, formato) {
    var datePat;
    var matchArray;

    if (formato == "DD/MM/AAAA") {
        datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[3];
        day = matchArray[1];
        year = matchArray[5];
    }

    if (formato == "YYMM") {
        datePat = /^(\d{1,2})(\d{1,2})/;
        matchArray = dateStr.match(datePat); // si formato esta bien
        if (matchArray == null) {
            return false;
        }
        month = matchArray[2];
        year = matchArray[1];
    }

    if (year.length < 4) {
        return false;
    } // chequeo de numero de digitos en A?
    if (year >= 2079) {
        return false;
    } // chequeo del A? para smalldate
    if (month < 1 || month > 12 || month.length < 2) {
        return false;
    } // checa rango mes
    if (day < 1 || day > 31 || day.length < 2) {
        return false;
    }
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
        return false;
    }
    if (month == 2) { // check para febrero 29
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}


//REALIZA LA BUSQUEDA DE CODIGOS POSTALES
function search_cp(p_cp) {
    if (p_cp == null) {
        re_cp = 0;
    } else {
        re_cp = p_cp
    }
    var re_cp;
    var myvar;
    myvar = "top=400,left=550,resizable=no,width=680,height=350,toolbar=no,location=0,status=no,directories=no,scrollbars=yes,menubar=no"
    cp_window = window.open("modules.php?mod=agentes&op=codigos_postales&p_cp=" + re_cp, "cp_window", myvar);

}

//### CALCULA EL RFC DEL CLIENTE
// function calcula_rfc() {
//     if (document.getElementById('nombre').value == "") {
//         alert("Debes capturar el Nombre");
//         return false;
//     } else if (document.getElementById('paterno').value == "") {
//         alert("Debes capturar el apellido Paterno");
//         return false;
//     } else if (document.getElementById('fecha_nac').value == "") {
//         alert("Debes capturar la fecha de nacimiento");
//         return false;
//     } else if (document.getElementById('fecha_nac').value.length > 0) {
//         if (!isDate(document.getElementById('fecha_nac').value)) {
//             alert("El formato de fecha no es correcto");
//             return false;
//         } else {
//             document.getElementById('loading').style.display = "inline";
//             nombre = document.getElementById('nombre').value;
//             paterno = document.getElementById('paterno').value;
//             materno = document.getElementById('materno').value;
//             fecha_nac = document.getElementById('fecha_nac').value;
//             request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac;
//             send_post_page_rfc(request, "RFC", "modules.php?mod=agentes&op=process_data&act=20");
//         }
//     }
// }

// VALIDA EL FORMATO DE FECHA
function isDate(dateStr) {
    var datePat;
    var matchArray;
    datePat = /^(\d{1,2})(\/)(\d{1,2})(\/)(\d{4})$/;
    matchArray = dateStr.match(datePat); // si formato esta bien
    if (matchArray == null) {
        return false;
    }
    month = matchArray[3];
    day = matchArray[1];
    year = matchArray[5];

    if (year.length < 4)
        return false;
    if (year >= 2079)
        return false;
    if (year <= 1900)
        return false;
    if (month < 1 || month > 12 || month.length < 2)
        return false;
    if (day < 1 || day > 31 || day.length < 2)
        return false;
    if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31)
        return false;
    if (month == 2) {
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day == 29 && !isleap)) {
            return false;
        }
    }
    return true;
}

//### Envia datos por ajax para corroborar datos
function send_post_page_rfc(request, container, page, valor) {
    var contenedor;
    //contenedor = document.getElementById(container);
    contenedor = eval('document.SurveyResponse.' + container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            // alert(ajax.responseText.substr(0,7));
            if (ajax.responseText.substr(0,7) == "000-000") {
                contenedor.value = ajax.responseText.substr(7, 13);
                $("#btn_continue").hide();
                $("#btn_save").hide();
                //$("#rfc_e").html(ajax.responseText.substr(21));
                // document.getElementById('btn_continue').style.display = "none";
                // document.getElementById('btn_save').style.display = "none";
                // document.getElementById('rfc_e' + valor).innerHTML = ajax.responseText.substr(21);
            } else if (ajax.responseText.substr(0, 7) == "000-001") {
                contenedor.value = ajax.responseText.substr(7, 13);
                /*document.getElementById('btn_continue').style.display = "none";
                 document.getElementById('btn_save').style.display = "none";*/
                //document.getElementById('rfc_e' + valor).innerHTML = ajax.responseText.substr(21);
            } else {
                contenedor.value = ajax.responseText;
                document.getElementById('btn_continue').style.display = "inline";
                document.getElementById('btn_save').style.display = "inline";
                //document.getElementById('rfc_e' + valor).innerHTML = "";
            }
            //candado23(eval("document.getElementById('FECHA_NAC" + valor + "').value"));
        }

    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

//### VALIDA LA LONGITUD DEL CODIGO POSTAL PARA HACER LA BUSQUEDA
function valida_cp() {
    if (document.frm1.p_cp.value.length < 5) {
        alert('La longitud del Codigo postal debe ser de 5 posisciones');
        return false;
    } else {
        if (!numeros(document.frm1.p_cp, "Codigo Postal"))
            return false;
    }
    document.frm1.submit();
}

//### REGRESA LOS PARAMETROS DE LA BUSQUEDA DE CP A LA PAGINA PRINCIPAL
function resultados_cp(r_id_codigo, r_cp, r_colonia, r_municipio, r_estado) {
    window.parent.opener.document.frm1.id_codigo.value = r_id_codigo
    window.parent.opener.document.frm1.cp.value = r_cp;
    window.parent.opener.document.frm1.colonia.value = r_colonia
    window.parent.opener.document.frm1.municipio.value = r_municipio;
    window.parent.opener.document.frm1.estado.value = r_estado;
    self.close();
}

// ### funcion que valida el campo correo
function valida_mail(mail) {
    bandera = true;
    if (mail.value != "") {
        var s = mail.value;
        var filter = /^[A-Za-z0-9][A-Za-z0-9_.\-]*@[A-Za-z0-9_]+\.[A-Za-z0-9_.\-]+[A-za-z]$/;
        if (!filter.test(s)) {
            bandera = false;
        }
    }
    return bandera;
}

// ### REGRESAR A LA PAGINA DE SI CONTACTO
function regresar_no_contacto() {
    document.SurveyResponse.action = 'modules.php?mod=agentes&op=index'
    document.SurveyResponse.submit();
}

function calificar_si_contacto(boton, u_persona, action, ispredictivo, nomina, solicitud, no_autentica=null){
    document.SurveyResponse.action = '';
    //console.log('califica_si', action); 
    var tipoBase = $('#iniciativasL4').val();    
    var surveyid = $('#survey_id').val();
    
    if(parseInt(no_autentica)==201){
        document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&no_autentica=' + no_autentica;
        document.SurveyResponse.submit();

    } else if(document.SurveyResponse.si_contacto.value == 0){
        Swal.fire("Debes seleccionar una calificacion");
        boton.disabled = false;
        return false;

    // } else if(document.SurveyResponse.si_contacto.value == 10000){
    //     document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=MjA=';
    //     request = "act=MjE=&u_persona=" + u_persona;//21
    //     send_post_page_valida_capturada(request, "modules.php?mod=agentes&op=process_data&act=MjE=");

    } else if(document.SurveyResponse.si_contacto.value == 406 || document.SurveyResponse.si_contacto.value == 407){
        document.SurveyResponse.action = 'modules.php?mod=agentes&op=agenda';
        document.SurveyResponse.submit();

    }else{
        if(tipoBase == 'L4' && surveyid == '1'){ 
            var resultadoValL4 = validaCamposL4();
            if(resultadoValL4 == false){
                boton.disabled = false;
                return false;
            }
        }     

        
        if (ispredictivo == 1){
            $(function(){
                $("#dialog-proceso").dialog({
                    autoOpen: true,
                    height: 100,
                    width: 350,
                    modal: true,
                    closeOnEscape: false,
                    open: function (event, ui) {
                        jQuery('.ui-dialog-titlebar-close').hide();
                    }
                });
            });
        }

        colgar_asistido(2, action, nomina, solicitud);
        //document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
        // document.SurveyResponse.submit();

 

    }

    //alert(document.frm1.si_contacto.value);


    return false;
   
    document.SurveyResponse.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
    document.SurveyResponse.submit();

    return false;
}

// VALIDA LAS EXTENSIONES PERMITIDAS ASI COMO LOS CAMPOS OBLIGATORIOS PARA LA CARGA DE ARCHIVOS
function validaFicheroForm() {
    if (document.frm1.fichero.value.length == 0) {
        Swal.fire('Para continuar, ingresa la ruta donde se encuentra el archivo que deseas cargar.');              
        return false;
    } else {
        extensiones_permitidas = new Array(".txt", ".csv");
        extension1 = (document.frm1.fichero.value.substring(document.frm1.fichero.value.lastIndexOf("."))).toLowerCase();
        permitida = false;

        for (var i = 0; i < extensiones_permitidas.length; i++) {
            if (extensiones_permitidas[i] == extension1) {
                permitida = true;
                break;
            }
        }

        if (!permitida) {
            alert('El archivo que intentas cargar no es correcto.\nSolo se pueden Adjuntar archivos de tipo:' + extensiones_permitidas.join());
            return sel;
        } else {
            document.frm1.continuar.style.visibility = "hidden";
            document.frm1.submit();
        }
    }
}


// VALIDA EL FORMULARIO PARA CLASIFICAR LOS DATOS
function validaFormEstatus(registros) {
    if (registros > 0) {
        document.frm1.continuar.style.visibility = "hidden";
        document.frm1.submit();
    } else {
        alert('No se puede ejecutar esta accion sin registros');
        return false;
    }
}

function ShowSolicitud() {
    var u_persona = document.frm1.u_persona.value;
    var u_registro = document.frm1.u_registro.value;
    request = "action=1&u_persona=" + u_persona + "&u_registro=" + u_registro;
    send_post_page_n(request, "script", "modules.php?mod=agentes&op=cuestionarion_1");
}

//Permite realizar la grabacion
function GuardaValidando() {
    var u_persona = document.frm1.u_persona.value;
    var u_registro = document.frm1.u_registro.value;
    request = "act=21&u_persona=" + u_persona + "&u_registro=" + u_registro;
    send_post_page_valida_capturada(request, "modules.php?mod=agentes&op=process_data&act=21");
}


// CALIFICA LOS TELEFONOS CON AJAX
function send_post_page_valida_capturada(request, page) {
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            if (ajax.responseText == '0') {
                alert("No se puede realizar esta accion, porque la solicitud aun no se procesa..")
                return false;
            } else {
                document.frm1.submit();
            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

// CONTINUAR CON LA AGENDA
function Continuar_Agenda() {
    if (document.frm1.fecha_busqueda.value == "") {
        alert('Debes capturar el campo de fecha');
        return false;
    }

    document.frm1.submit();
}

// CONTINUAR CON 01800
function Continuar_01800() {
    if (document.frm1.fecha_busqueda.value == "") {
        alert('Debes capturar el campo de fecha');
        return false;
    }

    document.frm1.submit();
}


// Cancela la accion de agendar registro #####
function Cancelar_agenda(action) {
    document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action;
    document.frm1.submit();
}

function Mostrar_agendado(existe, registro, u_persona, action) {
    document.frm1.u_persona.value = "";
    document.frm1.u_registro.value = "";
    if (existe == 0) {
        document.frm1.u_persona.value = u_persona;
        document.frm1.u_registro.value = registro;

        if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm1.submit();
        } else {
            return false;
        }
    } else {
        alert('Necesitas abandonar el registro actual');
        return false;
    }
}

function Mostrar_agendado2(existe, registro, u_persona, action, trabajado) {
    document.frm1.u_persona.value = "";
    document.frm1.u_registro.value = "";
    if (existe == 0) {
        document.frm1.u_persona.value = u_persona;
        document.frm1.u_registro.value = registro;
        document.frm1.trabajado.value = trabajado;

        if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm1.submit();
        } else {
            return false;
        }
    } else {
        alert('Necesitas abandonar el registro actual');
        return false;
    }
}

function Mostrar_agendado3(existe, registro, u_persona, action) {
    document.frm3.u_persona.value = "";
    document.frm3.u_registro.value = "";

    if (existe == 0) {
        document.frm3.u_persona.value = u_persona;
        document.frm3.u_registro.value = registro;

        if (confirm('Se mostrara el siguiente registro en pantalla\nDeseas continuar?')) {
            document.frm3.action = "modules.php?mod=agentes&op=process_data&act=" + action;
            document.frm3.submit();
        } else {
            return false;
        }
    } else {
        alert('Necesitas abandonar el registro actual');
        return false;
    }
}

// BOTON PARA ENVIAR AL FORMULARIO PARA LA CAPTURA DE UN NUEVO NUMERO TELEFONICO
function Agregar_Telefono(boton) {
    if (confirm('Se va a agregar un nuevo numero telefonico\nDeseas Continuar?')) {
        document.frm1.action = "modules.php?mod=agentes&op=nuevo_telefono";
        document.frm1.submit();
    } else {
        boton.disabled = false;
        return false;
    }
}

// BOTON PARA ENVIAR AL AVISO DE PRIVACIDAD
function Aviso_privacidad(boton) {
    if (confirm('Se enviara al aviso de privacidad, terminara tu llamada...\n¿Estas seguro?')) {
//        jQuery("#inicio").attr("class", "menulink2");
//        jQuery("#inicio").attr("disabled", "disabled");

        $.post("modules.php?mod=agentes&op=process_data&act=NDY=", {//46
        }, function (data, status) {
            //alert(data);
        });
    } else {
        boton.disabled = false;
        return false;
    }
}

// BOTON PARA ENVIAR AL FORMULARIO PARA LA ACTUALIZACION DE NOMBRE
function Actualizar_Nombre(boton) {
    if (confirm('Debe ingresar los datos correctos del cliente que contesto,\nSí aun no cuenta con el nombre real del cliente, presione cancelar!!!\nDeseas Continuar?')) {
        document.frm1.action = "modules.php?mod=agentes&op=actualiza_nombre";
        document.frm1.submit();
    } else {
        boton.disabled = false;
        return false;
    }
}


// BOTON PARA ENVIAR AL FORMULARIO PARA LA CAPTURA DE UN NUEVO NUMERO TELEFONICO
function Valida_Telefono(action) {


    if (document.frm1.lada.value == "") {
        alert("Debes capturar el campo Lada");
        return false;
    } else if (document.frm1.telefono.value == "") {
        alert("Debes capturar el campo Telefono");
        return false;
    }

    //414, 419, 427, 441, 442, 448, 487.
    /*tel = document.frm1.lada.value+document.frm1.telefono.value;
     if(tel.substring(0,3) == '414'||
     tel.substring(0,3) == '419'||
     tel.substring(0,3) == '427'||
     tel.substring(0,3) == '441'||
     tel.substring(0,3) == '442'||
     tel.substring(0,3) == '448'||
     tel.substring(0,3) == '487'){
     alert('La lada no es permitida-');
     document.frm1.lada.focus();

     return false;
     }*/
    //alert(count_tel);

    if (count_tel >= 3) {
        alert("Se han superado el ingreso de numeros telefonicos.");
        return false;
    }

    if (tel_valido_9 == 0) {
        alert("El Telefono es invalido, favor de verificarlo")
        return false;
    }

    if (!numeros(document.frm1.lada, "LADA")) {
        return false;
    }
    if (!numeros(document.frm1.telefono, "TELEFONO")) {
        return false;
    }

    if ((document.frm1.telefono.value.length + document.frm1.lada.value.length) < 10) {
        alert('La suma de lada y telefono es a 10 posiciones');
        return false;
    } else {
        document.frm1.action = "modules.php?mod=agentes&op=process_data&act=" + action;
        document.frm1.submit();
    }
}


//### Envia datos por ajax para corroborar datos DEL CP
function send_post_page_cp1(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
//            alert(ajax.responseText.substr(0,1));
            /*if(id == 1){
                v_cobertura_casa = ajax.responseText.substr(0,1);
                if(ajax.responseText.substr(0,1) == 0){
                    alert("CP sin cobertura");
                    document.getElementById("cp_"+id).innerHTML = "<font color='red'>CP sin cobertura</font>";
                }else{
                    document.getElementById("cp_"+id).innerHTML = "<font color='green'>CP con cobertura</font>";
                }
            }else if (id == 2){
                v_cobertura_empresa = ajax.responseText.substr(0,1);
                if(ajax.responseText.substr(0,1) == 0){
                    alert("CP sin cobertura");
                    document.getElementById("cp_"+id).innerHTML = "<font color='red'>CP sin cobertura</font>";
                }else{
                    document.getElementById("cp_"+id).innerHTML = "<font color='green'>CP con cobertura</font>";
                }
            }*/
            contenedor.innerHTML = ajax.responseText.substr(1);
//            if (ajax.responseText.substr(0, 17) == '<option value=-1>' && id == 1) {
//                document.getElementById('btn_continue').style.display = "none";
//
//            } else {
//                document.getElementById('btn_continue').style.display = "inline";
//            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

function send_post_page_cp2(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax1 = nuevoAjax();
    ajax1.open("POST", page, true);
    ajax1.onreadystatechange = function () {
        if (ajax1.readyState == 4) {
            contenedor.innerHTML = ajax1.responseText

            $('#CIUDAD'+id).html(ajax1.responseText);

            document.getElementById(boton).style.display = "inline";
            if (valor_loading == 1) {
                document.body.removeChild(document.getElementById('div_padre'));
            }
        }
    }
    ajax1.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax1.send(request);
}

function send_post_page_cp3(request, container, boton, page, valor_loading, id) {
    var contenedor;
    contenedor = document.getElementById(container);

    ajax2 = nuevoAjax();
    ajax2.open("POST", page, true);
    ajax2.onreadystatechange = function () {
        if (ajax2.readyState == 4) {
            contenedor.innerHTML = ajax2.responseText
            document.getElementById(boton).style.display = "inline";
            if (valor_loading == 1) {
                // document.body.removeChild(document.getElementById('div_padre'));
            }
        }
    }
    ajax2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax2.send(request);
}

function loading_fun() {
    Html = '<div id="ajControl" width="100%">' +
            '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
            '<tr id="ajControlBody">' +
            '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

    var div = document.createElement('div');
    div.id = 'div_padre';
    div.innerHTML = Html;

    document.body.appendChild(div);
}

//### CALCULA EL RFC DEL CLIENTE
function Generar_1(valor) {
    var nombre, paterno, materno, fecha_nac;
    //Nombre
    if (eval("document.getElementById('nombrepila" + valor + "')") != null) {
        if (eval("document.getElementById('nombrepila" + valor + "').value") == "") {
            alert("Debes capturar el Nombre");
            return false;
        } else {
            nombre = eval("document.getElementById('nombrepila" + valor + "').value");
        }
    }

    //Segundo nombre
    if (eval("document.getElementById('nombreseg" + valor + "')") != null) {
        if (eval("document.getElementById('nombreseg" + valor + "').value") != "") {
            nombre += ' ' + eval("document.getElementById('nombreseg" + valor + "').value");
        }
    }

    //Apellido paterno
    if (eval("document.getElementById('appaterno" + valor + "')") != null) {
        if (eval("document.getElementById('appaterno" + valor + "').value") == "") {
            alert("Debes capturar el Apellido Paterno");
            return false;
        } else {
            paterno = eval("document.getElementById('appaterno" + valor + "').value");
        }
    }

    //Apellido materno
    if (eval("document.getElementById('apmaterno" + valor + "')") != null) {
        if (eval("document.getElementById('apmaterno" + valor + "').value") != "") {
            materno = eval("document.getElementById('apmaterno" + valor + "').value");
        }
    }

    //Fecha de nacimiento
    if (eval("document.getElementById('fechanacimiento" + valor + "')") != null) {
        if (eval("document.getElementById('fechanacimiento" + valor + "').value") == "") {
            alert("Debes capturar la fecha de nacimiento");
            return false;
        } else {
            fecha_nac = eval("document.getElementById('FECHA_NAC" + valor + "').value");
        }
    }

    //---document.getElementById('Generar').style.display = "none";
    request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac;
    send_post_page_rfc(request, "RFC" + valor, "modules.php?mod=agentes&op=process_data&act=MjM=");
}

function submitCP(id, valor_cp) {
    if (valor_cp.value == "") {
        alert("Favor de escribir el CP de la Direccion ");
        return false;
    } else {
        if (!/^([0-9])*$/.test(valor_cp.value)) {
            alert("El CP debe ser numerico de la Direccion ");
            return false;
        } else {
            if (!tamanos(valor_cp, "CP", 5, 5)) {
                alert("El CP debe ser de 5 diguitos");
                return false;
            }
        }

        //loading_fun();

        $("#ESTADO" + id).html("");
        $("#MUNICIPIO" + id).html("");
        $("#COLONIA" + id).html("");

        // document.getElementById("ESTADO" + id).innerHTML = "";
        // document.getElementById("MUNICIPIO" + id).innerHTML = "";
        // document.getElementById("COLONIA" + id).innerHTML = "";

        var boton = 'CP' + id;
        $(boton).hide();
        // document.getElementById(boton).style.display = "none";
        cp_ = valor_cp.value;
        request = "cp=" + cp_ + "&id=" + id;
        //alert(request);
        send_post_page_cp1(request, "ESTADO" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjQ=", 0, id);//24
        send_post_page_cp2(request, "MUNICIPIO" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjU=", 0, id);//25
        send_post_page_cp3(request, "COLONIA" + id, boton, "modules.php?mod=agentes&op=process_data&act=MjY=", 1, id);//26
    }
    return false;
}

function comprueba_RFC(valor) {
    var nombre, paterno, materno, fecha_nac, contador = 0;
    //alert(valor);
    //Nombre
    if (eval("document.getElementById('nombrepila" + valor + "')") != null) {
        if (eval("document.getElementById('nombrepila" + valor + "').value") != "") {
            contador += 1;
            nombre = eval("document.getElementById('nombrepila" + valor + "').value");
        }
    }

    //Segundo nombre
    if (eval("document.getElementById('nombreseg" + valor + "')") != null) {
        if (eval("document.getElementById('nombreseg" + valor + "').value") != "") {
            nombre += ' ' + eval("document.getElementById('nombreseg" + valor + "').value");
        }
    }

    //Apellido paterno
    if (eval("document.getElementById('appaterno" + valor + "')") != null) {
        if (eval("document.getElementById('appaterno" + valor + "').value") != "") {
            contador += 1;
            paterno = eval("document.getElementById('appaterno" + valor + "').value");
        }
    }

    //Apellido materno
    if (eval("document.getElementById('apmaterno" + valor + "')") != null) {
        if (eval("document.getElementById('apmaterno" + valor + "').value") != "") {
            materno = eval("document.getElementById('apmaterno" + valor + "').value");
        }
    }

    //Fecha de nacimiento
    if (eval("document.getElementById('fechanacimiento" + valor + "')") != null) {
        if (eval("document.getElementById('FECHA_NAC" + valor + "').value") != "") {
            contador += 1;
            fecha_nac = eval("document.getElementById('fechanacimiento" + valor + "').value");

            if (!isDate2(fecha_nac, "DD/MM/AAAA")) {
                alert("[ERROR!] Fecha Incorrecta");
                contador -= 1;
            }

        }
    }
    //alert(contador);
    if (contador == 3) {
        //alert("entro");
        document.getElementById('rfc_e' + valor).innerHTML = "";
        request = "action=5&nombre=" + nombre + "&paterno=" + paterno + "&materno=" + materno + "&fecha_nac=" + fecha_nac + "&num_reconocedor=" + valor;
        send_post_page_rfc(request, "RFC" + valor, "modules.php?mod=agentes&op=process_data&act=MjM=", valor);
    }

}

// function candado23(fecha) {
//     if (fecha != null) {
//         var fecha2 = fecha.split("/");
//         var fechaf = fecha2[2] + fecha2[1] + fecha2[0];
//         var f = new Date();
//         var mesact = f.getMonth() + 1;
//         var diaact = f.getDate();
//         if (diaact < 10) {
//             diaact = "0" + diaact;
//         }
//         if (mesact < 10) {
//             mesact = "0" + mesact;
//         }

//         var hoy = diaact + "/" + (mesact) + "/" + f.getFullYear();
//         var hoy2 = hoy.split("/");
//         var hoy3 = hoy2[2] + hoy2[1] + hoy2[0];

//         var ed = (hoy3 - fechaf) / 10000;
//         //console.log(ed);
//         //console.log(ed);
//         if (ed < 22.9900) {
//             alert("Cliente No cumple con la edad minima requerida");
//             document.getElementById('btn_continue').style.display = "none";
//             document.getElementById('btn_continue').disabled = true;
//             return false;
//         } else {
//             document.getElementById('btn_continue').style.display = "inline";
//             document.getElementById('btn_continue').disabled = false;
//         }
//     }
// }

function ObtenerMunicipios() {
    document.frm1.action = '';
    document.frm1.submit();
}

function seg_agente() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.nomina.value == "") {
        alert("El nÃºmero de nÃ³mina estÃ¡ vacÃ­o");
        document.frm1.nomina.focus();
        return false;
    }
    if (document.frm1.fecha_del.value == "" || document.frm1.fecha_al.value == "") {
        alert('Los campos de fecha estan vacios');
        document.frm1.fecha_del.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";
        var i;
        for (i = 0; i < document.frm1.tipo_rep.length; i++) {
            if (document.frm1.tipo_rep[i].checked) {
                tipo_rep = document.frm1.tipo_rep[i].value;
                break;
            }
        }
        document.getElementById('resp_act').style.display = "inline";

        fecha_del = document.frm1.fecha_del.value;
        fecha_al = document.frm1.fecha_al.value;
        nomina = document.frm1.nomina.value;

        request = "nomina=" + nomina + "&tipo_rep=" + tipo_rep + "&fecha_del=" + fecha_del + "&fecha_al=" + fecha_al;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=3");
    }
}

function seg_solicitud() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.solicitud.value == "") {
        alert("El nÃºmero de solicitud estÃ¡ vacÃ­o");
        document.frm1.solicitud.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";

        solicitud = document.frm1.solicitud.value;

        request = "solicitud=" + solicitud;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=4");
    }
}

function revivir_solicitud() {
    document.getElementById('resp_act').style.display = "none";
    document.getElementById('resp_act').innerHTML = '<img src="' + linkpath + 'includes/imgs/loading.gif">';
    document.getElementById('resp_act').style.display = "inline";

    if (document.frm1.solicitud.value == "") {
        alert("El nÃºmero de solicitud estÃ¡ vacÃ­o");
        document.frm1.solicitud.focus();
        return false;
    } else {
        document.getElementById('resp_act').style.display = "inline";

        solicitud = document.frm1.solicitud.value;

        request = "solicitud=" + solicitud;
        send_post_page_n(request, "resp_act", "modules.php?mod=supervisor&op=process_data&act=5");
    }
}

function habilitar(boton) {
    //document.getElementById('seleccionado').value = boton;
    switch (boton) {
        case "1":
            document.getElementById('nombre').disabled = false;
            document.getElementById('paterno').disabled = false;
            document.getElementById('materno').disabled = false;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('nombre').focus();
            break;
        case "2":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = false;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('solicitud').focus();
            break;
        case "3":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = false;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = true;
            document.getElementById('clave').focus();
            break;
        case "4":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = false;
            document.getElementById('rfc').disabled = true;
            document.getElementById('telefono').focus();
            break;
        case "5":
            document.getElementById('nombre').disabled = true;
            document.getElementById('paterno').disabled = true;
            document.getElementById('materno').disabled = true;
            document.getElementById('solicitud').disabled = true;
            document.getElementById('clave').disabled = true;
            document.getElementById('telefono').disabled = true;
            document.getElementById('rfc').disabled = false;
            document.getElementById('rfc').focus();
            break;
        default:
            alert("No seleccionaste opciÃ³n");
    }
}

function liberar_registro(id_solicitud) {
    if (confirm("Â¿Deseas liberar el registro " + id_solicitud + "?")) {
        request = "solicitud=" + id_solicitud;
        document.getElementById('resp_act').style.display = "inline";
        send_post_page_n(request, "resp_act", "modules.php?mod=agentes&op=process_data&act=MzQ="); // 34
    }
}

function avisoPrivacidad(sApellido, inicio) {
    if (inicio == "y") {
        var aviso = "Aviso de Privacidad\n\n";
        aviso = aviso + "Sr./Srita. " + sApellido + ":\n\
Le informamos que en Banco INVEX S.A., con domicilio en:\n\n\
Boulevard Manuel Ávila Camacho #40,\n\
Col. Lomas de Chapultepec,\n\n\
sus datos personales están protegidos y serán utilizados\n\
para tramitar su TDC VOLARIS-INVEX. Para mayor información\n\
podrá consultar nuestro Aviso de Privacidad en www.invextarjetas.com.mx";

        alert(aviso);
        //return aviso;
    }
}

function revisa_calificacion(combo, tipo, referente, telefono) {
//    var calificacion = combo.value;
    // alert(tipo);
    //alert(SurveyResponse.cont.value);

    var referido = false;
    var calificacion = combo.value;
    var pregunta = "";
    if (tipo == 1) {
//        pregunta = "¿Deseas agregar un contacto distinto?";
        pregunta = "Que lastima que no tuve suerte de encontrarlo, mi nombre es (mencionar nombre y apellido) de Volaris Invex la intención de mi llamada era para informarle que por lanzamiento se le está invitando a adquirir nuestra tarjeta Volaris un año por medio de la cual puede ser acreedor a grandes descuentos que les haremos llegar vía correo electrónico y podrá tener viajes por medio de la aerolínea sin costo, no se si usted ha viajado o ha escuchado de la aerolínea Volaris.\n\
        Perfecto, esta tarjeta la podemos hacer extensiva para usted la cual tiene un bono de bienvenida de $1,200 y por cada compra que usted realice se le estará bonificando en su monedero electrónico para que comience a viajar a costos muy bajos y como cliente preferencial ya que...";
    } else {
//        pregunta = "¿Deseas agregar un recomendado?";
        pregunta = "¡No concluyas ahí, pregunta por alguna otra persona que le interese!\n\n\
¿Obtuve un recomendado?";
    }

    if (combo.options[combo.selectedIndex].text.indexOf("[R]") >= 0) {
        if (tipo == 1 || tipo == 2) {
            if (confirm(pregunta)) { ////
                referido = true;
            } ////
        } else {
            referido = false;
        }
        if (referido == true) { //subcalificaciones
            window.location = "modules.php?mod=agentes&op=nuevoregistro&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono + "&cont=" + frm1.cont.value;
        }
    }

    for (i = 1; i <= frm1.cont.value; i++) {
        tel = (i < 10 ? "0" + i : i);
        document.getElementById("tel_" + tel).disabled = false; //Habilitar todos los combos
    }
    if (combo.value == "1010") {
        for (i = 1; i <= frm1.cont.value; i++) {
            tel = (i < 10 ? "0" + i : i);
            flag = true;
            if (combo.name == "tel_" + tel) {
                flag = false;
            }
            document.getElementById("tel_" + tel).disabled = flag; //Deshabilitar los no 1010
        }
    }
}

function revisa_calificacion_test(combo, tipo, referente, telefono, num) {
//    var calificacion = combo.value;
    // alert(tipo);
    //alert(SurveyResponse.cont.value);

    var referido = false;
    var cliente_molesto = false;
    var calificacion = combo.value;
    var pregunta = "";
    if (tipo == 1) {
//        pregunta = "¿Deseas agregar un contacto distinto?";
        pregunta = "Que lastima que no tuve suerte de encontrarlo, mi nombre es (mencionar nombre y apellido) de Volaris Invex la intención de mi llamada era para informarle que por lanzamiento se le está invitando a adquirir nuestra tarjeta Volaris un año por medio de la cual puede ser acreedor a grandes descuentos que les haremos llegar vía correo electrónico y podrá tener viajes por medio de la aerolínea sin costo, no se si usted ha viajado o ha escuchado de la aerolínea Volaris.\n\
        Perfecto, esta tarjeta la podemos hacer extensiva para usted la cual tiene un bono de bienvenida de $1,200 y por cada compra que usted realice se le estará bonificando en su monedero electrónico para que comience a viajar a costos muy bajos y como cliente preferencial ya que...";
    } else {
//        pregunta = "¿Deseas agregar un recomendado?";
        pregunta = "¡No concluyas ahí, pregunta por alguna otra persona que le interese!\n\n\
¿Obtuve un recomendado?";
    }

    if (combo.options[combo.selectedIndex].text.indexOf("[R]") >= 0) {
/*
        if (tipo == 1 || tipo == 2) {
            //if (confirm(pregunta)) { ////
            referido = true;
            //} ////
        } else {
            referido = false;
        }
        if (referido == true) { //subcalificaciones
            avisoPrivacidadImpulse();
            window.location = "modules.php?mod=agentes&op=subcalificaciones&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono + "&cont=" + frm1.cont.value + "&num=" + num;
        }
*/
        if (tipo == 1 || tipo == 2) {
            if (confirm("¿Deseas agregar un recomendado?")) {
                referido = true;
            }
        } else {
            referido = false;
        }
        if (referido == true) {
            window.location = "modules.php?mod=agentes&op=nuevoregistro&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono;
        }
    }

    //Bloqueo de clientes muy molestos
    if (combo.options[combo.selectedIndex].text.indexOf("[B]") >= 0) {
        if (confirm("¿Estas seguro de calificar como 'CLIENTE MUY MOLESTO'?")) {
            cliente_molesto = true;
        } else {
            cliente_molesto = false;
        }

        if (cliente_molesto == true) {
            avisoPrivacidadImpulse_bloqueo();
            window.location = "modules.php?mod=agentes&op=process_data&act=NjAw";
        }
    }


    if (combo.options[combo.selectedIndex].text.indexOf("[N]") >= 0) {
//		process_subcalificacion(2, 0, 0, "NDI=", combo.options[combo.selectedIndex].value, 0, num);
    }






    for (i = 1; i <= frm1.cont.value; i++) {
        tel = (i < 10 ? "0" + i : i);
        document.getElementById("tel_" + tel).disabled = false; //Habilitar todos los combos
    }
    if (combo.value == "1010") {
        for (i = 1; i <= frm1.cont.value; i++) {
            tel = (i < 10 ? "0" + i : i);
            flag = true;
            if (combo.name == "tel_" + tel) {
                flag = false;
            }
            document.getElementById("tel_" + tel).disabled = flag; //Deshabilitar los no 1010
        }
    }
}

function revisa_calificacion2(origen, combo, tipo, referente, calificacion, telefono, cont, num, action) {
    //procesar con ajax la subcalificacion
    process_subcalificacion(origen, referente, combo.value, action, calificacion, telefono, num);

    //mandar a agregar el referido

    setTimeout(function () {
        if (combo.value == 3)
            window.location = "modules.php?mod=agentes&op=nuevoregistro&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono;
        else
            window.location = "modules.php?mod=agentes&op=index&subcalificacion=" + combo.value + "&cont=" + cont;
    }, 1000);

}




//## Prepara las variables para mandar liberar extension
function process_subcalificacion(origen, referente, subcalificacion, action, calificacion, telefono, num) {

    request = "origen=" + origen + "&referente=" + referente + "&calificacion=" + subcalificacion + "&telefono=" + telefono + "&calificado=" + calificacion + "," + num + "|";
    //alert(request);


    send_post_page_proc_sub(request, "", "modules.php?mod=agentes&op=process_data&act=" + action);//42
}

//## Ejecuta la funcion de liberar extension
function send_post_page_proc_sub(request, container, page) {

//    var contenedor;
//    contenedor = document.getElementById(container);

    ajax7 = nuevoAjax();
    ajax7.open("POST", page, true);
    ajax7.onreadystatechange = function () {
        if (ajax7.readyState == 4) {
            x = x;
        }
    }
    ajax7.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax7.send(request);

}





function revisa_calificacion_cuestionario(combo, tipo, referente, telefono) {
//    var calificacion = combo.value;

    var referido = false;
    var calificacion = combo.value;

    if (combo.options[combo.selectedIndex].text.indexOf("[R]") >= 0) {

        if (tipo == 1 || tipo == 2) {
            if (confirm("Lamentablemente esta tarjeta requiere (mencionar requisito que no cumplió) sin embargo para no dejar pasar esta oportunidad podemos hacerle la invitación a algún familiar o amigo y sea acreedor a viajes y promociones por medio de la aerolínea, a quien le gustaría que le diéramos este beneficio?")) {
                referido = true;
            }
        } else {
            referido = true;
        }
        if (referido == true) {
            window.location = "modules.php?mod=agentes&op=nuevoregistro&tipo=" + tipo + "&referente=" + referente + "&calificacion=" + calificacion + "&telefono=" + telefono;
        }
        /*if (referido == false) {
         $(function(){
         $( "#dialog-proceso" ).dialog({
         autoOpen: true,
         height: 100,
         width: 350,
         modal: true,
         closeOnEscape:false,
         open: function(event, ui) { jQuery('.ui-dialog-titlebar-close').hide(); }
         });
         });
         window.location = "modules.php?mod=agentes&op=process_data&act=NA==";
         }*/
        //window.location = "modules.php?mod=agentes&op=process_data&act=NA==";
    }
}

function avisoPrivacidadImpulse() {
    alert("Aviso de Privacidad:\n\n" +
            "Impulse Telecommunications de México S.A de C.V.\n" +
            "con domicilio en Av. 5 de febrero 1309 Nave A4\n" +
            "Col. Felipe Carrillo Puerto C.P. 76138 Querétaro, Qro. México;\n" +
            "utiliza información personal de los titulares\n" +
            "para la promoción y venta de productos y servicios.\n" +
            "Para conocer nuestro aviso de privacidad integral\n" +
            "por favor visite www.impulse-telecom.com.");

    /*
     "Le recordamos que todos los datos que me ha proporcionado\n" +
     "estÃ¡n siendo protegidos y son utilizados para promociÃ³n de\n" +
     "productos y servicios. Para mÃ¡s informaciÃ³n le pedimos revisar\n" +
     "nuestro aviso de privacidad en www.impulse-telecom.com");
     */

}

function avisoPrivacidadImpulse_bloqueo() {
    alert("Aviso de Privacidad:\n\n" +
            "Impulse Telecommunications de México S.A de C.V.\n" +
            "con domicilio en Av. 5 de febrero 1309 Nave A4\n" +
            "Col. Felipe Carrillo Puerto C.P. 76138 Querétaro, Qro. México;\n" +
            "utiliza información personal de los titulares\n" +
            "para la promoción y venta de productos y servicios.\n" +
            "Para conocer nuestro aviso de privacidad integral\n" +
            "por favor visite www.impulse-telecom.com.\n\n\n" +
            "QUE CONTESTAR AL CLIENTE:\n\n" +
            "Si el cliente menciona que está inscrito en REUS (Registro Público de Usuarios Personas Físicas), CONDUSEF (Comisión Nacional para la Protección y Defensa de los Usuarios de los Servicios Financieros) o ya requirió derecho de ARCO:\n\n" +
            "De parte de (campaña) le ofrezco una disculpa, no tenía conocimiento de esta situación. Le agradezco que haya atendido mi llamada, muchas gracias.\n\n" +
            "Que responder ante la pregunta ¿Cómo obtuviste mis datos?\n\n" +
            "Señor (nombre y apellido), no se preocupe, los únicos datos con los que contamos son nombre y teléfono, son datos públicos y no tenemos ningún dato confidencial.\n\n" +
            "Con insistencia, de dónde los obtuvieron: \n\n" +
            "Señor (nombre y apellido), nuestra información fuente es pública, como por ejemplo la sección blanca o amarilla, o bien alguno de nuestros clientes distinguidos lo refirió para que contara con nuestro excelente servicio.\n\n" +
            "Tercera insistencia:\n\n" +
            "Señor (nombre y apellido), de parte de (campaña) le ofrezco una disculpa, definitivamente no es nuestro objetivo generarle desconfianza alguna, sin embargo entiendo su preocupación. En estos momentos procedo al bloqueo de sus datos para que no lo volvamos a contactar. Le agradezco que haya atendido mi llamada, muchas gracias.\n\n"
            );
}

function avisoAltaRegistroTuBase() {
    alert("Aviso de Alta de registro TU BASE:\n\n" +
            "Te recordamos que al ingresar un registro no debe tener relación con ninguno ya existente en base.\n" +
            "Adicionalmente, si tienes un llamada en curso y no ingresaste como referido\n" +
            "o no se tiene relación con este nuevo registro, NO SE ENCONTRARÁ LA GRABACION.\n\n" +
            "Si tienes duda de como ingresar un registro dirígete con tu líder.");
}

function avisoClienteMolesto() {
    alert("Aviso de Cliente Molesto:\n\n" +
            "Este cliente se encuentra en la lista de clientes molestos confirma los datos." +
            "Verifica con tu líder si puedes ingresarlo.");
}


function avisoTuBase() {
    alert("Verifica que hayas concluido tu llamada anterior de lo contrario se va a cortar tu línea.");
}

$(function () {
    $("#dialog-proceso").dialog({
        autoOpen: false,
        height: 100,
        width: 350,
        modal: true,
        closeOnEscape: false,
        resizable: false,
        position: {my: "center"},
        draggable: false,
        open: function (event, ui) {
            jQuery('.ui-dialog-titlebar-close').hide();
        }
    });

    /*$( "#indicador" ).dialog({
     autoOpen: false,
     height: 400,
     width: 600,
     closeOnEscape: false,
     resizable: false,
     position: {my: "center"},
     /*show: {
     effect: "blind",
     duration: 1000
     },
     hide: {
     effect: "explode",
     duration: 1000
     }
     });*/

    $("#obRegistroPred")
            //.button()
            .click(function () {
                $("#dialog-proceso").dialog("open");
            }
            );//
    $("#obRegistroPredContinuar")
            //.button()
            .click(function () {
                $("#dialog-proceso").dialog("open");
            }
            );
    $("#obRegistroPredAgenda")
            //.button()
            .click(function () {
                $("#dialog-proceso").dialog("open");
            }
            );
    $("#obRegistroPredCancelarRefe")
            //.button()
            .click(function () {
                $("#dialog-proceso").dialog("open");
            }
            );

    $("#progressbar").progressbar({
        value: false
    });
    //$("#tu_base").button();
    //$("#bsregistro").button();
    //$("#agenda").button();
    //$("#obRegistroAsis").button();
    //$("#inicio").button();

    $("#accordion").accordion({
        collapsible: true,
        heightStyle: "fill",
        active: false
    });

    $("#accordion-resizer").resizable({
        minHeight: 140,
        minWidth: 200,
        resize: function () {
            $("#accordion").accordion("refresh");
        }
    });

    $("#datepicker").datepicker({
        inline: true
    });

    $("#dialog2").dialog({
        autoOpen: false,
        height: 400,
        width: 600,
        closeOnEscape: false,
        resizable: false,
        position: {my: "center"},
        /*show: {
         effect: "blind",
         duration: 1000
         },*/
        /*hide: {
         effect: "explode",
         duration: 1000
         }*/
    });

    $("#opener").click(function () {
        $("#dialog2").dialog("open");
    });

    /*$( "#indicadores" ).click(function() {
     $( "#indicador" ).dialog( "open" );
     });*/

    $("#menu").menu();

});


function marcarpredictivo(act) {
    window.location = "modules.php?mod=agentes&op=process_data&act=" + act;
    //alert (url);
    //document.getElementById("pred").src = url;
}

function Finalizar_venta(action) {

 
     
    var horaValida = ValidaHorario();

            document.frm1.action = 'modules.php?mod=agentes&op=process_data&act=' + action + '&validahorario=' + horaValida;
            document.frm1.submit();
    }

function score2() {

        if (document.getElementById("calificavalidador").value == '') {
            alert("Debes Incluir Validador");
        }else{
        var comen = document.getElementById("comentario").value;
        var validador = document.getElementById("calificavalidador").value;
        var antsol = document.getElementById("antiguasolicitud").value;
        var puntaje = $(".rate_row").find(":hidden").val();
        var page = 'modules.php?mod=agentes&op=process_data&act=Q1Y=&comen=' + comen + '&validador=' + validador + '&puntaje=' + puntaje+'&antsol='+antsol;

//    var page = 'modules.php?mod=agentes&op=process_data&act=Q1Y=';
        ajaxPrima = nuevoAjax();
        ajaxPrima.open("POST", page, true);
        ajaxPrima.onreadystatechange = function () {
            if (ajaxPrima.readyState == 4) {
                //alert(PRIMA.value)
//            contenedor.innerHTML = '<option value=""></option>' + ajaxPrima.responseText;
                alert("Calificacion Guardada.");

            }
            //else{ alert(ajaxPrima.responseText)};
        };
        ajaxPrima.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajaxPrima.send(request);
    }
}

// Enviar datos para agenda
function send_post_page_agenda(request, container, page) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax_agenda = nuevoAjax();
    ajax_agenda.open("POST", page, true);
    ajax_agenda.onreadystatechange = function () {
        if (ajax_agenda.readyState == 4) {
            contenedor.innerHTML = ajax_agenda.responseText;
        }
    }
    ajax_agenda.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax_agenda.send(request);
}

function verAgenda(boton, fecha, contenedor, tipo_agenda) {
    boton.disabled = false;
    request = "fecha=" + fecha + "&tipo_agenda=" + tipo_agenda;
    send_post_page_agenda(request, contenedor, "modules.php?mod=agentes&op=process_data&act=NDA2");
}

function guardaAgenda(agenda, hora, nombre, solicitud, ispred) {
    mediahora = document.getElementById("hora");
    mediahora.value = agenda;    
    Agenda_registro('Ng==', hora, nombre, solicitud, ispred); //Action 6
}


function f5(that, val) {
    //alert("entro");
    if (val)
    {
        that.on('keydown', function (e) {
            var code = (e.keyCode ? e.keyCode : e.which);
            if (code == 116 /*|| code == 8*/) {
                e.preventDefault();
            }
        });
    } else {
        that.off('keydown');
    }
}

function dialogo(src, indicadores) {
    //alert(src);
    document.getElementById("iframeind").src = src;
    $("#indicador").dialog({
        autoOpen: true,
        height: 600,
        width: 600,
        closeOnEscape: false,
        resizable: true,
        title: indicadores,
        position: {my: "center"},
        /*show: {
         effect: "blind",
         duration: 1000
         },*/
        /*hide: {
         effect: "explode",
         duration: 1000
         }*/
    });

}

function generar_layouts() {

    if (document.layouts.fecha.value == "") {
        alert('Los campos de fecha estan vacios')
        return false;
    } else if (document.layouts.t_layout.value == "") {
        alert('Seleccione el Layout')
        return false;
    } else {

        document, layouts.l_button.disabled = true;

        loading_fun()

        fecha = document.layouts.fecha.value;
        t_layout = document.layouts.t_layout.value;

        request = "fecha=" + fecha + "&t_layout=" + t_layout;
        sen_post_layots(request, "result", "modules.php?mod=supervisor&op=process_data&act=6", 1);
    }
}

function sen_post_layots(request, container, page, valor_loading) {
    var contenedor;
    contenedor = document.getElementById(container);
    ajax = nuevoAjax();
    ajax.open("POST", page, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            contenedor.innerHTML = ajax.responseText
            if (valor_loading == 1) {
                document.body.removeChild(document.getElementById('div_padre'));
                document, layouts.l_button.disabled = false;
            }
        }
    }
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(request);
}

function loading_fun() {
    Html = '<div id="ajControl" width="100%">' +
            '<table cellpadding="0" cellspacing="0" width="100%" height="100%" align="center">' +
            '<tr id="ajControlBody">' +
            '<td>Cargando...<br><br>Su peticion esta siendo procesada</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

    var div = document.createElement('div');
    div.id = 'div_padre';
    div.innerHTML = Html;

    document.body.appendChild(div);
}





//## Prepara las variables para mandar liberar extension
function liberar_extension(extension, action, boton) {

    //loading_fun();
    boton.disabled = true;

    document.getElementById("LibExtContainer").innerHTML = "";

    request = "extension=" + extension;

    send_post_page_lib_ext(request, "LibExtContainer", "modules.php?mod=external&op=process_data&act=" + action);//1 (external)

    return false;
}

//## Ejecuta la funcion de liberar extension
function send_post_page_lib_ext(request, container, page) {
//	alert(request);
    //ajax5

    var contenedor;
    contenedor = document.getElementById(container);

    ajax5 = nuevoAjax();
    ajax5.open("POST", page, true);
    ajax5.onreadystatechange = function () {
        if (ajax5.readyState == 4) {
            contenedor.innerHTML = ajax5.responseText
        }
    }
    ajax5.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax5.send(request);

}

function verify_movil(boton, tel) {
    if (boton.value != '') {
        if (tel == 1) {
            numero = document.SurveyResponse.txtQId32CId23.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_1", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 2) {
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_2", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 3) {
            numero = /*document.SurveyResponse.txtQId37CId89.value +*/ boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_3", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 4) {
            numero = /*document.SurveyResponse.txtQId37CId94.value +*/ boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_4", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 5) {
            numero = /*document.SurveyResponse.txtQId37CId102.value +*/ boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_5", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 6) {
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_6", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 7) {
            numero = boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_7", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 8) {
            numero = document.SurveyResponse.txtQId33CId13.value + boton.value;
            //alert(numero);
            request = "numero=" + numero;
            send_post_page_verifica_numero(request, "tel_8", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        } else if (tel == 9) {
            var tel_valido_9 = 0;
            var count_tel = 0;
            numero = document.frm1.lada.value + boton.value;
            //alert(numero);

            request = "numero=" + numero;
            send_post_get_count_tel(request, "", "modules.php?mod=agentes&op=process_data&act=NTY=", tel);
            send_post_page_verifica_numero(request, "tel_9", "modules.php?mod=agentes&op=process_data&act=NDE=", tel);
        }

    } else {
        if (tel == 1) {
            tel_valido_1 = 0;
        } else if (tel == 2) {
            tel_valido_2 = 0;
        } else if (tel == 3) {
            tel_valido_3 = 0;
        } else if (tel == 4) {
            tel_valido_4 = 0;
        } else if (tel == 5) {
            tel_valido_5 = 0;
        } else if (tel == 6) {
            tel_valido_6 = 0;
        } else if (tel == 7) {
            tel_valido_7 = 0;
        } else if (tel == 8) {
            tel_valido_8 = 0;
        }
    }
}

function send_post_page_verifica_numero(request, container, page, tel) {
//	alert(request);
    //ajax5

    var contenedor;
    contenedor = document.getElementById(container);

    ajax5 = nuevoAjax();
    ajax5.open("POST", page, true);
    ajax5.onreadystatechange = function () {
        if (ajax5.readyState == 4) {
            contenedor.innerHTML = "<font color='red'>" + ajax5.responseText + "</font>";

             if (tel == 2) {
                if (ajax5.responseText != 'MOVIL') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    alert("En el campo de celular debe ser Movil");
                    //return false;
                    if (ajax5.responseText == 'No valido') {
                        document.getElementById('btn_continue').style.display = "none";
                        document.getElementById('btn_save').style.display = "none";
                        alert("Ha ingresado un telefono no valido");
                        tel_valido_1 = 1;
                        return false;
                    } else {
                        document.getElementById('btn_continue').style.display = "inline";
                        document.getElementById('btn_save').style.display = "inline";
                        tel_valido_1 = 0;
                        return true;
                    }
                } else {
                    if (ajax5.responseText == 'No valido') {
                        document.getElementById('btn_continue').style.display = "none";
                        document.getElementById('btn_save').style.display = "none";
                        alert("Ha ingresado un telefono no valido");
                        tel_valido_2 = 1;
                        return false;
                    } else {
                        document.getElementById('btn_continue').style.display = "inline";
                        document.getElementById('btn_save').style.display = "inline";
                        tel_valido_2 = 0;
                        return true;
                    }
                }

            } else if (tel == 3) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    alert("Ha ingresado un telefono no valido");
                    tel_valido_3 = 1;
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_3 = 0;
                    return true;
                }
            } else if (tel == 4) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    tel_valido_4 = 1;
                    alert("Ha ingresado un telefono no valido");
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_4 = 0;
                    return true;
                }
            } else if (tel == 5) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    alert("Ha ingresado un telefono no valido");
                    tel_valido_5 = 1;
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_5 = 0;
                    return true;
                }
            } else if (tel == 6) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    alert("Ha ingresado un telefono no valido");
                    tel_valido_6 = 1;
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_6 = 0;
                    return true;
                }
            } else if (tel == 7) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    tel_valido_7 = 1;
                    alert("Ha ingresado un telefono no valido");
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_7 = 0;
                    return true;
                }
            } else if (tel == 8) {
                if (ajax5.responseText == 'No valido') {
                    document.getElementById('btn_continue').style.display = "none";
                    document.getElementById('btn_save').style.display = "none";
                    alert("Ha ingresado un telefono no valido");
                    tel_valido_8 = 1;
                    return false;
                } else {
                    document.getElementById('btn_continue').style.display = "inline";
                    document.getElementById('btn_save').style.display = "inline";
                    tel_valido_8 = 0;
                    return true;
                }
            } else if (tel == 9) {
                if (ajax5.responseText == 'No valido') {
                    /*document.getElementById('btn_continue').style.display = "none";
                     document.getElementById('btn_save').style.display = "none"; */
                    alert("Ha ingresado un telefono no valido");
                    tel_valido_9 = 0;
                    return false;
                } else {

                    tel_valido_9 = 1;
                    if (ajax5.responseText == 'MOVIL') {
                        document.getElementById('tipo_telefonico').value = 3
                    } else if (ajax5.responseText == 'FIJO') {
                        document.getElementById('tipo_telefonico').value = 1
                    }
                    return true;
                }
            }

        }
    }
    ajax5.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax5.send(request);

}

function prescrining(boton) {
    //alert("prescrining");
    pri_nombre = document.SurveyResponse.txtQId31CId2.value;
    seg_nombre = document.SurveyResponse.txtQId31CId3.value;
    ap_paterno = document.SurveyResponse.txtQId31CId4.value;
    ap_materno = document.SurveyResponse.txtQId31CId5.value;
    fec_nac = document.SurveyResponse.txtQId31CId6.value;
    rfc = document.SurveyResponse.txtQId31CId7.value;
    //
    calle = document.SurveyResponse.txtQId32CId2.value;
    numero = document.SurveyResponse.txtQId32CId3.value;

    cp = document.SurveyResponse.txtQId32CId7.value;
    otra_colonia = document.SurveyResponse.txtQId32CId8.value;

    colonia = document.SurveyResponse.txtQId32CId9;
    municipio = document.SurveyResponse.txtQId32CId11;
    edo = document.SurveyResponse.txtQId32CId12;
    edo_nac = document.SurveyResponse.txtQId31CId21;//txtQId31CId21

    colonia_text = colonia.options[colonia.selectedIndex].text;
    municipio_text = municipio.options[municipio.selectedIndex].text;
    edo_text = edo.options[edo.selectedIndex].text;
    edo_nac_tex = edo_nac.options[edo_nac.selectedIndex].text;

    if (pri_nombre == "") {
        alert("Ingrese el nombre");
        return false;
    }
    if (ap_paterno == "") {
        alert("Ingrese el Ap. Paterno");
        return false;
    }
    if (fec_nac == "") {
        alert("Ingrese la Fecha de Nacimiento");
        return false;
    }

    if (edo_nac_tex == "") {
        alert("Favor de leccionar el Estado de Nacimiento");
        return false;
    }

    if (calle == "") {
        alert("Ingrese la Calle");
        return false;
    }
    if (numero == "") {
        alert("Ingrese el numero");
        return false;
    }

    if (rfc == "") {
        alert("Ingrese el RFC");
        return false;
    }
    if (cp == "") {
        alert("Ingrese el Codigo Postal");
        return false;
    }
    if (colonia_text == "") {
        if (otra_colonia == "" || otra_colonia == " " || otra_colonia == "  " || otra_colonia == "  ") {
            alert("Ingrese o seleccione la colonia");
            return false;
        } else {
            colonia_ = otra_colonia;
        }
    } else {
        if (otra_colonia != "") {
            alert("Favor de solo proporcionar una colonia.");
            return false;
        } else {
            colonia_ = colonia_text;
        }
    }

    if (municipio_text == "") {
        alert("Favor de leccionar el Municipio");
        return false;
    }

    if (edo_text == "") {
        alert("Favor de leccionar el Estado");
        return false;
    }

    if (edo.value == "-1" || colonia.value == "-1" || municipio.value == "-1") {
        alert("CP sin cobertura");
        return false;
    }

    $.post("modules.php?mod=agentes&op=process_data&act=NDc=", {//47
        nombre: pri_nombre + " " + seg_nombre,
        ap_panterno: ap_paterno,
        ap_materno: ap_materno,
        fec_nac: fec_nac,
        rfc: rfc,
        calle: calle,
        numero: numero,
        cp: cp,
        municipio: municipio_text,
        colonia: colonia_text,
        edo_nac: edo_nac_tex,
        edo: edo_text,
        act2: 1
    }, function (data, status) {
        alert(data);
    });
}

function Actualizar2() {
    //boton.hidden = true;

    var xmlhttp;
    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    } else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    document.getElementsByName("b_actualizar")[0].class = "menulink2";
    document.getElementsByName("b_actualizar")[1].class = "menulink2";
    setTimeout(function () {
        document.getElementsByName("b_actualizar")[0].disabled = false;
        document.getElementsByName("b_actualizar")[1].disabled = false;
        document.getElementsByName("b_actualizar")[0].class = "menulink";
        document.getElementsByName("b_actualizar")[1].class = "menulink";
    }, 30000);

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("result2").innerHTML = xmlhttp.responseText;
            //boton.disabled = false;
        }
    };

    xmlhttp.open("POST", "modules.php?mod=agentes&op=process_data&act=NDg=", true);
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send("nomina=<?= $nomina ?>&u_user=<?= $u_user ?>");
}

function send_post_get_count_tel(request, container, page, tel) {
//	alert(request);
    //ajax5

    ajax6 = nuevoAjax();
    ajax6.open("POST", page, true);
    ajax6.onreadystatechange = function () {
        if (ajax6.readyState == 4) {
            count_tel = ajax6.responseText;
        }
    }
    ajax6.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax6.send(request);

}

function actulizar_forma_pago(producto, selectd) {
    //alert(selectd.options[selectd.selectedIndex].text);
    /*if(producto == 1){
     v_prod_value = selectd.options[selectd.selectedIndex].text;
     }else {*/
    v_prod_value = selectd.value;
    //}

    $.post("modules.php?mod=agentes&op=process_data&act=NDc=", {
        producto: producto,
        prod_value: v_prod_value
    }, function (data, status) {
        /*if(producto == 1){
         document.SurveyResponse.txtQId11CId17.innerHTML = data;
         }else{**/
        document.getElementById('FORMA_PAGO').innerHTML = data;
        //}

        //alert(data);
    });
}

function actulizar_prima(producto, selectd) {
    $.post("modules.php?mod=agentes&op=process_data&act=NDc=", {
        producto: producto,
        prod_value: selectd.value
    }, function (data, status) {
        /*if(producto == 1){
         document.SurveyResponse.txtQId11CId17.innerHTML = data;
         }else{**/
        document.getElementById('PRIMA').innerHTML = data;
        //}

        //alert(data);
    });
}

function inicio_marcar(inicio_marcar) {
    if (inicio_marcar == 2) {
        $("#btnMarcar1").click();
    } else {
        $("#obRegistroPred").click();
    }

}

function guarda_click(id) {
    jQuery("#bntagenda").attr("class", "menulink2");
    jQuery("#bsregistro").attr("class", "menulink2");
    jQuery("#btnbreak").attr("class", "menulink2");
    jQuery("#btnbano").attr("class", "menulink2");
    jQuery("#btncapa").attr("class", "menulink2");
    jQuery("#btnretro").attr("class", "menulink2");
    jQuery("#btnrep").attr("class", "menulink2");
    jQuery("#btndes").attr("class", "menulink2");
    jQuery("#btnjunta").attr("class", "menulink2");
    jQuery("#terminar_ss").attr("class", "menulink2");

    jQuery("#bntagenda").attr("disabled", "disabled");
    jQuery("#bsregistro").attr("disabled", "disabled");
    jQuery("#btnbreak").attr("disabled", "disabled");
    jQuery("#btnbano").attr("disabled", "disabled");
    jQuery("#btncapa").attr("disabled", "disabled");
    jQuery("#btnretro").attr("disabled", "disabled");
    jQuery("#btnrep").attr("disabled", "disabled");
    jQuery("#btndes").attr("disabled", "disabled");
    jQuery("#btnjunta").attr("disabled", "disabled");
    jQuery("#terminar_ss").attr("disabled", "disabled");

    $.post("modules.php?mod=agentes&op=process_data&act=Njc=", {
        id: id
    }, function (data, status) {
        //alert(data);
    });
}

function alert_producto(combo) {
    strscript = "";
    if(combo.value == "3"){
        alert("Volaris 0, TDC sin anualidad, comisión y equivalencia menor");
    }

    if(combo.value == "4"){
        strscript = "_lowes";
    }

    ShowScript_GeneralIN(strscript);
}

// var errores = 0;
// function validaRespuesta(tipo){
//     // R RFC,
//     // F Fecha

//     $('#input_'+tipo).attr('disabled', true);

//     let cont = 0;

//     if(cont < 2){
//         cont++;

//         let contra = tipo == 'R' ? 2 : 1;
//         let resp = $('#resp_'+tipo).text();
//         let comparacion = $('#input_'+tipo).val();

//         if(resp == comparacion){
//             $('#spanResp_1_'+tipo).show();
//             $('#cuestionario').show();

//         } else{
//             errores++;
//             $('#spanResp_0_'+tipo).show();
//             $('#td_'+contra).show();
//         }
//     }

//     if(errores == 2){
//         $('#tdAutenticacion').show();
//     }
// }

var errores = 0;
var cont = 0;
function validaRespuesta(tipo){

    $('#input_'+tipo).html('');
    $('.icono_'+tipo).hide();

    let resp = $('#resp_'+tipo).text(); // respuesta correcta
    let comparacion = $('#input_'+tipo).val(); // dato ingresado por AVI
    let contra = tipo == 'R' ? 2 : 1; // id de la siguiente pregunta

    if(cont < 4){
        cont++;

        if(resp != comparacion){
            errores++;
            $('#conteoErrores').html('Errores: ' + errores).show();
            $('#spanResp_0_'+tipo).show();

            if(errores == 3){
                cont =  0;
                $('#input_'+tipo).attr('disabled', true);
                $('#td_'+contra).show();
            }
            if(errores == 6){
                $('#input_'+tipo).attr('disabled', true);
            }

        } else{
            $('#spanResp_1_'+tipo).show();
            $('#cuestionario').show();

            /*setTimeout(function(){
                var input = document.getElementsByTagName('input');

                $(input).each(function(index){
                    var ids = $(this).attr('id');
                    $(this).attr('onblur',"chuy('"+ids+"')")
                });
            }, 3000);*/
        }
    }

    if(errores == 6){
        $('#tdAutenticacion').show();
    }


    // if(cont < 3){
    //     cont++;

    //     let contra = tipo == 'R' ? 2 : 1;
    //     let resp = $('#resp_'+tipo).text();
    //     let comparacion = $('#input_'+tipo).val();

    //     if(resp == comparacion){
    //         $('#spanResp_1_'+tipo).show();
    //         $('#cuestionario').show();

    //     } else{
    //         errores++;
    //         $('#spanResp_0_'+tipo).show();
    //         $('#td_'+contra).show();
    //     }
    // }

    // if(errores == 2){
    //     $('#tdAutenticacion').show();
    // }
}

function oculta_beneficiarios(){
    // agregar clase a los bloques de beneficiario
    $('.bloque_beneficiarios').hide();
    $('.bloque_asegurados').hide();
}

function removeSpaces(id){ // remover espacios y ñ
    const chars = {'ñ':'n','Ñ':'N'};
    var val_actual = $('#'+id).val();
    var val_nuevo = val_actual.replace(/^\s+|\s+$|\s+(?=\s)/g, '');

    let chuy_ret = chuy(val_nuevo);
    //console.log('"'+val_actual+'"', '"'+val_nuevo+'"');
    $('#'+id).val(chuy_ret);
}


function armaCamposCorreo(){
    $.ajax({
        url: "modules.php?mod=agentes&op=process_data&act=ODM=",
        type: "post",
        dataType: "html",
        //data: formData,
        cache: false,
        contentType: false,
        processData: false
    }).done(function(data){
        $('#email').hide();
        $('#email').parent().prepend(`
            <input id="texto_correo" onchange="habilitaDominos(this.value);">
            <select id="select_dominio" onchange="validaCorreo(this.value);" disabled>
                ${data}
            </select>
            <div id="div_nuevo_dominio_correo" style="display:none;">
             @ <input id="nuevo_dominio_correo" placeholder="NO PONGAS @" onblur="validaNuevoDominio(this.value);">
             <input type="button" class="btn" value="Cancelar" style="background-color:red;color:#fff;padding:0 2rem;" onclick="cancelarNuevoDominio();">
            </div>
        `).css('display','block ruby');
    });

    setTimeout(function(){
      validarCorreoExistente();
    }, 500);
}

function habilitaDominos(valor){
    if(valor == ''){
        alert('Por favor ingresa el texto del correo antes de elegir el dominio');
        $('#select_dominio').attr('disabled', true);

   } else{
        let validacion = validarDato(valor, 'texto_correo');
        if(validacion == true){
            $('#select_dominio').attr('disabled', false);
        }
    }
}

function validaCorreo(dominio){
    let texto_correo = $('#texto_correo').val();
    let dominio_correo = dominio;

    if(dominio=='otro'){
        $('#div_nuevo_dominio_correo').show();
        $('#select_dominio').hide();

    } else{
        let validacion = validarDato(texto_correo + dominio_correo, 'email');
        if(validacion == true){
            correcCorrecto(texto_correo + dominio_correo);
        }
    }
}

function cancelarNuevoDominio(){
    $('#nuevo_dominio_correo').val('');
    $('#div_nuevo_dominio_correo').hide();
    $('#select_dominio').show();
}

function validaNuevoDominio(dominio){
    let texto_correo = $('#texto_correo').val();
    let dominio_correo = '@' + dominio;

    let validacion = validarDato(texto_correo + dominio_correo, 'email');

    if(validacion == true){
        $('#select_dominio').append(`
            <option selected="selected" value="${dominio_correo}">${dominio_correo}</option>
        `);

        cancelarNuevoDominio();
        correcCorrecto(texto_correo + dominio_correo);
    }
}

function editarCorreo(){
    $('#texto_correo').show();
    $('#select_dominio').show();

    $('#email').val('').hide();
    $('#btnEditCorreo').remove();
}

function correcCorrecto(correo){
    $('#texto_correo').hide();
    $('#select_dominio').hide();

    $('#email').val(correo).show().prop('readonly', 'readonly').parent().append(`
        <input type="button" id="btnEditCorreo" class="btn" value="Editar" style="background-color:red;color:#fff;padding:0 2rem;" onclick="editarCorreo(this.id);">
    `);
}

function validarDato(valor, id){
    //console.log('desde el jscode PRINCIPAL');
    //e.preventDefault();
    $('#errorDato').remove();

    var dato_ = 1;
    if(id == 'email'){
        var regExp_dato = /^(([^<>()[\]\.\s@\"]+(\.[^<>()[\]\.\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.\s@\"]+\.)+[^<>()[\]\.\s@\"]{2,})$/i;
        var dato = 'Correo Invalido.';

    } else if(id == 'fecha_cobro'){
        var regExp_dato = /^(?:(?:(?:0?[1-9]|1\d|2[0-8])[/-](?:0?[1-9]|1[0-2])|(?:29|30)[/-](?:0?[13-9]|1[0-2])|31[/](?:0?[13578]|1[02]))[/-](?:0{2,3}[1-9]|0{1,2}[1-9]\d|0?[1-9]\d{2}|[1-9]\d{3})|29[/-]0?2[/-](?:\d{1,2}(?:0[48]|[2468][048]|[13579][26])|(?:0?[48]|[13579][26]|[2468][048])00))$/;
        var dato = 'Fecha Invalida.';

        if(valor.split('/')[2].length != 4){
            dato_ = 0;
        }
    } else if(id == 'texto_correo'){
        var regExp_dato = /^[A-Za-z0-9._-]+$/;
    }

    if (!regExp_dato.test(valor) || dato_==0){
       $('#'+id).parent().append('<span style="color:red;" id="errorDato">'+dato+'</span>');
       return false;
    } else{
       dato_valido = 1;
       return true;
    }
}

function chuy(value_){
    // const n_min_regExp = /[\u00f1]/g;
    // const n_may_regExp = /[\u00d1]/g;

    // return value_.replace(n_min_regExp, 'n').replace(n_may_regExp, 'N');
    const n_min_regExp = /[\u00f1]/g;
    const n_may_regExp = /[\u00d1]/g;

    // Reemplazar "ñ" y "Ñ"
    value_ = value_.replace(n_min_regExp, 'n').replace(n_may_regExp, 'N');

    // Reemplazar vocales con acentos minúsculas
    value_ = value_.replace(/[\u00e1]/g, 'a'); // á -> a
    value_ = value_.replace(/[\u00e9]/g, 'e'); // é -> e
    value_ = value_.replace(/[\u00ed]/g, 'i'); // í -> i
    value_ = value_.replace(/[\u00f3]/g, 'o'); // ó -> o
    value_ = value_.replace(/[\u00fa]/g, 'u'); // ú -> u

    // Reemplazar vocales con acentos mayúsculas
    value_ = value_.replace(/[\u00c1]/g, 'A'); // Á -> A
    value_ = value_.replace(/[\u00c9]/g, 'E'); // É -> E
    value_ = value_.replace(/[\u00cd]/g, 'I'); // Í -> I
    value_ = value_.replace(/[\u00d3]/g, 'O'); // Ó -> O
    value_ = value_.replace(/[\u00da]/g, 'U'); // Ú -> U
    
    return value_;
}

//------------------------------------------------------ El Master CO
function validarRFC(rfc){
    const regExp_rfc = /^([A-ZÑ&]{3,4}) ?(?:- ?)?(\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])) ?(?:- ?)?([A-Z\d]{2})([A\d])$/;

    //console.log(regExp_rfc, rfc, regExp_rfc.test(rfc));
    if(!regExp_rfc.test(rfc)){
        return false;
    } else{
        return true;
    }
}

function checameElRFC(num_beneficiarios){
    // validar RFC
  var cont_errores_rfc = 0;
  var msg_errores_rfc = '';


  var rfc_titular = $('#RFC').val();  // validar rfc titular
  var val_rfc_tit = validarRFC(rfc_titular);
  if(val_rfc_tit == false){
    cont_errores_rfc++;
    msg_errores_rfc = 'El RFC del titular esta mal.';
  }

  for(var l=0; l<num_beneficiarios; l++){  // validar beneficiarios
    var rfc_beneficiario = $('#rfc_bene'+(l+1)).val();
    var val_rfc_bene = validarRFC(rfc_beneficiario);

    if(!val_rfc_bene){
      cont_errores_rfc++;
      msg_errores_rfc += '\nEl RFC del beneficiario ' +(l+1)+ ' esta mal.';
    }
  }

  if(cont_errores_rfc > 0){
    alert(msg_errores_rfc);
    return false;
  }
}

function convierteDatepicker(id){
    $("#"+id).datepicker({
        changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'dd/mm/yy'
            // ,
            // onClose: function(dateText, inst) {
            //     var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            //     var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            //     $(this).datepicker('setDate', new Date(year, month, 1));
            // }
    });
}

function addValidaTipoDato(arrayCampos){
    // array compuesto por arrays con el id y regexp
    for(let b in arrayCampos){
        //for(let r in arrayCampos[b]){
            let id = arrayCampos[b][0];
            let regExp = arrayCampos[b][1];

            let onblur_actual = $(id).attr('onblur');
            $(id).attr('onblur', onblur_actual+'validaTipoDato("'+id+'", '+regExp+');');
        //}
    }
}

function validaTipoDato(id, regExp_){
    $(id).parent().find('br').remove();
    var str = $(id).val();
    var id_ = $(id).attr('id');
    if((id_ == 'nombreseg' || id_ == 'apmaterno')){
        if(str != ''){
            var regExp = regExp_;
        } else{
           var regExp = /^([A-Z a-z\.]){0,}$/g;
        }
    } else{
        var regExp = regExp_;
    }

    $('#error'+id_).remove();
    if(regExp.test(str) == false){
        //alert("Solamente se permiten letras. Por favor revisa la informacion ingresada en la seccion ["+bloque+"].");
        $(id).addClass('conError').parent().append('<span id="error'+id_+'" class="errorValidacion" style="color:#de0000;">Dato invalido</span>');
    } else{
        $(id).removeClass('conError');
        $('#error'+id_).remove();
    }
}

function validarCorreoExistente(){
  var correo = $('#email').val();
  if(correo != ''){
      correcCorrecto(correo);
  }
}
//-------------------------------------------------------
function valida_marcacion(){
    const tipo=document.getElementById('lg_marcacion');
    const btn_agenda_= document.getElementById('btn_agenda_');
    const btn_obt_reg= document.getElementById('btn_obt_reg');
    const btn_bus_reg= document.getElementById('btn_bus_reg');
    // alert(tipo.value);

    if ( tipo !==null && tipo.value == 3){
        btn_agenda_ !==null ? btn_agenda_.style.display='none' : console.log('error');
        btn_obt_reg !==null ? btn_obt_reg.style.display='none' : console.log('error');
        btn_bus_reg !==null ? btn_bus_reg.style.display='none' : console.log('error');


    }


}

