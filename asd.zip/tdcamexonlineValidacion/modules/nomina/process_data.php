<?php
# @uthor Mark 
# Process_data File en NOMINA

require_once("includes/includes.inc.php");
require_once("nominas.inc.php");

initialize_nolayout("supervisor","");

$action = $_REQUEST['act'];
$header = "modules.php?mod=nomina&op=activacion";

if(isset($action) && $action == 1){ # ACTIVA EL ID USUARIO

	$s_usr_id = $_REQUEST['s_usr_id'];
	$rs_activacion = set_activa_usuario($s_usr_id, $db);
	if($rs_activacion == 1){
		set_traking(get_session_varname("s_usr_id"),'ACTIVO USUARIO', get_session_varname("s_usr_maquina"), $s_usr_id, '', $db);
		echo '<font color="blue">Se libero correctamente la sesion del usuario '.$nomina.'</font>';
	}else{
		echo '<font color="red">No se pudo liberar la sesion del usuario '.$nomina.'</font>';
	}
	die();
	
} elseif (isset($action) && $action == 2) { // GUARDA AL NUEVO USUARIO

	$usr_id = $_REQUEST['idSelected'];
	$nombre = $_REQUEST['nombre'];
	$contrasena = $_REQUEST['contrasena'];
    $re_contrasena = $_REQUEST['re_contrasena'];
    $perfil = $_REQUEST['perfil'];
    $activo = (isset($_REQUEST['activo'])?1:0);
	$supervisor = $_REQUEST['supervisor'];
	$etapa = $_REQUEST['etapa'];
	$generacion = $_REQUEST['generacion'];
	
	$edita_usuario = set_datos_usuario($usr_id, strtoupper($nombre),  (strlen($contrasena)>0?md5('0101'.$contrasena.'1010'):""), $perfil, $activo, $supervisor, $etapa, $generacion, $db);
	$header = "modules.php?mod=nomina&op=abc_usuarios";
}

header("location: ".$header);
?>