const db = require("../db/mysql");

const KnowledgeModel = {
  async getByBot(idBot) {
    const [rows] = await db.query(
      `SELECT id, title, content
        FROM BOT_KNOWLEDGE
        WHERE id_bot = ?
          AND is_active = 1
        ORDER BY priority DESC, id ASC
        `,
      [idBot]
    );

    
    return rows.map((row) => ({
        id: row.id,
        title: row.title,
        content: row.content,
        tags: row.tags || [], // ✅ YA ES ARRAY
        priority: row.priority,
      }));
  },
  async getActiveByBot(idBot) {
    const [rows] = await db.query(
      `
      SELECT system_prompt
      FROM BOT_PROMPTS
      WHERE id_bot = ?
        AND is_active = 1
      LIMIT 1
      `,
      [idBot]
    );

    return rows.length ? rows[0].system_prompt : null;
  }
};

module.exports = KnowledgeModel;


