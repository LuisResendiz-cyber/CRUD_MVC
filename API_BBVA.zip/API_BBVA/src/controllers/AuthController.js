const AuthModel = require('../models/AuthModel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const secretKey = process.env.JWT_SECRET;

const AuthController = {
    async login(req, res){
        const { username, password } = req.body;                       
        const user = await AuthModel.getAcces({ username });

        const isMatch = await bcrypt.compare(password, user.PASSWORD);
        if (!isMatch) return res.status(400).json({ message: 'Contraseña incorrecta' });

        // Crear token JWT
        const token = jwt.sign(
            { userId: user.userId, username: user.username },
            secretKey,
            { expiresIn: '90d' }
        );

        res.json({user,message: 'Login correcto', token });
    }
}


module.exports = AuthController;