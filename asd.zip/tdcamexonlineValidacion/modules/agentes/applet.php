<META HTTP-EQUIV="content-type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="Refresh" CONTENT="1">

<?

echo 'Obteniendo registro de predictivo, por favor espere...</br>';

?>
<html>
    <head>
        <script>

            var Doc_ObtenerRegistro;

            function ObtenerRegistroPred(u_user){
                //alert ("entra a obtener registro")+u_user; //return;
                Doc_ObtenerRegistro = new XMLHttpRequest();
                Doc_ObtenerRegistro.onload = process ;
	    	    	    	    
                Doc_ObtenerRegistro.open( "GET", "http://172.21.15.1/click2dial/invex/get-pre_avail-pg.php?employeeid="+u_user, true );
                Doc_ObtenerRegistro.send( null );
            }
	
            function process() {
                if ( Doc_ObtenerRegistro.readyState != 4 ) return ;
                var datos = Doc_ObtenerRegistro.responseText;
                var datos = datos.split(",");
                var CustomerId = parseInt(datos[0]);
                var Telefono = datos[1];
                var Nombre = datos[2];
	
                /*while(CustomerId == 0){
                setTimeout(window.location.reload(),1000);
                //window.location.reload()
            }*/

                if (CustomerId == -1){
                    alert("No se pudo obtener registro, favor de volver a intentar... \n error -1 (conexion base de datos)");
                    return;
                }else{
                    if(CustomerId != 0){
                        //alert("Nombre del cliente: " + Nombre);
                        var page = "http://172.21.15.1/invex11g_prueba/modules.php?mod=agentes&op=process_data&act=Mjk=&u_registro="+CustomerId+"&tel="+Telefono
                        location.href = page;
                    }
                    //Sigue en espera de registro
                }
            }

            //window.onload = ObtenerRegistroPred('<?= $_REQUEST['u_user'] ?>');

        </script>
    </head>

    <body onload="ObtenerRegistroPred('<?= $_REQUEST['u_user'] ?>')">
    </body>
</html> 