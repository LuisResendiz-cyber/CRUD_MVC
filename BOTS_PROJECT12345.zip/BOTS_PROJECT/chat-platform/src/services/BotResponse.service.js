async function resolveBotResponse(session, message) {
    if (session.status !== "bot") return null;
  
    const resolution = await ChatResolver.resolve({ session, message });
    if (!resolution?.message) return null;
  
    await customerModel.insertWebhookLog({
      event_type: "bot_reply",
      status: "sent",
      message_text: resolution.message,
      channel: session.channel,
      role: "assistant",
      conversation_id: session.session_uuid
    });
  
    return {
      role: "assistant",
      message_text: resolution.message
    };
  }
  