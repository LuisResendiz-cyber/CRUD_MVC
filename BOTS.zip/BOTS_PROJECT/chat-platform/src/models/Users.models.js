const db = require("../db/mysql");

const Users = {
    async getUser(clientKey) {
        const rows = await db.query(`
          SELECT
            c.id           AS customerId,
            c.active       AS customerActive,
            b.id_bot       AS botId,
            b.nombre,
            b.tipo,
            b.estado
          FROM CUSTOMERS c
          JOIN BOTS b ON b.id_bot = c.bot_id
          WHERE c.client_key = ?
          LIMIT 1
        `, [clientKey]);

        if (!rows.length ||!rows[0][0].customerActive) {
          return null;
        }
        return rows[0];
      },
      async CreateUser(datosUser) {
        const { customer_id, name, last_name, phone_number, email_user, password, rolid } = datosUser;

        
        const [result] = await db.query("INSERT INTO USERS(customer_id, name,last_name, phone_number, email_user, password, rolid) VALUES(?,?,?,?,?,?,?)", [customer_id, name, last_name, phone_number, email_user, password, rolid]);
        return result;
      },
      async getAcces(user) {  
        const { email_user } = user;
        const [rows] = await db.query('SELECT us.*, r.name as nombrerol FROM USERS us JOIN ROLES r ON us.rolid  = r.idrol  where email_user = ?', [email_user]);
        return rows[0];
      },
      async getModules(idUser) {
        const [rows] = await db.query(`SELECT DISTINCT m.title, m.icon, s.idsubmodule, s.title as submodulo_titulo, s.route as submodulo_ruta, s.icon as submodulo_icono,
    s.orden as submodulo_orden
    FROM USERS u
    JOIN ROLES r ON u.rolid = r.idRol
    JOIN PERMISSIONS p ON r.idRol = p.rolid
    JOIN SUB_MODULES s ON p.submodule_id = s.idsubmodule
    JOIN MODULES m ON s.module_id = m.idmodule
    WHERE u.idUser = ?
      AND m.status = 1
      AND s.status = 1
    ORDER BY s.orden;`, [idUser]);
        return rows;
      },
      async Roles(method, params = {}) {

        try {
          // Valores por defecto
          const {
            id = null,
            name = null,
            description = null,
            status = null
          } = params;
      
          // Ejecutar el procedimiento
          const [rows] = await db.query(
            'CALL sp_role_crud(?, ?, ?, ?, ?)', 
            [method, id, name, description, status]
          );

          // Devolver resultado según el método
          if (method === 1 || method === 2) {
            return rows[0]; // Datos de los roles
          } else {
            return rows[0][0]; // Mensajes de confirmación
          }
        } catch (error) {
          console.error('Error en Roles:', error);
          throw error;
        }
      }
      
};

module.exports = Users;


