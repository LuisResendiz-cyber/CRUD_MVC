const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
            //console.log(context);

const baseQuery = "BEGIN DBO.SPS_PREDICTIVO(:v_predictivo); END;"; //DBO
	let query = baseQuery;
	const binds = {};

    try {
        binds.v_predictivo = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};
        const result = await database.simpleExecute(query, binds);
        return result;
    } catch (error) {
        console.log(error);
    }

}

module.exports.find = find;

//-------------------------------

/*DEVUELVE SI LA CAMPAÃ‘A ESTA EN PREDICTIVO

function get_EsPredictivo($db) {
    $stmt = $db->PrepareSP("BEGIN DBO.SPS_PREDICTIVO(:v_predictivo); END;");
    $db->OutParameter($stmt, $v_predictivo, 'v_predictivo');
    $db->Execute($stmt);
    return $v_predictivo;
}*/
