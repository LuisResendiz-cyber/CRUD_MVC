const oracledb = require('oracledb');
const database = require('../services/database.js');
 

 
async function find(context) {

  const baseQuery = "BEGIN "+ context.schema +".xsp_setsuper_cambio_base(:nomina, :super_destino, :asigno_base, :opcion, :result); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};
  
 if(!context.nomina || !context.super_destino || !context.asigno_base || !context.opcion){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{
          	binds.nomina = context.nomina;
            binds.super_destino = context.super_destino;
            binds.asigno_base = context.asigno_base;
            binds.opcion = context.opcion;
            binds.result = {val:context.result, dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
        	
  const result = await database.simpleExecute(query, binds);
  // console.log(result); 
  return result;
  }
}
 
module.exports.find = find;