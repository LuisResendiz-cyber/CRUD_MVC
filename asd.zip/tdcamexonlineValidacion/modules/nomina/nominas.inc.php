<?php
# OBTIENE UN NUEVO REGISTRO Y DEVUELVE EL NUMERO DE SOLICITUD
function set_activa_usuario($p_usr_id, $db){
        $stmt = $db->PrepareSP("BEGIN CSP_GETUSUARIOSA(:p_id_user); END;");
	$db->InParameter($stmt, $p_usr_id, 'p_id_user');
	$db->Execute($stmt);

        return 1;
}

# REGRESA LA BUSQUEDA DE LOS USUARIOS
function get_busqueda_usuarios($nombre_completo, $id_usuario, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_BUSQUEDAUSUARIOS('".strtoupper($nombre_completo)."',".$id_usuario.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

function get_perfil_usuario($nivel){
	$permission_array = array('A' => 'agente','AI' => 'agente_in', 'N' => 'nomina', 'V' => 'validacion','MC' => 'mesa_control', 'GO' => 'gerente_operacion', 'GV' => 'gerente_validacion', 'S' => 'supervisor');
	return strtoupper($permission_array[trim($nivel)]);
}

# OBTIENE LA LISTA DE CATALOGOS DE FORMA DINAMICA
function get_perfiles($v_id_campo, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_CATALOGO('".$v_id_campo."',:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

# DEVUELVE LA INFORMACION DEL USUARIO
function get_informacion_usuario($usr_id, $db){
	$rs = $db->ExecuteCursor("BEGIN SPS_INFOUSUARIO(".$usr_id.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}

#DEVUELVE LA LISTA DE LOS SUPERVISORES ACTIVOS
function get_supervisores($var,$db){
	$rs = $db->ExecuteCursor("BEGIN SPS_SUPERVISORES(".$var.",:rc); END;", 'rc');
	$db->SetFetchMode(ADODB_FETCH_BOTH);
	return $rs;
}


# GUARDA LOS DATOS DEL USUARIO EDITADO
function set_datos_usuario($usr_id, $nombre, $contrasena, $perfil, $activo, $supervisor, $etapa, $generacion, $db){
	$stmt = $db->PrepareSP("BEGIN SPX_NOMINAUSUARIO(:p_usr_id, :p_nombre, :p_contrasena, :p_perfil, :p_activo, :p_supervisor, :p_etapa, :p_generacion, :p_usr_id_activado); END;");
	$db->InParameter($stmt, $usr_id, 'p_usr_id');
	$db->InParameter($stmt, $nombre, 'p_nombre');
	$db->InParameter($stmt, $contrasena, 'p_contrasena');
	$db->InParameter($stmt, $perfil, 'p_perfil');
	$db->InParameter($stmt, $activo, 'p_activo');
	$db->InParameter($stmt, $supervisor, 'p_supervisor');
	$db->InParameter($stmt, $etapa, 'p_etapa');
	$db->InParameter($stmt, $generacion, 'p_generacion');
	$db->OutParameter($stmt, $p_usr_id_activado, 'p_usr_id_activado');
	$db->Execute($stmt);
	return $p_usr_id_activado;
}

?>