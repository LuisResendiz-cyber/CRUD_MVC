const { getUser } = require('../controllers/appController');
const db = require('../lib/configmysql');

const UsersModel = {
  // Obtener todos los usuarios
  async getAll() {
    const [rows] = await db.query('SELECT * FROM users');
    return rows;
  },
  async CreateUser(datosUser){
    const { username, email, password, bio, location} = datosUser;
    const [result] = await db.query("INSERT INTO users(username, email, passwordHash, bio, location) VALUES(?,?,?,?,?)", [username, email, password, bio, location]);
    return result;
  },
  async getUser(user) {
    const {id} = user;
    const [rows] = await db.query('SELECT * FROM users where userId = ?', [id]);
    return rows;
  },
  async getAcces(user){
    const {email} = user;
    const [rows] = await db.query('SELECT * FROM users where email = ?', [email]);
    return rows[0];
  }

};

module.exports = UsersModel;