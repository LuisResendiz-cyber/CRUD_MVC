import {
  openConn,
  closeConn,
  checkFiles,
  downloadFiles,
  logDig,
} from "../model/sftpModel.js";

export const start = async () => {
  try {
    console.log("\x1b[32m%s\x1b[0m",  '_'.repeat(80));
    console.log('Proceso principal INICIADO');

    if (!(await openConn())) {
      await logDig(2, "Error: No se pudo conectar al servidor SFTP");
      return false;
    }
    await logDig(1, "Conectado con exito al servidor SFTP");

    if (!(await checkFiles())) {
      await logDig(1, "Sin archivos validos en el servidor SFTP");
      await logDig(1, "Desconectado con exito del servidor SFTP");
      await closeConn();
      return false;
    }
    await logDig(1, "Archivos encontrados en el servidor SFTP");

    //* 1   outbox ARCHIVOS NUEVOS
    //* 2   sent ARCHIVOS TOCADOS

    if ((await downloadFiles(1)) == 0) {//!Importante descomentar
      await logDig(1, "Sin archivos descargados a servidor impulse");
      return false;
    }
    await logDig(1, "Archivos descargados a servidor de impulse");

    if (!(await closeConn())) {
      await logDig(
        2,
        "Error: No se pudo cerrar la conexion con el servidor SFTP"
      );
      return false;
    }
    await logDig(1, "Desconectado con exito del servidor SFTP");


    
  } catch (error) {
    await logDig(2, `Error en el proceso: ${error.message}`);
    console.error(error);
  } finally {
    await closeConn();
    console.log('Proceso principal FINALIZADO');
    console.log("\x1b[32m%s\x1b[0m",  '_'.repeat(80));

  }
  // await new Promise(resolve => setTimeout(resolve, 300000));
};
