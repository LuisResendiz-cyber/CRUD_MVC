import { Query } from "mysql2/typings/mysql/lib/protocol/sequences/Query";
import pool from "../config/dbMysqlConfig";
import { ISurvey, IinfoCustomer } from "../interfaces/ISurvey";
import { RowDataPacket } from "mysql2";

export class SurveyModel {
  public async truncateTable(nameTable: string) {
    const query = `TRUNCATE table API_BANAMEX.${nameTable}`;
    const [result] = await pool.query(query);
    return result;
  }

  public async createSurvey(survey: ISurvey, user_id: string) {
    const {
      CUSTOMERID,
      ID_PHONE,
      TYPIFICATIONID,
      CAMPAIGN,
      STATUS_FROM_TMK,
      PRODUCT,
      TDC,
      LINE_CREDIT,
      BASE_FOLIO,
      BIRTH_DATE,
      HOLDER_LAST_NAME_FATHER,
      HOLDER_LAST_NAME_MOTHER,
      HOLDER_NAME,
      RFC,
      HOMOCLAVE,
      CURP,
      COMMENTS,
      STREET,
      EXTERIOR_NUMBER,
      INTERIOR_NUMBER,
      POSTAL_CODE,
      COLONY,
      STATE,
      REFERENCE_MUNICIPALITY,
      MUNICIPALITY,
      CELL_PHONE,
      PHONE,
      CONTACT_PHONE,
      COUNTRY_BIRTH,
      FEDERAL_ENTITY,
      EMAIL,
      MONTHLY_INCOME,
      INCOME_RECEIPT_TYPE,
      IDENTIFICATION_TYPE,
      ADDRESS_RECEIPT_TYPE,
      NUMBER_REFERENCES,
      CREDIT_REFERENCE_1,
      LAST_4_DIGITS_CARD_1,
      CREDIT_REFERENCE_2,
      LAST_4_DIGITS_CARD_2,
      CREDIT_REFERENCE_3,
      LAST_4_DIGITS_CARD_3,
      PERSONAL_LAST_NAME_FATHER,
      PERSONAL_LAST_NAME_MOTHER,
      PERSONAL_NAME,
      PERSONAL_RELATIONSHIP,
      PERSONAL_PHONE,
      PERSONAL_EXTENSION,
      BRANCH_VISIT_DATE,
    } = survey;

    try {
      const [result] = await pool.query(
        `INSERT INTO SURVEYDATA (
          ID_USER,
          CUSTOMERID,
          ID_PHONE,
          TYPIFICATIONID,
          CAMPAIGN,
          STATUS_FROM_TMK,
          PRODUCT,
          TDC,
          LINE_CREDIT,
          BASE_FOLIO,
          BIRTH_DATE,
          HOLDER_LAST_NAME_FATHER,
          HOLDER_LAST_NAME_MOTHER,
          HOLDER_NAME,
          RFC,
          HOMOCLAVE,
          CURP,
          COMMENTS,
          STREET,
          EXTERIOR_NUMBER,
          INTERIOR_NUMBER,
          POSTAL_CODE,
          COLONY,
          STATE,
          REFERENCE_MUNICIPALITY,
          MUNICIPALITY,
          CELL_PHONE,
          PHONE,
          CONTACT_PHONE,
          COUNTRY_BIRTH,
          FEDERAL_ENTITY,
          EMAIL,
          MONTHLY_INCOME,
          INCOME_RECEIPT_TYPE,
          IDENTIFICATION_TYPE,
          ADDRESS_RECEIPT_TYPE,
          NUMBER_REFERENCES,
          CREDIT_REFERENCE_1,
          LAST_4_DIGITS_CARD_1,
          CREDIT_REFERENCE_2,
          LAST_4_DIGITS_CARD_2,
          CREDIT_REFERENCE_3,
          LAST_4_DIGITS_CARD_3,
          PERSONAL_LAST_NAME_FATHER,
          PERSONAL_LAST_NAME_MOTHER,
          PERSONAL_NAME,
          PERSONAL_RELATIONSHIP,
          PERSONAL_PHONE,
          PERSONAL_EXTENSION,
          BRANCH_VISIT_DATE
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          user_id,
          CUSTOMERID,
          ID_PHONE,
          TYPIFICATIONID,
          CAMPAIGN,
          STATUS_FROM_TMK,
          PRODUCT,
          TDC,
          LINE_CREDIT,
          BASE_FOLIO,
          BIRTH_DATE,
          HOLDER_LAST_NAME_FATHER,
          HOLDER_LAST_NAME_MOTHER,
          HOLDER_NAME,
          RFC,
          HOMOCLAVE,
          CURP,
          COMMENTS,
          STREET,
          EXTERIOR_NUMBER,
          INTERIOR_NUMBER,
          POSTAL_CODE,
          COLONY,
          STATE,
          REFERENCE_MUNICIPALITY,
          MUNICIPALITY,
          CELL_PHONE,
          PHONE,
          CONTACT_PHONE,
          COUNTRY_BIRTH,
          FEDERAL_ENTITY,
          EMAIL,
          MONTHLY_INCOME,
          INCOME_RECEIPT_TYPE,
          IDENTIFICATION_TYPE,
          ADDRESS_RECEIPT_TYPE,
          NUMBER_REFERENCES,
          CREDIT_REFERENCE_1,
          LAST_4_DIGITS_CARD_1,
          CREDIT_REFERENCE_2,
          LAST_4_DIGITS_CARD_2,
          CREDIT_REFERENCE_3,
          LAST_4_DIGITS_CARD_3,
          PERSONAL_LAST_NAME_FATHER,
          PERSONAL_LAST_NAME_MOTHER,
          PERSONAL_NAME,
          PERSONAL_RELATIONSHIP,
          PERSONAL_PHONE,
          PERSONAL_EXTENSION,
          BRANCH_VISIT_DATE,
        ]
      );

      return result;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  public async createSurveyNoSale(survey: ISurvey, user_id: string) {
    try {
      const { CUSTOMERID,ID_PHONE, TYPIFICATIONID } = survey;

      const [result] = await pool.query(
        `
        INSERT INTO SURVEYDATANOSALES (
          ID_USER,
          CUSTOMERID,
          ID_PHONE,
          TYPIFICATIONID
          ) VALUES (?,?,?,?)`,
        [user_id, CUSTOMERID, ID_PHONE, TYPIFICATIONID]
      );
      return result;
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  public async insertCustomerInfo(data: any, batchSize: number = 2000) {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      for (let i = 0; i < data.length; i += batchSize) {
        const batch = data.slice(i, i + batchSize);
        const query = `INSERT INTO TEM_CUSTOMER_INFO 
                      (ID_USER, CUSTOMERID,NAME,LAST_NAME_P,LAST_NAME_M,PRODUCT_TYPE,PRODUCT_1,PRODUCT_2) 
                      VALUES ?`;

        const values = batch.map((data: IinfoCustomer) => [
          data.ID_USER,
          data.CUSTOMERID,
          data.NAME,
          data.LAST_NAME_P,
          data.LAST_NAME_M,
          data.PRODUCT_TYPE,
          data.PRODUCT_1,
          data.PRODUCT_2,
        ]);

        await connection.query(query, [values]);
        // console.log(`Processed batch ${i / batchSize + 1}`);
      }

      await connection.commit();
      // return data.length;
      let [countRows] = await connection.query(
        "SELECT COUNT(*) ROWSINSERT FROM TEM_CUSTOMER_INFO"
      );
      return countRows;
    } catch (err) {
      await connection.rollback();
      throw err;
    } finally {
      connection.release();
    }
  }

  public async getCustomerInfo(CUSTOMERID: string, user_id: string) {
    const query =
      "SELECT CUSTOMERID,NAME,LAST_NAME_P,LAST_NAME_M,PRODUCT_TYPE,PRODUCT_1,PRODUCT_2 FROM API_BANAMEX.TEM_CUSTOMER_INFO WHERE ID_USER = ? AND CUSTOMERID = ?";
    // const [rows] = await pool.query(query, [CUSTOMERID]);
    const [rows] = await pool.query<RowDataPacket[]>(query, [
      user_id,
      CUSTOMERID,
    ]);

    return rows;
  }

  public async getAllCustomerInfo(page: number, limit: number, offset: number) {
    const query =
      "SELECT CUSTOMERID,NAME,LAST_NAME_P,LAST_NAME_M,PRODUCT_TYPE,PRODUCT_1,PRODUCT_2 FROM API_BANAMEX.TEM_CUSTOMER_INFO LIMIT ? OFFSET ?";

    const countQuery = "SELECT COUNT(*) TOTAL FROM TEM_CUSTOMER_INFO";

    const [rows, countResult] = await Promise.all([
      pool.query<RowDataPacket[]>(query, [limit, offset]),
      pool.query<RowDataPacket[]>(countQuery),
    ]);

    const total = countResult[0][0].TOTAL;
    const totalPages = Math.ceil(total / limit);

    return {
      data: rows[0],
      pagination: {
        total,
        totalPages,
        currentPage: page,
        itemsPerPage: limit,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    };
  }

  public async getSpecificAllSurveys(user_id: string): Promise<ISurvey[]> {
    const query = `
    select 
    CUSTOMERID
    ,TYPIFICATIONID
    ,CAMPAIGN 
    ,STATUS_FROM_TMK 
    ,PRODUCT 
    ,TDC 
    ,LINE_CREDIT 
    ,BASE_FOLIO 
    ,BIRTH_DATE 
    ,HOLDER_LAST_NAME_FATHER 
    ,HOLDER_LAST_NAME_MOTHER 
    ,HOLDER_NAME 
    ,RFC 
    ,HOMOCLAVE 
    ,CURP 
    ,COMMENTS 
    ,STREET 
    ,EXTERIOR_NUMBER 
    ,INTERIOR_NUMBER 
    ,POSTAL_CODE 
    ,COLONY 
    ,STATE 
    ,REFERENCE_MUNICIPALITY 
    ,MUNICIPALITY 
    ,CELL_PHONE 
    ,PHONE 
    ,CONTACT_PHONE 
    ,COUNTRY_BIRTH 
    ,FEDERAL_ENTITY 
    ,EMAIL 
    ,MONTHLY_INCOME 
    ,INCOME_RECEIPT_TYPE 
    ,IDENTIFICATION_TYPE 
    ,ADDRESS_RECEIPT_TYPE 
    ,NUMBER_REFERENCES 
    ,CREDIT_REFERENCE_1 
    ,LAST_4_DIGITS_CARD_1 
    ,CREDIT_REFERENCE_2 
    ,LAST_4_DIGITS_CARD_2 
    ,CREDIT_REFERENCE_3 
    ,LAST_4_DIGITS_CARD_3 
    ,PERSONAL_LAST_NAME_FATHER 
    ,PERSONAL_LAST_NAME_MOTHER 
    ,PERSONAL_NAME 
    ,PERSONAL_RELATIONSHIP 
    ,PERSONAL_PHONE 
    ,PERSONAL_EXTENSION
    ,BRANCH_VISIT_DATE
    
    FROM API_BANAMEX.SURVEYDATA 
    WHERE date(DATE_INSERT) <= CURDATE()-5 and ID_USER = ? 
    `;
    const [rows] = await pool.query(query, [user_id]);
    return rows as ISurvey[];
  }

  public async getAllSurveys(): Promise<ISurvey[]> {
    const query = `SELECT
      ID_SURVEY, DATE_FORMAT(DATE_INSERT, '%d/%m/%Y %H:%i:%S') DATE_INSERT, STATUS_SURVEY, ID_USER, CUSTOMERID, ID_PHONE,TYPIFICATIONID,
      CAMPAIGN, STATUS_FROM_TMK, PRODUCT, TDC, LINE_CREDIT, BASE_FOLIO, BIRTH_DATE, 
      HOLDER_LAST_NAME_FATHER, HOLDER_LAST_NAME_MOTHER, HOLDER_NAME, RFC, HOMOCLAVE, 
      CURP, COMMENTS, STREET, EXTERIOR_NUMBER, INTERIOR_NUMBER, POSTAL_CODE, COLONY, 
      STATE, REFERENCE_MUNICIPALITY, MUNICIPALITY, CELL_PHONE, PHONE, CONTACT_PHONE, 
      COUNTRY_BIRTH, FEDERAL_ENTITY, EMAIL, MONTHLY_INCOME, INCOME_RECEIPT_TYPE, 
      IDENTIFICATION_TYPE, ADDRESS_RECEIPT_TYPE, NUMBER_REFERENCES, CREDIT_REFERENCE_1, 
      LAST_4_DIGITS_CARD_1, CREDIT_REFERENCE_2, LAST_4_DIGITS_CARD_2, CREDIT_REFERENCE_3, 
      LAST_4_DIGITS_CARD_3, PERSONAL_LAST_NAME_FATHER, PERSONAL_LAST_NAME_MOTHER, 
      PERSONAL_NAME, PERSONAL_RELATIONSHIP, PERSONAL_PHONE, PERSONAL_EXTENSION, 
      BRANCH_VISIT_DATE    
      FROM API_BANAMEX.SURVEYDATA WHERE STATUS_SURVEY = 0`;
    const [rows] = await pool.query(query);
    return rows as ISurvey[];
  }

  public async getAllSurveysNoSales(): Promise<ISurvey[]> {
    // const query = `SELECT * from API_BANAMEX.SURVEYDATANOSALES WHERE date(DATE_INSERT) >= CURDATE()-10`;
    const query = `
      SELECT ID_SURVEYNOSALE,DATE_FORMAT(DATE_INSERT, '%d/%m/%Y %H:%i:%S') DATE_INSERT,STATUS_NOSALE,ID_USER,CUSTOMERID,TYPIFICATIONID,ID_PHONE  
      from API_BANAMEX.SURVEYDATANOSALES
      WHERE STATUS_NOSALE = 0`;
    const [rows] = await pool.query(query);
    return rows as ISurvey[];
  }

  public async updateSurvey(ID_SURVEY: number, STATUS_SURVEY: ISurvey) {
    const query = `UPDATE API_BANAMEX.SURVEYDATA SET STATUS_SURVEY = ? WHERE ID_SURVEY = ?`;
    const [result] = await pool.query(query, [STATUS_SURVEY, ID_SURVEY]);
    return result;
  }

  public async updateSurveys(
    option: number,
    ID_SURVEYS: number[],
    STATUS_SURVEYS: number[]
  ) {
    if (![1, 2].includes(option)) {
      // Asumiendo que solo hay 2 opciones válidas
      throw new Error("Invalid option value");
    }

    const tableConfig = {
      1: {
        tableName: "SURVEYDATA",
        idColumn: "ID_SURVEY",
        statusColumn: "STATUS_SURVEY",
      },
      2: {
        tableName: "SURVEYDATANOSALES",
        idColumn: "ID_SURVEYNOSALE",
        statusColumn: "STATUS_NOSALE",
      },
    };
    const { tableName, idColumn, statusColumn } = tableConfig[option as 1 | 2];

    let query = `UPDATE API_BANAMEX.${tableName} SET ${statusColumn} = CASE ${idColumn} `;

    const updates: string[] = [];
    const values: (string | number)[] = [];

    ID_SURVEYS.forEach((id, index) => {
      updates.push(`WHEN ? THEN ?`);
      values.push(id, STATUS_SURVEYS[index]);
    });

    query +=
      updates.join(" ") +
      ` END WHERE ${idColumn} IN (${ID_SURVEYS.map(() => "?").join(",")})`;

    values.push(...ID_SURVEYS);
    const [result] = await pool.query(query, values);
    return result;
  }
}
