<?php

# @uthor Mark 
# Process_data File 

require_once("includes/includes.inc.php");
require_once("external.inc.php");

//initialize_nolayout("agente,supervisor", "");

$action = desencripta($_REQUEST['act']);

//$isPredictivo = get_EsPredictivo($db);
$isPredictivo = 0;
$header = "index.php";

	
if (isset($action) && $action == 1) { //BOMBARDIKMAN
	
	echo libera_extension($_POST["extension"], $db);
	//echo $_POST["extension"];
    die();	
	
} elseif (isset($action) && $action == 2) { ### NEXT FUNCTION
	die();
}
header("location: " . $header);
