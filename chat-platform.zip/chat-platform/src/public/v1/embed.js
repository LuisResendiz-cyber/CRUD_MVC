(function () {
  // Evitar cargar el widget dos veces
  if (window.__CHAT_WIDGET_LOADED__) return;
  window.__CHAT_WIDGET_LOADED__ = true;

  const SCRIPT_TAG = document.currentScript;

  // Configuración básica (luego crecerá)
  const CONFIG = {
    clientId: SCRIPT_TAG.getAttribute("data-client-id") || "demo",
    baseUrl: SCRIPT_TAG.src.replace("/embed.js", ""),
  };

  /* =========================
       ESTILOS DEL BOTÓN
    ========================== */
  const style = document.createElement("style");
  style.innerHTML = `
      #chat-launcher {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: #d32f2f;
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 24px;
        box-shadow: 0 6px 20px rgba(0,0,0,.25);
        z-index: 999999;
      }
  
      #chat-iframe {
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 360px;
        height: 520px;
        border: none;
        border-radius: 14px;
        box-shadow: 0 10px 40px rgba(0,0,0,.2);
        z-index: 999999;
        display: none;
        background: transparent;
      }
  
      @media (max-width: 400px) {
        #chat-iframe {
          right: 0;
          bottom: 0;
          width: 100%;
          height: 100%;
          border-radius: 0;
        }
      }
    `;
  document.head.appendChild(style);

  /* =========================
       BOTÓN FLOTANTE
    ========================== */
  const button = document.createElement("button");
  button.id = "chat-launcher";
  button.innerHTML = "💬";

  /* =========================
       IFRAME DEL CHAT
    ========================== */
  const iframe = document.createElement("iframe");
  iframe.id = "chat-iframe";
  iframe.src = `${CONFIG.baseUrl}/widget.html?clientId=${CONFIG.clientId}`;
  iframe.allow = "clipboard-write";

  /* =========================
       TOGGLE CHAT
    ========================== */
  let isOpen = false;

  button.addEventListener("click", () => {
    isOpen = !isOpen;
    iframe.style.display = isOpen ? "block" : "none";
  });

  /* =========================
       INYECTAR EN DOM
    ========================== */
  document.body.appendChild(button);
  document.body.appendChild(iframe);

  // Escuchar mensajes del iframe
  window.addEventListener("message", (event) => {
    if (!event.data) return;

    if (event.data.type === "CHAT_WIDGET_CLOSE") {
      isOpen = false;
      iframe.style.display = "none";
    }
  });

  window.addEventListener("load", () => {
    isOpen = true;
    iframe.style.display = "block";
  });
})();
