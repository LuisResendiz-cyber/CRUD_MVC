const mysql = require('mysql'); 
const dbConfig = require('../config/database_mysql.js');

// console.log(dbConfig.objConfiguracion);
module.exports = mysql.createPool(dbConfig.objConfiguracion); 