<?php
header('Content-Type: application/json'); 
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/models/ApiModel.php';
require_once __DIR__ . '/../app/models/OracleModel.php';
require_once __DIR__ . '/../app/controllers/ApiController.php';

// // Acceder a las variables
$controller = new ApiController();
$response =$controller->getNoSales();
echo json_encode($response);

die();
 