<?php
require_once("includes/includes.inc.php");


$valor_return = 0;
$message = "";
echo get_session_varname('s_usr_tipo_base');
load_session();

if (isset($_GET["log_out"])) {
    $message = "Ha finalizado tu sesion.";
}

if (isset($_GET["msg"])) {
    $valor_return = desencripta($_GET["msg"]);
    switch ($valor_return) {
        case 1:
            $message = "La clave de usuario y/o contrase&ntilde;a no es valida...";
            break;
        case 2:
            $message = "La clave de usuario y/o contrase&ntilde;a no es valida...";
            break;
        case 4:
            $message = "Error de base de datos...";
            break;
        case 3:
            $message = "Sesi&oacute;n ocupada...";
            break;
        case 5:
            $message = "Tu contrase&ntilde;a est&aacute; por caducar.\n\nPor favor solicita que la reseteen para no perder tu acceso...\n";
            break;
        case 6:
            $message = "Tu contrase&ntilde;a caduca hoy mismo.\n\nPor favor solicita que la reseteen o no tendr&aacute;s acceso ma&ntilde;ana...\n";
            break;
        case 7:
            $message = "Tu contrase&ntilde;a ha caducado.\n\nPor favor solicita que la reseteen para volver a tener acceso...\n";
            break;
        case 8:
            $message = "Tu extensi�n se encuentra ocupada.\n\nPide que liberen tu extensi&oacute;n para volver a tener acceso...\n";
            break;
        case 9:
            $message = "Bloqueado por falta injustificada\n";
            break;
        case 10:
            $message = "Has rebasado el n&utilde;mero de intentos\n\nTu usuario ha sido bloquedo...";
            break;
        case 11:
            $message = "El usuario ha sido bloqueado, para el desbloquear lo podra hacer solo y unicamente (Supervisro,Jefe operacion,guns)";
            break;
        case 11:
            $message = "El usuario ha sido bloqueado, para el desbloquear lo podra hacer solo y unicamente (Supervisro,Jefe operacion,guns)";
            break;
        case 12:
            $message = "Tu cuenta tiene Autorizaci&oacute;n de Permiso, notificar t&uacute; regreso(Jefe) para que activen tu session.";
            break;
        case 13:
            $message = "N� NOMINA NO EXISTE EN PLANTILLA.";
            break;
        case 14:
            $message = "Usuario no existe en sicall.";
            break;
        case 15:
            $message = "Usuario no esta asignado a la Campa�a.";
            break;
        case 17.1:
            $message = "Ocurrio un problema, Sin informacion 1";
            break;
        case 17.2:
            $message = "Ocurrio un problema, Sin informacion 2";
            break;
        case 17.3:
            $message = "Ocurrio un problema, Sin informacion 3";
            break;
        
    }
}

layout_header("Inicio");
if(get_session_varname("s_usr_marcacion") == 1){
    $body = " inicio_marcar(".get_session_varname("s_usr_marcacion")."); ";
}else{
    $body = "";
}

layout_menu($db,$body);

if (is_logged()) {
    if ($valor_return == 5 || $valor_return == 6) {
        echo $message;
    }
    echo 'Seleccione una opcion del menu que se encuentra a la izquierda<br>
        <form name="GenericForm" action="#" method="POST"></form>';
} else {
    layout_loggin($message);
}

if (isset($message) && $message != ""){
    ?>
<script>
    swal({
        title: "<?= html_entity_decode($message) ?>",
        text: "",
        type: "warning",
        showConfirmButton: true
    });
</script>
    <?php
}

if(!is_logged()){


	//if($_SERVER['REMOTE_ADDR'] == '172.20.2.15') {
		$ip = $_SERVER['REMOTE_ADDR'];

		switch (substr($ip, 0, 7)) {
                    case '172.20.': 
			$ip_number = str_replace("172.20.", "", $ip);
                        break;
                    case '172.21.': 
            $ip_number = str_replace("172.21.", "", $ip);
                        break;
                    case '172.30.': 
            $ip_number = str_replace("172.30.", "", $ip);
                        break;
                    case '172.23.': 
                        if (intval(substr($ip, strlen($ip)-3,strlen($ip))) > 100)  {
                            $ip_number = str_replace("172.23.62", "64.", $ip);                                                                
                        }else{
                            $ip_number = str_replace("172.23.", "", $ip);
                        }                        
                        break;
                    case '192.168': 
                        $ip_number = str_replace("192.168.", "", $ip);
                        break;
		}
                if (strlen($ip_number) <= 4) {
                    $ini_ext_ip = substr($ip_number, 1, 1);
                    $fin_ext_ip = substr($ip_number, 3, 5);

                    if ($ini_ext_ip == '.') {
                        $ip_number = str_pad($ip_number, 5, "0", STR_PAD_LEFT);
                    } else {
                        if ($fin_ext_ip != '.') {
                            $ip_number = substr($ip_number, 0, 2) . str_pad($fin_ext_ip, 2, "0", STR_PAD_LEFT);
                        }
                    }
                } elseif (strlen($ip_number) == 6){
                    $ini_ext_ip = substr($ip_number, 0, 2);
                    $fin_ext_ip = substr($ip_number, 3, 6);

                    switch ($fin_ext_ip){
                        case "100":
                        $fin_ext_ip = str_replace("1","",$fin_ext_ip);
                        $ip_number = $ini_ext_ip.$fin_ext_ip;
                        break;
                        case "101":case "102":case "103":case "104":case "105":case "106":case "107":case "108":case "109":
                        case "110":case "111":case "113":case "114":case "115":case "116":case "117":case "118":case "119":
                        $fin_ext_ip = str_replace("2","",$fin_ext_ip);
                        $ip_number = $ini_ext_ip.$fin_ext_ip;
                        $ip_number = $ip_number + 2000;
                        break;
                        case "200":case "201":case "203":case "204":case "205":case "206":case "207":case "208":case "209":
                        case "210":case "211":case "213":case "214":case "215":case "216":case "217":case "218":case "219":
                        case "220":case "221":case "223":case "224":case "225":case "226":case "227":case "228":case "229":
                        $fin_ext_ip = str_replace("2","",$fin_ext_ip);
                        $ip_number = $ini_ext_ip.$fin_ext_ip;
                        $ip_number = $ip_number + 100;
                        break;
                        case "202":case "212":case "222":
                        $fin_ext_ip = substr($fin_ext_ip,1,2);
                        $ip_number = $ini_ext_ip.$fin_ext_ip;
                        $ip_number = $ip_number + 100;
                        break;
                    }
                }

                $extension = str_replace(".", "", $ip_number);

                //ajuste para cuando la �ltima parte de la IP es de 3 cifras
                if ($extension >= 10000) {
                    $extension = 100 * floor($extension / 1000) + $extension % 100;
                }



                switch ($extension) {
                    case "0027":
                    $extension = "1076";
                    break;
                    case "0251":
                    $extension = "1065";
                    break;
                    case "0224":
                    $extension = "1063";
                    break;
                    case "0214":
                    $extension = "1069";
                    break;
                    case "0216":
                    $extension = "1064";
                    break;
                    case "0233":
                    $extension = "1165";
                    break;
                    case "0022":
                    $extension = "1070";
                    break;
                }
                
		echo "<br />Extensi&oacute;n: $extension";
		?>
			<br />
			<input type="button" value="Liberar extension" id="btnLibExt" onclick="/*this.disabled = true;*/
					liberar_extension(<?= $extension ?>, '<?= encripta(1) ?>', this)"/>&nbsp;&nbsp;
			<br />
			<div id = "LibExtContainer" name = "LibExtContainer">
			</div>
		
		<?php
	//}

	
}


layout_footer();