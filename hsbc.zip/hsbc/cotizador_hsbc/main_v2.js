import {
  quotationDate,
  saveData,
  updateCustomerTable,
  generateTable
} from "./functions_v2.js";

import { hea,agfu,asim,acsel  } from "./quotationObjects.js";

const principalInputs = document.querySelectorAll(
  "#D5, #D6, #D7, #D8, #D9, #D10, #funeralExpenses"
);

const customerTableInputs = document.querySelectorAll(
  ".date-of-birth, .gender"
);
const tbl_hea = document.getElementById("tbl_hea");
const tbl_agfu = document.getElementById("tbl_agfu");
const tbl_asim = document.getElementById("tbl_asim");
const tblAcsel = document.getElementById("tblAcsel");
const btnNewQuotation = document.getElementById("btnNewQuotation");

window.addEventListener("load", function () {
  console.log(
    "%c Developed by dtrejo",
    "color: blue; font-size: 20px; font-weight: bold; background-color: white; padding: 4px; border-radius: 4px;"
  );
  // console.clear();

  quotationDate(); //!load actual date

  tbl_hea.innerHTML= generateTable(hea);
  tbl_agfu.innerHTML= generateTable(agfu);
  tbl_asim.innerHTML= generateTable(asim);
  tblAcsel.innerHTML= generateTable(acsel);
});

principalInputs.forEach((input) => {
  input.addEventListener("change", (event) => {
    saveData(principalInputs);    
  });
});

customerTableInputs.forEach((input) => {
  input.addEventListener("change", handleInputChange);
});


function handleInputChange(event) {
  saveData(principalInputs);
  updateCustomerTable(event);
  saveData(principalInputs);
}

//! La funcion saveData se manda llamar dos veces ya que el calculo de Suma Asegurada no se actualiza correctamente
//!NO CAMBIAR EL ORDER DE COMO SE EJECUTA ESTA FUNCION handleInputChange



const newQuotation = () => {
  const currentUrl = window.location.href;
  const separator = currentUrl.includes('?') ? '&' : '?';
  const newUrl = `${currentUrl}${separator}refresh=${new Date().getTime()}`;
  window.location.href = newUrl;
}

btnNewQuotation.addEventListener('click',newQuotation)


