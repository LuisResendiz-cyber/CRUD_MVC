import express, { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

declare global {
    namespace Express {
      interface Request {
        user?: any;
      }
    }
  }
  

const authenticateJWT = (req: Request, res: Response, next: NextFunction):void => {
    const token = req.header('Authorization')?.split(' ')[1];

    if (token) {
        jwt.verify(token, process.env.JWT_SECRET as string, (err, user) => {
            if (err) {
                res.status(403).json(err); 
                return

            }
            req.user = user as { username: any};
            next();
        });
    } else {
        // res.sendStatus(401); // Unauthorized
        res.status(401).json({error: "Unauthorized" }); 
        return
    }
};

export default authenticateJWT;




