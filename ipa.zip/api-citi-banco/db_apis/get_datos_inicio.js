const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN "+ context.schema +".Sps_DatosInico_web_Val(:varUserID, :v_producto, :rc); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.varUserID || !context.v_producto){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.varUserID = context.varUserID;
            binds.v_producto = context.v_producto;
   			binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;  
                }
}
 
module.exports.find = find;