const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

    console.log(context);
    try {      
      const baseQuery = "BEGIN "+ context.schema +".SPS_DOMICILIO(:v_sirh, :rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};

  	binds.v_sirh     = context.sirh;
  	binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

  const result = await database.simpleExecuteRC(query, binds);
	console.log('...', result, '...');
  return result;
} catch (error) {
  console.log(error);
}
}

module.exports.find = find;
