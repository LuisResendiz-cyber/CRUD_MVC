const axios = require("axios");
require("dotenv").config();

async function transcribeAudio(fileBuffer) {
  const apiKey = process.env.ELEVENLABS_API_KEY;

  const res = await axios.post(
    "https://api.elevenlabs.io/v1/speech-to-text",
    fileBuffer,
    {
      headers: {
        "Content-Type": "audio/mpeg",
        "xi-api-key": apiKey
      }
    }
  );

  return res.data.text;
}

module.exports = { transcribeAudio };
