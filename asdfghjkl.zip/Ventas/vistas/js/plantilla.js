


         /*    var iframe = document.getElementById("miIframe");

            var url = "https://www.ejemplo.com";

            iframe.src = url; */


	  

// document.addEventListener("DOMContentLoaded", function() {
	
	
//    var iframe = document.createElement("iframe");
    
//     iframe.src = "https://www.w3schools.com";
//     iframe.style.width = "100%";
//     iframe.style.height = "100%";
//     iframe.style.border = "none";

//     // Agrega el iframe al contenedor
//     document.getElementById("iframeContainer").appendChild(iframe);
// });

// document.addEventListener("DOMContentLoaded", function () {
// 	var iframe = document.getElementById("miIframe");
// 	var url = "https://www.w3schools.com";
// 	iframe.src = btoa(url); // Codifica la URL en base64
//       });


/* 
document.addEventListener("DOMContentLoaded", function() {
   // URL encriptada (puedes utilizar tu propio método de encriptación)
   var encryptedURL = "aHR0cHM6Ly9hcHAucG93ZXJiaS5jb20vdmlldz9yPWV5SnJJam9pTkdSbE56WTJOV0l0WWpBM05DMDBZMkpoTFdKaE1qRXRZamt5WW1Nek1qUm1NV0UwSWl3aWRDSTZJamRsTVRJNVpqVmpMV1l4TmpJdE5EaGxZaTA1TlRRMUxURXdZVE5rT0RSa05EUXdOU0o5";

   // Decodificar la URL encriptada
   var decodedURL = atob(encryptedURL);

   // Crear el elemento iframe dinámicamente
   var iframe = document.createElement("iframe");
   
   // Configurar los atributos del iframe
   iframe.src = decodedURL;
   iframe.style.width = "100%";
   iframe.style.height = "100%";
   iframe.style.border = "none";

   // Agregar el iframe al contenedor
   document.getElementById("iframeContainer").appendChild(iframe);
}); 

 */