<?php 

	class Roles extends Controllers{						
		
		private AuthService $auth;

		public function __construct()
		{
			parent::__construct();
			session_start();
			if(empty($_SESSION['login']))
			{
				header('Location: '.base_url().'/login');
			}
			getPermisos(2);
			$this->auth = new AuthService();
		}

		public function Roles()
		{
			if(empty($_SESSION['permisosMod']['r'])){
				header("Location:".base_url().'/dashboard');
			}
			$data['page_id'] = 3;
			$data['page_tag'] = "Roles Usuario";
			$data['page_name'] = "rol_usuario";
			$data['page_title'] = "Roles Usuario <small> Impulse Bots</small>";
			$data['page_functions_js'] = "functions_roles.js";
			$this->views->getView($this,"roles",$data);
		}

		public function getRoles()
		{
			$btnView = '';
			$btnEdit = '';
			$btnDelete = '';
			//$arrData = $this->model->selectRoles();
			$authService = new AuthService();
			$arrData = $authService->getRoles();//METHOD_GET

			echo json_encode($arrData,JSON_UNESCAPED_UNICODE);
			die();
		}

		public function getSelectRoles()
		{
			$htmlOptions = "";
			$arrData = $this->model->selectRoles();
			if(count($arrData) > 0 ){
				for ($i=0; $i < count($arrData); $i++) { 
					if($arrData[$i]['status'] == 1 ){
					$htmlOptions .= '<option value="'.$arrData[$i]['idrol'].'">'.$arrData[$i]['nombrerol'].'</option>';
					}
				}
			}
			echo $htmlOptions;
			die();		
		}

		public function getRol(int $idrol){
			$intIdrol = intval(strClean($idrol));
			if($intIdrol > 0)
			{
				$authService = new AuthService();
				$arrData = $authService->getRol($intIdrol);

				if(empty($arrData)){
					$arrResponse = array('status' => false, 'msg' => 'Datos no encontrados.');
				}else{
					$arrResponse = $arrData;
					array_push($arrResponse, 'modalFormRol');
				}
				echo json_encode($arrResponse,JSON_UNESCAPED_UNICODE);
			}
			die();
		}

		public function setRol(){
			$intIdrol = intval($_POST['idRol']);
			$strRol =  strClean($_POST['txtNombre']);
			$strDescipcion = strClean($_POST['txtDescripcion']);
			$intStatus = intval($_POST['listStatus']);

			$authService = new AuthService();
			
			
			if($intIdrol == 0){
				//Crear
				$request_rol = $authService->createRol($strRol, $strDescipcion,$intStatus);
				$option = 1;
			}else{
				//Actualizar
				$request_rol = $authService->updateRol($intIdrol, $strRol, $strDescipcion, $intStatus);
				$option = 2;
			}

			echo json_encode($request_rol,JSON_UNESCAPED_UNICODE);
			die();
		}

		public function delRol(int $idrol)
		{
				$intIdrol = intval($idrol);
				$authService = new AuthService();
				$requestDelete = $authService->deleteRol($intIdrol);
				echo json_encode($requestDelete,JSON_UNESCAPED_UNICODE);
			
			die();
		}

	}
 ?>