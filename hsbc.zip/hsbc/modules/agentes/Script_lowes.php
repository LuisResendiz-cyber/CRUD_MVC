<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
	<TITLE></TITLE>
	<META NAME="GENERATOR" CONTENT="LibreOffice 3.5  (Linux)">
	<META NAME="AUTHOR" CONTENT="jlara ">
	<META NAME="CREATED" CONTENT="20151110;11393200">
	<META NAME="CHANGEDBY" CONTENT="jlara ">
	<META NAME="CHANGED" CONTENT="20151110;11394700">
	<STYLE TYPE="text/css">
	<!--
		@page { margin: 2cm }
		P { margin-bottom: 0.21cm }
	-->
	</STYLE>
</HEAD>
<BODY LANG="es-ES" DIR="LTR">
    <img align="center" src="includes/imgs/lowes.jpg" /><br />
    <p>SCRIPT DE VENTA LOWE'S</p>
    <p align="justify">
Hola buen d&iacute;a mi nombre es _______________de Invex y Lowe's antes que nada
gracias por recibir mi llamada y el motivo de esta es para hacerle una cordial
invitaci&oacute;n a conocer nuestra nueva tarjeta Lowe's oro, con la que brindaremos un
mejor servicio y beneficios exclusivos por ser cliente del programa de Lealtad
LOWE'S (mencionar el programa al que pertenece).
    </p>
    <p align="justify">
La tarjeta le brinda el primer a&ntilde;o sin costo de anualidad y beneficios, como ejemplo,
al pagar con su nueva tarjeta le otorga una bonificaci&oacute;n del 10% en su primera
compra en LOWE'S, adem&aacute;s un bono de bienvenida por 3,000 puntos mediante
nuestro programa gratuito de Recompensas Select que tambi&eacute;n le otorgar&aacute; un
punto por cada $10 de compra.
    </P>
    <p align="justify">
Tambi&eacute;n le comento que cuenta con coberturas de protecci&oacute;n de compras, de
precio, garant&iacute;a extendida y seguro de alquiler de auto, esta tarjeta est&aacute; respaldada
por VISA lo que le da un respaldo internacional haciendo extensivos los beneficios
en todas sus compras y no solo en la tienda LOWE'S y el l&iacute;mite de cr&eacute;dito
preautorizado podr&iacute;a ser desde los 7 mil hasta los 100 mil pesos y por si fuera poco
sus compras las podr&aacute; diferir a 3,6,9,12,18 y 20 meses sin intereses con un m&iacute;nimo
de $2,500 y 6 meses en sus compras en el extranjero.
    </P>
    <p align="justify">
Por &uacute;ltimo, mencionarle que al realizar sus compras mayores a $1,000 con su tarjeta
tendr&aacute; un 3% adicional en el programa de Lealtad LOWE'S, Para personalizar su
tarjeta &iquest;cu&aacute;l es su nombre completo?
    </p>
    <p>SONDEO.</P>
    <p>&iquest;Con que tarjeta se maneja actualmente?</P>
    <p>&iquest;Cu&aacute;l es la antig&uuml;edad con su tarjeta?</P>
    <p>&iquest;A cu&aacute;nto asciende su l&iacute;nea de cr&eacute;dito m&aacute;s alta?</p>
    <p>&iquest;La tarjeta se la entregaremos a casa u oficina?</P>

</BODY>
</HTML>