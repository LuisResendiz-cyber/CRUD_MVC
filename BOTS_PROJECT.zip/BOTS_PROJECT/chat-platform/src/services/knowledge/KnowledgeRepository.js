// repositories/KnowledgeRepository.js

class KnowledgeRepository {
    constructor(db) {
      this.db = db;
    }
  
    async getByBot(idBot) { 
      const [rows] = await this.db.query(
        `
        SELECT id, title, content, tags, priority
        FROM BOT_KNOWLEDGE
        WHERE id_bot = ?
          AND is_active = 1
        ORDER BY priority DESC, id ASC
        `,
        [idBot]
      );
  
      return rows.map(row => ({
        id: row.id,
        title: row.title,
        content: row.content,
        tags: row.tags ? JSON.parse(row.tags) : [],
        priority: row.priority
      }));
    }
  }
  
  module.exports = KnowledgeRepository;
  