const get_datos_inicio = require('../db_apis/get_datos_inicio.js');
 
async function post(req, res, next) {
  try {
    const context = req.body;//{};  
 
    const rows = await get_datos_inicio.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;