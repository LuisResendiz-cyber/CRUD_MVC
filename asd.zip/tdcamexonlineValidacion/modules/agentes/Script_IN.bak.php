<?php
# Script IN File
# @uthor Mark

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","Nuevo registro");

//$id_solicitud = $_REQUEST['sol'];
$agente = get_session_varname('s_usr_nombre');
//$registro = get_detalle_solicitud($id_solicitud, $db);
//$NOMBRE_COMPLETO = $registro->fields["NOMBRE_COMPLETO"];
//$PATERNO = $registro->fields["PATERNO"];
//$DIGITOS = $registro->fields["DIGITOS"];
$NOMBRE_COMPLETO = "";
$PATERNO = "";
$DIGITOS = '00';
?>
<html>
    <head>
        <title>GUI&oacute;N TELEMARKETING</title>
    </head>
<body>

<p><b><span style='font-size:14.0pt;color:red'>Inbound Balance Transfer</span></b></p>

<table border="1"  style="border-style:solid;border-width:1px;border-color:black;">
	<tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Conversaci&oacute;n 1:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p>
                <span>Buenos (as) d&iacute;as/tardes/noches, le atiende </span>
				<span style='color:red'><?=$agente ?>.</span>
				<span>del Grupo Financiero Santander, en que puedo servirle? </span>
			</p>
			<p><span>&nbsp;</span></p>			
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Cliente:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Recibe una información acerca de la posibilidad de transferir saldos de otras TDC a mi tarjeta Santander.</span></p>
			<p><span>&nbsp;</span></p>			
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) <span style='color:red'><?=$PATERNO ?>.</span>, me puede indicar por favor los siguientes datos:</span></p>
			<p><span>&nbsp;</span></p>
			<p><span>
				<UL type = square>
                    <LI> Los 16 dígitos de su TDC
                    <LI> Su nombre completo por favor,
                    <LI> Su número telefónico principal,
                    <LI> Algún celular en el que lo podamos localizar por favor
                    <LI> Su correo electrónico por favor.
       			</UL>
			</span></p>			
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Revisar si este cliente está en la base de Balance Transfer Inbound  para poder explicarle el proceso para transferir saldos así como la tasa que aplica. </span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>   a) Si, esta dentro de la base -- Continuar con la conversación.</span></p>
            <br><br>
			<p><span>b) No esta dentro de la base -- Rectificar datos del cliente o tomar información sobre el cliente para que se verifique posteriormente si esta dentro de la base o no.</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
            <p><span>Muchas gracias por la espera.</span></p><br>
            <p><span>Muy bien Sr.(ita.) <?=$NOMBRE_COMPLETO ?>.,  Permítame comentarle que debido al buen uso que ha hecho del crédito de su Tarjeta Santander (DESC_PRODUCTO) terminación (ULT_4_DIGITOS), le vamos a recompensar con una tasa preferencial de (TRAERLO DE BD)% anual.</span></p><br>
            <p><span><b>Con esta tasa preferencial va a poder ahorrar mucho dinero, ya que nosotros le podemos ayudar a que pague sus tarjetas de crédito de otros Bancos, las cuales son mucho más caras. Además este servicio es en línea y no le costará ni un solo peso por ser un cliente distinguido.</b></span></p><br>
            <p><span>Para su tranquilidad y conveniencia, Ud. puede elegir entre 6, 12 o 18 meses para pagar, con lo cual tendrá la certidumbre de saber cuánto pagará y por cuánto tiempo.</span></p>
            <p><span>Para aprovechar esta oportunidad lo único que requerimos es confirmar algunos de sus datos.</span></p>
            <p><span>¿Desea realizar una transferencia en este momento?</span></p>
    	</td>
	</tr><tr>
    	<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >cliente </span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>   a) Si, Pasar a Transferencia de saldo .</span></p>
            <br><br>
			<p><span>b) No, Pasar a despedida.</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Transferencia de Saldo:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>			
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
            <p><span>Sr./Srita. (Apellido), a continuación le pido tenga a la mano su tarjeta Santander Black  terminación (ULT_4_DIGITOS) y la Tarjeta de la cuál desea hacer la transferencia.</span></p><br>
            <p><span>1.Ejecutivo telefónico ingresa su número de usuario y password a la aplicación de transferencias de saldo y confirma al cliente los datos precargados </span></p><br>
            <p><span>2.Captura los 16 dígitos de la tarjeta Santander y de la Tarjeta del otro banco, así como el monto a transferir</span></p><br>
            <p><span>3.Elige el plazo en la aplicación de acuerdo a solicitud del cliente.</span></p><br>
            <p><span>4.Proporciona # de folio de transferencia al cliente.</span></p><br>
            <p><span>Sr./Srita. (Apellido), su transferencia ha sido procesada con el numero de folio (10 dígitos)  y debe de ser aplicada en un lapso de 5 días hábiles, en caso de cualquier duda favor de comunicarse a Súper línea al 5169 4300 del Distrito Federal ó al 01800 50 10000 del interior del país con su número de folio, si la fecha de pago de su otra tarjeta está dentro de los próximos 5 días, le sugerimos realizar al menos el pago mínimo.</span></p><br>
            <p><span>&nbsp;</span></p>
		</td>
    </tr><tr>
        		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >&nbsp; </span></b></p>
		</td>
		<td colspan="2">
			<p><span>Tiene usted alguna pregunta?</span></p>
            <p><span>&nbsp;</span></p>
			<p><span>   a) Si, Pasar a Preguntas Frecuentes .</span></p>
            <br><br>
			<p><span>b) No, Pasar a despedida 3.</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Despedida 1:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>En ese caso nos comunicaremos posteriormente para informarle a detalle del motivo de nuestra llamada.  </span></p><br>
			<p><span>Le agradezco mucho su atención que pase buen día / tarde / noche</span></p><br>
			<p><span>Fin de llamada</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
				<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Despedida 2:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr./Srita. (Apellido), esperamos que su decisión no sea definitiva y si más adelante requiere realizar la transferencia le pido se comunique a SúperLínea al 5169 4300 del Distrito Federal ó al 01800 50 10000 del interior del país donde con gusto le atenderemos ó puede realizarla directamente a través de Internet en  www.santander.com.mx. </span></p><br>
			<p><span>Por último le recuerdo que la tasa preferencial aplica hasta el 30 de Abril de 2009</span></p><br>
			<p><span>Le agradezco mucho su atención que pase buen día / tarde / noche</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
    		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Despedida 3:</span></b></p>
			<p><b><span >&nbsp;</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>Sr./Srita. (Apellido), Agradezco mucho su atención, en caso de que tenga alguna duda le pido se comunique a SuperLínea con su folio de transferencia al 5169 4300 del Distrito Federal ó al 01800 50 10000 del interior del país donde con gusto le atenderemos </span></p><br>
			<p><span>Que pase buen día / tarde / noche.</span></p><br>
			<p><span>Fin de llamada</span></p><br>
			<p><span>&nbsp;</span></p>
		</td>

	</tr>
</table>
</body>
</html>