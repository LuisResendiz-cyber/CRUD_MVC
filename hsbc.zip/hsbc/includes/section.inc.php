<?php

#VERIFICA EL PERFIL DEL USUARIO TENGA PERMISOS EN LA SECCION
/* function check_profile($section, $db){

  $stmt = $db->PrepareSP("BEGIN SPS_SECTIONPROFILE(:s_usr_nivel, :s_usr_section, :s_count); END;");
  $db->InParameter($stmt, get_session_varname("s_usr_nivel"), 's_usr_nivel');
  $db->InParameter($stmt, $section, 's_usr_section');
  $db->OutParameter($stmt, $s_count, 's_count');
  $db->Execute($stmt);

  return $s_count == 1;
  } */

function check_profile($section, $conn) {
    //echo '--'.get_session_varname("s_usr_nivel").'--'.$section;
    $section_array = explode(",", $section);
    $permission_array = array('A' => 'agente', 'AI' => 'agente', 'ASB' => 'agente', 'ACB' => 'agente', 'N' => 'nomina', 'V' => 'validacion', 'MC' => 'mesa_control', 'GO' => 'gerente_operacion', 'GV' => 'gerente_validacion', 'S' => 'supervisor');
//    $permission_array = array('A' => 'agente','AI' => 'agente_in', 'N' => 'nomina', 'V' => 'validacion','MC' => 'mesa_control', 'GO' => 'gerente_operacion', 'GV' => 'gerente_validacion', 'S' => 'supervisor');
    for ($i = 0; $i <= count($section_array) - 1; $i++) {
        if ($section_array[$i] == $permission_array[get_session_varname("s_usr_nivel")]) {
            $exist = 1;
            break;
        } else {
            $exist = 0;
        }
    }

    return $exist;
}
