const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN DBO.SPI_SCORE(:V_CAMPANA, :V_CUSTOMERID, :V_NOMINA_AGENTE, :V_SUPER_AGENTE ,:V_NOMINA_VALIDADOR, :V_COMENTS, :V_SCORE); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.V_CAMPANA || !context.V_CUSTOMERID || !context.V_NOMINA_AGENTE || !context.V_SUPER_AGENTE || !context.V_NOMINA_VALIDADOR || !context.V_COMENTS || !context.V_SCORE){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
          
      			binds.V_CAMPANA = context.V_CAMPANA;
      			binds.V_CUSTOMERID = context.V_CUSTOMERID;
            binds.V_NOMINA_AGENTE = context.V_NOMINA_AGENTE;
            binds.V_SUPER_AGENTE = context.V_SUPER_AGENTE;
            binds.V_NOMINA_VALIDADOR = context.V_NOMINA_VALIDADOR;
            binds.V_COMENTS = context.V_COMENTS;
            binds.V_SCORE = context.V_SCORE;


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;