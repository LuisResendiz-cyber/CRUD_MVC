import express, { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { string } from "yup";

declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

export const authenticateJWT = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.header("Authorization");
  const { user_id } = req.params;

  if (!authHeader) {
    res.status(401).json({
      error: "Unauthorized",
      details: "Authorization header is missing",
    });
    return;
  }
  const token = req.header("Authorization")?.split(" ")[1];

  if (!token) {
    res.status(401).json({
      error: "Unauthorized",
      details: "Token is missing from Authorization header",
    });
    return;
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as {
      [key: string]: any;
    };
    if (decoded.user_id != user_id) {
      res.status(403).json({
        error: "Forbidden",
        details: "Token does not match requested user",
      });
      return;
    }

    next();
  } catch (err) {
    // Manejar diferentes tipos de errores de JWT
    let errorMessage = "Invalid token";

    if (err instanceof jwt.TokenExpiredError) {
      errorMessage = "Token expired";
    } else if (err instanceof jwt.JsonWebTokenError) {
      errorMessage = "Invalid token";
    }
    res.status(403).json({
      error: "Forbidden",
      details: errorMessage,
    });
    return;
  }
};

export const ipFilter = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  // Lista de IPs permitidas con tipo explícito
  const allowedIPs: string[] = process.env.ALLOWED_IPS?.split(',') || [
    '192.168.1.1',
    '127.0.0.1',
    '::1',// IPv6 para localhost
    '::ffff:127.0.0.1'// Formato alternativo IPv4 en IPv6
  ];

  // Extracción segura de la IP con tipo garantizado
  const forwardedHeader = req.headers['x-forwarded-for'];
  const firstForwardedIp = typeof forwardedHeader === 'string' 
    ? forwardedHeader.split(',')[0].trim() 
    : null;
  const clientIp = firstForwardedIp || req.ip;
  
  if (typeof clientIp != 'string') {    
    res.status(403).json({
      error: 'Forbidden',
      details: 'It is no posible to read ips',
      yourIp: clientIp
    });
    return
  }
console.log(clientIp)
  // Validación
  if (!allowedIPs.includes(clientIp)) {
    res.status(403).json({
      error: 'Forbidden',
      details: 'IP not allowed for this operation',
      yourIp: clientIp
    });
    return
  }

  next();
};