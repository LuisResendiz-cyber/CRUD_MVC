const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
  console.log('****obtener permisos****');
  console.log(context);

  const baseQuery = "BEGIN CITI.SPS_GET_PERMISOS(:v_opcion, :v_perfil, :v_id, :v_estatus, :rc); END;";
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if (context.opcion == 1) { // obtener permisos 
    binds.v_opcion = context.opcion;
    binds.v_perfil = null;
    binds.v_id = null;
    binds.v_estatus = null;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
    
  } else if (context.opcion == 2) { // crear permiso
    if (context.perfil == "") {
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;
    } else {
      binds.v_opcion = context.opcion;
      binds.v_perfil = context.permiso;
      binds.v_id = null;
      binds.v_estatus = null;
      binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

      const result = await database.simpleExecuteRC(query, binds);
      console.log(result);
      return result;
    }
  } else if (context.opcion == 3 || context.opcion == '3') { // editar permiso
    if (context.id == "") {
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;
    } else {
      binds.v_opcion = context.opcion;
      binds.v_perfil = context.permiso;
      binds.v_id = context.id;
      binds.v_estatus = context.estatus;
      binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

      const result = await database.simpleExecuteRC(query, binds);
      console.log(result);
      return result;
    }
  } else if (context.opcion == 4) { // eliminar permiso
    if (context.id == "") {
      result2.error_ = true;
      result2.mensaje = "Parametros Erroneos";
      return result2;
    } else {
      binds.v_opcion = context.opcion;
      binds.v_perfil = null;
      binds.v_id = context.id;
      binds.v_estatus = null;
      binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

      const result = await database.simpleExecuteRC(query, binds);
      console.log(result);
      return result;
    }
  }

}

module.exports.find = find;
