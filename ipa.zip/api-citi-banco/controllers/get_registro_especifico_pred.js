const get_registro_especifico_pred = require('../db_apis/get_registro_especifico_pred.js');
const fetch = require('node-fetch');
const jwt = require('./token_manager');
const config  = require('../config/web-server');

async function post(req, res, next) {
  try {
    const context = req.body;//{};

    // const rows = await get_registro_especifico_pred.find(context);
    // console.log(rows);
    // const params = {
    //   fecha_carga: rows[0].FECHA_CARGA,
    //   schema: context.schema
    // };
    //
    // let data = await fetch(config.keyRingHost, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'access_token': jwt.get(),
    //     'Accept': 'application/json'
    //   },
    //   body: JSON.stringify(params)
    // })
    // .then(res=>res.json())
    // .then(data=>{
    //   if(!data.error){
    //     jwt.set(data.idtoken)
    //     context.keyrig = data.dataKey;
    //     context.error_kr = data.error;
    //     context.msg_kr = data.msg;
    //   }
    //   else{
    //     res.status(500);
    //     throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );
    //   }
    // })
    // .catch(err=>{
    //   res.status(500);
    //   return err;
    // })




    const respuesta = await get_registro_especifico_pred.give(context);

    if (req.params.id) {
      if (respuesta.length === 1) {
        res.status(200).json(respuesta[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(respuesta);
    }
  } catch (err) {
    next(err);
  }
}

module.exports.post = post;
