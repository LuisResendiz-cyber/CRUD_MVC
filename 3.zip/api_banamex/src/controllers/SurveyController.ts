import { Request, Response } from 'express';
import { SurveyModel } from '../models/SurveyModel';
import { ISurvey } from '../interfaces/ISurvey';

export class SurveyController {
  private surveyModel:SurveyModel
  
  constructor() {
    this.surveyModel = new SurveyModel();
  }

  public createSurvey = async (req: Request, res: Response): Promise<void> => {
    try {
      const surveyData: ISurvey = req.body;
      const {user_id} = req.params
      const newSurvey = await this.surveyModel.createSurvey(surveyData,user_id);
      if (newSurvey == false) {
        res.status(401).json({ message: 'Error al guardar el registro'});        
      }else {
        res.status(200).json({ message: 'Registro guardado correctamente'});        
      }
      
    } catch (error) {
      res.status(500).json({ message: 'Error al crear la encuesta' });
    }
  };

  public createSurveyNoSale = async (req: Request, res: Response): Promise<void> => {
    try {
      const surveyData: ISurvey = req.body;
      const {user_id} = req.params
      const newSurvey = await this.surveyModel.createSurveyNoSale(surveyData,user_id);
      if (newSurvey == false) {
        res.status(401).json({ message: 'Error al guardar el registro'});        
      }else {
        res.status(200).json({ message: 'Registro guardado correctamente'});        
      }
      
    } catch (error) {
      res.status(500).json({ message: 'Error al crear la encuesta' });
    }
  };


  public customerInformation = async (req: Request, res: Response): Promise<void> => {
    try {
      // const surveyData: ISurvey = req.body;
      const {CUSTOMERID} = req.body

      const rspta = await this.surveyModel.getCustomerInfo(CUSTOMERID);

      if (rspta.length === 0) {
        res.json({
          status: "error",
          details: `NO INFORMATION FOUND WITH THIS CUSTOMERID: ${CUSTOMERID}`
        })
        return
      }  

     
      res.json({
        status: "success",
        data:rspta
      })
      
    } catch (error) {
      res.status(500).json({ message: 'Error al crear la encuesta' });
    }
  };



  public getAllSurveys = async (req: Request, res: Response): Promise<void> => {
    try {
      const surveys = await this.surveyModel.getAllSurveys();
      res.status(200).json(surveys);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener las encuestas' });
    }
  };
  
  public updateSurveys = async (req: Request, res: Response): Promise<void> => {

    const {ID_SURVEY,STATUS_SURVEY} = req.body;
    try {

      const surveys = await this.surveyModel.updateSurvey(ID_SURVEY,STATUS_SURVEY);

        res.status(200).json(surveys); 

      
    } catch (error) {
      res.status(500).json({ message: 'Error al actualizar registros' });
    }
  };

  public updateMassSurveys = async (req: Request, res: Response): Promise<void> => {

    const {surveys} = req.body;
    try {
      console.log(surveys);

    const ID_SURVEYS = surveys.map((survey:any) => survey.ID_SURVEY);
    const STATUS_SURVEYS = surveys.map((survey:any) => survey.STATUS_SURVEY);
    const result = await this.surveyModel.updateSurveys(ID_SURVEYS, STATUS_SURVEYS);
    
    res.status(200).json(result); 

    } catch (error) {
      res.status(500).json({ message: 'Error al actualizar registros' });
    }
  };



}


