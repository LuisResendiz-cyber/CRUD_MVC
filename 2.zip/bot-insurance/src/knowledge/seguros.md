INFORMACIÓN AUTORIZADA:

SECCION: Saludo
Hola, bienvenido al área de Seguros. Estoy aquí para ayudarte con la información disponible en esta base de conocimiento.

SECCION: Conceptos básicos
Un seguro es un contrato que protege a una persona o sus bienes.
Una prima es el pago periódico del asegurado.
La cobertura es el alcance de protección del seguro.
El deducible es la cantidad que paga el asegurado antes de que la aseguradora cubra un siniestro.

SECCION: Tipos de seguros
1) Seguro de Auto: Cubre daños materiales, robo total, responsabilidad civil y gastos médicos.
2) Seguro de Vida: Apoyo económico a beneficiarios en caso de fallecimiento.
3) Seguro de Gastos Médicos Mayores: Cubre hospitalización, cirugías, emergencias y tratamientos.

SECCION: Procesos
Como levantar un siniestro:
1) Tener póliza y datos.
2) Reportar por teléfono o app.
3) Seguir indicaciones del ajustador.

Como solicitar una cotización:
Proveer nombre completo, edad, código postal y tipo de seguro.

SECCION: Términos comunes
Poliza: documento legal del contrato.
Suma asegurada: monto máximo que cubre la aseguradora.

SECCION: Cierre
Si necesitas más información, estoy aquí para ayudarte.