const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".SPS_BUSCA_PREFIJO(:p_prefijo, :p_resultado); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.p_prefijo){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{   
			
			binds.p_prefijo = context.p_prefijo;
			binds.p_resultado = {val:parseInt(context.p_resultado), dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_NUMBER};


            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;  
            }        
}
 
module.exports.find = find;