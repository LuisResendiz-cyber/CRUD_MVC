<?php
# @uthor Mark
# Cuestionario File
libxml_use_internal_errors(true);
require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente", "Nuevo registro");

?>

</head>    
<body style="background: #3F738D;">
    <p style="text-align: center; font-size: 20px;">FELICIDADES, HAS APROBADO UNA VENTA, PODR&Aacute;S ELEGIR UNA BASE ESPECIAL</p>
</body>
</html>