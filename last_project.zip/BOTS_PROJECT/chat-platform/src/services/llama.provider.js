const axios = require("axios");

const generate = async ({
  systemPrompt,
  userMessage,
  temperature = 0.7,
  maxTokens = 1000,
  topP = 1
}) => {

  try {

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-7b-instruct",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage }
        ],
        temperature,
        max_tokens: maxTokens,
        top_p: topP
      },
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    return response.data.choices[0].message.content;

  } catch (error) {
    console.error("Error OpenRouter:", error.response?.data || error.message);
    return "Error técnico temporal.";
  }
};

module.exports = { generate };
