from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from . import service, schemas

router = APIRouter()


@router.post("/", response_model=schemas.CallResponse)
def create_call(call: schemas.CallCreate, db: Session = Depends(get_db)):
    return service.create_call(db, call)
