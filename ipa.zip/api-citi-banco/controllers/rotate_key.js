'use strict'
//const encriptar_datos = require('../db_apis/encriptar_datos.js');
const fetch = require('node-fetch'); 
const jwt = require('./token_manager'); 
const config  = require('../config/web-server'); 

// const postKey = async (req, res, next) => {
async function post(req, res, next) {
  try {
    const context = req.body;//{};
    const params = {
      fecha: context.fecha,
      schema: context.schema
    };

    // let data = await fetch(config.keyRingRotate, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'access_token': jwt.get(),
    //     'Accept': 'application/json'
    //   },
    //   body: JSON.stringify(params)
    // })
    // .then(res=>res.json())
    // .then(data=>{
    //   console.log(data);
    //   if(data.error){
    //     res.status(500).json(data);
    //     throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );
    //   }
    //   else{
    //     jwt.set(data.idtoken)
    //     context.keyrig = data.dataKey;
        
    //     console.log(data);
    //     res.status(200).json(data);
    //   }
    // })
    // .catch(err=>{
    //   res.status(500);
    //   return err;
    // })       
    
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;
// module.exports = {postKey};