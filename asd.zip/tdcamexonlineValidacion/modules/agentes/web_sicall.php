<?php
# @eresendiz
# Error File

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");

initialize("agente","standby");

$tipo_standby = $_REQUEST["e"];

set_session_varname("tipo_standby", $tipo_standby);
layout_menu($db, "");

if($estatus == 1){
    $msg = 'Break';
} else if($estatus == 2) {
    $msg = 'Ba�o';
} else if($estatus == 3) {
    $msg = 'Capacitaci�n';
}

$empresa = get_session_varname("s_usr_centro");
$url = 'https://'.$_SERVER['SERVER_ADDR'].'/sicall/bancomerseg/modules/agentes/reportes_websicall.php?e='.$empresa;

?>
<p class="textbold">Agentes &gt; Standby</p>
<p>&nbsp;</p>
<table border="0">
    <tr>
        <td class="textleft" colspan="2" >
            <b class="mensaje"><?=$msg?></b>
        </td>
    </tr>
    <tr>
        <td>
            
        </td>
    </tr>
</table>
<iframe src="<?php echo $url;?>" width="100%" height="700px" frameborder="1">
    <p>El navegador no soporta IFrames.</p>
</iframe>
<?
layout_footer();
?>
