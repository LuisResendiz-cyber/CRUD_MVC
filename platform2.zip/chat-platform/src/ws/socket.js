const { Server } = require("socket.io");
const { processIncomingMessage } = require("../services/MessageFlow.service");

function initWebSocket(server) {
  const io = new Server(server, {
    cors: { origin: "*" }
  });

  io.on("connection", (socket) => {

    const { session_id } = socket.handshake.auth;

    socket.on("user_message", async (text) => {
      try {
        const reply = await processIncomingMessage({
          session_id,
          message: text,
          channel: "web"
        });

        if (reply) {
          socket.emit("bot_message", reply);
        }

      } catch (err) {
        console.log(err);
        socket.emit("bot_message", "Ocurrió un error, intenta más tarde.");
      }
    });

  });
}

module.exports = { initWebSocket };
