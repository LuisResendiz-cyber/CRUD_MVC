import { pool } from "../config/dbMysqlConfig.js";


const myslqAccions = {

  checkConn: async () => {
    let connection;
    try {
      connection = await pool.getConnection();
      const [rows] = await connection.query("SELECT 1");
      // console.log(rows)
      return true
    } catch (error) {
      throw new Error("Database connection error: " + error.message);
    } finally {
      if (connection) connection.release();
    }
  },

  insertLog: async(paso,status_log,comments) => {
    const connection = await pool.getConnection();
    try {
      const [result] = await connection.query(`INSERT INTO LOG_LEADS_DIGITAL (STEP,COMMENTS,STATUS_LOG) VALUES (?,?,?)`,[paso,comments,status_log]);
    return result.affectedRows
    } catch (error) {
     console.log(error) 
    }finally {
      if (connection) connection.release();
    }
    
  } 

}
export default myslqAccions