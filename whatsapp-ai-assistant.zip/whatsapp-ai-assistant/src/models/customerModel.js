const db = require("../config/configmysql");
const { getOraclePool } = require("../config/configOracleSql");

const CustomersModel = {
  async getCustomers() {
    const [result] = await db.query(
      "SELECT nombre, numero FROM WHATSAAP_ASSISTANT.DATA_NUMEROS di WHERE send = 0"
    );
    return result;
  },
//   async getPhones(pcnList) {
//     let connection;

//     console.log(pcnList);

//     try {
//       const pool = getOraclePool();
//       connection = await pool.getConnection();

//       // Dividimos los PCN en bloques de 500
//       const batchSize = 500;
//       const promises = [];

//       for (let i = 0; i < pcnList.length; i += batchSize) {
//         const batch = pcnList.slice(i, i + batchSize);
//         const pcnValues = batch.map((item) => item.PCN); // Extraemos los valores de PCN

//         if (pcnValues.length === 0) {
//           continue;
//         }

//         // Convertir los valores de PCN en una cadena separada por comas
//         const pcnValuesString = pcnValues.map((pcn) => `'${pcn}'`).join(",");

//         // Generamos la consulta SQL con el parámetro nombrado :pcn
//         const query = `
//             SELECT NOMBRE || ' ' ||APATERNO || '' || AMATERNO as NOMBRE, (CLAVELADA || '' || TELEFONO) AS TELEFONO FROM 
//             TDCAMEXONLINE.BD_ESPEJO be
//             JOIN TDCAMEXONLINE.REGISTROSTELEFONICOS RT on be.u_persona = RT.U_PERSONA
//             JOIN TDCAMEXONLINE.PERSONAS p on p.u_persona = RT.U_PERSONA
//                 WHERE BE.PCN IN (${pcnValuesString})`;

//         // Ejecutamos la consulta sin parámetros nombrados, ya que pasamos directamente el string
//         promises.push(connection.execute(query));
//       }
//               // Ejecutamos todas las consultas en paralelo y combinamos los resultados
//               const results = await Promise.all(promises);

//               // Transformar los resultados para tener formato clave-valor
//               return results.flatMap(result => result.rows.map(row => {
//                   return {
//                       name: row[0],        // El nombre
//                       telefono: row[1],    // El teléfono
//                   };
//               }));
      
//               // Devuelvo los teléfonos en el formato esperado
//               return { phones };


//       return { phones };
//     } catch (err) {
//       console.error("Error en obtener primer registro:", err);
//       return { success: false, error: err.message };
//     } finally {
//       if (connection) {
//         try {
//           await connection.close();
//         } catch (e) {
//           console.error("Error cerrando conexión Oracle:", e.message);
//         }
//       }
//     }
//   },




};

module.exports = CustomersModel;
