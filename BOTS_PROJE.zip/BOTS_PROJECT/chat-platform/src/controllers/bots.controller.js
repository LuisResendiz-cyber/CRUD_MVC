const Bots = require("../models/bots.models");
const MenuService = require("../services/User.service");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const secretKey = process.env.JWT_SECRET;

const botsController = {
    // GET /api/bots - Obtener todos los bots
    async getAllBots(req, res) {
      try {
        const bots = await Bots.Bot(1); // Ajusta según tu estructura
        res.json({
          status: true,
          data: bots,
          message: 'Bots obtenidos exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al obtener bots',
          error: error.message
        });
      }
    },
  
    // GET /api/bots/active - Obtener solo bots activos
    async getActiveBots(req, res) {
      try {
        const bots = await Bots.Bot('GET_ACTIVE');
        res.json({
          status: true,
          data: bots,
          message: 'Bots activos obtenidos exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al obtener bots activos',
          error: error.message
        });
      }
    },
  
    // GET /api/bots/:id - Obtener un bot por ID
    async getBotById(req, res) {
      try {
        const { id } = req.params;
        const bots = await Bots.Bot('GET_BY_ID', { id });
        
        if (bots.length === 0 || bots[0].Error) {
          return res.status(404).json({
            status: false,
            message: 'Bot no encontrado'
          });
        }
        
        res.json({
          status: true,
          data: bots[0],
          message: 'Bot obtenido exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al obtener el bot',
          error: error.message
        });
      }
    },
  
    // GET /api/bots/type/:type - Obtener bots por tipo
    async getBotsByType(req, res) {
      try {
        const { type } = req.params;
        const bots = await Bots.Bot('GET_BY_TYPE', { tipo: type });
        
        res.json({
          status: true,
          data: bots,
          message: `Bots de tipo ${type} obtenidos exitosamente`
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al obtener bots por tipo',
          error: error.message
        });
      }
    },
  
    // POST /api/bots - Crear nuevo bot
    async createBot(req, res) {
      try {
        const { nombre, descripcion, tipo = 'gen', estado = 'activo', LLM } = req.body;
        
        // Validaciones
        if (!nombre || !LLM) {
          return res.status(400).json({
            status: false,
            message: 'Nombre y LLM son requeridos'
          });
        }
  
        // Validar tipo
        const tiposValidos = ['cobranza', 'ventas', 'seguros', 'tarjetas', 'soporte', 'gen'];
        if (!tiposValidos.includes(tipo)) {
          return res.status(400).json({
            status: false,
            message: `Tipo no válido. Use: ${tiposValidos.join(', ')}`
          });
        }
  
        // Validar estado
        const estadosValidos = ['activo', 'inactivo'];
        if (estado && !estadosValidos.includes(estado)) {
          return res.status(400).json({
            status: false,
            message: `Estado no válido. Use: ${estadosValidos.join(', ')}`
          });
        }
        
        const result = await Bots.Bot('INSERT', { 
          nombre, 
          descripcion, 
          tipo, 
          estado, 
          LLM 
        });
        
        res.status(201).json({
          status: true,
          data: result,
          message: 'Bot creado exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al crear el bot',
          error: error.message
        });
      }
    },
  
    // PUT /api/bots/:id - Actualizar bot
    async updateBot(req, res) {
      try {
        const { id } = req.params;
        const { nombre, descripcion, tipo, estado, LLM } = req.body;
        
        // Verificar si existe el bot
        const existingBot = await Bots.Bot('GET_BY_ID', { id });
        if (existingBot.length === 0 || existingBot[0].Error) {
          return res.status(404).json({
            status: false,
            message: 'Bot no encontrado'
          });
        }
        
        // Validar tipo si se proporciona
        if (tipo) {
          const tiposValidos = ['cobranza', 'ventas', 'seguros', 'tarjetas', 'soporte', 'gen'];
          if (!tiposValidos.includes(tipo)) {
            return res.status(400).json({
              status: false,
              message: `Tipo no válido. Use: ${tiposValidos.join(', ')}`
            });
          }
        }
  
        // Validar estado si se proporciona
        if (estado) {
          const estadosValidos = ['activo', 'inactivo'];
          if (!estadosValidos.includes(estado)) {
            return res.status(400).json({
              status: false,
              message: `Estado no válido. Use: ${estadosValidos.join(', ')}`
            });
          }
        }
        
        const result = await Bots.Bot('UPDATE', {
          id_bot: id,
          nombre: nombre || existingBot[0].NOMBRE,
          descripcion: descripcion !== undefined ? descripcion : existingBot[0].DESCRIPCION,
          tipo: tipo || existingBot[0].TIPO,
          estado: estado || existingBot[0].ESTADO,
          LLM: LLM || existingBot[0].ID_LLM
        });
        
        res.json({
          status: true,
          data: result,
          message: 'Bot actualizado exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al actualizar el bot',
          error: error.message
        });
      }
    },
  
    // DELETE /api/bots/:id - Eliminar/desactivar bot
    async deleteBot(req, res) {
      try {
        const { id } = req.params;
        
        // Verificar si existe el bot
        const existingBot = await Bots.Bot('GET_BY_ID', { id });
        if (existingBot.length === 0 || existingBot[0].Error) {
          return res.status(404).json({
            status: false,
            message: 'Bot no encontrado'
          });
        }
        
        const result = await Bots.Bot('DELETE', { id_bot: id });
        
        res.json({
          status: true,
          data: result,
          message: 'Bot eliminado exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al eliminar el bot',
          error: error.message
        });
      }
    },
  
    // PATCH /api/bots/:id/status - Cambiar estado del bot
    async changeBotStatus(req, res) {
      try {
        const { id } = req.params;
        const { estado } = req.body;
        
        if (!estado) {
          return res.status(400).json({
            status: false,
            message: 'El estado es requerido'
          });
        }
  
        // Validar estado
        const estadosValidos = ['activo', 'inactivo'];
        if (!estadosValidos.includes(estado)) {
          return res.status(400).json({
            status: false,
            message: `Estado no válido. Use: ${estadosValidos.join(', ')}`
          });
        }
        
        const result = await Bots.Bot('CHANGE_STATUS', {
          id_bot: id,
          estado
        });
        
        res.json({
          status: true,
          data: result,
          message: 'Estado del bot actualizado exitosamente'
        });
      } catch (error) {
        res.status(500).json({
          status: false,
          message: 'Error al cambiar el estado del bot',
          error: error.message
        });
      }
    }
  };
  
  module.exports = botsController;
