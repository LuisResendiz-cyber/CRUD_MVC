const { actionsMysql } = require("../model/model-mysql");
const { executeQuery } = require("../model/model-oraclePool");
const {createConnObj,oraExcProc2,oraExcQuery } = require("../model/model-oracle");


const actGral = {
  testApi: (req, res) => {
    console.log("rspta: peticion test exitosa")
    res.json({ rspta: "peticion test exitosa" });    
  },
  testConnMysql: async (req, res) => {
    try {
      await actionsMysql.validarConexion();

      res.status(200).json({ rspta: "conectado" });
    } catch (error) {
      console.error("Error en el controlador:", error);
      res.status(500).json(error);
    }
  },
  testConnOracle: async (req, res) => {
    try {
      const sql = "SELECT * FROM dual";
      const result = await executeQuery(sql);
      console.log(result);
      res.json(result);
    } catch (error) {
      console.error("Error:", error);
      res.json(error);
    }
  },
};

const oraProcedure = {
  testProcedure: async (req, res) => {
    const {
      parameters,
      campaign,
      nameProcedure
    } = req.body 
    objConnOracle =await createConnObj(campaign,nameProcedure,parameters)  
    if (objConnOracle == null || objConnOracle == undefined) {    
      res.json({ status: 402, rspta: "NO CREDENTIALS FOR THIS CAMPAIGN" });
    }else{
      try {
        const oraRspta = await oraExcProc2(objConnOracle);  
        if (oraRspta.length == 0) {
          res.json({ status: 200, rspta: "NO DATA IN ORACLE" });          
        }else{
          res.json(oraRspta)

        }        
      } catch (error) {
        console.log(error)
        res.json(error)

      }
    } 
  },
  testQuery : async (req,res) => {
    const {query}= req.body    
    const { campaign} = req.body 
    const rspta = await oraExcQuery(campaign,query)
    res.json(rspta)
    
  }
}

module.exports = {
  actGral,
  oraProcedure,
}

