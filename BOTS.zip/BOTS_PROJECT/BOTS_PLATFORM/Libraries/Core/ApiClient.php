<?php

// class ApiClient
// {
//     protected string $baseUrl;
//     public function __construct()
//     {
//         $this->baseUrl = API_NODE_URL;
//     }

//     protected function request(string $method, string $endpoint, array $data = [], array $headers = [])
//     {
//         $ch = curl_init();

//         $url = rtrim($this->baseUrl, '/') . '/' . ltrim($endpoint, '/');

//         $defaultHeaders = [
//             'Content-Type: application/json'
//         ];

//         $headers = array_merge($defaultHeaders, $headers);

//         curl_setopt_array($ch, [
//             CURLOPT_URL            => $url,
//             CURLOPT_RETURNTRANSFER => true,
//             CURLOPT_CUSTOMREQUEST  => strtoupper($method),
//             CURLOPT_HTTPHEADER     => $headers,
//             CURLOPT_TIMEOUT        => 15,
//         ]);

//         if (!empty($data)) {
//             curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
//         }

//         $response = curl_exec($ch);

//         if ($response === false) {
//             $error = curl_error($ch);
//             curl_close($ch);
//             return [
//                 'status' => false,
//                 'msg' => 'Error conexión API',
//                 'error' => $error
//             ];
//         }


//         $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//         curl_close($ch);

//         return json_decode($response, true);
//     }
// }



class ApiClient
{
    protected string $baseUrl;

    public function __construct()
    {
        $this->baseUrl = API_NODE_URL;
    }

    protected function request(string $method, string $endpoint, array $data = [], array $headers = [])
    {
        $ch = curl_init();

        $url = rtrim($this->baseUrl, '/') . '/' . ltrim($endpoint, '/');

        $defaultHeaders = [
            'Content-Type: application/json'
        ];

        $headers = array_merge($defaultHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => strtoupper($method),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false, // Solo para desarrollo
            CURLOPT_SSL_VERIFYHOST => false, // Solo para desarrollo
        ]);

        // Para métodos que envían datos (POST, PUT, PATCH)
        if (in_array(strtoupper($method), ['POST', 'PUT', 'PATCH']) && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return [
                'status' => false,
                'msg' => 'Error conexión API',
                'error' => $error
            ];
        }

        $decodedResponse = json_decode($response, true);
        
        // Si no se pudo decodificar JSON
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'status' => false,
                'msg' => 'Error decodificando respuesta de API',
                'raw_response' => $response
            ];
        }
        
        return $decodedResponse;
    }
}
