const { getUser } = require('../controllers/appController');
const db = require('../lib/configmysql');

const {getOraclePool} = require("../lib/configOracleSql");


const UsersModel = {
  async getAll() {
    const [rows] = await db.query('SELECT * FROM users');
    return rows;
  },
  async CreateUser(datosUser) {
    const { username, email, password, profile, statusUser } = datosUser;
    const [result] = await db.query("INSERT INTO users(username, passwordHash, profile, status) VALUES(?,?,?,?)", [username, password, profile, statusUser]);
    return result;
  },
  async getUser(user) {
    const { id } = user;
    const [rows] = await db.query('SELECT * FROM users where userId = ?', [id]);
    return rows;
  },
  async getAcces(user) {
    const { username } = user;
    const [rows] = await db.query('SELECT * FROM users where username = ?', [username]);
    return rows[0];
  },
  async getContactos() {
    const [rows] = await db.query('SELECT * FROM contactos_llamadas where flag = 1');
    return rows;
  },
  async insertarContacto(contacto) {
    let connection;
    try {
      const pool = getOraclePool();
      connection = await pool.getConnection();
      
      await connection.execute(
        `INSERT INTO CONTACTOS_LLAMADAS (ID, NOMBRE, TELEFONO)
       VALUES (:id, :nombre, :telefono)`,
        {
          id: contacto.id,
          nombre: contacto.nombre,
          telefono: contacto.telefono,
          horario: contacto.horario,
          

        },
        { autoCommit: true }
      );

      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (e) {
          console.error('Error cerrando conexión Oracle:', e.message);
        }
      }
    }
  },
  async actualizarEstado(id){
    await db.query('UPDATE contactos_llamadas SET flag = 2 where id = ?', [id]);
  }
};

module.exports = UsersModel;