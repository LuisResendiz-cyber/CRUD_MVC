<?php
require_once("includes/includes.inc.php");
require_once("validacion.inc.php");

initialize("validacion","Nuevo registro");

$id_solicitud = $_REQUEST['sol'];

$agente = get_session_varname('s_usr_nombre');
$registro = get_detalle_solicitud($id_solicitud, $db);
$NOMBRE_COMPLETO = $registro->fields["NOMBRE_COMPLETO"];
$PATERNO = $registro->fields["PATERNO"];
$DIGITOS = $registro->fields["DIGITOS"];
$DESC_PRO = $registro->fields["DESC_PRO"];
$CORTE = $registro->fields["CORTE"];
$SALDO = $registro->fields["SALDO"];
$TASA_ANTERIOR = '';
$LIMITE_PAGO = $registro->fields["DIA_LIMITE"];
?>
<html>
<head>
	<title>GUI&oacute;N TELEMARKETING</title>
</head>
<body>

<p><b><span style='font-size:12.0pt;'>Fecha de cancelación automática clásica (legales): <br>30 noviembre 2009…</span></b></p>

<p><b><span style='font-size:14.0pt;color:red'>Validaci&oacute;n Upgrade Clásicas a Oro</span></b></p>

<table border="1"  style="border-style:solid;border-width:1px;border-color:black;">
	<tr>
		<td>
			<p><b><span >Validación.</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><b><span >Operador:</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >Cliente:</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >Operador:</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >Cliente:</span></b></p>
            <p><b><span >&nbsp;</span></b></p>
            <p><b><span >Operador:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>Inicio de Grabación</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>Su nombre completo por favor como aparece en su tarjeta de crédito por favor.</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>XXXXXX XXXXXXX</span></p>
            <p><span>&nbsp;</span></p>
			<p><span>Sr.(ita.) (Apellido del cliente), me confirma que acepta el cambio de producto de su tarjeta de crédito clásica terminación XXXX por una Santander Oro MasterCard?</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>Si</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>Cuenta con adicionales?</span></p>
			<p><span>&nbsp;</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >&nbsp;</span></b></p>
			<p><b><span >Respuesta Cliente</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
			<p><span>   a) Si cuento  -- Pasar a Revisión de adicionales  y continuar con conversación 2.</span></p>
            <br><br>
			<p><span>   b) No cuento  -- Pasar a Conversación 1</span></p>
		</td>
	</tr><tr>
		<td>
			<p><b><span >Revisión de Adicionales:</span></b></p>
            <p><span>&nbsp;</span></p>
            <p><b><span >Operador:</span></b></p>
            <p><span>&nbsp;</span></p>
            <p><b><span >Cliente:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>Me puede proporcionar los números de tarjeta de las adicionales para solicitar también el cambio de producto..</span></p><br>
            <p><span>XXXXXX XXXXXXX</span></p>
        </td>
    </tr><tr>
		<td>
			<p><b><span >Conversación :</span></b></p>
            <p><span>&nbsp;</span></p>
            <p><b><span >Operador:</span></b></p>
            <p><span>&nbsp;</span></p>
            <p><span>&nbsp;</span></p>
            <p><span>&nbsp;</span></p>
            <p><span>&nbsp;</span></p>
            <p><b><span >Cliente:</span></b></p>
            <p><span>&nbsp;</span></p>
            <p><span>&nbsp;</span></p>
            <p><b><span >Operador:</span></b></p>
		</td>
		<td colspan="2">
			<p><span>&nbsp;</span></p>
            <p><b><span >&nbsp;</span></b></p>
			<p><span>De acuerdo, le confirmo que ha quedado inscrito  para realizar el cambio de su tarjeta de crédito clásica  terminación XXXX por una tarjeta de crédito Santander Oro.</span></p><br>
            <p><span>Está de acuerdo?</span></p>
            <p><span>&nbsp;</span></p>
            <p><span>Si</span></p>
            <p><span>&nbsp;</span></p>
            <p><span>&nbsp;</span></p>
            <p><span>El primer cobro de la anualidad se realizará en XXXX del 2009 por $162.50 pesos más IVA.</span></p><br>
            <p><span>Le recuerdo que, al recibir su nueva tarjeta de crédito Oro Santander, deberá de actualizar su número de tarjeta de crédito para los cargos automáticos que tenga ya que su número de cuenta cambiará, el pago de su recibo Telmex podrá solicitarlo o actualizarlo al momento que realice la activación en SuperLínea.</span></p><br>
            <p><span>Ya se ha ingresado su solicitud, le comento que el cambio de producto esta sujeto a aprobación por parte de admisiones, en caso de ser aprobada en 10 días estará recibiendo una notificación por parte del Santander de las modificaciones al contrato por el cambio de producto y en  30 días hábiles recibirá su tarjeta de Crédito Santander Oro.</span></p><br>
            <p><span>El primer cobro de la anualidad se realizará en XXXX del 2009 por $162.50 pesos más IVA.</span></p><br>
            <p><span>En caso de tener cualquier duda o aclaración acerca del proceso de cambio de producto puede comunicarse SuperLínea al 51 69 43 00 o para el interior de la República  al 01 800 50 100 00.</span></p><br>
            <p><span>Despedida</span></p><br>
        </td>
	</tr>
</table>
</body>
</html>