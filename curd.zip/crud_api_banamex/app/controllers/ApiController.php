<?php

error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

class ApiController
{
  private ApiModel $model;
  private dataBaseModel $oracleModel;

  public function __construct()
  {
    $this->model = new ApiModel(
      new \GuzzleHttp\Client()
    );
    $this->oracleModel = new dataBaseModel();
  }

  public function getSales() //obtener la informacion de ventas
  {
    $data = $this->model->fetchDataGet($_ENV['API_BOT_URL'] . 'getInfoSales');

    if ($data == null) {
      echo "Sin datos para mostrar";
      return;
    }
    if (empty($data['data'])) {
      return [
        'success' => true,
        'data' => 'Sin ventas para descargar',
      ];
    }
    $response =$this->processSales($data['data']);
    return $response;

  }
  
  private function processSales(array $data)
  {
    $this->updateStatusSales($data, 1, 1);
    // // var_dump($data);    
    $rspta = $this->oracleModel->insertSales($data);
    // var_dump($rspta);
    // sleep(2);
    $this->updateStatusSales($rspta, 99, 1);
    return $rspta;
    
  }


  public function getNoSales()//obtener la informacion de ventas
  {
    $data = $this->model->fetchDataGet($_ENV['API_BOT_URL'] . 'getInfoNoSales');

    if ($data == null) {
      return [
        'success' => true,
        'data' => "Sin datos",
      ];
    }
    if (empty($data['data'])) {
      return [
        'success' => true,
        'data' => 'Sin ventas para descargar',
      ];
    }
    $response =$this->processNoSales($data['data']);
    return $response;
  }
  private function processNoSales(array $data)
  {
    $this->updateStatusSales($data, 1, 2);
    $rspta = $this->oracleModel->insertNoSales($data);    
    $this->updateStatusSales($rspta, 99, 2);
    // sleep(2);
    return $rspta;
  }



  private function updateStatusSales(array $data, $step, $table): void
  {
    $idKey = $table == 2 ? 'ID_SURVEYNOSALE' : 'ID_SURVEY';

    $dataUpdate = [
      "option" => $table,
      'surveys' => []
    ];

    foreach ($data as $valor) {
      $dataUpdate['surveys'][] = [
        'ID_SURVEY' => $valor[$idKey],
        'STATUS_SURVEY' => $step
      ];
    }
    $data = $this->model->fetchDataPost($_ENV['API_BOT_URL'] . 'updateMassSurveys', $dataUpdate);

    if (isset($data['status']) && $data['status'] == 'error') {
      echo 'No se actualizaron los datos';
      return;
    }
    // echo $data['message'];
  }



  //! *********************************************************************************
  public function simulateSale() //obtener la informacion de ventas
  {
    $rspta = $this->oracleModel->simulate();

    if ($rspta[0]['RESPONSE'] != 99) {
      // $this->model->report_errors($rspta[0]['DETAILS']);
      return [
        'success' => "true",
        'data' => $rspta[0]['DETAILS'],
      ];
    }
    $response = json_decode($rspta[0]['DETAILS'], true);
    return [
      'success' => "true",
      'data' => $response,
    ];  
  }



  //! *********************************************************************************
  public function simulateNoSale() //obtener la informacion de ventas
  {
    $rspta = $this->oracleModel->simulateNoSale();

    if ($rspta[0]['RESPONSE'] != 99) {
      $this->model->report_errors($rspta[0]['DETAILS']);
      return [
        'success' => "true",
        'data' => $rspta[0]['DETAILS'],
      ];
    }
    return [
      'success' => "true",
      'data' => $rspta[0]['DETAILS'],
    ];    
  }



  //! *********************************************************************************
  public function getCustomerData() //obtener la informacion de ventas
  {
    // ID_USER --- ESTO ES PARA IDENTIFICAR QUE CLIENTE CONSULTA QUE INFORMACION 

    $data = $this->oracleModel->customerData();

    if (isset($data[0]['RESPONSE']) && $data[0]['RESPONSE'] != 99) {
      $this->model->report_errors($data[0]['DETAILS']);
      return;
      echo "La respuesta es: " . $data[0]['RESPONSE'];
    }

    $loadData = [
      "data" => $data,
    ];
    $rspta = $this->model->fetchDataPost($_ENV['API_BOT_URL'] . 'loadInfoCustomer', $loadData);
    return [
      'success' => true,
      'data' => $rspta,
    ];
  }
}
