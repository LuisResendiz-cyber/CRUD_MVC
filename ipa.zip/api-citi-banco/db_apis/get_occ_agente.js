const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  console.log(context);
  const baseQuery = "BEGIN DBO.xsp_getOccUser(:v_nomina, :v_schema, :v_occ); END;"; //DBO
  // console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.s_usr_nomina || !context.schema){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    //Se asignan los valores respecto a los parametros del SP
    binds.v_nomina = { val: context.s_usr_nomina , dir:oracledb.BIND_IN , type: oracledb.DB_TYPE_VARCHAR };
    binds.v_schema = {val:context.schema, dir:oracledb.BIND_IN, type:oracledb.DB_TYPE_VARCHAR};
    binds.v_occ = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};

    const result = await database.simpleExecute(query, binds);
     console.log(result);
    return result;
  }
}

module.exports.find = find;

/*
DEVUELVE LA OCC POR AGENTE

function get_occ_agente($nomina, $dbuser, $db) {
    $v_occ = 0;
    $stmt = $db->PrepareSP("BEGIN DBO.xsp_getOccUser(:v_nomina, :v_schema, :v_occ); END;");
    $db->InParameter($stmt, $nomina, 'v_nomina');
    $db->InParameter($stmt, $dbuser, 'v_schema');
    $db->OutParameter($stmt, $v_occ, 'v_occ');
    $db->Execute($stmt);
    return $v_occ;
}
*/
