const axios = require("axios");

const OLLAMA_URL = "http://localhost:11434/api/generate";
const MODEL = "phi3:latest";

async function classifyIntent(message) {
  const prompt = `
Clasifica el mensaje del usuario en UNA sola categoría.

CATEGORÍAS:
- greeting
- question
- complaint
- opinion
- farewell_soft
- farewell
- other

RESPONDE SOLO CON JSON VÁLIDO.
Formato EXACTO:
{"intent":"question"}

MENSAJE:
"${message}"
`;

  try {
    const response = await axios.post(OLLAMA_URL, {
      model: MODEL,
      prompt,
      stream: false,
      options: {
        temperature: 0
      }
    });

    const raw = response.data.response;

    // 🔥 EXTRAER JSON AUNQUE EL LLM HABLE DE MÁS
    const match = raw.match(/\{[\s\S]*?\}/);

    if (!match) {
      console.warn("No se pudo extraer JSON:", raw);
      return "other";
    }

    const parsed = JSON.parse(match[0]);

    return parsed.intent || "other";

  } catch (error) {
    console.error("IntentService error:", error.message);
    return "other";
  }
}

module.exports = { classifyIntent };
