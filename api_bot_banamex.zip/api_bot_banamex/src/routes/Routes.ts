import { Router } from "express";
import {
  validateSurvey,
  ValSurvey,
  ValSurveyNoSale,
  validate,
  ValUpdateSurvey,
  ValCustomerInformation,
  ValUpdateDataCustomer
} from "../validation/validators";
import { SurveyController } from "../controllers/SurveyController";
import {authenticateJWT,ipFilter} from "../validation/authMiddleware";
const router = Router();

const surveyController = new SurveyController();

const ENVIRONMENT = process.env.NODE_ENV || "development";
if (ENVIRONMENT == "development") {
  router.use((req, res, next) => {
    let horaEjecucion = new Date().toLocaleString();
    console.log(
      "-----------------------------------------------------------------------"
    );
    console.log(
      `DEV => Tipo: ${req.method} Ruta: ${req.url} IP: ${req.ip} Hora: ${horaEjecucion}`
    );
    console.log("Body--->", req.body);
    console.log(
      "-----------------------------------------------------------------------"
    );
    console.log("Params--->", req.params);
    console.log(
      "-----------------------------------------------------------------------"
    );
    next();
  });

  router.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function (body) {
      console.log("Respuesta enviada:", body);
      return originalJson.call(this, body);
    };
    next();
  });
}


//!START CUSTOMERS ENDPOINTS ---------------------------------------------------------------------------
router.post(
  "/dataInsert/:user_id",
  authenticateJWT,
  validateSurvey(ValSurvey),
  surveyController.createSurvey
);

router.post(
  "/dataInsert_noSale/:user_id",
  authenticateJWT,
  validateSurvey(ValSurveyNoSale),
  surveyController.createSurveyNoSale
);

router.post(
  "/customerInformation/:user_id",
  authenticateJWT,
  validateSurvey(ValCustomerInformation),
  surveyController.customerInformation
);
//!END CUSTOMERS ENDPOINTS ---------------------------------------------------------------------------




/**Estas ligas son para impulse*/
router.get("/getInfoSales",ipFilter, surveyController.getAllSurveys); //Ventas
router.get("/getInfoNoSales",ipFilter, surveyController.getAllSurveysNoSales); //No ventas

router.get("/checkDataCustomer",ipFilter,validate(ValUpdateDataCustomer), surveyController.checkDataCustomer); //No ventas
router.post("/loadInfoCustomer",ipFilter,surveyController.loadCustomerInformation);



// router.post("/updateSurvey",validate(ValUpdateSurvey),surveyController.updateSurveys);
router.post("/updateMassSurveys",ipFilter,surveyController.updateMassSurveys);

export default router;
