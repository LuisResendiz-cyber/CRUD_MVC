const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".XSP_SETNOTASPERSONALES(:p_usr_id, :nota); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.p_usr_id || !context.nota){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.p_usr_id     = context.p_usr_id;
            binds.nota      = context.nota;

            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;