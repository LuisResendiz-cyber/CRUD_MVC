const UsersModel = require('../models/appModel');
const bcrypt = require('bcryptjs');
const jwt  = require('jsonwebtoken');

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const secretKey = process.env.JWT_SECRET;

const appController = {
    async getUser(req, res) {
        try {
            const users = await UsersModel.getAll();
            res.json(users);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    },
    async setUser(req, res) {
        const { username, passwordHash, profile, statusUser } = req.body;

        const salt = await bcrypt.genSalt(10);
        const password = await bcrypt.hash(passwordHash, salt);

        try {
            const resp = await UsersModel.CreateUser({ username, password, profile, statusUser });

            if (resp.affectedRows > 0) {
                res.json({
                    message: 'Usuario registrado con éxito',
                    userId: resp.insertId
                });
            } else {
                res.status(400).json({ message: ' No se pudo insertar el usuario' });
            }

        } catch (error) {
            console.log(error.message);
            return res.status(500).json({ message: ' Error en el servidor, intenta más tarde' });
        }
    },
    async getUserById(req, res) {
        const { id } = req.params;

        try {
            const user = await UsersModel.getUser({ id });
            if (user.length > 0) {
                res.status(200).json(user);
            } else {
                res.status(404).json({ message: "Usuario no encontrado" });
            }
        } catch (error) {
            console.log(error.message);
            return res.status(500).json({ message: 'Error en el servidor, intenta más tarde' });
        }
    },
    async login(req, res) {
        const { username, passwordHash } = req.body;

        const user = await UsersModel.getAcces({ username });
        const isMatch = await bcrypt.compare(passwordHash, user.passwordHash);
        if (!isMatch) return res.status(400).json({ message: 'Contraseña incorrecta' });

        // Crear token JWT
        const token = jwt.sign(
            { userId: user.userId, username: user.username },
            secretKey,
            { expiresIn: '90d' }
        );

        res.json({ message: 'Login correcto', token });

    },
    async getContacto(req, res) {                
        try {
            const contactos = await UsersModel.getContactos();        

            if (contactos.length > 0) {
                res.status(200).json(contactos);                
            }else{
                res.status(404).json({ message: "Sin registros nuevos Encontrados" });            
            }
            
        } catch (error) {
            console.log(error.message);
            return res.status(500).json({ message: ' Error en el servidor, intenta más tarde' });
        }

    },
    async DataProcess(req, res){

    try {
    const contactos = await UsersModel.getContactos();

    if (contactos.length === 0) {
      return res.status(200).json({ message: 'No hay contactos para sincronizar' });
    }
    let procesados = 0;
    let errores = [];

    for (const contacto of contactos) {
      const result = await UsersModel.insertarContacto(contacto);
      if (result.success) {
        await UsersModel.actualizarEstado(contacto.id);
        procesados++;
      } else {
        errores.push({ id: contacto.id, error: result.error });
      }
    }
    
    return res.status(200).json({
      message: 'Sincronización completa',
      total: contactos.length,
      procesados,
      errores
    });

    } catch (error) {
    console.error('Error en DataProcess:', error.message);
    return res.status(500).json({ message: 'Error en el servidor durante el proceso de sincronización' });
  }



    }

}

module.exports = appController;