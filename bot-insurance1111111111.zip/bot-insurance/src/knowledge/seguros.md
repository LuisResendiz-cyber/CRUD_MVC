# Base de Conocimientos - Seguros

## Tipos de Seguro

### Seguro Médico
El seguro médico cubre gastos relacionados con consultas, hospitalización, cirugías y medicamentos.  
Incluye distintos planes: básico, estándar y premium.

### Seguro de Auto
Protege al conductor y al vehículo en caso de accidente, robo, daños a terceros o desastres naturales.  
Coberturas comunes:
- Daños materiales
- Robo total
- Responsabilidad civil
- Gastos médicos de ocupantes

### Seguro de Hogar
Protege la vivienda y pertenencias contra incendio, robo, daños por agua, fenómenos naturales y responsabilidad civil familiar.

---

## Procedimientos Comunes

### Proceso para solicitar una póliza
1. El cliente proporciona sus datos.
2. Se evalúan sus necesidades.
3. Se selecciona el tipo de seguro adecuado.
4. Se calcula el costo.
5. Se emite la póliza.

### Requisitos Generales
- Identificación oficial
- Comprobante de domicilio
- Datos de contacto
- Información específica según el tipo de seguro

---

## Preguntas Frecuentes

### ¿Qué es una prima?
Es el costo que paga el cliente para mantener activa la póliza.

### ¿Qué es un deducible?
Cantidad fija o porcentaje que debe pagar el asegurado antes de que la aseguradora cubra el resto.

### ¿Qué hacer en caso de siniestro?
1. Mantener la calma.
2. Contactar a la aseguradora.
3. Presentar documentación.
4. Seguir instrucciones del ajustador.
