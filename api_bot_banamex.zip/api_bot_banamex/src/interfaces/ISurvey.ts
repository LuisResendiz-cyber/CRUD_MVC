

export interface ISurvey {
    ID_SURVEY?: number;                // ID de la encuesta, opcional
    CUSTOMERID?: string;
    ID_PHONE?: string;
    TYPIFICATIONID?: string;
    CAMPAIGN?: string;
    STATUS_FROM_TMK?: string;
    PRODUCT?: string;
    TDC?: string;
    LINE_CREDIT?: string;
    BASE_FOLIO?: string;
    BIRTH_DATE?: string;
    HOLDER_LAST_NAME_FATHER?: string;
    HOLDER_LAST_NAME_MOTHER?: string;
    HOLDER_NAME?: string;
    RFC?: string;
    HOMOCLAVE?: string;
    CURP?: string;
    COMMENTS?: string;
    STREET?: string;
    EXTERIOR_NUMBER?: string;
    INTERIOR_NUMBER?: string;
    POSTAL_CODE?: string;
    COLONY?: string;
    STATE?: string;
    REFERENCE_MUNICIPALITY?: string;
    MUNICIPALITY?: string;
    CELL_PHONE?: string;
    PHONE?: string;
    CONTACT_PHONE?: string;
    COUNTRY_BIRTH?: string;
    FEDERAL_ENTITY?: string;
    EMAIL?: string;
    MONTHLY_INCOME?: string;
    INCOME_RECEIPT_TYPE?: string;
    IDENTIFICATION_TYPE?: string;
    ADDRESS_RECEIPT_TYPE?: string;
    NUMBER_REFERENCES?: string;
    CREDIT_REFERENCE_1?: string;
    LAST_4_DIGITS_CARD_1?: string;
    CREDIT_REFERENCE_2?: string;
    LAST_4_DIGITS_CARD_2?: string;
    CREDIT_REFERENCE_3?: string;
    LAST_4_DIGITS_CARD_3?: string;
    PERSONAL_LAST_NAME_FATHER?: string;
    PERSONAL_LAST_NAME_MOTHER?: string;
    PERSONAL_NAME?: string;
    PERSONAL_RELATIONSHIP?: string;
    PERSONAL_PHONE?: string;
    PERSONAL_EXTENSION?: string;
    BRANCH_VISIT_DATE?: string;
}



export interface IinfoCustomer {
    ID_USER?: string;
    CUSTOMERID?: string;
    NAME?: string;
    LAST_NAME_P?: string;
    LAST_NAME_M?: string;
    PRODUCT_TYPE?: string;
    PRODUCT_1?: string;
    PRODUCT_2?: string;
  }