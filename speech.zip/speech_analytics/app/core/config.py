from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):

    # App
    app_name: str = Field(default="SpeechLens API")
    environment: str = Field(default="development")

    #comentario f test,

    # API
    api_port: int = Field(default=8000)

    # Postgres
    postgres_db: str
    postgres_user: str
    postgres_password: str
    postgres_port: int = 5432
    postgres_host: str = "postgres"

    # Redis
    redis_port: int = 6378 #se cambio pq estaba ocupado oroiginal 6379
    redis_host: str = "redis" #conecion entrte back y redis

#testing de prueba
    @property
    def database_url(self) -> str:
        return (
            f"postgresql+psycopg2://"
            f"{self.postgres_user}:"
            f"{self.postgres_password}@"
            f"{self.postgres_host}:"
            f"{self.postgres_port}/"
            f"{self.postgres_db}"
        )

    class Config:
        env_file = ".env"
        extra = "ignore"   # 🔥 ESTA LÍNEA EVITA QUE Pydantic truene


settings = Settings()
