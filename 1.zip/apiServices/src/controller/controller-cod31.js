const CryptoJS = require("crypto-js");

const cod31 = {
  encrypt : (req,res) => {
    const {payload}= req.query 
    const macId             = "ji55FNZtct73ngTJukYNSyiuBDKnrijO";
    const key               = "Xep5aNueT6GY49ykx7xRVaqcGe2usmSr";
    const host              = "api2s.americanexpress.com";
    const port              = "443";
    const requestPath       = "/marketing/v1/offer_refusals";
    const method            = "POST";
    const timestamp = Date.now()
    const nonce = Math.random().toString(36).substring(2)+(new Date()).getTime().toString(36);

    let sha256 = CryptoJS.HmacSHA256(JSON.stringify(payload), key);

    let bodyHash          = CryptoJS.enc.Base64.stringify(sha256);
    let signatureData     = timestamp + '\n' + nonce + '\n' + method + '\n' + requestPath + '\n' + host + '\n' + port + '\n' + bodyHash + '\n';

    let sha256_encodedMac = CryptoJS.HmacSHA256(signatureData, key);

	  let encodedMac        = CryptoJS.enc.Base64.stringify(sha256_encodedMac);

    let authHeader        = 'MAC id=\"' + macId +
    '\", ts=\"' + timestamp + 
    '\", nonce=\"' + nonce + 
    '\", bodyhash=\"' + bodyHash + 
    '\", mac=\"' + encodedMac + '\"';
        
    console.log(authHeader)
    res.json(authHeader)

  }


}


module.exports = {cod31}