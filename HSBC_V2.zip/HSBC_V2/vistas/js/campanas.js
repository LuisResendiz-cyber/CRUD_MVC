
//EDITAR USUARIO
$(".tablas").on("click", ".btnEditarCampana", function(){
	var idCampana = $(this).attr("idCampana");

	var datos = new FormData();
	datos.append("idCampana", idCampana);
	
    $("#id_Campana").val(idCampana);

	$.ajax({
		url:"ajax/campanas.ajax.php",
		method: "POST",
		data: datos,
		cache: false,
		contentType: false,
		processData: false,
		dataType: "json",
		success: function(respuesta){
			 $("#EditarName").val(respuesta["NOMBRE_CAMPANA"]);
		}
	});
})

//ELIMINAR USUARIO
$(".tablas").on("click", ".btnEliminarCampana", function(){
    var idcampana = $(this).attr("idcampana");
    
  swal({
    title: '¿Está seguro de borrar la Campaña?',
    text: "¡Si no lo está puede cancelar la accíón!",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Cancelar',
      confirmButtonText: 'Si, borrar Enlace!'
  }).then(function(result){

    if(result.value){

      window.location = "index.php?ruta=campanas&idCampana="+idcampana;

    }

  })

})




