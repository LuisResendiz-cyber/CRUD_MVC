const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".xsp_verifyAccess(:usr_id, :function, :languaje, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.usr_id || !context.function || !context.languaje){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.usr_id     = context.usr_id;
            binds.function      = context.function;
            binds.languaje      = context.languaje;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};        

            const result = await database.simpleExecuteRC(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;