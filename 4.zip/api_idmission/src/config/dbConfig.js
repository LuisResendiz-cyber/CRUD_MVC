const mysql = require('mysql2/promise');

// Crear y exportar el pool de conexiones
// const pool = mysql.createPool({
//   host: '127.0.0.2',  
//   port: 3307,
//   user: 'daniel',
//   password: '1234',
//   database: 'API_IDMISSION',
//   waitForConnections: true,
//   connectionLimit: 1, // Máximo número de conexiones simultáneas
//   queueLimit: 0 // Sin límite en la cola de solicitudes
// });



// const pool = mysql.createPool({
//   host: '172.20.1.149',
//   user: 'lresendiz',
//   password: 'R3s3nd1z*',
//   database: 'API_IDMISSION',
//   waitForConnections: true,
//   connectionLimit: 1, // Máximo número de conexiones simultáneas
//   queueLimit: 0 // Sin límite en la cola de solicitudes
// });


const pool = mysql.createPool({
  host: 'localhost',
  user: 'tdconline',
  password: '/sjcP1.@I3gz(k5!',
  database: 'API_IDMISSION',
  waitForConnections: true,
  connectionLimit: 1, // Máximo número de conexiones simultáneas
  queueLimit: 0 // Sin límite en la cola de solicitudes
});

module.exports = pool;
