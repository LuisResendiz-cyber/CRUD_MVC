
export const generateTable = (tableData) => {


  let tableHTML = `
      <thead>
        <tr class="table-danger">
          ${tableData.headers.map(header => `<th>${header}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        ${tableData.rows.map((row, rowIndex) => `
          <tr>
            ${row.map((cell, colIndex) => `
              <td class="${tableData.headers[0]}-${rowIndex}-${colIndex}">${cell}</td>
            `).join('')}
          </tr>
        `).join('')}
      </tbody>
  `;
  return tableHTML; 
}

