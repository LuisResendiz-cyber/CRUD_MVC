const jwt = require("jsonwebtoken");
const myslqAccions = require("../models/dbModel");
const { encrypt, desencrypt } = require("./authController");
const webhookImp = require("../controllers/webhookController");

const JWT_SECRET = process.env.JWT_SECRET;

const checkConn = async (req, res) => {
  res.json({ status: "Success", details: "Hi world." });
};

const checkConnMySQL = async (req, res) => {
  const rspt = await myslqAccions.checkConn();

  res.json({ status: "Success", details: rspt });
};

const newUser = async (req, res) => {
  const { userId, password } = req.body;

  const pass = await encrypt(password);

  let resp = await myslqAccions.addUser(userId, pass);
  if (!resp) {
    res
      .status(401)
      .json({ status: "Error", details: "Try a different userId" });
  } else {
    res.json({
      status: "Success",
      details: `Your userId: ${userId} was successfully registered`,
    });
  }
};

const getToken = async (req, res) => {
  const { userId, password } = req.body;

  let userDb = await myslqAccions.getUser(userId);

  if (userDb.length === 0) {
    return res
      .status(401)
      .json({ status: "Error", details: `${userId} not found` });
  }
 

  const isvalid = await desencrypt(password, userDb.PASS);

  // console.log(isvalid);
  if (!isvalid) {
    webhookImp.send(userId,{ status: "Error", details: `Incorrect password with user ${userId}` })
    return res
      .status(401)
      .json({ status: "Error", details: `Incorrect password` });
  }

  const token = jwt.sign(
    { id: userDb.NAME, username: userDb.PASS },
    JWT_SECRET,
    { expiresIn: "90d" }
  );
  
  webhookImp.send(userId,{ status: "Success", details: `Token generated with user ${userId}` })
  
  res.json({ status: "Success", details: `Token generated`, token: token });
};

const checkToken = async (req, res) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  try {
    const decoded = jwt.decode(token);
    // console.log(decoded);
    const actDate = Math.floor(Date.now() / 1000);
    const secondsRestants = decoded.exp - actDate;
    const daysRestants = Math.ceil(secondsRestants / (60 * 60 * 24));

    res.json({
      status: "Success",
      details: "Valid token",
      expiresIn: `${daysRestants} days`,
    });
  } catch (error) {
    console.log(error);
  }
};

const newWebhook = async (req, res) => {
  const { userId, urlWebhook } = req.body;

  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  const decoded = jwt.decode(token);
  // console.log(decoded);

  if (decoded.id != userId) {
    return res.status(403).json({
      status: "Error",
      details: "UserId must be the same as the token owner",
    });
  }
  let resp = await myslqAccions.addWebook(userId, urlWebhook);

  if (!resp) {
    webhookImp.send(userId,{ status: "Error", details: `This link already exists for your ${userId}` })
    res.json({
      status: "Error",
      details: "This link already exists for your userId",
    });
  } else {
    webhookImp.send(userId,{ status: "Success", details: `Webhook successfully registered` })
    res.json({ status: "Success", details: "Webhook successfully registered" });
  }
};

const dataInsert = async (req, res) => {

  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  const decoded = jwt.decode(token);

  const {
    PCN,
    AGENCY,
    CHANNEL,
    SUB_CHANNEL,
    PRODUCT,
    DATE_ASIGNED,
    DATE_LINK_SENT,
    NUMBER_LINK_REVENUES,
    DATE_LAST_REPORT,
    DATE_LAST_IDMISSION_DECISION,
    DATE_LAST_AGENCY_DECISION,
    DATE_LAST_AMEX_DECISION,
    DOCUMENTATION_STATUS,
    INSURANCE,
    CHECKBOX_PUBLICITY,
    NATIONALITY,
    DEVICE,
    BROWSER,
    DECISION_DATE,
    DEC,
    COD_DEC,
    RESPONSE_CODE,
    CUSTOMER_TYPE,
    NUMBER_REJECTIONS,
  } = req.body;

  let resp = await myslqAccions.dataIdmissionInsert({
    PCN,
    AGENCY,
    CHANNEL,
    SUB_CHANNEL,
    PRODUCT,
    DATE_ASIGNED,
    DATE_LINK_SENT,
    NUMBER_LINK_REVENUES,
    DATE_LAST_REPORT,
    DATE_LAST_IDMISSION_DECISION,
    DATE_LAST_AGENCY_DECISION,
    DATE_LAST_AMEX_DECISION,
    DOCUMENTATION_STATUS,
    INSURANCE,
    CHECKBOX_PUBLICITY,
    NATIONALITY,
    DEVICE,
    BROWSER,
    DECISION_DATE,
    DEC,
    COD_DEC,
    RESPONSE_CODE,
    CUSTOMER_TYPE,
    NUMBER_REJECTIONS,
  });

  if (!resp) {
    webhookImp.send(decoded.id,{ status: "Error", details: `Error inserting data ${PCN}` })
    return res
      .status(401)
      .json({ status: "Error", details: `Error inserting data` });
  }

  webhookImp.send(decoded.id,{ status: "Success", details: `Data insert ${PCN}` })
  res.json({ status: "Success", details: "Data insert" });
};


const getDataImp =  async (req,res) => {

  const { userId, password } = req.body;

  let userDb = await myslqAccions.getUser(userId);

  if (userDb.length === 0) {
    return res
      .status(401)
      .json({ status: "Error", details: `${userId} not found` });
  } 

  const isvalid = await desencrypt(password, userDb.PASS);

  if (!isvalid) {
    webhookImp.send(userId,{ status: "Error", details: `Incorrect password with user ${userId}` })
    return res
      .status(401)
      .json({ status: "Error", details: `Incorrect password` });
  }

  let dataImp = await myslqAccions.getData();
  
  if (dataImp.length == 0) {
    webhookImp.send(userId,{ status: "Success", details: `No data found` })
    res.json({ status: "Success", details: `No data found`});  
  }else {
    webhookImp.send(userId,{ status: "Success", details: `Information successfully requested` })
    res.json({ status: "Success", details: dataImp});
  }  
  
}


const updateDataImp =  async (req,res) => {
  const { userId, password,data,status_data } = req.body;

  let userDb = await myslqAccions.getUser(userId);

  if (userDb.length === 0) {
    return res
      .status(401)
      .json({ status: "Error", details: `${userId} not found` });
  } 

  const isvalid = await desencrypt(password, userDb.PASS);

  if (!isvalid) {
    webhookImp.send(userId,{ status: "Error", details: `Incorrect password with user ${userId}` })
    return res
      .status(401)
      .json({ status: "Error", details: `Incorrect password` });
  }



  if (data.length === 0) {    
    webhookImp.send(userId,{ status: "Error", details: `No ids to update the table` })
    return res.json({ status: "Error", details: "No ids to update the table"});
  }


  let dataImp = await myslqAccions.updateData(status_data,data);

  if (dataImp) {
    webhookImp.send(userId,{ status: "Success", details: `Registers correctly updated` })
    res.status(200).json({ status: "Success", details: "Registers correctly updated"}); 
  } else {
    webhookImp.send(userId,{ status: "Error", details: `Error update registers` })
    res.status(401).json({ status: "Error", details: "Error update registers"});    
  }  
}




const actSandCont = {
  checkConn,
  newUser,
  getToken,
  checkToken,
  dataInsert,
  newWebhook,
  checkConnMySQL,
  getDataImp,
  updateDataImp
};

module.exports = actSandCont;
