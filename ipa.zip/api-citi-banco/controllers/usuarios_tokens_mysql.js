//const conexion = require('../services/database_pg.js');
const conexion = require('../services/database_mysql.js');

module.exports = {
    obtenerToken(usuario_id){
      //console.log("entro 5");
     return new Promise((resolve, reject) => {
      conexion.query(`select * from usuarios_tokens where usuario_id = ?`,
        [usuario_id],
        (err, resultados,rows) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados);
            if(resultados.length > 0){
              resolve({token:resultados[0].token,uid:resultados[0].uid});
            }else{
              resolve({length:0});
            }
          }
        }
      );
    });
  },
  insertarUsuario(usuario_id,token,uid){
    //console.log("entro 4");
    return new Promise((resolve, reject) => {
      conexion.query(`insert into usuarios_tokens values (?,?,?)`,
        [usuario_id,token,uid],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            //console.log(resultados.insertId);
            resolve(resultados[0]);
          }
        }
      );
    });
  },
  updateUsuario(usuario_id,token,uid){
   // console.log("entro 2");
    return new Promise((resolve, reject) => {
      conexion.query(`update usuarios_tokens set token= ?uid = ? where usuario_id = ?`,
        [token,uid,usuario_id],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            resolve(resultados[0]);
          }
        }
      );
    });
  },
  cleanUsuario(usuario_id){
   // console.log("entro 2");
    return new Promise((resolve, reject) => {
      conexion.query(`delete from usuarios_tokens where usuario_id = ?`,
        [usuario_id],
        (err, resultados) => {
          if (err) {
            reject(err);
          }else {
            resolve(resultados[0]);
          }
        }
      );
    });
  }
}
//--urgente o por job sjr
