const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {
    console.log(context);

    try {
        const baseQuery = "BEGIN "+ context.schema +".SPS_UBICACION(:op,:estado,:municipio,:trabajoSabado,:rc); END;";
        let query = baseQuery;
        const binds = {};
        let result2 = {};
        
        binds.op     = context.op;
        binds.estado     = context.estado;
        binds.municipio     = context.municipio;
        binds.trabajoSabado     = context.trabajoSabado;

        binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
        
        const result = await database.simpleExecuteRC(query, binds);
        return result;
    } catch (error) {
        console.log(Error);
    }
}

module.exports.find = find;
