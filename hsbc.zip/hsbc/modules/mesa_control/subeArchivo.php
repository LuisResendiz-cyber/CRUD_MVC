<?php
# @uthor Mark
# SubeArchivo File
require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize("mesa_control","Carga de registros");


layout_menu($db,"");

$error = (isset($_GET['e'])?$_GET['e']:0);
$ky = (isset($_GET['ky'])?$_GET['ky']:0);

if(isset($error) && $error != 0){
	$cantidad = (isset($_GET['c'])?$_GET['c']:"");
	if($error == 1){
		$valor_error = '<font color="red">El archivo no se cargo correctamente, intente de nuevo!!!!';
	}else if($error == 2){
		$valor_error = '<font color="red">No se recibio un tipo de archivo de texto, intente de nuevo!!!!';
	}else if($error == 3){
		$valor_error = '<font color="blue">Se actualizaron correctamente '.$cantidad.' registros!!!!';
	}else if($error == 4){
		$valor_error = '<font color="red">No se pudo realizar la peticion, intente nuevamente!!!!';
	}
?>
	<b>Resultado de la carga de Archivo.</b><br><br>
	<form name="frm1" method="POST" action="modules.php?mod=mesa_control&op=process_data&act=8">
	<input type="hidden" name="ky" value="<?=$ky?>">
	<table width="35%" border ="0">
		<tr>
			<td><b>Mensaje:</b></td>
			<td><b><?php echo $valor_error;?></b></td>
		</tr><tr>
			<td colspan="2">
				<br><br>
				<input type="button" value="Terminar" onclick="location.href='<?php echo $linkpath;?>index.php'" />&nbsp;
				<?
					if($ky != 0){
						echo '<input type="submit" value="Mostrar reporte"/>&nbsp;';
					}
				?>
			</td>
		</tr>
	</table>
	</form>
<?php
} else {
?>	
	<b>Seleccione la acci&oacute;n a realizar.</b><br><br>
	<form name="frm1" method="post" action="modules.php?mod=mesa_control&op=process_data&act=7">
		<table>
			<tr>
				<td width="40%" valign="bottom">
					<table border ="0">
						<tr style="background-color:<?=getColor(0)?>;font-weight:bold" align="center">
							<td># Reg.</td>
                            <td>&nbsp;</td>
                            <td>Solicitud.</td>
                            <td>&nbsp;</td>
							<td>Folio Campa&ntilde;a</td>
                            <td>&nbsp;</td>
							<td>Estado Actual</td>
                            <td>&nbsp;</td>
                            <td>Estado a Aplicar</td>
						</tr>
						<?php 
							$i = 0;
							$ii = 0;
							$contador_registro = 1;
							
							$rs_data = get_data_by_file($db);
							while(!$rs_data->EOF){
								echo '<tr style="background-color:'.getColor($contador_registro).'" align="center">';
									if(strlen($rs_data->fields["SOLICITUD"]) >= 1) {
										echo '<td>'.$contador_registro.'&nbsp;&nbsp;</td>
                                              <td>&nbsp;</td>
                                              <td>'.$rs_data->fields["SOLICITUD"].'&nbsp;&nbsp;</td>
                                              <td>&nbsp;</td>
                                              <td>'.$rs_data->fields["FOLIO"].'&nbsp;&nbsp;</td>
                                              <td>&nbsp;</td>
                                              <td><b>'.$rs_data->fields["ESTADO_ACTUAL"].'&nbsp;&nbsp;</b></td>
                                              <td>&nbsp;</td>
                                              <td><b>'.$rs_data->fields["NUEVO_ESTADO"].'&nbsp;&nbsp;</b></td>';
											  $i++;
									} else {
										echo '<td>'.$contador_registro.'&nbsp;&nbsp;</td>
											  <td colspan="3"><font size="2" color="red"><b>No se encontro informacion</b></font>&nbsp;&nbsp;</td>
											  <td>'.$rs_data->fields["FOLIO"].'&nbsp;&nbsp;</td>
											  <td><b>----</b></td>
											  ';
											  $ii++;
									}
								echo '</tr>';
								$contador_registro++;
								$rs_data->MoveNext();
							}
						?>
						<tr>
							<td colspan="5"><b>Registros Encontrados: <?=$i?></b></td>
						</tr><tr>
							<td colspan="5"><b>Registros No Encontrados: <?=$ii?></b></td>
						</tr><tr>
							<td colspan="5">&nbsp;</td>
						</tr>
					</table>
				</td>
			</tr><tr>
				<td>&nbsp;</td>
			</tr><tr>
				<td colspan="2">&nbsp;<div id="loading" style="display:none">Realizando peticion, espere un momento.&nbsp;<img src="<?=$linkpath?>includes/imgs/loading.gif"></div></td>
			</tr><tr>
				<td colspan="2">
					<input type="button" value="Terminar" onclick="back()"/>&nbsp;&nbsp;
					<input type="button" value="Continuar" name="continuar" onclick="validaFormEstatus(<?=$i-1?>)">
                    <!--onclick="validaFormEstatus(<?//=$i-1?>)"-->
				</td>
			</tr>
		</table>
	</form>
<?php
}
layout_footer();
?>