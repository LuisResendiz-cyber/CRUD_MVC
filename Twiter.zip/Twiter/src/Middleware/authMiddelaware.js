const jwt = require('jsonwebtoken')

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });

const secretKey = process.env.JWT_SECRET;

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization']; // normalmente: "Bearer <token>"
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Token no proporcionado' });
  }

  // Verificamos el token
  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.status(403).json({ message: 'Token inválido o expirado' });

    req.user = user; // payload del token, por ejemplo { userId, username }
    next();
  });
}

module.exports = authenticateToken;
