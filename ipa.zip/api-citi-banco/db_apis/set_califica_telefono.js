const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  console.log(context);
  const baseQuery = "BEGIN " + context.schema + ".spU_setRegistroTelefonico(:iRegTelefono, :iStatusLlamada); END;";
	let query = baseQuery;
	const binds = {};
  let result2 = {};

  if(!context.iRegTelefono || !context.iStatusLlamada){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    binds.iRegTelefono     = context.iRegTelefono;
    binds.iStatusLlamada      = context.iStatusLlamada;

    const result = await database.simpleExecute(query, binds);
    console.log('1. ', result);
    return result;
  }
}

module.exports.find = find;
