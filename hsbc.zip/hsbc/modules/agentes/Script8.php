<?php
/*require_once("includes/includes.inc.php");
require_once("agentes.inc.php");*/

function darSaludo() {
    $iHora = date('H');

    if ($iHora >= 0 && $iHora < 12) {
        $sSaludo = "Buenos d&iacute;as";
    } else if ($iHora >= 12 && $iHora <= 19) {
        $sSaludo = "Buenas tardes";
    } else {
        $sSaludo = "Buenas noches";
    }

    return $sSaludo;
}

require_once("includes/includes.inc.php");
require_once("agentes.inc.php");
initialize("agentes", "Script");

$u_persona = $_SESSION['datos_persona'][0]['U_PERSONA'];
//$rfc = $_SESSION['datos_persona'][0]['RFC'];
$nombre = $_SESSION['s_usr_nombre'];
//$apaterno = $_SESSION['datos_persona'][0]['APATERNO'];        
echo "<pre>";
 $productos_ = get_productos_campana($u_persona, $db);
 //print_r($productos_);
echo "</pre>";
$datos = get_datos_query2('XSP_GETDATOSCLIENTEINICIO_1('.$u_persona.',:rc)',$db);

echo "<pre>";
//print_r($datos);
echo "</pre>";
?>


    <table width="360" cellpadding="0" cellspacing="0">
        <tr>
            <td width="354" height="165" colspan="2" bgcolor="#FFFFF9" align="center">
                <div class=Section1>

                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=576
                           style='width:432.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes;
                            height:123.75pt'>
                            <td width=576 style='width:432.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                height:123.75pt'>
                                <p align=center style='text-align:center'><span style='font-size:9.0pt;
                                                                                font-family:Arial'>Logo <span class=SpellE>Amex</span><o:p></o:p></span></p>
                                <p class=style13 align=center style='text-align:center'><span class=SpellE><span
                                            style='font-size:9.0pt'>Script</span></span><span style='font-size:9.0pt'>
                                        <span class=SpellE>Venta Supp's</span><o:p></o:p></span></p>
                                <p class=MsoNormal align=center style='text-align:center'><strong><span
                                            style='font-size:9.0pt;font-family:Arial;color:blue'>No. de Solicitud: <?php echo $u_persona; ?> <br>Producto Origen: <?php echo$productos_->_array[$t]['NOMBRE'];?></span></strong><span
                                        style='font-size:9.0pt;font-family:Arial;color:blue'> <br style='mso-special-character:
                                                                                              line-break'>
                                        <![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
                                        <![endif]><o:p></o:p></span></p>
                                <div align=center>
                                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=504
                                           style='width:378.0pt;mso-cellspacing:0cm;mso-padding-alt:0cm 0cm 0cm 0cm'>
                                        <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                            PRESENTACI&Oacute;N
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:1;height:14.25pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:14.25pt'>
                                                <p><span style='font-size:9.0pt;font-family:Arial'><?php echo darSaludo(); ?> 
                                                        Sr/Srita. <b style='mso-bidi-font-weight:normal'><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>, 
                                                        mi nombre es 
                                                        </span><span class=style151><b
                                                                style='mso-bidi-font-weight:normal'><span style='color:windowtext'></span></b></span>
                                                        <b style='mso-bidi-font-weight:normal'><?php echo $nombre.","; ?></b> 
                                                        Asesor/Ejecutivo American Express, mucho gusto.                                                        
                                                        <br>
                                            </td>                                            
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                    Opci&oacute;n 1
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>                                        
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    &iquest;Qu&eacute; tal su d&iacute;a? me alegra que se encuentre bien, me es muy grato
                                                    comunicarme con usted, para American Express es muy importante
                                                    satisfacer las necesidades de cada uno de sus Tarjetahabientes, por ende
                                                    nos encantar&iacute;a saber cu&aacute;l es el beneficio que usted disfruta m&aacute;s.
                                                </span></span></p>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Sr/ Srita <b style='mso-bidi-font-weight:normal'><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b> que le parec&iacute;a extender este beneficio que me acaba de
                                                    comentar a su esposa, hijos, padres, hermanos, o tal vez a la persona que
                                                    usted elija. A trav&eacute;s de una Tarjeta adicional la cual es <b>Sin Costo de por
                                                    Vida.</b> Es decir por la misma Anualidad que Ud. Ya paga. Sr/ Srita <b style='mso-bidi-font-weight:normal'><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>, 
                                                    me podr&iacute;a confirmar el nombre de su primer Tarjeta adicional.
                                                </span></span></p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>
                                                            Opci&oacute;n 2
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr> 
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                            Es muy grato para mi poder conversar con usted, &iquest;C&oacute;mo se encuentra&quest;...
                                                    excelente, Sr/Srita <b style='mso-bidi-font-weight:normal'><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b> usted actualmente disfruta de los beneficios
                                                    que le otorga su Tarjeta ___________ es correcto?, Me gustar&iacute;a comentarle que
                                                    usted tiene un gran beneficio que NO ha decidido disfrutar. Hoy cubre una
                                                    anualidad de $_______ + IVA, por la que usted Sr/Srita <?php echo $datos->fields['NOMBRE_CLIENTE']; ?> tiene
                                                    derecho a disfrutar de hasta 5 (RCP) / 3 (GRCC) Tarjetas adicionales Sin
                                                    Costo de Por Vida, y actualmente usted no tiene este privilegio habilitado.
                                                </span></p><br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    <table>
                                                        <tr>
                                                            <td>
                                                                &nbsp;
                                                            </td>
                                                            <td>
                                                                <b>Tarjeta</b>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <b>GRCC</b>
                                                            </td>
                                                            <td>
                                                                The Gold Elite Credit Card
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>                                                                
                                                            </td>
                                                            <td>
                                                                The Platinum Skyplus Credit Card American
                                                                Express
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>                                                                
                                                            </td>
                                                            <td>
                                                                The Platinum Credit Card
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>                                                                
                                                                <b>RCP</b>
                                                            </td>
                                                            <td>
                                                                Propietarias La Tarjeta American Express
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                
                                                            </td>
                                                            <td>
                                                                The Gold Card American Express
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                
                                                            </td>
                                                            <td>
                                                                The Platinum Card American Express
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                <b>RCP</b> 
                                                            </td>
                                                            <td>
                                                                Marca Compartida La Tarjeta American Express Aerom&eacute;xico
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                
                                                            </td>
                                                            <td>
                                                                The Gold Card American Express Aerom&eacute;xico
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                
                                                            </td>
                                                            <td>
                                                                The Platinum Card American Express
                                                                Aerom&eacute;xico
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                            Sr. / Srita. <b><?php echo $datos->fields['NOMBRE_CLIENTE']; ?></b>, me podr&iacute;a confirmar el nombre de su primer Tarjeta
                                                            adicional. Al contar con sus tarjetas adicionales sus familiares o seres queridos podr&aacute;n:
                                                </span></span></p>
                                                <br>                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span
                                                            style='font-size:9.0pt;font-family:Arial;color:white'>BENEFICIOS<o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm; height:15.0pt'>
                                                <ol type="num">
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                Generar m&aacute;s puntos por las compras que &eacute;l/ella realicen de su
                                                                programa de recompensas, los cuales usted seguir&aacute; tomando la
                                                                decisi&oacute;n de c&oacute;mo disfrutar.
                                                            </span></span></p>                                                        
                                                    </li>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>                                                        
                                                            <p><span class=style31><span style='font-size:9.0pt;'>
                                                                La protecci&oacute;n de nuestras coberturas ya incluidas en su actual Tarjeta
                                                                por ejemplo:
                                                            </span></span></p>
                                                            <ul type='a'>
                                                                <li>
                                                                    <p><span class=style31><span style='font-size:9.0pt;'>
                                                                        Seguro autom&aacute;tico contra accidentes por hasta (dependiendo de
                                                                        la Tarjeta), &uacute;nicamente por pagar con La Tarjeta su trayecto
                                                                    </span></span></p>
                                                                </li>
                                                                <li>
                                                                    <p><span class=style31><span style='font-size:9.0pt;'>
                                                                        Al comprar por ejemplo una pantalla o una lap top con un costo
                                                                        superior a los $50 usd estar&aacute; protegiendo su art&iacute;culo en caso de
                                                                        robo, asalto, incendio y/o explosi&oacute;n hasta por un a&ntilde;o despu&eacute;s de
                                                                        adquirirla.
                                                                    </span></span></p>
                                                                </li>
                                                                <li>
                                                                    <p><span class=style31><span style='font-size:9.0pt;'>
                                                                        A trav&eacute;s de Garant&iacute;a Plus, extender por el doble o hasta por un
                                                                        a&ntilde;o m&aacute;s la garant&iacute;a original de sus art&iacute;culos.
                                                                    </span></span></p>
                                                                </li>
                                                            </ul>
                                                        <br>
                                                        <p><span class=style31><span style='font-size:9.0pt;'>                                                
                                                            Sin la complejidad que por ejemplo usted vaya al establecimiento, porque sus
                                                            Tarjetas adicionales cuenta con dicha protecci&oacute;n y al comprar/firmar ellos
                                                            est&aacute;n cubiertos con American Express
                                                        </span></span></p><br>
                                                    </li>
                                                    <li class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt: auto;mso-list:l3 level1 lfo2;tab-stops:list 36.0pt'>
                                                        Ver catalogo de propuesta de valor de la Tarjeta espec&iacute;ficamente
                                                        <b>(carpeta compartida)</b>
                                                    </li>                                                    
                                                </ol>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                            Aviso de Privacidad. GRCC
                                                        <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    American Express Bank (M&eacute;xico), S.A. Instituci&oacute;n de Banca M&uacute;ltiple, con
                                                    domicilio en Patriotismo 635, Col. Ciudad de los Deportes, Delegaci&oacute;n Benito
                                                    Ju&aacute;rez, C.P. 03710, M&eacute;xico, D.F., recaba sus datos personales para la
                                                    realizaci&oacute;n de todas las actividades relacionadas con Tarjetas de Cr&eacute;dito de
                                                    American Express. Para mayor informaci&oacute;n consulte nuestro Aviso de
                                                    Privacidad integral en www.americanexpress.com.mx.
                                                </span></span></p>
                                                <br>                                                
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width=504 style='width:378.0pt;background:red;padding:0cm 0cm 0cm 0cm;
                                                height:15.0pt'>
                                                <p class=MsoNormal align=center style='text-align:center'><b><span style='font-size:9.0pt;font-family:Arial;color:white'>
                                                            Aviso de Privacidad. RCP
                                                <o:p></o:p></span></b></p>
                                            </td>
                                        </tr>
                                        <tr style='mso-yfti-irow:5;height:15.0pt; text-align: justify;'>
                                            <td width=504 style='width:378.0pt;background:#FFFFF9;padding:0cm 0cm 0cm 0cm;height:15.0pt'>
                                                <br>                                                
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    American Express Company (M&eacute;xico), S.A. de C.V., con domicilio en
                                                    Patriotismo 635, Col. Ciudad de los Deportes, Delegaci&oacute;n Benito Ju&aacute;rez, C.P.
                                                    03710, M&eacute;xico, D.F., recaba sus datos personales para la realizaci&oacute;n de todas
                                                    las actividades relacionadas con las Tarjetas de Servicios de American
                                                    Express. Para mayor informaci&oacute;n consulte nuestro Aviso de Privacidad
                                                    integral en www.americanexpress.com.mx.
                                                </span></span></p>
                                                <br>
                                                <p><span class=style31><span style='font-size:9.0pt;'>
                                                    Le reitero mi Nombre <?php echo $nombre; ?> ejecutivo/asesor de American Express, mi
                                                    tel&eacute;fono es _________, lo dejo con mi compa&ntilde;ero (a) ________de calidad
                                                    quien validar&aacute; su informaci&oacute;n y realizara &uacute;nicamente una grabaci&oacute;n
                                                    de autorizaci&oacute;n. Agradezco y le felicito por su excelente decisi&oacute;n de
                                                    formar parte de los TH American Express que siga teniendo un(a) excelente
                                                    <?php echo darSaludo(); ?>. Hasta luego
                                                </span></span></p>
                                                <br>                                                
                                            </td>
                                        </tr>                                                                               
                                    </table>
                                </div>
                            <p align=center style='text-align:center'>&nbsp;</p>
                        </td>
                    </tr>
                </table>