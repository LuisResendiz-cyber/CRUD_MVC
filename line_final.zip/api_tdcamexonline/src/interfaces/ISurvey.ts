export interface ISurvey {
    CUSTOMERID?: number;                // ID de la encuesta, opcional
    TYPIFICATIONID?: string;
    RELACION_REGISTRO?: string;
    NOMBRE?: string;
    AP_PATERNO?: string;
    AP_MATERNO?: string;
    ID_PHONE?: string;
    FECHA_NACIMIENTO?: string;
    RFC?: string;
    INGRESOS_FIJOS_COMPROBABLES?: string;
    NACIONALIDAD?: string;
    PAÍS_ORIGEN?: string;
    SEXO?: string;
    ESTADO_NACIMIENTO?: string;
    ESTADO_ALTERNO_NACIMIENTO?: string;
    TIPO_ID?: string;
    NÚMERO_ID?: string;
    ANTIGÜEDAD_VIVIENDA_ACTUAL_AÑOS?: string;
    ANTIGÜEDAD_VIVIENDA_ACTUAL_MESES?: string;
    CALLE?: string;
    NÚMERO_EXTERIOR?: string;
    NÚMERO_INTERIOR?: string;
    CP?: string;
    COLONIA?: string;
    MUNICIPIO?: string;
    ESTADO?: string;
    LADA?: string;
    TELÉFONO?: string;
    TELÉFONO_CELULAR?: string;
    CORREO_ELECTRÓNICO?: string;
    TIPO_VIVIENDA?: string;
    TRABAJADOR_INDEPENDIENTE?: string;
    STATUS_LABORAL?: string;
    TIPO_INDUSTRIA?: string;
    OCUPACIÓN?: string;
    ANTIGÜEDAD_EMPRESA_AÑOS?: string;
    ANTIGÜEDAD_EMPRESA_MESES?: string;
    NOMBRE_EMPRESA?: string;
    LADA_OFICIONA?: string;
    TELÉFONO_OFICINA?: string;
    BANCO_REF_1?: string;
    DIGITOS_TDC?: string;
    CRÉDITO_HIPOTECARIO?: string;
    CRÉDITO_AUTO?: string;
    TITULAR_TDC?: string;
}



export interface IinfoCustomer {
    ID_USER?: string;
    CUSTOMERID?: string;
    NAME?: string;
    LAST_NAME_P?: string;
    LAST_NAME_M?: string;
    PRODUCT_TYPE?: string;
    PRODUCT_1?: string;
    PRODUCT_2?: string;
  }

