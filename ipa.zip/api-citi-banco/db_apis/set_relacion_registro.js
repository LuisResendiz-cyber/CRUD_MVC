const oracledb = require('oracledb');
const database = require('../services/database.js');
 
async function find(context) {
 
const baseQuery = "BEGIN " + context.schema + ".XSP_INSERTARELACIONREGISTRO_WS(:referente, :referido, :tipobase); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.referente || !context.referido || !context.tipobase){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{
            binds.referente      = context.referente;
            binds.referido      = context.referido;
            binds.tipobase      = context.tipobase;

            const result = await database.simpleExecute(query, binds);

            // console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;