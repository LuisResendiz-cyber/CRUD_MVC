<?php
$url = $_GET['url'] ?? null; // Usar null coalescing para evitar errores

$url2 = base64_decode($url);

    header("Location: ". $url2);  

exit();
?>