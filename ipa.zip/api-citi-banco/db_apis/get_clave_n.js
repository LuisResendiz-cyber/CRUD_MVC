const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  // console.log('--------+++');
  console.log(context);
  // console.log('--------+++');*/

  const baseQuery = "BEGIN "+ context.schema +".GET_CLAVE_N(:u_estatusllamada, :rc); END;";
  console.log(context);
	let query = baseQuery;
	const binds = {};
  let result = {};

  if(!context.u_estatusllamada){
    //console.log("Parametros incorrectos")
    result.error_ = true;
    result.mensaje = "Parametros Erroneos";
    return result;

  } else{
    binds.u_estatusllamada     = context.u_estatusllamada;
    binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);

    return result;
  }

}

module.exports.find = find;
