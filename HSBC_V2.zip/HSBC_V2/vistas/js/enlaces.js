
//EDITAR USUARIO
$(".tablas").on("click", ".btnEditarEnlace", function(){
	var idEnlace = $(this).attr("idEnlace");

	var datos = new FormData();
	datos.append("idEnlace", idEnlace);
    $("#id_Enlace").val(idEnlace);

	$.ajax({
		url:"ajax/enlaces.ajax.php",
		method: "POST",
		data: datos,
		cache: false,
		contentType: false,
		processData: false,
		dataType: "json",
		success: function(respuesta){
			 $("#Editartitulo").val(respuesta["titulo"]);
			 $("#EditarLiga").val(respuesta["url"]);	
			 $("#Editarcampana").val(respuesta["id_campana"]);	
		}
	});
})

//ELIMINAR USUARIO
$(".tablas").on("click", ".btnEliminarEnlace", function(){
    var idEnlace = $(this).attr("idEnlace");
    
  swal({
    title: '¿Está seguro de borrar el Enlace?',
    text: "¡Si no lo está puede cancelar la accíón!",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Cancelar',
      confirmButtonText: 'Si, borrar Enlace!'
  }).then(function(result){

    if(result.value){

      window.location = "index.php?ruta=enlaces&idEnlace="+idEnlace;

    }

  })

})

//mostrar campanas
$("#modalAgregarLiga").on("click", "#cat_campanas", function(){
	var cat_campanas = document.getElementById("cat_campanas");
	 $.ajax({
	 	url:"ajax/enlaces.ajax.php",
	 	method: "POST",
	 	cache: false,
	 	contentType: false,
	 	processData: false,
	 	dataType: "json",
	 	success: function(respuesta){
			cat_campanas.innerHTML = '';
			respuesta.forEach(function (res) {
				let optCamp = document.createElement('option');
				optCamp.text = res.NOMBRE_CAMPANA;
				optCamp.value = res.id_campana;                 
				cat_campanas.appendChild(optCamp);
			});


	 	}
	 });
})




