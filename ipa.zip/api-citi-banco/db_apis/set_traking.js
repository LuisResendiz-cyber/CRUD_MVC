const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  // console.log('++++++++++++++++++++');
   console.log(context);
  // console.log('++++++++++++++++++++');
//$Curl->set_post_fields(array('p_id_user'=>$id_usr, 'p_evento'=>$evento, 'p_maquina'=>$maquina, 'p_id_solicitud'=>$id_solicitud, 'p_url'=>$url));
//$datos =  array('p_id_user' => 8981, "p_evento" => "FINALIZO SESION", "p_maquina" => "172.20.2.14", "p_id_solicitud" => 0, "p_url" =>  "");   //set_traking
const baseQuery = `BEGIN DBO.XSP_SETEVENTO(:p_id_user, :p_evento, :p_maquina, :p_id_solicitud, :p_url); END;`;
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.p_id_user || !context.p_evento || !context.p_maquina || !context.p_id_solicitud){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          // console.log('#########');
          // console.log(result2);
          // console.log('#########');
          return result2;

        }else{

            binds.p_id_user      = context.p_id_user;
            binds.p_evento      = context.p_evento;
            binds.p_maquina      = context.p_maquina;
            binds.p_id_solicitud      = context.p_id_solicitud;
            binds.p_url      = "";

            const result = await database.simpleExecute(query, binds);

            // console.log('#########');
            console.log('3.', result);	
            // console.log('#########');
            return result;
        }
}

module.exports.find = find;
