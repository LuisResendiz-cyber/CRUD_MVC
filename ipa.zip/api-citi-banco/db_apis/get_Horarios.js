const oracledb = require('oracledb');
const database = require('../services/database.js');


async function find(context) {

    try {
        const baseQuery = "BEGIN "+ context.schema +".SPS_HORARIOS(:op,:rc); END;";
        let query = baseQuery;
        const binds = {};
        let result2 = {};
        
        binds.op     = context.op;
        binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
        
        const result = await database.simpleExecuteRC(query, binds);
        return result;
    } catch (error) {
        console.log(Error);
    }
}

module.exports.find = find;
