const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
console.log("GET_PREGUNTAS",context);
const baseQuery = "BEGIN " + context.schema + ".PROC_SURVEY_GETQUESTIONS(:SurveyId_ ,:Lang, :Exist, :rc); END;";
	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.SurveyId_ || !context.Lang || !context.Exist){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.SurveyId_      = context.SurveyId_;
            binds.Lang      = context.Lang;
            binds.Exist      = {val:context.Exist, dir:oracledb.BIND_INOUT, type:oracledb.DB_TYPE_VARCHAR};
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

            const result = await database.simpleExecuteRC(query, binds);

             console.log(result);

            return result;
        }
}

module.exports.find = find;
