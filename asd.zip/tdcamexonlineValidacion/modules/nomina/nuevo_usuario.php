<?php
# @uthor Mark 
# abc_usuarios File en NOMINA

require_once("includes/includes.inc.php");
require_once("nominas.inc.php");

initialize("nomina","Alta de Usuarios");
layout_menu($db, "");
?>
	<h4>Alta de Usuarios</h4>
	<p id="text">Capture los datos del usuario y d� click en el bot�n continuar</p>
	<br>

	<form name="frm1" method="post" action="modules.php?mod=nomina&op=process_data&act=2">
		<table  id="t1" border="0">
		   <tr>
		        <td colspan="2"><?=form_oblmsg()?></td>
		    </tr><tr>
				<td colspan="2">&nbsp;</td>
			</tr><tr>
				<td><b>* Id Usuario:</b></td>
				<td class="label"><input type="text" name="idSelected" maxlength="6" size="10" class="label"></td>
			</tr><tr>
				<td><b>* Nombre:</b></td>
				<td><input type="text" name="nombre" maxlength="80" size="80" class="label"></td>
		    </tr><tr>
				<td><b>Contrase�a:</b></td>
				<td><input type="password" name="contrasena"  maxlength="8" size="10" class="label"></td>
		    </tr><tr>
				<td><b>Reescribir contrase�a:</b></td>
				<td><input type="password" name="re_contrasena"  maxlength="8" size="10" class="label"></td>
			</tr><tr>
				<td><b>* Perfil:</b></td>
				<td>
					<select name="perfil" onchange="muestra_super(this)">
						<option value="0">Seleccione perfil</option>
						<?
						$catalogos = get_perfiles('USR_NIVEL', $db);
						while(!$catalogos->EOF) {
							echo '<option value="'.$catalogos->fields["VALOR"].'">'.$catalogos->fields["VALOR"].' - '.$catalogos->fields["ETIQUETA"].'</option>';
							$catalogos->MoveNext();
						}
						?>
					</select>
				</td>
			</tr><tr>
				<td colspan="2">
				<br>
					<table style="display:none" id="super">
						<tr>
							<td width="36%"><b>* Supervisor:</b></td>
							<td>
								<select name="supervisor">
									<?
									$supervisores = get_supervisores(1,$db);
									while(!$supervisores->EOF) {
										echo '<option value="'.$supervisores->fields["USR_ID"].'">'.$supervisores->fields["USR_NOMBRE"].'</option>';
										$supervisores->MoveNext();
									}
									?>
								</select>
							</td>
						<tr>
					</table>
				</td>
			</tr><tr>
				<td><b>Activo</b></td>
				<td><input type="checkbox" name="activo"></td>
			</tr><tr>
				<td><b>Etapa</b></td>
				<td>
					<select name="etapa">
						<?
						$catalogos = get_perfiles('USR_ETAPA', $db);
						while(!$catalogos->EOF) {
							echo '<option value="'.$catalogos->fields["VALOR"].'" '.(trim($catalogos->fields["VALOR"])==trim($usuarios->fields['USR_GENERACION'])?"selected":"").'>'.$catalogos->fields["ETIQUETA"].'</option>';
							$catalogos->MoveNext();
						}
						?>
					</select>
				</td>
			</tr><tr>
				<td><b>Generacion</b></td>
				<td><input type="text" name="generacion" value="<?=$usuarios->fields["USR_GENERACION"]?>" maxlength="10"></td>
			</tr>
		</table>
		<br>
		<input type="button" value="Cancelar" onclick="back()">
		<input type="button" value="Continuar" onclick="valida_edicion_usuario(1)">
	</form>
	<br>
<?php
layout_footer();
?>

         
          