var tableUsuarios;
var divLoading = document.querySelector("#divLoading");
document.addEventListener("DOMContentLoaded", function () {
    initDataTable({
      tableId: "#tableUsuarios",
      url: base_url + "/Usuarios/getUsuarios",
      dataSrc: "usuarios",
      module: "Usuarios",
      request: ["getUsuario", "delUsuarios", "getUsuario"],
      columnRenderers: {
        status: function (data) {
          return data == 1
            ? '<span class="badge badge-success">Activo</span>'
            : '<span class="badge badge-danger">Inactivo</span>';
        },
      },
    });


    const formUsuario = document.querySelector("#formUsuario");

formUsuario.addEventListener("submit", async function (e) {
    e.preventDefault();

    var strNombre = document.querySelector('#txtNombre').value;
    var strApellido = document.querySelector('#txtApellido').value;
    var strEmail = document.querySelector('#txtEmail').value;
    var intTelefono = document.querySelector('#txtTelefono').value;
    var intTipousuario = document.querySelector('#listRolid').value;
    var strPassword = document.querySelector('#txtPassword').value;

    if(strApellido == '' || strNombre == '' || strEmail == '' || intTelefono == '' || intTipousuario == '')
    {
        swal("Atención", "Todos los campos son obligatorios." , "error");
        return false;
    }

    let elementsValid = document.getElementsByClassName("valid");
    for (let i = 0; i < elementsValid.length; i++) { 
        if(elementsValid[i].classList.contains('is-invalid')) { 
            swal("Atención", "Por favor verifique los campos en rojo." , "error");
            return false;
        } 
    }

    divLoading.style.display = "flex";

    const Url = `${base_url}/Usuarios/setUsuario`;
    const formData = new FormData(formUsuario);

    try {
      const response = await fetch(Url, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Error en la petición");
      }

      const objData = await response.json();

      if (objData.data.status) {
        $("#modalFormUsuario").modal("hide");
        formUsuario.reset();
        swal("Exito", objData.data.Message, "success");

        setTimeout(() => {
        initDataTable({
        tableId: "#tableUsuarios",
        url: base_url + "/Usuarios/getUsuarios",
        dataSrc: "usuarios",
        module: "Usuarios",
        request: ["getUsuario", "delUsuario", "getUsuario"],
        columnRenderers: {
          status: function (data) {
            return data == 1
              ? '<span class="badge badge-success">Activo</span>'
              : '<span class="badge badge-danger">Inactivo</span>';
          },
        } ,
      });
    }, 500);
   } else {
        swal("Error", objData.data.Message, "error");
      }
    } catch (error) {
      console.error(error);
      swal("Error", "No se pudo procesar la solicitud", "error");
    } finally {
      divLoading.style.display = "none";
    }
  });
});

async function fntRolesUsuario(idRol = null) {
    const Url = `${base_url}/Roles/getRoles`;

    const response = await fetch(Url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: 1 })
    });

    const objData = await response.json();
    const roles = objData.roles;

    const $select = $('#listRolid');

    $select.empty();

    $select.append(`<option value="">Seleccione un rol</option>`);

    roles.forEach(role => {
        $select.append(`
            <option value="${role.ID}">
                ${role.NOMBRE}
            </option>
        `);
    });

    // 🔥 1. refresca opciones
    $select.selectpicker('refresh');

    // 🔥 2. fuerza el valor seleccionado
    if (idRol) {
        $select.selectpicker('val', idRol);
    }

    // 🔥 3. renderiza el texto visible
    $select.selectpicker('render');
}


function fntViewUsuario(data){
    const {EMAIL,FECHA_CREACION,  ID, ID_ROL, NOMBRE, NOMBRE_ROL, phone_number,status} = data.data;
    
            if(status)
            {
               var estadoUsuario = status == 1 ? 
                '<span class="badge badge-success">Activo</span>' : 
                '<span class="badge badge-danger">Inactivo</span>';

                document.querySelector("#celIdentificacion").innerHTML = ID;
                document.querySelector("#celNombre").innerHTML = NOMBRE;
                document.querySelector("#celTipoUsuario").innerHTML = NOMBRE_ROL;
                document.querySelector("#celEstado").innerHTML = estadoUsuario;
                document.querySelector("#celTelefono").innerHTML = phone_number;
                document.querySelector("#celEmail").innerHTML = EMAIL;
                document.querySelector("#celFechaRegistro").innerHTML = FECHA_CREACION;
                $('#modalViewUser').modal('show');
            }else{
                swal("Error", "Sin datos para Visualizar" , "error");
            }
}

async function editUsuarios(data){
    console.log(data);
    const {EMAIL,FECHA_CREACION,  ID, ID_ROL, NOMBRE, APELLIDO, NOMBRE_ROL, phone_number,status} = data.data;

    document.querySelector('#titleModal').innerHTML ="Actualizar Usuario";
    document.querySelector('.modal-header').classList.replace("headerRegister", "headerUpdate");
    document.querySelector('#btnActionForm').classList.replace("btn-primary", "btn-info");
    document.querySelector('#btnText').innerHTML ="Actualizar";
    
        document.querySelector("#idUsuario").value = ID;
        document.querySelector("#txtNombre").value = NOMBRE;
        document.querySelector("#txtApellido").value = APELLIDO;
        document.querySelector("#txtTelefono").value = phone_number;
        document.querySelector("#txtEmail").value = EMAIL;
        await fntRolesUsuario(ID_ROL,NOMBRE_ROL);
        //document.querySelector("#listRolid").value =NOMBRE_ROL;
        //$('#listRolid').selectpicker('render');

        if(status == 1){
            document.querySelector("#listStatus").value = 1;
        }else{
            document.querySelector("#listStatus").value = 2;
        }
        $('#listStatus').selectpicker('render');
        $('#modalFormUsuario').modal('show');
}
//http://localhost:8080/Usuarios/getUsuario/59

function fntDelUsuario(idpersona){

    var idUsuario = idpersona;
    swal({
        title: "Eliminar Usuario",
        text: "¿Realmente quiere eliminar el Usuario?",
        type: "warning",
        showCancelButton: true,
        confirmButtonText: "Si, eliminar!",
        cancelButtonText: "No, cancelar!",
        closeOnConfirm: false,
        closeOnCancel: true
    }, function(isConfirm) {
        
        if (isConfirm) 
        {
            var request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            var ajaxUrl = base_url+'/Usuarios/delUsuario';
            var strData = "idUsuario="+idUsuario;
            request.open("POST",ajaxUrl,true);
            request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            request.send(strData);
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    var objData = JSON.parse(request.responseText);
                    if(objData.status)
                    {
                        swal("Eliminar!", objData.msg , "success");
                        tableUsuarios.api().ajax.reload();
                    }else{
                        swal("Atención!", objData.msg , "error");
                    }
                }
            }
        }

    });

}

async function openModal()
{
    document.querySelector('#idUsuario').value ="";
    document.querySelector('.modal-header').classList.replace("headerUpdate", "headerRegister");
    document.querySelector('#btnActionForm').classList.replace("btn-info", "btn-primary");
    document.querySelector('#btnText').innerHTML ="Guardar";
    document.querySelector('#titleModal').innerHTML = "Nuevo Usuario";
    document.querySelector("#formUsuario").reset();
    $('#modalFormUsuario').modal('show');

    await fntRolesUsuario();
}

function openModalPerfil(){
    $('#modalFormPerfil').modal('show');
}