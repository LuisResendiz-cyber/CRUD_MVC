const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
 console.log("autentico",context);
const baseQuery = "BEGIN "+ context.schema +".SPS_NOMBRE_GRABACION(:nomina, :telefono, :solicitud, :empresa, :v_result); END;";
	let query = baseQuery;
	const binds = {};
    let result2 = {};

        if(!context.nomina || !context.telefono || !context.solicitud || !context.empresa){
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.nomina = context.nomina;
            binds.telefono = context.telefono;
            binds.solicitud = context.solicitud;
            binds.empresa = context.empresa;
            binds.v_result = {val:context.v_result, dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};

            const result = await database.simpleExecute(query, binds);

             console.log(result);

            return result;
                }
}

module.exports.find = find;
