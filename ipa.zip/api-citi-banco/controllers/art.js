const art = require('../db_apis/art.js');
const fetch = require('node-fetch'); 
const jwt = require('./token_manager'); 
const config  = require('../config/web-server'); 

async function post(req, res, next) {
  try {
    const context = req.body;//{};
    // console.log('conteext');
    // console.log(context);
    const params = {
    //   fecha_carga: context.fecha1,
      schema: 'citi'
    };
    
    // console.log(params);

    // let data = await fetch(config.keyRingHost, {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'access_token': jwt.get(),
    //     'Accept': 'application/json'
    //   },
    //   body: JSON.stringify(params)
    // })
    // .then(res=>res.json())
    // .then(data=>{
    //   if(!data.error){
    //     jwt.set(data.idtoken)
    //     context.keyrig=data.dataKey;
    //   }
    //   else{
    //     res.status(500);
    //     throw Error("Error al Obtener KEYRING ( "+data.msg+" )" );       
    //   }
    // })
    // .catch(err=>{
    //   res.status(500);
    //   return err;
    // })   
    
    // console.log(context);
    const rows = await art.find(context);
 
    if (req.params.id) {
      if (rows.length === 1) {
        res.status(200).json(rows[0]);
      } else {
        res.status(404).end();
      }
    } else {
      res.status(200).json(rows);
    }
  } catch (err) {
    next(err);
  }
}
 
module.exports.post = post;