const oracledb = require('oracledb');
const database = require('../services/database.js');
 

async function find(context) {

const baseQuery = "BEGIN "+ context.schema +".XSP_BUSCAREGISTRO_WEB(:solicitud, :nombre, :paterno, :materno, :agente, :telefono, :rc); END;";
// const baseQuery = "BEGIN "+ context.schema +".XSP_BUSCAREGISTRO_WEB(:solicitud, :nombre, :paterno, :materno, :agente, :telefono, :rc, :keys); END;";
//console.log(baseQuery);
console.log(context);

	let query = baseQuery;
	const binds = {};
        let result2 = {};

        if(!context.solicitud||!context.agente||!context.telefono){//!context.nombre||!context.paterno||!context.materno||
          // if(!context.solicitud||!context.agente||!context.telefono||context.keys== ''){//!context.nombre||!context.paterno||!context.materno||
          //console.log("Parametros incorrectos")
          result2.error_ = true;
          result2.mensaje = "Parametros Erroneos";
          return result2;

        }else{

            binds.solicitud      = context.solicitud;
            binds.nombre      = context.nombre;
            binds.paterno      = context.paterno;
            binds.materno      = context.materno;
            binds.agente      = context.agente;
            binds.telefono      = context.telefono;
            binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
            // binds.keys      = context.keyrig;

            const result = await database.simpleExecuteRC(query, binds);

            console.log(result);	

            return result;
        }            
}
 
module.exports.find = find;
