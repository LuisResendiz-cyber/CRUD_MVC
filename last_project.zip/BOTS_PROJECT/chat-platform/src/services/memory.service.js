const conversationMemory = {};

const saveMessage = (sessionId, role, content) => {
  if (!conversationMemory[sessionId]) {
    conversationMemory[sessionId] = [];
  }

  conversationMemory[sessionId].push({ role, content });

  // limitar a últimos 6 mensajes
  if (conversationMemory[sessionId].length > 6) {
    conversationMemory[sessionId].shift();
  }
};

const getMemory = (sessionId) => {
  return conversationMemory[sessionId] || [];
};

module.exports = {
  saveMessage,
  getMemory
};
