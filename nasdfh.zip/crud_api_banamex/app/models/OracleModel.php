<?php

require_once __DIR__ . '/../config/database.php';

class dataBaseModel
{
  protected $db;
  protected $tbl = 'CITISOFOM.VENTAS_BOT';
  protected $procedure = 'CITISOFOM.XSP_BOT_VENTAS';

  public function __construct()
  {
    $this->db = new OracleConexion();
    $this->db->connect();
  }

  public function testConn($query)
  {
    $sql = "SELECT * FROM dual";
    return $this->db->execute('select', $sql);
  }

  private function cleanData($data)
  {
    $str = trim($data);

    $acentos = [
      'Á' => 'A',
      'É' => 'E',
      'Í' => 'I',
      'Ó' => 'O',
      'Ú' => 'U',
      'Ü' => 'U',
      'á' => 'a',
      'é' => 'e',
      'í' => 'i',
      'ó' => 'o',
      'ú' => 'u',
      'ü' => 'u',
      'Ñ' => 'N',
      '/' => '',
      '|' => '',
      'ñ' => 'n'
    ];

    $str = strtr($str, $acentos);
    return $str;
  }

  public function insertSales($data)
  {
    $details = [];
    foreach ($data as $valor) {
      $parametros = [
        ':v_step' => 1,
        ':ID_SURVEY' => $valor['ID_SURVEY'],
        ':ID_USER' => $valor['ID_USER'],
        ':DATE_INSERT' => $valor['DATE_INSERT'],
        ':CUSTOMERID' => $valor['CUSTOMERID'],
        ':ID_PHONE' => $valor['ID_PHONE'],
        ':TYPIFICATIONID' => $valor['TYPIFICATIONID'],
        ':CAMPANA' => $valor['CAMPAIGN'],
        ':STATUS_FROM_TMK' => $valor['STATUS_FROM_TMK'],
        ':PRODUCT' => $valor['PRODUCT'],
        ':TDC' => $valor['TDC'],
        ':LINE_CREDIT' => $valor['LINE_CREDIT'],
        ':BASE_FOLIO' => $valor['BASE_FOLIO'],
        ':BIRTH_DATE' => $valor['BIRTH_DATE'],
        ':HOLDER_LAST_NAME_FATHER' => $valor['HOLDER_LAST_NAME_FATHER'],
        ':HOLDER_LAST_NAME_MOTHER' => $valor['HOLDER_LAST_NAME_MOTHER'],
        ':HOLDER_NAME' => $valor['HOLDER_NAME'],
        ':RFC' => $valor['RFC'],
        ':HOMOCLAVE' => $valor['HOMOCLAVE'],
        ':CURP' => $valor['CURP'],
        ':COMMENTS' => $valor['COMMENTS'],
        ':STREET' => $valor['STREET'],
        ':EXTERIOR_NUMBER' => $valor['EXTERIOR_NUMBER'],
        ':INTERIOR_NUMBER' => $valor['INTERIOR_NUMBER'],
        ':POSTAL_CODE' => $valor['POSTAL_CODE'],
        ':COLONY' => $valor['COLONY'],
        ':STATE' => $valor['STATE'],
        ':REFERENCE_MUNICIPALITY' => $valor['REFERENCE_MUNICIPALITY'],
        ':MUNICIPALITY' => $valor['MUNICIPALITY'],
        ':CELL_PHONE' => $valor['CELL_PHONE'],
        ':PHONE' => $valor['PHONE'],
        ':CONTACT_PHONE' => $valor['CONTACT_PHONE'],
        ':COUNTRY_BIRTH' => $valor['COUNTRY_BIRTH'],
        ':FEDERAL_ENTITY' => $valor['FEDERAL_ENTITY'],
        ':EMAIL' => $valor['EMAIL'],
        ':MONTHLY_INCOME' => $valor['MONTHLY_INCOME'],
        ':INCOME_RECEIPT_TYPE' => $valor['INCOME_RECEIPT_TYPE'],
        ':IDENTIFICATION_TYPE' => $valor['IDENTIFICATION_TYPE'],
        ':ADDRESS_RECEIPT_TYPE' => $valor['ADDRESS_RECEIPT_TYPE'],
        ':NUMBER_REFERENCES' => $valor['NUMBER_REFERENCES'],
        ':CREDIT_REFERENCE_1' => $valor['CREDIT_REFERENCE_1'],
        ':LAST_4_DIGITS_CARD_1' => $valor['LAST_4_DIGITS_CARD_1'],
        ':CREDIT_REFERENCE_2' => $valor['CREDIT_REFERENCE_2'],
        ':LAST_4_DIGITS_CARD_2' => $valor['LAST_4_DIGITS_CARD_2'],
        ':CREDIT_REFERENCE_3' => $valor['CREDIT_REFERENCE_3'],
        ':LAST_4_DIGITS_CARD_3' => $valor['LAST_4_DIGITS_CARD_3'],
        ':PERSONAL_LAST_NAME_FATHER' => $valor['PERSONAL_LAST_NAME_FATHER'],
        ':PERSONAL_LAST_NAME_MOTHER' => $valor['PERSONAL_LAST_NAME_MOTHER'],
        ':PERSONAL_NAME' => $valor['PERSONAL_NAME'],
        ':PERSONAL_RELATIONSHIP' => $valor['PERSONAL_RELATIONSHIP'],
        ':PERSONAL_PHONE' => $valor['PERSONAL_PHONE'],
        ':PERSONAL_EXTENSION' => $valor['PERSONAL_EXTENSION'],
        ':BRANCH_VISIT_DATE' => $valor['BRANCH_VISIT_DATE']


      ];
      // $cursorParam = ':rc';
      $rspta = $this->db->ejecutarProcedimientoConCursor($this->procedure, $parametros);
      // var_dump($rspta[0]['RESPONSE']);

      $details[] = [
        'ID_SURVEY' => $valor['ID_SURVEY'],
        'STATUS' => $rspta[0]['RESPONSE']
      ];
    }
    return $details;
  }

  public function simulate(){
    try {
      $parametros = [
        ':v_step' => 99,
        ':ID_SURVEY' => null,
        ':ID_USER' => null,
        ':DATE_INSERT' => null,
        ':CUSTOMERID' => null,
        ':ID_PHONE' => null,
        ':TYPIFICATIONID' => null,
        ':CAMPANA' => null,
        ':STATUS_FROM_TMK' => null,
        ':PRODUCT' => null,
        ':TDC' => null,
        ':LINE_CREDIT' => null,
        ':BASE_FOLIO' => null,
        ':BIRTH_DATE' => null,
        ':HOLDER_LAST_NAME_FATHER' => null,
        ':HOLDER_LAST_NAME_MOTHER' => null,
        ':HOLDER_NAME' => null,
        ':RFC' => null,
        ':HOMOCLAVE' => null,
        ':CURP' => null,
        ':COMMENTS' => null,
        ':STREET' => null,
        ':EXTERIOR_NUMBER' => null,
        ':INTERIOR_NUMBER' => null,
        ':POSTAL_CODE' => null,
        ':COLONY' => null,
        ':STATE' => null,
        ':REFERENCE_MUNICIPALITY' => null,
        ':MUNICIPALITY' => null,
        ':CELL_PHONE' => null,
        ':PHONE' => null,
        ':CONTACT_PHONE' => null,
        ':COUNTRY_BIRTH' => null,
        ':FEDERAL_ENTITY' => null,
        ':EMAIL' => null,
        ':MONTHLY_INCOME' => null,
        ':INCOME_RECEIPT_TYPE' => null,
        ':IDENTIFICATION_TYPE' => null,
        ':ADDRESS_RECEIPT_TYPE' => null,
        ':NUMBER_REFERENCES' => null,
        ':CREDIT_REFERENCE_1' => null,
        ':LAST_4_DIGITS_CARD_1' => null,
        ':CREDIT_REFERENCE_2' => null,
        ':LAST_4_DIGITS_CARD_2' => null,
        ':CREDIT_REFERENCE_3' => null,
        ':LAST_4_DIGITS_CARD_3' => null,
        ':PERSONAL_LAST_NAME_FATHER' => null,
        ':PERSONAL_LAST_NAME_MOTHER' => null,
        ':PERSONAL_NAME' => null,
        ':PERSONAL_RELATIONSHIP' => null,
        ':PERSONAL_PHONE' => null,
        ':PERSONAL_EXTENSION' => null,
        ':BRANCH_VISIT_DATE' => null
      ];
      $rspta = $this->db->ejecutarProcedimientoConCursor($this->procedure, $parametros);
      return $rspta;

    } catch (Exception $e) {
      echo "Se produjo un error: " . $e->getMessage();
    }   
  }
  public function insertNoSales($data,$option =1)
  {
    $details = [];
    foreach ($data as $valor) {
      $parametros = [
        ':v_step' => 2,
        ':ID_SURVEY' => $valor['ID_SURVEYNOSALE'],
        ':ID_USER' => $valor['ID_USER'],
        ':DATE_INSERT' => $valor['DATE_INSERT'],
        ':CUSTOMERID' => $valor['CUSTOMERID'],
        ':ID_PHONE' => $valor['ID_PHONE'],
        ':TYPIFICATIONID' => $valor['TYPIFICATIONID'],
        ':CAMPANA' => null,
        ':STATUS_FROM_TMK' => null,
        ':PRODUCT' => null,
        ':TDC' => null,
        ':LINE_CREDIT' => null,
        ':BASE_FOLIO' => null,
        ':BIRTH_DATE' => null,
        ':HOLDER_LAST_NAME_FATHER' => null,
        ':HOLDER_LAST_NAME_MOTHER' => null,
        ':HOLDER_NAME' => null,
        ':RFC' => null,
        ':HOMOCLAVE' => null,
        ':CURP' => null,
        ':COMMENTS' => null,
        ':STREET' => null,
        ':EXTERIOR_NUMBER' => null,
        ':INTERIOR_NUMBER' => null,
        ':POSTAL_CODE' => null,
        ':COLONY' => null,
        ':STATE' => null,
        ':REFERENCE_MUNICIPALITY' => null,
        ':MUNICIPALITY' => null,
        ':CELL_PHONE' => null,
        ':PHONE' => null,
        ':CONTACT_PHONE' => null,
        ':COUNTRY_BIRTH' => null,
        ':FEDERAL_ENTITY' => null,
        ':EMAIL' => null,
        ':MONTHLY_INCOME' => null,
        ':INCOME_RECEIPT_TYPE' => null,
        ':IDENTIFICATION_TYPE' => null,
        ':ADDRESS_RECEIPT_TYPE' => null,
        ':NUMBER_REFERENCES' => null,
        ':CREDIT_REFERENCE_1' => null,
        ':LAST_4_DIGITS_CARD_1' => null,
        ':CREDIT_REFERENCE_2' => null,
        ':LAST_4_DIGITS_CARD_2' => null,
        ':CREDIT_REFERENCE_3' => null,
        ':LAST_4_DIGITS_CARD_3' => null,
        ':PERSONAL_LAST_NAME_FATHER' => null,
        ':PERSONAL_LAST_NAME_MOTHER' => null,
        ':PERSONAL_NAME' => null,
        ':PERSONAL_RELATIONSHIP' => null,
        ':PERSONAL_PHONE' => null,
        ':PERSONAL_EXTENSION' => null,
        ':BRANCH_VISIT_DATE' => null


      ];
      // $cursorParam = ':rc';
      $rspta = $this->db->ejecutarProcedimientoConCursor($this->procedure, $parametros);
      // var_dump($rspta[0]['RESPONSE']);

      $details[] = [
        'ID_SURVEYNOSALE' => $valor['ID_SURVEYNOSALE'],
        'STATUS' => $rspta[0]['RESPONSE']
      ];
    }
    // var_dump($details);
    return $details;
  }



  public function simulateNoSale(){
    try {
      $parametros = [
        ':v_step' => 3,
        ':ID_SURVEY' => null,
        ':ID_USER' => null,
        ':DATE_INSERT' => null,
        ':CUSTOMERID' => null,
        ':ID_PHONE' => null,
        ':TYPIFICATIONID' => null,
        ':CAMPANA' => null,
        ':STATUS_FROM_TMK' => null,
        ':PRODUCT' => null,
        ':TDC' => null,
        ':LINE_CREDIT' => null,
        ':BASE_FOLIO' => null,
        ':BIRTH_DATE' => null,
        ':HOLDER_LAST_NAME_FATHER' => null,
        ':HOLDER_LAST_NAME_MOTHER' => null,
        ':HOLDER_NAME' => null,
        ':RFC' => null,
        ':HOMOCLAVE' => null,
        ':CURP' => null,
        ':COMMENTS' => null,
        ':STREET' => null,
        ':EXTERIOR_NUMBER' => null,
        ':INTERIOR_NUMBER' => null,
        ':POSTAL_CODE' => null,
        ':COLONY' => null,
        ':STATE' => null,
        ':REFERENCE_MUNICIPALITY' => null,
        ':MUNICIPALITY' => null,
        ':CELL_PHONE' => null,
        ':PHONE' => null,
        ':CONTACT_PHONE' => null,
        ':COUNTRY_BIRTH' => null,
        ':FEDERAL_ENTITY' => null,
        ':EMAIL' => null,
        ':MONTHLY_INCOME' => null,
        ':INCOME_RECEIPT_TYPE' => null,
        ':IDENTIFICATION_TYPE' => null,
        ':ADDRESS_RECEIPT_TYPE' => null,
        ':NUMBER_REFERENCES' => null,
        ':CREDIT_REFERENCE_1' => null,
        ':LAST_4_DIGITS_CARD_1' => null,
        ':CREDIT_REFERENCE_2' => null,
        ':LAST_4_DIGITS_CARD_2' => null,
        ':CREDIT_REFERENCE_3' => null,
        ':LAST_4_DIGITS_CARD_3' => null,
        ':PERSONAL_LAST_NAME_FATHER' => null,
        ':PERSONAL_LAST_NAME_MOTHER' => null,
        ':PERSONAL_NAME' => null,
        ':PERSONAL_RELATIONSHIP' => null,
        ':PERSONAL_PHONE' => null,
        ':PERSONAL_EXTENSION' => null,
        ':BRANCH_VISIT_DATE' => null
      ];
      $rspta = $this->db->ejecutarProcedimientoConCursor($this->procedure, $parametros);
      return $rspta;

    } catch (Exception $e) {
      echo "Se produjo un error: " . $e->getMessage();
    }   
  }

  public function customerData(){
    try {
      $parametros = [
        ':v_step' => 4,
        ':ID_SURVEY' => null,
        ':ID_USER' => null,
        ':DATE_INSERT' => null,
        ':CUSTOMERID' => null,
        ':ID_PHONE' => null,
        ':TYPIFICATIONID' => null,
        ':CAMPANA' => null,
        ':STATUS_FROM_TMK' => null,
        ':PRODUCT' => null,
        ':TDC' => null,
        ':LINE_CREDIT' => null,
        ':BASE_FOLIO' => null,
        ':BIRTH_DATE' => null,
        ':HOLDER_LAST_NAME_FATHER' => null,
        ':HOLDER_LAST_NAME_MOTHER' => null,
        ':HOLDER_NAME' => null,
        ':RFC' => null,
        ':HOMOCLAVE' => null,
        ':CURP' => null,
        ':COMMENTS' => null,
        ':STREET' => null,
        ':EXTERIOR_NUMBER' => null,
        ':INTERIOR_NUMBER' => null,
        ':POSTAL_CODE' => null,
        ':COLONY' => null,
        ':STATE' => null,
        ':REFERENCE_MUNICIPALITY' => null,
        ':MUNICIPALITY' => null,
        ':CELL_PHONE' => null,
        ':PHONE' => null,
        ':CONTACT_PHONE' => null,
        ':COUNTRY_BIRTH' => null,
        ':FEDERAL_ENTITY' => null,
        ':EMAIL' => null,
        ':MONTHLY_INCOME' => null,
        ':INCOME_RECEIPT_TYPE' => null,
        ':IDENTIFICATION_TYPE' => null,
        ':ADDRESS_RECEIPT_TYPE' => null,
        ':NUMBER_REFERENCES' => null,
        ':CREDIT_REFERENCE_1' => null,
        ':LAST_4_DIGITS_CARD_1' => null,
        ':CREDIT_REFERENCE_2' => null,
        ':LAST_4_DIGITS_CARD_2' => null,
        ':CREDIT_REFERENCE_3' => null,
        ':LAST_4_DIGITS_CARD_3' => null,
        ':PERSONAL_LAST_NAME_FATHER' => null,
        ':PERSONAL_LAST_NAME_MOTHER' => null,
        ':PERSONAL_NAME' => null,
        ':PERSONAL_RELATIONSHIP' => null,
        ':PERSONAL_PHONE' => null,
        ':PERSONAL_EXTENSION' => null,
        ':BRANCH_VISIT_DATE' => null
      ];
      $rspta = $this->db->ejecutarProcedimientoConCursor($this->procedure, $parametros);
      return $rspta;

    } catch (Exception $e) {
      echo "Se produjo un error: " . $e->getMessage();
    }   
  }
}
