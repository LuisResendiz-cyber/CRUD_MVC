<?php
function start($db){
  $logger = new Logger($db);
  $logger->log('TRUNCANDO TABLA',0,2); //truncar tabla
  sleep(1);
  $logger->log('TABLA TRUNCADA',0,1); // guardar log
  sleep(1);

  $dir = scandir('leads_Temporal');
  $directorio = array_diff($dir, array('.', '..'));
    foreach ($directorio as $key => $value) {         
      read_leads($value,$db);      
      $fileMover = new FileMover();
      $fileMover->moveFile($value, 1);
    }
}
function read_leads($data,$db){   
  $logger = new Logger($db);
  $fileMover = new FileMover();
  $acentosRemover = new RemoveAccents();
  $registroSender = new Capi();  
  
  $logger->log('LEYENDO ARCHIVOS',0,1); // guardar log
  sleep(1);
  try {
      $archivo = fopen("leads_Temporal/".$data, "r");
      if ($archivo) {           
        fgetcsv($archivo);               
        while (($linea = fgetcsv($archivo,1000,"|")) !== false) {        
          $lead = array();      
          for ($i = 0; $i <= 65; $i++) {
              $column_name = 'dato_' . $i;
              $dato = isset($linea[$i]) ? $acentosRemover->quitarAcentos($linea[$i]) : '';
              $lead[$column_name] = $dato;
          }        
          
          // SE COMENTA POR INDICACIONES DE AMEX CAPI                    
          // if ($lead["dato_10"] == 1 || $lead["dato_10"] == 2) {    
          //   $resultado = $registroSender->enviarRegistroMain6($lead);
          //   $logger->log("ENVIO DE DATOS A CAPI",0,1);                                    
          // }      

          $name_file=str_replace( array('.txt'), array(''),$data);  //nombre del archivo
          $tipoArchivo = substr($name_file, 30) ? $oa=2 : $oa=1;
          $lead["dato_59"] = $name_file;
          $lead["dato_60"] = $tipoArchivo;
          $lead["dato_53"] = substr($lead["dato_53"], 0, 4); //validar solo 4 digitos tarjeta          
          $dataInserter = new DataInserter($db);
          $result = $dataInserter->insertData($lead); 

          if ($result==1) {
            $logger->log("EXITO AL GUARDAR REGISTROS, FOLIO: ".$lead["dato_0"],0,1);                                    
            
          } else {
            $logger->log("ERROR AL GUARDAR REGISTROS, FOLIO: ".$lead["dato_0"],1,1);  
            notify(1,$data); 
            notify(2,$data.' Fila => '.$lead["dato_14"]);          
            $fileMover->moveFile($data, 2);  
          }          
        } //fin while          
        $logger->log('FINALIZA CARGA LEADS',0,1);    
        fclose($archivo);
      } else {
        $logger->log("ARCHIVO DANADO: $data",1,1);            
        notify(1,$data); 
        notify(2,$data);            
      }  
  } catch (Exception $e) {      
      $error_=$e->getMessage();
      notify(1,'ERROR GENERAL'); 
      notify(2,$error_);       
  }  
}//fin read_leads
?>