<?php

/*
  /// <param name="nombre">Nombre(s) de la persona</param>
  /// <param name="apellidoPaterno">Apellido paterno de la persona</param>
  /// <param name="apellidoMaterno">Apellido materno de la persona</param>
  /// <param name="fecha">Fecha en formato dd/MM/yy (12/10/68)</param>
  /// <returns>Regresa el RFC como cadena de caracteres</returns>
 */

/*
 * Quita art�culos de nombre y apellidos compuestos
 */

function QuitarArticulos($palabra) {
    if ($palabra != null) {
    $palabra = str_replace("DA ", "", $palabra);
    $palabra = str_replace("DI ", "", $palabra);
    $palabra = str_replace("DD ", "", $palabra);
    $palabra = str_replace("DIE ", "", $palabra);
    $palabra = str_replace("DAS ", "", $palabra);
    $palabra = str_replace("DEL ", "", $palabra);
    $palabra = str_replace("DER ", "", $palabra);
    $palabra = str_replace("LAS ", "", $palabra);
    $palabra = str_replace("DE ", "", $palabra);
    $palabra = str_replace("LA ", "", $palabra);
    $palabra = str_replace("EL ", "", $palabra);
    $palabra = str_replace("LE ", "", $palabra);
    $palabra = str_replace("LES ", "", $palabra);
    $palabra = str_replace("Y ", "", $palabra);
    $palabra = str_replace("A ", "", $palabra);
    $palabra = str_replace("MC ", "", $palabra);
    $palabra = str_replace("MAC ", "", $palabra);
    $palabra = str_replace("LOS ", "", $palabra);
    $palabra = str_replace("VON ", "", $palabra);
    $palabra = str_replace("VAN ", "", $palabra);
    }  else{
        $palabra = 'X';
    }  

    return $palabra;
  
}

/*
 * Quitar del nombre JOS� y MAR�A
 */

function QuitarNombreJM($nombre) {
    $nombres = explode(" ", strtoupper($nombre));
    if (count($nombres) > 1) {
        if (array_search('JOSE', $nombres) !== false) {
            $nombres[array_search('JOSE', $nombres)] = "";
        } else if (array_search('MARIA', $nombres) !== false) {
            $nombres[array_search('MARIA', $nombres)] = "";
        }else if (array_search('MA', $nombres) !== false) {
            $nombres[array_search('MA', $nombres)] = "";
        }else if (array_search('MA.', $nombres) !== false) {
            $nombres[array_search('MA.', $nombres)] = "";
        }else if (array_search('M', $nombres) !== false) {
            $nombres[array_search('M', $nombres)] = "";
        }else if (array_search('M.', $nombres) !== false) {
            $nombres[array_search('M.', $nombres)] = "";
        }else if (array_search('JO', $nombres) !== false) {
            $nombres[array_search('JO', $nombres)] = "";
        }else if (array_search('JO.', $nombres) !== false) {
            $nombres[array_search('JO.', $nombres)] = "";
        }else if (array_search('J', $nombres) !== false) {
            $nombres[array_search('J', $nombres)] = "";
        }else if (array_search('J.', $nombres) !== false) {
            $nombres[array_search('J.', $nombres)] = "";
        }
        array_replace($nombres, array('JOSE', 'MARIA', 'MA', 'MA.', 'M', 'M.', 'JO', 'JO.', 'J', 'J.'));
        /*
          if (in_array($nombres[0], array('JOSE', 'MARIA'))) {
          $nombres[0] = "";
          }
         * 
         */
    }
    $nombre_correcto = trim(implode(" ", $nombres));
    return $nombre_correcto;
}

function EsVocal($letra) {
    //if ($letra == 'A' || $letra == 'E' || $letra == 'I' || $letra == 'O' || $letra == 'U' || $letra == 'a' || $letra == 'e' || $letra == 'i' || $letra == 'o' || $letra == 'u')
    $es_vocal = strpos('AEIOUaeiou����������', $letra);
    if ($es_vocal === false) {
        return 0;
    } else {
        return 1;
    }
}

function QuitarAltisonantes($rfc) {
    $iniciales = substr($rfc, 0, 4);
    $altisonantes = "BUEIBUEYCACACACOCAGACAGOCAKACAKOCOGECOJAKOGEKOJOKAKAKULOMAMEMAMO";
    $altisonantes .= "MEARMEASMEONMIONCOJECOJICOJOCULOFETOGUEYJOTOKACAKACOKAGA";
    $altisonantes .= "KAGOMOCOMULAPEDAPEDOPENEPUTAPUTOQULORATARUINCOLAPITOGATAGATO";
    $i = 0;
    while ($i < strlen($altisonantes)) {
        $lista[] = substr($altisonantes, $i, 4);
        $i += 4;
    }
    $resultado = "";
    if (in_array($iniciales, $lista)) {
        $resultado = substr($rfc, 0, 3) . 'X' . substr($rfc, 4);
    } else {
        $resultado = $rfc;
    }
    return $resultado;
}

function CalcularHomoclave($nombreCompleto, $rfc) {
    $tablaRFC1[' '] = '00';
    $tablaRFC1['0'] = '00';
    $tablaRFC1['1'] = '01';
    $tablaRFC1['2'] = '02';
    $tablaRFC1['3'] = '03';
    $tablaRFC1['4'] = '04';
    $tablaRFC1['5'] = '05';
    $tablaRFC1['6'] = '06';
    $tablaRFC1['7'] = '07';
    $tablaRFC1['8'] = '08';
    $tablaRFC1['9'] = '09';
    $tablaRFC1['&'] = '10';
    $tablaRFC1['A'] = '11';
    $tablaRFC1['B'] = '12';
    $tablaRFC1['C'] = '13';
    $tablaRFC1['D'] = '14';
    $tablaRFC1['E'] = '15';
    $tablaRFC1['F'] = '16';
    $tablaRFC1['G'] = '17';
    $tablaRFC1['H'] = '18';
    $tablaRFC1['I'] = '19';
    $tablaRFC1['J'] = '21';
    $tablaRFC1['K'] = '22';
    $tablaRFC1['L'] = '23';
    $tablaRFC1['M'] = '24';
    $tablaRFC1['N'] = '25';
    $tablaRFC1['O'] = '26';
    $tablaRFC1['P'] = '27';
    $tablaRFC1['Q'] = '28';
    $tablaRFC1['R'] = '29';
    $tablaRFC1['S'] = '32';
    $tablaRFC1['T'] = '33';
    $tablaRFC1['U'] = '34';
    $tablaRFC1['V'] = '35';
    $tablaRFC1['W'] = '36';
    $tablaRFC1['X'] = '37';
    $tablaRFC1['Y'] = '38';
    $tablaRFC1['Z'] = '39';
    $tablaRFC1['�'] = '40';

    $tablaRFC2[0] = "1";
    $tablaRFC2[1] = "2";
    $tablaRFC2[2] = "3";
    $tablaRFC2[3] = "4";
    $tablaRFC2[4] = "5";
    $tablaRFC2[5] = "6";
    $tablaRFC2[6] = "7";
    $tablaRFC2[7] = "8";
    $tablaRFC2[8] = "9";
    $tablaRFC2[9] = "A";
    $tablaRFC2[10] = "B";
    $tablaRFC2[11] = "C";
    $tablaRFC2[12] = "D";
    $tablaRFC2[13] = "E";
    $tablaRFC2[14] = "F";
    $tablaRFC2[15] = "G";
    $tablaRFC2[16] = "H";
    $tablaRFC2[17] = "I";
    $tablaRFC2[18] = "J";
    $tablaRFC2[19] = "K";
    $tablaRFC2[20] = "L";
    $tablaRFC2[21] = "M";
    $tablaRFC2[22] = "N";
    $tablaRFC2[23] = "P";
    $tablaRFC2[24] = "Q";
    $tablaRFC2[25] = "R";
    $tablaRFC2[26] = "S";
    $tablaRFC2[27] = "T";
    $tablaRFC2[28] = "U";
    $tablaRFC2[29] = "V";
    $tablaRFC2[30] = "W";
    $tablaRFC2[31] = "X";
    $tablaRFC2[32] = "Y";
    $tablaRFC2[33] = "Z";

    $tablaRFC3['0'] = 0;
    $tablaRFC3['1'] = 1;
    $tablaRFC3['2'] = 2;
    $tablaRFC3['3'] = 3;
    $tablaRFC3['4'] = 4;
    $tablaRFC3['5'] = 5;
    $tablaRFC3['6'] = 6;
    $tablaRFC3['7'] = 7;
    $tablaRFC3['8'] = 8;
    $tablaRFC3['9'] = 9;
    $tablaRFC3['A'] = 10;
    $tablaRFC3['B'] = 11;
    $tablaRFC3['C'] = 12;
    $tablaRFC3['D'] = 13;
    $tablaRFC3['E'] = 14;
    $tablaRFC3['F'] = 15;
    $tablaRFC3['G'] = 16;
    $tablaRFC3['H'] = 17;
    $tablaRFC3['I'] = 18;
    $tablaRFC3['J'] = 19;
    $tablaRFC3['K'] = 20;
    $tablaRFC3['L'] = 21;
    $tablaRFC3['M'] = 22;
    $tablaRFC3['N'] = 23;
    $tablaRFC3['&'] = 24;
    $tablaRFC3['O'] = 25;
    $tablaRFC3['P'] = 26;
    $tablaRFC3['Q'] = 27;
    $tablaRFC3['R'] = 28;
    $tablaRFC3['S'] = 29;
    $tablaRFC3['T'] = 30;
    $tablaRFC3['U'] = 31;
    $tablaRFC3['V'] = 32;
    $tablaRFC3['W'] = 33;
    $tablaRFC3['X'] = 34;
    $tablaRFC3['Y'] = 35;
    $tablaRFC3['Z'] = 36;
    $tablaRFC3[' '] = 37;
    $tablaRFC3['�'] = 38;

    $nombreEnNumero = "0";
    $len_nombreCompleto = strlen($nombreCompleto);
    for ($x = 0; $x < $len_nombreCompleto; $x++) {
        $c = substr($nombreCompleto, $x, 1);
        if (isset($tablaRFC1[$c])) {
            $nombreEnNumero .= $tablaRFC1[$c];
        } else {
            $nombreEnNumero .= "00";
        }
    }

    $valorSuma = 0;
    $n = strlen($nombreEnNumero) - 1;
    for ($i = 0; $i < $n; $i++) {
        $prod1 = substr($nombreEnNumero, $i, 2);
        $prod2 = substr($nombreEnNumero, $i + 1, 1);
        $valorSuma += $prod1 * $prod2;
    }

    $dividendo = $valorSuma % 1000;
    $cociente = floor($dividendo / 34);
    $residuo = $dividendo % 34;

    $hc = $tablaRFC2[$cociente];
    $hc.= $tablaRFC2[$residuo];

    $rfc_hc = $rfc . $hc;

    $a = 1;
    $b = 13;
    $digitoNum = 0;
    while ($a <= 12) {
        $digito = substr($rfc_hc, $a - 1, 1);
        $valorDigito = $tablaRFC3[$digito];
        $digitoNum += $valorDigito * $b;
        $a++;
        $b--;
    }
    $digito = 11 - ($digitoNum % 11);
    switch ($digito) {
        case 10:
            $RfcDigitVeri = "A";
            break;
        case 11:
            $RfcDigitVeri = "0";
            break;
        default:
            $RfcDigitVeri = $digito;
    }
    $hc .= $RfcDigitVeri;
    //$rfc .= $RfcDigitVeri;
    return $hc;
}

function CalcularRFC($nombre, $apellidoPaterno, $apellidoMaterno, $fecha) {
    /*
     * Cambiamos todo a may�sculas.
     * Quitamos los espacios al principio y final del nombre y apellidos
     */
    $nombre = strtoupper(trim($nombre));
    $nombre = str_replace(array('�', '�', '�', '�'), 'A', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'E', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'I', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'O', $nombre);
    $nombre = str_replace(array('�', '�', '�', '�'), 'U', $nombre);
    $nombre = str_replace(array('�', '�'), '&', $nombre);
    $apellidoPaterno = strtoupper(trim($apellidoPaterno));
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'A', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'E', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'I', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'O', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�', '�', '�'), 'U', $apellidoPaterno);
    $apellidoPaterno = str_replace(array('�', '�'), '&', $apellidoPaterno);
    $apellidoMaterno = strtoupper(trim($apellidoMaterno));
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'A', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'E', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'I', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'O', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�', '�', '�'), 'U', $apellidoMaterno);
    $apellidoMaterno = str_replace(array('�', '�'), '&', $apellidoMaterno);

    //RFC que se regresar�
    $rfc = "";

    //Quitamos los art�culos de los apellidos
    $apellidoPaterno_editado = QuitarArticulos($apellidoPaterno);
    $apellidoMaterno_editado = QuitarArticulos($apellidoMaterno);
    $nombre_editado1 = QuitarNombreJM($nombre);
    $nombre_editado = QuitarArticulos($nombre_editado1);

    //Agregamos el primer caracter del apellido paterno
    $rfc = substr($apellidoPaterno_editado, 0, 1);

    //Buscamos y agregamos al rfc la primera vocal del primer apellido
    $len_apellidoPaterno = strlen($apellidoPaterno_editado);
    for ($x = 1; $x < $len_apellidoPaterno; $x++) {
        $c = substr($apellidoPaterno_editado, $x, 1);
        if (EsVocal($c)) {
            $rfc .= $c;
            break;
        }
    }

    //Agregamos el primer caracter del apellido materno
    $rfc .= substr($apellidoMaterno_editado, 0, 1);

    //Agregamos el primer caracter del primer nombre
    $rfc .= substr($nombre_editado, 0, 1);

    //Agregamos la fecha yymmdd (por ejemplo: 680825, 25 de agosto de 1968 )
    $rfc .= substr($fecha, 8, 4) . substr($fecha, 3, 2) . substr($fecha, 0, 2);

    //Le agregamos la homoclave al rfc
    //CalcularHomoclave($apellidoPaterno . " " . $apellidoMaterno . " " . $nombre, $fecha, $rfc);
    $rfc = QuitarAltisonantes($rfc);
    $homoclave = CalcularHomoclave($apellidoPaterno . " " . $apellidoMaterno . " " . $nombre, $rfc);
    $rfc .= $homoclave;
    return $rfc;
}
