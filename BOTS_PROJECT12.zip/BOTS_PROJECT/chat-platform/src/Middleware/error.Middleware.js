const Joi = require('joi');

// Definimos el esquema de validación
// const userSchema = Joi.object({
//     email_user: Joi.string().min(3).max(30).required().messages({
//         "string.base": "El nombre de usuario debe ser un texto",
//         "string.empty": "El nombre de usuario es obligatorio",
//         "string.min": "El nombre de usuario debe tener al menos {#limit} caracteres",
//         "string.max": "El nombre de usuario no puede tener más de {#limit} caracteres",
//         "any.required": "El nombre de usuario es obligatorio"
//     }),
//     passwordHash: Joi.string().min(6).required()
// }).unknown(true);


const userSchema = Joi.object({
    email_user: Joi.string()
      .email({
        minDomainSegments: 2,
        tlds: { allow: false } // permite cualquier TLD (.com, .mx, .io, etc.)
      })
      .min(6)
      .max(100)
      .required()
      .messages({
        "string.base": "El correo electrónico debe ser un texto",
        "string.empty": "El correo electrónico es obligatorio",
        "string.email": "El correo electrónico no tiene un formato válido",
        "string.min": "El correo electrónico debe tener al menos {#limit} caracteres",
        "string.max": "El correo electrónico no puede tener más de {#limit} caracteres",
        "any.required": "El correo electrónico es obligatorio"
      }),
      passwordHash: Joi.string().min(6).required().messages({
        "string.min": "La password debe tener al menos {#limit} caracteres"
      }),
  }).unknown(true);

  

const UserSchema = Joi.object({
    id: Joi.number().integer().min(1).required().messages({
    "number.base": "El id debe ser un número",
    "number.integer": "El id debe ser un número entero",
    "number.min": "El id debe ser mayor a 0",
    "any.required": "El id es obligatorio"
  })
})


const loginSchema = Joi.object({
      email_user: Joi.string().required().messages({
        "string.base": "El user debe ser un texto",
        "any.required": "El user es obligatorio"
    }),
    passwordHash: Joi.string().required().messages({
        "string.base": "El password de usuario debe ser un Alfanumerico",
        "any.required": "El password de usuario es obligatorio"
    }),
})

const checkUser = (req, res, next) => {
    const { error } = userSchema.validate(req.body);
    if (error) {
        return res.status(400).json({ error: error.details[0].message });
    }
    next();
};

 const checkLogin = (req, res, next) => {
     const { error } = loginSchema.validate(req.body);

     if (error) {
         return res.status(400).json({ error: error.details[0].message });
     }
     next();
 }

 const checkGetUser = (req, res, next)=>{
     const { error } = UserSchema.validate(req.params);

     if (error) {
        return res.status(400).json({error: error.details[0].message})
     }
     next();
 }


const check = { checkUser, checkLogin, checkGetUser }

module.exports = check;
