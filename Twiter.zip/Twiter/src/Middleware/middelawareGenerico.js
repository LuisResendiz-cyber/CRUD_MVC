const Joi = require('joi');


function validateGenerci(ValidationSChema){
    const [[paloadKey, joiSChema]] = joi.entries(ValidationSChema);

    if (paloadKey != body || paloadKey != query && paloadKey != params) {
        throw new Error("Ivalidad payload key");
    }

}


return function validateMiddelaware(req, res, next){
    const error = validate(req[paloadKey], joiSChema);

    error ? next(error): next();
}


module.exports =  validateGenerci;