const customerModel = require("../models/webchat.models");

const webchatController = {
  async receiveMessage(req, res) {
    try {
      const { session_id, message } = req.body;

      const session = await customerModel.getOrCreateSession(session_id, "web");

      if (!session_id || !message) {
        return res.status(400).json({ error: "Datos incompletos" });
      }

      await customerModel.insertWebhookLog({
        event_type: "web_reply",
        wamid: null,
        status: "received",
        message_text: message,
        id_envio: session_id,
      });

      const reply = "Gracias por tu mensaje, en un momento te atendemos 😊";

      await customerModel.insertWebhookLog({
        event_type: "web_reply",
        wamid: null,
        status: "sent",
        message_text: reply,
        role: "assistant",
        id_envio: session_id,
      });

      res.json({ reply });
    } catch (error) {
      console.log(error);
    }
  },
  async historyConversation(req, res) {
    try {
      const { conversation_id } = req.params;

      const history = await customerModel.getHistory(conversation_id)

      res.json({ messages: history });

    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Error al obtener historial" });
    }
  },
};

module.exports = webchatController;
