<?php
date_default_timezone_set('America/Mexico_City');

include "adodb.inc.php";
include "tohtml.inc.php";
global $dbserver, $dbuser, $dbpassword, $dbschema;

$db = NewADOConnection("oci8");

if (($_SERVER['REMOTE_ADDR'] == '172.20.2.24') || ($_SERVER['REMOTE_ADDR'] == '172.20.2.12') || ($_SERVER['REMOTE_ADDR'] == '172.20.2.14') || ($_SERVER['REMOTE_ADDR'] == '172.20.2.7') || ($_SERVER['REMOTE_ADDR'] == '172.20.2.101')   ) {
//  $db->debug = true;
}
//$db->debug = true;
//$db->connectSID = true;
$db->PConnect($dbserver, $dbuser, $dbpassword, $dbschema) or die("No hay conexi&oacute;n");
?>
