const oracledb = require("oracledb");
const database = require("../services/database.js");

async function find(context) {
   console.log(context);
  const baseQuery =
    "BEGIN CITI.SPI_LOG_DID(:v_nomina, :v_archivo, :v_peso, :v_opcion, :rc); END;";
  let query = baseQuery;
  const binds = {};
  let result2 = {};
  let result = {};

  if (context.v_nomina == "" || context.v_archivo == "") {
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;
  } else {
    binds.v_nomina = context.v_nomina;
    binds.v_archivo = context.v_archivo;
    binds.v_peso = context.v_peso;
    binds.v_opcion = context.v_opcion;
    binds.rc = { dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_CURSOR };

    result = await database.simpleExecuteRC(query, binds);
     console.log(result);  

    return result;
  }
}

module.exports.find = find;
