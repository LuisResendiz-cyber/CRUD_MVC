const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
  console.log('**funcion para llamar a SPI_NEW_USER**');
  console.log(context);
  // const baseQuery = "BEGIN "+context.schema+".SPI_NEW_USER(:nomina, :perfil, :keys, :rc); END;";
  const baseQuery = "BEGIN "+context.schema+".SPI_NEW_USER(:nomina, :perfil, :rc); END;";

  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};   

  if(context.schema=='' || context.nomina=='' || context.perfil==''){
    // if(context.schema=='' || context.nomina=='' || context.perfil=='' || context.keys){
    //console.log("Parametros incorrectos")
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
  	binds.nomina = context.nomina;
    binds.perfil = context.perfil;
    // binds.keys = context.keyrig;
    binds.rc = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecuteRC(query, binds);
    console.log(result);
    return result;
  }
}

module.exports.find = find;
