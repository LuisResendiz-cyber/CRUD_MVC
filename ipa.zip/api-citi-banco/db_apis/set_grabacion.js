const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {
    console.log(context);
    
    try {
        const baseQuery = "BEGIN "+ context.schema +".SPI_GRABACION(:v_solicitud, :v_calificacion, :u_telefono, :rc); END;";
        let query = baseQuery;
        const binds = {};
        
        binds.v_solicitud     = context.u_persona;
        binds.v_calificacion     = context.calificacion;
        binds.u_telefono     = context.u_telefono;
        binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};
        
        const result = await database.simpleExecuteRC(query, binds);    

        return result;

    } catch (error) {
        console.log(error);
    }
}

module.exports.find = find;