<?php
# @uthor Mark
# Zonas File
require_once("includes/includes.inc.php");
require_once("mesa_control.inc.php");

initialize("mesa_control","Asignaci�n Zonas");

layout_menu($db ,'loadTree()');
?>
	<link rel="stylesheet" type="text/css" href="<?=$linkpath?>includes/dhtmlXTree/dhtmlXTree.css">
	<script  src="<?=$linkpath?>includes/dhtmlXTree/dhtmlXCommon.js"></script>
	<script  src="<?=$linkpath?>includes/dhtmlXTree/dhtmlXTree.js"></script>	
	
	<script>
		
		var tree;
		var xmlLoader = new dtmlXMLLoaderObject(doLoadDetails,window);
		var newItemLabel = "New Item";
		var newItemId = "-1";
		var aleatorio = parseInt(Math.random() * 100); 
		
		//LOAD TREE ON PAGE
		function loadTree(){
			tree = new dhtmlXTreeObject("treebox","100%","100%",0);
			tree.setImagePath("/ccupdate/includes/dhtmlXTree/imgs/");

			tree.enableTreeImages(0);
			tree.enableTreeLines(true);
			//tree.enableCheckBoxes(true)
			tree.enableThreeStateCheckboxes(false);
			
			tree.enableDragAndDrop(true);
			tree.setDragHandler(doOnBeforeDrop);
			tree.setOnClickHandler(doOnSelect);
			tree.loadXML("modules.php?mod=mesa_control&op=tree&nocache="+aleatorio);
			status();
		}
		
		//add new node next to currently selected (or the first in tree)
		function addNewPeer(){
			if(tree.getLevel(newItemId)!=0){//check if unsaved item already exists
				alert("New Item (unsaved) already exists")
				return false;
			}
			var selectedId = tree.getSelectedItemId();
			if(selectedId!=""){
				tree.insertNewNext(selectedId,newItemId,newItemLabel,"","","","","SELECT,CALL",0)
			}else{
				tree.insertNewItem(0,newItemId,newItemLabel,"","","","","SELECT,CALL",0)
			}
		}
		
		//add new child node to selected item (or the first item in tree)
		function addNewChild(){
			if(tree.getLevel(newItemId)!=0){//check if unsaved item already exists
				alert("New Item (unsaved) already exists")
				return false;
			}
			var selectedId = tree.getSelectedItemId();
			if(selectedId!=""){
				tree.insertNewItem(selectedId,newItemId,newItemLabel,"","","","","SELECT,CALL",0)
			}else{
				tree.insertNewItem(0,newItemId,newItemLabel,"","","","","SELECT,CALL",0)
			}
		}
		
		//delete item (from database)
		function deleteNode(){
			status(true);
			var f = document.forms["detailsForm"];
			if(tree.getSelectedItemId()!=newItemId){//delete node from db
				if(!confirm("Are you sure you want to delete selected node?"))
					return false;
				f.action = "deletenode.php"
				f.submit()
			}else{//delete unsaved node
				doDeleteTreeItem(newItemId);
			}
		}

		//remove item from tree
		function doDeleteTreeItem(id){
			document.getElementById("details").style.visibility = "hidden";
			var pId = tree.getParentId(id);
			tree.deleteItem(id);
			if(pId!="0")
				tree.selectItem(pId,true);
			status();
		}
		
		//save item
		function saveItem(){
			status(true);
			var f = document.forms["detailsForm"];
			f.action = "savenode.php";
			f.submit();
		}

		//save moved (droped) item to db. Cancel drop if save failed or item is new
		function doOnBeforeDrop(id,parentId){
			if(id==newItemId)
				return false;
			else{
				status(true);
				var dropSaver = new dtmlXMLLoaderObject(null,null,false);//sync mode
				dropSaver.loadXML("dropprocessor.php?id="+id+"&parent_id="+parentId);
				var root = dropSaver.getXMLTopNode("succeedded");
				var id = root.getAttribute("id");
				if(id==-1){
					alert("Save failed");
					status();
					return false;
				}else{
					if(tree.getSelectedItemId()==id){//update details (really need only parent id)
						loadDetails(id);
					}
				}
				status();
				return true;
			}
		}
		
		//update item
		function doUpdateItem(id, label){
			var f = document.forms["detailsForm"];
			f.item_id.value = id;
			tree.changeItemId(tree.getSelectedItemId(),id);
			tree.setItemText(id,label);
			tree.setItemColor(id,"black","white");
			status();
		}
		
		//AL SELECCIONAR UN ELEMENTO
		function doOnSelect(itemId){
			if(itemId!=newItemId){
				if(tree.getLevel(newItemId)!=0){
					if(confirm("Do you want to save changes?")){//save changes to new item
						tree.selectItem(newItemId,false)
						saveItem();
						return;
					}
					tree.deleteItem(newItemId);
				}	
			}else{//set color to new item label
				tree.setItemColor(itemId,"red","pink")
			}
			loadDetails(itemId);//load details for selected item
		}
		//send request to the server to load details
		
		function loadDetails(id){
			//document.getElementById('resp_act').style.display = "inline";
			//s_usr_id = document.frm1.s_usr_id.value;
			request = "s_usr_id="+id;
			send_post_page_n(request,"details","modules.php?mod=mesa_control&op=detalles&id="+id);
			
			//status(true);
			//xmlLoader.loadXML("detalles.php?id="+id);
		}
		
		//populate form of details
		function doLoadDetails(obj){
			var f = document.forms["detailsForm"];
			var root = xmlLoader.getXMLTopNode("details")
			var id = root.getAttribute("id");
			document.getElementById("details").style.visibility = "visible";
			if(id==newItemId){
				f.item_nm.value = tree.getItemText(id);
				f.item_desc.value = "";
			}else{
				f.item_nm.value = root.getElementsByTagName("name")[0].firstChild.nodeValue;
				if(root.getElementsByTagName("desc")[0].firstChild!=null)
					f.item_desc.value = root.getElementsByTagName("desc")[0].firstChild.nodeValue;
				else
					f.item_desc.value = "";
			}
			f.item_id.value = id
			f.item_order.value = get_order(id);
			f.item_parent_id.value = tree.getParentId(id);
			status();
		}

        function get_order(itemId){
            var z=tree._globalIdStorageFind(itemId);
            var z2=z.parentObject;
            for (var i=0; i<z2.childsCount; i++)
                if (z2.childNodes[i]==z) return i;
            return -1;
        }
		
		//show status of request on page
		function status(fl){
			var d = document.getElementById("showproc");
			if(fl)
				d.style.display = "";
			else
				d.style.display = "none";
		}
	</script>	
	
	<p class="textbold">Mesa Control &gt; Asignacion Zonas</p>
	<p>&nbsp;</p>
	<form name="frm1" action="modules.php?mod=mesa_control&op=zonas" method="post">
	<div id="showproc" style="display:block;">Procesando...</div>
	
	
	<table border="0" width="90%">
		<tr>
			<td>De click sobre la pesta�a para mostrar la informaci�n</td>
		</tr><tr>
			<td>&nbsp;<input type="hidden" size="20" name="id_solicitud" id="id_solicitud" value="<?=$id_solicitud?>" readonly></td>
		</tr><tr>
			<td>
				<div id="Accordion1" class="Accordion" tabindex="0" style="overflow: auto; margin: 0px; padding: 0px; height: 362px;">
					<div class="AccordionPanel">
						<div class="AccordionPanelTab"><b>Zonas</b></div>
						<div class="AccordionPanelContent" style="overflow: auto; margin: 0px; padding: 0px; height: 320px;">
							<table border="0">
								<tr align="center">
									<td bgcolor="grey" colspan="13">&nbsp;<td>
								</tr><tr align="center">
									<td><b>Grupo</b></td>
									<td>&nbsp;</td>
									<td><b>Zona</b></td>
									<td>&nbsp;</td>
									<td><b>Shot</b></td>
									<td>&nbsp;</td>
									<td><b>Nombre</b></td>
									<td>&nbsp;</td>
									<td><b>Activa</b></td>
									<td>&nbsp;</td>
									<td><b>Libres</b></td>
									<td>&nbsp;</td>
									<td><b>Abandonados</b></td>
								</tr>
									<?
									$zonas = get_detalle_zonas(0, 2, $db);
									while(!$zonas->EOF) {
										echo '
											<tr>
												<td align="center">'.$zonas->fields["IGRUPO_ID"].'</td>
												<td>&nbsp;</td>
												<td align="center">'.$zonas->fields["IZONA_ID"].'</td>
												<td>&nbsp;</td>
												<td>'.$zonas->fields["VSHOT"].'</td>
												<td>&nbsp;</td>
												<td>'.$zonas->fields["VNOMBRE"].'</td>
												<td>&nbsp;</td>
												<td align="center"><input type="checkbox" name="zona'.$zonas->fields["IZONA_ID"].'" '.($zonas->fields["IACTIVA"]!=0?" checked":"").' onclick="ActivaZonas('.$zonas->fields["IZONA_ID"].',this)"></td>
												<td>&nbsp;</td>
												<td align="center"><input type="hidden" name="libres'.$zonas->fields["IZONA_ID"].'" value="'.$zonas->fields["CUANTOS"].'">'.$zonas->fields["CUANTOS"].'</td>
												<td>&nbsp;</td>
												<td align="center"><input type="hidden" name="abandonados'.$zonas->fields["IZONA_ID"].'" value="'.$zonas->fields["ABANDONADOS"].'">'.$zonas->fields["ABANDONADOS"].'</td>
											</tr>';
										$zonas->MoveNext();
									}
									?>
								<tr>
									<td colspan="13"></td>
								</tr>
							</table>					
						</div>
					</div>	
					<div class="AccordionPanel">
						<div class="AccordionPanelTab"><b>Asignaci�n Zonas</b></div>
						<div class="AccordionPanelContent" style="overflow: auto; margin: 0px; padding: 0px; height: 300px;">
							<table border="0" width="80%">
								<tr>
									<td colspan="2">Seleccione al usuario para editar sus datos o de click sobre el icono <b>+</b> para mostrar a los agentes.</td>
								</tr><tr align="center" bgcolor="grey">
									<td width="40%"><b>Usuarios Disponibles<b></td>
									<td><b>Detalle<b></td>				
								</tr><tr align="center">
									<td>
										<div id="treebox" style="width:300px; height:250px; background-color:#f5f5f5; border :1px solid Silver;"/>
									</td>
									<td id="details"></td>
								<tr>
									<td coltd="2">&nbsp;&nbsp;</td>
								</tr>
							</table>														
					    </div>
					</div>
				</div>
			</td>
		</tr>
	</table>
	
	<script type="text/javascript">
<!--
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
//-->
</script>
	
	
	

	</form>
<?
layout_footer();
?>