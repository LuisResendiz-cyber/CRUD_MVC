const oracledb = require('oracledb');
const database = require('../services/database.js');

async function find(context) {

const baseQuery = "BEGIN DBO.xsp_gettimellamadaUser(:v_nomina, :v_schema, :v_llamada); END;"; //DBO

   console.log("autentico",context);
  let query = baseQuery;
  const binds = {}; //Define un objeto para la variable SP
  let result2 = {};

  if(!context.s_usr_nomina || !context.schema){
    result2.error_ = true;
    result2.mensaje = "Parametros Erroneos";
    return result2;

  } else{
    //console.log("Parametros correctos");
    //Se asignan los valores respecto a los parametros del SP
    binds.v_nomina = { val: context.s_usr_nomina , dir:oracledb.BIND_IN , type: oracledb.DB_TYPE_VARCHAR };
    binds.v_schema = {val:context.schema, dir:oracledb.BIND_IN, type:oracledb.DB_TYPE_VARCHAR};
    binds.v_llamada = {dir: oracledb.BIND_OUT, type: oracledb.DB_TYPE_VARCHAR};
    // binds.rc      = {dir:oracledb.BIND_OUT, type:oracledb.DB_TYPE_CURSOR};

    const result = await database.simpleExecute(query, binds);
     console.log(result);
    return result;
  }
}

module.exports.find = find;
