<?php
ini_set('display_errors', true);
ini_set("soap.wsdl_cache_enabled", "0");

require_once("lib/nusoap.php");
$client = new soapclient("http://172.20.1.72/rfc/server.php?wsdl");
// $nombre = $_GET['nombre'];
// $paterno = $_GET['paterno'];
// $materno = $_GET['materno'];
// $fecha = $_GET['fecha'];
$nombre = 'EDSON ULISES';
$paterno = 'JUAREZ';
$materno = '';
$fecha = '25/07/1998 ';
$result = $client->CalcularRFC($nombre, $paterno, $materno, $fecha);
echo "<pre>";
print_r($result);
echo "</pre>";
